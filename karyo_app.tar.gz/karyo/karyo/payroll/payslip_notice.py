"""Payslip availability notice (training manual, "Bulk email to view payslip on ESS").

Once a payroll period is closed, staff are emailed to verify their payslip on
Employee Self-Service. The manual keeps the group mailbox as a system parameter
(``PS_GROUP_MAIL``); here it is the Payslip Group Email on Karyo Payroll
Settings, and replies are directed to it.
"""

import frappe
from frappe import _

SUBJECT = "Your payslip for {period} is available"


def _settings():
	return frappe.get_cached_doc("Karyo Payroll Settings")


def _period_label(cycle):
	return cycle.get("pay_period_label") or frappe.utils.formatdate(cycle.get("end_date")) or cycle["name"]


def recipients(payroll_cycle):
	"""Employees with a submitted salary slip in this cycle, and their login."""
	cycle = frappe.db.get_value(
		"Payroll Cycle",
		payroll_cycle,
		["name", "payroll_entry", "pay_period_label", "company", "start_date", "end_date"],
		as_dict=True,
	)
	if not cycle:
		return None, []
	select = """select ss.employee, ss.employee_name, e.user_id, e.company_email, e.personal_email
		from `tabSalary Slip` ss inner join `tabEmployee` e on e.name = ss.employee
		where ss.docstatus = 1 and """
	if cycle.payroll_entry:
		rows = frappe.db.sql(select + "ss.payroll_entry = %s", cycle.payroll_entry, as_dict=True)
	elif cycle.start_date and cycle.end_date:
		# Slips posted outside a Payroll Entry still belong to the period.
		rows = frappe.db.sql(
			select + "ss.company = %s and ss.start_date >= %s and ss.end_date <= %s",
			(cycle.company, cycle.start_date, cycle.end_date),
			as_dict=True,
		)
	else:
		return cycle, []
	for row in rows:
		row["email"] = row.user_id or row.company_email or row.personal_email
	return cycle, [row for row in rows if row["email"]]


def period_recipients(payroll_period):
	period = frappe.db.get_value(
		"Payroll Period", payroll_period, ["name", "company", "start_date", "end_date"], as_dict=True
	)
	if not period:
		return None, []
	rows = frappe.db.sql(
		"""select ss.employee, ss.employee_name, e.user_id, e.company_email, e.personal_email
		from `tabSalary Slip` ss inner join `tabEmployee` e on e.name=ss.employee
		where ss.docstatus=1 and ss.company=%s and ss.start_date >= %s and ss.end_date <= %s""",
		(period.company, period.start_date, period.end_date), as_dict=True,
	)
	for row in rows:
		row["email"] = row.user_id or row.company_email or row.personal_email
	return period, [row for row in rows if row["email"]]


@frappe.whitelist()
def send_period_payslip_notice(payroll_period):
	"""Send a real availability notice for submitted slips in an annual period."""
	period = frappe.get_doc("Payroll Period", payroll_period)
	period.check_permission("write")
	period, people = period_recipients(period.name)
	if not people:
		return {"sent": 0, "skipped": _("No submitted salary slips carry a reachable email address.")}
	settings = _settings()
	group_email = (settings.payslip_group_email or "").strip()
	message = _(
		"Your payslip is now available. Sign in to Employee Self-Service and open My Payroll to view and verify it."
	)
	frappe.sendmail(
		recipients=sorted({row["email"] for row in people}),
		subject=SUBJECT.format(period=period.name), message=message,
		reply_to=group_email or None, reference_doctype="Payroll Period",
		reference_name=period.name, now=False,
	)
	frappe.get_doc({"doctype": "Comment", "comment_type": "Info",
		"reference_doctype": "Payroll Period", "reference_name": period.name,
		"content": _("Payslip availability notice sent to {0} employee(s).").format(len(people)),
	}).insert(ignore_permissions=True)
	return {"sent": len(people), "period": period.name, "group_email": group_email,
		"message": _("Payslip notice queued for {0} employee(s).").format(len(people))}


@frappe.whitelist()
def send_payslip_notice(payroll_cycle, force=False):
	"""Email every employee paid in the cycle that their payslip is on ESS."""
	if not frappe.has_permission("Payroll Cycle", "write", doc=payroll_cycle):
		frappe.throw(_("Not permitted to notify staff for this payroll cycle."), frappe.PermissionError)
	settings = _settings()
	if not settings.notify_payslip_on_close and not force:
		return {"sent": 0, "skipped": _("Payslip notices are switched off in MBC Payroll Settings.")}
	cycle, people = recipients(payroll_cycle)
	if not cycle:
		frappe.throw(_("Payroll Cycle not found."))
	if not people:
		return {"sent": 0, "skipped": _("No submitted salary slips carry a reachable email address.")}

	period = _period_label(cycle)
	group_email = (settings.payslip_group_email or "").strip()
	message = _(
		"Your payslip for {0} is now available. Sign in to Employee Self-Service "
		"and open My Payroll to view and verify it."
	).format(frappe.utils.escape_html(period))
	if group_email:
		message += "<br><br>" + _("Questions about your payslip should go to {0}.").format(
			frappe.utils.escape_html(group_email)
		)

	frappe.sendmail(
		recipients=[row["email"] for row in people],
		subject=SUBJECT.format(period=period),
		message=message,
		reply_to=group_email or None,
		reference_doctype="Payroll Cycle",
		reference_name=cycle.name,
		now=False,
	)
	frappe.get_doc(
		{
			"doctype": "Comment",
			"comment_type": "Info",
			"reference_doctype": "Payroll Cycle",
			"reference_name": cycle.name,
			"content": _("Payslip availability notice sent to {0} employee(s).").format(len(people)),
		}
	).insert(ignore_permissions=True)
	return {"sent": len(people), "period": period, "group_email": group_email}


def notify_on_close(payroll_cycle):
	"""Fire-and-forget notice used by the Close Payroll step.

	A mail failure must never leave a closed period looking unclosed, so the
	error is logged against the cycle instead of rolling the closure back.
	"""
	try:
		return send_payslip_notice(payroll_cycle)
	except Exception:
		frappe.log_error(
			title="Payslip availability notice failed",
			message=frappe.get_traceback(),
			reference_doctype="Payroll Cycle",
			reference_name=payroll_cycle,
		)
		return {"sent": 0, "error": True}
