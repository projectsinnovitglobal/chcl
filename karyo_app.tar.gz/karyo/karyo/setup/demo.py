"""Seed a small demo dataset so the Karyo workspace + reports show content.

    bench --site dev.localhost execute karyo.setup.demo.seed

Idempotent-ish: skips employees/records that already exist by name. Safe to
re-run. Intended for the demo site only.
"""

import frappe
from frappe.model.workflow import apply_workflow

STRUCTURE = "Karyo Demo Structure"


def _company():
	return "SIL" if frappe.db.exists("Company", "SIL") else frappe.db.get_value("Company", {}, "name")


def _ensure_structure(company):
	if not frappe.db.exists("Salary Component", "Karyo Basic"):
		frappe.get_doc(
			{
				"doctype": "Salary Component",
				"salary_component": "Karyo Basic",
				"salary_component_abbr": "KB",
				"type": "Earning",
			}
		).insert(ignore_permissions=True)
	if not frappe.db.exists("Salary Structure", STRUCTURE):
		ss = frappe.get_doc(
			{
				"doctype": "Salary Structure",
				"name": STRUCTURE,
				"company": company,
				"payroll_frequency": "Monthly",
				"earnings": [{"salary_component": "Karyo Basic", "amount": 40000}],
			}
		)
		ss.insert(ignore_permissions=True)
		ss.submit()


def _employee(company, full_name, dob, base):
	existing = frappe.db.get_value("Employee", {"employee_name": full_name}, "name")
	if existing:
		return existing
	first, last = full_name.split(" ", 1)
	emp = frappe.get_doc(
		{
			"doctype": "Employee",
			"first_name": first,
			"last_name": last,
			"gender": frappe.db.get_value("Gender", {}, "name") or "Male",
			"date_of_birth": dob,
			"date_of_joining": "2015-01-01",
			"company": company,
			"status": "Active",
			"pb_eligible": 1,
			"employment_type": "Permanent",
			"karyo_employment_category": "PERM",
			"karyo_permanent_pensionable": 1,
			"karyo_date_confirmed": "2020-01-01",
		}
	).insert(ignore_permissions=True, ignore_mandatory=True)
	frappe.get_doc(
		{
			"doctype": "Salary Structure Assignment",
			"employee": emp.name,
			"salary_structure": STRUCTURE,
			"company": company,
			"from_date": "2015-01-01",
			"base": base,
		}
	).insert(ignore_permissions=True).submit()
	return emp.name


def _usage_items():
	items = [
		("AIRTICKET", "Air Ticket", 100, 0),
		("MEDICAL", "Medical Treatment", 100, 1000),
		("EXAM", "Examination Fees", 100, 0),
	]
	for code, name, rate, minbal in items:
		if not frappe.db.exists("Passage Benefit Usage Item", code):
			frappe.get_doc(
				{
					"doctype": "Passage Benefit Usage Item",
					"usage_item_code": code,
					"usage_item_name": name,
					"encash_rate": rate,
					"min_balance_credit": minbal,
					"is_active": 1,
				}
			).insert(ignore_permissions=True)


def _loan_types():
	for code, name, rate in [("PERSONAL", "Personal Loan", 6), ("MOTOR", "Motor Vehicle Loan", 8)]:
		if not frappe.db.exists("Loan Type", code):
			frappe.get_doc(
				{
					"doctype": "Loan Type",
					"loan_code": code,
					"loan_name": name,
					"loan_category": "Personal",
					"interest_rate": rate,
					"max_period_months": 120,
					"is_active": 1,
					"recast_cap_pct": 5,
					"pdb_capital": "Karyo Loan Capital",
					"pdb_interest": "Karyo Loan Interest",
					"pdb_insurance": "Karyo Loan Insurance",
				}
			).insert(ignore_permissions=True)
		else:
			frappe.db.set_value("Loan Type", code, {
				"pdb_capital": "Karyo Loan Capital",
				"pdb_interest": "Karyo Loan Interest",
				"pdb_insurance": "Karyo Loan Insurance",
			})


def _reference_data():
	if not frappe.db.exists("Loan Recomputation Parameter", {"function": "RECAST"}):
		frappe.get_doc(
			{
				"doctype": "Loan Recomputation Parameter",
				"function": "RECAST",
				"loan_type": "PERSONAL",
				"value": 5,
				"start_date": "2020-01-01",
				"is_active": 1,
				"remarks": "Standard recast cap",
			}
		).insert(ignore_permissions=True)
	if not frappe.db.exists("Loan Insurance Rate", {"loan_code": "ALL"}):
		bands = [(18, 39, 25.00), (40, 49, 29.19), (50, 65, 35.00)]
		for min_age, max_age, rate in bands:
			frappe.get_doc(
				{
					"doctype": "Loan Insurance Rate",
					"loan_code": "ALL",
					"min_age": min_age,
					"max_age": max_age,
					"min_term_months": 0,
					"max_term_months": 999,
					"rate": rate,
					"effective_date": "2020-01-01",
					"threshold": 100000,
				}
			).insert(ignore_permissions=True)


def _pb_bank_and_earn(employee, base):
	if not frappe.db.exists("Passage Benefit Bank", employee):
		frappe.get_doc(
			{
				"doctype": "Passage Benefit Bank",
				"employee": employee,
				"opening_date": "2026-01-01",
				"opening_balance": 0,
			}
		).insert(ignore_permissions=True)
	if frappe.db.exists("Passage Benefit Computation", {"employee": employee, "docstatus": 1}):
		return
	comp = frappe.get_doc(
		{
			"doctype": "Passage Benefit Computation",
			"employee": employee,
			"from_date": "2026-01-01",
			"to_date": "2026-04-30",
			"pay_period": "Apr-2026",
			"segments": [{"monthly_salary": base, "eligible_days": 120}],
		}
	)
	comp.insert(ignore_permissions=True)
	comp.submit()


def _pb_claim(employee):
	if frappe.db.exists("Passage Benefit Application", {"employee": employee}):
		return
	app = frappe.get_doc(
		{
			"doctype": "Passage Benefit Application",
			"employee": employee,
			"usage_item": "AIRTICKET",
			"request_amount": 3000,
			"posting_date": "2026-05-10",
			"pay_period": "May-2026",
		}
	)
	app.insert(ignore_permissions=True)
	for action in ("Submit for Approval", "Recommend", "Approve", "Process"):
		app = apply_workflow(app, action)


def _active_loan(employee, company, guarantors=None):
	# A consumed demo can leave a Draft/Returned/Settled loan behind. Reuse only an
	# actually active scenario; otherwise create a fresh journey that can safely be
	# progressed through the workflow and used by the recast demonstration.
	existing = frappe.db.get_value(
		"Karyo Loan", {"employee": employee, "status": "Active", "docstatus": 1}, "name"
	)
	if existing:
		return existing
	loan = frappe.get_doc(
		{
			"doctype": "Karyo Loan",
			"employee": employee,
			"loan_type": "PERSONAL",
			"company": company,
			"approved_amount": 300000,
			"period_months": 60,
			"eligible_salary": 90000,
			"disbursement_date": "2026-06-01",
			"repayment_start_date": "2026-06-01",
			"guarantors": [{"guarantor": g} for g in (guarantors or [])],
		}
	)
	loan.insert(ignore_permissions=True)
	for action in (
		"Print Application",
		"Schedule Committee",
		"Start Review",
		"Recommend",
		"Approve",
		"Disburse",
		"Activate",
	):
		loan = apply_workflow(loan, action)
	return loan.name


def _recast_example(loan_name):
	if frappe.db.exists("Karyo Loan Recast", {"loan": loan_name, "docstatus": 1}):
		return
	rc = frappe.get_doc(
		{
			"doctype": "Karyo Loan Recast",
			"loan": loan_name,
			"effective_date": "2026-09-01",
			"advance_payment": 50000,
			"new_period": 54,
		}
	)
	rc.insert(ignore_permissions=True)
	rc.submit()


def seed():
	company = _company()
	if not company:
		print("SKIP: no Company on site")
		return
	print("Seeding Karyo demo data...")
	frappe.db.set_single_value("Karyo Settings", "max_deduction_pct", 40)
	_ensure_structure(company)
	_usage_items()
	_loan_types()
	_reference_data()

	people = [
		("Amara Boodhun", "1988-03-12", 45000),
		("Devan Ramsamy", "1985-07-01", 60000),
		("Priya Luchoomun", "1990-11-23", 90000),
	]
	emps = [_employee(company, n, dob, base) for n, dob, base in people]
	for emp, (_n, _d, base) in zip(emps, people):
		_pb_bank_and_earn(emp, base)
	_pb_claim(emps[0])
	loan_name = _active_loan(emps[2], company, guarantors=[emps[0], emps[1]])
	if loan_name:
		_recast_example(loan_name)

	frappe.db.commit()
	print(
		f"Done. Seeded {len(emps)} employees, PB banks + claim, an active loan (2 guarantors) and a recast."
	)


def _cancel_additional_salary(name):
	if name and frappe.db.get_value("Additional Salary", name, "docstatus") == 1:
		a = frappe.get_doc("Additional Salary", name)
		a.flags.ignore_links = True
		a.cancel()
	if name and frappe.db.exists("Additional Salary", name):
		frappe.delete_doc("Additional Salary", name, force=True, ignore_permissions=True)


def reset_loans():
	"""Remove demo loans + recasts (and their payroll deductions) so seed() can
	rebuild them with guarantors + a recast. Demo site only."""
	for name in frappe.get_all("Karyo Loan Recast", pluck="name"):
		rc = frappe.get_doc("Karyo Loan Recast", name)
		for d in rc.deductions or []:
			_cancel_additional_salary(d.additional_salary)
		if rc.docstatus == 1:
			rc.flags.ignore_links = True
			rc.cancel()
		frappe.delete_doc("Karyo Loan Recast", name, force=True, ignore_permissions=True)
	for name in frappe.get_all("Karyo Loan", pluck="name"):
		loan = frappe.get_doc("Karyo Loan", name)
		for d in loan.deductions or []:
			_cancel_additional_salary(d.additional_salary)
		if loan.docstatus == 1:
			loan.flags.ignore_links = True
			loan.cancel()
		frappe.delete_doc("Karyo Loan", name, force=True, ignore_permissions=True)
	frappe.db.commit()
	print("Demo loans + recasts reset.")
