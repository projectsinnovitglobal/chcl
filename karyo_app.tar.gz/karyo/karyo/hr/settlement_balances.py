"""Dated leaving-service leave positions; annual allocations and banks stay separate."""

import frappe
from frappe.utils import add_days, cint, flt, getdate


def _leave_days(employee, row, start, end):
	from hrms.hr.doctype.leave_application.leave_application import get_number_of_leave_days

	if getdate(start) > getdate(end):
		return 0.0
	if getdate(start) == getdate(row.from_date) and getdate(end) == getdate(row.to_date):
		return flt(row.total_leave_days)
	half_date = row.get("half_day_date")
	half = cint(row.get("half_day")) and half_date and getdate(start) <= getdate(half_date) <= getdate(end)
	return flt(get_number_of_leave_days(employee, row.leave_type, start, end, cint(bool(half)), half_date))


def _legacy_balance(employee, code, as_at):
	if not frappe.db.exists("DocType", "Leave Balance"):
		return 0.0, []
	row = frappe.db.get_value("Leave Balance", {
		"employee": employee, "leave_code": code, "as_at_date": ("<=", as_at), "is_system_synced": 0,
	}, ["name", "as_at_date", "closing_balance"], order_by="as_at_date desc, modified desc", as_dict=True)
	if not row:
		return 0.0, []
	taken = 0.0
	if frappe.db.exists("DocType", "Leave Transaction"):
		taken = flt(frappe.db.get_value("Leave Transaction", {
			"employee": employee, "leave_code": code, "cancelled": 0,
			"legacy_status": ("in", ["Approved", "Taken", "Posted", "Completed", "Closed"]),
			"start_date": (">", row.as_at_date), "end_date": ("<=", as_at),
		}, "sum(duration_units)"))
	return max(0, flt(row.closing_balance) - taken), [{"doctype": "Leave Balance", "name": row.name}]


def current_leave_as_at(employee, as_at, code):
	"""Count posted allocation balances through the cut-off, excluding future/pending leave."""
	from hrms.hr.doctype.leave_application.leave_application import (
		get_allocation_expiry_for_cf_leaves, get_leave_allocation_records, get_leaves_for_period,
	)
	from karyo.hr.lateness import posted_lateness_days

	allocations = frappe.db.sql("""
		select a.name, a.leave_type, a.from_date from `tabLeave Allocation` a
		inner join `tabLeave Type` t on t.name=a.leave_type
		where a.employee=%s and a.docstatus=1 and a.from_date<=%s and a.to_date>=%s
		and (t.karyo_mbc_leave_code=%s or
			(coalesce(t.karyo_mbc_leave_code,'')='' and t.name=%s and t.is_lwp=0))
		order by a.from_date desc
	""", (employee, as_at, as_at, code, "Sick Leave" if code == "SICK01" else "Annual Leave"), as_dict=True)
	if not allocations:
		return _legacy_balance(employee, code, as_at)
	seen, balance = set(), 0.0
	for allocation in allocations:
		if allocation.leave_type in seen:
			continue
		seen.add(allocation.leave_type)
		period = get_leave_allocation_records(employee, as_at, allocation.leave_type).get(allocation.leave_type)
		if not period:
			continue
		expiry = get_allocation_expiry_for_cf_leaves(employee, allocation.leave_type, as_at, period.from_date)
		if expiry and flt(period.unused_leaves):
			# Native carry-forward helpers read through allocation.to_date. Bound both
			# consumption windows explicitly so approved future leave cannot affect exit.
			cf_end = min(getdate(expiry), getdate(as_at))
			cf_taken = -flt(get_leaves_for_period(employee, allocation.leave_type, period.from_date, cf_end))
			new_start = getdate(add_days(expiry, 1))
			new_taken = -flt(get_leaves_for_period(employee, allocation.leave_type, new_start, as_at)) if new_start <= getdate(as_at) else 0
			new_taken += max(0, cf_taken - flt(period.unused_leaves))
			cf_remaining = max(0, flt(period.unused_leaves) - cf_taken) if getdate(as_at) <= getdate(expiry) else 0
			amount = flt(period.new_leaves_allocated) - new_taken + cf_remaining
		else:
			amount = flt(period.total_leaves_allocated) + flt(get_leaves_for_period(employee, allocation.leave_type, period.from_date, as_at))
		# Include every posted manual expiry through the cut-off, including the date
		# itself, rather than the native helper's first entry before the cut-off.
		amount += flt(frappe.db.get_value("Leave Ledger Entry", {
			"employee": employee, "leave_type": allocation.leave_type, "docstatus": 1,
			"transaction_type": "Leave Allocation", "is_expired": 1, "is_carry_forward": 0,
			"from_date": (">=", period.from_date), "to_date": ("<=", as_at),
		}, "sum(leaves)"))
		amount -= posted_lateness_days(employee, allocation.leave_type, period.from_date, as_at)
		balance += max(0, amount)
	return balance, [{"doctype": "Leave Allocation", "name": row.name} for row in allocations]


def bank_balance_as_at(employee, as_at, bank_type):
	"""Reverse dated future movements out of the authoritative live bank.

	Year-end postings are effective on 31 December of their year. Approved future
	bank leave already reduces the live bank when submitted, so restore its portion
	after the leaving date. Advance Sick Leave is a separate account.
	"""
	as_at = getdate(as_at)
	is_sick = bank_type == "Sick Leave Bank"
	code = "SICK02" if is_sick else "VAC01"
	field = "bank_days" if is_sick else "balance_days"
	bank = frappe.db.get_value(bank_type, {"employee": employee}, ["name", field], as_dict=True)
	if not bank:
		return _legacy_balance(employee, code, as_at)
	opening = frappe.db.get_value("Leave Opening Balance", {
		"employee": employee, "balance_source": bank_type, "docstatus": 1,
	}, ["name", "balance_as_at_date"], as_dict=True)
	if opening and getdate(opening.balance_as_at_date) > as_at:
		return 0.0, []
	balance = flt(bank.get(field))
	refs = [{"doctype": bank_type, "name": bank.name}]
	posting_type = "Sick Leave Bank Posting" if is_sick else "Vacation Leave Posting"
	opening_field = "opening_bank_days" if is_sick else "opening_balance_days"
	closing_field = "closing_bank_days" if is_sick else "closing_balance_days"
	postings = frappe.get_all(posting_type, filters={"employee": employee, "docstatus": 1},
		fields=["name", "year", opening_field, closing_field], limit_page_length=0)
	for posting in postings:
		if getdate(f"{cint(posting.year)}-12-31") > as_at:
			balance -= flt(posting.get(closing_field)) - flt(posting.get(opening_field))
		else:
			refs.append({"doctype": posting_type, "name": posting.name})
	future_leave = frappe.db.sql("""
		select a.name, a.leave_type, a.from_date, a.to_date, a.total_leave_days,
			a.half_day, a.half_day_date from `tabLeave Application` a
		inner join `tabLeave Type` t on t.name=a.leave_type
		where a.employee=%s and a.docstatus=1 and a.status='Approved' and a.to_date>%s
		and t.karyo_bank_type=%s and coalesce(t.karyo_mbc_leave_code,'') not in ('SICK03','SICK04')
	""", (employee, as_at, bank_type), as_dict=True)
	for row in future_leave:
		balance += _leave_days(employee, row, max(getdate(row.from_date), getdate(add_days(as_at, 1))), row.to_date)
	return max(0, flt(balance, 2)), refs


def leave_position_as_at(employee, as_at):
	as_at = getdate(as_at)
	sick_current, sick_current_refs = current_leave_as_at(employee, as_at, "SICK01")
	# A closed year has already transferred/refunded its unused annual sick days.
	if (as_at.month, as_at.day) == (12, 31) and frappe.db.exists("Sick Leave Bank Posting", {
		"employee": employee, "year": as_at.year, "docstatus": 1,
	}):
		sick_current = 0.0
	sick_bank, sick_bank_refs = bank_balance_as_at(employee, as_at, "Sick Leave Bank")
	annual_current, annual_current_refs = current_leave_as_at(employee, as_at, "ANN")
	annual_bank, annual_bank_refs = bank_balance_as_at(employee, as_at, "Vacation Leave Bank")
	return {
		"sick_current_days": flt(sick_current, 2), "sick_bank_days": flt(sick_bank, 2),
		"annual_current_days": flt(annual_current, 2), "annual_bank_days": flt(annual_bank, 2),
		"references": {"sick_current": sick_current_refs, "sick_bank": sick_bank_refs,
			"annual_current": annual_current_refs, "annual_bank": annual_bank_refs},
	}
