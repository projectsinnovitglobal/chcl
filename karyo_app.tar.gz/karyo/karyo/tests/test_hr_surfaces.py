"""Governed promotion salaries and status-aware register controls."""
import unittest
import frappe
from karyo.desk.hr_surface import actions
from karyo.hr.lifecycle import prepare_employee_promotion, prepare_employee_promotion_salary
from karyo.payroll.salary_scales import allocation_options, grade_scale


class TestHRSurfaces(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('hr_surfaces_test')
        self.employee = frappe.db.get_value('Employee', {'status': 'Active'}, 'name')
        self.assertTrue(self.employee)

    def tearDown(self):
        frappe.db.rollback(save_point='hr_surfaces_test')
        frappe.set_user(self.user)

    def promotion(self):
        return frappe.get_doc(dict(doctype='Employee Promotion', employee=self.employee,
            promotion_date=frappe.utils.today(), current_ctc=0, revised_ctc=420000)).insert()

    def test_free_form_promotion_salary_is_ignored_without_grade_change(self):
        meta=frappe.get_meta('Employee Promotion')
        self.assertFalse(meta.get_field('revised_ctc').depends_on)
        self.assertFalse(meta.get_field('current_ctc').mandatory_depends_on)
        self.assertTrue(meta.get_field('current_ctc').read_only)
        self.assertTrue(meta.get_field('revised_ctc').read_only)
        self.assertEqual(meta.get_field('current_ctc').label, 'Current Basic Salary')
        self.assertEqual(meta.get_field('revised_ctc').label, 'New Basic Salary')
        self.assertTrue(meta.get_field('karyo_new_salary_point'))
        self.assertFalse(meta.quick_entry)
        previous=frappe.db.get_value('Employee', self.employee, 'ctc')
        doc=self.promotion()
        doc.revised_ctc=450000
        doc.save()
        self.assertFalse(frappe.db.get_value('Employee Promotion',doc.name,'revised_ctc'))
        self.assertEqual(frappe.db.get_value('Employee',self.employee,'ctc'),previous)

    def test_grade_promotion_salary_must_come_from_destination_scale(self):
        today = frappe.utils.getdate()
        candidates = [row for row in frappe.get_all(
            'Employee Salary Appointment',
            filters={'docstatus': 1, 'pay_basis': 'Grade Scale', 'effective_from': ('<', today)},
            fields=['employee', 'grade', 'salary_point', 'basic_salary', 'effective_from', 'effective_to'],
            order_by='effective_from asc', limit_page_length=0,
        ) if (not row.effective_to or frappe.utils.getdate(row.effective_to) >= today)
            and frappe.db.get_value('Employee', row.employee, 'status') == 'Active']
        current = None
        for candidate in candidates:
            try:
                grade_scale(candidate.grade, candidate.effective_from)
            except frappe.ValidationError:
                continue
            current = candidate
            break
        if not current:
            self.skipTest('No active employee with an existing Grade Scale appointment')

        target = options = None
        for grade in frappe.get_all('Employee Grade', filters={'name': ('!=', current.grade)}, pluck='name'):
            try:
                candidate = allocation_options(grade, today).get('points') or []
            except frappe.ValidationError:
                continue
            if candidate:
                target, options = grade, candidate
                break
        if not target:
            self.skipTest('No alternate grade with an approved current salary scale')

        chosen = options[-1]
        doc = frappe.get_doc({
            'doctype': 'Employee Promotion',
            'employee': current.employee,
            'promotion_date': today,
            'revised_ctc': 999999,
            'karyo_new_salary_point': str(chosen['salary_point']),
            'promotion_details': [{
                'property': 'Grade', 'fieldname': 'grade',
                'current': current.grade, 'new': target,
            }],
        })
        prepare_employee_promotion_salary(doc)
        self.assertEqual(doc.current_ctc, current.basic_salary)
        self.assertEqual(doc.revised_ctc, chosen['salary'])

        invalid = frappe.copy_doc(doc)
        invalid.karyo_new_salary_point = '999999'
        invalid.revised_ctc = 999999
        prepare_employee_promotion_salary(invalid)
        self.assertFalse(invalid.revised_ctc)
        with self.assertRaises(frappe.ValidationError):
            prepare_employee_promotion(invalid)

        doc.insert()
        doc.submit()
        appointment = frappe.get_doc('Employee Salary Appointment', doc.karyo_salary_appointment)
        self.assertEqual(appointment.grade, target)
        self.assertEqual(str(appointment.salary_point), str(chosen['salary_point']))
        self.assertEqual(appointment.basic_salary, chosen['salary'])
        employee = frappe.db.get_value(
            'Employee', current.employee, ['grade', 'karyo_scale_basic_salary', 'ctc'], as_dict=True,
        )
        self.assertEqual(employee.grade, target)
        self.assertEqual(employee.karyo_scale_basic_salary, chosen['salary'])
        self.assertEqual(employee.ctc, chosen['salary'])

    def test_record_status_controls(self):
        doc=self.promotion()
        self.assertEqual(actions(doc.doctype,[doc.name])[doc.name], {'edit':True,'delete':True})
        # Model a submitted/cancelled status without invoking financial side effects.
        frappe.db.set_value(doc.doctype,doc.name,'docstatus',1)
        self.assertEqual(actions(doc.doctype,[doc.name])[doc.name], {'edit':False,'delete':False})
        frappe.db.set_value(doc.doctype,doc.name,'docstatus',2)
        self.assertEqual(actions(doc.doctype,[doc.name])[doc.name], {'edit':False,'delete':True})

    def test_guest_cannot_request_actions(self):
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            actions('Employee Promotion',[])

    def test_limit(self):
        with self.assertRaises(frappe.ValidationError):
            actions('Employee Promotion',['x']*501)

    def test_master_enable_state(self):
        name=frappe.db.get_value('Department', {}, 'name')
        self.assertTrue(name)
        doc=frappe.get_doc('Department',name)
        state=actions('Department',[name])[name]
        self.assertEqual(state['toggle'], {'field':'disabled', 'value':bool(doc.disabled), 'can_write':True})
