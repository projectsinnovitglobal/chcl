"""Reference-screen fields for governed employee promotions and transfers."""
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


def movement_fields(doctype):
    promotion = doctype == 'Employee Promotion'
    fields = [
        ('karyo_movement_section', 'Section Break', 'Appointment / Posting / Promotion' if promotion else 'Transfer to Department', {}),
        ('karyo_appointment_type', 'Select', 'Appointment', {'options': 'Appointment\nPosting\nPromotion\nTransfer', 'default': 'Promotion' if promotion else 'Transfer'}),
        ('karyo_probation_start', 'Date', 'Probation Start Date', {}),
        ('karyo_vacancy_reference', 'Data', 'Vacancy Ref.', {}),
        ('karyo_new_grade', 'Link', 'New Grade', {'options': 'Employee Grade'}),
        ('karyo_new_section', 'Link', 'New Section', {'options': 'Employee Section'}),
        ('karyo_end_date', 'Date', 'End Date', {}),
        ('karyo_salary_scale', 'Link', 'Salary Scale Code', {'options': 'Salary Scale', 'read_only': 1}),
        ('karyo_rate', 'Currency', 'Rate', {'read_only': 1, 'precision': '2', 'description': 'Normal hourly rate from the approved monthly salary and employee work pattern.'}),
        ('karyo_movement_column', 'Column Break', '', {}),
        ('karyo_employment_type', 'Link', 'Type', {'options': 'Employment Type'}),
        ('karyo_probation_end', 'Date', 'Probation End Date', {}),
        ('karyo_new_department', 'Link', 'New Department', {'options': 'Department', 'reqd': 1}),
        ('karyo_new_location', 'Link', 'New Location / Unit', {'options': 'Employee Location'}),
        ('karyo_new_salary_point', 'Select', 'Salary Point', {'options': ''}),
        ('beyond_scale_authorized', 'Check', 'Long Service Increment', {}),
        ('beyond_scale_salary', 'Currency', 'Authorized Basic Salary', {'precision': '2', 'depends_on': 'eval:doc.beyond_scale_authorized', 'mandatory_depends_on': 'eval:doc.beyond_scale_authorized'}),
        ('karyo_salary_display', 'Currency', 'Salary', {'read_only': 1, 'precision': '2'}),
        ('karyo_movement_site_column', 'Column Break', '', {}),
        ('karyo_site', 'Data', 'Site', {'read_only': 1}),
        ('karyo_seniority', 'Data', 'Level of Seniority', {}),
        ('karyo_date_appointed', 'Date', 'Date Appointed', {}),
        ('beyond_scale_authority', 'Small Text', 'Beyond-Scale Authority / Reference', {'depends_on': 'eval:doc.beyond_scale_authorized', 'mandatory_depends_on': 'eval:doc.beyond_scale_authorized'}),
        ('beyond_scale_reason', 'Small Text', 'Long-Service Justification', {'depends_on': 'eval:doc.beyond_scale_authorized', 'mandatory_depends_on': 'eval:doc.beyond_scale_authorized'}),
        ('karyo_movement_notes_section', 'Section Break', '', {}),
        ('karyo_movement_remarks', 'Small Text', 'Remarks', {}),
        ('karyo_structure_section', 'Section Break', 'Payroll Structure Mapping', {}),
        ('karyo_salary_structure', 'Link', 'Salary Structure', {'options': 'Salary Structure', 'description': 'Defaults to the current salary assignment. Required for an initial appointment without a salary assignment.'}),
        ('karyo_income_tax_slab', 'Link', 'Income Tax Slab', {'options': 'Income Tax Slab'}),
    ]
    result = []
    after = 'promotion_date' if promotion else 'transfer_date'
    for name, kind, label, options in fields:
        result.append(dict(fieldname=name, fieldtype=kind, label=label, insert_after=after, **options))
        after = name
    if not promotion:
        for name, kind, label, options in [
            ('current_ctc', 'Currency', 'Current Basic Salary', {'read_only': 1}),
            ('revised_ctc', 'Currency', 'New Basic Salary', {'read_only': 1}),
            ('karyo_salary_appointment', 'Link', 'Salary Appointment', {'options': 'Employee Salary Appointment', 'read_only': 1, 'hidden': 1, 'no_copy': 1}),
            ('karyo_previous_salary_appointment', 'Link', 'Previous Salary Appointment', {'options': 'Employee Salary Appointment', 'read_only': 1, 'hidden': 1, 'no_copy': 1}),
            ('karyo_previous_salary_effective_to', 'Date', 'Previous Salary Effective To', {'read_only': 1, 'hidden': 1, 'no_copy': 1}),
        ]:
            result.append(dict(fieldname=name, fieldtype=kind, label=label, insert_after=after, **options))
            after = name
    return result


def apply():
    create_custom_fields({
        'Employee Promotion': movement_fields('Employee Promotion'),
        'Employee Transfer': movement_fields('Employee Transfer'),
        'Employee': [
            {'fieldname': 'karyo_probation_start_date', 'fieldtype': 'Date', 'label': 'Probation Start Date', 'insert_after': 'scheduled_confirmation_date'},
            {'fieldname': 'karyo_vacancy_reference', 'fieldtype': 'Small Text', 'label': 'Vacancy Ref.', 'insert_after': 'karyo_probation_start_date'},
            {'fieldname': 'karyo_level_of_seniority', 'fieldtype': 'Small Text', 'label': 'Level of Seniority', 'insert_after': 'karyo_vacancy_reference'},
            {'fieldname': 'karyo_date_appointed', 'fieldtype': 'Date', 'label': 'Date Appointed', 'insert_after': 'karyo_level_of_seniority'},
        ],
    }, update=True)
    for doctype, field in [('Employee Promotion', 'promotion_date'), ('Employee Transfer', 'transfer_date')]:
        make_property_setter(doctype, field, 'label', 'Start Date', 'Data', validate_fields_for_doctype=False)
        frappe.clear_cache(doctype=doctype)
    # Keep existing records and integrations on the same authorization field.
    for field, value, kind in [
        ('label', 'Long Service Increment', 'Data'),
        ('insert_after', 'salary_point', 'Data'),
    ]:
        make_property_setter('Employee Salary Appointment', 'beyond_scale_authorized', field, value, kind, validate_fields_for_doctype=False)
    frappe.clear_cache(doctype='Employee Salary Appointment')
