# Copyright (c) 2026, AstraFlow and Contributors
# See license.txt

"""Phase 4 — §9.2 reports + screens 9/10/11 inquiry APIs.

Builds one eligible employee with salary history, a bank, a submitted computation
(earning + rolled period + segment log), a claim and an adjustment, then asserts
each report surfaces the employee and the three inquiry APIs return correct data.
The audit compute (screen 10) must never mutate the PB Bank.

    bench --site dev.localhost run-tests --module karyo.passage_benefit.test_pb_reporting
"""

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.pb_adjustment_audit.pb_adjustment_audit import execute as run_adjustment_audit
from karyo.karyo.report.pb_bank_balance_listing.pb_bank_balance_listing import execute as run_bank_listing
from karyo.karyo.report.pb_computation_log.pb_computation_log import execute as run_computation_log
from karyo.karyo.report.pb_exception_report.pb_exception_report import execute as run_exception_report
from karyo.karyo.report.pb_request_register.pb_request_register import execute as run_request_register
from karyo.passage_benefit import inquiry
from karyo.tasks import run_passage_benefit_period


class TestPassageBenefitReporting(FrappeTestCase):
	def setUp(self):
		frappe.db.set_single_value("Passage Benefit Settings", "entitlement_operation_code", "GSAL")
		frappe.db.delete("Passage Benefit Parameter Version", {"parent": "Passage Benefit Settings"})
		self.company = frappe.db.get_value("Company", {}, "name")
		if not self.company:
			self.skipTest("no Company on site")
		frappe.db.set_single_value("Passage Benefit Settings", "min_salary_threshold", 0)
		frappe.db.set_single_value("Passage Benefit Settings", "min_years_service", 10)
		frappe.db.set_single_value("Passage Benefit Settings", "eligibility_mode", "Route-based (salary or service)")
		frappe.db.set_single_value("Passage Benefit Settings", "require_confirmation", 0)
		frappe.db.set_single_value("Passage Benefit Settings", "require_permanent_employee", 0)
		frappe.db.set_single_value("Passage Benefit Settings", "vacation_leave_type", None)

		self.emp = frappe.get_doc(
			{
				"doctype": "Employee",
				"first_name": "Karyo",
				"last_name": "Reporting",
				"gender": frappe.db.get_value("Gender", {}, "name") or "Male",
				"date_of_birth": "1985-01-01",
				"date_of_joining": "2015-01-01",
				"company": self.company,
				"status": "Active",
				"pb_eligible": 1,
			}
		).insert(ignore_permissions=True, ignore_mandatory=True)

		if not frappe.db.exists("Salary Component", "Karyo Basic"):
			frappe.get_doc(
				{
					"doctype": "Salary Component",
					"salary_component": "Karyo Basic",
					"salary_component_abbr": "KB",
					"type": "Earning",
				}
			).insert(ignore_permissions=True)
		if not frappe.db.exists("Salary Structure", "Karyo Test SS"):
			ss = frappe.get_doc(
				{
					"doctype": "Salary Structure",
					"name": "Karyo Test SS",
					"company": self.company,
					"payroll_frequency": "Monthly",
					"earnings": [{"salary_component": "Karyo Basic", "amount": 30000}],
				}
			)
			ss.insert(ignore_permissions=True)
			ss.submit()
		a = frappe.get_doc(
			{
				"doctype": "Salary Structure Assignment",
				"employee": self.emp.name,
				"salary_structure": "Karyo Test SS",
				"company": self.company,
				"from_date": "2015-01-01",
				"base": 30000,
			}
		)
		a.insert(ignore_permissions=True)
		a.submit()

		frappe.get_doc(
			{
				"doctype": "Passage Benefit Bank",
				"employee": self.emp.name,
				"opening_date": "2026-01-01",
				"opening_balance": 0,
			}
		).insert(ignore_permissions=True)

		# A submitted computation: posts an Earning, rolls the period, logs segments.
		self.comp = frappe.get_doc(
			{
				"doctype": "Passage Benefit Computation",
				"employee": self.emp.name,
				"from_date": "2026-01-01",
				"to_date": "2026-04-30",
				"pay_period": "2026-04",
			}
		)
		self.comp.insert(ignore_permissions=True)
		self.comp.submit()

		# A manual adjustment (before/after snapshot feeds the audit report).
		self.adj = frappe.get_doc(
			{
				"doctype": "Passage Benefit Adjustment",
				"employee": self.emp.name,
				"posting_date": "2026-05-01",
				"amount": 500,
				"remarks": "reporting test adjustment",
			}
		)
		self.adj.insert(ignore_permissions=True)
		self.adj.submit()

	# --- reports -----------------------------------------------------------
	def test_bank_balance_listing(self):
		_, data = run_bank_listing({"employee": self.emp.name})
		row = next(r for r in data if r["employee"] == self.emp.name)
		self.assertGreater(row["total_earned"], 0)
		self.assertEqual(row["total_adjustments"], 500)
		self.assertEqual(row["last_computation"].isoformat(), "2026-04-30")

	def test_computation_log_flattens_segments(self):
		_, data = run_computation_log({"employee": self.emp.name})
		self.assertTrue(data)
		self.assertTrue(all(r["computation"] == self.comp.name for r in data))
		self.assertEqual(sum(r["eligible_days"] for r in data), self.comp.eligible_days_total)
		self.assertTrue(all("excluded_days" in r and "denominator" in r for r in data))

	def test_adjustment_audit_shows_before_after(self):
		_, data = run_adjustment_audit({"employee": self.emp.name})
		row = next(r for r in data if r["adjustment"] == self.adj.name)
		self.assertEqual(row["amount"], 500)
		self.assertAlmostEqual(row["balance_after"] - row["balance_before"], 500, places=2)
		self.assertEqual(row["status"], "Submitted")

	def test_exception_report_from_run(self):
		# Re-running the same period skips the already-computed employee -> exception row.
		run_passage_benefit_period(
			"2026-01-01", "2026-04-30", pay_period="2026-04", employees=[self.emp.name]
		)
		_, data = run_exception_report({"pay_period": "2026-04"})
		mine = [r for r in data if r["employee"] == self.emp.name]
		self.assertTrue(mine)
		self.assertEqual(mine[0]["category"], "Skipped")

	def test_request_register_lists_application(self):
		app = frappe.get_doc(
			{
				"doctype": "Passage Benefit Application",
				"employee": self.emp.name,
				"posting_date": "2026-05-10",
				"pay_period": "2026-05",
				"usage_item": self._usage_item(),
				"request_amount": 100,
			}
		)
		app.insert(ignore_permissions=True)
		_, data = run_request_register({"employee": self.emp.name})
		self.assertTrue(any(r["request"] == app.name for r in data))

	# --- inquiry APIs (screens 9/10/11) ------------------------------------
	def test_screen9_query_balance(self):
		res = inquiry.query_balance(self.emp.name)
		self.assertIsNotNone(res["bank"])
		self.assertTrue(res["periods"])
		self.assertTrue(res["computation_log"])
		self.assertTrue(res["transactions"])
		self.assertIn("requests", res)

	def test_screen10_audit_compute_does_not_touch_bank(self):
		before = frappe.db.get_value("Passage Benefit Bank", self.emp.name, "current_balance")
		res = inquiry.compute_balance_as_at(as_on="2026-06-30", employees=[self.emp.name])
		after = frappe.db.get_value("Passage Benefit Bank", self.emp.name, "current_balance")
		self.assertEqual(before, after)  # audit compute must not mutate the bank
		self.assertEqual(res["count"], 1)
		row = res["rows"][0]
		self.assertAlmostEqual(row["closing_amount"], row["opening_amount"] + row["earned"], places=2)

	def test_screen11_pb_and_vacation_balance(self):
		res = inquiry.pb_and_vacation_balance(self.emp.name, as_on="2026-06-30")
		self.assertTrue(res["eligible"])
		self.assertIsNone(res["vacation_balance"])  # no vacation_leave_type configured
		self.assertGreaterEqual(res["pb_balance"], 0)

	def test_screen11_balance_is_historical_as_at_date(self):
		before_adjustment = inquiry.pb_and_vacation_balance(self.emp.name, as_on="2026-04-30")
		after_adjustment = inquiry.pb_and_vacation_balance(self.emp.name, as_on="2026-05-01")
		self.assertAlmostEqual(after_adjustment["pb_balance"] - before_adjustment["pb_balance"], 500, places=2)

	def _usage_item(self):
		name = "Karyo Test Usage"
		if not frappe.db.exists("Passage Benefit Usage Item", name):
			frappe.get_doc(
				{
					"doctype": "Passage Benefit Usage Item",
					"usage_item_code": name,
					"usage_item_name": name,
					"encash_rate": 1,
				}
			).insert(ignore_permissions=True)
		return name
