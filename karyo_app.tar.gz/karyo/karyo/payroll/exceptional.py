"""Dual approval, posting, and reversal for exceptional payroll."""

import frappe
from frappe import _

from karyo.payroll.sequencing import reserve_transaction


@frappe.whitelist()
def review_batch(name):
	return _transition(name, "Draft", "Reviewed")


@frappe.whitelist()
def approve_batch(name):
	return _transition(name, "Reviewed", "Approved")


def _transition(name, expected, target):
	batch = frappe.get_doc("Exceptional Payroll Batch", name)
	if batch.status != expected:
		frappe.throw(_("Exceptional batch must be {0} before moving to {1}.").format(expected, target))
	batch.status = target
	batch.save()
	return batch.name


@frappe.whitelist()
def post_batch(name):
	batch = frappe.get_doc("Exceptional Payroll Batch", name)
	cycle = frappe.get_doc("Payroll Cycle", batch.payroll_cycle)
	if batch.status == "Posted":
		return {"batch": batch.name, "posted": [], "already_posted": True}
	if batch.status != "Approved":
		frappe.throw(_("Only Approved exceptional batches can be posted."))
	if cycle.status not in ("Processing", "Review"):
		frappe.throw(_("Payroll Cycle must be Processing or Review before posting."))
	posted = []
	for row in batch.lines:
		allocation = reserve_transaction(
			cycle.name, "Exceptional Payroll Line", row.name, "Once-off", row.amount, row.employee
		)
		additional_salary = frappe.get_doc(
			{
				"doctype": "Additional Salary",
				"employee": row.employee,
				"company": batch.company,
				"salary_component": row.salary_component,
				"amount": row.amount,
				"payroll_date": cycle.payment_date,
				"deduct_full_tax_on_selected_payroll_date": row.calculate_tax,
				"overwrite_salary_structure_amount": 0,
				"ref_doctype": batch.doctype,
				"ref_docname": batch.name,
				"karyo_transaction_category": "Exceptional Payroll",
				"karyo_exceptional_batch": batch.name,
				"karyo_payroll_cycle": cycle.name,
			}
		)
		additional_salary.insert(ignore_permissions=True)
		additional_salary.submit()
		row.allocation = allocation.name
		row.additional_salary = additional_salary.name
		posted.append(additional_salary.name)
	batch.status = "Posted"
	batch.save()
	return {"batch": batch.name, "posted": posted, "already_posted": False}


@frappe.whitelist()
def reverse_batch(name, reason):
	batch = frappe.get_doc("Exceptional Payroll Batch", name)
	if batch.status != "Posted" or not reason:
		frappe.throw(_("A Posted exceptional batch and reversal reason are required."))
	for row in batch.lines:
		if (
			row.additional_salary
			and frappe.db.get_value("Additional Salary", row.additional_salary, "docstatus") == 1
		):
			additional_salary = frappe.get_doc("Additional Salary", row.additional_salary)
			additional_salary.flags.ignore_links = True
			additional_salary.cancel()
		if row.allocation:
			frappe.db.set_value(
				"Payroll Transaction Allocation", row.allocation, "status", "Released", update_modified=False
			)
	batch.status = "Cancelled"
	batch.decision_reason = reason
	batch.flags.reversal_complete = True
	batch.save()
	return batch.name
