frappe.query_reports["MBC Pay Register"] = {
	filters: [
		{fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company", default: frappe.defaults.get_user_default("Company"), reqd: 1},
		{fieldname: "from_date", label: __("Period From"), fieldtype: "Date", default: frappe.datetime.year_start()},
		{fieldname: "to_date", label: __("Period To"), fieldtype: "Date", default: frappe.datetime.year_end()},
		{fieldname: "payroll_cycle", label: __("Payroll Cycle"), fieldtype: "Link", options: "Payroll Cycle", get_query: () => ({filters: {company: frappe.query_report.get_filter_value("company")}})},
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee", get_query: () => ({filters: {company: frappe.query_report.get_filter_value("company")}})},
		{fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department"},
		{fieldname: "designation", label: __("Designation"), fieldtype: "Link", options: "Designation"},
		{fieldname: "document_status", label: __("Document Status"), fieldtype: "Select", options: "\nDraft\nSubmitted", default: "Submitted"},
		{fieldname: "payment_status", label: __("Payment Status"), fieldtype: "Select", options: "\nDraft\nPrepared\nAuthorised\nPAID\nCancelled"},
	],
};
