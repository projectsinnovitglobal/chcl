"""Vehicle lien / registration tracking (LN-09, BR-FAR-LMS-AGR-008..010).

Adds a config-driven `lien_required` flag to Loan Type (so which loans need a
lien is data, not code) and a lien-tracking section to Karyo Loan. The loan
controller blocks disbursement of a lien-required loan until the lien is
registered (see KaryoLoan._validate_vehicle_lien).

    bench --site dev.localhost execute karyo.setup.loan_lien.setup
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def setup():
	make_doctype(
		"Karyo Loan Lien History",
		istable=1,
		fields=[
			f("lien_status", "Data", "Lien Status", read_only=1, in_list_view=1),
			f("event_date", "Datetime", "Event Date", read_only=1, in_list_view=1),
			f("event_user", "Link", "Event User", options="User", read_only=1),
			f("registration_no", "Data", "Registration No.", read_only=1),
			f("document", "Attach", "Evidence", read_only=1),
			f("remarks", "Small Text", "Reason / Remarks", read_only=1),
		],
	)
	create_custom_fields(
		{
			"Loan Type": [
				{
					"fieldname": "lien_required",
					"fieldtype": "Check",
					"label": "Vehicle Lien Required",
					"insert_after": "loan_category",
					"description": "Block disbursement until a vehicle lien is registered (car / motorcycle).",
				},
			],
			"Karyo Loan": [
				{
					"fieldname": "vehicle_lien_sb",
					"fieldtype": "Section Break",
					"label": "Vehicle Lien",
					"insert_after": "settlement_date",
					"depends_on": "eval:doc.loan_type",
					"collapsible": 1,
				},
				{
					"fieldname": "lien_status",
					"fieldtype": "Select",
					"label": "Lien Status",
					"options": "Not Applicable\nPending\nReturned\nRejected\nRegistered\nRelease Pending\nReleased\nCancelled",
					"default": "Not Applicable",
					"insert_after": "vehicle_lien_sb",
					"in_list_view": 0,
					"allow_on_submit": 1,
				},
				{
					"fieldname": "lien_registration_no",
					"fieldtype": "Data",
					"label": "Lien Registration No.",
					"insert_after": "lien_status",
					"allow_on_submit": 1,
				},
				{"fieldname": "vehicle_registration_no", "fieldtype": "Data", "label": "Vehicle Registration No.", "insert_after": "lien_registration_no", "allow_on_submit": 1},
				{
					"fieldname": "lien_registered_date",
					"fieldtype": "Date",
					"label": "Lien Registered On",
					"insert_after": "vehicle_registration_no",
					"allow_on_submit": 1,
				},
				{
					"fieldname": "lien_cb",
					"fieldtype": "Column Break",
					"insert_after": "lien_registered_date",
				},
				{
					"fieldname": "lien_document",
					"fieldtype": "Attach",
					"label": "Lien Document",
					"insert_after": "lien_cb",
					"allow_on_submit": 1,
				},
				{
					"fieldname": "lien_released_date",
					"fieldtype": "Date",
					"label": "Lien Released On",
					"insert_after": "lien_document",
					"allow_on_submit": 1,
				},
				{"fieldname": "lien_verified", "fieldtype": "Check", "label": "Lien Verified", "insert_after": "lien_released_date", "allow_on_submit": 1},
				{"fieldname": "lien_verified_by", "fieldtype": "Link", "label": "Lien Verified By", "options": "User", "read_only": 1, "insert_after": "lien_verified", "allow_on_submit": 1},
				{"fieldname": "lien_verified_on", "fieldtype": "Datetime", "label": "Lien Verified On", "read_only": 1, "insert_after": "lien_verified_by", "allow_on_submit": 1},
				{"fieldname": "lien_return_reason", "fieldtype": "Small Text", "label": "Lien Return Reason", "insert_after": "lien_verified_on", "allow_on_submit": 1},
				{"fieldname": "lien_rejection_reason", "fieldtype": "Small Text", "label": "Lien Rejection / Cancellation Reason", "insert_after": "lien_return_reason", "allow_on_submit": 1},
				{"fieldname": "lien_history", "fieldtype": "Table", "label": "Lien History", "options": "Karyo Loan Lien History", "read_only": 1, "insert_after": "lien_rejection_reason", "allow_on_submit": 1},
			],
		},
		ignore_validate=True,
	)
	# Older vehicle-loan records were created before the lien fields existed and
	# therefore retained the generic "Not Applicable" default.  Move only open,
	# lien-governed loans to Pending so they can be completed from Loan Management.
	lien_types = frappe.get_all("Loan Type", filters={"lien_required": 1}, pluck="name")
	if lien_types:
		for name in frappe.get_all(
			"Karyo Loan",
			filters={
				"loan_type": ("in", lien_types),
				"docstatus": ("<", 2),
				"status": ("not in", ["Settled", "Closed", "Rejected", "Cancelled"]),
				"lien_status": ("in", ["", "Not Applicable"]),
			},
			pluck="name",
		):
			frappe.db.set_value("Karyo Loan", name, "lien_status", "Pending", update_modified=False)
	frappe.db.commit()
	print("Vehicle lien tracking fields ensured (Loan Type.lien_required, Karyo Loan lien section).")
