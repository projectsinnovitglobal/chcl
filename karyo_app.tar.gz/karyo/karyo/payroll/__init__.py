"""Karyo payroll orchestration and configuration safety."""
