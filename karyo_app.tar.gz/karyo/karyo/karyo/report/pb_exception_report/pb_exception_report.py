# Copyright (c) 2026, AstraFlow and contributors
# For license information, please see license.txt

"""PB Exception Report (§9.2 #6) — identify blocked or failed transactions.

Minimum fields (BRD §9.2): employee, process, error reason, period, required
correction, status. Sourced from the per-run exception log written by the
scheduler / manual runs (scheduler §8, PB-JOB-006).
"""

import frappe


def execute(filters=None):
	filters = frappe._dict(filters or {})
	return _columns(), _data(filters)


def _columns():
	return [
		{
			"label": "Run",
			"fieldname": "run",
			"fieldtype": "Link",
			"options": "Passage Benefit Computation Run",
			"width": 170,
		},
		{"label": "Run Date", "fieldname": "run_datetime", "fieldtype": "Datetime", "width": 160},
		{"label": "Source", "fieldname": "run_source", "fieldtype": "Data", "width": 90},
		{
			"label": "Employee",
			"fieldname": "employee",
			"fieldtype": "Link",
			"options": "Employee",
			"width": 110,
		},
		{"label": "Employee Name", "fieldname": "employee_name", "fieldtype": "Data", "width": 160},
		{"label": "Pay Period", "fieldname": "pay_period", "fieldtype": "Data", "width": 90},
		{"label": "Process", "fieldname": "category", "fieldtype": "Data", "width": 100},
		{"label": "Error / Reason", "fieldname": "reason", "fieldtype": "Small Text", "width": 320},
		{"label": "Required Correction", "fieldname": "required_correction", "fieldtype": "Data", "width": 220},
		{"label": "Status", "fieldname": "status", "fieldtype": "Data", "width": 90},
	]


def _data(filters):
	conditions = ["1 = 1"]
	values = {}
	if filters.get("pay_period"):
		conditions.append("e.pay_period = %(pay_period)s")
		values["pay_period"] = filters.pay_period
	if filters.get("category"):
		conditions.append("e.category = %(category)s")
		values["category"] = filters.category
	if filters.get("employee"):
		conditions.append("e.employee = %(employee)s")
		values["employee"] = filters.employee
	if filters.get("company"):
		conditions.append("r.company = %(company)s")
		values["company"] = filters.company

	rows = frappe.db.sql(
		"""
		select
			r.name as run, r.run_datetime, r.run_source,
			e.employee, e.employee_name, e.pay_period, e.category, e.reason
		from `tabPassage Benefit Run Exception` e
		inner join `tabPassage Benefit Computation Run` r on e.parent = r.name
		where {conditions}
		order by r.run_datetime desc, e.idx
		""".format(conditions=" and ".join(conditions)),
		values,
		as_dict=True,
	)
	for row in rows:
		row["required_correction"] = "Review employee setup and rerun the computation"
		row["status"] = "Open"

	# Approved requests that could not yet cross the Finance processing boundary
	# are correctable live exceptions even when the failed request transaction was
	# rolled back (and therefore could not safely persist its own error row).
	app_filters = {"workflow_state": "Approved", "processed": 0, "docstatus": 0}
	if filters.get("employee"):
		app_filters["employee"] = filters.employee
	if filters.get("company"):
		app_filters["company"] = filters.company
	if filters.get("pay_period"):
		app_filters["pay_period"] = filters.pay_period
	for app in frappe.get_all(
		"Passage Benefit Application",
		filters=app_filters,
		fields=["name", "modified", "employee", "employee_name", "pay_period", "processing_route"],
		order_by="modified desc",
	):
		rows.append(
			{
				"run": None,
				"run_datetime": app.modified,
				"run_source": "Finance",
				"employee": app.employee,
				"employee_name": app.employee_name,
				"pay_period": app.pay_period,
				"category": "Claim Processing",
				"reason": "Approved request awaiting successful payroll/internal processing",
				"required_correction": "Validate processing reference, PDB setup and balance, then reprocess",
				"status": "Open",
			}
		)
	return rows
