"""Importable facade for the repository-level Phase 0 register builder."""

from tools.build_phase0_registers import collect_rules, infer_module, infer_version, main, write_csv

__all__ = ["collect_rules", "infer_module", "infer_version", "main", "write_csv"]
