# Copyright (c) 2026, AstraFlow and contributors
# For license information, please see license.txt

"""PB Payroll Posting Report (§9.2 #4) — validate payroll integration.

Minimum fields (BRD §9.2): request reference, PDB code, amount, payroll period,
posting status, error reason.
"""

import frappe


def execute(filters=None):
	filters = frappe._dict(filters or {})
	return _columns(), _data(filters)


def _columns():
	return [
		{
			"label": "Request",
			"fieldname": "request",
			"fieldtype": "Link",
			"options": "Passage Benefit Application",
			"width": 160,
		},
		{
			"label": "Employee",
			"fieldname": "employee",
			"fieldtype": "Link",
			"options": "Employee",
			"width": 110,
		},
		{"label": "Employee Name", "fieldname": "employee_name", "fieldtype": "Data", "width": 160},
		{"label": "Passage Method", "fieldname": "processing_route", "fieldtype": "Data", "width": 110},
		{
			"label": "PDB Code",
			"fieldname": "payroll_pdb_code",
			"fieldtype": "Link",
			"options": "Payroll PDB Code",
			"width": 130,
		},
		{"label": "Salary Component", "fieldname": "pdb_component", "fieldtype": "Link", "options": "Salary Component", "width": 150},
		{"label": "Amount", "fieldname": "amount_taken", "fieldtype": "Currency", "width": 120},
		{"label": "Pay Period", "fieldname": "pay_period", "fieldtype": "Data", "width": 90},
		{
			"label": "Posting Reference",
			"fieldname": "posting_reference",
			"fieldtype": "Dynamic Link",
			"options": "posting_doctype",
			"width": 160,
		},
		{"label": "Posting Status", "fieldname": "posting_status", "fieldtype": "Data", "width": 120},
		{"label": "Error Reason", "fieldname": "error_reason", "fieldtype": "Data", "width": 200},
	]


def _data(filters):
	conditions = {
		"docstatus": ["<", 2],
		"workflow_state": ["in", ["Approved", "Processed"]],
	}
	if filters.get("company"):
		conditions["company"] = filters.company
	if filters.get("pay_period"):
		conditions["pay_period"] = filters.pay_period
	if filters.get("employee"):
		conditions["employee"] = filters.employee

	rows = frappe.get_all(
		"Passage Benefit Application",
		filters=conditions,
		fields=[
			"name as request",
			"employee",
			"employee_name",
			"processing_route",
			"payroll_pdb_code",
			"pdb_component",
			"amount_taken",
			"pay_period",
			"processed",
			"additional_salary",
			"processed_reference",
			"workflow_state",
		],
		order_by="pay_period desc, name desc",
	)
	for r in rows:
		if r.get("processing_route") == "Payroll":
			r["posting_doctype"] = "Additional Salary"
			r["posting_reference"] = r.get("additional_salary")
		else:
			r["posting_doctype"] = None
			r["posting_reference"] = r.get("processed_reference")
		if r.get("processed"):
			r["posting_status"] = "Posted"
			r["error_reason"] = None
		else:
			r["posting_status"] = "Pending"
			# Approved-but-unposted with no payroll reference is the failure signal
			# payroll reconciliation looks for (PB-APP posting not yet completed).
			r["error_reason"] = "Approved but not yet posted" if not r.get("posting_reference") else None
	return rows
