#!/usr/bin/env python3
"""Build Phase 0 rule and evidence registers from the supplied MBC DOCX files.

Only immutable source facts are extracted. Decisions, ownership and sign-off
remain blank/Open until MBC supplies them.
"""

from __future__ import annotations

import argparse
import csv
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

RULE_ID = re.compile(
	r"(?<![A-Z0-9-])(?:MBC-(?:LV|PAY|PB)-[A-Z]{2,4}-\d{3}|CL-[A-Z]{2}-\d{1,2}|"
	r"PRB-(?:ACT|ATT|BASIC|CONV|EMP|EOY|GEO|INC)-\d{2,3}|"
	r"(?:ACT|ATT|BASIC|CONV|EMP|EOY|GEO|INC|DEC|EV|GAP|GEN|LV)-\d{2,3})(?![A-Z0-9-])"
)
WORD_TEXT = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"


def extract_paragraphs(path: Path) -> list[str]:
	with zipfile.ZipFile(path) as archive:
		root = ET.fromstring(archive.read("word/document.xml"))
	paragraphs = []
	for paragraph in root.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
		text = "".join(node.text or "" for node in paragraph.iter(WORD_TEXT)).strip()
		if text:
			paragraphs.append(text)
	return paragraphs


def collect_rules(source_dir: Path) -> list[dict[str, str]]:
	rules: dict[tuple[str, str], dict[str, str]] = {}
	for path in sorted(source_dir.rglob("*.docx")):
		for paragraph in extract_paragraphs(path):
			for rule_id in RULE_ID.findall(paragraph):
				key = (path.name, rule_id)
				rules.setdefault(
					key,
					{
						"rule_id": rule_id,
						"module": infer_module(rule_id),
						"rule_text": paragraph,
						"source_document": path.name,
						"source_version": infer_version(path.name),
						"source_location": "DOCX paragraph (automatically extracted)",
						"evidence_id": "",
						"current_behaviour": "",
						"classification": "Open",
						"temporary_handling": "Blocked from production use pending decision",
						"decision_reference": "",
						"owner": "",
						"decision_deadline": "",
						"uat_case": "",
						"sign_off_reference": "",
					},
				)
	return sorted(rules.values(), key=lambda row: (row["rule_id"], row["source_document"]))


def infer_module(rule_id: str) -> str:
	parts = set(rule_id.split("-"))
	if "LV" in parts:
		return "Leave"
	if "PB" in parts:
		return "Passage Benefit"
	if "PAY" in parts:
		return "Payroll"
	if "ATT" in parts:
		return "Attendance"
	return "Cross-cutting / requires classification"


def infer_version(filename: str) -> str:
	match = re.search(r"V\s*(\d+(?:\.\d+)*)", filename, re.IGNORECASE)
	return match.group(1) if match else "Unspecified in filename"


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
	path.parent.mkdir(parents=True, exist_ok=True)
	with path.open("w", newline="", encoding="utf-8") as handle:
		writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
		writer.writeheader()
		writer.writerows(rows)


def main() -> None:
	parser = argparse.ArgumentParser()
	parser.add_argument("source_dir", type=Path)
	parser.add_argument("output", type=Path)
	args = parser.parse_args()
	rules = collect_rules(args.source_dir)
	if not rules:
		raise SystemExit(f"No requirement IDs found below {args.source_dir}")
	write_csv(args.output, rules)
	print(f"Wrote {len(rules)} source/rule rows to {args.output}")


if __name__ == "__main__":
	main()
