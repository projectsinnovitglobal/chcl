"""PRB allowances engine: travelling/mileage/travel grant, meal, subsistence,
out-of-pocket and geographical allowances (pure, testable).

PRB analysis §9 and §12 (TRAV-*, MEAL-*, SUB-*, OOP-*, GEO-*). Fixed rates are
2026 defaults and must be effective-dated configuration in production.
"""

# --- mileage (TRAV-05/06/07) ------------------------------------------------
CAR_RATE_FIRST_800 = 14.50
CAR_RATE_BEYOND = 9.05
MOTORCYCLE_RATE = 4.70
MOTORCYCLE_RES_OFFICE = 3.35
AUTOCYCLE_RATE = 3.85
AUTOCYCLE_RES_OFFICE = 2.60


def car_mileage(official_km, residence_office_km=0, precision=2):
	"""Rs 14.50/km for the first 800 km, Rs 9.05/km beyond, plus residence-office
	field-day distance at Rs 9.05/km (TRAV-05)."""
	amount = (
		min(official_km, 800) * CAR_RATE_FIRST_800
		+ max(0, official_km - 800) * CAR_RATE_BEYOND
		+ residence_office_km * CAR_RATE_BEYOND
	)
	return round(amount, precision)


def motorcycle_mileage(official_km, residence_office_km=0, bus_fare=0, precision=2):
	"""Rs 4.70/km; residence-office at Rs 3.35/km or bus fare, whichever higher (TRAV-06)."""
	return round(
		official_km * MOTORCYCLE_RATE + max(residence_office_km * MOTORCYCLE_RES_OFFICE, bus_fare), precision
	)


def autocycle_mileage(official_km, residence_office_km=0, bus_fare=0, precision=2):
	"""Rs 3.85/km; residence-office at Rs 2.60/km or bus fare, whichever higher (TRAV-07)."""
	return round(
		official_km * AUTOCYCLE_RATE + max(residence_office_km * AUTOCYCLE_RES_OFFICE, bus_fare), precision
	)


# --- meal / subsistence / out-of-pocket (MEAL/SUB/OOP) ----------------------
MEAL_RATE = 175
SUBSISTENCE_RATES = {"none": 1420, "lodging": 655, "half_board": 340}
OUT_OF_POCKET_RATE = 220
ATTENDANCE_BONUS_RATE = 2140
INCENTIVE_PRESENCE_RATE = 1500


def meal_allowance(meals, rate=MEAL_RATE):
	"""Rs 175 per meal when retained >=3h beyond normal hours (MEAL-01/02)."""
	return meals * rate


def subsistence_allowance(nights, kind="none"):
	"""Per-night subsistence: no board/lodging 1420, lodging provided 655,
	half-board 340 (SUB-01/02/03)."""
	return nights * SUBSISTENCE_RATES[kind]


def out_of_pocket(days, rate=OUT_OF_POCKET_RATE):
	"""Rs 220 per day or part-day for outer-island visits (OOP-01)."""
	return days * rate


def presence_bonus(leaves_taken, base_amount, precision=2):
	"""MBC attendance/presence scale: 100%, 75%, 50%, 25%, then nil.

	Only half-day increments are valid inputs. Which approved leave codes count
	towards this value remains a payroll configuration responsibility.
	"""
	leaves = float(leaves_taken or 0)
	if leaves < 0 or leaves * 2 != int(leaves * 2):
		raise ValueError("leaves_taken must be a non-negative half-day increment")
	factor = {0.0: 1.0, 0.5: 0.75, 1.0: 0.5, 1.5: 0.25}.get(leaves, 0.0)
	return round(float(base_amount) * factor, precision)


def attendance_bonus(leaves_taken, base_amount=ATTENDANCE_BONUS_RATE, precision=2):
	return presence_bonus(leaves_taken, base_amount, precision)


def incentive_presence_bonus(leaves_taken, base_amount=INCENTIVE_PRESENCE_RATE, precision=2):
	return presence_bonus(leaves_taken, base_amount, precision)


def era_hours_payment(
	excess_hours,
	gross_salary,
	basic_salary,
	leaves_taken=0,
	*,
	lower_rate=0.15,
	lower_cap=3940,
	lower_salary_max=31525,
	upper_rate=0.13,
	upper_cap=4435,
	upper_salary_min=32350,
	upper_salary_max=54200,
	minimum_hours=15,
	full_payment_hours=30,
	working_days_divisor=22,
	casual_leave_taken=None,
	other_absence_days=None,
	casual_leave_exemption=1,
	precision=2,
):
	"""ATT-CALC-004 ERA payment with configurable salary bands and leave rules.

	The gap between salary bands is intentionally ineligible instead of silently
	assigning a rate.  One approved casual-leave day is exempt; other absences
	reduce the payment using the configured working-day divisor.  ``leaves_taken``
	is retained as a legacy fallback for callers that cannot distinguish leave
	types yet.
	"""
	hours = float(excess_hours or 0)
	if hours < 0:
		raise ValueError("excess hours cannot be negative")
	if float(gross_salary or 0) < 0 or float(basic_salary or 0) < 0:
		raise ValueError("salary values cannot be negative")
	if float(minimum_hours) < 0 or float(full_payment_hours) <= 0:
		raise ValueError("invalid ERA hour thresholds")
	if float(working_days_divisor) <= 0:
		raise ValueError("working-days divisor must be greater than zero")
	if hours < float(minimum_hours):
		return 0.0
	if 0 <= basic_salary <= lower_salary_max:
		rate, cap = lower_rate, lower_cap
	elif upper_salary_min <= basic_salary <= upper_salary_max:
		rate, cap = upper_rate, upper_cap
	else:
		return 0.0
	amount = min(round(rate * float(gross_salary), precision), cap)
	if hours <= float(full_payment_hours):
		amount *= hours / float(full_payment_hours)
	if casual_leave_taken is None and other_absence_days is None:
		chargeable_leave = max(0.0, float(leaves_taken or 0) - float(casual_leave_exemption))
	else:
		casual = float(casual_leave_taken or 0)
		other = float(other_absence_days or 0)
		if casual < 0 or other < 0:
			raise ValueError("leave and absence values cannot be negative")
		chargeable_leave = max(0.0, casual - float(casual_leave_exemption)) + other
	divisor = float(working_days_divisor)
	amount = (amount / divisor) * max(0.0, divisor - chargeable_leave)
	return round(amount, precision)


# --- geographical (GEO) -----------------------------------------------------
def inducement_allowance(monthly_salary, pct=50, precision=2):
	"""Rodrigues inducement = % of monthly salary (GEO-01, default 50%)."""
	return round(monthly_salary * pct / 100.0, precision)


def disturbance_allowance(gross_salary, pct=60, precision=2):
	"""Agalega/St Brandon disturbance = 60% of gross (GEO-03); Rodriguan police to
	Mauritius = 25% (GEO-04)."""
	return round(gross_salary * pct / 100.0, precision)
