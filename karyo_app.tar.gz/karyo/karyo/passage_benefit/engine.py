"""Passage Benefit computation engine (pure, DB-free, unit-testable).

Implements the FAREI Passage Benefit earning formula (business rules PB-CMP-*,
section 7.3 / 7.4 of the FAREI Passage Benefit BRD):

    Annual Gross  = Monthly Gross x 12          (salary basis, configurable)
    Annual PB     = Annual Gross x PB%           (default 5%)
    Daily PB Rate = Annual PB / denominator      (365, or 366 in leap years)
    Segment PB    = round(Daily PB Rate, prec) x eligible_days
    PB Earned     = sum of all salary-segment amounts

The daily rate is rounded to `precision` decimals BEFORE multiplying by eligible
days, matching the worked scenarios (e.g. 18000/365 = 49.32 -> 49.32 x 120 =
5,918.40). This rounding point is a FAREI sign-off item (OP-PB-003); keep it here
so it is changed in exactly one place.
"""

from decimal import ROUND_HALF_UP, Decimal


def _round(value, precision=2):
	q = Decimal(10) ** -precision
	return float(Decimal(str(value)).quantize(q, rounding=ROUND_HALF_UP))


def annual_from_monthly(monthly_salary, salary_basis="Monthly Gross x 12"):
	"""Resolve the annual salary base from the configured salary basis."""
	if salary_basis in ("Annual Gross",):
		return float(monthly_salary)
	# "Monthly Gross x 12" and "Basic Salary" both annualise monthly x 12 here.
	return float(monthly_salary) * 12


def compute_segment(
	monthly_salary,
	eligible_days,
	pb_percentage=5.0,
	denominator=365,
	precision=2,
	salary_basis="Monthly Gross x 12",
	rounding_stage="Daily Rate",
):
	"""Compute one salary segment's passage benefit. Returns a breakdown dict.

	`rounding_stage` controls where rounding happens (FAREI open point OP-PB-003):
	  - "Daily Rate"   (default): round the daily rate to `precision`, then x days.
	                    Reproduces FAREI worked scenarios 11.1 & 11.2 exactly.
	  - "Final Amount": multiply the exact daily rate by days, round only the total.
	"""
	annual_salary = annual_from_monthly(monthly_salary, salary_basis)
	annual_pb = annual_salary * (float(pb_percentage) / 100.0)
	exact_daily = annual_pb / denominator
	if rounding_stage == "Final Amount":
		daily_rate = _round(exact_daily, precision)
		segment_amount = _round(exact_daily * int(eligible_days), precision)
	else:
		daily_rate = _round(exact_daily, precision)
		segment_amount = _round(daily_rate * int(eligible_days), precision)
	return {
		"monthly_salary": float(monthly_salary),
		"eligible_days": int(eligible_days),
		"annual_salary": _round(annual_salary, precision),
		"annual_pb": _round(annual_pb, precision),
		"daily_rate": daily_rate,
		"segment_amount": segment_amount,
	}


def compute_pb(
	segments,
	pb_percentage=5.0,
	denominator=365,
	precision=2,
	salary_basis="Monthly Gross x 12",
	rounding_stage="Daily Rate",
):
	"""Compute total passage benefit over salary segments.

	`segments`: iterable of dicts with `monthly_salary` and `eligible_days`.
	Returns {"segments": [...breakdown...], "eligible_days": int, "earned": float}.
	"""
	rows = []
	total = 0.0
	total_days = 0
	for seg in segments:
		segment_denominator = int(seg.get("denominator") or denominator)
		row = compute_segment(
			seg["monthly_salary"],
			seg["eligible_days"],
			pb_percentage=pb_percentage,
			denominator=segment_denominator,
			precision=precision,
			salary_basis=salary_basis,
			rounding_stage=rounding_stage,
		)
		row["denominator"] = segment_denominator
		rows.append(row)
		total += row["segment_amount"]
		total_days += row["eligible_days"]
	return {"segments": rows, "eligible_days": total_days, "earned": _round(total, precision)}


def denominator_for(year, leap_year_treatment="Always 365"):
	"""Day-count denominator for a given year per the configured treatment."""
	if leap_year_treatment == "366 in leap years":
		is_leap = (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)
		return 366 if is_leap else 365
	return 365
