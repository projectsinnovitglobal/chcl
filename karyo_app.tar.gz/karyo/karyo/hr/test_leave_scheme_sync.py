from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.employee_resources import assignments
from karyo.hr.leave_controls import ensure_employee_leave_entitlements
from karyo.hr.self_service import leave_balances, publish_balance_update


class TestLeaveSchemeSync(FrappeTestCase):
	@patch("frappe.publish_realtime")
	@patch("frappe.db.get_value", return_value="employee@example.com")
	def test_bank_changes_publish_live_counter_refresh(self, _get_value, publish):
		publish_balance_update(frappe._dict(
			doctype="Vacation Leave Bank", employee="EMP-1", name="EMP-1",
		))
		payloads = [call.args[1] for call in publish.call_args_list]
		self.assertTrue(any("Vacation Leave Bank" in payload["doctypes"] for payload in payloads))
		self.assertTrue(any(call.kwargs.get("user") == "employee@example.com" for call in publish.call_args_list))

	def test_selected_scheme_creates_all_allocations_and_dashboard_counters(self):
		frappe.set_user("Administrator")
		employee_name = frappe.db.get_value(
			"Employee", {"status": "Active", "karyo_leave_scheme": ("is", "set")}, "name",
		)
		self.assertTrue(employee_name)
		self.employee = frappe.get_doc("Employee", employee_name)
		policy = self.employee.karyo_leave_scheme

		ensure_employee_leave_entitlements(self.employee.name)
		second = ensure_employee_leave_entitlements(self.employee.name)
		self.assertEqual(second["allocations_created"], 0)
		self.assertEqual(second["allocations_updated"], 0)

		codes = set(frappe.get_all(
			"Leave Allocation",
			filters={"employee": self.employee.name, "docstatus": 1},
			pluck="karyo_leave_code", limit_page_length=0,
		))
		self.assertTrue({"ANN", "CASL01", "SICK01"}.issubset(codes))
		policy_types = set(frappe.get_all(
			"Leave Policy Detail",
			filters={"parent": policy, "parenttype": "Leave Policy", "annual_allocation": (">", 0)},
			pluck="leave_type", limit_page_length=0,
		))
		allocation_types = set(frappe.get_all(
			"Leave Allocation",
			filters={"employee": self.employee.name, "docstatus": 1},
			pluck="leave_type", limit_page_length=0,
		))
		self.assertTrue(policy_types.issubset(allocation_types))
		self.assertTrue(frappe.db.exists("Sick Leave Bank", {"employee": self.employee.name}))
		self.assertTrue(frappe.db.exists("Vacation Leave Bank", {"employee": self.employee.name}))

		balances = leave_balances(self.employee.name)
		by_code = {row["leave_code"]: row for row in balances}
		self.assertTrue({"ANN", "CASL01", "SICK01", "SICK02", "SICK03", "VAC01"}.issubset(by_code))
		for code in ("ANN", "CASL01", "SICK01", "SICK02", "SICK03", "VAC01"):
			self.assertTrue({"total", "taken", "remaining"}.issubset(by_code[code]))
		self.assertGreater(by_code["ANN"]["total"], 0)
		self.assertEqual(
			by_code["ANN"]["remaining"],
			max(0, by_code["ANN"]["total"] - by_code["ANN"]["taken"] - by_code["ANN"]["pending"]),
		)

		with patch("karyo.hr.employee_resources._own_employee", return_value=self.employee):
			resources = assignments()
		self.assertEqual(resources["policies"][0].leave_policy, policy)
		self.assertEqual(resources["policies"][0].status, "Current (selected)")
		self.assertTrue(
			{"Annual Leave", "Casual Leave", "Sick Leave"}.issubset(
				{row.leave_type for row in resources["policies"][0].details}
			)
		)

	def test_paternity_is_a_ten_day_conditional_entitlement_not_a_bank_dependency(self):
		male = frappe.db.get_value(
			"Employee", {"status": "Active", "gender": "Male", "karyo_employment_category": "PERM"}, "name",
		)
		self.assertTrue(male)
		ensure_employee_leave_entitlements(male)
		balance = next((row for row in leave_balances(male) if row.get("leave_code") == "PAT"), None)
		self.assertTrue(balance)
		self.assertEqual(balance["source"], "Conditional entitlement")
		self.assertEqual(balance["total"], 10)
		self.assertLessEqual(balance["remaining"], 10)
		self.assertEqual(balance["bank_type"], "None")

	def test_employee_supports_multiple_and_conditional_leave_schemes(self):
		meta = frappe.get_meta("Employee")
		self.assertTrue(meta.has_field("karyo_leave_schemes"))
		employee = frappe.db.get_value(
			"Employee", {"status": "Active", "karyo_employment_category": "PERM"}, "name",
		)
		self.assertTrue(employee)
		rows = frappe.get_all(
			"Employee Leave Scheme Selection",
			filters={"parent": employee, "parenttype": "Employee", "is_active": 1},
			fields=["leave_scheme", "selection_source", "condition"], order_by="idx asc",
		)
		self.assertGreaterEqual(len(rows), 2)
		self.assertIn("Conditional", {row.selection_source for row in rows})
