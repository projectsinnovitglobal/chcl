import json
import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.desk.payroll_drawer import record_save, record_action
from karyo.desk.payroll_management import screen_data


class TestPayrollTableConsistency(unittest.TestCase):
    def setUp(self):
        self.user=frappe.session.user;frappe.set_user('Administrator');frappe.db.savepoint('table_consistency')
        self.notify=patch('frappe.publish_realtime');self.notify.start()
        self.suffix='Row-'+uuid4().hex[:10]

    def tearDown(self):
        self.notify.stop();frappe.set_user('Administrator');frappe.db.rollback(save_point='table_consistency');frappe.set_user(self.user)

    def test_remove_child_keeps_master_and_rejects_foreign_locked_rows(self):
        components=[record_save('salarysetup','Salary Component',{'salary_component':self.suffix+str(i),
            'salary_component_abbr':self.suffix+str(i),'type':'Earning','depends_on_payment_days':0})['name'] for i in range(2)]
        company=frappe.db.get_value('Company',{},'name')
        name=record_save('salarysetup','Salary Structure',{'record_name':self.suffix,'company':company,
            'currency':frappe.db.get_value('Company',company,'default_currency'),'is_active':'Yes','payroll_frequency':'Monthly',
            'earnings':[{'salary_component':c,'amount':1000,'depends_on_payment_days':0} for c in components]})['name']
        doc=frappe.get_doc('Salary Structure',name)
        row=doc.earnings[-1].name
        with self.assertRaises(frappe.ValidationError):record_action('salarysetup','Salary Structure',name,'remove_row',json.dumps({'fieldname':'earnings','row_name':'foreign-row'}))
        record_action('salarysetup','Salary Structure',name,'remove_row',json.dumps({'fieldname':'earnings','row_name':row}))
        doc.reload();self.assertEqual(len(doc.earnings),1);self.assertTrue(frappe.db.exists('Salary Component',components[-1]))
        with self.assertRaises(frappe.PermissionError):record_action('salarysetup','Salary Structure',name,'remove_row',json.dumps({'fieldname':'company','row_name':row}))
        record_action('salarysetup','Salary Structure',name,'submit')
        with self.assertRaises(frappe.ValidationError):record_action('salarysetup','Salary Structure',name,'remove_row',json.dumps({'fieldname':'earnings','row_name':doc.earnings[0].name}))
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):record_action('salarysetup','Salary Structure',name,'remove_row',json.dumps({'fieldname':'earnings','row_name':row}))

    def test_all_branches_and_canonical_pdb_catalogue(self):
        frappe.set_user('mbc.admin@mbc.mu')
        data=screen_data('bank')
        self.assertIsNone(data['master']['selected'])
        self.assertEqual({r.name for r in data['detail']['rows']},set(frappe.get_list('Payroll Bank Branch',pluck='name',limit_page_length=40)))
        pdb=screen_data('pdb')
        self.assertEqual({r.name for r in pdb['detail']['rows']},set(frappe.get_list('Payroll PDB Code',pluck='name',order_by='modified desc, name asc',limit_page_length=40)))
        self.assertTrue(all('_record_tools' in r for r in pdb['detail']['rows']))
