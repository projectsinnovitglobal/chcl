"""CSV parsing, staging validation, approval, and atomic posting."""

import csv
import hashlib
import io
import json

import frappe
from frappe import _
from frappe.utils import flt, getdate, now_datetime

from karyo.payroll.once_off import post_batch


def get_template_headers(template_name):
	template = frappe.get_doc("Payroll Transaction Import Template", template_name)
	return json.loads(template.headers_json)


@frappe.whitelist()
def download_template(template_name):
	return ",".join(get_template_headers(template_name)) + "\n"


def _file_content(doc, csv_content=None):
	if csv_content is not None:
		return csv_content.decode() if isinstance(csv_content, bytes) else csv_content
	if not doc.csv_file:
		frappe.throw(_("Attach a CSV file before processing the import."))
	file_doc = frappe.get_doc("File", {"file_url": doc.csv_file})
	content = file_doc.get_content()
	return content.decode() if isinstance(content, bytes) else content


@frappe.whitelist()
def process_upload(name, csv_content=None):
	doc = frappe.get_doc("Payroll Transaction Import", name)
	if doc.status in ("Approved", "Posted", "Rejected"):
		frappe.throw(_("Approved, posted, or rejected imports cannot be processed again."))
	content = _file_content(doc, csv_content)
	file_hash = hashlib.sha256(content.encode("utf-8-sig")).hexdigest()
	duplicate = frappe.db.exists(
		"Payroll Transaction Import",
		{
			"name": ("!=", doc.name),
			"company": doc.company,
			"payroll_cycle": doc.payroll_cycle,
			"upload_type": doc.upload_type,
			"file_hash": file_hash,
			"status": ("!=", "Rejected"),
		},
	)
	if duplicate:
		frappe.throw(_("This CSV file has already been uploaded as {0}.").format(duplicate))
	reader = csv.DictReader(io.StringIO(content.lstrip("\ufeff")))
	expected = get_template_headers(doc.template_version)
	if reader.fieldnames != expected:
		frappe.throw(_("CSV headers do not match template {0}.").format(doc.template_version))
	doc.set("rows", [])
	seen = set()
	for row_number, values in enumerate(reader, start=2):
		row = doc.append("rows", _parse_row(row_number, values))
		_validate_row(doc, row, seen)
		if row.business_key:
			seen.add(row.business_key)
	doc.file_hash = file_hash
	doc.status = "Validated"
	_update_controls(doc)
	doc.save()
	return get_import_report(doc.name)


def _parse_row(row_number, values):
	return {
		"row_number": row_number,
		"raw_values": json.dumps(values, sort_keys=True),
		"employee": (values.get("employee") or "").strip(),
		"pdb_code": (values.get("pdb_code") or "").strip(),
		"amount": flt(values.get("amount")),
		"calculation_method": (values.get("calculation_method") or "Fixed Amount").strip(),
		"formula": (values.get("formula") or "").strip(),
		"start_date": (values.get("start_date") or "").strip() or None,
		"end_date": (values.get("end_date") or "").strip() or None,
		"initial_balance": flt(values.get("initial_balance")),
		"transaction_reference": (values.get("transaction_reference") or "").strip(),
		"remarks": (values.get("remarks") or "").strip(),
	}


def _validate_row(doc, row, seen):
	errors = []
	if not frappe.db.exists("Employee", {"name": row.employee, "company": doc.company}):
		errors.append(_("Employee is missing or belongs to another company."))
	pdb = frappe.db.get_value(
		"Payroll PDB Code",
		row.pdb_code,
		["transaction_mode", "reducing_balance", "is_active"],
		as_dict=True,
	)
	required_mode = "Static" if doc.upload_type == "Static" else "Once Off"
	if not pdb or not pdb.is_active or pdb.transaction_mode not in (required_mode, "Both"):
		errors.append(_("PDB Code is not active for {0} imports.").format(doc.upload_type))
	if flt(row.amount) <= 0 and not (doc.upload_type == "Static" and row.formula):
		errors.append(_("Amount must be positive unless a static formula is supplied."))
	if doc.upload_type == "Static":
		if not row.start_date:
			errors.append(_("Start Date is required for static transactions."))
		else:
			try:
				getdate(row.start_date)
			except Exception:
				errors.append(_("Start Date is invalid."))
		if row.end_date:
			try:
				if getdate(row.end_date) < getdate(row.start_date):
					errors.append(_("End Date cannot be before Start Date."))
			except Exception:
				errors.append(_("End Date is invalid."))
		if pdb and pdb.reducing_balance and flt(row.initial_balance) <= 0:
			errors.append(_("Initial Balance is required for reducing-balance PDBs."))
	row.business_key = _business_key(doc, row)
	if row.business_key in seen or _business_key_exists(doc, row.business_key):
		errors.append(_("Duplicate business key."))
	row.status = "Invalid" if errors else "Valid"
	row.validation_message = "\n".join(errors)


def _business_key(doc, row):
	qualifier = row.start_date if doc.upload_type == "Static" else (row.transaction_reference or row.amount)
	raw = f"{doc.upload_type}::{doc.payroll_cycle}::{row.employee}::{row.pdb_code}::{qualifier}"
	return hashlib.sha256(raw.encode()).hexdigest()


def _business_key_exists(doc, business_key):
	rows = frappe.get_all(
		"Payroll Transaction Import Row",
		filters={"business_key": business_key, "parent": ("!=", doc.name), "status": ("in", ["Valid", "Posted"])},
		pluck="parent",
	)
	return any(
		frappe.db.get_value("Payroll Transaction Import", parent, "status") != "Rejected"
		for parent in rows
	)


def _update_controls(doc):
	doc.total_rows = len(doc.rows)
	doc.valid_rows = sum(row.status == "Valid" for row in doc.rows)
	doc.invalid_rows = sum(row.status == "Invalid" for row in doc.rows)
	doc.control_total = sum(flt(row.amount) for row in doc.rows)
	doc.accepted_total = sum(flt(row.amount) for row in doc.rows if row.status == "Valid")


@frappe.whitelist()
def approve_import(name):
	doc = frappe.get_doc("Payroll Transaction Import", name)
	if doc.status != "Validated" or doc.invalid_rows:
		frappe.throw(_("Only a fully valid staged import can be approved."))
	doc.status = "Approved"
	doc.approved_by = frappe.session.user
	doc.approved_on = now_datetime()
	doc.save()
	return doc.name


@frappe.whitelist()
def reject_import(name, reason):
	if not reason:
		frappe.throw(_("A rejection reason is required."))
	doc = frappe.get_doc("Payroll Transaction Import", name)
	if doc.status == "Posted":
		frappe.throw(_("Posted imports cannot be rejected."))
	doc.status = "Rejected"
	doc.decision_reason = reason
	for row in doc.rows:
		if row.status != "Posted":
			row.status = "Rejected"
	doc.save()
	return doc.name


@frappe.whitelist()
def post_import(name):
	doc = frappe.get_doc("Payroll Transaction Import", name)
	if doc.status == "Posted":
		return get_import_report(doc.name)
	if doc.status != "Approved":
		frappe.throw(_("Only Approved imports can be posted."))
	if doc.upload_type == "Once-off":
		_post_once_off(doc)
	else:
		_post_static(doc)
	doc.status = "Posted"
	doc.posted_by = frappe.session.user
	doc.posted_on = now_datetime()
	doc.save()
	return get_import_report(doc.name)


def _post_once_off(doc):
	batch = frappe.get_doc(
		{
			"doctype": "Once-Off PDB Batch",
			"company": doc.company,
			"payroll_cycle": doc.payroll_cycle,
			"batch_description": _("CSV Import {0}").format(doc.name),
			"status": "Draft",
			"lines": [
				{
					"employee": row.employee,
					"pdb_code": row.pdb_code,
					"amount": row.amount,
					"transaction_reference": row.transaction_reference or f"{doc.name}-{row.row_number}",
					"remarks": row.remarks,
				}
				for row in doc.rows
				if row.status == "Valid"
			],
		}
	).insert(ignore_permissions=True)
	batch.status = "Approved"
	batch.flags.approved_import = doc.name
	batch.save(ignore_permissions=True)
	post_batch(batch.name)
	doc.generated_batch = batch.name
	for row in doc.rows:
		if row.status == "Valid":
			row.status = "Posted"
			row.target_doctype = "Once-Off PDB Batch"
			row.target_name = batch.name


def _post_static(doc):
	for row in doc.rows:
		if row.status != "Valid":
			continue
		recurring = frappe.get_doc(
			{
				"doctype": "Employee Recurring PDB",
				"employee": row.employee,
				"company": doc.company,
				"pdb_code": row.pdb_code,
				"calculation_method": row.calculation_method or "Fixed Amount",
				"amount": row.amount,
				"formula": row.formula,
				"initial_balance": row.initial_balance,
				"start_date": row.start_date,
				"end_date": row.end_date,
				"remarks": row.remarks,
				"status": "Draft",
			}
		).insert(ignore_permissions=True)
		recurring.status = "Active"
		recurring.change_reason = _("Approved CSV import {0}").format(doc.name)
		recurring.save(ignore_permissions=True)
		row.status = "Posted"
		row.target_doctype = recurring.doctype
		row.target_name = recurring.name


@frappe.whitelist()
def get_import_report(name):
	doc = frappe.get_doc("Payroll Transaction Import", name)
	return {
		"name": doc.name,
		"status": doc.status,
		"total_rows": doc.total_rows,
		"valid_rows": doc.valid_rows,
		"invalid_rows": doc.invalid_rows,
		"control_total": doc.control_total,
		"accepted_total": doc.accepted_total,
		"rejections": [
			{"row_number": row.row_number, "message": row.validation_message, "raw_values": row.raw_values}
			for row in doc.rows
			if row.status in ("Invalid", "Rejected")
		],
	}
