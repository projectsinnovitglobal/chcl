"""Validated Passage Benefit bank cutover from the client opening-balance sheet."""

import hashlib
import json
from pathlib import Path

import frappe
from frappe import _
from frappe.utils import add_days, flt, getdate


DATA_FILE = Path(__file__).resolve().parent.parent / "payroll" / "data" / "pb_bank_opening_balances.json"
BATCH_NAME = "MBC-PB-BANK-2023-SHEET-1"
MAPPING_VERSION = "PBB-SHEET-1"
MIGRATION_ROLES = ("System Manager", "Data Migration Manager")


def _load_source():
	with DATA_FILE.open(encoding="utf-8") as handle:
		return json.load(handle)


def _canonical_payload(row):
	return json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _hash(value):
	return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _resolve_employee(legacy_code):
	"""Resolve a legacy employee code without guessing from display names."""
	legacy_code = str(legacy_code or "").strip()
	if not legacy_code:
		return None, "Employee Code is required."
	candidates = set(frappe.get_all("Employee", filters={"name": legacy_code}, pluck="name"))
	meta = frappe.get_meta("Employee")
	for fieldname in ("karyo_legacy_employee_id", "employee_number"):
		if meta.has_field(fieldname):
			candidates.update(
				frappe.get_all("Employee", filters={fieldname: legacy_code}, pluck="name")
			)
	if not candidates:
		return None, _("No Employee mapping exists for legacy code {0}.").format(legacy_code)
	if len(candidates) > 1:
		return None, _("Legacy employee code {0} maps to multiple Employees.").format(legacy_code)
	return candidates.pop(), None


def _reconciliation_difference(row):
	if row.get("opening_balance") is None or row.get("closing_balance") is None:
		return None
	expected = (
		flt(row.get("opening_balance"))
		+ flt(row.get("earned"))
		+ flt(row.get("adjustments"))
		- flt(row.get("claims_used"))
	)
	return round(flt(row.get("closing_balance")) - expected, 2)


def _validate_row(row):
	errors = []
	if not str(row.get("employee_code") or "").strip():
		errors.append(("MISSING_EMPLOYEE_CODE", "Employee Code is required."))
	if not str(row.get("pb_period") or "").strip():
		errors.append(("MISSING_PERIOD", "PB Year / Period is required."))
	if row.get("opening_balance") is None:
		errors.append(("MISSING_OPENING_BALANCE", "Opening Balance is required for cutover."))
	if row.get("closing_balance") is None:
		errors.append(("MISSING_CLOSING_BALANCE", "Closing Balance is required for cutover."))
	if not row.get("as_at_date"):
		errors.append(("MISSING_AS_AT_DATE", "As At / Last Computation Date is required for cutover."))

	employee, employee_error = _resolve_employee(row.get("employee_code"))
	if employee_error:
		errors.append(("EMPLOYEE_NOT_MAPPED", employee_error))
	elif frappe.db.exists("Passage Benefit Bank", employee):
		errors.append(("BANK_EXISTS", _("Employee {0} already has a Passage Benefit Bank.").format(employee)))

	difference = _reconciliation_difference(row)
	if difference is not None and abs(difference) >= 0.005:
		errors.append((
			"BALANCE_MISMATCH",
			_("Closing Balance differs from Opening + Earned + Adjustments - Claims by {0:.2f}.").format(
				difference
			),
		))
	return employee, difference, errors


def stage_current_sheet(commit=True):
	"""Stage the current PBB sheet exactly once; invalid source rows remain unloaded."""
	if frappe.db.exists("MBC Migration Batch", BATCH_NAME):
		batch = frappe.get_doc("MBC Migration Batch", BATCH_NAME)
		return _summary(batch, created=False)
	payload = _load_source()
	rows = payload["rows"]
	canonical_source = _canonical_payload(payload)
	as_at_dates = [getdate(row["as_at_date"]) for row in rows if row.get("as_at_date")]
	batch = frappe.get_doc({
		"doctype": "MBC Migration Batch",
		"load_id": BATCH_NAME,
		"migration_domain": "Passage Benefit",
		"source_filename": "PBB Sheet2 A1-K6",
		"source_checksum": _hash(canonical_source),
		"source_as_at": max(as_at_dates),
		"source_reference": payload["source_url"],
		"status": "Preview",
		"mapping_version": MAPPING_VERSION,
	})
	for row in rows:
		employee, difference, errors = _validate_row(row)
		row_json = _canonical_payload(row)
		batch.append("rows", {
			"row_number": row["sheet_row"],
			"legacy_id": f"{row['employee_code']}:{row['pb_period']}",
			"source_hash": _hash(row_json),
			"payload_json": row_json,
			"status": "Rejected" if errors else "Valid",
			"error_code": errors[0][0] if errors else None,
			"error_message": " | ".join(message for _code, message in errors) if errors else None,
			"target_doctype": "Passage Benefit Bank" if employee else None,
			"control_amount": row.get("closing_balance") or 0,
		})
	batch.insert(ignore_permissions=True)
	if commit:
		frappe.db.commit()
	return _summary(batch, created=True)


def _summary(batch, created=False):
	return {
		"batch": batch.name,
		"created": created,
		"status": batch.status,
		"source_rows": len(batch.rows),
		"valid": sum(row.status in ("Valid", "Loaded") for row in batch.rows),
		"rejected": sum(row.status == "Rejected" for row in batch.rows),
		"errors": [
			{"row": row.row_number, "code": row.error_code, "message": row.error_message}
			for row in batch.rows if row.status == "Rejected"
		],
	}


@frappe.whitelist()
def validate_batch(batch_name=BATCH_NAME, approval_reference=None):
	frappe.only_for(MIGRATION_ROLES)
	batch = frappe.get_doc("MBC Migration Batch", batch_name)
	if batch.migration_domain != "Passage Benefit" or batch.status not in ("Preview", "Failed"):
		frappe.throw(_("Only a Preview or Failed Passage Benefit batch can be validated."))
	for item in batch.rows:
		row = json.loads(item.payload_json)
		employee, _difference, errors = _validate_row(row)
		item.status = "Rejected" if errors else "Valid"
		item.error_code = errors[0][0] if errors else None
		item.error_message = " | ".join(message for _code, message in errors) if errors else None
		item.target_doctype = "Passage Benefit Bank" if employee else None
		item.target_name = None
	if batch.status == "Failed":
		batch.status = "Preview"
	if not any(item.status == "Rejected" for item in batch.rows):
		batch.approval_reference = approval_reference or batch.approval_reference
		if not batch.approval_reference:
			frappe.throw(_("Approval Reference is required to validate the migration batch."))
		batch.status = "Validated"
	batch.save(ignore_permissions=True)
	return _summary(batch)


@frappe.whitelist()
def load_validated_batch(batch_name=BATCH_NAME):
	"""Load only approved, reconciled rows as cutover opening balances."""
	frappe.only_for(MIGRATION_ROLES)
	batch = frappe.get_doc("MBC Migration Batch", batch_name)
	if batch.migration_domain != "Passage Benefit" or batch.status != "Validated":
		frappe.throw(_("The Passage Benefit migration batch must be Validated before loading."))
	target_total = 0.0
	for item in batch.rows:
		if item.status != "Valid":
			continue
		row = json.loads(item.payload_json)
		employee, difference, errors = _validate_row(row)
		if errors:
			frappe.throw(_("Source row {0} is no longer valid: {1}").format(item.row_number, errors[0][1]))
		bank = frappe.get_doc({
			"doctype": "Passage Benefit Bank",
			"employee": employee,
			"opening_date": add_days(getdate(row["as_at_date"]), 1),
			"opening_balance": row["closing_balance"],
			"last_computation_date": row["as_at_date"],
			"last_salary_basis": row.get("last_salary_basis"),
			"migration_batch": batch.name,
			"migration_status": "Loaded",
			"legacy_employee_code": row["employee_code"],
			"legacy_pb_period": row["pb_period"],
			"legacy_opening_balance": row.get("opening_balance"),
			"legacy_earned": row.get("earned"),
			"legacy_adjustments": row.get("adjustments"),
			"legacy_claims_used": row.get("claims_used"),
			"legacy_closing_balance": row["closing_balance"],
			"legacy_as_at_date": row["as_at_date"],
			"legacy_last_salary_basis": row.get("last_salary_basis"),
			"legacy_reconciliation_difference": difference,
			"legacy_source_reference": row.get("source_reference"),
			"legacy_remarks": row.get("remarks"),
		})
		bank.insert(ignore_permissions=True)
		item.status = "Loaded"
		item.target_doctype = "Passage Benefit Bank"
		item.target_name = bank.name
		target_total += flt(bank.opening_balance)
	batch.target_total = target_total
	batch.status = "Loaded"
	batch.save(ignore_permissions=True)
	return _summary(batch)


@frappe.whitelist()
def reconcile_loaded_batch(batch_name=BATCH_NAME, reconciliation_reference=None):
	frappe.only_for(MIGRATION_ROLES)
	batch = frappe.get_doc("MBC Migration Batch", batch_name)
	if batch.migration_domain != "Passage Benefit" or batch.status != "Loaded":
		frappe.throw(_("Only a Loaded Passage Benefit batch can be reconciled."))
	target_total = 0.0
	for item in batch.rows:
		if item.status != "Loaded" or not item.target_name:
			continue
		bank = frappe.get_doc("Passage Benefit Bank", item.target_name)
		if bank.migration_batch != batch.name:
			frappe.throw(_("Passage Benefit Bank {0} is not linked to this batch.").format(bank.name))
		target_total += flt(bank.opening_balance)
		bank.db_set("migration_status", "Reconciled", update_modified=False)
	batch.target_total = target_total
	batch.reconciliation_reference = reconciliation_reference or batch.reconciliation_reference
	if not batch.reconciliation_reference:
		frappe.throw(_("Reconciliation Reference is required."))
	batch.status = "Reconciled"
	batch.save(ignore_permissions=True)
	return _summary(batch)
