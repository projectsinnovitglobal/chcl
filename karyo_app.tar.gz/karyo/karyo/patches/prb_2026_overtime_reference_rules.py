"""Align deployed payroll settings with the supplied PRB 2026 reference."""

import frappe


def execute():
	# PRB 16.5.62-16.5.63 makes urgency/unpostponability a condition for the
	# Rs 60,600-Rs 77,750 band.  Earlier attendance-sheet configuration left
	# this switch disabled, which would incorrectly pay ordinary overtime.
	frappe.db.set_single_value("PRB Payroll Settings", "ot_middle_band_requires_urgent", 1)
	frappe.clear_document_cache("PRB Payroll Settings", "PRB Payroll Settings")
