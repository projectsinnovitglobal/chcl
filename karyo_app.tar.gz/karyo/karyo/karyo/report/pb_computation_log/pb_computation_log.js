frappe.query_reports["PB Computation Log"] = {
	filters: [
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
		{fieldname: "pay_period", label: __("Pay Period"), fieldtype: "Data"},
		{fieldname: "from_date", label: __("Period From"), fieldtype: "Date"},
		{fieldname: "to_date", label: __("Period To"), fieldtype: "Date"},
	],
};
