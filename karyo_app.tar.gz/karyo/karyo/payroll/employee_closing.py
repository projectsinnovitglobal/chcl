"""Employee completion within a governed payroll cycle."""
import frappe
from frappe import _
from frappe.utils import now_datetime, flt
from karyo.payroll.governance import has_actor_role
from karyo.payroll.employee_processing import mark


def population(cycle):
    from karyo.desk.payroll_management import employee_run_eligibility
    pay_day_master = frappe.db.get_value('Payroll Pay Day', cycle.pay_day, 'pay_day_master')
    filters = {'company': cycle.company, 'status': 'Active',
        'date_of_joining': ('<=', cycle.end_date), 'karyo_payroll_type': cycle.payroll_type}
    if pay_day_master:
        filters['karyo_pay_day'] = pay_day_master
    rows = frappe.get_all('Employee', filters=filters,
        fields=['name', 'status', 'date_of_joining', 'relieving_date', 'karyo_post_exit_payroll_enabled', 'karyo_post_exit_payroll_until', 'karyo_post_exit_payment_reference'])
    names = {r.name for r in rows if employee_run_eligibility(r, cycle.start_date, cycle.end_date)['eligible']}
    names.update(frappe.get_all('Payroll Cycle Employee', filters={'payroll_cycle': cycle.name,
        'status': ('!=', 'Excluded')}, pluck='employee'))
    names.difference_update(frappe.get_all('Payroll Cycle Employee', filters={'payroll_cycle':cycle.name,
        'status':'Excluded'}, pluck='employee'))
    names.update(s.employee for s in slips(cycle))
    return names


def slips(cycle):
    filters = {'docstatus': ('<', 2), 'company': cycle.company}
    links = [['karyo_payroll_cycle', '=', cycle.name]]
    if cycle.payroll_entry:
        links.append(['payroll_entry', '=', cycle.payroll_entry])
    return frappe.get_all('Salary Slip', filters=filters, or_filters=links,
        fields=['name', 'employee', 'docstatus', 'gross_pay', 'net_pay', 'payroll_entry', 'karyo_payroll_cycle'])


def loan_blocked(cycle, employee):
    unpaid = frappe.db.sql('''select count(*) from `tabKaryo Loan Schedule` s
        inner join `tabKaryo Loan` l on l.name=s.parent
        where l.company=%s and l.employee=%s and s.due_date between %s and %s
        and l.status='Active'
        and s.status not in ('Paid', 'Rejected')
        and abs((s.paid_capital+s.paid_interest+s.paid_insurance)-s.total)>0.005''',
        (cycle.company, employee, cycle.start_date, cycle.end_date))[0][0]
    mismatch = frappe.db.sql('''select count(*) from (
        select a.loan from `tabKaryo Loan Payroll Allocation` a
        inner join `tabKaryo Loan` l on l.name=a.loan
        where a.payroll_cycle=%s and l.employee=%s group by a.loan
        having abs(sum(case when a.is_reversal=1 then -a.amount else a.amount end)-
          (select coalesce(sum(e.credit-e.debit),0) from `tabKaryo Loan Ledger Entry` e
           where e.loan=a.loan and e.payroll_cycle=%s))>0.005) differences''',
        (cycle.name, employee, cycle.name))[0][0]
    return bool(unpaid or mismatch)


def state(cycle, employees=None):
    cycle.check_permission('read')
    if isinstance(employees, str):
        employees = frappe.parse_json(employees)
    if employees is not None and (not isinstance(employees, list) or any(not isinstance(e, str) for e in employees)):
        frappe.throw(_('Select employees from the employee filter.'))
    all_names = population(cycle)
    options = frappe.get_list('Employee', filters={'name': ('in', list(all_names) or ['']), 'company': cycle.company},
        fields=['name', 'employee_name', 'department'], order_by='employee_name asc', limit_page_length=0)
    requested = list(dict.fromkeys(employees or []))
    if set(requested) - {r.name for r in options}:
        frappe.throw(_('Selected employees do not belong to this cycle or are not accessible.'))
    chosen = set(requested or [r.name for r in options])
    records = {r.employee: r for r in frappe.get_all('Payroll Cycle Employee', filters={'payroll_cycle':cycle.name},
        fields=['employee', 'status', 'closed_on', 'closed_by', 'employee_approved_on'])}
    salary_slips = slips(cycle)
    results = frappe.get_all('Payroll Statutory Result', filters={'payroll_cycle':cycle.name},
        fields=['employee','status','result_type'])
    exceptions = frappe.get_all('Payroll Readiness Exception', filters={'payroll_cycle':cycle.name,
        'status':'Open','severity':('in',['Blocking','Approval Required'])}, fields=['employee','validation_code','message'])
    can_close = cycle.has_permission('write') and has_actor_role('finance')
    rows = []
    for employee in options:
        if employee.name not in chosen:
            continue
        record = records.get(employee.name, {})
        employee_slips = [s for s in salary_slips if s.employee == employee.name]
        statutory = [r for r in results if r.employee == employee.name]
        issues = [r for r in exceptions if not r.employee or r.employee == employee.name]
        reason, screen = None, 'close'
        if cycle.docstatus == 2 or cycle.status == 'Cancelled':
            reason = _('Cancelled payroll cannot be closed.')
        elif not record.get('employee_approved_on') and (cycle.docstatus != 1 or cycle.status not in ('Approved','Reopened','Closed')):
            reason = _('Approve Payroll for this employee selection before closing.')
        elif issues:
            reason, screen = issues[0].message, 'process'
        elif record.get('status') == 'Failed':
            reason, screen = _('Resolve this employee’s failed payroll processing.'), 'process'
        elif len(employee_slips) != 1 or employee_slips[0].docstatus != 1:
            reason = _('Submit exactly one Salary Slip for this employee and cycle.')
        elif employee_slips[0].karyo_payroll_cycle not in (None, '', cycle.name):
            reason = _('The Salary Slip belongs to a different payroll cycle.')
        elif not statutory or any(r.status not in ('Reviewed','Applied') for r in statutory):
            reason, screen = _('Calculate and review this employee’s PAYE and contributions.'), 'applypaye'
        elif any(r.result_type in ('PAYE','Employee Contribution') and r.status != 'Applied' for r in statutory):
            reason, screen = _('Apply this employee’s PAYE and contribution deductions.'), 'applypaye'
        elif loan_blocked(cycle, employee.name):
            reason, screen = _('Reconcile this employee’s unpaid loan schedules and loan ledger.'), 'loan_report'
        closed = bool(not reason and (record.get('closed_on') or cycle.status == 'Closed'))
        slip = employee_slips[0] if len(employee_slips) == 1 else {}
        rows.append({'employee':employee.name,'employee_name':employee.employee_name,'department':employee.department,
            'status': 'Closed' if closed else 'Blocked' if reason else 'Ready to close',
            'generated':bool(employee_slips), 'slip':employee_slips[0].name if len(employee_slips)==1 else None,
            'closed_on':record.get('closed_on'), 'closed_by':record.get('closed_by'),
            'reason':reason, 'screen':screen, 'exception_code':issues[0].validation_code if issues else None,
            'can_close': bool(can_close and not closed and not reason),
            'gross_pay':flt(slip.get('gross_pay')), 'net_pay':flt(slip.get('net_pay'))})
    closed_names = {name for name, r in records.items() if r.closed_on}
    return {'employees':[r['employee'] for r in rows], 'options':[{'value':r.name,'label':r.employee_name,'description':r.name} for r in options],
        'rows':rows, 'can_close':can_close, 'total':len(all_names), 'remaining':len(all_names-closed_names),
        'ready':sum(r['can_close'] for r in rows), 'closed':sum(r['status']=='Closed' for r in rows),
        'blocked':sum(bool(r['reason']) for r in rows),
        'summary':{'employees':len(rows),'slips':len([s for s in salary_slips if s.employee in chosen]),
            'draft':sum(s.docstatus==0 for s in salary_slips if s.employee in chosen),
            'submitted':sum(s.docstatus==1 for s in salary_slips if s.employee in chosen),
            'gross_pay':sum(r['gross_pay'] for r in rows),'net_pay':sum(r['net_pay'] for r in rows)}}


@frappe.whitelist()
def close_employees(payroll_cycle, employees=None):
    cycle = frappe.get_doc('Payroll Cycle', payroll_cycle)
    cycle.check_permission('write')
    if not has_actor_role('finance'):
        frappe.throw(_('Only payroll finance can close employee payroll.'), frappe.PermissionError)
    # Serialize selections and finalization; repeated requests are idempotent.
    frappe.db.sql('select name from `tabPayroll Cycle` where name=%s for update', cycle.name)
    cycle.reload()
    scope = state(cycle, employees)
    closed = []
    for row in scope['rows']:
        if row['can_close']:
            previous_flag = frappe.flags.payroll_employee_closing
            try:
                frappe.flags.payroll_employee_closing = True
                mark(cycle, row['employee'], status='Closed', closed_on=now_datetime(), closed_by=frappe.session.user)
            finally:
                frappe.flags.payroll_employee_closing = previous_flag
            closed.append(row['employee'])
    blocked = [{'employee':r['employee'], 'reason':r['reason']} for r in scope['rows'] if r['reason']]
    message = _('{0} employee(s) closed; {1} blocked employee(s) remain open.').format(len(closed), len(blocked))
    final_reason = None
    closed_names = set(frappe.get_all('Payroll Cycle Employee', filters={'payroll_cycle':cycle.name,
        'closed_on':('is','set')}, pluck='employee'))
    everyone = population(cycle)
    if everyone and everyone.issubset(closed_names) and cycle.status != 'Closed':
        frappe.db.savepoint('employee_cycle_finalize')
        try:
            from karyo.payroll.completion import run_step
            run_step(cycle.name, 'Close Payroll')
            message += ' ' + _('The payroll cycle is now closed.')
        except (frappe.ValidationError, frappe.PermissionError) as exc:
            frappe.db.rollback(save_point='employee_cycle_finalize')
            final_reason = str(exc)
            message += ' ' + _('The overall cycle remains open: {0}').format(final_reason)
    else:
        message += ' ' + _('The overall cycle remains open until all employees and cycle checks are complete.') if cycle.status != 'Closed' else ''
    return {'closed':closed,'blocked':blocked,'message':message,'final_reason':final_reason,
        'cycle_status':frappe.db.get_value('Payroll Cycle',cycle.name,'status')}


def guard_closed_slip(doc, method=None):
    cycle = doc.get('payroll_cycle') or doc.get('karyo_payroll_cycle') or (frappe.db.get_value('Payroll Entry',doc.payroll_entry,'karyo_payroll_cycle') if doc.get('payroll_entry') else None)
    if cycle and (frappe.db.get_value('Payroll Cycle', cycle, 'status') == 'Closed' or frappe.db.exists(
        'Payroll Cycle Employee', {'payroll_cycle':cycle,'employee':doc.employee,'closed_on':('is','set')})):
        frappe.throw(_('This employee’s payroll is closed. Reopen the payroll cycle before changing its payroll records.'))

    if cycle and not frappe.flags.payroll_employee_completion and frappe.db.exists(
        'Payroll Cycle Employee', {'payroll_cycle':cycle, 'employee':doc.employee, 'employee_approved_on':('is','set')}):
        frappe.throw(_('This employee payroll is approved. Use the selected payroll steps or reopen the cycle before editing payroll records.'))
