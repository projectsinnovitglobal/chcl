"""Seed the initial Open period record on pre-existing Passage Benefit Banks.

Phase 1 (G1a) restructures the bank into discrete per-period balance records.
Legacy banks carry a single running balance and no period rows; saving each bank
runs validate(), which appends an initial Open period (opening amount = opening
balance) and reconciles its figures from the ledger. Idempotent.
"""

import frappe


def execute():
	if not frappe.db.table_exists("Passage Benefit Bank"):
		return
	migrated = 0
	for name in frappe.get_all("Passage Benefit Bank", pluck="name"):
		bank = frappe.get_doc("Passage Benefit Bank", name)
		if bank.periods:
			continue
		bank.save(ignore_permissions=True)
		migrated += 1
	frappe.db.commit()
	frappe.logger("karyo").info(f"PB bank period seed: {migrated} bank(s) migrated")
