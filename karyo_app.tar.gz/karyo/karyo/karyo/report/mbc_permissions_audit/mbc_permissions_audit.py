import frappe
from frappe import _


DOMAIN_ROLES = (
	"System Manager",
	"Registry Officer", "Payroll Input", "Payroll Processor", "Payroll Reviewer",
	"Payroll Approver", "Payroll Finance", "Payroll Auditor", "Passage Benefit Officer",
	"Loan Officer", "Loan Committee", "Karyo IT Support",
)
CONFLICTS = (
	("Payroll Input", "Payroll Approver", "Payroll maker and approver"),
	("Payroll Processor", "Payroll Approver", "Payroll processor and approver"),
	("Loan Officer", "Loan Committee", "Loan maker and committee"),
)


def execute(filters=None):
	rows = []
	users = frappe.get_all(
		"Has Role", filters={"role": ("in", DOMAIN_ROLES), "parenttype": "User"},
		fields=["parent as user", "role"], order_by="parent, role",
	)
	by_user = {}
	for row in users:
		by_user.setdefault(row.user, set()).add(row.role)
	for user, roles in by_user.items():
		for left, right, reason in CONFLICTS:
			if {left, right}.issubset(roles):
				rows.append({"severity": "Blocking", "user": user, "roles": f"{left}, {right}", "finding": reason})
		if "System Manager" in roles and len(roles) > 1:
			rows.append({"severity": "Review", "user": user, "roles": ", ".join(sorted(roles)), "finding": "Privileged and operational role combination"})
	return _columns(), rows


def _columns():
	return [
		{"fieldname": "severity", "label": _("Severity"), "fieldtype": "Data", "width": 100},
		{"fieldname": "user", "label": _("User"), "fieldtype": "Link", "options": "User", "width": 220},
		{"fieldname": "roles", "label": _("Roles"), "fieldtype": "Data", "width": 280},
		{"fieldname": "finding", "label": _("Finding"), "fieldtype": "Data", "width": 300},
	]
