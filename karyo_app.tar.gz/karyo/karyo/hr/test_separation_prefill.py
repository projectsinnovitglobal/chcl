"""Dated operational records and real separation lifecycle, rolled back per test."""

import json
import unittest

import frappe

from karyo.hr import final_settlement as api
from karyo.hr.settlement_balances import bank_balance_as_at, current_leave_as_at, leave_position_as_at
from karyo.tests import test_salary_scales as fixtures


class TestSeparationPrefill(unittest.TestCase):
	make_scale = fixtures.TestSalaryScales.make_scale

	def setUp(self):
		fixtures.TestSalaryScales.setUp(self)
		self.as_at = "2026-09-30"
		holiday = "Settlement holidays " + self.uid
		frappe.get_doc({"doctype": "Holiday List", "name": holiday, "holiday_list_name": holiday,
			"from_date": "2000-01-01", "to_date": "2099-12-31"}).db_insert()
		frappe.db.set_value("Employee", self.employee.name, {"karyo_scale_basic_salary": 44000,
			"ctc": 44000, "holiday_list": holiday, "karyo_on_payroll": 0,
			"date_of_birth": "1970-01-01", "karyo_date_joined_service": "2000-01-01"})
		self.employee.reload()
		self.types = {code: frappe.db.get_value("Leave Type", {"karyo_mbc_leave_code": code, "karyo_is_retired": 0}, "name")
			for code in ("SICK01", "SICK02", "ANN", "VAC01")}
		for code in ("SICK01", "ANN"):
			frappe.get_doc({"doctype": "Leave Allocation", "employee": self.employee.name,
				"leave_type": self.types[code], "from_date": "2026-01-01", "to_date": "2026-12-31",
				"new_leaves_allocated": 21}).insert().submit()
		self.leave("SICK01", "2026-09-01", "2026-09-05", 5)
		self.leave("SICK01", "2026-10-10", "2026-10-11", 2)
		self.leave("ANN", "2026-09-10", "2026-09-13", 4)
		self.leave("ANN", "2026-10-01", "2026-10-03", 3)
		# Live bank counters already include later approved leave and year-end postings.
		frappe.get_doc({"doctype": "Sick Leave Bank", "name": self.employee.name, "employee": self.employee.name,
			"status": "Active", "opening_bank_days": 30, "bank_days": 30}).db_insert()
		frappe.get_doc({"doctype": "Vacation Leave Bank", "name": self.employee.name, "employee": self.employee.name,
			"status": "Active", "opening_balance_days": 15, "balance_days": 20}).db_insert()
		self.leave("SICK02", "2026-09-10", "2026-09-11", 2)
		self.leave("SICK02", "2026-10-01", "2026-10-03", 3)
		self.leave("VAC01", "2026-09-10", "2026-09-11", 2)
		self.leave("VAC01", "2026-10-01", "2026-10-03", 3)
		frappe.get_doc({"doctype": "Sick Leave Bank Posting", "name": "SET-SICK-" + self.uid,
			"employee": self.employee.name, "year": 2026, "docstatus": 1,
			"opening_bank_days": 25, "closing_bank_days": 30}).db_insert()
		frappe.get_doc({"doctype": "Vacation Leave Posting", "name": "SET-VAC-" + self.uid,
			"employee": self.employee.name, "year": 2026, "docstatus": 1,
			"opening_balance_days": 10, "closing_balance_days": 20}).db_insert()
		frappe.get_doc({"doctype": "Passage Benefit Bank", "name": self.employee.name,
			"employee": self.employee.name, "company": self.employee.company,
			"opening_date": "2026-01-01", "opening_balance": 5000, "current_balance": 8000}).db_insert()
		for date, amount in [("2026-09-20", 1000), ("2026-10-20", 2000)]:
			frappe.get_doc({"doctype": "Passage Benefit Ledger Entry", "name": frappe.generate_hash(),
				"employee": self.employee.name, "pb_bank": self.employee.name, "posting_date": date,
				"entry_type": "Earning", "amount": amount, "docstatus": 1}).db_insert()
		self.active_loan = self.loan(9500, "2026-01-01", future_credit=1500)
		self.loan(0, "2026-02-01", future_credit=2000, status="Settled")
		self.loan(900000, "2026-10-01")

	def tearDown(self):
		fixtures.TestSalaryScales.tearDown(self)

	def leave(self, code, start, end, days, status="Approved", docstatus=1):
		doc = frappe.get_doc({"doctype": "Leave Application", "name": "SET-LEAVE-" + frappe.generate_hash(),
			"employee": self.employee.name, "company": self.employee.company,
			"leave_type": self.types[code], "from_date": start, "to_date": end,
			"total_leave_days": days, "status": status, "docstatus": docstatus,
			"holiday_list": self.employee.holiday_list})
		doc.db_insert()
		if docstatus == 1:
			doc.create_leave_ledger_entry()
		return doc

	def loan(self, outstanding, disbursement, future_credit=0, status="Disbursed"):
		name = "SET-LOAN-" + frappe.generate_hash()
		frappe.get_doc({"doctype": "Karyo Loan", "name": name, "employee": self.employee.name,
			"company": self.employee.company, "disbursement_date": disbursement,
			"loan_type": "Settlement test", "status": status, "docstatus": 1,
			"outstanding_capital": outstanding}).db_insert()
		if future_credit:
			frappe.get_doc({"doctype": "Karyo Loan Ledger Entry", "name": frappe.generate_hash(),
				"loan": name, "employee": self.employee.name, "transaction_date": "2026-10-01",
				"date_processed": "2026-10-01", "credit": future_credit, "ref_type": "Refund"}).db_insert()
		return name

	def separation(self, status="In Process"):
		return frappe.get_doc({"doctype": "Employee Separation", "employee": self.employee.name,
			"company": self.employee.company, "boarding_begins_on": "2026-09-01",
			"karyo_leaving_date": self.as_at, "boarding_status": status}).insert()

	def test_new_exit_prefills_all_components_without_saving_or_changing_sources(self):
		before = frappe.db.count("Employee Separation")
		result = api.preview_separation(self.employee.name, self.as_at)
		r = result["settlement"]
		self.assertEqual(result["status"], "Preview")
		self.assertEqual((r["sick_current_days"], r["sick_bank_days"], r["annual_current_days"], r["annual_bank_days"]), (16, 28, 17, 13))
		self.assertEqual((r["pb_balance"], r["loan_outstanding"]), (6000, 13000))
		self.assertEqual((r["leave_settlement_amount"], r["gross_settlement"], r["net_settlement"]), (148000, 154000, 141000))
		self.assertEqual(frappe.db.count("Employee Separation"), before)
		self.assertEqual(frappe.db.get_value("Sick Leave Bank", self.employee.name, "bank_days"), 30)
		self.assertEqual(frappe.db.get_value("Employee", self.employee.name, "status"), "Active")

	def test_pending_leave_is_excluded_and_as_at_date_changes_the_preview(self):
		self.leave("ANN", "2026-09-20", "2026-09-25", 6, status="Open", docstatus=0)
		self.assertEqual(api.calculate(self.employee.name, self.as_at)["annual_current_days"], 17)
		self.assertEqual(api.calculate(self.employee.name, "2026-10-04")["annual_current_days"], 14)
		self.assertEqual(api.calculate(self.employee.name, "2026-10-04")["sick_bank_days"], 25)

	def test_bank_leave_crossing_cutoff_restores_only_future_portion(self):
		self.leave("SICK02", "2026-09-29", "2026-10-02", 4)
		frappe.db.set_value("Sick Leave Bank", self.employee.name, "bank_days", 26)
		self.assertEqual(bank_balance_as_at(self.employee.name, self.as_at, "Sick Leave Bank")[0], 26)

	def test_save_persists_prefill_and_submit_in_process_keeps_employee_active(self):
		doc = self.separation()
		self.assertEqual((doc.karyo_sick_current_days, doc.karyo_sick_bank_days, doc.karyo_pb_balance), (16, 28, 6000))
		self.assertEqual(doc.karyo_gross_settlement, 154000)
		doc.submit()
		self.assertEqual(doc.karyo_settlement_status, "Preview")
		self.assertEqual(frappe.db.get_value("Employee", self.employee.name, "status"), "Active")

	def test_submitted_date_change_refreshes_snapshot_on_update_after_submit(self):
		doc = self.separation(); doc.submit()
		doc.karyo_leaving_date = "2026-10-04"; doc.save(); doc.reload()
		self.assertEqual(doc.karyo_annual_current_days, 14)
		self.assertEqual(str(doc.karyo_settlement_as_at), "2026-10-04")

	def test_separation_workspace_and_employee_profile_use_the_same_live_preview(self):
		from karyo.desk.record_workspace import get_workspace
		doc = self.separation()
		frappe.db.set_value("Sick Leave Bank", self.employee.name, "bank_days", 31)
		workspace = get_workspace("employee-separation", doc.name)
		preview = workspace["settlement"]
		profile = api.employee_final_settlement(self.employee.name)
		self.assertEqual(preview["sick_bank_days"], 29)
		self.assertEqual(preview["net_settlement"], profile["net_settlement"])
		self.assertEqual(next(row["value"] for row in workspace["fields"] if row["fieldname"] == "karyo_net_settlement"), preview["net_settlement"])
		self.assertNotEqual(workspace["flow"]["current"], 4)

	def test_completion_freezes_all_values_and_repeated_project_updates_do_not_recalculate(self):
		doc = self.separation(); doc.submit()
		project = frappe.get_doc("Project", doc.project)
		project.percent_complete_method = "Manual"; project.status = "Completed"; project.save()
		doc.reload(); self.assertEqual(doc.boarding_status, "Completed")
		self.assertEqual(doc.karyo_settlement_status, "Finalized")
		self.assertEqual(frappe.db.get_value("Employee", self.employee.name, "status"), "Inactive")
		before = doc.karyo_settlement_breakdown; timestamp = doc.karyo_settlement_finalized_on
		frappe.db.set_value("Sick Leave Bank", self.employee.name, "bank_days", 99)
		project.save(); doc.reload()
		self.assertEqual(doc.karyo_settlement_breakdown, before)
		self.assertEqual(doc.karyo_settlement_finalized_on, timestamp)
		result = api.preview_separation(self.employee.name, self.as_at, doc.name)
		self.assertEqual(result["settlement"]["sick_bank_days"], 28)
		doc.karyo_net_settlement = -1; doc.save(); doc.reload()
		self.assertEqual(doc.karyo_net_settlement, 141000)
		doc.boarding_status = "Pending"
		with self.assertRaises(frappe.ValidationError): doc.save()
		doc.reload()
		with self.assertRaises(frappe.ValidationError): api.preview_separation(self.employee.name, "2026-10-04", doc.name)
		doc.karyo_leaving_date = "2026-10-04"
		with self.assertRaises(frappe.ValidationError): doc.save()

	def test_completed_draft_is_preview_until_submission(self):
		doc = self.separation("Completed")
		self.assertEqual(doc.karyo_settlement_status, "Preview")
		doc.submit(); self.assertEqual(doc.karyo_settlement_status, "Finalized")

	def test_year_end_banked_sick_is_not_counted_again_as_current_year(self):
		position = leave_position_as_at(self.employee.name, "2026-12-31")
		self.assertEqual(position["sick_current_days"], 0)
		self.assertEqual(position["sick_bank_days"], 30)

	def test_invalid_date_before_service_and_wrong_separation_employee_are_rejected(self):
		with self.assertRaises(frappe.ValidationError): api.preview_separation(self.employee.name, "1999-12-31")
		doc = self.separation()
		with self.assertRaises(frappe.PermissionError): api.preview_separation(self.source.name, self.as_at, doc.name)

	def test_guest_and_employee_only_login_cannot_preview_other_employees(self):
		frappe.set_user("Guest")
		with self.assertRaises(frappe.PermissionError): api.preview_separation(self.employee.name, self.as_at)
		frappe.set_user("Administrator")
		user = "settlement-" + self.uid + "@example.test"
		frappe.get_doc({"doctype": "User", "email": user, "first_name": "Settlement test", "send_welcome_email": 0,
			"roles": [{"role": "Employee"}]}).insert(ignore_permissions=True)
		frappe.set_user(user)
		with self.assertRaises(frappe.PermissionError): api.preview_separation(self.employee.name, self.as_at)

	def test_no_record_balances_are_zero_and_no_bank_is_created(self):
		empty = frappe.copy_doc(self.employee); empty.name = "SETEMPTY-" + self.uid; empty.docstatus = 0; empty.db_insert()
		result = api.calculate(empty.name, self.as_at)
		self.assertEqual((result["sick_leave_days"], result["vacation_leave_days"], result["pb_balance"], result["loan_outstanding"]), (0, 0, 0, 0))
		self.assertFalse(frappe.db.exists("Sick Leave Bank", empty.name))
		self.assertFalse(frappe.db.exists("Vacation Leave Bank", empty.name))
		self.assertFalse(frappe.db.exists("Passage Benefit Bank", empty.name))

	def test_signed_pb_overdraw_is_retained_in_net_and_missing_cutoff_is_rejected(self):
		frappe.get_doc({"doctype": "Passage Benefit Ledger Entry", "name": frappe.generate_hash(),
			"employee": self.employee.name, "pb_bank": self.employee.name, "posting_date": "2026-09-21",
			"entry_type": "Claim", "amount": -10000, "docstatus": 1}).db_insert()
		result = api.calculate(self.employee.name, self.as_at)
		self.assertEqual(result["pb_balance"], -4000)
		self.assertEqual(result["net_settlement"], 131000)
		with self.assertRaises(frappe.ValidationError): api.preview_separation(self.employee.name, None)

	def test_audited_bank_opening_after_cutoff_is_not_included(self):
		for bank, code in [("Sick Leave Bank", "SICK02"), ("Vacation Leave Bank", "VAC01")]:
			frappe.get_doc({"doctype": "Leave Opening Balance", "name": frappe.generate_hash(),
				"employee": self.employee.name, "leave_type": self.types[code], "balance_source": bank,
				"balance_as_at_date": "2026-10-01", "balance_days": 10, "docstatus": 1}).db_insert()
			self.assertEqual(bank_balance_as_at(self.employee.name, self.as_at, bank)[0], 0)

	def test_multiple_loans_closed_after_exit_are_included_and_later_disbursement_is_excluded(self):
		frappe.db.set_value("Karyo Loan", self.active_loan, {
			"outstanding_capital": 8000, "outstanding_interest": 1000, "outstanding_insurance": 500,
		})
		amount, loans = api._loan_position_as_at(self.employee.name, frappe.utils.getdate(self.as_at))
		self.assertEqual(amount, 13000)
		self.assertEqual(sorted(row["outstanding"] for row in loans), [2000, 11000])

	def test_previous_year_bank_posting_does_not_hide_current_year_bank_usage(self):
		frappe.get_doc({"doctype": "Sick Leave Bank Posting", "name": "SET-SICK-PRIOR-" + self.uid,
			"employee": self.employee.name, "year": 2025, "docstatus": 1,
			"opening_bank_days": 20, "closing_bank_days": 30}).db_insert()
		self.assertEqual(bank_balance_as_at(self.employee.name, self.as_at, "Sick Leave Bank")[0], 28)

	def test_salary_uses_approved_appointment_at_exit_not_later_current_salary(self):
		first = fixtures.TestSalaryScales.appointment(self, effective_to="2026-09-30").insert()
		first.submit()
		later = fixtures.TestSalaryScales.appointment(self, effective_from="2026-10-01", salary_point="2").insert()
		later.submit()
		self.assertEqual(api.calculate(self.employee.name, self.as_at)["basic_salary"], 16785)
		self.assertEqual(api.calculate(self.employee.name, "2026-10-04")["basic_salary"], 17045)

	def test_carry_forward_consumption_and_expiry_use_cutoff_not_allocation_end(self):
		allocation = frappe.db.get_value("Leave Allocation", {"employee": self.employee.name, "leave_type": self.types["ANN"], "docstatus": 1}, "name")
		frappe.get_doc({"doctype": "Leave Ledger Entry", "name": frappe.generate_hash(), "docstatus": 1,
			"employee": self.employee.name, "leave_type": self.types["ANN"], "transaction_type": "Leave Allocation",
			"transaction_name": allocation, "leaves": 5, "is_carry_forward": 1, "is_expired": 0,
			"from_date": "2026-01-01", "to_date": self.as_at}).db_insert()
		self.assertEqual(current_leave_as_at(self.employee.name, "2026-09-05", "ANN")[0], 26)
		self.assertEqual(current_leave_as_at(self.employee.name, self.as_at, "ANN")[0], 22)
		self.assertEqual(current_leave_as_at(self.employee.name, "2026-10-04", "ANN")[0], 18)

	def test_all_manual_expiries_and_lateness_through_cutoff_reduce_leave(self):
		allocation = frappe.db.get_value("Leave Allocation", {"employee": self.employee.name, "leave_type": self.types["ANN"], "docstatus": 1}, "name")
		for date, amount in [("2026-09-20", -1), (self.as_at, -2), ("2026-10-05", -10)]:
			frappe.get_doc({"doctype": "Leave Ledger Entry", "name": frappe.generate_hash(), "docstatus": 1,
				"employee": self.employee.name, "leave_type": self.types["ANN"], "transaction_type": "Leave Allocation",
				"transaction_name": allocation, "leaves": amount, "is_expired": 1, "is_carry_forward": 0,
				"from_date": date, "to_date": date}).db_insert()
		frappe.get_doc({"doctype": "Leave Ledger Entry", "name": frappe.generate_hash(), "docstatus": 1,
			"employee": self.employee.name, "leave_type": self.types["ANN"], "transaction_type": "Lateness Leave Deduction",
			"transaction_name": "SET-LATE-"+self.uid, "leaves": -0.5,
			"from_date": "2026-09-25", "to_date": "2026-09-25"}).db_insert()
		self.assertEqual(current_leave_as_at(self.employee.name, self.as_at, "ANN")[0], 13.5)
