frappe.query_reports["Outstanding Loan Balances"] = {
	filters: [
		{ fieldname: "as_at_date", label: __("As At Date"), fieldtype: "Date", reqd: 1, default: frappe.datetime.get_today() },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "include_settled", label: __("Include Settled"), fieldtype: "Check", default: 0 },
	],
};
