"""Regression coverage for the September 2026 attendance/leave/EDF fixes."""

import unittest

import frappe

from karyo.desk.hr_surface import actions, delete_pending_leave_application
from karyo.desk.payroll_drawer import record_form
from karyo.desk.payroll_screens import screen_data


class TestRequestedAttendanceLeaveEDFFixes(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("requested_attendance_leave_edf_fixes")

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="requested_attendance_leave_edf_fixes")
		frappe.set_user(self.user)

	def test_leave_actions_are_available_only_while_pending(self):
		pending = frappe.db.get_value(
			"Leave Application", {"docstatus": 0, "status": "Open"}, "name"
		)
		approved = frappe.db.get_value(
			"Leave Application", {"status": "Approved"}, "name"
		)
		cancelled = frappe.db.get_value(
			"Leave Application", {"status": "Cancelled"}, "name"
		)
		self.assertTrue(pending and approved and cancelled)
		states = actions("Leave Application", [pending, approved, cancelled])
		self.assertTrue(states[pending]["edit"] and states[pending]["delete"])
		self.assertFalse(states[approved]["edit"] or states[approved]["delete"])
		self.assertFalse(states[cancelled]["edit"] or states[cancelled]["delete"])

	def test_deleting_pending_leave_does_not_touch_ledger(self):
		name = frappe.db.get_value(
			"Leave Application", {"docstatus": 0, "status": "Open"}, "name"
		)
		self.assertTrue(name)
		before = frappe.db.count("Leave Ledger Entry", {
			"transaction_type": "Leave Application", "transaction_name": name,
		})
		self.assertEqual(before, 0)
		delete_pending_leave_application(name)
		self.assertFalse(frappe.db.exists("Leave Application", name))
		self.assertEqual(frappe.db.count("Leave Ledger Entry", {
			"transaction_type": "Leave Application", "transaction_name": name,
		}), 0)

	def test_edf_relief_lists_are_loaded_and_creatable(self):
		for tab, doctype in (
			("relief-categories", "Employee Tax Exemption Category"),
			("relief-subcategories", "Employee Tax Exemption Sub Category"),
		):
			data = screen_data("paye", {"tab": tab})
			block = next(row for row in data["tabs"] if row["key"] == tab)
			self.assertEqual(block["doctype"], doctype)
			self.assertTrue(block["loaded"] and block["can_create"])
			self.assertTrue(block["rows"])

	def test_operation_code_master_and_mapping_are_maintainable(self):
		data = screen_data("opcodes", {"master": "GSPB"})
		self.assertTrue(data["master"]["can_create"])
		self.assertEqual(len(data["detail"]["rows"]), 24)
		form = record_form("opcodes", "Payroll Operation Code", is_admin=True)
		fields = {field["fieldname"]: field for section in form["sections"] for field in section["fields"]}
		for fieldname in ("operation_code", "description", "operation_category"):
			self.assertFalse(fields[fieldname]["read_only"])

	def test_reviewer_segregation_is_explained_before_approval(self):
		batch = frappe.db.get_value(
			"Exceptional Payroll Batch", {"status": "Reviewed", "reviewed_by": "mbc.admin@mbc.mu"}, "name"
		)
		self.assertTrue(batch)
		frappe.set_user("mbc.admin@mbc.mu")
		data = screen_data("separate", {})
		row = next(item for item in data["batches"] if item["name"] == batch)
		approve = next(action for action in row["actions"] if action["key"] == "approve")
		self.assertFalse(approve["available"])
		self.assertIn("different user", approve["blocked_reason"])
		frappe.set_user("mbc.approver@mbc.mu")
		data = screen_data("separate", {})
		row = next(item for item in data["batches"] if item["name"] == batch)
		approve = next(action for action in row["actions"] if action["key"] == "approve")
		self.assertTrue(approve["available"])


if __name__ == "__main__":
	unittest.main()
