"""Effective-dated Mauritius PAYE and employee EDF/IET masters (PAY-050/051)."""

import json

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Payroll PAYE Band",
		istable=1,
		fields=[
			f("upper_chargeable_income", "Currency", "Upper Chargeable Income", in_list_view=1),
			f("is_open_ended", "Check", "No Upper Limit", default="0", in_list_view=1),
			f("tax_rate", "Percent", "Tax Rate", reqd=1, in_list_view=1),
		],
	)
	make_doctype(
		"Payroll PAYE Year",
		autoname="format:{tax_year}-{version}",
		title_field="tax_year",
		fields=[
			f("identity_sb", "Section Break", "PAYE Year"),
			f("tax_year", "Data", "Income Year", reqd=1, in_list_view=1),
			f("version", "Data", "Version", reqd=1, default="1", in_list_view=1),
			f("company", "Link", "Company", options="Company", in_standard_filter=1),
				f("identity_cb", "Column Break"),
				f("periods_per_year", "Int", "PAYE Periods", default="13", reqd=1),
				f("currency_precision", "Int", "Tax Rounding Precision", default="0", reqd=1),
				f(
					"current_paye_rounding",
					"Select",
					"Current PAYE Rounding",
					options="Round Down\nRound Half Up",
					default="Round Down",
					reqd=1,
				),
				f("no_edf_rate", "Percent", "No-EDF Rate", default="15", reqd=1),
			f("no_edf_optional_rate", "Percent", "No-EDF Optional Rate", default="20"),
			f("threshold_sb", "Section Break", "Thresholds and Reliefs"),
			f("monthly_no_paye_threshold", "Currency", "Monthly No-PAYE Threshold"),
			f("dependent_1_relief", "Currency", "One Dependent"),
			f("dependent_2_relief", "Currency", "Two Dependents"),
			f("threshold_cb", "Column Break"),
			f("dependent_3_relief", "Currency", "Three Dependents"),
			f("dependent_4_plus_relief", "Currency", "Four or More Dependents"),
			f("bands_sb", "Section Break", "Progressive Tax Bands"),
			f("bands", "Table", "PAYE Bands", options="Payroll PAYE Band", reqd=1),
			f("validity_sb", "Section Break", "Validity and Governance"),
			f("effective_from", "Date", "Effective From", reqd=1, in_list_view=1),
			f("effective_to", "Date", "Effective To"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("configuration_version", "Link", "Configuration Version", options="Payroll Configuration Version", reqd=1),
			f("source_reference", "Data", "Source Reference", reqd=1),
		],
	)
	make_doctype(
		"Employee Tax Declaration",
		autoname="format:{employee}-{tax_year}-{effective_from}",
		title_field="employee",
		fields=[
			f("identity_sb", "Section Break", "Employee Declaration"),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("tax_year", "Link", "PAYE Year", options="Payroll PAYE Year", reqd=1, in_list_view=1),
			f("company", "Link", "Company", options="Company", read_only=1),
			f("identity_cb", "Column Break"),
			f("declaration_status", "Select", "EDF Status", options="Submitted\nNo EDF", default="Submitted", reqd=1, in_list_view=1),
			f("no_edf_rate_option", "Select", "No-EDF Rate Option", options="15\n20", depends_on="eval:doc.declaration_status=='No EDF'"),
			f("number_of_dependents", "Int", "Number of Dependents", default="0"),
			f("amounts_sb", "Section Break", "Reliefs, Deductions and IET"),
			f("annual_reliefs", "Currency", "Approved Other Reliefs / Deductions"),
			f("annual_iet", "Currency", "Calculated Dependent Deduction", read_only=1),
			f("total_annual_edf_amount", "Currency", "Total Annual EDF / IET", read_only=1),
			f("imported_edf_amount", "Currency", "Imported Legacy EDF Amount", read_only=1),
			f("prior_employment_emoluments", "Currency", "Prior Employment Emoluments"),
			f("amounts_cb", "Column Break"),
			f("prior_employment_paye", "Currency", "Prior Employment PAYE"),
			f("effective_from", "Date", "Effective From", reqd=1, in_list_view=1),
			f("effective_to", "Date", "Effective To"),
			f("source_reference", "Data", "Source / EDF Reference"),
			f("source_file", "Attach", "Source File"),
			f("source_opening_record", "Link", "Source EDF/PAYE Opening", options="EDF PAYE Opening", read_only=1),
		],
	)


def seed_received_2025_26_reference():
	"""Load the received MRA values as Draft, never as production-approved data."""
	config_name = frappe.db.get_value(
		"Payroll Configuration Version",
		{"config_key": "MRA-PAYE-2025-26", "version": "RECEIVED-1"},
		"name",
	)
	if not config_name:
		config_name = frappe.get_doc(
			{
				"doctype": "Payroll Configuration Version",
				"config_key": "MRA-PAYE-2025-26",
				"configuration_type": "PAYE",
				"version": "RECEIVED-1",
				"configuration_status": "Draft",
				"is_production_eligible": 0,
				"effective_from": "2025-07-01",
				"effective_to": "2026-06-30",
				"source_reference": "MRA Guide on PAYE, December 2025; client PAYE Computation.xlsx",
				"configuration_json": json.dumps(
					{
						"income_year": "2025/2026",
						"periods": 13,
						"status": "Received reference awaiting payroll-owner activation",
					},
					indent=2,
				),
				"notes": "Received statutory source; validate and approve before production activation.",
			}
		).insert(ignore_permissions=True).name
	# Statutory rules are global unless a company-specific approved version is
	# deliberately created. Clear any session User Default applied on insert.
	frappe.db.set_value("Payroll Configuration Version", config_name, "company", None)
	if frappe.db.exists("Payroll PAYE Year", {"tax_year": "2025/2026", "version": "RECEIVED-1"}):
		frappe.db.set_value(
			"Payroll PAYE Year",
			"2025/2026-RECEIVED-1",
			{"company": None, "current_paye_rounding": "Round Half Up"},
		)
		return
	frappe.get_doc(
		{
			"doctype": "Payroll PAYE Year",
			"tax_year": "2025/2026",
			"version": "RECEIVED-1",
			"periods_per_year": 13,
			"currency_precision": 0,
			"no_edf_rate": 15,
			"no_edf_optional_rate": 20,
			"monthly_no_paye_threshold": 38462,
			"current_paye_rounding": "Round Half Up",
			"dependent_1_relief": 110000,
			"dependent_2_relief": 190000,
			"dependent_3_relief": 275000,
			"dependent_4_plus_relief": 355000,
			"effective_from": "2025-07-01",
			"effective_to": "2026-06-30",
			"is_active": 1,
			"configuration_version": config_name,
			"source_reference": "MRA Guide on PAYE, December 2025; client PAYE Computation.xlsx",
			"bands": [
				{"upper_chargeable_income": 500000, "tax_rate": 0},
				{"upper_chargeable_income": 1000000, "tax_rate": 10},
				{"is_open_ended": 1, "tax_rate": 20},
			],
		}
	).insert(ignore_permissions=True)
	frappe.db.set_value("Payroll PAYE Year", "2025/2026-RECEIVED-1", "company", None)


def setup():
	print("Karyo payroll PAYE/EDF setup:")
	create_doctypes()
	seed_received_2025_26_reference()
	frappe.db.commit()
	print("Done (effective PAYE years, progressive bands, employee EDF/IET, and received draft reference).")
