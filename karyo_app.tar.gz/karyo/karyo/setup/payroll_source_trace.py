"""Cross-source Additional Salary traceability and reconciliation (PAY-034)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


CATEGORY_OPTIONS = (
	"\nLoan Deduction\nEOY Bonus\nPassage Benefit\nLeave Encashment\nOvertime\nAllowance\nRecurring PDB\n"
	"Once-off PDB\nExceptional Payroll\nPRB Payroll\nBulk Payroll\nOther"
)


def create_doctype():
	make_doctype(
		"Payroll Source Trace",
		autoname="hash",
		fields=[
			f("source_key", "Data", "Source Key", reqd=1, unique=1, read_only=1),
			f("category", "Data", "Category", reqd=1, in_list_view=1, in_standard_filter=1),
			f("source_doctype", "Link", "Source Type", options="DocType", reqd=1, in_list_view=1),
			f("source_name", "Dynamic Link", "Source", options="source_doctype", reqd=1, in_list_view=1),
			f("output_cb", "Column Break"),
			f("additional_salary", "Link", "Additional Salary", options="Additional Salary", reqd=1),
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle"),
			f("employee", "Link", "Employee", options="Employee", reqd=1),
			f("details_sb", "Section Break", "Payroll Mapping and Calculation"),
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1),
			f("salary_component", "Link", "Salary Component", options="Salary Component", reqd=1),
			f("amount", "Currency", "Amount", reqd=1, in_list_view=1),
			f("payment_date", "Date", "Payment Date"),
			f("status", "Select", "Status", options="Posted\nReversed", default="Posted", reqd=1),
			f("calculation_trace", "Code", "Calculation Trace", options="JSON", reqd=1),
			f("audit_cb", "Column Break"),
			f("posted_on", "Datetime", "Posted On", read_only=1),
			f("reversed_on", "Datetime", "Reversed On", read_only=1),
		],
	)


def add_additional_salary_fields():
	create_custom_fields(
		{
			"Additional Salary": [
				{
					"fieldname": "karyo_transaction_category",
					"fieldtype": "Select",
					"label": "MBC Transaction Category",
					"options": CATEGORY_OPTIONS,
					"insert_after": "ref_docname",
					"read_only": 1,
				},
				{
					"fieldname": "karyo_pdb_code",
					"fieldtype": "Link",
					"label": "Payroll PDB Code",
					"options": "Payroll PDB Code",
					"insert_after": "karyo_transaction_category",
					"read_only": 1,
				},
				{
					"fieldname": "karyo_source_key",
					"fieldtype": "Data",
					"label": "Payroll Source Key",
					"insert_after": "karyo_pdb_code",
					"read_only": 1,
				},
				{
					"fieldname": "karyo_source_trace",
					"fieldtype": "Link",
					"label": "Payroll Source Trace",
					"options": "Payroll Source Trace",
					"insert_after": "karyo_source_key",
					"read_only": 1,
				},
				{
					"fieldname": "karyo_payroll_cycle",
					"fieldtype": "Link",
					"label": "Payroll Cycle",
					"options": "Payroll Cycle",
					"insert_after": "karyo_source_trace",
					"read_only": 1,
				},
			]
		},
		ignore_validate=True,
	)
	field = frappe.db.get_value(
		"Custom Field", {"dt": "Additional Salary", "fieldname": "karyo_transaction_category"}, "name"
	)
	if field:
		frappe.db.set_value("Custom Field", field, "options", CATEGORY_OPTIONS, update_modified=False)


def add_permissions():
	meta = frappe.get_doc("DocType", "Payroll Source Trace")
	matrix = {
		"Payroll Processor": {"read": 1, "report": 1},
		"Payroll Reviewer": {"read": 1, "report": 1},
		"Payroll Approver": {"read": 1, "report": 1},
		"Payroll Finance": {"read": 1, "report": 1, "export": 1},
		"Payroll Auditor": {"read": 1, "report": 1, "export": 1},
	}
	for role, values in matrix.items():
		row = next((permission for permission in meta.permissions if permission.role == role), None)
		if not row:
			row = meta.append("permissions", {"role": role})
		for fieldname, value in values.items():
			row.set(fieldname, value)
	meta.save(ignore_permissions=True)


def setup():
	print("Karyo payroll source trace setup:")
	create_doctype()
	add_additional_salary_fields()
	add_permissions()
	frappe.db.commit()
	print("Done (custom payroll source mapping, deduplication, and trace records created).")
