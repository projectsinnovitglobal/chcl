import unittest
from uuid import uuid4
import frappe
from karyo.desk.payroll_management import screen_data, payslip_generation_context
from karyo.desk.payroll_screens import payslip_period_options
from karyo.desk.payroll_drawer import record_form, record_save

class TestPaydayMasterFlow(unittest.TestCase):
    def setUp(self):
        self.user=frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('payday_master_test')
    def tearDown(self):
        frappe.db.rollback(save_point='payday_master_test')
        frappe.set_user(self.user)
    def test_all_screens_use_payday_master_with_actual_status(self):
        options=payslip_period_options()
        days=frappe.get_all('Payroll Pay Day',fields=['name','status'])
        self.assertEqual({o['pay_day']:o['status'] for o in options},{d.name:d.status for d in days})
        for option in options:
            for screen in ('query','payslipgen','process'):
                data=screen_data(screen,pay_day=option['key'],payroll_period=option['key'])
                self.assertEqual(data['cycles'],options)
                self.assertEqual(data['selected_cycle'],option['key'])
                if screen=='process':
                    self.assertTrue(all(d.name==option['pay_day'] for d in data['pay_days']))
    def test_major_minor_runs_are_scoped_and_cannot_be_substituted(self):
        major=payslip_generation_context('payday::MBC-2026-07-MAJOR')
        minor=payslip_generation_context('payday::MBC-2026-07-MINOR')
        self.assertEqual(major['selected'].payroll_type,'Major')
        self.assertEqual(minor['selected'].payroll_type,'Minor')
        with self.assertRaises(frappe.ValidationError):
            payslip_generation_context('payday::MBC-2026-07-MAJOR',minor['selected'].name)
        slip='payday-slip-'+uuid4().hex
        frappe.get_doc({'doctype':'Salary Slip','name':slip,'employee':'MBC/HR/00001',
            'company':major['company'],'start_date':major['selected'].start_date,
            'end_date':major['selected'].end_date,'karyo_payroll_cycle':major['selected'].name,
            'docstatus':0,'gross_pay':100,'net_pay':100}).db_insert()
        for screen in ('query','payslipgen'):
            m=screen_data(screen,pay_day='payday::MBC-2026-07-MAJOR',employee='MBC/HR/00001')
            n=screen_data(screen,pay_day='payday::MBC-2026-07-MINOR',employee='MBC/HR/00001')
            self.assertIn(slip,[r.name for r in m['list']['rows']])
            self.assertNotIn(slip,[r.name for r in n['list']['rows']])
    def test_status_edit_is_writable_and_native_guards_apply(self):
        form=record_form('paydays','Payroll Pay Day','MBC-2026-09-MAJOR',is_admin=True)
        status=next(f for section in form['sections'] for f in section['fields'] if f['fieldname']=='status')
        self.assertFalse(status['read_only'])
        self.assertEqual(status['options'],['Planned','Active','Processing','Closed','Cancelled'])
        with self.assertRaises(frappe.ValidationError):
            record_save('paydays','Payroll Pay Day',{'status':'Active'},'MBC-2026-09-MAJOR',is_admin=True)
        with self.assertRaises(frappe.ValidationError):
            record_save('paydays','Payroll Pay Day',{'status':'Closed'},'MBC-2026-07-MAJOR',is_admin=True)
        with self.assertRaises(frappe.ValidationError):
            record_save('paydays','Payroll Pay Day',{'status':'Processing'},'MBC-2026-07-MAJOR',is_admin=True)
        record_save('paydays','Payroll Pay Day',{'status':'Cancelled'},'MBC-2026-09-MAJOR',is_admin=True)
        self.assertEqual(frappe.db.get_value('Payroll Pay Day','MBC-2026-09-MAJOR','status'),'Cancelled')
        self.assertEqual(next(o['status'] for o in payslip_period_options() if o['pay_day']=='MBC-2026-09-MAJOR'),'Cancelled')
    def test_legacy_calendar_active_flag_does_not_block_new_payday(self):
        doc=frappe.copy_doc(frappe.get_doc('Payroll Pay Day','MBC-2026-09-MAJOR'))
        doc.pay_day_code='TEST-'+uuid4().hex.upper()
        doc.payment_date='2026-09-26'
        doc.pay_day_master=None
        doc.status='Planned'
        frappe.db.set_value('Payroll Period',doc.payroll_period,'is_active',0)
        doc.insert()
        self.assertEqual(doc.status,'Planned')
