frappe.pages["attendance-overview"].on_page_load = function (wrapper) {
	karyo.overview.render(wrapper, "attendance-overview", {
		title: __("Attendance & Shifts"),
		subtitle: __("Daily attendance, check-ins and shifts"),
		cycle: false,
		actions: [
			{ label: __("Mark Attendance"), primary: true, onclick: () => frappe.set_route("employee-attendance-tool") },
			{ label: __("New Attendance Correction"), onclick: () => frappe.new_doc("Attendance Request") },
			{ label: __("Assign Overtime / Night Duty / Excess Hours"), onclick: () => karyo.additional_hours.launch() },
			{ label: __("Overtime Register"), onclick: () => frappe.set_route("overtime-register") },
			{ label: __("Work Patterns"), onclick: () => frappe.set_route("List", "Employee Work Pattern") },
			{ label: __("New Shift Assignment"), onclick: () => frappe.new_doc("Shift Assignment") },
		],
	});
};
