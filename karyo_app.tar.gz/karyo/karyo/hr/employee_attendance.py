"""Own attendance workspace, including check-ins awaiting processing."""
import frappe
from frappe import _
from frappe.utils import cint, flt, get_datetime, getdate, get_first_day, get_last_day, now_datetime, today
from karyo.hr.clocking import _own_employee, attendance_clock_view

STATUSES = ("Present", "Absent", "On Leave", "Half Day", "Work From Home", "Clocked In", "Clocked Out")
PRESENT_DAY_WEIGHTS = {"Present": 1, "Work From Home": 1, "Half Day": 0.5}


def _month_bounds(month):
	try:
		first = get_first_day(getdate((month or today()[:7]) + "-01"))
	except (ValueError, TypeError):
		frappe.throw(_("Select a valid attendance month."))
	return first, get_last_day(first)


def attendance_period_for_company(company, month=None, pay_day_master=None):
	"""Resolve a payment month from the recurring Pay Day master.

	A day-of-month of 25 produces a window from the 26th of the previous
	month through the 25th of the selected payment month.
	"""
	month_start, month_end = _month_bounds(month)
	master = None
	if pay_day_master:
		master = frappe.db.get_value(
			"Pay Day", pay_day_master,
			["name", "pay_day_name", "company", "day_of_month", "is_active"], as_dict=True,
		)
		if master and (master.company != company or not master.is_active):
			master = None
	if not master and company:
		masters = frappe.get_all(
			"Pay Day",
			filters={"company": company, "payroll_type": "Major", "is_active": 1},
			fields=["name", "pay_day_name", "company", "payroll_group", "day_of_month", "is_active"],
			order_by="modified desc",
		)
		master = next((row for row in masters if not row.payroll_group), masters[0] if masters else None)
	if not master:
		return frappe._dict(
			start_date=month_start, end_date=month_end, payment_date=None,
			pay_day_master=None, label=month_start.strftime("%B %Y"), source="Calendar Month",
		)
	from karyo.setup.payroll_calendar import pay_window_for_month
	start_date, end_date, payment_date = pay_window_for_month(month_start, master.day_of_month)
	return frappe._dict(
		start_date=start_date, end_date=end_date, payment_date=payment_date,
		pay_day_master=master.name, label=master.pay_day_name, source="Pay Day Master",
	)


@frappe.whitelist()
def get_company_attendance_period(company, month=None):
	if not frappe.has_permission("Attendance", "read"):
		frappe.throw(_("You do not have permission to view attendance."), frappe.PermissionError)
	return attendance_period_for_company(company, month)


def attendance_summary(employee, from_date, to_date):
	"""Return submitted attendance counts and present-day equivalents."""
	rows = frappe.get_all(
		"Attendance",
		filters={
			"employee": employee,
			"docstatus": 1,
			"attendance_date": ("between", [getdate(from_date), getdate(to_date)]),
		},
		fields=["status"],
		limit_page_length=0,
	)
	summary = {}
	for row in rows:
		summary[row.status] = summary.get(row.status, 0) + 1
	return {
		"summary": summary,
		"present_days": flt(sum(PRESENT_DAY_WEIGHTS.get(row.status, 0) for row in rows)),
		"total": len(rows),
	}


@frappe.whitelist()
def get_attendance(month=None, status=None, start=0):
	person = _own_employee(required=True)
	identity = frappe.db.get_value(
		"Employee", person.name,
		["employee_name", "employee_number", "department", "company", "karyo_pay_day"], as_dict=True,
	) or frappe._dict()
	period = attendance_period_for_company(identity.company, month, identity.get("karyo_pay_day"))
	first, last = period.start_date, period.end_date
	if status and status not in STATUSES:
		frappe.throw(_("Select a valid attendance status."))
	# Submitted Attendance is authoritative. Draft processing rows must not leak
	# into ESS; unprocessed punches are added separately as live clock rows.
	filters = {"employee": person.name, "attendance_date": ("between", [first, last]), "docstatus": 1}
	fields = [
		"name", "employee", "employee_name", "attendance_date", "status", "shift", "docstatus",
		"attendance_request", "karyo_is_corrected", "karyo_correction_request", "karyo_corrected_on",
		"karyo_detected_late_minutes", "karyo_detected_late_entry_minutes", "karyo_detected_early_exit_minutes",
		"karyo_late_entry_grace_minutes", "karyo_early_exit_grace_minutes", "karyo_grace_source", "karyo_lateness_status",
	]
	rows = frappe.get_list("Attendance", filters=filters,
		fields=fields,
		order_by="attendance_date desc, name desc", limit_page_length=0)
	clock = attendance_clock_view([row.name for row in rows], filters=[
		["Attendance", "attendance_date", ">=", str(first)], ["Attendance", "attendance_date", "<=", str(last)]],
		from_date=first, to_date=last)
	by_name = {row.name: row for row in rows}
	for row in clock["live_rows"]:
		by_name.setdefault(row.name, row)
	saved_names = [row.name for row in rows]
	if saved_names:
		requests = frappe.db.sql(
			"""select karyo_attendance, karyo_request_status, name
			from `tabAttendance Request`
			where karyo_attendance in %(names)s and docstatus < 2
			order by creation desc""",
			{"names": tuple(saved_names)},
			as_dict=True,
		)
		for request in requests:
			row = by_name.get(request.karyo_attendance)
			if row and not row.get("correction_status"):
				row.correction_status = request.karyo_request_status
				row.correction_request = request.name
	result=[]
	for row in by_name.values():
		row.update(clock["records"].get(row.name, {}))
		# Status is the saved HR decision. Clock timing (Late / On-time) already
		# has its own column and must not replace Present in the Status column.
		row.status = row.get("attendance_status") or row.status
		if not status or row.status == status:
			result.append(row)
	result.sort(key=lambda row:(str(row.attendance_date),row.name),reverse=True)
	requests = frappe.get_all(
		"Attendance Request",
		filters={
			"employee": person.name,
			"from_date": ("<=", last),
			"to_date": (">=", first),
			"docstatus": ("<", 2),
		},
		fields=[
			"name", "from_date", "to_date", "reason", "explanation",
			"karyo_requested_status", "karyo_request_status", "creation",
		],
		order_by="creation desc",
		limit_page_length=100,
	)
	start=max(0,frappe.utils.cint(start))
	return {"employee":person.name,"employee_code":identity.employee_number or person.name,
		"employee_name":identity.employee_name or person.employee_name,
		"department":identity.department,"company":identity.company,"month":month or today()[:7],
		"rows":result[start:start+25],"total":len(result),"has_more":len(result)>start+25,
		"start":start,"requests":requests,"period":period}


@frappe.whitelist()
def get_overtime_bonuses(month=None):
	"""Return only the signed-in employee's governed additional-time/pay items.

	The employee cannot supply an employee id.  This makes the page safe for ESS
	while retaining records that calculated to zero, so policy exclusions remain
	visible and explainable instead of silently disappearing.
	"""
	person = _own_employee(required=True)
	identity = frappe.db.get_value(
		"Employee", person.name,
		["employee_name", "employee_number", "department", "company", "karyo_pay_day"], as_dict=True,
	) or frappe._dict()
	period = attendance_period_for_company(identity.company, month, identity.get("karyo_pay_day"))
	first, last = period.start_date, period.end_date

	time_rows = frappe.db.sql(
		"""select a.name, a.claim_type, a.planned_start, a.planned_end, a.planned_hours,
			a.actual_start, a.actual_end, a.actual_hours, a.approved_hours,
			a.eligibility_reason, a.authorization_status, a.payroll_approval_status,
			a.calculation_explanation, a.hourly_rate_calculation, a.hourly_rate,
			a.overtime_period, a.docstatus, a.shift_type, a.shift_code,
			a.roster_schedule, a.roster_assignment, a.roster_status,
			r.name as payroll_run, r.posting_status, c.component_code,
			c.salary_component, c.amount as payroll_amount, c.additional_salary
		from `tabPRB Overtime Authorization` a
		left join `tabPRB Payroll Input` i
			on i.source_doctype='PRB Overtime Authorization' and i.source_name=a.name
		left join `tabPRB Payroll Run` r
			on r.name=i.parent and r.docstatus<2
		left join `tabPRB Payroll Component` c
			on c.parent=r.name and c.input_row=i.name
		where a.employee=%(employee)s and a.docstatus<2
		and (
			(a.actual_start is not null and date(a.actual_start) between %(first)s and %(last)s)
			or (a.actual_start is null and date(a.planned_start) between %(first)s and %(last)s)
		)
		order by coalesce(a.actual_start, a.planned_start) desc, a.name desc""",
		{"employee": person.name, "first": first, "last": last}, as_dict=True,
	)

	bonus_rows = frappe.db.sql(
		"""select r.name as payroll_run, r.run_purpose, r.calculation_date,
			r.payroll_cycle, r.docstatus, r.posting_status,
			c.component_code, c.description, c.amount, c.rule_ref, c.additional_salary
		from `tabPRB Payroll Run` r
		inner join `tabPRB Payroll Component` c on c.parent=r.name
		left join `tabPayroll Cycle` cycle on cycle.name=r.payroll_cycle
		where r.employee=%(employee)s and r.docstatus<2
		and c.component_code in (
			'ATTENDANCE_BONUS', 'INCENTIVE_ATTENDANCE', 'INCENTIVE_PRESENCE'
		)
		and (
			r.calculation_date between %(first)s and %(last)s
			or (cycle.start_date<=%(last)s and cycle.end_date>=%(first)s)
		)
		order by r.calculation_date desc, r.name desc, c.idx asc""",
		{"employee": person.name, "first": first, "last": last}, as_dict=True,
	)

	higher_duties = frappe.get_all(
		"PRB Higher Duty Assignment",
		filters={
			"employee": person.name,
			"docstatus": ("<", 2),
			"from_date": ("<=", last),
			"to_date": (">=", first),
		},
		fields=[
			"name", "assignment_type", "from_date", "to_date", "assignment_days",
			"substantive_post", "higher_post", "higher_grade_scale", "docstatus",
		],
		order_by="from_date desc, name desc",
		limit_page_length=100,
	)

	assigned_by_type = {"Overtime": 0.0, "Night Duty": 0.0, "Excess Hours": 0.0}
	approved_by_type = {"Overtime": 0.0, "Night Duty": 0.0, "Excess Hours": 0.0}
	for row in time_rows:
		if row.docstatus == 1:
			assigned_by_type[row.claim_type] = assigned_by_type.get(row.claim_type, 0.0) + float(row.planned_hours or 0)
		approved_by_type[row.claim_type] = approved_by_type.get(row.claim_type, 0.0) + float(row.approved_hours or 0)

	return {
		"employee": person.name,
		"employee_name": identity.employee_name or person.employee_name,
		"employee_code": identity.employee_number or person.name,
		"department": identity.department,
		"company": identity.company,
		"month": month or today()[:7],
		"from_date": first,
		"to_date": last,
		"period": period,
		"time_rows": time_rows,
		"bonus_rows": bonus_rows,
		"higher_duties": higher_duties,
		"summary": {
			"assigned_overtime_hours": assigned_by_type.get("Overtime", 0.0),
			"assigned_night_duty_hours": assigned_by_type.get("Night Duty", 0.0),
			"assigned_extra_hours": assigned_by_type.get("Excess Hours", 0.0),
			"overtime_hours": approved_by_type.get("Overtime", 0.0),
			"night_duty_hours": approved_by_type.get("Night Duty", 0.0),
			"extra_hours": approved_by_type.get("Excess Hours", 0.0),
			"bonus_total": sum(float(row.amount or 0) for row in bonus_rows),
		},
	}


@frappe.whitelist(methods=["POST"])
def submit_overtime_claim(values):
	"""Submit the signed-in employee's own overtime claim for payroll approval.

	The claim may complete actuals on an existing submitted authorisation, or
	create a new self-service claim when no prior assignment exists. Payability is
	still decided by the PRB overtime rules and the payroll approval gate.
	"""
	person = _own_employee(required=True)
	values = frappe.parse_json(values or "{}")
	claim_type = str(values.get("claim_type") or "Overtime").strip()
	if claim_type not in {"Overtime", "Night Duty", "Excess Hours"}:
		frappe.throw(_("Choose Overtime, Night Duty or Excess Hours."))
	actual_start = get_datetime(values.get("actual_start")) if values.get("actual_start") else None
	actual_end = get_datetime(values.get("actual_end")) if values.get("actual_end") else None
	if not actual_start or not actual_end:
		frappe.throw(_("Enter Actual Start and Actual End for the overtime claim."))
	if actual_end <= actual_start:
		frappe.throw(_("Actual End must be after Actual Start."))
	if actual_end > now_datetime():
		frappe.throw(_("Overtime claims can only be submitted after the work has been completed."))
	reason = str(values.get("reason") or "").strip()
	if not reason:
		frappe.throw(_("Enter the claim reason or authority reference."))
	authorization_name = str(values.get("authorization") or "").strip()
	common = {
		"actual_start": actual_start,
		"actual_end": actual_end,
		"claimed_hours": flt(values.get("claimed_hours") or 0),
		"total_actual_hours": flt(values.get("total_actual_hours") or 0),
		"deemed_worked_hours": flt(values.get("deemed_worked_hours") or 0),
		"deemed_hours_reference": values.get("deemed_hours_reference"),
		"days_worked": cint(values.get("days_worked") or 0),
		"lying_in_hours": flt(values.get("lying_in_hours") or 0),
		"equivalent_time_off_unavailable": cint(values.get("equivalent_time_off_unavailable") or 0),
		"urgent_unpostponable": cint(values.get("urgent_unpostponable") or 0),
		"hourly_paid": cint(values.get("hourly_paid") or 0),
		"excess_hours_basis": values.get("excess_hours_basis") or "Week",
	}
	if claim_type == "Overtime" and flt(common["total_actual_hours"]) <= 0:
		frappe.throw(_("Enter the total actual hours for the covered week or cycle."))
	if common["claimed_hours"] <= 0:
		common["claimed_hours"] = flt((actual_end - actual_start).total_seconds() / 3600, 6)
	if authorization_name:
		doc = frappe.get_doc("PRB Overtime Authorization", authorization_name)
		if doc.employee != person.name:
			frappe.throw(_("You can only claim overtime for your own employee record."), frappe.PermissionError)
		if doc.docstatus != 1:
			frappe.throw(_("Only submitted overtime authorisations can receive a claim."))
		if doc.get("payroll_approval_status") in {"Approved", "Rejected"}:
			frappe.throw(_("This overtime record already has a payroll decision."))
		if frappe.db.exists("PRB Payroll Input", {"source_doctype": "PRB Overtime Authorization", "source_name": doc.name}):
			frappe.throw(_("This overtime record is already linked to payroll."))
		for fieldname, value in common.items():
			doc.set(fieldname, value)
		doc.add_comment("Info", _("Overtime claim submitted by employee: {0}").format(reason))
		doc.save(ignore_permissions=True)
	else:
		doc = frappe.get_doc({
			"doctype": "PRB Overtime Authorization",
			"employee": person.name,
			"claim_type": claim_type,
			"planned_start": actual_start,
			"planned_end": actual_end,
			"overtime_period": values.get("overtime_period") or "weekday_day",
			"authority_reference": _("ESS overtime claim: {0}").format(reason),
			"unavoidable_service_need": 1 if claim_type == "Overtime" else 0,
			"outside_normal_schedule": 1,
			**common,
		})
		doc.flags.karyo_ess_claim = True
		doc.insert(ignore_permissions=True)
		doc.flags.ignore_permissions = True
		doc.submit()
		doc.add_comment("Info", _("Overtime claim submitted by employee: {0}").format(reason))
	doc.reload()
	return {
		"name": doc.name,
		"claim_type": doc.claim_type,
		"authorization_status": doc.authorization_status,
		"payroll_approval_status": doc.get("payroll_approval_status") or (
			"Pending" if doc.authorization_status == "Recorded" and flt(doc.approved_hours) > 0 else "Awaiting Actuals"
		),
		"approved_hours": flt(doc.approved_hours),
		"eligibility_reason": doc.eligibility_reason,
		"message": _("Overtime claim {0} submitted for approval.").format(doc.name),
	}


@frappe.whitelist()
def get_additional_pay_analytics(month=None):
	"""Current-month overtime, excess-hours and encashment analytics for ESS.

	Identity is always resolved from the signed-in user. Draft encashments remain
	visible as pending requests but only submitted encashments contribute to the
	approved days and amount shown on My Payroll.
	"""
	data = get_overtime_bonuses(month)
	first, last = getdate(data["from_date"]), getdate(data["to_date"])
	employee = data["employee"]
	type_totals = {
		"Overtime": {"assigned_hours": 0.0, "actual_hours": 0.0, "approved_hours": 0.0, "amount": 0.0, "records": 0},
		"Night Duty": {"assigned_hours": 0.0, "actual_hours": 0.0, "approved_hours": 0.0, "amount": 0.0, "records": 0},
		"Excess Hours": {"assigned_hours": 0.0, "actual_hours": 0.0, "approved_hours": 0.0, "amount": 0.0, "records": 0},
	}
	for row in data.get("time_rows") or []:
		total = type_totals.setdefault(row.claim_type, {
			"assigned_hours": 0.0, "actual_hours": 0.0, "approved_hours": 0.0, "amount": 0.0, "records": 0,
		})
		if row.docstatus == 1:
			total["assigned_hours"] += flt(row.planned_hours)
		total["actual_hours"] += flt(row.actual_hours)
		total["approved_hours"] += flt(row.approved_hours)
		total["amount"] += flt(row.payroll_amount)
		total["records"] += 1

	encashments = frappe.get_all(
		"Leave Encashment",
		filters={
			"employee": employee,
			"docstatus": ("<", 2),
			"encashment_date": ("between", [first, last]),
		},
		fields=[
			"name", "encashment_date", "actual_encashable_days", "encashment_days",
			"karyo_encashment_rate_per_day", "encashment_amount", "currency",
			"karyo_payroll_cycle", "additional_salary", "docstatus", "creation",
		],
		order_by="encashment_date desc, creation desc",
		limit_page_length=100,
	)
	additional_salary_names = [row.additional_salary for row in encashments if row.additional_salary]
	additional_salaries = {
		row.name: row for row in frappe.get_all(
			"Additional Salary",
			filters={"name": ("in", additional_salary_names or [""])},
			fields=["name", "salary_component", "amount", "payroll_date", "docstatus"],
			limit_page_length=0,
		)
	}
	pdb_code = frappe.db.get_value(
		"Payroll PDB Code", {"salary_component": "Leave Encashment", "is_active": 1}, "pdb_code",
	) or "LENC"
	for row in encashments:
		posting = additional_salaries.get(row.additional_salary)
		rate = flt(row.karyo_encashment_rate_per_day)
		days = flt(row.encashment_days)
		amount = flt(row.encashment_amount)
		row.update({
			"pdb_code": pdb_code,
			"formula": _("{0} day(s) × {1:.2f} per day = {2:.2f}").format(days, rate, amount),
			"request_status": _("Approved and submitted to payroll") if row.docstatus == 1 and posting
				else _("Approved") if row.docstatus == 1 else _("Pending approval"),
			"salary_component": posting.salary_component if posting else "Leave Encashment",
			"payroll_amount": flt(posting.amount) if posting else 0,
			"additional_salary_docstatus": posting.docstatus if posting else None,
		})

	approved_encashments = [row for row in encashments if row.docstatus == 1]
	currency = next((row.currency for row in encashments if row.currency), None)
	if not currency and data.get("company"):
		currency = frappe.db.get_value("Company", data["company"], "default_currency")
	additional = {
		"assigned_hours": sum(flt(total["assigned_hours"]) for total in type_totals.values()),
		"actual_hours": sum(flt(total["actual_hours"]) for total in type_totals.values()),
		"approved_hours": sum(flt(total["approved_hours"]) for total in type_totals.values()),
		"amount": sum(flt(total["amount"]) for total in type_totals.values()),
		"records": sum(int(total["records"]) for total in type_totals.values()),
	}
	return {
		"employee": employee,
		"employee_name": data.get("employee_name"),
		"company": data.get("company"),
		"currency": currency,
		"month": str(first)[:7],
		"from_date": first,
		"to_date": last,
		"additional_hours": additional,
		"by_type": type_totals,
		"time_rows": data.get("time_rows") or [],
		"encashment": {
			"approved_days": sum(flt(row.encashment_days) for row in approved_encashments),
			"approved_amount": sum(flt(row.encashment_amount) for row in approved_encashments),
			"requested_days": sum(flt(row.encashment_days) for row in encashments),
			"pending_requests": sum(row.docstatus == 0 for row in encashments),
			"latest_qualified_days": flt(encashments[0].actual_encashable_days) if encashments else 0,
			"records": encashments,
		},
	}


@frappe.whitelist()
def get_record(name):
	person = _own_employee(required=True)
	if frappe.db.get_value("Attendance", name, "employee") != person.name:
		frappe.throw(_("You can only view your own attendance."),frappe.PermissionError)
	doc=frappe.get_doc("Attendance",name)
	doc.check_permission("read")
	clock=attendance_clock_view([name])["records"].get(name,{})
	result = {**{field:doc.get(field) for field in (
		"name","employee_name","attendance_date","status","shift","docstatus","leave_type",
		"attendance_request","karyo_is_corrected","karyo_correction_request","karyo_corrected_on",
	)},**clock}
	result["status"] = clock.get("attendance_status") or doc.status
	request = frappe.db.get_value(
		"Attendance Request",
		{"karyo_attendance": name, "docstatus": ("<", 2)},
		["name", "karyo_request_status"], order_by="creation desc", as_dict=True,
	)
	if request:
		result.update(correction_request=request.name, correction_status=request.karyo_request_status)
	return result
