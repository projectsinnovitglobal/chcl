"""Passage Benefit Computation automation fields.

bench --site dev.localhost execute karyo.setup.pb_automation.setup
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def setup():
	create_custom_fields(
		{
			"Passage Benefit Computation": [
				{
					"fieldname": "eligible_from_date",
					"fieldtype": "Date",
					"label": "Eligible From Date",
					"read_only": 1,
					"insert_after": "to_date",
				},
			]
		},
		ignore_validate=True,
	)
	frappe.db.commit()
	print("PB automation fields ensured.")
