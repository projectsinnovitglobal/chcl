"""Materialize recurring PDBs exactly once into eligible Major payroll cycles."""

import frappe
from frappe import _
from frappe.utils import flt, now_datetime
from frappe.utils.safe_exec import safe_eval


@frappe.whitelist()
def change_recurring_status(name, status, reason):
	doc = frappe.get_doc("Employee Recurring PDB", name)
	doc.status = status
	doc.change_reason = reason
	doc.save()
	return doc.name


@frappe.whitelist()
def amend_recurring(name, effective_date, changes=None, reason=None):
	doc = frappe.get_doc("Employee Recurring PDB", name)
	changes = frappe.parse_json(changes) if isinstance(changes, str) else (changes or {})
	doc.status = "Amended"
	doc.change_reason = reason or _("Recurring PDB amended")
	doc.save()
	values = {
		fieldname: doc.get(fieldname)
		for fieldname in (
			"employee",
			"company",
			"pdb_code",
			"calculation_method",
			"amount",
			"formula",
			"initial_balance",
			"remaining_balance",
			"priority",
			"remarks",
		)
	}
	values.update(changes)
	values.update(
		{
			"doctype": "Employee Recurring PDB",
			"start_date": effective_date,
			"end_date": None,
			"status": "Draft",
			"supersedes": doc.name,
		}
	)
	return frappe.get_doc(values).insert().name


def eligible_recurring_pdbs(cycle):
	if cycle.payroll_type != "Major":
		return []
	rows = frappe.get_all(
		"Employee Recurring PDB",
		filters={
			"company": cycle.company,
			"status": "Active",
			"start_date": ("<=", cycle.end_date),
		},
		fields=["*"],
		order_by="employee, priority, pdb_code, name",
	)
	# A loan-linked row is payable only after the loan has completed approval,
	# disbursement and activation. This also quarantines legacy/manual static rows
	# that were linked to an application prematurely.
	loan_references = {row.loan_reference for row in rows if row.loan_reference}
	loan_statuses = (
		{
			row.name: row.status
			for row in frappe.get_all(
				"Karyo Loan",
				filters={"name": ("in", list(loan_references))},
				fields=["name", "status"],
			)
		}
		if loan_references
		else {}
	)
	return [
		row
		for row in rows
		if not row.loan_reference or loan_statuses.get(row.loan_reference) == "Active"
	]


def static_deduction_pdb_code(salary_component):
	"""Resolve a component only to an active Static deduction PDB code."""
	for row in frappe.get_all(
		"Payroll PDB Code",
		filters={
			"salary_component": salary_component,
			"is_active": 1,
			"transaction_mode": ("in", ["Static", "Both"]),
		},
		fields=["name", "pdb_type"],
		order_by="name",
	):
		if frappe.db.get_value("Payroll PDB Type", row.pdb_type, "classification") == "Deduction":
			return row.name
	frappe.throw(
		_("Salary Component {0} has no active Static deduction Payroll PDB Code.").format(
			frappe.bold(salary_component)
		)
	)


def _base_salary(recurring, cycle):
	from karyo.payroll.salary_scales import approved_appointment

	appointment = approved_appointment(recurring.employee, cycle.end_date)
	if not appointment and frappe.db.exists("Employee Salary Appointment", {
		"employee": recurring.employee, "docstatus": ["in", [1, 2]],
		"effective_from": ["<=", cycle.end_date],
	}):
		frappe.throw(_("No approved Salary Appointment covers {0}; recurring calculation {1} cannot use a fallback base.").format(
			cycle.end_date, recurring.name
		))
	return flt(appointment.basic_salary) if appointment else flt(
		frappe.db.get_value(
			"Salary Structure Assignment",
			{
				"employee": recurring.employee,
				"company": cycle.company,
				"from_date": ("<=", cycle.end_date),
				"docstatus": 1,
			},
			"base",
			order_by="from_date desc",
		)
	)


def calculate_amount(recurring, cycle):
	if recurring.calculation_method in ("Fixed Amount", "Fixed Monthly"):
		amount = flt(recurring.amount)
	elif recurring.calculation_method == "Percentage of Basic Salary":
		amount = _base_salary(recurring, cycle) * flt(recurring.amount) / 100
	else:
		base_salary = _base_salary(recurring, cycle)
		amount = flt(
			safe_eval(
				recurring.formula,
				None,
				{
					"base_salary": base_salary,
					"remaining_balance": flt(recurring.remaining_balance),
				},
			)
		)
	if amount <= 0:
		frappe.throw(_("Recurring PDB {0} calculated a non-positive amount.").format(recurring.name))
	if recurring.is_reducing_balance:
		amount = min(amount, flt(recurring.remaining_balance))
	return amount


@frappe.whitelist()
def post_recurring_for_cycle(payroll_cycle):
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if cycle.payroll_type != "Major":
		frappe.throw(_("Recurring/static PDBs can only be posted to Major payroll."))
	if cycle.status not in ("Processing", "Review"):
		frappe.throw(_("Payroll Cycle must be Processing or Review before recurring PDBs are posted."))
	created = []
	skipped = []
	failed = []
	for row in eligible_recurring_pdbs(cycle):
		if row.end_date and row.end_date < cycle.start_date:
			expired = frappe.get_doc("Employee Recurring PDB", row.name)
			expired.flags.ignore_recurring_immutability = True
			expired.status = "Completed"
			expired.change_reason = _("Configured end date reached before {0}").format(cycle.name)
			expired.save(ignore_permissions=True)
			continue
		if frappe.db.exists(
			"Employee Recurring PDB Posting",
			{"payroll_cycle": cycle.name, "recurring_pdb": row.name, "status": "Posted"},
		):
			skipped.append(row.name)
			continue
		# One employee's missing salary structure or component mapping must not
		# discard the whole run. The row is isolated in a savepoint, the reason is
		# raised as a readiness exception, and posting continues.
		savepoint = "recurring_" + frappe.generate_hash(length=8)
		frappe.db.savepoint(savepoint)
		try:
			created.append(_post_one(cycle, frappe.get_doc("Employee Recurring PDB", row.name)))
		except Exception as error:
			frappe.db.rollback(save_point=savepoint)
			message = str(error)
			failed.append({"recurring_pdb": row.name, "employee": row.employee, "message": message})
			_raise_posting_exception(cycle, row, message)
	return {"created": created, "skipped": skipped, "failed": failed}


def _raise_posting_exception(cycle, row, message):
	"""Record a resolvable readiness exception for a recurring PDB that failed."""
	fingerprint = f"RECURRING_POST_FAILED:{cycle.name}:{row.name}"
	values = {
		"payroll_cycle": cycle.name,
		"employee": row.employee,
		"validation_code": "RECURRING_POST_FAILED",
		"severity": "Blocking",
		"status": "Open",
		"message": _("Recurring PDB {0} could not be posted: {1}").format(row.name, message)[:500],
		"fingerprint": fingerprint,
		"remediation_doctype": "Employee Recurring PDB",
		"remediation_name": row.name,
		"last_checked_on": now_datetime(),
	}
	existing = frappe.db.get_value("Payroll Readiness Exception", {"fingerprint": fingerprint}, "name")
	if existing:
		frappe.db.set_value("Payroll Readiness Exception", existing, values, update_modified=False)
	else:
		frappe.get_doc({"doctype": "Payroll Readiness Exception", **values}).insert(ignore_permissions=True)


def _post_one(cycle, recurring):
	amount = calculate_amount(recurring, cycle)
	before = flt(recurring.remaining_balance) if recurring.is_reducing_balance else 0
	after = max(0, before - amount) if recurring.is_reducing_balance else 0
	posting = frappe.get_doc(
		{
			"doctype": "Employee Recurring PDB Posting",
			"payroll_cycle": cycle.name,
			"recurring_pdb": recurring.name,
			"employee": recurring.employee,
			"pdb_code": recurring.pdb_code,
			"salary_component": recurring.salary_component,
			"amount": amount,
			"balance_before": before,
			"balance_after": after,
			"status": "Posted",
			"posted_on": now_datetime(),
			"posted_by": frappe.session.user,
		}
	).insert(ignore_permissions=True)
	additional_salary = frappe.get_doc(
		{
			"doctype": "Additional Salary",
			"employee": recurring.employee,
			"company": recurring.company,
			"salary_component": recurring.salary_component,
			"amount": amount,
			"payroll_date": cycle.payment_date,
			"overwrite_salary_structure_amount": 0,
			"ref_doctype": posting.doctype,
			"ref_docname": posting.name,
			"karyo_transaction_category": "Recurring PDB",
			"karyo_pdb_code": recurring.pdb_code,
			"karyo_payroll_cycle": cycle.name,
		}
	)
	additional_salary.insert(ignore_permissions=True)
	additional_salary.submit()
	posting.db_set("additional_salary", additional_salary.name, update_modified=False)
	if recurring.is_reducing_balance:
		recurring.flags.ignore_recurring_immutability = True
		recurring.remaining_balance = after
		if not after:
			recurring.status = "Completed"
			recurring.end_date = cycle.end_date
			recurring.change_reason = _("Reducing balance fully recovered in {0}").format(cycle.name)
		recurring.save(ignore_permissions=True)
	return posting.name
