"""Allow payroll staff to resolve accounting references without editing them."""

import frappe
from frappe.permissions import add_permission, update_permission_property


def apply():
	# Accounts Master is an administrator-owned setup surface. ERPNext does not
	# grant Account access to System Manager by default, which left MBC
	# administrators able to see the menu but blocked as soon as the table API
	# loaded. Keep this as a real DocType permission so list, link and document
	# operations all follow the same access rule.
	for role in ("System Manager",):
		if not frappe.db.exists("Role", role):
			continue
		if not frappe.db.exists("Custom DocPerm", {
			"parent": "Account", "role": role, "permlevel": 0, "if_owner": 0,
		}):
			add_permission("Account", role, 0, "read")
		for permission in ("read", "select", "create", "write", "delete"):
			update_permission_property("Account", role, 0, permission, 1)

	# Employee payroll cost-centre links fetch reference values through APIs
	# requiring read permission as well as the link selector's select permission.
	for role in ("HR Manager", "Payroll Processor"):
		if not frappe.db.exists("Role", role):
			continue
		if not frappe.db.exists("Custom DocPerm", {
			"parent": "Cost Center", "role": role, "permlevel": 0, "if_owner": 0,
		}):
			add_permission("Cost Center", role, 0, "read")
		for permission in ("read", "select"):
			update_permission_property("Cost Center", role, 0, permission, 1)
		# Salary Structure and Assignment validate Payroll Payable Account links.
		# Selection is sufficient; payroll roles do not need account maintenance.
		if not frappe.db.exists("Custom DocPerm", {
			"parent": "Account", "role": role, "permlevel": 0, "if_owner": 0,
		}):
			add_permission("Account", role, 0, "select")
			update_permission_property("Account", role, 0, "read", 0)
		update_permission_property("Account", role, 0, "select", 1)

	# Salary Structure exposes Mode of Payment as a Link. Payroll and HR staff
	# need the reference list, but do not need to maintain the accounting master.
	for role in (
		"System Manager", "HR Manager", "HR User", "Payroll Input", "Payroll Processor",
		"Payroll Reviewer", "Payroll Approver", "Payroll Finance",
	):
		if not frappe.db.exists("Role", role):
			continue
		if not frappe.db.exists("Custom DocPerm", {
			"parent": "Mode of Payment", "role": role, "permlevel": 0, "if_owner": 0,
		}):
			add_permission("Mode of Payment", role, 0, "select")
		update_permission_property("Mode of Payment", role, 0, "select", 1)

	# These two Department references are selectable in the shared organisation
	# editor. Read/select access prevents Link controls from raising a permission
	# dialog while keeping create, write and delete governed by their own masters.
	for doctype in ("Cost Center", "Leave Block List"):
		for role in ("System Manager", "HR Manager", "HR User"):
			if not frappe.db.exists("Role", role):
				continue
			if not frappe.db.exists("Custom DocPerm", {
				"parent": doctype, "role": role, "permlevel": 0, "if_owner": 0,
			}):
				add_permission(doctype, role, 0, "read")
			for permission in ("read", "select"):
				update_permission_property(doctype, role, 0, permission, 1)
	# Company maintenance exposes Default Finance Book as a reference field.
	# ERPNext does not grant that master to System Manager or HR Manager by
	# default, so merely focusing the link can produce a repeating permission
	# dialog.  These roles only need to resolve the reference; they do not gain
	# create, write or delete access to Finance Book.
	for role in ("System Manager", "HR Manager"):
		if not frappe.db.exists("Role", role):
			continue
		if not frappe.db.exists("Custom DocPerm", {
			"parent": "Finance Book", "role": role, "permlevel": 0, "if_owner": 0,
		}):
			add_permission("Finance Book", role, 0, "read")
		for permission in ("read", "select"):
			update_permission_property("Finance Book", role, 0, permission, 1)
	frappe.clear_cache(doctype="Cost Center")
	frappe.clear_cache(doctype="Account")
	frappe.clear_cache(doctype="Finance Book")
	frappe.clear_cache(doctype="Mode of Payment")
	frappe.clear_cache(doctype="Leave Block List")


def setup():
	apply()
	enable_cost_center_maintenance()


def enable_cost_center_maintenance():
	"""Payroll administrators maintain the shared cost-center master from Setup."""
	for role in ("HR Manager", "System Manager"):
		if not frappe.db.exists("Custom DocPerm", {"parent": "Cost Center", "role": role, "permlevel": 0, "if_owner": 0}):
			add_permission("Cost Center", role, 0, "read")
		for permission in ("read", "select", "create", "write", "delete"):
			update_permission_property("Cost Center", role, 0, permission, 1)
	frappe.clear_cache(doctype="Cost Center")
