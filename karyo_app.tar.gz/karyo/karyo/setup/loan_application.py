"""Karyo Loan — application lifecycle fields (Phase 1).

    bench --site dev.localhost execute karyo.setup.loan_application.setup

Adds the application-stage fields the client status model and prototype require
(applied vs approved amount, purpose, approval flag, registration fee, net loan
amount, amount-in-words, loan reference number, committee + MD decision capture,
agreement print date) and organises the Karyo Loan form into tabs matching the
prototype drawer. Idempotent — create_custom_fields upserts.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def add_application_fields():
	# Approved Amount may legitimately remain blank until approval when configured.
	frappe.db.set_value("DocField", {"parent": "Karyo Loan", "fieldname": "approved_amount"}, "reqd", 0)
	create_custom_fields(
		{
			"Loan Type": [
				{
					"fieldname": "agreement_print_format",
					"fieldtype": "Link",
					"label": "Loan Agreement Template",
					"options": "Print Format",
					"insert_after": "insurance_required",
					"description": "Optional Loan Type-specific agreement template. Blank uses MBC Loan Agreement.",
				},
			],
			"Karyo Loan": [
				# --- Application details (near the top, after the workflow state) ---
				{
					"fieldname": "application_sb",
					"fieldtype": "Section Break",
					"label": "Application Details",
					"insert_after": "workflow_state",
				},
				{
					"fieldname": "application_channel",
					"fieldtype": "Select",
					"label": "Application Channel",
					"options": "ESS\nHR/Loan Officer",
					"default": "HR/Loan Officer",
					"read_only": 1,
					"insert_after": "application_sb",
				},
				{
					"fieldname": "amount_applied",
					"fieldtype": "Currency",
					"label": "Amount Applied (Requested)",
					"insert_after": "application_channel",
				},
				{
					"fieldname": "date_applied",
					"fieldtype": "Date",
					"label": "Date Applied",
					"insert_after": "amount_applied",
				},
				{
					"fieldname": "purpose",
					"fieldtype": "Small Text",
					"label": "Purpose of Loan",
					"insert_after": "date_applied",
				},
				{"fieldname": "application_remarks", "fieldtype": "Small Text", "label": "Application Remarks / Reason", "insert_after": "purpose"},
				{
					"fieldname": "is_approval_required",
					"fieldtype": "Check",
					"label": "Approval by Committee",
					"default": "1",
					"insert_after": "application_remarks",
				},
				{
					"fieldname": "application_cb",
					"fieldtype": "Column Break",
					"insert_after": "is_approval_required",
				},
				{
					"fieldname": "registration_fee",
					"fieldtype": "Currency",
					"label": "Registration Fee",
					"insert_after": "application_cb",
				},
				{
					"fieldname": "net_loan_amount",
					"fieldtype": "Currency",
					"label": "Net Loan Amount",
					"read_only": 1,
					"insert_after": "registration_fee",
					"description": "Approved amount less registration fee (BR-FAR-LMS-CAL §8).",
				},
				{
					"fieldname": "cheque_no",
					"fieldtype": "Data",
					"label": "Cheque No.",
					"insert_after": "net_loan_amount",
				},
				{
					"fieldname": "loan_reference_no",
					"fieldtype": "Data",
					"label": "Loan Reference No.",
					"read_only": 1,
					"insert_after": "cheque_no",
					"description": "LMS reference generated on activation; used for schedule, ledger and payroll postings.",
				},
				{
					"fieldname": "approved_amount_words",
					"fieldtype": "Small Text",
					"label": "Approved Amount in Words",
					"read_only": 1,
					"insert_after": "loan_reference_no",
				},
				{
					"fieldname": "override_approved_amount",
					"fieldtype": "Check",
					"label": "Allow Approved > Applied",
					"insert_after": "approved_amount_words",
					"description": "Authorised override so the approved amount may exceed the applied amount (VAL-FAR-005).",
				},
				# --- Tab: Computation (groups computed components + schedule) ---
				{
					"fieldname": "computation_tab",
					"fieldtype": "Tab Break",
					"label": "Computation",
					"insert_after": "sum_assured",
				},
				# --- Tab: Guarantors & Deductions ---
				{
					"fieldname": "parties_tab",
					"fieldtype": "Tab Break",
					"label": "Guarantors & Deductions",
					"insert_after": "schedule",
				},
				# --- Tab: Committee & Approval (decision capture) ---
				{
					"fieldname": "approval_tab",
					"fieldtype": "Tab Break",
					"label": "Committee & Approval",
					"insert_after": "settlement_date",
				},
				{
					"fieldname": "committee_date",
					"fieldtype": "Date",
					"label": "Loan Committee Date",
					"insert_after": "approval_tab",
				},
				{
					"fieldname": "committee_decision",
					"fieldtype": "Select",
					"label": "Committee Decision",
					"options": "\nRecommended\nRejected\nPending",
					"insert_after": "committee_date",
				},
				{
					"fieldname": "committee_remarks",
					"fieldtype": "Small Text",
					"label": "Committee Remarks",
					"insert_after": "committee_decision",
				},
				{
					"fieldname": "approval_cb",
					"fieldtype": "Column Break",
					"insert_after": "committee_remarks",
				},
				{
					"fieldname": "md_decision",
					"fieldtype": "Select",
					"label": "MD Decision",
					"options": "\nApproved\nRejected",
					"insert_after": "approval_cb",
				},
				{
					"fieldname": "md_approver",
					"fieldtype": "Link",
					"label": "MD Approver",
					"options": "User",
					"insert_after": "md_decision",
				},
				{
					"fieldname": "agreement_printed_on",
					"fieldtype": "Date",
					"label": "Agreement Printed On",
					"read_only": 1,
					"insert_after": "md_approver",
				},
				{
					"fieldname": "committee_decided_by",
					"fieldtype": "Link",
					"label": "Committee Decision By",
					"options": "User",
					"read_only": 1,
					"insert_after": "agreement_printed_on",
				},
				{
					"fieldname": "committee_decided_on",
					"fieldtype": "Datetime",
					"label": "Committee Decision On",
					"read_only": 1,
					"insert_after": "committee_decided_by",
				},
				{
					"fieldname": "loan_approved_by",
					"fieldtype": "Link",
					"label": "Loan Approved By",
					"options": "User",
					"read_only": 1,
					"insert_after": "committee_decided_on",
				},
				{
					"fieldname": "loan_approved_on",
					"fieldtype": "Datetime",
					"label": "Loan Approved On",
					"read_only": 1,
					"insert_after": "loan_approved_by",
				},
				{
					"fieldname": "approval_route",
					"fieldtype": "Data",
					"label": "Approval Route",
					"read_only": 1,
					"insert_after": "loan_approved_on",
				},
				{
					"fieldname": "amount_override_reason",
					"fieldtype": "Small Text",
					"label": "Approved Amount Override Reason",
					"insert_after": "approval_route",
				},
				{
					"fieldname": "deduction_override_reason",
					"fieldtype": "Small Text",
					"label": "Affordability Override Reason",
					"insert_after": "amount_override_reason",
				},
				{"fieldname": "return_reason", "fieldtype": "Small Text", "label": "Return for Rework Reason", "insert_after": "deduction_override_reason"},
				{"fieldname": "rejection_reason", "fieldtype": "Small Text", "label": "Rejection Reason", "insert_after": "return_reason"},
				{"fieldname": "returned_by", "fieldtype": "Link", "label": "Returned By", "options": "User", "read_only": 1, "insert_after": "rejection_reason"},
				{"fieldname": "returned_on", "fieldtype": "Datetime", "label": "Returned On", "read_only": 1, "insert_after": "returned_by"},
				{"fieldname": "approval_snapshot", "fieldtype": "Long Text", "label": "Final Approval Snapshot", "read_only": 1, "hidden": 1, "insert_after": "returned_on"},
				{"fieldname": "approval_snapshot_hash", "fieldtype": "Data", "label": "Approval Snapshot Hash", "read_only": 1, "insert_after": "approval_snapshot"},
				{"fieldname": "insurance_control_sb", "fieldtype": "Section Break", "label": "Insurance Confirmation", "insert_after": "approval_snapshot_hash"},
				{"fieldname": "insurance_rate_rule", "fieldtype": "Link", "label": "Insurance Rate Rule", "options": "Loan Insurance Rate", "read_only": 1, "insert_after": "insurance_control_sb"},
				{"fieldname": "insurance_rate_version", "fieldtype": "Data", "label": "Insurance Rate Version", "read_only": 1, "insert_after": "insurance_rate_rule"},
				{"fieldname": "insurance_provider", "fieldtype": "Data", "label": "Insurance Provider", "read_only": 1, "insert_after": "insurance_rate_version"},
				{"fieldname": "insurance_policy_reference", "fieldtype": "Data", "label": "Policy / Rate Reference", "read_only": 1, "insert_after": "insurance_provider"},
				{"fieldname": "insurance_confirmed", "fieldtype": "Check", "label": "Insurance Confirmed", "insert_after": "insurance_policy_reference"},
				{"fieldname": "insurance_cb", "fieldtype": "Column Break", "insert_after": "insurance_confirmed"},
				{"fieldname": "insurance_confirmed_by", "fieldtype": "Link", "label": "Confirmed By", "options": "User", "read_only": 1, "insert_after": "insurance_cb"},
				{"fieldname": "insurance_confirmed_on", "fieldtype": "Datetime", "label": "Confirmed On", "read_only": 1, "insert_after": "insurance_confirmed_by"},
				{"fieldname": "insurance_snapshot", "fieldtype": "Long Text", "label": "Insurance Snapshot", "read_only": 1, "hidden": 1, "insert_after": "insurance_confirmed_on"},
				{"fieldname": "insurance_snapshot_hash", "fieldtype": "Data", "label": "Insurance Snapshot Hash", "read_only": 1, "insert_after": "insurance_snapshot"},
			],
			"Karyo Settings": [
				{
					"fieldname": "loan_application_channels",
					"fieldtype": "Select",
					"label": "Enabled Loan Application Channels",
					"options": "ESS and HR/Loan Officer\nESS Only\nHR/Loan Officer Only",
					"default": "ESS and HR/Loan Officer",
					"insert_after": "require_appraisal_payroll_cycle",
				},
				{
					"fieldname": "approved_amount_default_policy",
					"fieldtype": "Select",
					"label": "Approved Amount Default Policy",
					"options": "Requested Amount\nBlank Until Approval",
					"default": "Requested Amount",
					"insert_after": "loan_application_channels",
				},
				{"fieldname": "loan_amount_override_role", "fieldtype": "Link", "label": "Approved Amount Override Role", "options": "Role", "insert_after": "approved_amount_default_policy"},
				{"fieldname": "loan_recast_override_role", "fieldtype": "Link", "label": "Recast Cap Override Role", "options": "Role", "insert_after": "loan_amount_override_role"},
			]
		},
		ignore_validate=True,
	)
	print("  + Karyo Loan application fields ensured")


def setup():
	print("Karyo Loan application setup:")
	add_application_fields()
	frappe.clear_cache(doctype="Karyo Loan")
	print("Done.")
