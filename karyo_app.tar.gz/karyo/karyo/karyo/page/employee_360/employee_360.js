frappe.pages["employee-360"].on_page_load = function (wrapper) {
	frappe.ui.make_app_page({ parent: wrapper, title: __("Employee 360"), single_column: true });
	$(wrapper).addClass("karyo-module-page employee-360-page");
};

frappe.pages["employee-360"].on_page_show = function (wrapper) {
	const employee = frappe.get_route()[1];
	const $root = $(wrapper).find(".layout-main-section").empty();
	if (!employee) {
		frappe.set_route("people-overview");
		return;
	}
	$root.append('<div class="employee-360-loading">Loading employee…</div>');
	karyo.live.request(wrapper, {
		method: "karyo.desk.people.employee_360",
		args: { employee },
		callback: (r) => {
			const pane=$root.find('.employee-pane.active').attr('data-pane');
			render($root,r.message||{});
			if(pane){$root.find('.employee-pane').removeClass('active').filter(`[data-pane="${pane}"]`).addClass('active');const index=$root.find('.employee-pane').index($root.find(`.employee-pane[data-pane="${pane}"]`));$root.find('.employee-profile-tabs button').removeClass('active').eq(index).addClass('active');}
		},
	});
};

function render($root, d) {
	const person = d.employee || {};
	$root.empty();
	const $page = $('<div class="karyo-page employee-360"></div>').appendTo($root);
	const $crumbs = $('<div class="karyo-crumbs"></div>').appendTo($page);
	$crumbs.append(
		$('<a href="/app/people-overview"></a>').text(__("People")),
		'<span class="karyo-crumb-sep">›</span>',
		$("<span></span>").text(person.employee_name || person.name)
	);
	const initials = (person.employee_name || person.name || "?")
		.split(/\s+/)
		.slice(0, 2)
		.map((p) => p[0])
		.join("")
		.toUpperCase();
	const $hero = $(`
		<div class="employee-hero">
			<div class="employee-avatar"><span></span></div>
			<div class="employee-identity"><div class="employee-name"></div><div class="employee-title"></div><div class="employee-tags"></div></div>
			<div class="employee-actions"></div>
		</div>
	`).appendTo($page);
	if (person.image)
		$hero.find(".employee-avatar").empty().append($("<img alt=''>").attr("src", person.image));
	else $hero.find(".employee-avatar span").text(initials);
	const $photo = $hero.find(".employee-avatar").wrap('<div class="mbc-employee-photo-editor"></div>').parent();
	if (d.actions?.edit) {
		karyo.employee_photo.pencil().appendTo($photo).on("click", () => {
			new frappe.ui.FileUploader({
				doctype: "Employee", docname: person.name, fieldname: "image",
				allow_multiple: false, restrictions: { allowed_file_types: ["image/*"] },
				on_success: async (file) => {
					await frappe.db.set_value("Employee", person.name, "image", file.file_url);
					person.image = file.file_url;
					$hero.find(".employee-avatar").empty().append($("<img alt=''>").attr("src", file.file_url));
					frappe.show_alert({ message: __("Employee photo updated"), indicator: "green" });
				},
			});
		});
	}
	$hero.find(".employee-name").text(person.employee_name || person.name);
	$hero
		.find(".employee-title")
		.text(
			[person.designation, person.department].filter(Boolean).join(" · ") ||
				__("Employment details not set")
		);
	$hero
		.find(".employee-tags")
		.append(
			karyo.pages.pill(
				person.status || __("Unknown"),
				person.status === "Active" ? "green" : "grey"
			),
			$("<span></span>").text(person.name)
		);
	add_actions($hero.find(".employee-actions"), person, d.actions || {}, d.navigation || {});
	const $lifecycle = $('<section class="employee-section employee-lifecycle"><div class="employee-section-head"><h3></h3><span></span></div><div class="employee-lifecycle-body"></div></section>').appendTo($page);
	$lifecycle.find("h3").text(__("Lifecycle"));
	$lifecycle.find(".employee-section-head span").text(__("{0} events", [(d.activity || []).length]));
	karyo.pages.timeline($lifecycle.find(".employee-lifecycle-body"), (d.activity || []).map((item) => ({
		title: `${item.label} · ${item.name}`, description: item.status || "", date: item.date, route: item.route,
	})));

	const $tabs = $('<div class="employee-profile-tabs"></div>').appendTo($page);
	const panes = {};
	const tabs = [
		["overview", __("Overview")],
		["employment", __("Employment")],
		["attendance", __("Attendance")],
		["leave", __("Leave")],
		["pay", __("Pay")],
		["benefits", __("Benefits")],
		["documents", __("Documents")],
		["activity", __("Activity")],
	];
	tabs.forEach(([key, label], index) => {
		panes[key] = $('<div class="employee-pane"></div>')
			.attr("data-pane", key).toggleClass("active", index === 0).appendTo($page);
		const $button = $('<button type="button"></button>')
			.text(label)
			.toggleClass("active", index === 0)
			.on("click", () => {
				$tabs.find("button").removeClass("active");
				$button.addClass("active");
				$page.find(".employee-pane").removeClass("active");
				panes[key].addClass("active");
			});
		$tabs.append($button);
	});
	render_overview(panes.overview, person, d);
	render_employment(panes.employment, person);
	render_attendance(panes.attendance, d.details?.time || {});
	render_leave(panes.leave, d.details?.time || {});
	render_pay(panes.pay, d.details?.payroll || {});
	render_final_settlement(panes.pay, d.final_settlement);
	const $paymentWindow = d.post_exit_payment?.completed_separation
		? $('<section class="employee-section"></section>').prependTo(panes.pay) : panes.pay;
	karyo.post_exit_payment.render($paymentWindow, d.post_exit_payment, async () => {
		const data = await frappe.xcall("karyo.desk.people.employee_360", {employee: person.name});
		render($root, data);
		$root.find('.employee-profile-tabs button').eq(4).trigger('click');
	});
	render_benefits(panes.benefits, d.details?.benefits || {});
	render_documents(panes.documents, person, d.documents || [], d.actions || {});
	render_activity(panes.activity, d.activity || []);
}

function add_actions($parent, person, actions, navigation) {
	// 1. Compact prev / next pager
	const $pager = $('<div class="employee-nav-pager"></div>');
	[
		[navigation.previous, "‹", __("Previous employee")],
		[navigation.next, "›", __("Next employee")],
	].forEach(([target, glyph, label]) => {
		const $btn = $('<button type="button" class="employee-nav-btn"></button>')
			.text(glyph)
			.attr("title", target ? target.employee_name || label : label);
		if (target) $btn.on("click", () => frappe.set_route(target.route.replace(/^\/app\//, "")));
		else $btn.prop("disabled", true);
		$pager.append($btn);
	});
	if (navigation.previous || navigation.next) $parent.append($pager);

	// 2. Everyday action kept visible
	if (actions.edit)
		$parent.append(
			$('<button class="btn btn-sm karyo-btn-secondary"></button>')
				.text(__("Edit profile"))
				.on("click", () => frappe.set_route("Form", "Employee", person.name))
		);

	// 3. Lifecycle actions collapsed into a single dropdown
	const items = [];
	if (actions.promotion) items.push({ label: __("Promote"), doctype: "Employee Promotion" });
	if (actions.transfer) items.push({ label: __("Transfer"), doctype: "Employee Transfer" });
	if (actions.leave) items.push({ label: __("Record leave"), doctype: "Leave Application" });
	if (actions.separation)
		items.push({ label: __("Start separation"), doctype: "Employee Separation", danger: true });
	if (items.length) $parent.append(build_actions_menu(person, items));
}

function build_actions_menu(person, items) {
	const $menu = $('<div class="employee-actions-menu"></div>');
	const $toggle = $('<button type="button" class="btn btn-sm btn-primary employee-actions-toggle"></button>')
		.append($("<span></span>").text(__("Actions")), $('<b class="employee-actions-caret">▾</b>'));
	const $dropdown = $('<div class="employee-actions-dropdown"></div>');
	items.forEach((item) => {
		$dropdown.append(
			$('<button type="button" class="employee-actions-option"></button>')
				.text(item.label)
				.toggleClass("is-danger", !!item.danger)
				.on("click", () => {
					$menu.removeClass("open");
					frappe.new_doc(item.doctype, { employee: person.name });
				})
		);
	});
	$toggle.on("click", (e) => {
		e.stopPropagation();
		$(".employee-actions-menu.open").not($menu).removeClass("open");
		$menu.toggleClass("open");
	});
	$(document)
		.off("click.emp360menu")
		.on("click.emp360menu", () => $(".employee-actions-menu.open").removeClass("open"));
	$menu.append($toggle, $dropdown);
	return $menu;
}

function render_overview($pane, person, d) {
	render_health($pane, person, d.health || {}, d.actions || {});
	const $grid = $('<div class="employee-overview-grid"></div>').appendTo($pane);
	const $details = $(
		'<section class="employee-section"><h3>At a glance</h3><div class="employee-detail-list"></div></section>'
	)
		.appendTo($grid)
		.find(".employee-detail-list");
	[
		[__("Employee ID"), person.name],
		[__("Department"), person.department],
		[__("Designation"), person.designation],
		[__("Branch"), person.branch],
		[__("Company"), person.company],
		[__("Joined"), person.date_of_joining],
		[__("Employment type"), person.employment_type],
	].forEach(
		([label, value]) =>
			value &&
			$details.append(
				$("<div><span></span><strong></strong></div>")
					.find("span")
					.text(label)
					.end()
					.find("strong")
					.text(value)
					.end()
			)
	);
	const $manager = $(
		'<section class="employee-section"><h3>Reporting line</h3><div class="reporting-card"></div></section>'
	)
		.appendTo($grid)
		.find(".reporting-card");
	if (person.manager_name)
		$manager.append(
			$("<span></span>").text(__("Reports to")),
			$('<button type="button"></button>')
				.text(person.manager_name)
				.on("click", () => frappe.set_route(person.manager_route.replace(/^\/app\//, "")))
		);
	else $manager.text(__("No manager assigned"));
	const $reports = $(
		'<section class="employee-section span-2"><h3>Direct reports</h3><div class="direct-reports"></div></section>'
	)
		.appendTo($grid)
		.find(".direct-reports");
	if (!(d.direct_reports || []).length)
		$reports.append('<div class="employee-muted">No direct reports</div>');
	(d.direct_reports || []).forEach((report) =>
		$reports.append(
			$('<button type="button"><strong></strong><span></span></button>')
				.find("strong")
				.text(report.employee_name || report.name)
				.end()
				.find("span")
				.text(report.designation || report.department || "")
				.end()
				.on("click", () => frappe.set_route(report.route.replace(/^\/app\//, "")))
		)
	);
}

function render_health($pane, person, health, actions) {
	const $health = $(
		'<div class="employee-health-grid"><section class="employee-section profile-completeness"><div class="profile-score"><strong></strong><span>Profile complete</span></div><div class="profile-score-track"><i></i></div><div class="profile-sections"></div></section><section class="employee-section attention-section"><div class="employee-section-head"><h3>Needs attention</h3><span></span></div><div class="attention-list"></div></section></div>'
	).appendTo($pane);
	$health.find(".profile-score strong").text(`${health.score ?? 100}%`);
	$health.find(".profile-score-track i").css("width", `${health.score ?? 100}%`);
	const $sections = $health.find(".profile-sections");
	(health.sections || []).forEach((section) => {
		const $row = $(
			'<div class="profile-section-row"><span class="profile-check"></span><span class="profile-section-name"></span><small></small></div>'
		);
		$row.find(".profile-check")
			.text(section.complete ? "✓" : "!")
			.toggleClass("complete", section.complete);
		$row.find(".profile-section-name").text(section.label);
		$row.find("small").text(
			section.complete
				? __("Complete")
				: __("Missing: {0}", [(section.missing || []).join(", ")])
		);
		$sections.append($row);
	});
	const attention = health.attention || [];
	$health
		.find(".attention-section .employee-section-head span")
		.text(attention.length ? __("{0} open", [attention.length]) : __("All clear"));
	const $list = $health.find(".attention-list");
	if (!attention.length) {
		$list.append(
			$("<div class='attention-clear'><strong>✓</strong><span></span></div>")
				.find("span")
				.text(__("No profile or employment issues need attention."))
				.end()
		);
	} else {
		attention.forEach((item) => {
			const $item = $(
				'<button type="button" class="attention-item"><span class="attention-indicator"></span><span><strong></strong><small></small></span><b>Fix →</b></button>'
			);
			$item.addClass(`is-${item.severity || "warning"}`);
			$item.find("strong").text(item.title);
			$item.find("small").text(item.detail);
			$item.find("b").toggle(actions.edit === true);
			if (actions.edit)
				$item.on("click", () => frappe.set_route("Form", "Employee", person.name));
			else $item.prop("disabled", true);
			$list.append($item);
		});
	}
}

function render_employment($pane, person) {
	const $section = $(
		'<section class="employee-section"><h3>Employment profile</h3><div class="employee-detail-list wide"></div></section>'
	)
		.appendTo($pane)
		.find(".employee-detail-list");
	[
		[__("Status"), person.status],
		[__("Company"), person.company],
		[__("Branch"), person.branch],
		[__("Department"), person.department],
		[__("Designation"), person.designation],
		[__("Grade"), person.grade],
		[__("Employment type"), person.employment_type],
		[__("Date of joining"), person.date_of_joining],
		[__("Company email"), person.company_email],
		[__("Mobile"), person.cell_number],
	].forEach(([label, value]) =>
		$section.append(
			$("<div><span></span><strong></strong></div>")
				.find("span")
				.text(label)
				.end()
				.find("strong")
				.text(value || "—")
				.end()
		)
	);
}

const EMPLOYEE_WORKSPACE_ROUTES = {
	"employee-onboarding": "employee-onboarding",
	"employee-separation": "employee-separation",
	"employee-promotion": "employee-promotion",
	"employee-transfer": "employee-transfer",
	"leave-application": "leave-application",
	"attendance-request": "attendance-request",
	"salary-slip": "salary-slip",
	"expense-claim": "expense-claim",
	"karyo-loan": "karyo-loan",
};

function open_employee_record(route_prefix, name) {
	const workspace = EMPLOYEE_WORKSPACE_ROUTES[route_prefix];
	if (workspace) frappe.set_route("hr-record", workspace, name);
	else frappe.set_route(route_prefix, name);
}

function employee_record_table($parent, title, columns, rows, route_prefix, empty) {
	const $section = $(
		'<section class="employee-section employee-record-section"><div class="employee-section-head"><h3></h3><span></span></div><div class="employee-record-table"></div></section>'
	).appendTo($parent);
	$section.find("h3").text(title);
	$section.find(".employee-section-head span").text(__("{0} records", [(rows || []).length]));
	const $table = $section.find(".employee-record-table");
	if (!(rows || []).length) {
		$table.append(
			$("<div class='employee-muted'></div>").text(empty || __("No records available"))
		);
		return $section;
	}
	const $head = $('<div class="employee-record-row is-head"></div>').appendTo($table);
	columns.forEach((column) => $head.append($("<span></span>").text(column.label)));
	rows.forEach((row) => {
		const $record = $('<button type="button" class="employee-record-row"></button>');
		columns.forEach((column) => {
			let value = row[column.field];
			if (column.currency && value != null) value = format_currency(value, row.currency);
			$record.append($("<span></span>").text(value ?? "—"));
		});
		if (route_prefix && row.name)
			$record.on("click", () => open_employee_record(route_prefix, row.name));
		$table.append($record);
	});
	return $section;
}

function render_leave($pane, time) {
	const leaveDays = (value) => format_number(flt(value || 0), null, Number.isInteger(flt(value || 0)) ? 0 : 2);
	const $balances = $(
		'<section class="employee-section"><div class="employee-section-head"><h3>Current leave balances</h3></div><div class="leave-balance-grid"></div></section>'
	)
		.appendTo($pane)
		.find(".leave-balance-grid");
	if (!(time.leave_balances || []).length)
		$balances.append(
			$("<div class='employee-muted'></div>").text(__("No current leave allocations"))
		);
	(time.leave_balances || []).forEach((leave) => {
		const allocated = Number(leave.total_leaves_allocated || leave.new_leaves_allocated || 0);
		const balance = Number(leave.balance || 0);
		const pct = allocated ? Math.max(0, Math.min(100, (balance / allocated) * 100)) : 0;
		const $card = $(
			'<button type="button" class="leave-balance-card"><div><strong></strong><span></span></div><b></b><div class="leave-balance-track"><i></i></div><small></small></button>'
		);
		$card.find("strong").text(leave.leave_type);
		$card.find("span").text(leave.availability_status || __("Available"));
		if (leave.is_carry_forward) {
			$card.find("strong").after(karyo.pages.pill(__(leave.tag || "Carry Forward"), "green"));
		}
		$card.find("b").text(leaveDays(balance));
		$card.find("i").css("width", `${pct}%`);
		$card.find("small").text(__("{0} allocated · {1} taken · {2} pending · {3} expired", [leaveDays(allocated), leaveDays(leave.used), leaveDays(leave.pending), leaveDays(leave.expired)]));
		$card.on("click", () => frappe.set_route("leave-allocation", leave.name));
		$balances.append($card);
	});
	const $grid = $('<div class="employee-data-grid"></div>').appendTo($pane);
	employee_record_table(
		$grid,
		__("Leave applications"),
		[
			{ label: __("Leave type"), field: "leave_type" },
			{ label: __("Dates"), field: "date_range" },
			{ label: __("Days"), field: "total_leave_days" },
			{ label: __("Status"), field: "status" },
		],
		(time.leave_applications || []).map((row) => ({
			...row,
			date_range: [row.from_date, row.to_date].filter(Boolean).join(" → "),
		})),
		"leave-application",
		__("No leave applications")
	);
}

function render_attendance($pane, time) {
	const $grid = $('<div class="employee-data-grid"></div>').appendTo($pane);
	const governedHours = (row, field, statusField) => row[statusField] === "Not Eligible"
		? __("Not Eligible")
		: (row[field] == null || (!row[statusField] && flt(row[field]) === 0) ? "-" : __("{0} hrs", [format_number(row[field], null, 2)]));
	const governedBonus = (row, field) => row[`${field}_status`] === "Not Eligible"
		? __("Not Eligible") : (row[field] == null ? "-" : format_currency(row[field]));
	const rows = (time.attendance || []).map(row => ({
		...row,
		overtime_display: governedHours(row, "overtime_hours", "overtime_status"),
		excess_display: governedHours(row, "excess_hours", "excess_hours_status"),
		night_duty_display: governedHours(row, "night_duty_hours", "night_duty_status"),
		total_hours_display: row.total_hours == null ? "-" : __("{0} hrs", [format_number(row.total_hours, null, 2)]),
		attendance_bonus_display: governedBonus(row, "attendance_bonus"),
		incentive_bonus_display: governedBonus(row, "incentive_bonus"),
	}));
	employee_record_table(
		$grid,
		__("Recent attendance"),
		[
			{ label: __("Date"), field: "attendance_date" },
			{ label: __("Status"), field: "status" },
			{ label: __("Source"), field: "entry_source" },
			{ label: __("Clock In"), field: "clock_in" },
			{ label: __("Clock Out"), field: "clock_out" },
			{ label: __("Overtime"), field: "overtime_display" },
			{ label: __("Excess Hrs"), field: "excess_display" },
			{ label: __("Night Duty"), field: "night_duty_display" },
			{ label: __("Total Hrs"), field: "total_hours_display" },
			{ label: __("Attendance Bonus"), field: "attendance_bonus_display" },
			{ label: __("Incentive Bonus"), field: "incentive_bonus_display" },
			{ label: __("Leave type"), field: "leave_type" },
			{ label: __("Remark"), field: "remark" },
		],
		rows,
		"attendance",
		__("No submitted attendance records")
	);
}

function render_pay($pane, payroll) {
	const latest = (payroll.payslips || [])[0];
	if (latest) {
		const $summary = $('<div class="pay-summary"></div>').appendTo($pane);
		[
			[__("Latest gross pay"), latest.gross_pay],
			[__("Latest deductions"), latest.total_deduction],
			[__("Latest net pay"), latest.net_pay],
		].forEach(([label, value]) =>
			$summary.append(
				$("<div><span></span><strong></strong><small></small></div>")
					.find("span")
					.text(label)
					.end()
					.find("strong")
					.text(format_currency(value || 0, latest.currency))
					.end()
					.find("small")
					.text([latest.start_date, latest.end_date].filter(Boolean).join(" → "))
					.end()
			)
		);
	}
	const $grid = $('<div class="employee-data-grid"></div>').appendTo($pane);
	const $payslips = $('<section class="employee-section employee-record-section"><h3></h3></section>').appendTo($grid);
	$payslips.find('h3').text(__('Generated payslips'));
	if ((payroll.payslips || []).length) karyo.payroll.employee_payslip_table($payslips,
		payroll.payslips.map(row=>({...row, generated_on:row.creation})), {manageStatus:true, view:name=>open_employee_record('salary-slip',name)});
	else $('<p class="employee-muted">').text(__('No accessible payslips')).appendTo($payslips);
	employee_record_table(
		$grid,
		__("Salary assignments"),
		[
			{ label: __("Effective from"), field: "from_date" },
			{ label: __("Salary structure"), field: "salary_structure" },
			{ label: __("Base"), field: "base", currency: true },
			{ label: __("Variable"), field: "variable", currency: true },
		],
		payroll.salary_assignments || [],
		"salary-structure-assignment",
		__("No accessible salary assignments")
	);
}

function render_final_settlement($pane, settlement) {
	if (!settlement) return;
	const $section = $('<section class="employee-section"><div class="employee-section-head"><h3></h3><span></span></div><p class="employee-muted"></p><div class="pay-summary"></div></section>').prependTo($pane);
	$section.find("h3").text(__("Leaving Service Final Settlement"));
	$section.find(".employee-section-head span").append(karyo.pages.pill(__(settlement.status || "Preview"), settlement.status === "Finalized" ? "green" : "orange"));
	$section.find("p").text(__("Outstanding balances as at {0}", [settlement.as_at || "—"]));
	[
		[__("Remaining Sick Leave"), __("{0} days", [format_number(flt(settlement.sick_leave_days || 0), null, 2)])],
		[__("Annual Leave Balance"), __("{0} days", [format_number(flt(settlement.vacation_leave_days || 0), null, 2)])],
		[__("Passage Benefit Balance"), format_currency(settlement.pb_balance || 0, settlement.currency)],
		[__("Outstanding Loan Balance"), format_currency(settlement.loan_outstanding || 0, settlement.currency)],
		[__("Total Accrued Benefits"), format_currency(settlement.gross_settlement || 0, settlement.currency)],
		[__("Net Settlement"), format_currency(settlement.net_settlement || 0, settlement.currency)],
	].forEach(([label, value]) => $section.find(".pay-summary").append(
		$("<div><span></span><strong></strong></div>").find("span").text(label).end().find("strong").text(value).end()
	));
	if (settlement.separation)
		$("<button type='button' class='btn btn-default btn-sm mt-3'>").text(__("Open Separation and Settlement"))
			.on("click", () => open_employee_record("employee-separation", settlement.separation)).appendTo($section);
}

function render_benefits($pane, benefits) {
	const $grid = $('<div class="employee-data-grid"></div>').appendTo($pane);
	employee_record_table(
		$grid,
		__("Loans"),
		[
			{ label: __("Loan"), field: "loan_type" },
			{ label: __("Approved"), field: "approved_amount", currency: true },
			{ label: __("Outstanding"), field: "outstanding_capital", currency: true },
			{ label: __("Total paid"), field: "total_paid", currency: true },
			{ label: __("Monthly repayment"), field: "monthly_refund", currency: true },
			{ label: __("Repayment status"), field: "repayment_status" },
			{ label: __("Status"), field: "status" },
		],
		benefits.loans || [],
		"karyo-loan",
		__("No accessible loans")
	);
	employee_record_table(
		$grid,
		__("Expense claims"),
		[
			{ label: __("Date"), field: "posting_date" },
			{ label: __("Claimed"), field: "total_claimed_amount", currency: true },
			{ label: __("Sanctioned"), field: "total_sanctioned_amount", currency: true },
			{ label: __("Approval"), field: "approval_status" },
			{ label: __("Status"), field: "status" },
		],
		benefits.expenses || [],
		"expense-claim",
		__("No expense claims")
	);
	employee_record_table(
		$grid,
		__("Passage benefit"),
		[
			{ label: __("Bank"), field: "name" },
			{ label: __("Earned"), field: "total_earned", currency: true },
			{ label: __("Taken"), field: "total_taken", currency: true },
			{ label: __("Balance"), field: "current_balance", currency: true },
			{ label: __("Status"), field: "status" },
		],
		benefits.passage_benefit || [],
		"passage-benefit-bank",
		__("No passage benefit bank")
	);
}

function render_activity($pane, activity) {
	const $section = $(
		'<section class="employee-section"><h3>Employee activity</h3><div class="employee-timeline"></div></section>'
	)
		.appendTo($pane)
		.find(".employee-timeline");
	if (!activity.length) {
		$section.append('<div class="employee-muted">No employee activity yet</div>');
		return;
	}
	activity.forEach((item) => {
		const $row = $(
			'<button type="button" class="timeline-row"><span class="timeline-dot"></span><span class="timeline-content"><strong></strong><small></small></span><span class="timeline-status"></span></button>'
		);
		$row.find("strong").text(`${item.label} · ${item.name}`);
		$row.find("small").text(item.date || "");
		$row.find(".timeline-status").text(item.status || "");
		$row.on("click", () => {
			const route = item.route.replace(/^\/app\//, "").split("/");
			open_employee_record(route.shift(), route.join("/"));
		});
		$section.append($row);
	});
}

function render_documents($pane, person, documents, actions) {
	const $section = $('<section class="employee-section"><div class="employee-section-head"><h3></h3></div><div class="mbc-document-grid"></div></section>').appendTo($pane);
	$section.find("h3").text(__("Documents"));
	const $grid = $section.find(".mbc-document-grid");
	if (!documents.length) $grid.append($("<div class='employee-muted'></div>").text(__("No document types available")));
	documents.forEach((document) => {
		const $card = $('<div class="mbc-document-card"><div class="mbc-document-status"></div><div class="control-label"></div></div>')
			.toggleClass("has-document", !!document.file_url).appendTo($grid);
		$card.find(".mbc-document-status").text(document.file_url ? __("Uploaded") : __("Not uploaded"));
		$card.find(".control-label").text(__(document.label));
		if (document.file_url && /^(\/(?!\/)|https?:\/\/)/i.test(document.file_url)) {
			$('<a class="btn btn-sm karyo-btn-secondary" target="_blank" rel="noopener noreferrer"></a>')
				.attr("href", document.file_url).text(__("View document")).appendTo($card);
		} else {
			$('<span class="employee-muted"></span>').text(__("No document uploaded")).appendTo($card);
		}
		if (actions.edit) {
			const $upload = $('<button type="button" class="btn btn-sm btn-primary"></button>')
				.text(__("Upload"))
				.attr("aria-label", __("Upload {0}", [document.label]))
				.appendTo($('<div class="mt-3"></div>').appendTo($card));
			$upload.on("click", () => {
				karyo.employee_documents.open_uploader({
					doctype: "Employee",
					docname: person.name,
					fieldname: document.fieldname,
					allow_multiple: false,
					on_success: async (file) => {
						await frappe.db.set_value("Employee", person.name, document.fieldname, file.file_url);
						document.file_url = file.file_url;
						render_documents($pane.empty(), person, documents, actions);
						frappe.show_alert({ message: __("Document uploaded"), indicator: "green" });
					},
				});
			});
		}
	});
}
