"""Dual-approved exceptional payroll batches (PAY-033)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Exceptional Payroll Line",
		istable=1,
		fields=[
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1),
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1, in_list_view=1),
			f("salary_component", "Link", "Salary Component", options="Salary Component", read_only=1),
			f("amount", "Currency", "Amount", reqd=1, in_list_view=1),
			f("calculate_tax", "Check", "Calculate Tax", default="1", in_list_view=1),
			f("reason", "Small Text", "Exceptional Reason", reqd=1),
			f("transaction_reference", "Data", "Transaction Reference"),
			f("business_key", "Data", "Business Key", read_only=1),
			f("additional_salary", "Link", "Additional Salary", options="Additional Salary", read_only=1),
			f(
				"allocation",
				"Link",
				"Transaction Allocation",
				options="Payroll Transaction Allocation",
				read_only=1,
			),
		],
	)
	make_doctype(
		"Exceptional Payroll Batch",
		title_field="description",
		fields=[
			f("company", "Link", "Company", options="Company", reqd=1, in_list_view=1),
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1),
			f("pay_period_label", "Data", "Pay Period", read_only=1, in_list_view=1),
			f("identity_cb", "Column Break"),
			f("description", "Data", "Description", reqd=1),
			f("exception_reason", "Small Text", "Exceptional Payment Reason", reqd=1),
			f("supporting_attachment", "Attach", "Supporting Evidence", reqd=1),
			f(
				"status",
				"Select",
				"Status",
				options="Draft\nReviewed\nApproved\nPosted\nRejected\nCancelled",
				default="Draft",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f("lines_sb", "Section Break", "Exceptional Transactions"),
			f("lines", "Table", "Employee Lines", options="Exceptional Payroll Line", reqd=1),
			f("controls_sb", "Section Break", "Dual Approval and Controls"),
			f("line_count", "Int", "Line Count", read_only=1),
			f("control_total", "Currency", "Control Total", read_only=1),
			f("approval_cb", "Column Break"),
			f("reviewed_by", "Link", "Reviewed By Payroll Approver", options="User", read_only=1),
			f("reviewed_on", "Datetime", "Reviewed On", read_only=1),
			f("approved_by", "Link", "Approved By Payroll Finance", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
			f("posted_by", "Link", "Posted By", options="User", read_only=1),
			f("posted_on", "Datetime", "Posted On", read_only=1),
			f("decision_reason", "Small Text", "Decision / Cancellation Reason"),
		],
	)


def add_additional_salary_trace_fields():
	create_custom_fields(
		{
			"Additional Salary": [
				{
					"fieldname": "karyo_transaction_category",
					"fieldtype": "Select",
					"label": "MBC Transaction Category",
					"options": "\nRecurring PDB\nOnce-off PDB\nExceptional Payroll\nOther",
					"insert_after": "ref_docname",
					"read_only": 1,
				},
				{
					"fieldname": "karyo_exceptional_batch",
					"fieldtype": "Link",
					"label": "Exceptional Payroll Batch",
					"options": "Exceptional Payroll Batch",
					"insert_after": "karyo_transaction_category",
					"read_only": 1,
				},
			]
		},
		ignore_validate=True,
	)


def add_permissions():
	meta = frappe.get_doc("DocType", "Exceptional Payroll Batch")
	matrix = {
		"Payroll Input": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Processor": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Reviewer": {"read": 1, "report": 1},
		"Payroll Approver": {"read": 1, "write": 1, "report": 1},
		"Payroll Finance": {"read": 1, "write": 1, "report": 1},
		"Payroll Auditor": {"read": 1, "report": 1, "export": 1},
	}
	for role, values in matrix.items():
		row = next((permission for permission in meta.permissions if permission.role == role), None)
		if not row:
			row = meta.append("permissions", {"role": role})
		for fieldname, value in values.items():
			row.set(fieldname, value)
	meta.save(ignore_permissions=True)


def setup():
	print("Karyo exceptional payroll setup:")
	create_doctypes()
	add_additional_salary_trace_fields()
	add_permissions()
	frappe.db.commit()
	print("Done (dual-approved exceptional batches and payroll trace fields created).")
