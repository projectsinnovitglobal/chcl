"""Transactional coverage of configured leave controls in HR and ESS."""
import unittest
from datetime import timedelta
from unittest.mock import patch
from uuid import uuid4

import frappe
from frappe.utils import add_days, add_months, getdate, nowdate

from karyo.hr.leave_controls import (
	decide_leave_application,
	leave_days_by_code,
	leave_type_eligibility,
	validate_mbc_leave_rules,
)


class TestLeaveParameters(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user('Administrator')
		frappe.db.savepoint('leave_parameters')
		self.events = patch('frappe.publish_realtime')
		self.event_mock = self.events.start()
		self.addCleanup(self.events.stop)
		self.mail = patch('frappe.sendmail')
		self.mail.start()
		self.addCleanup(self.mail.stop)
		self.uid = 'LVP-' + uuid4().hex[:10]
		source = frappe.db.get_value('Employee', {'status': 'Active'}, 'name')
		self.employee = frappe.copy_doc(frappe.get_doc('Employee', source))
		self.employee.name = self.uid
		self.employee.docstatus = 0
		self.employee.user_id = None
		self.employee.date_of_joining = '2000-01-01'
		self.employee.karyo_date_joined_service = '2000-01-01'
		self.employee.relieving_date = None
		self.employee.contract_end_date = None
		self.employee.karyo_post_exit_payroll_enabled = 0
		for df in self.employee.meta.fields:
			if df.unique:
				self.employee.set(df.fieldname, None)
		self.employee.db_insert()
		self.leave_type = frappe.get_doc({'doctype': 'Leave Type', 'leave_type_name': self.uid, 'karyo_mbc_leave_code': self.uid, 'karyo_code_description': 'Leave parameter validation test', 'is_lwp': 1, 'include_holiday': 1, 'karyo_bank_type': 'None', 'karyo_requires_leave_bank': 0, 'karyo_max_days_per_application': 3}).insert()
		self.day = getdate(add_days(nowdate(), 40))

	def tearDown(self):
		frappe.set_user('Administrator')
		frappe.db.rollback(save_point='leave_parameters')
		frappe.clear_cache(doctype='MBC Leave Settings')
		frappe.clear_document_cache('Leave Type', self.leave_type.name)
		frappe.set_user(self.user)

	def request(self, days=1, on_date=None):
		first = getdate(on_date or self.day)
		return frappe.get_doc({'doctype': 'Leave Application', 'employee': self.employee.name, 'leave_type': self.leave_type.name, 'from_date': first, 'to_date': first + timedelta(days=days - 1), 'leave_approver': 'Administrator', 'description': 'Isolated leave parameter regression', 'status': 'Open'})

	def rule(self, **values):
		self.leave_type.update(values)
		self.leave_type.save()

	def test_per_application_limit_is_applied_on_save(self):
		with self.assertRaisesRegex(frappe.ValidationError, 'cannot exceed 3'):
			self.request(4).insert()
		self.assertEqual(self.request(3).insert().total_leave_days, 3)

	def test_new_parameter_is_checked_again_before_approval(self):
		doc = self.request(3).insert()
		self.rule(karyo_max_days_per_application=2)
		with self.assertRaisesRegex(frappe.ValidationError, 'cannot exceed 2'):
			decide_leave_application(doc.name, 'Approved')
		self.assertEqual(frappe.db.get_value('Leave Application', doc.name, ['status', 'docstatus']), ('Open', 0))
		self.assertFalse(frappe.db.exists('Leave Ledger Entry', {'transaction_name': doc.name}))

	def test_rejection_remains_possible_after_limit_change(self):
		doc = self.request(3).insert()
		self.rule(karyo_max_days_per_application=1)
		result = decide_leave_application(doc.name, 'Rejected')
		self.assertEqual((result['status'], result['docstatus']), ('Rejected', 1))
		self.assertFalse(frappe.db.exists('Leave Ledger Entry', {'transaction_name': doc.name}))

	def test_service_eligibility_is_required_at_start_of_leave(self):
		self.rule(karyo_min_service_months=12)
		joined = getdate(add_months(self.day, -12)) + timedelta(days=1)
		frappe.db.set_value('Employee', self.employee.name, {'date_of_joining': joined, 'karyo_date_joined_service': joined})
		with self.assertRaisesRegex(frappe.ValidationError, '12 month'):
			self.request(3).insert()
		preview = leave_type_eligibility(self.employee.name, self.leave_type.name, self.day, self.day + timedelta(days=2))
		self.assertFalse(preview.eligible)
		self.assertIn('12 month', preview.reason)

	def test_contract_must_cover_entire_leave(self):
		self.rule(karyo_requires_valid_contract=1)
		frappe.db.set_value('Employee', self.employee.name, 'contract_end_date', self.day + timedelta(days=1))
		with self.assertRaisesRegex(frappe.ValidationError, 'valid employment contract'):
			self.request(3).insert()
		self.assertEqual(self.request(2).insert().total_leave_days, 2)

	def test_category_and_gender_configuration_is_enforced(self):
		other_gender = 'Female' if self.employee.gender == 'Male' else 'Male'
		self.rule(karyo_eligible_gender=other_gender)
		with self.assertRaisesRegex(frappe.ValidationError, 'gender'):
			self.request().insert()
		self.rule(karyo_eligible_gender='', karyo_eligible_employment_categories='NOT-' + self.uid)
		with self.assertRaisesRegex(frappe.ValidationError, 'employment categories'):
			self.request().insert()

	def test_retired_type_cannot_be_requested_via_api(self):
		self.rule(karyo_is_retired=1)
		with self.assertRaisesRegex(frappe.ValidationError, 'retired'):
			self.request().insert()

	def test_numeric_parameters_and_prerequisite_codes_are_validated(self):
		for field in ('karyo_min_service_months', 'karyo_max_days_per_application', 'karyo_max_days_per_year', 'karyo_max_days_total', 'karyo_medical_certificate_after_days'):
			self.leave_type.set(field, -1)
			with self.assertRaisesRegex(frappe.ValidationError, 'non-negative'):
				self.leave_type.save()
			self.leave_type.reload()
		self.leave_type.karyo_prerequisite_codes = self.uid
		with self.assertRaisesRegex(frappe.ValidationError, 'own prerequisite'):
			self.leave_type.save()
		self.leave_type.reload()
		self.leave_type.karyo_prerequisite_codes = 'MISSING-' + self.uid
		with self.assertRaisesRegex(frappe.ValidationError, 'does not exist'):
			self.leave_type.save()

	def test_required_allocation_cannot_be_bypassed_by_unpaid_type(self):
		self.rule(karyo_requires_leave_bank=1)
		with self.assertRaisesRegex(frappe.ValidationError, 'Insufficient allocation balance'):
			self.request().insert()

	def test_medical_threshold_and_required_documents_block_approval(self):
		self.rule(karyo_requires_attachment=1, karyo_medical_certificate_after_days=1)
		one = self.request().insert()
		decide_leave_application(one.name, 'Approved')
		two = self.request(2, self.day + timedelta(days=5)).insert()
		with self.assertRaisesRegex(frappe.ValidationError, 'supporting document'):
			decide_leave_application(two.name, 'Approved')
		frappe.get_doc({'doctype': 'File', 'name': self.uid + '-FILE', 'docstatus': 0, 'file_name': 'leave-parameter-proof.txt', 'file_url': '/private/files/leave-parameter-proof.txt', 'is_private': 1, 'attached_to_doctype': 'Leave Application', 'attached_to_name': two.name}).db_insert()
		self.assertEqual(decide_leave_application(two.name, 'Approved')['docstatus'], 1)

	def test_year_limit_uses_both_years_and_existing_cross_year_leave(self):
		self.rule(karyo_max_days_per_year=1)
		year = self.day.year + 1
		first = getdate(f'{year}-12-31')
		doc = self.request(2, first).insert()
		decide_leave_application(doc.name, 'Approved')
		self.assertEqual(leave_days_by_code(self.employee.name, self.uid, year), 1)
		self.assertEqual(leave_days_by_code(self.employee.name, self.uid, year + 1), 1)
		with self.assertRaisesRegex(frappe.ValidationError, 'calendar-year limit'):
			self.request(1, getdate(f'{year + 1}-01-02')).insert()
		preview = leave_type_eligibility(self.employee.name, self.leave_type.name, f'{year + 1}-01-02', f'{year + 1}-01-02')
		self.assertFalse(preview.eligible)
		self.assertIn('calendar-year limit', preview.reason)

	def test_lifetime_limit_counts_only_approved_submitted_leave(self):
		self.rule(karyo_max_days_total=2)
		pending = self.request(2).insert()
		second = self.request(2, self.day + timedelta(days=10)).insert()
		decide_leave_application(second.name, 'Approved')
		with self.assertRaisesRegex(frappe.ValidationError, 'overall limit'):
			decide_leave_application(pending.name, 'Approved')

	def test_prerequisite_uses_configured_full_pay_advance_limit(self):
		full = frappe.db.get_value('Leave Type', {'karyo_mbc_leave_code': 'SICK03'}, 'name')
		half = frappe.db.get_value('Leave Type', {'karyo_mbc_leave_code': 'SICK04'}, 'name')
		self.assertTrue(full and half)
		frappe.db.set_value('Leave Type', full, 'karyo_max_days_total', 120)
		frappe.get_doc({'doctype': 'Leave Application', 'name': self.uid + '-HIST', 'docstatus': 1, 'employee': self.employee.name, 'leave_type': full, 'from_date': self.day - timedelta(days=150), 'to_date': self.day - timedelta(days=31), 'total_leave_days': 120, 'status': 'Approved'}).db_insert()
		frappe.get_doc({'doctype': 'Sick Leave Bank', 'name': self.uid + '-BANK', 'docstatus': 0, 'employee': self.employee.name, 'status': 'Active', 'bank_days': 0, 'advance_balance_days': 120}).db_insert()
		doc = self.request()
		doc.leave_type = half
		doc.total_leave_days = 1
		validate_mbc_leave_rules(doc)
		frappe.db.set_value('Leave Type', full, 'karyo_max_days_total', 121)
		with self.assertRaisesRegex(frappe.ValidationError, 'must be exhausted'):
			validate_mbc_leave_rules(doc)

	def test_settings_reject_invalid_entitlement_and_service_band(self):
		settings = frappe.get_single('MBC Leave Settings')
		settings.annual_leave_entitlement = -1
		with self.assertRaisesRegex(frappe.ValidationError, 'greater than zero'):
			settings.save()
		settings.reload()
		settings.vacation_leave_bands[0].service_from_years = -1
		with self.assertRaisesRegex(frappe.ValidationError, 'non-negative'):
			settings.save()

	def test_settings_project_approved_parameters_onto_leave_type(self):
		settings = frappe.get_single('MBC Leave Settings')
		settings.study_leave_limit = 12
		with patch('karyo.hr.leave_controls.sync_all_employee_leave_schemes'):
			settings.save()
		values = frappe.db.get_value('Leave Type', {'karyo_mbc_leave_code': 'STD'}, ['karyo_max_days_per_year', 'karyo_max_days_per_application'], as_dict=True)
		self.assertEqual((values.karyo_max_days_per_year, values.karyo_max_days_per_application), (12, 12))
		self.event_mock.assert_any_call('karyo_balance_updated', {'doctypes': ['Leave Type', 'Leave Application', 'Leave Allocation', 'Leave Policy']}, after_commit=True)

	def test_ess_is_validated_and_cannot_edit_parameters(self):
		user = frappe.get_doc({'doctype': 'User', 'email': self.uid.lower() + '@example.invalid', 'first_name': 'Leave Parameter Test', 'send_welcome_email': 0, 'roles': [{'role': 'Employee'}]}).insert()
		frappe.db.set_value('Employee', self.employee.name, 'user_id', user.name)
		user.add_roles('Employee')
		frappe.set_user(user.name)
		self.assertFalse(frappe.has_permission('MBC Leave Settings', 'write'))
		self.assertFalse(frappe.has_permission('Leave Type', 'write'))
		with self.assertRaisesRegex(frappe.ValidationError, 'cannot exceed 3'):
			self.request(4).insert()
		preview = leave_type_eligibility(self.employee.name, self.leave_type.name, self.day, self.day + timedelta(days=3))
		self.assertFalse(preview.eligible)
