"""Controlled insurance endorsement/change transaction for active loans."""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctype():
	make_doctype(
		"Karyo Loan Insurance Change",
		is_submittable=1,
		autoname="naming_series:",
		title_field="loan",
		fields=[
			f("naming_series", "Select", "Series", options="KLIN-.YYYY.-.#####", default="KLIN-.YYYY.-.#####"),
			f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
			f("employee", "Link", "Employee", options="Employee", read_only=1, in_list_view=1),
			f("loan_type", "Link", "Loan Type", options="Loan Type", read_only=1),
			f("effective_date", "Date", "Effective Date", reqd=1),
			f("cb1", "Column Break"),
			f("insurance_rate_rule", "Link", "Approved Insurance Rate Rule", options="Loan Insurance Rate", reqd=1),
			f("new_rate", "Float", "New Rate (per 10,000)", read_only=1, in_list_view=1),
			f("provider", "Data", "Insurance Provider", read_only=1),
			f("policy_reference", "Data", "Policy / Endorsement Reference", reqd=1),
			f("position_sb", "Section Break", "Before and After"),
			f("old_rate", "Float", "Old Rate", read_only=1),
			f("old_monthly_insurance", "Currency", "Old Monthly Insurance", read_only=1),
			f("old_monthly_refund", "Currency", "Old Monthly Refund", read_only=1),
			f("cb2", "Column Break"),
			f("new_monthly_insurance", "Currency", "New Monthly Insurance", read_only=1),
			f("new_monthly_refund", "Currency", "New Monthly Refund", read_only=1),
			f("remaining_duration", "Int", "Remaining Duration", read_only=1),
			f("approval_reference", "Data", "Approval Reference", reqd=1),
			f("remarks", "Small Text", "Reason / Remarks", reqd=1),
			f("prior_state_snapshot", "Long Text", "Prior State Snapshot", read_only=1, hidden=1),
			f("applied_schedule_version", "Int", "Applied Schedule Version", read_only=1),
			f("idempotency_key", "Data", "Idempotency Key", read_only=1, unique=1),
			f("reversal_processed", "Check", "Reversal Processed", read_only=1),
		],
	)


def setup():
	print("Karyo Loan insurance change setup:")
	create_doctype()
	frappe.db.commit()
	print("Done.")
