from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.loan_portfolio.loan_portfolio import _enrich


class TestLoanPortfolio(FrappeTestCase):
	@patch("frappe.get_all")
	def test_current_schedule_arrears_and_deduction_health(self, get_all):
		get_all.side_effect = [
			[
				frappe._dict(due_date="2026-08-31", capital=100, interest=20, insurance=5, paid_capital=50, paid_interest=20, paid_insurance=0),
				frappe._dict(due_date="2026-10-31", capital=100, interest=20, insurance=5, paid_capital=0, paid_interest=0, paid_insurance=0),
			],
			[
				frappe._dict(component_type="Capital", monthly_amount=100, status="Active"),
				frappe._dict(component_type="Interest", monthly_amount=20, status="Active"),
			],
		]
		row = frappe._dict(loan="LOAN-1", outstanding_capital=200, outstanding_interest=40, outstanding_insurance=10)
		_enrich(row, "2026-09-10")
		self.assertEqual(row.remaining_periods, 2)
		self.assertEqual(row.arrears_periods, 1)
		self.assertEqual(row.arrears_amount, 55)
		self.assertEqual(row.next_due_date, "2026-08-31")
		self.assertEqual(row.deduction_health, "Partial")
		self.assertEqual(get_all.call_args_list[0].kwargs["filters"]["is_current"], 1)
