"""Employee Group member normalization."""

import frappe
from frappe import _


def prepare_employee_group(doc, method=None):
	"""Keep the code selector, name selector and fetched details in sync."""
	selector = "karyo_employee_name_selector"
	if not frappe.get_meta("Employee Group Table").has_field(selector):
		return

	for row in doc.get("employee_list") or []:
		code = row.get("employee") or row.get(selector)
		if row.get("employee") and row.get(selector) and row.employee != row.get(selector):
			frappe.throw(_("Row {0}: Employee Code and Employee Name refer to different employees.").format(row.idx))
		if not code:
			row.employee_name = None
			row.user_id = None
			continue
		details = frappe.db.get_value("Employee", code, ["employee_name", "user_id"], as_dict=True)
		if not details:
			frappe.throw(_("Row {0}: Employee {1} does not exist.").format(row.idx, code))
		row.employee = code
		row.set(selector, code)
		row.employee_name = details.employee_name
		row.user_id = details.user_id
