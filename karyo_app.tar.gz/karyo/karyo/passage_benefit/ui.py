"""Real-data UI facade for the prototype-aligned Passage Benefit workspace.

This module deliberately contains no PB business calculations. It composes the
existing controllers, reports and services into bounded, permission-aware page
payloads for `/app/pb-overview`.
"""

import frappe
from frappe import _
from frappe.utils import cint, flt, getdate, nowdate

from karyo.passage_benefit import inquiry
from karyo.passage_benefit import computation_workflow
from karyo.passage_benefit.eligibility import evaluate as evaluate_eligibility
from karyo.passage_benefit.init_bank import create_banks, list_eligible_employees
from karyo.tasks import run_passage_benefit_period


PB_ADMIN_ROLES = {"System Manager", "HR Manager", "HR User", "Passage Benefit Officer"}
PB_FINANCE_ROLES = {"System Manager", "Karyo Finance", "Payroll Finance", "Payroll Processor"}


def _require_login():
	if frappe.session.user in (None, "", "Guest"):
		frappe.throw(_("Please log in to use the Passage Benefit workspace."), frappe.PermissionError)


def _require_admin():
	_require_login()
	if not set(frappe.get_roles()) & PB_ADMIN_ROLES:
		frappe.throw(_("You are not permitted to maintain Passage Benefit setup."), frappe.PermissionError)


def _page(value, default=20, maximum=100):
	return max(1, min(cint(value or default), maximum))


def _start(value):
	return max(0, cint(value or 0))


def _paged(rows, total, start, page_length):
	return {"rows": rows, "total": cint(total), "start": start, "page_length": page_length}


@frappe.whitelist()
def get_context():
	_require_login()
	roles = frappe.get_roles()
	full_name = frappe.db.get_value("User", frappe.session.user, "full_name") or frappe.session.user
	return {
		"user": frappe.session.user,
		"full_name": full_name,
		"roles": roles,
		"can_setup": bool(set(roles) & PB_ADMIN_ROLES),
		"can_finance": bool(set(roles) & PB_FINANCE_ROLES),
		"can_compute": bool(set(roles) & PB_ADMIN_ROLES),
		"today": nowdate(),
		"vacation_supported": bool(
			frappe.db.get_single_value("Passage Benefit Settings", "vacation_leave_type")
		),
	}


@frappe.whitelist()
def dashboard():
	_require_login()
	flagged = frappe.get_all("Employee", filters={"status": "Active", "pb_eligible": 1}, pluck="name")
	active_flagged = 0
	for employee in flagged:
		try:
			active_flagged += int(bool(evaluate_eligibility(employee, nowdate()).eligible))
		except Exception:
			# Incomplete employee/setup data is an exception, never an eligible KPI.
			pass
	banks = frappe.db.count("Passage Benefit Bank", {"status": "Active"})
	pending = frappe.db.count(
		"Passage Benefit Application",
		{"workflow_state": ("in", ("Pending Approval", "Recommended", "Approved")), "docstatus": ("<", 2)},
	)
	open_exceptions = frappe.db.count(
		"Passage Benefit Application", {"workflow_state": "Approved", "processed": 0, "docstatus": 0}
	) + frappe.db.count("Passage Benefit Run Exception")
	awaiting_bank = max(active_flagged - banks, 0)
	awaiting_finance = frappe.db.count(
		"Passage Benefit Application", {"workflow_state": "Approved", "docstatus": 0}
	)
	ready_payroll = frappe.db.count(
		"Passage Benefit Application",
		{"workflow_state": "Approved", "processing_route": "Payroll", "docstatus": 0},
	)
	rejected = frappe.db.count("Passage Benefit Application", {"workflow_state": "Rejected", "docstatus": 0})
	return {
		"metrics": [
			{"label": _("Eligible Employees"), "value": active_flagged, "hint": _("Active employees with the PB flag")},
			{"label": _("PB Bank Created"), "value": banks, "hint": _("Active Passage Benefit banks")},
			{"label": _("Pending Requests"), "value": pending, "hint": _("Awaiting workflow action")},
			{"label": _("Exceptions"), "value": open_exceptions, "hint": _("Setup or processing records requiring review")},
		],
		"pending_actions": [
			{"label": _("PB Bank to be initialised"), "count": awaiting_bank, "status": "Pending", "screen": "initialise"},
			{"label": _("PB not earned records to review"), "count": frappe.db.count("Passage Benefit Not Earned Period"), "status": "Setup", "screen": "notearned"},
			{"label": _("Requests awaiting Finance"), "count": awaiting_finance, "status": "Pending", "screen": "request"},
			{"label": _("Claims ready for payroll"), "count": ready_payroll, "status": "Ready", "screen": "request"},
			{"label": _("Rejected / returned requests"), "count": rejected, "status": "Blocked", "screen": "request"},
		],
		"exceptions": [
			{"label": _("Missing PDB setup"), "impact": _("Blocks payroll posting")},
			{"label": _("No PB Bank"), "impact": _("Blocks employee request")},
			{"label": _("Insufficient balance"), "impact": _("Blocks or caps claim according to policy")},
			{"label": _("PB not earned period"), "impact": _("Excludes days from PB computation")},
			{"label": _("Duplicate processing"), "impact": _("Blocks repeat payment or posting")},
		],
	}


@frappe.whitelist()
def parameters():
	_require_admin()
	doc = frappe.get_doc("Passage Benefit Settings")
	return {
		"values": doc.as_dict(),
		"history": [
			{
				"item_sequence": row.item_sequence,
				"effective_from": row.effective_from,
				"effective_to": row.effective_to,
				"pb_percentage": row.pb_percentage,
				"entitlement_operation_code": row.entitlement_operation_code,
				"payroll_pdb_code": row.payroll_pdb_code,
				"min_years_service": row.min_years_service,
				"min_salary_threshold": row.min_salary_threshold,
				"salary_basis": row.salary_basis,
				"eligibility_mode": row.eligibility_mode,
				"require_confirmation": row.require_confirmation,
				"require_permanent_employee": row.require_permanent_employee,
				"leap_year_treatment": row.leap_year_treatment,
				"modified_by": row.modified_by,
				"modified": row.modified,
			}
			for row in doc.parameter_versions
		],
	}


@frappe.whitelist()
def save_parameters(values):
	_require_admin()
	values = frappe.parse_json(values) if isinstance(values, str) else values
	doc = frappe.get_doc("Passage Benefit Settings")
	allowed = {
		"pb_percentage", "min_years_service", "min_salary_threshold", "salary_basis",
		"entitlement_operation_code", "adjustment_operation_code", "payroll_pdb_type",
		"payroll_pdb_code", "non_taxable", "default_min_balance_credit",
		"insufficient_balance_treatment", "min_balance_timing", "allow_negative_balance",
		"rounding_stage", "leap_year_treatment", "require_payroll_closure",
		"eligibility_mode", "require_confirmation", "require_permanent_employee",
	}
	for fieldname in allowed:
		if fieldname in values:
			doc.set(fieldname, values[fieldname])
	doc.save()
	return parameters()


@frappe.whitelist()
def usage_items(search=None, start=0, page_length=20):
	_require_login()
	start, page_length = _start(start), _page(page_length)
	filters = {}
	or_filters = None
	if search:
		like = f"%{search}%"
		or_filters = {"usage_item_code": ("like", like), "usage_item_name": ("like", like)}
	rows = frappe.get_list(
		"Passage Benefit Usage Item", filters=filters, or_filters=or_filters,
		fields=["name", "usage_item_code", "usage_item_name", "encash_rate", "min_balance_credit", "effective_from", "effective_to", "is_active", "requires_document", "remarks"],
		order_by="usage_item_name asc", start=start, page_length=page_length,
	)
	total = frappe.db.count("Passage Benefit Usage Item", filters=filters)
	if search:
		total = len(frappe.get_all("Passage Benefit Usage Item", or_filters=or_filters, pluck="name"))
	return _paged(rows, total, start, page_length)


@frappe.whitelist()
def not_earned_periods(search=None, start=0, page_length=20):
	_require_admin()
	start, page_length = _start(start), _page(page_length)
	filters = {}
	if search:
		filters["employee"] = ("like", f"%{search}%")
	rows = frappe.get_list(
		"Passage Benefit Not Earned Period", filters=filters,
		fields=["name", "pay_period", "employee", "employee_name", "date_from", "date_to", "days", "remarks", "modified_by", "modified"],
		order_by="date_from desc, employee asc", start=start, page_length=page_length,
	)
	return _paged(rows, frappe.db.count("Passage Benefit Not Earned Period", filters), start, page_length)


@frappe.whitelist()
def eligible_employees(
	company=None, grade=None, branch=None, employee=None, date_joined_from=None,
	date_joined_to=None, bank_created=None, as_on=None,
):
	return list_eligible_employees(
		company=company, grade=grade, branch=branch, employee=employee,
		date_joined_from=date_joined_from, date_joined_to=date_joined_to,
		bank_created=bank_created, as_on=as_on,
	)


@frappe.whitelist()
def initialise_banks(employees, opening_date=None, opening_balance=0):
	return create_banks(employees, opening_date, opening_balance)


@frappe.whitelist()
def adjustments(employee=None, start=0, page_length=20):
	_require_admin()
	start, page_length = _start(start), _page(page_length)
	filters = {"docstatus": ("<", 2)}
	if employee:
		filters["employee"] = employee
	rows = frappe.get_list(
		"Passage Benefit Adjustment", filters=filters,
		fields=["name", "posting_date", "employee", "employee_name", "amount", "balance_before", "balance_after", "remarks", "owner", "modified", "docstatus"],
		order_by="posting_date desc, creation desc", start=start, page_length=page_length,
	)
	return _paged(rows, frappe.db.count("Passage Benefit Adjustment", filters), start, page_length)


@frappe.whitelist()
def applications(search=None, start=0, page_length=20):
	_require_login()
	start, page_length = _start(start), _page(page_length)
	filters = {"docstatus": ("<", 2)}
	or_filters = None
	if search:
		like = f"%{search}%"
		or_filters = {"name": ("like", like), "employee": ("like", like), "employee_name": ("like", like)}
	fields = [
		"name", "posting_date", "employee", "employee_name", "usage_item", "request_amount",
		"claimable_amount", "processing_route", "pay_period", "workflow_state",
	]
	all_names = frappe.get_list(
		"Passage Benefit Application", filters=filters, or_filters=or_filters,
		fields=["name"], limit_page_length=0,
	)
	rows = frappe.get_list(
		"Passage Benefit Application", filters=filters, or_filters=or_filters, fields=fields,
		order_by="posting_date desc, creation desc", start=start, page_length=page_length,
	)
	return _paged(rows, len(all_names), start, page_length)


@frappe.whitelist()
def application_detail(name):
	_require_login()
	doc = frappe.get_doc("Passage Benefit Application", name)
	if not doc.has_permission("read"):
		frappe.throw(_("You are not permitted to view this request."), frappe.PermissionError)
	return doc.as_dict()


@frappe.whitelist()
def bank_listing(search=None, start=0, page_length=20):
	_require_login()
	start, page_length = _start(start), _page(page_length)
	filters = {}
	or_filters = None
	if search:
		like = f"%{search}%"
		or_filters = {"employee": ("like", like), "employee_name": ("like", like)}
	all_rows = frappe.get_list(
		"Passage Benefit Bank", filters=filters, or_filters=or_filters,
		fields=["name"], limit_page_length=0,
	)
	rows = frappe.get_list(
		"Passage Benefit Bank", filters=filters, or_filters=or_filters,
		fields=["employee", "employee_name", "opening_date", "opening_balance", "total_earned", "total_taken", "total_adjustments", "current_balance", "status"],
		order_by="employee_name asc", start=start, page_length=page_length,
	)
	return _paged(rows, len(all_rows), start, page_length)


@frappe.whitelist()
def balance_detail(employee):
	return inquiry.query_balance(employee)


@frappe.whitelist()
def compute(from_date, to_date, from_employee=None, to_employee=None, dry_run=1):
	_require_admin()
	employees = None
	if from_employee or to_employee:
		low, high = from_employee or to_employee, to_employee or from_employee
		if low > high:
			low, high = high, low
		employees = frappe.get_all(
			"Employee",
			filters={"name": ("between", (low, high)), "status": "Active", "pb_eligible": 1},
			pluck="name",
			order_by="name asc",
		)
	return run_passage_benefit_period(
		from_date, to_date, employees=employees, dry_run=cint(dry_run)
	)


@frappe.whitelist()
def applications(search=None, workflow_state=None, start=0, page_length=20):
	_require_login()
	start, page_length = _start(start), _page(page_length)
	filters = {"docstatus": ("<", 2)}
	if workflow_state:
		filters["workflow_state"] = workflow_state
	if search:
		filters["employee_name"] = ("like", f"%{search}%")
	rows = frappe.get_list(
		"Passage Benefit Application", filters=filters,
		fields=["name", "posting_date", "employee", "employee_name", "usage_item", "request_amount", "claimable_amount", "amount_taken", "processing_route", "pay_period", "workflow_state", "processed_reference", "modified"],
		order_by="posting_date desc, creation desc", start=start, page_length=page_length,
	)
	return _paged(rows, frappe.db.count("Passage Benefit Application", filters), start, page_length)


@frappe.whitelist()
def application_detail(name):
	_require_login()
	doc = frappe.get_doc("Passage Benefit Application", name)
	if not doc.has_permission("read"):
		frappe.throw(_("Not permitted."), frappe.PermissionError)
	return doc.as_dict()


@frappe.whitelist()
def computation_employees(as_on=None):
	"""All visible employees with explicit eligibility and blocker diagnostics."""
	_require_admin()
	rows = {row["employee"]: {**row, "applications": 0} for row in list_eligible_employees(as_on=as_on)}
	applications = frappe.get_list("Passage Benefit Application", filters={"docstatus": ["<", 2]},
		fields=["employee", "workflow_state"], order_by="modified desc", limit_page_length=0)
	people = {row.name: row for row in frappe.get_list("Employee", filters={"name": ["in", list({r.employee for r in applications})]},
		fields=["name", "employee_name", "company"], limit_page_length=0)} if applications else {}
	for application in applications:
		employee = application.employee
		if employee not in people:
			continue
		if employee not in rows:
			result = evaluate_eligibility(employee, as_on or nowdate())
			rows[employee] = {"employee": employee, "employee_name": people[employee].employee_name,
				"company": people[employee].company, "eligible": bool(result.eligible),
				"eligibility_status": result.eligibility_status,
				"eligibility_reason": result.message, "block_reason": result.block_reason,
				"eligibility_mode": result.eligibility_mode,
				"eligibility_rules": result.rules, "applications": 0}
		row = rows[employee]
		row["applications"] += 1
		row.setdefault("application_status", application.workflow_state)
	return sorted(rows.values(), key=lambda row: row["employee"])


@frappe.whitelist()
def computation_workspace(from_date=None, to_date=None, company=None, payroll_cycle=None):
	"""Dates, eligible employees, saved calculations and PDB mapping for the guided screen."""
	return computation_workflow.workspace(from_date, to_date, company, payroll_cycle)


@frappe.whitelist()
def calculate_computations(from_date, to_date, employees, company=None, payroll_cycle=None):
	return computation_workflow.calculate(from_date, to_date, employees, company, payroll_cycle)


@frappe.whitelist()
def approve_computations(computations):
	return computation_workflow.approve(computations)


@frappe.whitelist()
def submit_computations_to_payroll(computations, payroll_cycle=None):
	# Backward-compatible endpoint for an already-open browser tab. The accrual
	# action was historically misnamed; it must never create employee pay.
	return computation_workflow.submit_to_pb_bank(computations, payroll_cycle)


@frappe.whitelist()
def submit_computations_to_pb_bank(computations, payroll_cycle=None):
	return computation_workflow.submit_to_pb_bank(computations, payroll_cycle)


@frappe.whitelist()
def compute(from_date, to_date, employees=None, company=None, dry_run=1):
	_require_admin()
	if employees is not None:
		employees = frappe.parse_json(employees) if isinstance(employees, str) else employees
		if not isinstance(employees, list) or not employees:
			frappe.throw(_("Select at least one employee to compute Passage Benefit."))
		for employee in employees:
			frappe.get_doc("Employee", employee).check_permission("read")
	return run_passage_benefit_period(
		from_date, to_date, employees=employees, company=company, dry_run=cint(dry_run)
	)


@frappe.whitelist()
def bank_listing(search=None, start=0, page_length=20):
	_require_login()
	start, page_length = _start(start), _page(page_length)
	filters = {}
	if search:
		filters["employee_name"] = ("like", f"%{search}%")
	rows = frappe.get_list(
		"Passage Benefit Bank", filters=filters,
		fields=["name", "employee", "employee_name", "company", "opening_date", "opening_balance", "total_earned", "total_taken", "total_adjustments", "current_balance", "status"],
		order_by="employee_name asc", start=start, page_length=page_length,
	)
	return _paged(rows, frappe.db.count("Passage Benefit Bank", filters), start, page_length)


@frappe.whitelist()
def balance_detail(employee):
	return inquiry.query_balance(employee)


@frappe.whitelist()
def audit_balance(as_on=None, employee=None, branch=None):
	employees = [employee] if employee else None
	return inquiry.compute_balance_as_at(as_on=as_on, employees=employees, branch=branch)


@frappe.whitelist()
def vacation_balance(employee, as_on=None):
	return inquiry.pb_and_vacation_balance(employee, as_on)


def _earned_rows(from_date=None, to_date=None, employee=None, company=None, department=None):
	_require_admin()
	if from_date and to_date and getdate(from_date) > getdate(to_date):
		frappe.throw(_("From Date must be on or before To Date."))
	employee_filters = {}
	for key, value in (("name", employee), ("company", company), ("department", department)):
		if value:
			employee_filters[key] = value
	employees = {r.name: r for r in frappe.get_list("Employee", filters=employee_filters,
		fields=["name", "employee_name", "company", "department"], limit_page_length=0)}
	if not employees:
		return []
	filters = [["entry_type", "=", "Earning"], ["docstatus", "=", 1], ["employee", "in", list(employees)]]
	if from_date:
		filters.append(["posting_date", ">=", getdate(from_date)])
	if to_date:
		filters.append(["posting_date", "<=", getdate(to_date)])
	rows = frappe.get_list("Passage Benefit Ledger Entry", filters=filters,
		fields=["name", "employee", "posting_date", "pay_period", "amount", "eligible_days", "salary_used", "reference_name"],
		order_by="posting_date desc, name desc", limit_page_length=0)
	currencies = {}
	for row in rows:
		emp = employees[row.employee]
		row.update(employee_name=emp.employee_name, company=emp.company, department=emp.department)
		if emp.company not in currencies:
			currencies[emp.company] = frappe.get_cached_value("Company", emp.company, "default_currency")
		row.currency = currencies[emp.company]
	return rows


@frappe.whitelist()
def earned(from_date=None, to_date=None, employee=None, company=None, department=None, start=0, page_length=40):
	rows = _earned_rows(from_date, to_date, employee, company, department)
	totals, monthly = {}, {}
	for row in rows:
		totals[row.currency] = totals.get(row.currency, 0) + flt(row.amount)
		key = (str(row.posting_date)[:7], row.currency)
		monthly[key] = monthly.get(key, 0) + flt(row.amount)
	start, page_length = _start(start), _page(page_length)
	return {**_paged(rows[start:start + page_length], len(rows), start, page_length),
		"employees": len({r.employee for r in rows}),
		"totals": [{"currency": k, "amount": v} for k, v in totals.items()],
		"monthly": [{"month": k[0], "currency": k[1], "amount": v} for k, v in sorted(monthly.items())]}


@frappe.whitelist()
def download_earned(from_date=None, to_date=None, employee=None, company=None, department=None):
	import csv
	import io
	rows = _earned_rows(from_date, to_date, employee, company, department)
	if not frappe.has_permission("Passage Benefit Ledger Entry", "export"):
		frappe.throw(_("You do not have permission to export PB earnings."), frappe.PermissionError)
	fields = ["name", "employee", "employee_name", "company", "department", "posting_date", "pay_period", "amount", "currency", "eligible_days", "salary_used", "reference_name"]
	output = io.StringIO()
	writer = csv.writer(output)
	writer.writerow([_(f.replace("_", " ").title()) for f in fields])
	for row in rows:
		values = []
		for field in fields:
			value = row.get(field, "")
			if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
				value = "'" + value
			values.append(value)
		writer.writerow(values)
	frappe.response.filename = "pb-earned.csv"
	frappe.response.filecontent = "\ufeff" + output.getvalue()
	frappe.response.type = "download"
	frappe.response.content_type = "text/csv; charset=utf-8"
