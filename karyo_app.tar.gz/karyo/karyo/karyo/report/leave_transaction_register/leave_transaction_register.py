import frappe
from frappe import _


def execute(filters=None):
	filters = frappe._dict(filters or {})
	frappe.has_permission("Leave Transaction", "read", throw=True)
	return _columns(), _data(filters)


def _data(filters):
	conditions = {}
	if filters.get("employee"):
		conditions["employee"] = filters.employee
	if filters.get("leave_code"):
		conditions["leave_code"] = filters.leave_code
	if filters.get("status"):
		conditions["legacy_status"] = filters.status
	if filters.get("cancelled"):
		conditions["cancelled"] = 1 if filters.cancelled == "Yes" else 0
	if filters.get("from_date"):
		conditions["end_date"] = [">=", filters.from_date]
	if filters.get("to_date"):
		conditions["start_date"] = ["<=", filters.to_date]

	return frappe.get_list(
		"Leave Transaction",
		filters=conditions,
		fields=[
			"name", "leave_request_id", "employee", "employee_name", "leave_code",
			"leave_type", "leave_description", "start_date", "end_date", "duration_units",
			"duration_unit", "two_hour_permission", "requested_hours", "standard_day_hours",
			"equivalent_leave_days", "legacy_status", "applied_date", "approved_date", "cancelled",
			"cancellation_date", "reason_code", "source_record_audit_ref",
		],
		order_by="start_date desc, creation desc",
		limit_page_length=0,
	)


def _columns():
	def column(fieldname, label, fieldtype="Data", width=120, options=None):
		value = {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width}
		if options:
			value["options"] = options
		return value

	return [
		column("name", "Transaction", "Link", 150, "Leave Transaction"),
		column("leave_request_id", "Leave Request ID", width=140),
		column("employee", "Employee", "Link", 120, "Employee"),
		column("employee_name", "Employee Name", width=170),
		column("leave_code", "Leave Code", width=105),
		column("leave_type", "Leave Type / Category", width=150),
		column("leave_description", "Description", width=180),
		column("start_date", "Start Date", "Date", 105),
		column("end_date", "End Date", "Date", 105),
		column("duration_units", "Duration", "Float", 90),
		column("duration_unit", "Unit", width=75),
		column("two_hour_permission", "2-Hour Permission", "Check", 110),
		column("requested_hours", "Requested Hours", "Float", 105),
		column("standard_day_hours", "Standard Day Hours", "Float", 115),
		column("equivalent_leave_days", "Equivalent Leave Days", "Float", 130),
		column("legacy_status", "Status", width=110),
		column("applied_date", "Applied Date", "Date", 105),
		column("approved_date", "Approved Date", "Date", 105),
		column("cancelled", "Cancelled", "Check", 85),
		column("cancellation_date", "Cancellation Date", "Date", 115),
		column("reason_code", "Reason Code", width=120),
		column("source_record_audit_ref", "Source / Audit Ref", width=170),
	]
