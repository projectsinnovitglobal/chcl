import frappe
from frappe import _
from frappe.utils import flt, getdate

from karyo.karyo.report.loan_report_utils import add_loan_permission_condition


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if filters.from_date and filters.to_date and getdate(filters.from_date) > getdate(filters.to_date):
		frappe.throw(_("From Date cannot be after To Date."))
	conditions = ["ss.docstatus=1", "a.is_reversal=0"]
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	for field, expression in (("employee", "ss.employee"), ("loan", "a.loan"), ("payroll_period", "a.payroll_period"),
		("payroll_cycle", "a.payroll_cycle"), ("component", "a.component"), ("department", "a.department"), ("location", "a.branch")):
		if filters.get(field):
			conditions.append(f"{expression}=%({field})s")
	if filters.pdb_code:
		conditions.append("a.pdb_code like %(pdb_pattern)s")
		filters.pdb_pattern = f"%{filters.pdb_code}%"
	# Date limits are applied after computing balances so the first displayed row
	# still carries deductions processed before the requested window.
	rows = frappe.db.sql(
		f"""
		select a.name allocation, a.posting_date, a.payroll_period, a.payroll_cycle,
			a.loan, l.loan_type, ss.employee, ss.employee_name, a.pdb_code, a.component,
			a.amount, a.salary_slip, a.schedule_row, a.schedule_month, a.department,
			a.branch location, l.approved_amount, l.total_interest, l.total_insurance
		from `tabKaryo Loan Payroll Allocation` a
		inner join `tabSalary Slip` ss on ss.name=a.salary_slip
		inner join `tabKaryo Loan` l on l.name=a.loan
		where {' and '.join(conditions)}
		order by a.loan, a.component, a.posting_date, a.creation, a.name
		""",
		filters,
		as_dict=True,
	)
	balances = {}
	period_rows = []
	for row in rows:
		key = (row.loan, row.component)
		if key not in balances:
			balances[key] = _component_total(row)
		row.balance_before = max(0, balances[key])
		balances[key] -= flt(row.amount)
		row.reducing_balance = max(0, balances[key])
		if _within_dates(row.posting_date, filters):
			period_rows.append(row)
	return _columns(), _combine_employee_deductions(period_rows)


def _combine_employee_deductions(rows):
	"""Return one payroll row per employee Salary Slip.

	Capital, interest and insurance remain separately visible, but no longer
	create duplicate employee rows in the payroll deduction list. A Salary Slip
	is the correct grouping boundary because it represents one employee in one
	payroll run; an unrestricted multi-period report can therefore still show the
	employee's individual monthly recoveries.
	"""
	groups = {}
	component_fields = {
		"Capital": "capital",
		"Interest": "interest",
		"Insurance": "insurance",
	}
	for row in rows:
		key = row.salary_slip or (
			row.employee or "",
			row.payroll_cycle or "",
			str(row.posting_date or ""),
		)
		if key not in groups:
			groups[key] = frappe._dict(
				posting_date=row.posting_date,
				payroll_period=row.payroll_period,
				payroll_cycle=row.payroll_cycle,
				employee=row.employee,
				employee_name=row.employee_name,
				department=row.department,
				location=row.location,
				salary_slip=row.salary_slip,
				capital_amount=0,
				interest_amount=0,
				insurance_amount=0,
				capital_balance_before=0,
				interest_balance_before=0,
				insurance_balance_before=0,
				capital_balance=0,
				interest_balance=0,
				insurance_balance=0,
				balance_before=0,
				reducing_balance=0,
				_loans=set(),
				_loan_types=set(),
				_pdb_codes=set(),
				_schedule_months=set(),
			)
		group = groups[key]
		component = component_fields.get(row.component)
		if component:
			group[f"{component}_amount"] += flt(row.amount)
			group[f"{component}_balance_before"] += flt(row.balance_before)
			group[f"{component}_balance"] += flt(row.reducing_balance)
		group.balance_before += flt(row.balance_before)
		group.reducing_balance += flt(row.reducing_balance)
		for fieldname, value in (
			("_loans", row.loan),
			("_loan_types", row.loan_type),
			("_pdb_codes", row.pdb_code),
			("_schedule_months", row.schedule_month),
		):
			if value not in (None, ""):
				group[fieldname].add(str(value))

	data = []
	for group in groups.values():
		group.total_monthly_emi = flt(
			flt(group.capital_amount) + flt(group.interest_amount) + flt(group.insurance_amount),
			2,
		)
		for fieldname in (
			"capital_amount", "interest_amount", "insurance_amount",
			"capital_balance", "interest_balance", "insurance_balance",
			"balance_before", "reducing_balance",
		):
			group[fieldname] = flt(group[fieldname], 2)
		group.loans = ", ".join(sorted(group.pop("_loans")))
		group.loan_types = ", ".join(sorted(group.pop("_loan_types")))
		group.pdb_codes = ", ".join(sorted(group.pop("_pdb_codes")))
		group.schedule_months = ", ".join(
			sorted(
				group.pop("_schedule_months"),
				key=lambda value: (0, int(value)) if value.isdigit() else (1, value),
			)
		)
		data.append(group)
	return sorted(data, key=lambda row: (row.posting_date or "", row.employee_name or row.employee or ""))


def _component_total(row):
	return flt({"Capital": row.approved_amount, "Interest": row.total_interest, "Insurance": row.total_insurance}.get(row.component))


def _within_dates(posting_date, filters):
	date = getdate(posting_date)
	return (not filters.from_date or date >= getdate(filters.from_date)) and (not filters.to_date or date <= getdate(filters.to_date))


def _columns():
	def c(fieldname, label, fieldtype="Data", width=110, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("posting_date", "Posting Date", "Date", 95), c("payroll_period", "Payroll Period", width=130),
		c("payroll_cycle", "Payroll Cycle", "Link", 135, "Payroll Cycle"), c("employee", "Employee", "Link", 130, "Employee"),
		c("employee_name", "Employee Name", width=155), c("department", "Department", "Link", 135, "Department"),
		c("location", "Location / Branch", "Link", 125, "Branch"),
		c("salary_slip", "Salary Slip", "Link", 145, "Salary Slip"),
		c("loans", "Loan(s)", width=165), c("loan_types", "Loan Type(s)", width=130),
		c("pdb_codes", "PDB Code(s)", width=115), c("schedule_months", "Schedule Month(s)", width=115),
		c("capital_amount", "Loan Capital", "Currency", 120),
		c("interest_amount", "Loan Interest", "Currency", 120),
		c("insurance_amount", "Loan Insurance", "Currency", 120),
		c("total_monthly_emi", "Total Monthly EMI", "Currency", 135),
		c("capital_balance", "Capital Balance", "Currency", 125),
		c("interest_balance", "Interest Balance", "Currency", 125),
		c("insurance_balance", "Insurance Balance", "Currency", 125),
		c("reducing_balance", "Total Loan Balance", "Currency", 135)]
