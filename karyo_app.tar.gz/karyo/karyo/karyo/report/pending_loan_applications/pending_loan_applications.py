import frappe
from frappe import _
from frappe.utils import date_diff, getdate, today

from karyo.karyo.report.loan_application_register.loan_application_register import _enrich_employee_organisation


TERMINAL_OR_POST_APPLICATION_STATES = {"Rejected", "Disbursed", "Active Loan", "Settled", "Cancelled", "Closed"}


def execute(filters=None):
	filters = frappe._dict(filters or {})
	frappe.has_permission("Karyo Loan", "read", throw=True)
	states, actions = _configured_pending_states()
	if filters.workflow_state and filters.workflow_state not in states:
		return _columns(), [], None, None, _summary([])
	loan_filters = {"workflow_state": filters.workflow_state or ["in", states]}
	for field in ("loan_type", "employee", "owner"):
		if filters.get(field):
			loan_filters[field] = filters[field]
	rows = frappe.get_list("Karyo Loan", filters=loan_filters,
		fields=["name", "employee", "employee_name", "loan_type", "amount_applied", "approved_amount",
			"date_applied", "workflow_state", "committee_date", "owner", "creation", "modified"],
		order_by="date_applied asc, creation asc", limit_page_length=0)
	_enrich_employee_organisation(rows)
	minimum_age = int(filters.minimum_age_days or 0)
	result = []
	for row in rows:
		row.age_days = max(0, date_diff(today(), getdate(row.date_applied or row.creation)))
		row.next_action = ", ".join(actions.get(row.workflow_state, [])) or _("Workflow configuration required")
		if (not filters.department or row.department == filters.department) and \
			(not filters.location or row.location == filters.location) and row.age_days >= minimum_age:
			result.append(row)
	return _columns(), result, None, None, _summary(result)


def _configured_pending_states():
	workflow_name = frappe.db.get_value("Workflow", {"document_type": "Karyo Loan", "is_active": 1}, "name")
	if not workflow_name:
		return [], {}
	workflow = frappe.get_doc("Workflow", workflow_name)
	states = [row.state for row in workflow.states if row.state not in TERMINAL_OR_POST_APPLICATION_STATES]
	actions = {}
	for transition in workflow.transitions:
		if transition.state in states:
			actions.setdefault(transition.state, []).append(transition.action)
	return states, actions


def _summary(rows):
	return [
		{"label": _("Pending Applications"), "value": len(rows), "indicator": "Orange", "datatype": "Int"},
		{"label": _("Oldest Age (Days)"), "value": max((r.age_days for r in rows), default=0), "indicator": "Red", "datatype": "Int"},
	]


def _columns():
	def c(fieldname, label, fieldtype="Data", width=110, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width,
			**({"options": options} if options else {})}
	return [c("name", "Loan Application", "Link", 155, "Karyo Loan"), c("date_applied", "Date Applied", "Date", 100),
		c("age_days", "Age (Days)", "Int", 85), c("employee", "Employee", "Link", 130, "Employee"),
		c("employee_name", "Employee Name", width=155), c("department", "Department", "Link", 125, "Department"),
		c("location", "Location / Branch", "Link", 125, "Branch"), c("loan_type", "Loan Type", "Link", 115, "Loan Type"),
		c("amount_applied", "Amount Applied", "Currency", 120), c("approved_amount", "Amount Approved", "Currency", 125),
		c("workflow_state", "Current State", width=180), c("owner", "Owner", "Link", 145, "User"),
		c("next_action", "Available Next Action(s)", width=240), c("committee_date", "Committee Date", "Date", 110),
		c("modified", "Last Updated", "Datetime", 145)]
