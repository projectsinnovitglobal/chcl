# Copyright (c) 2026, AstraFlow and contributors
# For license information, please see license.txt

"""PB Computation Log (§9.2 #2) — UAT and production reconciliation.

One row per salary segment of each computation. Minimum fields (BRD §9.2): period,
salary segment, eligible days, salary, rate, calculated amount (exclusions and
rounding stage are carried on the parent computation trace).
"""

import frappe


def execute(filters=None):
	filters = frappe._dict(filters or {})
	return _columns(), _data(filters)


def _columns():
	return [
		{
			"label": "Computation",
			"fieldname": "computation",
			"fieldtype": "Link",
			"options": "Passage Benefit Computation",
			"width": 160,
		},
		{
			"label": "Employee",
			"fieldname": "employee",
			"fieldtype": "Link",
			"options": "Employee",
			"width": 110,
		},
		{"label": "Employee Name", "fieldname": "employee_name", "fieldtype": "Data", "width": 160},
		{"label": "Pay Period", "fieldname": "pay_period", "fieldtype": "Data", "width": 90},
		{"label": "Parameter Version", "fieldname": "parameter_version", "fieldtype": "Data", "width": 120},
		{"label": "Salary From", "fieldname": "salary_from", "fieldtype": "Date", "width": 100},
		{"label": "Salary To", "fieldname": "salary_to", "fieldtype": "Date", "width": 100},
		{"label": "Monthly Salary", "fieldname": "monthly_salary", "fieldtype": "Currency", "width": 120},
		{"label": "Eligible Days", "fieldname": "eligible_days", "fieldtype": "Int", "width": 100},
		{"label": "Excluded Days", "fieldname": "excluded_days", "fieldtype": "Int", "width": 100},
		{"label": "Denominator", "fieldname": "denominator", "fieldtype": "Int", "width": 100},
		{"label": "Daily Rate", "fieldname": "daily_rate", "fieldtype": "Float", "width": 100},
		{"label": "Segment Amount", "fieldname": "segment_amount", "fieldtype": "Currency", "width": 130},
	]


def _data(filters):
	conditions = ["c.docstatus = 1"]
	values = {}
	if filters.get("employee"):
		conditions.append("c.employee = %(employee)s")
		values["employee"] = filters.employee
	if filters.get("pay_period"):
		conditions.append("c.pay_period = %(pay_period)s")
		values["pay_period"] = filters.pay_period
	if filters.get("from_date"):
		conditions.append("c.to_date >= %(from_date)s")
		values["from_date"] = filters.from_date
	if filters.get("to_date"):
		conditions.append("c.from_date <= %(to_date)s")
		values["to_date"] = filters.to_date

	return frappe.db.sql(
		"""
		select
			c.name as computation, c.employee, c.employee_name, c.pay_period, c.parameter_version,
			s.salary_from, s.salary_to, s.monthly_salary,
			s.eligible_days, s.excluded_days, s.denominator, s.daily_rate, s.segment_amount
		from `tabPassage Benefit Computation` c
		inner join `tabPassage Benefit Computation Segment` s on s.parent = c.name
		where {conditions}
		order by c.employee, c.from_date, s.idx
		""".format(conditions=" and ".join(conditions)),
		values,
		as_dict=True,
	)
