"""Full demo dataset — every Karyo feature has a visible sample record so the
whole product can be walked through in a client demo. Builds on top of the base
`demo.seed` (employees, PB banks, personal loan) and adds:

  * Passage Benefit  — manual adjustment + a Not-Earned period
  * Loan Management   — a vehicle loan with a registered lien (LN-09) + a settled loan
  * PRB Payroll       — a payroll run, EOY bonus, PMS appraisals (officer + workman),
                        Sick Leave Bank posting, Vacation Leave posting
  * Rule registry     — effective-dated PRB Rule Version entries
  * Grade scales       — a fuller set of SAMPLE Volume 2 grades (PRB-17 stand-in)

Every business rate stays in the config Singles (Karyo / Passage Benefit / PRB
Payroll Settings) and reference tables — this only seeds *transactions*, so
changing a rate in the UI and re-running shows the new value flow through.

    bench --site dev.localhost execute karyo.setup.demo_full.seed

Idempotent: each block checks for an existing record first. Demo site only.
"""

import frappe

from karyo.setup import demo, prb_extra

REVIEW_YEAR = 2026


def _company():
	return "SIL" if frappe.db.exists("Company", "SIL") else frappe.db.get_value("Company", {}, "name")


def _emp(full_name):
	return frappe.db.get_value("Employee", {"employee_name": full_name}, "name")


def _block(label, fn):
	"""Run one seeding block; never let a single failure abort the whole demo."""
	try:
		fn()
		frappe.db.commit()
		print(f"  + {label}")
	except Exception as e:
		frappe.db.rollback()
		print(f"  ! {label} skipped: {e}")


# --- Passage Benefit extras --------------------------------------------------
def _pb_adjustment():
	emp = _emp("Amara Boodhun")
	if not emp or frappe.db.exists("Passage Benefit Adjustment", {"employee": emp}):
		return
	if not frappe.db.exists("Passage Benefit Bank", emp):
		return
	adj = frappe.get_doc(
		{
			"doctype": "Passage Benefit Adjustment",
			"employee": emp,
			"pb_bank": emp,
			"posting_date": "2026-06-15",
			"amount": 1500,
			"remarks": "Demo: manual balance correction approved by Finance (PB-ADJ-001).",
		}
	)
	adj.insert(ignore_permissions=True)
	adj.submit()


def _pb_not_earned():
	emp = _emp("Devan Ramsamy")
	if not emp or frappe.db.exists("Passage Benefit Not Earned Period", {"employee": emp}):
		return
	pay_day = frappe.db.get_value(
		"Payroll Pay Day",
		{"start_date": ("<=", "2026-07-15"), "end_date": (">=", "2026-07-15")},
		"name",
		order_by="payroll_type asc",
	)
	if not pay_day:
		return
	frappe.get_doc(
		{
			"doctype": "Passage Benefit Not Earned Period",
			"pay_day": pay_day,
			"employee": emp,
			"date_from": "2026-07-01",
			"date_to": "2026-07-15",
			"days": 15,
			"remarks": "Demo: leave without pay — excluded from PB accrual (PB-NE-002).",
		}
	).insert(ignore_permissions=True)


# --- Loan Management extras ---------------------------------------------------
def _vehicle_loan_type():
	if frappe.db.exists("Loan Type", "CARLOAN"):
		return
	frappe.get_doc(
		{
			"doctype": "Loan Type",
			"loan_code": "CARLOAN",
			"loan_name": "Car Loan",
			"loan_category": "Motor Vehicle",
			"interest_rate": 8,
			"is_active": 1,
			"lien_required": 1,
			"recast_cap_pct": 5,
		}
	).insert(ignore_permissions=True)


def _vehicle_lien_loan():
	company = _company()
	emp = demo._employee(company, "Rajesh Appadoo", "1987-05-20", 55000)
	if frappe.db.get_value("Karyo Loan", {"employee": emp}, "name"):
		return
	guarantor = _emp("Devan Ramsamy")
	loan = frappe.get_doc(
		{
			"doctype": "Karyo Loan",
			"employee": emp,
			"loan_type": "CARLOAN",
			"company": company,
			"approved_amount": 200000,
			"period_months": 72,
			"eligible_salary": 55000,
			"disbursement_date": "2026-06-01",
			"repayment_start_date": "2026-06-01",
			# LN-09: lien registered up-front so disbursement is allowed.
			"lien_status": "Registered",
			"lien_registration_no": "NTA-2026-004512",
			"lien_registered_date": "2026-05-28",
			"guarantors": [{"guarantor": guarantor}] if guarantor else [],
		}
	)
	loan.insert(ignore_permissions=True)
	from frappe.model.workflow import apply_workflow

	for action in (
		"Print Application",
		"Schedule Committee",
		"Start Review",
		"Recommend",
		"Approve",
		"Disburse",
		"Activate",
	):
		loan = apply_workflow(loan, action)


def _settled_loan():
	company = _company()
	emp = demo._employee(company, "Marie Celine", "1983-09-14", 50000)
	if frappe.db.get_value("Karyo Loan", {"employee": emp}, "name"):
		return
	guarantor = _emp("Amara Boodhun")
	loan = frappe.get_doc(
		{
			"doctype": "Karyo Loan",
			"employee": emp,
			"loan_type": "PERSONAL",
			"company": company,
			"approved_amount": 120000,
			"period_months": 24,
			"eligible_salary": 50000,
			"disbursement_date": "2025-01-01",
			"repayment_start_date": "2025-01-01",
			"guarantors": [{"guarantor": guarantor}] if guarantor else [],
		}
	)
	loan.insert(ignore_permissions=True)
	from frappe.model.workflow import apply_workflow

	for action in (
		"Print Application",
		"Schedule Committee",
		"Start Review",
		"Recommend",
		"Approve",
		"Disburse",
		"Activate",
		"Settle",
	):
		loan = apply_workflow(loan, action)


# --- PRB Payroll --------------------------------------------------------------
def _prb_payroll_run():
	emp = _emp("Devan Ramsamy")
	if not emp:
		return
	frappe.db.set_value("Employee", emp, "karyo_prb_salary_point", "089")
	if frappe.db.exists("PRB Payroll Run", {"employee": emp, "review_year": REVIEW_YEAR}):
		return
	run = frappe.get_doc(
		{
			"doctype": "PRB Payroll Run",
			"employee": emp,
			"review_year": REVIEW_YEAR,
			"period": "June 2026",
			"salary_point": "089",
			"increment_due": 0,
			"components": [
				{
					"component_code": "ACTING",
					"description": "Acting Allowance (demo)",
					"amount": 5000,
					"rule_ref": "ACT-05",
					"source": "Manual",
				}
			],
		}
	)
	run.insert(ignore_permissions=True)
	run.submit()


def _eoy_bonus():
	emp = _emp("Devan Ramsamy")
	if not emp or frappe.db.exists("EOY Bonus", {"employee": emp, "year": REVIEW_YEAR}):
		return
	doc = frappe.get_doc(
		{
			"doctype": "EOY Bonus",
			"employee": emp,
			"year": REVIEW_YEAR,
			"case": "Full Year",
			"monthly_salary": 60000,
		}
	)
	doc.insert(ignore_permissions=True)
	doc.submit()


def _pms_officer():
	emp = _emp("Amara Boodhun")
	if not emp or frappe.db.exists("PMS Appraisal", {"employee": emp, "year": REVIEW_YEAR}):
		return
	doc = frappe.get_doc(
		{
			"doctype": "PMS Appraisal",
			"employee": emp,
			"year": REVIEW_YEAR,
			"appraisal_type": "Officer",
			"max_rating": 5,
			"components": [
				{"competency": "Job Knowledge", "rating": 4, "weight": 45},
				{"competency": "Service Delivery", "rating": 3, "weight": 35},
				{"competency": "Team Work", "rating": 3, "weight": 20},
			],
		}
	)
	doc.insert(ignore_permissions=True)
	doc.submit()


def _pms_workman():
	emp = _emp("Marie Celine")
	if not emp or frappe.db.exists("PMS Appraisal", {"employee": emp, "year": REVIEW_YEAR}):
		return
	doc = frappe.get_doc(
		{
			"doctype": "PMS Appraisal",
			"employee": emp,
			"year": REVIEW_YEAR,
			"appraisal_type": "Workman",
			"points": 24,
			"max_points": 30,
		}
	)
	doc.insert(ignore_permissions=True)
	doc.submit()


def _sick_leave_bank():
	emp = _emp("Amara Boodhun")
	if not emp:
		return
	if not frappe.db.exists("Sick Leave Bank", emp):
		frappe.get_doc(
			{
				"doctype": "Sick Leave Bank",
				"employee": emp,
				"opening_bank_days": 100,
				"bank_days": 100,
				"advance_balance_days": 0,
			}
		).insert(ignore_permissions=True)
	if frappe.db.exists("Sick Leave Bank Posting", {"employee": emp, "year": REVIEW_YEAR}):
		return
	p = frappe.get_doc(
		{
			"doctype": "Sick Leave Bank Posting",
			"employee": emp,
			"year": REVIEW_YEAR,
			"sick_leave_taken_days": 5,
			"monthly_salary": 45000,
		}
	)
	p.insert(ignore_permissions=True)
	p.submit()


def _vacation_leave():
	emp = _emp("Devan Ramsamy")
	if not emp or frappe.db.exists("Vacation Leave Posting", {"employee": emp, "year": REVIEW_YEAR}):
		return
	p = frappe.get_doc(
		{
			"doctype": "Vacation Leave Posting",
			"employee": emp,
			"year": REVIEW_YEAR,
			"length_of_service_years": 12,
			"eligible_ratio": 1,
			"taken_days": 8,
		}
	)
	p.insert(ignore_permissions=True)
	p.submit()


# --- Rule registry ------------------------------------------------------------
RULE_VERSIONS = [
	("Passage Benefit Accrual", "FAREI PB BRD §7", "2026 base", "2026-01-01", 10),
	("PRB Overtime Multipliers", "PRB 2026 §16", "2026 base", "2026-01-01", 10),
	("Sick Leave Bank", "PRB 2026 §11", "2026 base", "2026-01-01", 10),
	("Loan Recast Cap", "SIL LMS §15.10", "2026 base", "2026-01-01", 10),
]


def _rule_versions():
	for group, src, addendum, eff, prio in RULE_VERSIONS:
		if frappe.db.exists("PRB Rule Version", {"rule_group": group, "effective_from": eff}):
			continue
		frappe.get_doc(
			{
				"doctype": "PRB Rule Version",
				"rule_group": group,
				"source_reference": src,
				"addendum_version": addendum,
				"effective_from": eff,
				"priority": prio,
				"status": "Active",
			}
		).insert(ignore_permissions=True)


def _ess_user_link():
	"""Link a demo employee to Administrator so the ESS "My HR" page shows live data."""
	if frappe.db.get_value("Employee", {"user_id": "Administrator"}, "name"):
		return
	emp = _emp("Priya Luchoomun")
	if emp:
		# db_set: skip Employee.user_id validation (Administrator is fine for a demo site)
		frappe.db.set_value("Employee", emp, "user_id", "Administrator")


def _pending_pb_claim():
	"""A claim sitting in the approval queue (Approvals page / PB-WKF demo)."""
	from frappe.model.workflow import apply_workflow

	emp = _emp("Devan Ramsamy")
	if not emp or not frappe.db.exists("Passage Benefit Bank", {"employee": emp}):
		return
	if frappe.db.exists(
		"Passage Benefit Application",
		{"employee": emp, "workflow_state": ["in", ["Pending Approval", "Recommended"]]},
	):
		return
	app = frappe.get_doc(
		{
			"doctype": "Passage Benefit Application",
			"employee": emp,
			"usage_item": "MEDICAL",
			"request_amount": 1500,
			"posting_date": frappe.utils.nowdate(),
			"pay_period": frappe.utils.formatdate(frappe.utils.nowdate(), "MMM-yyyy"),
		}
	)
	app.insert(ignore_permissions=True)
	apply_workflow(app, "Submit for Approval")


def seed():
	company = _company()
	if not company:
		print("SKIP: no Company on site")
		return

	print("Seeding BASE demo (employees, PB, personal loan + recast)...")
	demo.seed()

	print("Seeding FULL demo (every feature)...")
	# Reference / config-adjacent
	_block("richer sample grade scales (PRB-17 stand-in)", prb_extra.seed_sample_grade_scales)
	_block("PRB rule-version registry", _rule_versions)
	# Passage Benefit
	_block("PB manual adjustment", _pb_adjustment)
	_block("PB not-earned period", _pb_not_earned)
	# Loans
	_block("vehicle loan type (lien required)", _vehicle_loan_type)
	_block("vehicle loan with registered lien (LN-09)", _vehicle_lien_loan)
	_block("settled loan", _settled_loan)
	# PRB payroll
	_block("PRB payroll run", _prb_payroll_run)
	_block("EOY bonus", _eoy_bonus)
	_block("PMS appraisal — officer", _pms_officer)
	_block("PMS appraisal — workman", _pms_workman)
	_block("Sick Leave Bank + year-end posting", _sick_leave_bank)
	_block("Vacation Leave posting", _vacation_leave)
	# Desk pages demo state
	_block("ESS user link (My HR page)", _ess_user_link)
	_block("pending PB claim (Approvals queue)", _pending_pb_claim)

	print("Full demo seed complete — every module now has a sample record.")
