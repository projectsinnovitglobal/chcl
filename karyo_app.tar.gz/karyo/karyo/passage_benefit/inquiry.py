"""Passage Benefit inquiry APIs (prototype screens 9/10/11; pbf0030/pbf_temp/pbf0110).

Read-only balance/audit inquiries that back the three interactive screens:

  * ``query_balance``          — screen 9  (pbf0030): an employee's PB Bank, its
                                 period records and computation log.
  * ``compute_balance_as_at``  — screen 10 (pbf_temp): recompute the balance as at
                                 a date for audit/budget only. It reuses the exact
                                 production computation logic but **never inserts a
                                 document or touches the PB Bank** (scheduler note:
                                 "must not update the actual PB Bank").
  * ``pb_and_vacation_balance``— screen 11 (pbf0110): the PB balance beside the
                                 HRMS Vacation Leave balance for one employee.

Everything here is read-only; the reports under ``karyo/report`` cover the tabular
§9.2 listings.
"""

import frappe
from frappe import _
from frappe.utils import getdate, today

from karyo.passage_benefit.eligibility import evaluate as evaluate_eligibility
from karyo.passage_benefit.params import resolve as resolve_params
from karyo.security import PRIVILEGED_ROLES, _employee_for_user


def _assert_employee_access(employee):
	roles = set(frappe.get_roles())
	if roles & PRIVILEGED_ROLES:
		return
	if "Employee" not in roles or _employee_for_user(frappe.session.user) != employee:
		frappe.throw(_("You are not permitted to view this employee's Passage Benefit data."), frappe.PermissionError)


def _posted_balance_as_at(employee, as_on):
	bank = frappe.db.get_value(
		"Passage Benefit Bank", employee, ["opening_date", "opening_balance"], as_dict=True
	)
	if not bank or getdate(as_on) < getdate(bank.opening_date):
		return 0.0
	movement = frappe.db.sql(
		"""
		select coalesce(sum(amount), 0)
		from `tabPassage Benefit Ledger Entry`
		where pb_bank=%s and docstatus=1 and posting_date<=%s and entry_type!='Opening'
		""",
		(employee, as_on),
	)[0][0]
	return (bank.opening_balance or 0) + (movement or 0)


@frappe.whitelist()
def query_balance(employee):
	"""Screen 9 — an employee's PB Bank, period records and computation log."""
	_assert_employee_access(employee)
	if not frappe.db.exists("Passage Benefit Bank", employee):
		return {"employee": employee, "bank": None, "periods": [], "computation_log": []}

	bank = frappe.get_doc("Passage Benefit Bank", employee)
	periods = [
		{
			"period": p.period,
			"status": p.status,
			"opening_date": p.opening_date,
			"opening_amount": p.opening_amount,
			"earned": p.earned,
			"taken": p.taken,
			"adjustments": p.adjustments,
			"current_balance": p.current_balance,
			"closing_date": p.closing_date,
			"closing_amount": p.closing_amount,
		}
		for p in bank.periods
	]
	log = frappe.get_all(
		"Passage Benefit Computation",
		filters={"employee": employee, "docstatus": 1},
		fields=[
			"name",
			"from_date",
			"to_date",
			"pay_period",
			"eligible_days_total",
			"earned_amount",
		],
		order_by="from_date asc",
	)
	transactions = frappe.get_all(
		"Passage Benefit Ledger Entry",
		filters={"employee": employee},
		fields=[
			"name", "posting_date", "entry_type", "amount", "balance_after", "pay_period",
			"reference_doctype", "reference_name", "remarks", "docstatus", "owner", "creation",
		],
		order_by="posting_date desc, creation desc",
	)
	requests = frappe.get_all(
		"Passage Benefit Application",
		filters={"employee": employee},
		fields=[
			"name", "posting_date", "usage_item", "request_amount", "claimable_amount",
			"amount_taken", "pay_period", "workflow_state", "processing_route",
			"processed_reference", "travel_agent", "modified_by", "modified",
		],
		order_by="posting_date desc, creation desc",
	)
	return {
		"employee": employee,
		"employee_name": frappe.db.get_value("Employee", employee, "employee_name"),
		"bank": {
			"opening_date": bank.opening_date,
			"opening_balance": bank.opening_balance,
			"total_earned": bank.total_earned,
			"total_taken": bank.total_taken,
			"total_adjustments": bank.total_adjustments,
			"current_balance": bank.current_balance,
			"eligible_from_date": bank.get("eligible_from_date"),
		},
		"periods": periods,
		"computation_log": log,
		"transactions": transactions,
		"requests": requests,
	}


def _audit_compute_one(employee, as_on):
	"""Recompute an employee's PB as at ``as_on`` without persisting anything.

	Builds a transient (never inserted) Passage Benefit Computation and drives it
	through the same eligibility / segment-build / engine path used in production,
	so the audit figures can never drift from the real computation. The PB Bank is
	read only for the opening balance and is not modified. Returns ``None`` when the
	employee is not eligible as at the date."""
	opening = 0.0
	win_from = None
	if frappe.db.exists("Passage Benefit Bank", employee):
		bank = frappe.get_doc("Passage Benefit Bank", employee)
		opening = bank.current_balance or 0.0
		open_row = bank.get_open_period()
		if open_row and open_row.opening_date:
			win_from = getdate(open_row.opening_date)

	comp = frappe.new_doc("Passage Benefit Computation")
	comp.employee = employee
	comp.to_date = as_on
	try:
		comp._check_eligibility()  # sets eligible_from_date; throws if not eligible
	except frappe.ValidationError:
		frappe.clear_last_message()
		return None

	# Accrue from the current open period start (fallback: the eligible-from date).
	comp.from_date = win_from or getdate(comp.eligible_from_date)
	if getdate(comp.from_date) > getdate(as_on):
		earned, segments = 0.0, []
	else:
		comp._autobuild_segments()
		comp.apply_computation()
		earned = comp.earned_amount or 0.0
		segments = [
			{
				"salary_from": s.salary_from,
				"salary_to": s.salary_to,
				"eligible_days": s.eligible_days,
				"monthly_salary": s.monthly_salary,
				"annual_salary": s.annual_salary,
				"daily_rate": s.daily_rate,
				"segment_amount": s.segment_amount,
			}
			for s in comp.segments
		]

	emp = frappe.db.get_value("Employee", employee, ["employee_name", "grade", "branch"], as_dict=True)
	return {
		"employee": employee,
		"employee_name": emp.employee_name if emp else None,
		"grade": emp.grade if emp else None,
		"branch": emp.branch if emp else None,
		"opening_amount": opening,
		"earned": earned,
		"closing_amount": opening + earned,
		"segments": segments,
	}


@frappe.whitelist()
def compute_balance_as_at(as_on=None, employees=None, company=None, grade=None, branch=None):
	"""Screen 10 — audit/budget recompute as at a date. Never updates the PB Bank."""
	as_on = getdate(as_on) if as_on else getdate(today())
	if isinstance(employees, str):
		employees = frappe.parse_json(employees) if employees.strip().startswith("[") else [employees]
	if employees:
		for employee in employees:
			_assert_employee_access(employee)

	if not employees:
		roles = set(frappe.get_roles())
		if not roles & PRIVILEGED_ROLES:
			own_employee = _employee_for_user(frappe.session.user)
			if "Employee" not in roles or not own_employee:
				frappe.throw(_("You are not permitted to run Passage Benefit balance inquiry."), frappe.PermissionError)
			employees = [own_employee]
	if not employees:
		filters = {"status": "Active", "pb_eligible": 1}
		if company:
			filters["company"] = company
		if grade:
			filters["grade"] = grade
		if branch:
			filters["branch"] = branch
		employees = [e.name for e in frappe.get_all("Employee", filters=filters, fields=["name"])]

	rows, total_earned = [], 0.0
	for emp in employees:
		res = _audit_compute_one(emp, as_on)
		if res is None:
			continue
		rows.append(res)
		total_earned += res["earned"]
	return {
		"as_on": as_on,
		"count": len(rows),
		"total_earned": total_earned,
		"rows": rows,
	}


@frappe.whitelist()
def pb_and_vacation_balance(employee, as_on=None):
	"""Screen 11 — PB balance beside the HRMS Vacation Leave balance for one employee."""
	_assert_employee_access(employee)
	as_on = getdate(as_on) if as_on else getdate(today())
	emp = (
		frappe.db.get_value(
			"Employee",
			employee,
			["employee_name", "grade", "branch", "date_of_joining", "karyo_date_confirmed"],
			as_dict=True,
		)
		or frappe._dict()
	)

	pb_balance = _posted_balance_as_at(employee, as_on)

	leave_type = frappe.db.get_single_value("Passage Benefit Settings", "vacation_leave_type")
	vacation_balance = None
	if leave_type:
		from hrms.hr.doctype.leave_application.leave_application import get_leave_balance_on

		vacation_balance = get_leave_balance_on(employee, leave_type, as_on)

	res = evaluate_eligibility(employee, as_on, settings=resolve_params(as_on))
	return {
		"employee": employee,
		"employee_name": emp.get("employee_name"),
		"grade": emp.get("grade"),
		"branch": emp.get("branch"),
		"date_joined": emp.get("date_of_joining"),
		"date_confirmed": emp.get("karyo_date_confirmed"),
		"as_on": as_on,
		"pb_balance": pb_balance,
		"vacation_leave_type": leave_type,
		"vacation_balance": vacation_balance,
		"eligible": res["eligible"],
		"eligibility_status": res["eligibility_status"],
		"eligibility_reason": res["message"],
		"block_reason": res["block_reason"],
		"eligibility_mode": res["eligibility_mode"],
		"eligibility_rules": res["rules"],
		"eligible_from_date": res["eligible_from_date"],
	}
