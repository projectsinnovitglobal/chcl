frappe.query_reports["Loan Guarantor Exposure"] = {
	filters: [
		{ fieldname: "guarantor", label: __("Guarantor"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "borrower", label: __("Borrower"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{
			fieldname: "loan_status",
			label: __("Loan Status"),
			fieldtype: "Select",
			options: "\nDraft\nActive\nSettled\nClosed",
		},
		{ fieldname: "active_only", label: __("Active Exposure Only"), fieldtype: "Check", default: 1 },
	],
};
