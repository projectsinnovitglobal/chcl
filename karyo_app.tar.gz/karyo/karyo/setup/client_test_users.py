"""Create the three controlled accounts issued for SIL client testing."""

import frappe
from frappe.utils.password import update_password

COMPANY = "SIL"
ACCOUNTS = (
	{
		"email": "admin.test@sil.mu",
		"first_name": "SIL",
		"last_name": "Administrator",
		"password": "SIL-Admin@2026!",
		"roles": ("System Manager",),
		"all_roles": True,
	},
	{
		"email": "hr.test@sil.mu",
		"first_name": "SIL",
		"last_name": "HR Tester",
		"password": "SIL-HR@2026!",
		"roles": ("HR Manager", "HR User", "Leave Approver"),
	},
	{
		"email": "employee.test@sil.mu",
		"first_name": "SIL",
		"last_name": "ESS Tester",
		"password": "SIL-ESS@2026!",
		"roles": ("Employee",),
		"employee": True,
	},
)


def _ensure_user(account):
	email = account["email"]
	if frappe.db.exists("User", email):
		user = frappe.get_doc("User", email)
	else:
		user = frappe.get_doc(
			{
				"doctype": "User",
				"email": email,
				"first_name": account["first_name"],
				"last_name": account["last_name"],
				"enabled": 1,
				"send_welcome_email": 0,
				"user_type": "System User",
			}
		).insert(ignore_permissions=True)
	user.enabled = 1
	user.user_type = "System User"
	user.save(ignore_permissions=True)
	roles = account["roles"]
	if account.get("all_roles"):
		roles = frappe.get_all(
			"Role",
			filters={"disabled": 0},
			pluck="name",
		)
		excluded_roles = {"All", "Guest", "Desk User", "Administrator", "Customer", "Supplier"}
		roles = [
			role for role in roles if role not in excluded_roles and not role.startswith("_Test Role")
		]
		assigned_roles = {row.role for row in user.roles}
		if roles_to_remove := assigned_roles - set(roles):
			user.remove_roles(*roles_to_remove)
	user.add_roles(*roles)
	update_password(email, account["password"], logout_all_sessions=True)
	return user


def promote_client_admin():
	"""Provision the SIL client administrator with unrestricted application roles."""
	account = ACCOUNTS[0]
	user = _ensure_user(account)
	frappe.db.delete("User Permission", {"user": account["email"]})
	frappe.db.commit()
	frappe.clear_cache(user=account["email"])
	return {
		"user": user.name,
		"enabled": user.enabled,
		"user_type": user.user_type,
		"role_count": len(frappe.get_roles(user.name)),
	}


def _ensure_company_permission(email):
	filters = {"user": email, "allow": "Company", "for_value": COMPANY}
	if not frappe.db.exists("User Permission", filters):
		frappe.get_doc({"doctype": "User Permission", **filters}).insert(ignore_permissions=True)


def _ensure_employee(account):
	email = account["email"]
	employee = frappe.db.get_value("Employee", {"user_id": email}, "name")
	if employee:
		return employee
	employee = frappe.get_doc(
		{
			"doctype": "Employee",
			"first_name": account["first_name"],
			"last_name": account["last_name"],
			"gender": "Other",
			"date_of_birth": "1990-01-01",
			"date_of_joining": "2026-01-01",
			"company": COMPANY,
			"status": "Active",
			"user_id": email,
		}
	).insert(ignore_permissions=True)
	return employee.name


def create():
	if not frappe.db.exists("Company", COMPANY):
		frappe.throw(f"Company {COMPANY} does not exist")
	created = []
	for account in ACCOUNTS:
		_ensure_user(account)
		_ensure_company_permission(account["email"])
		employee = _ensure_employee(account) if account.get("employee") else None
		created.append({"email": account["email"], "roles": account["roles"], "employee": employee})
	frappe.db.commit()
	frappe.clear_cache()
	return created
