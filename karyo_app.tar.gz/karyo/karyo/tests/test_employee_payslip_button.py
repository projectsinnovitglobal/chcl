import unittest
from uuid import uuid4
from unittest.mock import patch
import frappe
from karyo.desk.payroll_management import generate_employee_payslip


class TestEmployeePayslipButton(unittest.TestCase):
    @staticmethod
    def _remove_stale_fixtures():
        employees = frappe.get_all('Employee', filters={'name': ('like', 'payslip-button-%')}, pluck='name')
        if employees:
            frappe.db.delete('Salary Slip', {'employee': ('in', employees)})
            frappe.db.delete('Salary Structure Assignment', {'employee': ('in', employees)})
        entries = frappe.get_all('Payroll Entry', filters={'name': ('like', 'payslip-entry-%')}, pluck='name')
        if entries:
            frappe.db.delete('Payroll Employee Detail', {'parent': ('in', entries)})
            frappe.db.delete('Payroll Entry', {'name': ('in', entries)})
        frappe.db.delete('Payroll Cycle', {'name': ('like', 'payslip-cycle-%')})
        frappe.db.delete('Payroll Pay Day', {'name': ('like', 'payslip-day-%')})
        if employees:
            frappe.db.delete('Employee', {'name': ('in', employees)})

    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        self._remove_stale_fixtures()
        frappe.db.commit()
        frappe.db.savepoint('employee_payslip_button')
        active_structures = frappe.get_all(
            'Salary Structure',
            filters={'docstatus': 1, 'is_active': 'Yes', 'payroll_frequency': 'Monthly'},
            pluck='name',
        )
        template_name = frappe.db.get_value(
            'Salary Structure Assignment',
            {
                'docstatus': 1,
                'salary_structure': ('in', active_structures),
                'from_date': ('<=', '2026-06-01'),
            },
            'name',
            order_by='from_date desc',
        )
        self.assertTrue(template_name, 'An active monthly salary assignment is required for this test.')
        template = frappe.get_doc('Salary Structure Assignment', template_name)
        self.salary_structure = template.salary_structure
        self.employee = frappe.copy_doc(frappe.get_doc('Employee', template.employee))
        self.employee.name = 'payslip-button-' + uuid4().hex
        self.employee.user_id = None
        self.employee.karyo_legacy_employee_id = None
        self.employee.docstatus = 0
        self.employee.status = 'Active'
        self.employee.date_of_joining = '2015-01-01'
        self.employee.relieving_date = None
        self.employee.db_insert()
        assignment = frappe.copy_doc(template)
        assignment.name = 'payslip-assignment-' + uuid4().hex
        assignment.employee = self.employee.name
        assignment.docstatus = 1
        assignment.from_date = '2015-01-01'
        assignment.income_tax_slab = frappe.db.get_value(
            'Income Tax Slab', {'docstatus': 1, 'effective_from': ('<=', '2025-07-01')},
            'name', order_by='effective_from desc'
        )
        assignment.db_insert()
        self.period = '2025-2026 (MBC)'
        if not frappe.db.exists('Payroll Period', self.period):
            frappe.get_doc({
                'doctype': 'Payroll Period', 'name': self.period,
                'company': self.employee.company, 'start_date': '2025-07-01',
                'end_date': '2026-06-30'
            }).db_insert()
        token = uuid4().hex
        pay_day = frappe.copy_doc(frappe.get_doc(
            'Payroll Pay Day', frappe.db.get_value('Payroll Pay Day', {'company': self.employee.company}, 'name')
        ))
        pay_day.name = 'payslip-day-' + token
        pay_day.pay_day_code = pay_day.name
        pay_day.payroll_period = self.period
        pay_day.payroll_type = 'Major'
        pay_day.pay_period_label = 'June 2026'
        pay_day.start_date = '2026-06-01'
        pay_day.end_date = '2026-06-30'
        pay_day.payment_date = '2026-06-25'
        pay_day.status = 'Active'
        pay_day.docstatus = 0
        pay_day.db_insert()
        entry = frappe.get_doc({
            'doctype': 'Payroll Entry', 'name': 'payslip-entry-' + token,
            'company': self.employee.company, 'payroll_frequency': 'Monthly',
            'start_date': '2026-06-01', 'end_date': '2026-06-30',
            'posting_date': '2026-06-30', 'currency': assignment.currency,
            'exchange_rate': 1, 'status': 'Submitted', 'docstatus': 1,
        })
        entry.db_insert()
        frappe.get_doc({
            'doctype': 'Payroll Employee Detail', 'name': 'payslip-detail-' + token,
            'parent': entry.name, 'parenttype': 'Payroll Entry', 'parentfield': 'employees',
            'employee': self.employee.name,
        }).db_insert()
        self.cycle = frappe.get_doc({
            'doctype': 'Payroll Cycle', 'name': 'payslip-cycle-' + token,
            'company': self.employee.company, 'pay_day': pay_day.name,
            'payroll_period': self.period, 'payroll_type': 'Major',
            'pay_period_label': 'June 2026', 'start_date': '2026-06-01',
            'end_date': '2026-06-30', 'payment_date': '2026-06-25',
            'status': 'Processing', 'readiness_status': 'Ready',
            'payroll_entry': entry.name, 'docstatus': 0,
        })
        self.cycle.db_insert()
        # HRMS' native salary-slip helper owns its transaction and rolls back
        # before recording failures. Commit this isolated fixture first so a
        # helper rollback cannot discard the assignment it is about to use.
        frappe.db.commit()
        self.events = patch('frappe.publish_realtime')
        self.events.start()

    def tearDown(self):
        frappe.set_user('Administrator')
        # Native salary generation may commit internally, invalidating a SQL
        # savepoint. Roll back pending work, then remove only this test's
        # uniquely prefixed records so reruns cannot create ambiguous cycles.
        frappe.db.rollback()
        self._remove_stale_fixtures()
        frappe.db.commit()
        self.events.stop()
        frappe.set_user(self.user)

    def test_generates_only_selected_employee_and_reuses_duplicate(self):
        before = frappe.db.count('Salary Slip')
        result = generate_employee_payslip(self.employee.name, self.period, '2026-06')
        self.assertTrue(result['created'])
        self.assertEqual(frappe.db.count('Salary Slip'), before + 1)
        slip = frappe.get_doc('Salary Slip', result['name'])
        self.assertEqual(slip.employee, self.employee.name)
        self.assertEqual(str(slip.start_date), '2026-06-01')
        self.assertEqual(str(slip.end_date), '2026-06-30')
        self.assertEqual(slip.docstatus, 0)
        self.assertEqual(slip.salary_structure, self.salary_structure)
        again = generate_employee_payslip(self.employee.name, self.period, '2026-06')
        self.assertFalse(again['created'])
        self.assertEqual(again['name'], slip.name)
        self.assertEqual(frappe.db.count('Salary Slip'), before + 1)

    def test_rejects_month_outside_period_and_missing_permission(self):
        with self.assertRaises(frappe.ValidationError):
            generate_employee_payslip(self.employee.name, self.period, '2026-07')
        with self.assertRaises(frappe.ValidationError):
            generate_employee_payslip(self.employee.name, self.period, '')
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            generate_employee_payslip(self.employee.name, self.period, '2026-06')

    def test_missing_assignment_does_not_create_slip(self):
        frappe.db.delete('Salary Structure Assignment', {'employee': self.employee.name})
        before = frappe.db.count('Salary Slip')
        with self.assertRaises(frappe.ValidationError):
            generate_employee_payslip(self.employee.name, self.period, '2026-06')
        self.assertEqual(frappe.db.count('Salary Slip'), before)

    def test_draft_cycle_allows_individual_generation_and_preparation_adopts_it(self):
        from karyo.desk.payroll_management import generate_payslips_for_run
        frappe.db.set_value('Payroll Cycle', self.cycle.name, {'status': 'Draft', 'readiness_status': None})
        with self.assertRaisesRegex(frappe.ValidationError, '(?i)payroll|readiness|processing'):
            generate_payslips_for_run(self.period, self.cycle.name, self.employee.name)

    def test_closed_cycle_cannot_generate_new_slip(self):
        frappe.db.set_value('Payroll Cycle', self.cycle.name, 'status', 'Closed')
        with self.assertRaises(frappe.ValidationError):
            from karyo.desk.payroll_management import generate_payslips_for_run
            generate_payslips_for_run(self.period, self.cycle.name, self.employee.name)

    def test_batch_continues_after_individual_slip_was_generated(self):
        from unittest.mock import MagicMock
        from karyo.payroll.process import generate_salary_slips
        cycle = frappe._dict(name='test-cycle', status='Processing', payroll_entry='test-entry')
        entry = MagicMock()
        entry.name = 'test-entry'
        entry.docstatus = 1
        entry.status = 'Submitted'
        entry.employees = [frappe._dict(employee='one'), frappe._dict(employee='two')]
        with patch('karyo.payroll.process.frappe.get_doc', side_effect=[cycle, entry]), \
             patch('karyo.payroll.process.frappe.db.exists', return_value=True), \
             patch('karyo.payroll.process.frappe.db.count', return_value=2), \
             patch('karyo.payroll.process._sync_salary_slips', side_effect=[[{'employee': 'one'}], [{'employee': 'one'}, {'employee': 'two'}]]), \
             patch('karyo.payroll.process._log'):
            result = generate_salary_slips(cycle.name)
        entry.create_salary_slips.assert_called_once()
        self.assertEqual((result['created'], result['reused']), (1, 1))
