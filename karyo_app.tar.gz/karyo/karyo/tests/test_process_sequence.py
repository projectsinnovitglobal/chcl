import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.tests import test_payroll_completion as completion_fixture
from karyo.payroll.completion import process_steps, run_process_step, PROCESS_ACTIONS

class TestProcessSequence(unittest.TestCase):
    setUp = completion_fixture.TestPayrollCompletion.setUp
    tearDown = completion_fixture.TestPayrollCompletion.tearDown

    def active(self):
        return [s['action'] for s in process_steps(self.cycle.name) if s['available']]

    def test_one_action_per_click_and_completed_steps_cannot_repeat(self):
        self.assertEqual(self.active(), [PROCESS_ACTIONS[0]])
        with self.assertRaises(frappe.ValidationError):
            run_process_step(self.cycle.name, 'Prepare Payroll')
        run_process_step(self.cycle.name, 'Open Inputs')
        self.assertEqual(self.active(), ['Run Readiness Checks'])
        with self.assertRaises(frappe.ValidationError):
            run_process_step(self.cycle.name, 'Open Inputs')
        def ready(name):
            frappe.db.set_value('Payroll Cycle', name, 'readiness_status', 'Ready')
            return {'blocking': 0}
        with patch('karyo.payroll.readiness.run_readiness', side_effect=ready):
            run_process_step(self.cycle.name, 'Run Readiness Checks')
        self.assertEqual(self.active(), ['Start Processing'])
        self.assertEqual(frappe.db.get_value('Payroll Cycle', self.cycle.name, 'status'), 'Input Open')
        run_process_step(self.cycle.name, 'Start Processing')
        self.assertEqual(self.active(), ['Prepare Payroll'])
        entry = 'sequence-' + uuid4().hex
        def prepare(name):
            frappe.get_doc({'doctype': 'Payroll Entry', 'name': entry, 'company': self.cycle.company,
                'status': 'Draft', 'docstatus': 0}).db_insert()
            frappe.get_doc({'doctype': 'Payroll Employee Detail', 'name': entry + '-employee',
                'parent': entry, 'parenttype': 'Payroll Entry', 'parentfield': 'employees',
                'employee': 'sequence-employee'}).db_insert()
            frappe.db.set_value('Payroll Cycle', name, 'payroll_entry', entry)
            return {'payroll_entry': entry}
        with patch('karyo.payroll.process.prepare_payroll', side_effect=prepare) as operation:
            run_process_step(self.cycle.name, 'Prepare Payroll')
            operation.assert_called_once()
        self.assertEqual(self.active(), ['Generate Draft Salary Slips'])
        frappe.db.set_value('Payroll Entry', entry, 'status', 'Queued')
        self.assertEqual(self.active(), [])
        self.assertTrue(process_steps(self.cycle.name)[-1]['running'])
        with self.assertRaises(frappe.ValidationError):
            run_process_step(self.cycle.name, 'Generate Draft Salary Slips')
        frappe.db.set_value('Payroll Entry', entry, 'status', 'Draft')
        def generate(name):
            frappe.get_doc({'doctype': 'Salary Slip', 'name': entry + '-slip',
                'employee': 'sequence-employee', 'payroll_entry': entry, 'docstatus': 0}).db_insert()
            return {'created': 1}
        with patch('karyo.payroll.process.generate_salary_slips', side_effect=generate) as operation:
            run_process_step(self.cycle.name, 'Generate Draft Salary Slips')
            operation.assert_called_once()
        self.assertEqual(self.active(), [])
        self.assertTrue(all(s['done'] for s in process_steps(self.cycle.name)))
        with self.assertRaises(frappe.ValidationError):
            run_process_step(self.cycle.name, 'Generate Draft Salary Slips')
        self.assertEqual(frappe.db.get_value('Payroll Cycle', self.cycle.name, 'status'), 'Processing')

    def test_blocked_readiness_stays_active_and_guest_is_denied(self):
        run_process_step(self.cycle.name, 'Open Inputs')
        def blocked(name):
            frappe.db.set_value('Payroll Cycle', name, 'readiness_status', 'Blocked')
            return {'blocking': 3}
        with patch('karyo.payroll.readiness.run_readiness', side_effect=blocked):
            result = run_process_step(self.cycle.name, 'Run Readiness Checks')
        self.assertIn('3 blocking', result['message'])
        self.assertEqual(self.active(), ['Run Readiness Checks'])
        with self.assertRaises(frappe.ValidationError):
            run_process_step(self.cycle.name, 'Start Processing')
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            run_process_step(self.cycle.name, 'Run Readiness Checks')
