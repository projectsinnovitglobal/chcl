import frappe
from frappe import _


TRAVEL_CODES = ("PRB-CAR-MILEAGE", "PRB-MOTORCYCLE-MILEAGE", "PRB-AUTOCYCLE-MILEAGE")


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions, values = ["ss.docstatus < 2"], {}
	for field, expression in (
		("company", "ss.company"), ("employee", "ss.employee"),
		("department", "ss.department"), ("designation", "ss.designation"),
		("payroll_cycle", "ss.karyo_payroll_cycle"),
		("payment_status", "ss.karyo_payment_status"),
	):
		if filters.get(field):
			conditions.append(f"{expression} = %({field})s")
			values[field] = filters.get(field)
	if filters.get("from_date"):
		conditions.append("ss.end_date >= %(from_date)s")
		values["from_date"] = filters.from_date
	if filters.get("to_date"):
		conditions.append("ss.start_date <= %(to_date)s")
		values["to_date"] = filters.to_date
	if filters.get("document_status") == "Draft":
		conditions.append("ss.docstatus = 0")
	elif filters.get("document_status") == "Submitted":
		conditions.append("ss.docstatus = 1")

	data = frappe.db.sql(
		f"""
		select ss.name as salary_slip, ss.start_date, ss.end_date, ss.company,
			ss.karyo_payroll_cycle as payroll_cycle, ss.employee, ss.employee_name,
			ss.department, ss.designation,
			sum(case when pdb.pdb_code = 'BASIC' then sd.amount else 0 end) as basic_salary,
			sum(case when pdb.pdb_code = 'CMP' then sd.amount else 0 end) as compensation,
			sum(case when pdb.pdb_code in {TRAVEL_CODES} then sd.amount else 0 end) as travelling,
			sum(case when sd.parentfield = 'earnings'
				and ifnull(pdb.pdb_code, '') not in ('BASIC', 'CMP', 'PRB-CAR-MILEAGE',
					'PRB-MOTORCYCLE-MILEAGE', 'PRB-AUTOCYCLE-MILEAGE')
				then sd.amount else 0 end) as allowances,
			sum(case when pdb.pdb_type = 'CONT' or cs.name is not null then sd.amount else 0 end) as contribution,
			sum(case when pdb.pdb_code = 'PAYE' or sd.salary_component like '%%PAYE%%' then sd.amount else 0 end) as paye,
			ss.gross_pay, ss.total_deduction, ss.net_pay,
			case ss.docstatus when 1 then 'Submitted' else 'Draft' end as document_status,
			ss.karyo_payment_status as payment_status
		from `tabSalary Slip` ss
		left join `tabSalary Detail` sd on sd.parent = ss.name and sd.parenttype = 'Salary Slip'
		left join `tabPayroll PDB Code` pdb on pdb.salary_component = sd.salary_component
		left join `tabPayroll Contribution Scheme` cs on cs.employer_salary_component = sd.salary_component
		where {' and '.join(conditions)}
		group by ss.name, ss.start_date, ss.end_date, ss.company, ss.karyo_payroll_cycle,
			ss.employee, ss.employee_name, ss.department, ss.designation,
			ss.gross_pay, ss.total_deduction, ss.net_pay, ss.docstatus, ss.karyo_payment_status
		order by ss.start_date desc, ss.employee
		""",
		values,
		as_dict=True,
	)
	return _columns(), data, None, None, [
		{"label": _("Employees / slips"), "value": len(data), "indicator": "Blue", "datatype": "Int"},
		{"label": _("Gross pay"), "value": sum(row.gross_pay or 0 for row in data), "indicator": "Green", "datatype": "Currency"},
		{"label": _("Net pay"), "value": sum(row.net_pay or 0 for row in data), "indicator": "Green", "datatype": "Currency"},
	]


def _columns():
	return [
		{"fieldname": "salary_slip", "label": _("Salary Slip"), "fieldtype": "Link", "options": "Salary Slip", "width": 155},
		{"fieldname": "start_date", "label": _("Period Start"), "fieldtype": "Date", "width": 105},
		{"fieldname": "end_date", "label": _("Period End"), "fieldtype": "Date", "width": 105},
		{"fieldname": "payroll_cycle", "label": _("Payroll Cycle"), "fieldtype": "Link", "options": "Payroll Cycle", "width": 145},
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 130},
		{"fieldname": "employee_name", "label": _("Name"), "width": 170},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 145},
		{"fieldname": "designation", "label": _("Designation"), "fieldtype": "Link", "options": "Designation", "width": 140},
		{"fieldname": "basic_salary", "label": _("Basic Salary"), "fieldtype": "Currency", "width": 115},
		{"fieldname": "compensation", "label": _("Compensation"), "fieldtype": "Currency", "width": 115},
		{"fieldname": "travelling", "label": _("Travelling"), "fieldtype": "Currency", "width": 105},
		{"fieldname": "allowances", "label": _("Allowances"), "fieldtype": "Currency", "width": 110},
		{"fieldname": "contribution", "label": _("Contribution"), "fieldtype": "Currency", "width": 115},
		{"fieldname": "paye", "label": _("PAYE"), "fieldtype": "Currency", "width": 100},
		{"fieldname": "gross_pay", "label": _("Gross"), "fieldtype": "Currency", "width": 110},
		{"fieldname": "total_deduction", "label": _("Deductions"), "fieldtype": "Currency", "width": 110},
		{"fieldname": "net_pay", "label": _("Net Pay"), "fieldtype": "Currency", "width": 110},
		{"fieldname": "document_status", "label": _("Document Status"), "width": 110},
		{"fieldname": "payment_status", "label": _("Payment Status"), "width": 110},
	]
