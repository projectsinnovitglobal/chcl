"""Department defaults, reporting fallbacks and individual approval overrides."""

import unittest
from unittest.mock import patch
from uuid import uuid4

import frappe
from erpnext.setup.doctype.employee.test_employee import make_employee

from karyo.hr.approval_routing import prepare_employee_approvers, resolve_approvers
from karyo.desk.org_units import FIELDS, save as save_org_unit


class TestApprovalRouting(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("approval_routing")

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="approval_routing")
		frappe.set_user(self.user)

	def test_department_approvers_take_precedence(self):
		with patch("karyo.hr.approval_routing._department_approver", return_value="department@example.com"), \
			patch("karyo.hr.approval_routing._reporting_approver", return_value="manager@example.com"):
			resolved = resolve_approvers("Accounts - MBC", "EMP-MANAGER")
		self.assertTrue(all(value["approver"] == "department@example.com" for value in resolved.values()))
		self.assertTrue(all(value["source"] == "Department" for value in resolved.values()))

	def test_reporting_manager_is_the_fallback(self):
		with patch("karyo.hr.approval_routing._department_approver", return_value=None), \
			patch("karyo.hr.approval_routing._reporting_approver", return_value="manager@example.com"):
			resolved = resolve_approvers(None, "EMP-MANAGER")
		self.assertTrue(all(value == {"approver": "manager@example.com", "source": "Reporting Manager"}
			for value in resolved.values()))

	def test_department_editor_persists_all_approver_lists(self):
		suffix = uuid4().hex[:8]
		company = frappe.db.get_value("Company", {}, "name")
		department = frappe.get_doc({
			"doctype": "Department", "department_name": f"Editor {suffix}", "company": company,
		}).insert()
		values = {
			"department_name": department.department_name,
			"company": company,
			"shift_request_approver": [{"approver": "Administrator"}],
			"leave_approvers": [{"approver": "Administrator"}],
			"expense_approvers": [{"approver": "Administrator"}],
		}
		result = save_org_unit("Department", values, department.name)
		department = frappe.get_doc("Department", result["name"])
		for fieldname in ("shift_request_approver", "leave_approvers", "expense_approvers"):
			self.assertEqual([row.approver for row in department.get(fieldname)], ["Administrator"])
		self.assertTrue({"payroll_cost_center", "leave_block_list"}.issubset(FIELDS["Department"]))

	def test_designation_editor_persists_skills(self):
		suffix = uuid4().hex[:8]
		company = frappe.db.get_value("Company", {}, "name")
		skill = frappe.get_doc({"doctype": "Skill", "skill_name": f"Editor Skill {suffix}"}).insert()
		designation = frappe.get_doc({
			"doctype": "Designation", "designation_name": f"Editor Designation {suffix}", "company": company,
		}).insert()
		result = save_org_unit("Designation", {
			"designation_name": designation.designation_name,
			"company": company,
			"description": "Updated through the shared editor",
			"skills": [{"skill": skill.name}],
		}, designation.name)
		designation = frappe.get_doc("Designation", result["name"])
		self.assertEqual(designation.description, "Updated through the shared editor")
		self.assertEqual([row.skill for row in designation.skills], [skill.name])
		self.assertIn("skills", FIELDS["Designation"])
		self.assertNotIn("appraisal_template", FIELDS["Designation"])

	def test_employee_override_is_preserved(self):
		doc = frappe.get_doc({"doctype": "Employee", "first_name": "Approval", "company": "MBC",
			"expense_approver": "individual@example.com", "karyo_expense_approver_source": "Individual"})
		with patch("karyo.hr.approval_routing.resolve_approvers", return_value={
			"expense_approver": {"approver": "department@example.com", "source": "Department"},
			"leave_approver": {"approver": "department@example.com", "source": "Department"},
			"shift_request_approver": {"approver": "department@example.com", "source": "Department"},
		}):
			prepare_employee_approvers(doc)
		self.assertEqual(doc.expense_approver, "individual@example.com")
		self.assertEqual(doc.karyo_expense_approver_source, "Individual")
		self.assertEqual(doc.leave_approver, "department@example.com")
		self.assertEqual(doc.karyo_leave_approver_source, "Department")

	@patch("frappe.publish_realtime")
	def test_department_changes_sync_inherited_routes_but_not_individual_override(self, _notify):
		suffix = uuid4().hex[:8]
		company = frappe.db.get_value("Company", {}, "name")
		manager_user = f"route-manager-{suffix}@example.test"
		other_user = f"route-other-{suffix}@example.test"
		manager = make_employee(manager_user, company=company)
		make_employee(other_user, company=company)
		department = frappe.get_doc({"doctype": "Department", "department_name": f"Routing {suffix}",
			"company": company}).insert()
		employee = make_employee(f"route-employee-{suffix}@example.test", company=company,
			department=department.name, reports_to=manager)

		person = frappe.get_doc("Employee", employee)
		for field in ("shift_request_approver", "leave_approver", "expense_approver"):
			self.assertEqual(person.get(field), manager_user)

		for field in ("shift_request_approver", "leave_approvers", "expense_approvers"):
			department.set(field, [{"approver": "Administrator"}])
		department.save()
		person.reload()
		for field in ("shift_request_approver", "leave_approver", "expense_approver"):
			self.assertEqual(person.get(field), "Administrator")

		person.expense_approver = manager_user
		person.karyo_expense_approver_source = "Individual"
		person.save()
		for field in ("shift_request_approver", "leave_approvers", "expense_approvers"):
			department.set(field, [{"approver": other_user}])
		department.save()
		person.reload()
		self.assertEqual(person.shift_request_approver, other_user)
		self.assertEqual(person.leave_approver, other_user)
		self.assertEqual(person.expense_approver, manager_user)
		self.assertEqual(person.karyo_expense_approver_source, "Individual")
