"""Payroll wiring for Karyo Passage Benefit.

    bench --site dev.localhost execute karyo.setup.payroll.setup

Creates the default Passage Benefit payroll component (an Earning that pays out
the encashment on the salary slip) and points Passage Benefit Settings at it.
The component (PDB code) is a client sign-off item (OP-PB-005); this is the demo
default and remains overridable per usage item / setting.
"""

import frappe

COMPONENT = "Passage Benefit Encashment"


def create_component():
	if not frappe.db.exists("Salary Component", COMPONENT):
		frappe.get_doc(
			{
				"doctype": "Salary Component",
				"salary_component": COMPONENT,
				"salary_component_abbr": "PBE",
				"type": "Earning",
				"is_tax_applicable": 0,
				"depends_on_payment_days": 0,
			}
		).insert(ignore_permissions=True)
		print(f"  + Salary Component: {COMPONENT}")
	else:
		print(f"  = Salary Component exists: {COMPONENT}")


def setup():
	print("Karyo Passage Benefit payroll setup:")
	create_component()
	frappe.db.set_single_value("Passage Benefit Settings", "pdb_salary_component", COMPONENT)
	# Keep the processing boundary wired to the typed payroll catalogue. The
	# component alone is only a display snapshot; processing requires both codes.
	if frappe.db.exists("Payroll PDB Type", "BEN"):
		frappe.db.set_single_value("Passage Benefit Settings", "payroll_pdb_type", "BEN")
	if frappe.db.exists("Payroll PDB Code", "PBE"):
		frappe.db.set_single_value("Passage Benefit Settings", "payroll_pdb_code", "PBE")
	frappe.db.commit()
	print("Done.")
