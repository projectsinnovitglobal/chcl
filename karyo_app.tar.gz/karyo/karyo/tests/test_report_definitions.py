import unittest

from karyo.setup.workspace import INTEGRATION_REPORTS, LEAVE_ATTENDANCE_REPORTS, PAYROLL_REPORTS, REPORTS, _report_roles


class TestReportDefinitions(unittest.TestCase):
	def test_loan_operational_catalogue_is_unique_and_complete(self):
		names = [report["name"] for report in REPORTS]
		self.assertEqual(len(names), len(set(names)))
		self.assertTrue(
			{
				"Loan Application Register",
				"Loan Committee Review",
				"Loan Agreement Listing",
				"Loan Disbursement Register",
				"Loan Repayment Schedule",
				"Loan Statement",
				"Loan Deduction Report",
				"Loan Guarantor Exposure",
				"Outstanding Loan Balances",
				"Loan Budget - Interest Element",
			} <= set(names)
		)
		self.assertTrue(all(
			report.get("report_type") == "Script Report"
			or report.get("query", "").strip().lower().startswith("select")
			for report in REPORTS
		))

	def test_payroll_control_reports_and_roles(self):
		names = {report["name"] for report in PAYROLL_REPORTS}
		self.assertTrue(
			{"MBC Payroll Register", "MBC Payroll Summary Statistics", "Payroll Exception and Readiness", "Payroll Source to Salary Slip Trace", "Payroll Statutory Reconciliation", "Payroll PDB to GL Mapping"} <= names
		)
		for report in PAYROLL_REPORTS:
			roles = _report_roles(report)
			self.assertIn("Payroll Auditor", roles)
			self.assertNotIn("HR User", roles)

	def test_pb_governance_reports_exist(self):
		names = {report["name"] for report in REPORTS}
		self.assertTrue({"PB Parameter Change History", "PB Run Reconciliation"} <= names)

	def test_leave_attendance_reports_include_hr_and_payroll_control(self):
		names = {report["name"] for report in LEAVE_ATTENDANCE_REPORTS}
		self.assertEqual(
			{"MBC Leave Transaction Reconciliation", "Attendance Punch Exceptions", "Attendance Payment Reconciliation"},
			names,
		)
		for report in LEAVE_ATTENDANCE_REPORTS:
			self.assertIn("HR Manager", _report_roles(report))
			self.assertIn("Payroll Auditor", _report_roles(report))

	def test_integration_monitor_is_restricted(self):
		self.assertEqual(len(INTEGRATION_REPORTS), 1)
		roles = _report_roles(INTEGRATION_REPORTS[0])
		self.assertEqual(roles, ["System Manager", "Integration Manager", "Payroll Auditor"])


if __name__ == "__main__":
	unittest.main()
