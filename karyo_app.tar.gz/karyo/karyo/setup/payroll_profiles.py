"""Payroll Type and recurring Pay Day masters, plus Employee payroll mapping."""

import re

import frappe
from frappe import _
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.utils import cint, flt, getdate, nowdate


PROFILE_LAYOUT = {
	"karyo_hr_sb": {"label": "PRB & PB Settings", "insert_after": "salary_information", "collapsible": 0},
	"karyo_payroll_group": {"insert_after": "karyo_hr_sb", "label": "Salary Group (Payroll Group)"},
	"karyo_payroll_type": {"insert_after": "karyo_payroll_group"},
	"karyo_pay_day": {"insert_after": "karyo_payroll_type"},
	"payroll_cost_center": {"insert_after": "karyo_pay_day"},
	"pb_eligible": {"insert_after": "payroll_cost_center"},
	"karyo_employment_category": {"insert_after": "employment_type"},
	"karyo_employment_category_description": {"insert_after": "karyo_employment_category"},
	"karyo_payroll_eligible": {"insert_after": "karyo_employment_category_description"},
	"karyo_pb_eligibility_rule": {"insert_after": "karyo_payroll_eligible"},
	"karyo_permanent_pensionable": {"insert_after": "karyo_pb_eligibility_rule"},
	"karyo_cb1": {"insert_after": "karyo_permanent_pensionable"},
	"karyo_prb_opted_in": {"insert_after": "payroll_cost_center", "hidden": 1},
	"karyo_prb_grade": {"insert_after": "karyo_prb_opted_in", "label": "PRB Salary Scale / Grade", "hidden": 1},
	"karyo_prb_salary_point": {"insert_after": "karyo_prb_grade", "fieldtype": "Select", "options": None, "hidden": 1},
	"karyo_prb_row3_salary": {"insert_after": "karyo_prb_salary_point", "hidden": 1},
	"karyo_salary_appointment": {"insert_after": "karyo_prb_row3_salary"},
	"karyo_salary_scale": {"insert_after": "karyo_salary_appointment"},
	"karyo_scale_salary_point": {"insert_after": "karyo_salary_scale"},
	"karyo_scale_basic_salary": {"insert_after": "karyo_scale_salary_point", "hidden": 1},
	"karyo_salary_effective_from": {"insert_after": "ctc"},
	"karyo_pb_bank": {"insert_after": "karyo_salary_effective_from"},
	"karyo_prb_pb_status": {"insert_after": "karyo_pb_bank"},
	# Keep identity and general employment controls out of this focused section.
	"karyo_legacy_employee_id": {"insert_after": "employee_number"},
	"karyo_national_id": {"insert_after": "karyo_legacy_employee_id"},
	"karyo_temporary_grade": {"insert_after": "grade"},
	"karyo_retirement_date": {"insert_after": "date_of_retirement", "hidden": 1},
	"karyo_work_pattern": {"insert_after": "holiday_list"},
}

CATEGORY_DEPENDENCY_FIELDS = (
	"map_dependencies", "pensionable", "payroll_eligible", "pb_eligibility_rule",
	"leave_scheme", "loan_eligibility_group", "contribution_group",
)


def _reload_masters():
	for slug in ("payroll_type", "pay_day"):
		frappe.reload_doc("karyo", "doctype", slug)


def _employee_fields():
	create_custom_fields(
		{
			"Employee": [
				{
					"fieldname": "karyo_payroll_type",
					"fieldtype": "Link",
					"label": "Payroll Type",
					"options": "Payroll Type",
					"insert_after": "karyo_payroll_group",
					"in_list_view": 1,
					"description": "Primary payroll stream used to prepare this employee's payroll.",
				},
				{
					"fieldname": "karyo_pay_day",
					"fieldtype": "Link",
					"label": "Pay Day",
					"options": "Pay Day",
					"insert_after": "karyo_payroll_type",
					"in_list_view": 1,
					"description": "Recurring pay-day master for this employee and payroll group.",
				},
				{
					"fieldname": "karyo_pb_bank",
					"fieldtype": "Link",
					"label": "Passage Benefit Bank",
					"options": "Passage Benefit Bank",
					"insert_after": "karyo_salary_effective_from",
					"read_only": 1,
					"no_copy": 1,
					"description": "Live Passage Benefit account mapped to this employee.",
				},
				{
					"fieldname": "karyo_prb_row3_salary",
					"fieldtype": "Currency",
					"label": "PRB Row 3 Salary",
					"insert_after": "karyo_prb_salary_point",
					"read_only": 1,
					"no_copy": 1,
					"description": "Salary from the latest Row 3 PRB Salary Point master value.",
				},
				{
					"fieldname": "karyo_prb_pb_status",
					"fieldtype": "HTML",
					"label": "Synchronized Payroll and Benefit Status",
					"insert_after": "karyo_pb_bank",
				},
			],
		},
		update=True,
	)
	group = frappe.db.get_value("Custom Field", {"dt": "Employee", "fieldname": "karyo_payroll_group"}, "name")
	if group:
		frappe.db.set_value(
			"Custom Field", group,
			{"fieldtype": "Link", "options": "Employee Payroll Group", "in_list_view": 0},
			update_modified=False,
		)
	_arrange_employee_profile_fields()
	make_property_setter("Employee", "salary_information", "label", "Payroll", "Data")
	frappe.clear_cache(doctype="Employee")


def _arrange_employee_profile_fields():
	"""Keep one authoritative PRB/payroll/PB profile together on Overview."""
	for fieldname, values in PROFILE_LAYOUT.items():
		name = frappe.db.get_value("Custom Field", {"dt": "Employee", "fieldname": fieldname}, "name")
		if name:
			frappe.db.set_value("Custom Field", name, values, update_modified=False)


def seed_payroll_types():
	rows = (
		{
			"payroll_type_code": "MINOR",
			"payroll_type_name": "Minor",
			"processing_scope": "Once-off only",
			"sequence": 10,
			"description": "Urgent or exceptional payroll processed before the normal pay day.",
		},
		{
			"payroll_type_code": "MAJOR",
			"payroll_type_name": "Major",
			"processing_scope": "Regular and once-off",
			"sequence": 20,
			"description": "Normal payroll including recurring and once-off payments and deductions.",
		},
	)
	for row in rows:
		name = frappe.db.get_value("Payroll Type", {"payroll_type_code": row["payroll_type_code"]}, "name")
		if not name:
			frappe.get_doc({"doctype": "Payroll Type", "is_active": 1, **row}).insert(ignore_permissions=True)


def seed_employee_company_pay_days():
	"""Give every company with employees a usable Major and Minor profile."""
	companies = frappe.get_all("Employee", fields=["distinct company as company"], pluck="company")
	for company in filter(None, companies):
		for payroll_type, default_day in (("Major", 25), ("Minor", 15)):
			if not frappe.db.exists("Pay Day", {"company": company, "payroll_type": payroll_type}):
				ensure_pay_day(company, payroll_type, default_day)


def ensure_pay_day(company, payroll_type, day_of_month, payroll_group=None, cutoff_lead_days=3):
	"""Return the stable recurring master behind a dated Payroll Pay Day."""
	if not company or not payroll_type or not day_of_month:
		return None
	filters = {
		"company": company,
		"payroll_type": payroll_type,
		"day_of_month": int(day_of_month),
		"payroll_group": payroll_group or ("is", "not set"),
	}
	existing = frappe.db.get_value("Pay Day", filters, "name")
	if existing:
		return existing
	abbr = (frappe.db.get_value("Company", company, "abbr") or "PAY").upper()
	type_code = frappe.db.get_value("Payroll Type", payroll_type, "payroll_type_code") or payroll_type
	group_code = (payroll_group or "ALL").replace(" ", "-").upper()
	code = f"{abbr}-{type_code}-{int(day_of_month):02d}-{group_code}"
	# Legacy rows may store an empty string where the current filter expects
	# NULL. The deterministic code is still the same master, so reuse it.
	if frappe.db.exists("Pay Day", code):
		return code
	return frappe.get_doc(
		{
			"doctype": "Pay Day",
			"pay_day_code": code,
			"pay_day_name": _("{0} Pay Day ({1})").format(payroll_type, int(day_of_month)),
			"company": company,
			"payroll_type": payroll_type,
			"payroll_group": payroll_group,
			"day_of_month": int(day_of_month),
			"cutoff_lead_days": max(0, int(cutoff_lead_days or 0)),
			"is_active": 1,
			"description": _("Recurring {0} payroll schedule for day {1} of the month.").format(
				payroll_type, int(day_of_month)
			),
		}
	).insert(ignore_permissions=True).name


def backfill_pay_day_links():
	meta = frappe.get_meta("Payroll Pay Day")
	if not meta.has_field("pay_day_master"):
		return
	rows = frappe.get_all(
		"Payroll Pay Day",
		fields=["name", "company", "payroll_type", "payroll_group", "payment_date", "input_cutoff_date", "pay_day_master"],
		limit_page_length=0,
	)
	for row in rows:
		if row.pay_day_master or not row.payment_date:
			continue
		payment = getdate(row.payment_date)
		cutoff = getdate(row.input_cutoff_date) if row.input_cutoff_date else payment
		master = ensure_pay_day(
			row.company,
			row.payroll_type,
			payment.day,
			row.payroll_group,
			max(0, (payment - cutoff).days),
		)
		frappe.db.set_value("Payroll Pay Day", row.name, "pay_day_master", master, update_modified=False)


def backfill_employee_profiles():
	meta = frappe.get_meta("Employee")
	if not meta.has_field("karyo_payroll_type") or not meta.has_field("karyo_pay_day"):
		return
	for employee in frappe.get_all(
		"Employee",
		fields=["name", "company", "karyo_payroll_group", "karyo_payroll_type", "karyo_pay_day", "karyo_pb_bank", "karyo_prb_salary_point", "karyo_prb_row3_salary", "karyo_scale_basic_salary", "ctc", "karyo_prb_opted_in"],
		limit_page_length=0,
	):
		values = {}
		payroll_type = employee.karyo_payroll_type or (
			"Major" if frappe.db.exists("Payroll Type", "Major") else frappe.db.get_value("Payroll Type", {"is_active": 1}, "name", order_by="sequence desc")
		)
		if not employee.karyo_payroll_type and payroll_type:
			values["karyo_payroll_type"] = payroll_type
		if not employee.karyo_pay_day and payroll_type:
			filters = {"company": employee.company, "payroll_type": payroll_type, "is_active": 1}
			masters = frappe.get_all("Pay Day", filters=filters, fields=["name", "payroll_group"], order_by="day_of_month desc")
			master = next((row.name for row in masters if row.payroll_group == employee.karyo_payroll_group), None)
			master = master or next((row.name for row in masters if not row.payroll_group), None)
			if master:
				values["karyo_pay_day"] = master
		bank = frappe.db.get_value("Passage Benefit Bank", {"employee": employee.name}, "name")
		if bank and employee.karyo_pb_bank != bank:
			values["karyo_pb_bank"] = bank
		# Older Link-based forms stored the year-prefixed PRB document name.
		# Convert only the unambiguous YYYY-CODE shape; never guess free text.
		legacy_point = re.fullmatch(r"\d{4}-(.+)", str(employee.karyo_prb_salary_point or ""))
		if legacy_point and frappe.db.exists("PRB Salary Point", {"salary_point": legacy_point.group(1)}):
			values["karyo_prb_salary_point"] = legacy_point.group(1)
		point = values.get("karyo_prb_salary_point") or employee.karyo_prb_salary_point
		row3_salary = (prb_salary_value(point, effective_date=nowdate()) if employee.karyo_prb_opted_in else 0) or 0
		if abs(float(employee.karyo_prb_row3_salary or 0) - float(row3_salary)) > 0.005:
			values["karyo_prb_row3_salary"] = row3_salary
		base_salary = employee.karyo_scale_basic_salary or row3_salary or 0
		if abs(float(employee.ctc or 0) - float(base_salary)) > 0.005:
			values["ctc"] = base_salary
		if values:
			frappe.db.set_value("Employee", employee.name, values, update_modified=False)


def backfill_cycle_employee_profiles():
	meta = frappe.get_meta("Payroll Cycle Employee")
	if not all(meta.has_field(field) for field in ("payroll_type", "pay_day", "pay_day_master")):
		return
	frappe.db.sql(
		"""
		update `tabPayroll Cycle Employee` ce
		inner join `tabPayroll Cycle` c on c.name=ce.payroll_cycle
		left join `tabPayroll Pay Day` d on d.name=c.pay_day
		set ce.payroll_type=c.payroll_type,
			ce.pay_day=c.pay_day,
			ce.pay_day_master=d.pay_day_master
		where coalesce(ce.payroll_type, '')='' or coalesce(ce.pay_day, '')=''
		"""
	)


def prepare_employee_profile(doc, method=None):
	"""Supply defaults and keep duplicate standard dates synchronized."""
	_sync_employee_category(doc)
	_auto_assign_prb_conversion(doc)
	_sync_date_alias(doc, "final_confirmation_date", "karyo_date_confirmed")
	_sync_date_alias(doc, "date_of_retirement", "karyo_retirement_date")
	doc.karyo_prb_row3_salary = (prb_salary_value(doc.get("karyo_prb_salary_point"), effective_date=nowdate())
		if doc.get("karyo_prb_opted_in") else 0) or 0
	doc.ctc = doc.get("karyo_scale_basic_salary") or doc.karyo_prb_row3_salary or 0
	if not doc.get("karyo_payroll_type"):
		doc.karyo_payroll_type = "Major" if frappe.db.exists("Payroll Type", "Major") else None
	if not doc.get("karyo_pay_day") and doc.get("company") and doc.get("karyo_payroll_type"):
		filters = {"company": doc.company, "payroll_type": doc.karyo_payroll_type, "is_active": 1}
		rows = frappe.get_all("Pay Day", filters=filters, fields=["name", "payroll_group"], order_by="day_of_month desc")
		doc.karyo_pay_day = next((row.name for row in rows if row.payroll_group == doc.get("karyo_payroll_group")), None)
		doc.karyo_pay_day = doc.karyo_pay_day or next((row.name for row in rows if not row.payroll_group), None)
	# A restricted Pay Day is the authoritative source of its Payroll Group.
	# Align the employee before validation so Payroll Setup can repair legacy or
	# imported profiles instead of rejecting them with a circular form error.
	if doc.get("karyo_pay_day"):
		pay_day_group = frappe.db.get_value("Pay Day", doc.karyo_pay_day, "payroll_group")
		if pay_day_group:
			doc.karyo_payroll_group = pay_day_group
	if not doc.get("payroll_cost_center") and doc.get("company"):
		doc.payroll_cost_center = frappe.db.get_value("Company", doc.company, "cost_center")
	if not doc.is_new() and not doc.get("karyo_pb_bank"):
		doc.karyo_pb_bank = frappe.db.get_value("Passage Benefit Bank", {"employee": doc.name}, "name")


def _auto_assign_prb_conversion(doc):
	"""Derive the PRB grade/point from the employee's governed current scale.

	Explicit valid PRB choices win.  On a fresh opt-in or grade change, the
	conversion first tries the existing point and then the nearest Row-2 salary;
	this prevents selecting PRB from blanking a previously governed salary.
	"""
	if not cint(doc.get("karyo_prb_opted_in")):
		return
	grade = doc.get("karyo_prb_grade")
	if not grade and doc.get("grade"):
		grade_code = frappe.db.get_value("Employee Grade", doc.grade, "karyo_grade_code") or doc.grade
		grade = frappe.db.get_value("PRB Grade Scale", {"grade_id": grade_code, "is_active": 1}, "name")
		grade = grade or frappe.db.get_value("PRB Grade Scale", {"name": doc.grade, "is_active": 1}, "name")
		if grade:
			doc.karyo_prb_grade = grade
	if not grade:
		return
	point = doc.get("karyo_prb_salary_point")
	if point and _point_in_grade(point, grade):
		return
	existing_point = doc.get("karyo_scale_salary_point")
	if existing_point and _point_in_grade(existing_point, grade) and frappe.db.exists(
		"PRB Salary Point", {"salary_point": str(existing_point)}
	):
		doc.karyo_prb_salary_point = str(existing_point)
		return
	limits = frappe.db.get_value("PRB Grade Scale", grade, ["initial_point", "top_point"], as_dict=True)
	rows = frappe.get_all(
		"PRB Salary Point", fields=["salary_point", "gross_2025", "revised_2026"],
		order_by="review_year desc, salary_point asc", limit_page_length=0,
	)
	seen = set()
	rows = [row for row in rows if not (row.salary_point in seen or seen.add(row.salary_point)) and _point_in_grade(row.salary_point, grade)]
	if not rows:
		return
	current_salary = flt(doc.get("karyo_scale_basic_salary") or doc.get("ctc"))
	selected = min(rows, key=lambda row: abs(flt(row.gross_2025 or row.revised_2026) - current_salary)) if current_salary else rows[0]
	doc.karyo_prb_salary_point = str(selected.salary_point)


def normalize_prb_applicability():
	"""Clear legacy PRB values only where applicability is explicitly No."""
	rows = frappe.get_all(
		"Employee",
		filters={"karyo_prb_opted_in": 0},
		fields=["name", "karyo_prb_grade", "karyo_prb_salary_point", "karyo_prb_row3_salary"],
		limit_page_length=0,
	)
	changed = 0
	for row in rows:
		if row.karyo_prb_grade or row.karyo_prb_salary_point or row.karyo_prb_row3_salary:
			frappe.db.set_value(
				"Employee",
				row.name,
				{
					"karyo_prb_grade": None,
					"karyo_prb_salary_point": None,
					"karyo_prb_row3_salary": 0,
				},
				update_modified=False,
			)
			changed += 1
	return {"normalized": changed}


def _sync_employee_category(doc):
	"""Keep Grade, Employment Type and Employee Category on one master mapping."""
	if doc.get("grade") and frappe.get_meta("Employee Grade").has_field("karyo_employee_category"):
		grade = frappe.db.get_value(
			"Employee Grade", doc.grade,
			["karyo_grade_description", "karyo_job_family", "karyo_employee_category", "karyo_is_active"],
			as_dict=True,
		)
		before = doc.get_doc_before_save() if not doc.is_new() else None
		grade_changed = doc.is_new() or not before or before.get("grade") != doc.grade
		if grade and grade_changed and not cint(grade.karyo_is_active):
			frappe.throw(_("Select an active Grade Code."))
		if grade:
			doc.karyo_grade_description = grade.karyo_grade_description
			doc.karyo_job_family = grade.karyo_job_family
		if grade and grade.karyo_employee_category:
			category = frappe.db.get_value(
				"Employee Category", grade.karyo_employee_category,
				["employment_type", "category_name", "disabled", *CATEGORY_DEPENDENCY_FIELDS], as_dict=True,
			)
			if not category or cint(category.disabled):
				frappe.throw(_("Grade {0} is linked to an inactive Employee Category / Grade Group.").format(doc.grade))
			doc.employment_type = category.employment_type
			doc.karyo_employment_category = grade.karyo_employee_category
			doc.karyo_employment_category_description = category.category_name
			_apply_category_dependencies(doc, category)
			return
	if doc.get("employment_type"):
		category = frappe.db.get_value(
			"Employee Category", {"employment_type": doc.employment_type, "disabled": 0},
			["name", "category_name", *CATEGORY_DEPENDENCY_FIELDS], as_dict=True,
		)
		doc.karyo_employment_category = category.name if category else None
		doc.karyo_employment_category_description = category.category_name if category else None
		_apply_category_dependencies(doc, category)
	elif doc.get("karyo_employment_category"):
		category = frappe.db.get_value(
			"Employee Category", doc.karyo_employment_category,
			["employment_type", "category_name", *CATEGORY_DEPENDENCY_FIELDS], as_dict=True,
		)
		doc.employment_type = category.employment_type if category else None
		doc.karyo_employment_category_description = category.category_name if category else None
		_apply_category_dependencies(doc, category)


def _category_pb_eligible(rule, employee):
	rule = str(rule or "").strip()
	if rule == "Eligible":
		return 1
	if rule != "Eligible after Confirmation":
		return 0
	confirmation = employee.get("final_confirmation_date") or employee.get("karyo_date_confirmed")
	return cint(bool(confirmation and getdate(confirmation) <= getdate()))


def _category_dependency_values(category, employee):
	"""Return the Employee fields governed by one opted-in category master."""
	if not category or not cint(category.get("map_dependencies")):
		return {}
	return {
		"karyo_payroll_eligible": cint(category.get("payroll_eligible")),
		"karyo_pb_eligibility_rule": category.get("pb_eligibility_rule") or "Not Eligible",
		"karyo_permanent_pensionable": cint(category.get("pensionable")),
		"pb_eligible": _category_pb_eligible(category.get("pb_eligibility_rule"), employee),
		"karyo_leave_scheme": category.get("leave_scheme") or None,
		"karyo_loan_eligibility_group": category.get("loan_eligibility_group") or None,
		"karyo_contribution_group": category.get("contribution_group") or None,
	}


def _apply_category_dependencies(employee, category):
	for fieldname, value in _category_dependency_values(category, employee).items():
		if employee.meta.has_field(fieldname):
			employee.set(fieldname, value)


def sync_employee_category_dependents(category):
	"""Refresh existing linked employees immediately after a category change."""
	if cint(category.get("disabled")) or not cint(category.get("map_dependencies")):
		return 0
	from karyo.hr.leave_controls import sync_category_leave_scheme_selection

	meta = frappe.get_meta("Employee")
	fields = [
		"name", "final_confirmation_date", "karyo_date_confirmed",
		"karyo_employment_category", "employment_type",
	]
	fields = [fieldname for fieldname in fields if fieldname == "name" or meta.has_field(fieldname)]
	employees = frappe.get_all(
		"Employee",
		or_filters={
			"karyo_employment_category": category.name,
			"employment_type": category.employment_type,
		},
		fields=fields,
		limit_page_length=0,
	)
	for employee in employees:
		values = _category_dependency_values(category, employee)
		values.update({
			"employment_type": category.employment_type,
			"karyo_employment_category": category.name,
			"karyo_employment_category_description": category.category_name,
		})
		frappe.db.set_value("Employee", employee.name, values, update_modified=False)
		sync_category_leave_scheme_selection(employee.name, values.get("karyo_leave_scheme"))
	return len(employees)


def _sync_date_alias(doc, standard_field, profile_field):
	"""Propagate a date edited on either Employee surface to the other one."""
	standard, profile = doc.get(standard_field), doc.get(profile_field)
	before = doc.get_doc_before_save() if not doc.is_new() else None
	if standard == profile:
		return
	if before:
		standard_changed = standard != before.get(standard_field)
		profile_changed = profile != before.get(profile_field)
		if standard_changed and not profile_changed:
			doc.set(profile_field, standard)
			return
		if profile_changed:
			doc.set(standard_field, profile)
			return
	if profile:
		doc.set(standard_field, profile)
	elif standard:
		doc.set(profile_field, standard)


def validate_employee_profile(doc, method=None):
	_validate_prb_salary_point(doc)
	if not doc.get("karyo_payroll_type") and not doc.get("karyo_pay_day"):
		return
	if doc.get("karyo_payroll_type") and not frappe.db.get_value("Payroll Type", doc.karyo_payroll_type, "is_active"):
		frappe.throw(_("Select an active Payroll Type for this employee."))
	if not doc.get("karyo_pay_day"):
		return
	master = frappe.db.get_value(
		"Pay Day", doc.karyo_pay_day, ["company", "payroll_type", "payroll_group", "is_active"], as_dict=True
	)
	if not master or not master.is_active:
		frappe.throw(_("Select an active Pay Day for this employee."))
	if master.company != doc.company:
		frappe.throw(_("The employee Pay Day belongs to a different company."))
	if doc.get("karyo_payroll_type") and master.payroll_type != doc.karyo_payroll_type:
		frappe.throw(_("The employee Pay Day does not belong to the selected Payroll Type."))
	if master.payroll_group and doc.get("karyo_payroll_group") != master.payroll_group:
		frappe.throw(_("The employee Pay Day is restricted to payroll group {0}.").format(master.payroll_group))


def _point_number(value):
	try:
		return int(str(value).strip())
	except (TypeError, ValueError):
		return None


def _point_in_grade(point, grade):
	if not grade:
		return True
	limits = frappe.db.get_value(
		"PRB Grade Scale", grade, ["initial_point", "top_point"], as_dict=True
	)
	if not limits:
		return False
	value, low, high = map(_point_number, (point, limits.initial_point, limits.top_point))
	if None not in (value, low, high):
		return low <= value <= high
	return str(limits.initial_point or "") <= str(point or "") <= str(limits.top_point or "")


def prb_salary_value(point, review_year=None, effective_date=None):
	if not point:
		return None
	review_year = review_year or frappe.db.get_value("PRB Salary Point", {}, "max(review_year)")
	fields = ["gross_2025", "revised_2026"] if effective_date else "revised_2026"
	values = frappe.db.get_value(
		"PRB Salary Point", {"review_year": review_year, "salary_point": str(point)}, fields, as_dict=bool(effective_date)
	)
	if not effective_date or not values:
		return values
	if cint(review_year) != 2026:
		return values.revised_2026
	from karyo.prb.salary_phases import phased_salary

	return phased_salary(values.gross_2025, values.revised_2026, effective_date)


def _validate_prb_salary_point(doc):
	point = doc.get("karyo_prb_salary_point")
	if not point:
		return
	exists = frappe.db.exists("PRB Salary Point", {"salary_point": str(point)})
	in_grade = not doc.get("karyo_prb_grade") or _point_in_grade(point, doc.karyo_prb_grade)
	if not exists or not in_grade:
		before = doc.get_doc_before_save() if hasattr(doc, "get_doc_before_save") and not doc.is_new() else None
		# Surface historic invalid values in the live dropdown without preventing
		# an unrelated Employee edit. A newly selected value must always be valid.
		if before and before.get("karyo_prb_salary_point") == point:
			return
	if not exists:
		frappe.throw(_("Select a salary point from the PRB Salary Point master."))
	if not in_grade:
		frappe.throw(_("PRB Salary Point {0} is outside the selected PRB Grade range.").format(point))


@frappe.whitelist()
def prb_salary_point_options(grade=None, current=None, company=None, effective_date=None):
	"""Return current master values for the Employee dropdown, grade-filtered."""
	if not frappe.has_permission("Employee", "read"):
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	year = frappe.db.get_value("PRB Salary Point", {}, "max(review_year)")
	rows = frappe.get_all(
		"PRB Salary Point",
		filters={"review_year": year} if year else {},
		fields=["salary_point", "review_year", "gross_2025", "revised_2026"],
		order_by="salary_point asc",
		limit_page_length=0,
	)
	grade_range = frappe.db.get_value(
		"PRB Grade Scale", grade, ["initial_point", "top_point"], as_dict=True
	) if grade else None
	# If a legacy grade value no longer exists, show the complete master rather
	# than an empty dropdown so HR can repair the mapping immediately.
	available = [row for row in rows if not grade_range or _point_in_grade(row.salary_point, grade)]
	values = [str(row.salary_point) for row in available]
	selected = next((row for row in rows if str(row.salary_point) == str(current or "")), None)
	currency = frappe.db.get_value("Company", company, "default_currency") if company else None
	return {
		"review_year": year,
		"values": values,
		"points": [
			{
				"value": str(row.salary_point),
				"salary": prb_salary_value(row.salary_point, row.review_year, effective_date) if effective_date else row.revised_2026,
				"full_salary": row.revised_2026,
			}
			for row in available
		],
		"selected_salary": (
			prb_salary_value(selected.salary_point, selected.review_year, effective_date)
			if selected and str(current) in values and effective_date else
			selected.revised_2026 if selected and str(current) in values else None
		),
		"phase_percentage": 50 if effective_date and getdate(effective_date) < getdate("2027-01-01") and getdate(effective_date) >= getdate("2026-01-01") else 100 if effective_date and getdate(effective_date) >= getdate("2027-01-01") else 0,
		"currency": currency or "MUR",
		"grade_valid": bool(grade_range) if grade else True,
		"range": {
			"initial_point": grade_range.initial_point if grade_range else (values[0] if values else None),
			"top_point": grade_range.top_point if grade_range else (values[-1] if values else None),
			"minimum_salary": min((row.revised_2026 for row in available if row.revised_2026 is not None), default=None),
			"maximum_salary": max((row.revised_2026 for row in available if row.revised_2026 is not None), default=None),
		},
	}


@frappe.whitelist()
def company_profile_defaults(company, payroll_group=None, payroll_type=None):
	if not frappe.has_permission("Employee", "write"):
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	if not company or not frappe.db.exists("Company", company):
		return {}
	payroll_type = payroll_type or (
		"Major" if frappe.db.exists("Payroll Type", "Major") else
		frappe.db.get_value("Payroll Type", {"is_active": 1}, "name", order_by="sequence desc")
	)
	rows = frappe.get_all(
		"Pay Day", filters={"company": company, "payroll_type": payroll_type, "is_active": 1},
		fields=["name", "payroll_group"], order_by="day_of_month desc", limit_page_length=0,
	) if payroll_type else []
	selected = next((row for row in rows if payroll_group and row.payroll_group == payroll_group), None)
	selected = selected or next((row for row in rows if not row.payroll_group), None)
	# A company/payroll stream with one active Pay Day is unambiguous. Use its
	# governed group as the setup default instead of leaving both controls blank.
	selected = selected or (rows[0] if len(rows) == 1 else None)
	return {
		"payroll_type": payroll_type,
		"payroll_group": selected.payroll_group if selected and selected.payroll_group else payroll_group,
		"pay_day": selected.name if selected else None,
		"salary_currency": frappe.db.get_value("Company", company, "default_currency"),
		"payroll_cost_center": frappe.db.get_value("Company", company, "cost_center"),
	}


@frappe.whitelist()
def employee_dependency_context(employee):
	doc = frappe.get_doc("Employee", employee)
	doc.check_permission("read")
	from karyo.passage_benefit.eligibility import evaluate as evaluate_pb_eligibility

	bank = frappe.db.get_value(
		"Passage Benefit Bank", {"employee": employee},
		["name", "status", "eligible_from_date", "current_balance"], as_dict=True,
	)
	return {
		"payroll_type": doc.get("karyo_payroll_type"),
		"pay_day": doc.get("karyo_pay_day"),
		"salary_appointment": doc.get("karyo_salary_appointment"),
		"bank": bank,
		"pb_eligibility": evaluate_pb_eligibility(employee, nowdate()),
	}


def sync_passage_benefit_bank(doc, method=None):
	"""Bind a newly created or edited PB Bank back to its Employee."""
	if not doc.get("employee") or not frappe.get_meta("Employee").has_field("karyo_pb_bank"):
		return
	if frappe.db.get_value("Employee", doc.employee, "karyo_pb_bank") != doc.name:
		frappe.db.set_value("Employee", doc.employee, "karyo_pb_bank", doc.name, update_modified=False)


def clear_passage_benefit_bank(doc, method=None):
	if doc.get("employee") and frappe.db.get_value("Employee", doc.employee, "karyo_pb_bank") == doc.name:
		frappe.db.set_value("Employee", doc.employee, "karyo_pb_bank", None, update_modified=False)


def sync_employee_salary_structure(doc, method=None):
	"""Propagate a changed PRB Row-3 point into the native payroll assignment."""
	if getattr(doc.flags, "skip_prb_assignment_sync", False):
		return
	before = doc.get_doc_before_save()
	if before and before.get("karyo_prb_salary_point") == doc.get("karyo_prb_salary_point"):
		return
	if doc.get("karyo_prb_opted_in") and doc.get("karyo_prb_salary_point") and doc.get("karyo_prb_row3_salary"):
		from karyo.payroll.employee_salary_workspace import sync_base_from_prb_point

		sync_base_from_prb_point(doc.name, doc.karyo_prb_salary_point)


def apply():
	_reload_masters()
	_employee_fields()
	seed_payroll_types()
	backfill_pay_day_links()
	seed_employee_company_pay_days()
	backfill_employee_profiles()
	backfill_cycle_employee_profiles()
	frappe.clear_cache()


def setup():
	apply()
	frappe.db.commit()
	print("  + Payroll Type / Pay Day masters and Employee mappings ensured")
