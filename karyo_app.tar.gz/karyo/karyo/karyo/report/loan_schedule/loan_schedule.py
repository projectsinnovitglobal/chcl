import frappe
from frappe import _
from frappe.utils import flt
from karyo.karyo.report.loan_report_utils import add_loan_permission_condition


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = []
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	if not filters.include_superseded:
		conditions.append("s.is_current=1")
	if filters.loan:
		conditions.append("l.name=%(loan)s")
	if filters.employee:
		conditions.append("l.employee=%(employee)s")
	if filters.from_date:
		conditions.append("s.due_date >= %(from_date)s")
	if filters.to_date:
		conditions.append("s.due_date <= %(to_date)s")
	if filters.version:
		conditions.append("s.schedule_version=%(version)s")
	where = " and ".join(conditions) or "1=1"
	rows = frappe.db.sql(f"""
		select l.name loan, l.employee, l.loan_type, s.name schedule_row, s.schedule_version,
			s.is_current, s.month, s.due_date, s.opening_balance, s.capital, s.interest_generated, s.interest,
			s.insurance, s.total, s.closing_balance, s.paid_capital, s.paid_interest,
			s.paid_insurance, s.status, s.superseded_by_doctype, s.superseded_by_name
		from `tabKaryo Loan Schedule` s
		inner join `tabKaryo Loan` l on l.name=s.parent
		where {where}
		order by l.employee, l.name, s.schedule_version, s.due_date, s.month
	""", filters, as_dict=True)
	allocations_by_row = {}
	if rows:
		for allocation in frappe.get_all("Karyo Loan Payroll Allocation",
			filters={"schedule_row": ("in", [row.schedule_row for row in rows])},
			fields=["name", "schedule_row", "salary_slip", "payroll_cycle", "component", "amount", "posting_date", "is_reversal", "reversal_of"], limit_page_length=0):
			allocations_by_row.setdefault(allocation.schedule_row, []).append(allocation)
	for row in rows:
		all_allocations = allocations_by_row.get(row.schedule_row, [])
		reversed_names = {a.reversal_of for a in all_allocations if a.is_reversal and a.reversal_of}
		allocations = [a for a in all_allocations if not a.is_reversal and a.name not in reversed_names]
		row.payroll_reference = ", ".join(sorted({a.salary_slip for a in allocations if a.salary_slip}))
		row.payroll_cycle = ", ".join(sorted({a.payroll_cycle for a in allocations if a.payroll_cycle}))
		row.actual_repayment_date = max((a.posting_date for a in allocations if a.posting_date), default=None)
		if not row.actual_repayment_date and row.status == "Paid":
			row.actual_repayment_date = frappe.db.get_value(
				"Karyo Loan Settlement", {"loan": row.loan, "docstatus": 1}, "refund_date", order_by="refund_date desc"
			)
		row.capital_status = _component_status(row.capital, row.paid_capital)
		row.interest_status = _component_status(row.interest, row.paid_interest)
		row.insurance_status = _component_status(row.insurance, row.paid_insurance)
		row.paid_total = flt(row.paid_capital) + flt(row.paid_interest) + flt(row.paid_insurance)
		row.outstanding_total = flt(row.total) - row.paid_total
		row.remarks = (f"Superseded by {row.superseded_by_doctype} {row.superseded_by_name}" if not row.is_current and row.superseded_by_name else "")
	return _columns(), rows


def _component_status(due, paid):
	due, paid = flt(due), flt(paid)
	if due <= 0:
		return "Not Applicable"
	if paid >= due - 0.005:
		return "Paid"
	return "Partly Paid" if paid > 0 else "Pending"


def _columns():
	def c(fieldname, label, fieldtype="Data", width=110, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("loan", "Loan", "Link", 145, "Karyo Loan"), c("employee", "Employee", "Link", 130, "Employee"),
		c("schedule_version", "Version", "Int", 70), c("is_current", "Current", "Check", 65), c("month", "Month", "Int", 60),
		c("due_date", "Due Date", "Date", 95), c("actual_repayment_date", "Actual Repayment Date", "Date", 125),
		c("opening_balance", "Opening", "Currency"), c("capital", "Capital", "Currency"),
		c("capital_status", "Capital Status", width=105), c("interest_generated", "Interest Generated", "Currency", 130),
		c("interest", "Interest Recovery", "Currency", 125), c("interest_status", "Interest Status", width=105),
		c("insurance", "Insurance", "Currency"), c("insurance_status", "Insurance Status", width=110), c("total", "Scheduled Total", "Currency", 120),
		c("paid_total", "Paid Total", "Currency"), c("outstanding_total", "Outstanding", "Currency"), c("closing_balance", "Closing", "Currency"),
		c("status", "Row Status", width=90), c("payroll_reference", "Payroll / Receipt Reference", width=190),
		c("payroll_cycle", "Payroll Cycle", width=140), c("remarks", "Remarks", width=220)]
