from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

def apply():
	create_custom_fields({
		"Karyo Settings":[{"fieldname":"loan_insurance_calculation_unit","fieldtype":"Float","label":"Loan Insurance Calculation Unit","default":"10000","insert_after":"loan_interest_recovery_method","description":"Monthly insurance = rate × sum assured / (unit × 12). Applies to new or reworked applications."}],
		"Karyo Loan":[{"fieldname":"insurance_calculation_unit","fieldtype":"Float","label":"Insurance Calculation Unit","default":"10000","read_only":1,"insert_after":"insurance_rate"}],
	},update=True)
