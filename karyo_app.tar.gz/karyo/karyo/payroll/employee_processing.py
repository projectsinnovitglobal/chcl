"""Employee-scoped draft processing; cycle approval/release remain governed."""
import frappe
from frappe import _
from frappe.utils import now_datetime, getdate, flt
from karyo.payroll.governance import has_actor_role

ACTIONS = ('Open Inputs', 'Run Readiness Checks', 'Start Processing', 'Prepare Payroll', 'Generate Draft Salary Slips')


def resolve_employees(cycle, employees=None):
    if isinstance(employees, str):
        employees = frappe.parse_json(employees)
    if employees is not None and (not isinstance(employees, list) or any(not isinstance(e, str) for e in employees)):
        frappe.throw(_('Select employees from the employee filter.'))
    requested = list(dict.fromkeys(employees or []))
    from karyo.desk.payroll_management import employee_run_eligibility
    pay_day = frappe.db.get_value('Payroll Pay Day', cycle.pay_day,
        ['pay_day_master','payroll_group'], as_dict=True)
    pay_day_master = pay_day.pay_day_master if pay_day else None
    filters = {'company': cycle.company, 'status': 'Active',
        'date_of_joining': ('<=', cycle.end_date), 'karyo_payroll_type': cycle.payroll_type}
    if pay_day_master:
        filters['karyo_pay_day'] = pay_day_master
    if pay_day and pay_day.payroll_group:
        filters['karyo_payroll_group'] = pay_day.payroll_group
    rows = frappe.get_list('Employee', filters=filters, fields=['name','employee_name','status','date_of_joining','relieving_date','karyo_post_exit_payroll_enabled','karyo_post_exit_payroll_until','karyo_post_exit_payment_reference'],
        order_by='employee_name asc', limit_page_length=0)
    rows = [r for r in rows if employee_run_eligibility(r, cycle.start_date, cycle.end_date)['eligible']]
    # An explicit Excluded cycle row is the persisted run membership decision.
    # Keep removed employees out of both the default population and stale UI
    # selections; otherwise every screen refresh rebuilds the scope from all
    # active employees and silently adds them back to the prepared run.
    excluded_rows = frappe.get_all('Payroll Cycle Employee', filters={
        'payroll_cycle': cycle.name, 'status': 'Excluded'}, fields=['employee', 'exclusion_reason'])
    exclusions = {row.employee: row.exclusion_reason for row in excluded_rows}
    rows = [row for row in rows if row.name not in exclusions]
    allowed = {r.name for r in rows}
    rejected = list(dict.fromkeys(e for e in requested if e not in allowed))
    if rejected:
        # Explain accessible records without revealing records hidden by User Permissions.
        visible = frappe.get_list('Employee', filters={'name': ('in', rejected)},
            fields=['name', 'employee_name', 'company', 'status', 'date_of_joining', 'relieving_date', 'karyo_post_exit_payroll_enabled', 'karyo_post_exit_payroll_until', 'karyo_post_exit_payment_reference'],
            limit_page_length=0)
        reasons = []
        for employee in visible:
            if employee.name in exclusions:
                reason = exclusions[employee.name] or _('Employee was removed from this payroll run.')
            elif employee.company != cycle.company:
                reason = _('Employee belongs to {0}, not {1}.').format(employee.company, cycle.company)
            else:
                reason = employee_run_eligibility(employee, cycle.start_date, cycle.end_date)['reason']
            reasons.append('{0}: {1}'.format(employee.employee_name or employee.name, reason or _('Not eligible for this pay day.')))
        hidden = len(rejected) - len(visible)
        if hidden:
            reasons.append(_('{0} selected employee record(s) do not exist or are not accessible.').format(hidden))
        frappe.throw(_('The employee selection does not match this pay day ({0} to {1}): {2}').format(
            cycle.start_date, cycle.end_date, ' '.join(reasons)))
    return requested or [r.name for r in rows], rows


def counts(cycle, employees):
    result = {'blocking': 0, 'approval_required': 0, 'warnings': 0}
    if not employees:
        return result
    rows = frappe.get_all('Payroll Readiness Exception', filters={'payroll_cycle':cycle.name,
        'employee':('in',employees),'status':'Open'},fields=['severity'], limit_page_length=0)
    for row in rows:
        if row.severity in ('Blocking','Approval Required'): result['blocking'] += 1
        if row.severity == 'Approval Required': result['approval_required'] += 1
        if row.severity == 'Warning': result['warnings'] += 1
    return result


def blocker_details(cycle, employees):
    """Return actionable blockers with the employee identity kept intact."""
    if not employees:
        return []
    rows = frappe.get_all('Payroll Readiness Exception', filters={
        'payroll_cycle':cycle.name, 'employee':('in',employees), 'status':'Open',
        'severity':('in',('Blocking','Approval Required'))},
        fields=['employee','validation_code','severity','message','remediation_doctype','remediation_name'],
        order_by='employee asc, validation_code asc', limit_page_length=0)
    names = {row.name:row.employee_name for row in frappe.get_all('Employee',
        filters={'name':('in',list({row.employee for row in rows if row.employee}) or [''])},
        fields=['name','employee_name'], limit_page_length=0)}
    return [{**dict(row), 'employee_name':names.get(row.employee) or row.employee} for row in rows]


def blocker_message(blockers):
    if not blockers:
        return ''
    lines = [_('Blocked employees and required actions:')]
    for row in blockers:
        identity = '{0} ({1})'.format(row.get('employee_name') or row.get('employee'), row.get('employee'))
        lines.append('- {0}: {1}'.format(identity, row.get('message') or row.get('validation_code')))
    return '\n'.join(lines)


def employee_error_message(employee, error):
    employee_name = frappe.db.get_value('Employee', employee, 'employee_name') or employee
    return _('Employee {0} ({1}) is blocked: {2}').format(employee_name, employee, str(error))


def population(cycle, employees):
    return {r.employee:r for r in frappe.get_all('Payroll Cycle Employee', filters={
        'payroll_cycle':cycle.name,'employee':('in',employees)}, fields=['name','employee','status','payroll_entry',
        'salary_slip','readiness_checked_on','processing_started_on'])} if employees else {}


def prepared_population(cycle, entry):
    """Employees governed by this cycle/entry, including safe supplements."""
    if not entry or entry.docstatus == 2:
        return set()
    prepared = {row.employee for row in entry.employees}
    prepared.update(frappe.get_all('Payroll Cycle Employee', filters={
        'payroll_cycle':cycle.name, 'payroll_entry':entry.name,
        'status':('not in',('Excluded','Failed'))}, pluck='employee'))
    return prepared


def mark(cycle, employee, **values):
    name = frappe.db.get_value('Payroll Cycle Employee', {'business_key':f'{cycle.name}|{employee}'}, 'name')
    if name:
        frappe.db.set_value('Payroll Cycle Employee', name, values)
    else:
        frappe.get_doc({'doctype':'Payroll Cycle Employee','payroll_cycle':cycle.name,'employee':employee,
            'status':'Included', **values}).insert(ignore_permissions=True)


def recheck(cycle, employees):
    from karyo.payroll.readiness import run_readiness
    run_readiness(cycle.name, employees, update_cycle=False)
    checked = now_datetime()
    for employee in employees:
        mark(cycle, employee, readiness_checked_on=checked)
    # Preserve the cycle-wide gate: a partial check must never mark everyone Ready.
    all_employees, _options = resolve_employees(cycle)
    checked_rows = population(cycle, all_employees)
    full_counts = counts(cycle, all_employees)
    all_checked = bool(all_employees) and all(checked_rows.get(e, {}).get('readiness_checked_on') for e in all_employees)
    frappe.db.set_value('Payroll Cycle', cycle.name, {
        'readiness_status': 'Ready' if all_checked and not full_counts['blocking'] else 'Blocked',
        'exception_count': full_counts['blocking'], 'employee_count': len(all_employees)}, update_modified=False)
    result = counts(cycle, employees)
    result['blockers'] = blocker_details(cycle, employees)
    return result


def state(cycle, employees):
    employees, options = resolve_employees(cycle, employees)
    rows = population(cycle, employees)
    exceptions = counts(cycle, employees)
    checked = bool(employees) and all(rows.get(e, {}).get('readiness_checked_on') for e in employees)
    ready = checked and not exceptions['blocking']
    entry = frappe.db.get_value('Payroll Entry', cycle.payroll_entry, ['name','docstatus','status'], as_dict=True) if cycle.payroll_entry else None
    entry_ok = bool(entry and entry.docstatus != 2)
    prepared_employees = prepared_population(cycle, frappe.get_doc('Payroll Entry', entry.name)) if entry_ok else set()
    slips = frappe.get_all('Salary Slip', filters={'karyo_payroll_cycle':cycle.name,
        'employee':('in',employees),'docstatus':('<',2)}, fields=['name','employee','docstatus','gross_pay','net_pay']) if employees else []
    if entry_ok and employees:
        slips += frappe.get_all('Salary Slip', filters={'payroll_entry':entry.name,'employee':('in',employees),
            'docstatus':('<',2)}, fields=['name','employee','docstatus','gross_pay','net_pay'])
    slips = list({s.name:s for s in slips}.values())
    generated = {s.employee for s in slips}
    from karyo.payroll.input_posting import pending_cycle_inputs
    pending_input_employees = set(pending_cycle_inputs(cycle)['employees'])
    later = cycle.status in ('Review','Approved','Closed')
    done = {
        'Open Inputs':cycle.status in ('Input Open','Processing','Reopened') or later,
        'Run Readiness Checks':ready,
        'Start Processing':(cycle.status == 'Processing' or later) and bool(employees) and all(rows.get(e,{}).get('processing_started_on') or e in generated for e in employees),
        'Prepare Payroll':bool(employees) and set(employees).issubset(prepared_employees),
        'Generate Draft Salary Slips':bool(employees) and set(employees).issubset(generated)
            and not set(employees).intersection(pending_input_employees),
    }
    active = next((a for a in ACTIONS if not done[a]), None)
    from karyo.desk.payroll_management import PAYROLL_STEPS
    hints = {a:hint for a,screen,hint,statuses in PAYROLL_STEPS}
    from karyo.payroll.sequencing import major_sequence_requirement
    sequence_reason, _minor = major_sequence_requirement(cycle, employees)
    from karyo.payroll.pre_payroll_earnings import readiness as pre_payroll_readiness
    pre_payroll = pre_payroll_readiness(cycle, employees)
    if not pre_payroll['complete']:
        pending = ', '.join(row['label'] for row in pre_payroll['checks'] if not row['complete'])
        sequence_reason = _('Complete and submit current-month pre-payroll calculations first: {0}.').format(pending)
    steps=[]
    for action in ACTIONS:
        reason=None
        running=bool(action==ACTIONS[-1] and entry_ok and entry.status=='Queued' and not done[action])
        if done[action]: reason=_('Completed for this selection.')
        elif not employees: reason=_('No eligible employees are available for this pay day.')
        elif action!=active: reason=_('Complete {0} first.').format(active)
        elif cycle.docstatus!=0 or cycle.status not in ('Draft','Input Open','Processing','Reopened'):
            reason=_('This payroll cycle is locked for processing. Follow its review/reopen workflow.')
        elif not has_actor_role('processor'): reason=_('A payroll processor must run this step.')
        elif action in ('Start Processing', 'Prepare Payroll') and not pre_payroll['complete']:
            reason=_('Complete and submit current-month pre-payroll calculations first: {0}.').format(
                ', '.join(row['label'] for row in pre_payroll['checks'] if not row['complete']))
        elif action == 'Start Processing' and sequence_reason: reason=sequence_reason
        elif running: reason=_('Payslip generation is queued. Refresh to check completion.')
        population_amendment = bool(action == 'Prepare Payroll' and entry and entry.docstatus == 1
            and set(employees) - prepared_employees)
        steps.append({'action':action,
            'label':_('Amend Employee Population') if population_amendment else _(action),
            'population_amendment':population_amendment,
            'screen':'process',
            'hint':_('Add the selected employees without changing existing submitted payslips or accounting entries.')
                if population_amendment else _(hints[action]),'done':done[action],
            'next':action==active,'available':reason is None,'blocked_reason':reason,'running':running})
    return {'employees':employees,'options':[{'value':r.name,'label':r.employee_name,'description':r.name} for r in options],
        'sequence_blocked_reason':sequence_reason if not done['Start Processing'] else None,
        'population_amendment_required':bool(entry and entry.docstatus == 1
            and set(employees) - prepared_employees),
        'payroll_entry':dict(entry) if entry else None,
        'pre_payroll':pre_payroll,
        'steps':steps,'counts':exceptions,'blockers':blocker_details(cycle, employees),
        'ready':ready,'checked':checked,'slips':slips,
        'summary':{'employees':len(employees),'slips':len(slips),'draft':sum(s.docstatus==0 for s in slips),
            'submitted':sum(s.docstatus==1 for s in slips),'gross_pay':sum(flt(s.gross_pay) for s in slips),
            'net_pay':sum(flt(s.net_pay) for s in slips)}}


def assert_ready(cycle, employees):
    result=recheck(cycle,employees)
    if result['blocking']:
        frappe.throw(blocker_message(result['blockers']))


def prepare(cycle, employees):
    from karyo.payroll.process import _ensure_payroll_entry, prepare_entry_population
    from karyo.payroll.input_posting import materialize_cycle_inputs
    input_result = materialize_cycle_inputs(cycle)
    assert_ready(cycle,employees)
    from karyo.payroll.attendance_bonus import process_automatic_attendance_bonuses
    bonus_result = process_automatic_attendance_bonuses(cycle, employees)
    from karyo.payroll.pre_payroll_earnings import assert_complete
    assert_complete(cycle, employees)
    entry, reused = _ensure_payroll_entry(cycle,employees)
    entry.check_permission('write')
    amendment = prepare_entry_population(cycle, entry, employees)
    frappe.db.set_value('Payroll Cycle',cycle.name,'payroll_entry',entry.name)
    existing_rows = population(cycle, employees)
    for employee in employees:
        values = {'payroll_entry': entry.name, 'last_processed_on': now_datetime()}
        if not existing_rows.get(employee, {}).get('salary_slip'):
            values['status'] = 'Payroll Entry Ready'
        mark(cycle, employee, **values)
    supplemental = len(amendment['supplemental'])
    return {'payroll_entry':entry.name,'prepared':len(employees),'reused':reused,
        'supplemental':supplemental,
        'attendance_bonus': bonus_result, 'payroll_inputs': input_result,
        'message':_('Employee population amended for {0} employee(s). Existing submitted payroll results were not changed.').format(supplemental)
            if supplemental else _('Prepare Payroll completed for {0} employee(s).').format(len(employees))}


def generate(cycle, employees):
    from karyo.payroll.input_posting import materialize_cycle_inputs
    input_result = materialize_cycle_inputs(cycle)
    assert_ready(cycle,employees)
    entry=frappe.get_doc('Payroll Entry',cycle.payroll_entry)
    entry.check_permission('write')
    if entry.docstatus==2 or entry.status=='Queued':
        frappe.throw(_('The Payroll Entry is cancelled or generation is already queued.'))
    if entry.company!=cycle.company or entry.get('karyo_payroll_cycle')!=cycle.name:
        frappe.throw(_('Payroll Entry does not belong to this payroll cycle.'))
    if not set(employees).issubset(prepared_population(cycle, entry)):
        frappe.throw(_('Prepare Payroll for every selected employee first.'))
    if not frappe.has_permission('Salary Slip','create'):
        frappe.throw(_('Not permitted to generate Salary Slips.'),frappe.PermissionError)
    created=0
    for employee in employees:
        messages_before = list(getattr(frappe.local, 'message_log', []) or [])
        try:
            existing=frappe.get_all('Salary Slip',filters={'employee':employee,'company':cycle.company,
                'start_date':cycle.start_date,'end_date':cycle.end_date,'docstatus':('<',2)},
                fields=['name','payroll_entry','karyo_payroll_cycle','docstatus'],limit_page_length=0)
            slip=next((s for s in existing if s.payroll_entry==entry.name or s.karyo_payroll_cycle==cycle.name),None)
            if existing and not slip:
                frappe.throw(_('Employee {0} already has a Salary Slip for these dates in another run. Review it before generating.').format(employee))
            if not slip:
                args={field:entry.get(field) for field in ('salary_slip_based_on_timesheet','payroll_frequency','start_date',
                    'end_date','company','posting_date','deduct_tax_for_unclaimed_employee_benefits',
                    'deduct_tax_for_unsubmitted_tax_exemption_proof','exchange_rate','currency')}
                # Native Salary Slip validation/calculation, without the bulk helper's
                # unconditional commit or generation for unselected employees.
                slip=frappe.get_doc({'doctype':'Salary Slip',**args,'employee':employee,
                    'payroll_entry':entry.name,'karyo_payroll_cycle':cycle.name}).insert()
                created+=1
            elif not slip.payroll_entry and slip.docstatus==0:
                frappe.db.set_value('Salary Slip',slip.name,'payroll_entry',entry.name)
            mark(cycle,employee,status='Salary Slip Created',payroll_entry=entry.name,salary_slip=slip.name,
                last_processed_on=now_datetime(),exclusion_reason=None)
        except frappe.ValidationError as error:
            frappe.local.message_log = messages_before
            frappe.throw(employee_error_message(employee, error))
    expected = prepared_population(cycle, entry)
    actual = set(frappe.get_all('Salary Slip', filters={'payroll_entry':entry.name,'docstatus':('<',2)}, pluck='employee'))
    if expected and expected.issubset(actual):
        entry.db_set({'salary_slips_created':1, 'error_message':'', 'status':'Submitted' if entry.docstatus==1 else 'Draft'})
    return {'generated':created,'reused':len(employees)-created,'queued':False,
        'payroll_inputs':input_result}


def run(cycle, action, employees):
    selected, _options = resolve_employees(cycle,employees)
    current=state(cycle,selected)
    step=next((s for s in current['steps'] if s['action']==action),None)
    if not step or not step['available']:
        frappe.throw(step['blocked_reason'] if step else _('Select one of the five processing steps.'))
    from karyo.payroll.completion import run_step
    from karyo.payroll.process import _log
    if action=='Open Inputs':
        result=run_step(cycle.name,action)
    elif action=='Run Readiness Checks':
        result=recheck(cycle,selected)
        result['message']=_('Readiness checked for {0} employee(s): {1} blocking items.').format(len(selected),result['blocking'])
        if result['blockers']:
            result['message'] += '\n' + blocker_message(result['blockers'])
    elif action=='Start Processing':
        assert_ready(cycle,selected)
        from karyo.payroll.sequencing import validate_major_sequence
        validate_major_sequence(cycle, selected)
        if cycle.status!='Processing':
            previous=frappe.flags.payroll_processing_employees
            frappe.flags.payroll_processing_employees=selected
            try: run_step(cycle.name,'Start Processing')
            finally: frappe.flags.payroll_processing_employees=previous
        for employee in selected:
            mark(cycle,employee,processing_started_on=now_datetime())
        result={}
    elif action=='Prepare Payroll': result=prepare(cycle,selected)
    else: result=generate(cycle,selected)
    result.setdefault('message',_('{0} completed for {1} employee(s).').format(action,len(selected)))
    _log(cycle,action,'Failed' if result.get('blocking') else 'Completed',
        result['message']+' '+_('Employees: ')+', '.join(selected))
    return result
