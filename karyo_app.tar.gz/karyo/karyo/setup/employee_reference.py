"""Permissions for employee-maintained reference masters."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.model.rename_doc import rename_doc
from frappe.permissions import add_permission, update_permission_property


REFERENCE_DOCTYPES = ("Salutation", "Gender")
TITLE_VALUES = (
	("MISS.", "Miss"),
	("MR.", "Mr"),
	("MRS.", "Mrs"),
	("SIR", "Sir"),
	("DR", "Doctor"),
	("HON", "Honorable"),
)


def _rename_title(old_name, new_name):
	if old_name == new_name:
		return new_name
	# MariaDB's document-name collation is case-insensitive, so a case-only
	# change such as Dr -> DR needs a temporary name.
	if old_name.casefold() == new_name.casefold():
		temporary = f"KARYO-TITLE-{frappe.generate_hash(length=10)}"
		rename_doc("Salutation", old_name, temporary, force=True, ignore_permissions=True, show_alert=False)
		old_name = temporary
	return rename_doc("Salutation", old_name, new_name, force=True, ignore_permissions=True, show_alert=False)


def _setup_salutation_master():
	create_custom_fields(
		{
			"Salutation": [
				{
					"fieldname": "title_description",
					"fieldtype": "Data",
					"label": "Title Description",
					"insert_after": "salutation",
					"in_list_view": 1,
					"in_standard_filter": 1,
					"reqd": 1,
				}
			]
		},
		update=True,
	)
	make_property_setter("Salutation", "salutation", "label", "Title ID", "Data")
	make_property_setter("Salutation", "salutation", "in_list_view", 1, "Check")
	frappe.clear_cache(doctype="Salutation")

	# Preserve every local value, while reconciling the supplied legacy title
	# codes without creating semantic duplicates such as Mr and MR.
	for row in frappe.get_all(
		"Salutation", fields=["name", "salutation", "title_description"], limit_page_length=0
	):
		if not row.title_description:
			frappe.db.set_value(
				"Salutation", row.name, "title_description", row.salutation or row.name, update_modified=False
			)

	for title_id, description in TITLE_VALUES:
		rows = frappe.get_all(
			"Salutation", fields=["name", "salutation", "title_description"], limit_page_length=0
		)
		exact = next((row for row in rows if row.name == title_id), None)
		if exact:
			name = exact.name
		else:
			legacy = next(
				(
					row
					for row in rows
					if (row.title_description or row.salutation or row.name).strip().casefold()
					in {description.casefold(), title_id.casefold()}
				),
				None,
			)
			if legacy:
				name = _rename_title(legacy.name, title_id)
			else:
				name = frappe.get_doc(
					{"doctype": "Salutation", "salutation": title_id, "title_description": description}
				).insert(ignore_permissions=True).name
		frappe.db.set_value(
			"Salutation",
			name,
			{"salutation": title_id, "title_description": description},
			update_modified=False,
		)
	frappe.clear_cache(doctype="Salutation")


def apply():
	"""Let HR managers maintain the values offered on the Employee form."""
	_setup_salutation_master()
	if not frappe.db.exists("Role", "HR Manager"):
		return

	for doctype in REFERENCE_DOCTYPES:
		if not frappe.db.exists(
			"Custom DocPerm",
			{"parent": doctype, "role": "HR Manager", "permlevel": 0, "if_owner": 0},
		):
			add_permission(doctype, "HR Manager", 0, "read")
		for permission in ("read", "select", "create", "write", "delete", "export", "print", "report"):
			update_permission_property(doctype, "HR Manager", 0, permission, 1)
		frappe.clear_cache(doctype=doctype)


def setup():
	apply()
