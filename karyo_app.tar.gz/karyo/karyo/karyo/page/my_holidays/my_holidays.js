frappe.pages['my-holidays'].on_page_load = function(wrapper) {
 const body=karyo.pages.scaffold(wrapper,{title:__('My Holiday List'),subtitle:__('Your assigned information'),actions:[{label:__('My Leaves'),onclick:()=>frappe.set_route('List','Leave Application')}]});
 karyo.employee_resources.mount(body,'my-holidays','holidays');
};
