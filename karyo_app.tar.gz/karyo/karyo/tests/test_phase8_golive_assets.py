import csv
from pathlib import Path
import unittest


APP_ROOT = Path(__file__).resolve().parents[2]
PHASE_DIR = APP_ROOT / "docs" / "phase-8"


def read_rows(filename):
	with (PHASE_DIR / filename).open(newline="", encoding="utf-8") as handle:
		return list(csv.DictReader(handle))


class TestPhase8GoLiveAssets(unittest.TestCase):
	def test_gate_register_is_complete_and_defaults_blocked(self):
		rows = read_rows("go-live-gate-register.csv")
		self.assertEqual(11, len(rows))
		self.assertEqual(len(rows), len({row["gate_id"] for row in rows}))
		for row in rows:
			self.assertEqual("Blocked", row["status"])
			for field in ("gate", "required_evidence", "owner", "reviewer"):
				self.assertTrue(row[field].strip(), f"{row['gate_id']} missing {field}")

	def test_smoke_register_covers_every_critical_area(self):
		rows = read_rows("smoke-test-register.csv")
		areas = {row["module"] for row in rows}
		self.assertTrue(
			{"Platform", "Core HR", "Leave", "Attendance", "Payroll", "PB", "Loan", "Reports", "ESS", "Scheduler", "Integration", "Audit", "Recovery"} <= areas
		)
		self.assertTrue(all(row["status"] == "Not Run" for row in rows))

	def test_cutover_plan_has_execution_and_rollback_controls(self):
		text = (PHASE_DIR / "cutover-and-rollback-plan.md").read_text(encoding="utf-8")
		for control in ("Entry control", "Timed cut-over sequence", "Rollback triggers", "Rollback execution", "Final delta controls"):
			self.assertIn(f"## {control}", text)
		self.assertIn("direct database edit", text)

	def test_hypercare_register_retains_accountability(self):
		fields = set(read_rows("hypercare-register.csv")[0])
		self.assertTrue({"business_impact", "severity", "owner", "target_resolution", "status", "evidence_reference", "resolution_and_reconciliation"} <= fields)


if __name__ == "__main__":
	unittest.main()
