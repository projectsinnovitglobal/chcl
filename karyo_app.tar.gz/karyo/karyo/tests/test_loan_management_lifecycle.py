from unittest.mock import MagicMock, patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.desk.loan_management import _loan_lifecycle, run_lifecycle_action
from karyo.loan.self_service import _process


class TestRejectedLoanLifecycle(FrappeTestCase):
	def test_admin_lifecycle_preserves_completed_steps_and_ignores_future_steps(self):
		doc = frappe._dict({
			"name": "LOAN-TEST-REJECTED",
			"workflow_state": "Rejected",
			"status": "Draft",
			"is_approval_required": 1,
		})
		context = {
			"previous_state": "Under Loan Committee Review",
			"reason": "Eligibility condition was not met",
			"rejected_by": "approver@example.com",
			"rejected_on": "2026-09-17 12:00:00",
		}
		repayment = {
			"periods": 0, "paid_periods": 0, "progress": 0, "outstanding_capital": 0,
			"outstanding_interest": 0, "outstanding_insurance": 0, "total_paid": 0,
			"active": False, "settled": False,
		}
		with (
			patch("karyo.desk.loan_management._rejection_context", return_value=context),
			patch("karyo.desk.loan_management._actions", return_value=[]),
			patch("karyo.desk.loan_management._workflow_doc", return_value=None),
			patch("karyo.desk.loan_management._repayment_summary", return_value=repayment),
		):
			lifecycle = _loan_lifecycle(doc)

		steps = lifecycle["steps"]
		completed = [row["key"] for row in steps if row["done"] and not row.get("terminal")]
		self.assertEqual(completed, ["application", "print", "submit", "schedule", "review"])
		rejected = next(row for row in steps if row.get("terminal"))
		self.assertEqual(rejected["terminal_reason"], context["reason"])
		future = steps[steps.index(rejected) + 1:]
		self.assertTrue(future)
		self.assertTrue(all(row.get("ignored") for row in future))
		self.assertTrue(all(not row.get("blocked_reason") for row in future))

	def test_employee_process_carries_reason_and_ignores_future_stages(self):
		doc = frappe._dict({
			"workflow_state": "Rejected",
			"status": "Draft",
			"rejection_reason": "Eligibility condition was not met",
		})
		process = _process(doc)
		self.assertEqual(process["reason"], doc.rejection_reason)
		self.assertTrue(process["steps"][1]["failed"])
		self.assertTrue(all(row["ignored"] for row in process["steps"][2:]))

	@patch("karyo.desk.loan_management.application_detail", return_value={"approval_chain": {}})
	@patch("karyo.desk.loan_management.apply_workflow")
	@patch("karyo.desk.loan_management.approval_chain.record_decision")
	@patch("karyo.desk.loan_management._remarks_fields", return_value=["committee_remarks"])
	@patch("karyo.desk.loan_management._actions")
	@patch("frappe.get_doc")
	def test_lifecycle_waits_for_next_ordered_committee_member(
		self, get_doc, actions, _remarks, record_decision, apply_workflow, _detail
	):
		doc = MagicMock()
		doc.name = "LOAN-STEPWISE"
		doc.workflow_state = "Under Loan Committee Review"
		doc.check_permission.return_value = None
		get_doc.return_value = doc
		actions.return_value = [{"action": "Recommend", "next_state": "Recommended"}]
		next_step = frappe._dict(
			member_name="Senior Approver", approver_user="senior@example.com", approval_sequence=2
		)
		record_decision.return_value = {"complete": False, "next_step": next_step}

		result = run_lifecycle_action("LOAN-STEPWISE", "Recommend", {"remarks": "Recommended"})

		apply_workflow.assert_not_called()
		doc.reload.assert_called_once()
		self.assertIn("Senior Approver", result["message"])
