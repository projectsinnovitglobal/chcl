"""Curated email templates for the active MBC HRMS modules."""

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


OUT_OF_SCOPE_TEMPLATES = {
	"Dispatch Notification",
	"Exit Questionnaire Notification",
	"Interview Feedback Reminder",
	"Interview Reminder",
}

EMAIL_TEMPLATES = {
	"Leave Approval Notification": {
		"subject": "Leave application {{ name }} requires approval",
		"response": (
			"<p>{{ employee_name }} submitted a {{ leave_type }} request from "
			"{{ frappe.utils.formatdate(from_date) }} to {{ frappe.utils.formatdate(to_date) }}.</p>"
			'<p><a href="{{ frappe.utils.get_url_to_form(\'Leave Application\', name) }}">Review leave application</a></p>'
		),
	},
	"Leave Status Notification": {
		"subject": "Leave application {{ name }} is {{ status }}",
		"response": (
			"<p>Your {{ leave_type }} request from {{ frappe.utils.formatdate(from_date) }} to "
			"{{ frappe.utils.formatdate(to_date) }} is now <b>{{ status }}</b>.</p>"
			'<p><a href="{{ frappe.utils.get_url_to_form(\'Leave Application\', name) }}">Open leave application</a></p>'
		),
	},
	"MBC Payslip Available": {
		"subject": "Your payslip for {{ frappe.utils.formatdate(start_date, 'MMMM yyyy') }}",
		"response": (
			"<p>Dear {{ employee_name }},</p><p>Your payslip for "
			"{{ frappe.utils.formatdate(start_date, 'MMMM yyyy') }} is available. "
			"Sign in to MBC HRMS and open <b>My Payroll</b> to review it.</p>"
		),
	},
	"MBC Loan Approval Request": {
		"subject": "Loan {{ name }} requires approval",
		"response": (
			"<p>{{ employee_name }} submitted a {{ loan_type }} request for "
			"{{ frappe.utils.fmt_money(approved_amount or amount_applied) }}.</p>"
			'<p><a href="/app/loan-management">Review MBC loan</a></p>'
		),
	},
	"MBC Loan Decision": {
		"subject": "MBC loan {{ name }} is {{ workflow_state or status }}",
		"response": (
			"<p>Your {{ loan_type }} request is now <b>{{ workflow_state or status }}</b>.</p>"
			'<p><a href="/app/loan-management">Open MBC loan details</a></p>'
		),
	},
	"MBC Attendance Request": {
		"subject": "Attendance request {{ name }} requires review",
		"response": (
			"<p>{{ employee_name or employee }} submitted an attendance request from "
			"{{ frappe.utils.formatdate(from_date) }} to {{ frappe.utils.formatdate(to_date) }}.</p>"
			'<p><a href="{{ frappe.utils.get_url_to_form(\'Attendance Request\', name) }}">Review attendance request</a></p>'
		),
	},
	"MBC Passage Benefit Decision": {
		"subject": "Passage benefit claim {{ name }} is {{ workflow_state }}",
		"response": (
			"<p>Your passage benefit claim for {{ usage_item_name or usage_item }} is now "
			"<b>{{ workflow_state }}</b>.</p>"
			'<p><a href="{{ frappe.utils.get_url_to_form(\'Passage Benefit Application\', name) }}">Open claim</a></p>'
		),
	},
}


def _upsert(name, values):
	if frappe.db.exists("Email Template", name):
		doc = frappe.get_doc("Email Template", name)
		doc.update(values)
		doc.save(ignore_permissions=True)
		return
	frappe.get_doc({"doctype": "Email Template", "name": name, **values}).insert(
		ignore_permissions=True
	)


def setup():
	"""Remove upstream examples and install only current-module defaults."""
	for name in sorted(OUT_OF_SCOPE_TEMPLATES):
		if frappe.db.exists("Email Template", name):
			frappe.delete_doc("Email Template", name, ignore_permissions=True, force=True)
	for name, values in EMAIL_TEMPLATES.items():
		_upsert(name, values)

	# Remove the generic ERP/Jinja help blocks from the focused template editor.
	make_property_setter("Email Template", "email_reply_help", "hidden", 1, "Check")
	frappe.db.set_single_value(
		"HR Settings",
		{
			"leave_approval_notification_template": "Leave Approval Notification",
			"leave_status_notification_template": "Leave Status Notification",
		},
	)
	frappe.db.set_single_value("Payroll Settings", "email_template", "MBC Payslip Available")
	frappe.clear_cache(doctype="Email Template")
	frappe.db.commit()
