"""Connected payroll-input records for the MBC client demo.

Standalone, deterministic and idempotent. Records are deliberately left at
different workflow stages so lists, controls and approval queues tell a story.
"""

import frappe

COMPANY = "SIL"


def _employees(limit=12):
	return frappe.get_all(
		"Employee", filters={"company": COMPANY, "status": "Active"}, pluck="name", order_by="employee_name", limit=limit
	)


def _pdb(mode):
	return frappe.db.get_value(
		"Payroll PDB Code", {"is_active": 1, "transaction_mode": ("in", [mode, "Both"])}, "name"
	)


def _cycle():
	return frappe.db.get_value("Payroll Cycle", {"company": COMPANY}, "name", order_by="start_date desc")


def recurring():
	code = _pdb("Static")
	if not code:
		return
	amounts = (450, 675, 900, 1250, 1800, 2400, 3200, 4750)
	for employee, amount in zip(_employees(8), amounts):
		if frappe.db.exists("Employee Recurring PDB", {"employee": employee, "pdb_code": code, "remarks": ("like", "MBC demo:%")}):
			continue
		doc = frappe.get_doc({
			"doctype": "Employee Recurring PDB", "employee": employee, "company": COMPANY,
			"pdb_code": code, "calculation_method": "Fixed Amount", "amount": amount,
			"start_date": "2026-01-01", "status": "Draft",
			"remarks": "MBC demo: recurring employee payroll instruction",
		}).insert(ignore_permissions=True)
		doc.status = "Active"
		doc.change_reason = "Approved demo recurring instruction"
		doc.save(ignore_permissions=True)


def once_off():
	cycle, code, employees = _cycle(), _pdb("Once Off"), _employees(8)
	if not cycle or not code or len(employees) < 6:
		return
	sets = [
		("MBC Demo — Acting and Overtime Inputs", "Approved", [(employees[0], 3650), (employees[1], 2840), (employees[2], 1975)]),
		("MBC Demo — Travel and Meal Claims", "Draft", [(employees[3], 980), (employees[4], 1420), (employees[5], 760)]),
	]
	for index, (description, target, lines) in enumerate(sets, 1):
		if frappe.db.exists("Once-Off PDB Batch", {"batch_description": description}):
			continue
		doc = frappe.get_doc({
			"doctype": "Once-Off PDB Batch", "company": COMPANY, "payroll_cycle": cycle,
			"batch_description": description, "status": "Draft",
			"lines": [{"employee": emp, "pdb_code": code, "amount": amount,
				"transaction_reference": f"MBC-DEMO-ONCE-{index}-{row}", "remarks": description}
				for row, (emp, amount) in enumerate(lines, 1)],
		}).insert(ignore_permissions=True)
		if target == "Approved":
			doc.status = "Approved"
			doc.save(ignore_permissions=True)


def exceptional():
	cycle, code, employees = _cycle(), _pdb("Once Off"), _employees(12)
	if not cycle or not code or len(employees) < 10:
		return
	description = "MBC Demo — Cyclone Duty Exceptional Payroll"
	if frappe.db.exists("Exceptional Payroll Batch", {"description": description}):
		return
	doc = frappe.get_doc({
		"doctype": "Exceptional Payroll Batch", "company": COMPANY, "payroll_cycle": cycle,
		"description": description,
		"exception_reason": "Emergency attendance approved following cyclone duty roster.",
		"supporting_attachment": "/files/mbc-demo-cyclone-duty-approval.pdf", "status": "Draft",
		"lines": [
			{"employee": employee, "pdb_code": code, "amount": amount, "calculate_tax": 1,
			 "reason": "Approved emergency duty", "transaction_reference": f"MBC-DEMO-EXCP-{row}"}
			for row, (employee, amount) in enumerate(zip(employees[6:10], (5250, 4750, 6100, 3900)), 1)
		],
	}).insert(ignore_permissions=True)
	doc.status = "Reviewed"
	doc.save(ignore_permissions=True)


def seed():
	if not frappe.db.exists("Company", COMPANY):
		raise frappe.DoesNotExistError(f"Demo company {COMPANY} does not exist")
	recurring()
	once_off()
	exceptional()
	frappe.db.commit()
	print("MBC demo payroll inputs seeded.")
