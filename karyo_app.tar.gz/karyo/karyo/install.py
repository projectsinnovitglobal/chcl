"""Install + test bootstrap orchestration (XC-05).

`run_all_setup` runs every setup module in dependency order (foundation first),
so a fresh site can be provisioned in one call instead of 20. It is wired to
`after_install` (hooks.py) and to `before_tests`, so `bench run-tests --app karyo`
always finds the DocTypes, settings defaults and sample fixtures it needs.

    bench --site dev.localhost execute karyo.install.run_all_setup
"""

import frappe

# Dependency-ordered: foundation defines make_doctype/settings the rest rely on;
# workspace/reports come last once every DocType exists.
SETUP_SEQUENCE = [
	"foundation",
	"payroll_configuration",
	"payroll_tax",
	"payroll_pdb",
	"payroll_operation_code",
	"payroll_bank",
	"payroll_profiles",
	"payroll_calendar",
	"payroll_contribution",
	"payroll_compensation",
	"payroll_cycle",
	"payroll_calculation",
	"payroll_processing",
	"payroll_sequencing",
	"payroll_readiness",
	"payroll_governance",
	"role_access",
	"security_foundation",
	"employee_numbering",
	"employee_reference",
	"employee_loan",
	"employee_master",
	"salary_scales",
	"payroll_reference_permissions",
	"employee_tax_identifier",
	"migration",
	"integration_controls",
	"payroll_recurring_pdb",
	"payroll_once_off",
	"payroll_transaction_import",
	"payroll_exceptional",
	"payroll_source_trace",
	"claims",
	"payroll",
	"loan",
	"loan_reference",
	"loan_accounting",
	"loan_lifecycle",
	"loan_appraisal_recast",
	"loan_lien",
	"loan_application",
	"loan_approval_authority",
	"loan_committee",
	"loan_conditions",
	"loan_personal_policy",
	"loan_ledger",
	"loan_settlement",
	"loan_operation_code",
	"loan_documents",
	"loan_interest_change",
	"loan_insurance_change",
	"loan_correction",
	"loan_access",
	"loan_self_service",
	"pb_automation",
	"prb",
	"prb_extra",
	"prb_grade_migration",
	"prb_settings",
	"prb_run",
	"prb_posting",
	"payroll_bulk",
	"approval_routing",
	"attendance_correction",
	"leave",
	"attendance_grace",
	"eoy",
	"pms",
	"finishing",
	"ai",
	"print_formats",
	"dashboards",
	"notifications",
	"communication_templates",
	"workspace",
]


def samples_enabled():
	"""Return whether the current setup run explicitly opted into sample data."""
	return bool(getattr(frappe.flags, "karyo_with_samples", False))


def run_all_setup(with_samples=False):
	"""Run every setup module in order. Idempotent — safe to re-run."""
	import importlib

	previous_sample_flag = getattr(frappe.flags, "karyo_with_samples", False)
	frappe.flags.karyo_with_samples = bool(with_samples)
	try:
		for name in SETUP_SEQUENCE:
			mod = importlib.import_module(f"karyo.setup.{name}")
			if hasattr(mod, "setup"):
				print(f"→ karyo.setup.{name}.setup()")
				mod.setup()
	finally:
		frappe.flags.karyo_with_samples = previous_sample_flag
	# Seed config defaults + optional sample/dummy data.
	from karyo.setup import prb_settings

	prb_settings.seed_defaults()
	if with_samples:
		from karyo.setup import prb_extra

		prb_extra.seed_sample_grade_scales()
		from karyo.setup import loan_conditions

		loan_conditions.seed_sample_reference()
	frappe.db.commit()
	print("Karyo full setup complete.")


def after_install():
	"""Install production-safe schema and defaults; samples require explicit opt-in."""
	run_all_setup(with_samples=False)


def before_tests():
	"""Ensure the schema + settings defaults exist before the test suite runs."""
	# Salary points are business codes (for example 089) resolved together with
	# the review year. PRB Salary Point document names include that year
	# (2026-089), so configuring this Employee field as a Link rejects valid codes.
	from karyo.setup.foundation import apply_employee_salary_point_schema
	apply_employee_salary_point_schema()
	if not frappe.db.exists("DocType", "Karyo Loan"):
		run_all_setup(with_samples=True)
	else:
		# Schema is present; guarantee deterministic test-only reference fixtures.
		from karyo.setup import prb_settings
		from karyo.setup.payroll_tax import seed_received_2025_26_reference

		previous_sample_flag = getattr(frappe.flags, "karyo_with_samples", False)
		frappe.flags.karyo_with_samples = True
		try:
			from karyo.setup.prb import load_master_table
			from karyo.setup.prb_extra import seed_sample_grade_scales
			from karyo.setup.payroll_bank import seed_demo_data as seed_banks
			from karyo.setup.payroll_compensation import seed_demo_data as seed_compensation
			from karyo.setup.payroll_configuration import seed_demo_configurations, seed_setting_defaults
			from karyo.setup.payroll_contribution import seed_demo_data as seed_contributions
			from karyo.setup.payroll_operation_code import seed_demo_data as seed_operations
			from karyo.setup.payroll_pdb import seed_demo_data as seed_pdb

			seed_demo_configurations()
			seed_setting_defaults()
			seed_received_2025_26_reference()
			seed_pdb()
			seed_operations()
			seed_banks()
			seed_contributions()
			seed_compensation()
			load_master_table()
			seed_sample_grade_scales()
			prb_settings.seed_defaults()
		finally:
			frappe.flags.karyo_with_samples = previous_sample_flag
	frappe.db.commit()
