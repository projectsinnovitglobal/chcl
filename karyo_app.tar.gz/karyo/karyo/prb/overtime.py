"""Overtime, night-duty and weather compensation engine (pure, testable).

PRB analysis §7 (OT-*, ND-*, WEA-*): hourly-rate basis, overtime multipliers,
salary-ceiling eligibility, 25% night-duty, and extreme-weather pay.

PRB 2026 requires intermediate hourly rates to remain unrounded. Public display
helpers may round the hourly rate, but payable amounts are calculated from the
full-precision annual-salary basis and rounded only once at the end.
"""

from datetime import datetime, time, timedelta
from decimal import ROUND_HALF_UP, Decimal

WEEKLY_HOURS_40 = 40
WEEKLY_HOURS_STD = 33.75
CEILING_FULL = 60600  # below this: eligible for normal overtime (OT-08)
CEILING_80 = 77750  # 60,600-77,750: configurable 80% band; above: none (ATT-CALC-001)
MIDDLE_BAND_FACTOR = 0.8

FORTY_HOUR_GROUPS = {"workmen", "surveillant", "shift", "roster", "staggered", "forty_hour"}
MULTIPLIERS = {
	"weekday_day": 1.5,  # weekday 06:00-23:00
	"weekday_night": 2.0,  # weekday 23:00-06:00
	"sunday": 2.0,
	"public_holiday": 2.0,
	"cyclone": 2.0,
	"sunday_holiday_cyclone": 2.0,  # Sunday / public holiday / declared cyclone day
}


def _decimal(value):
	return Decimal(str(value or 0))


def _round(value, precision=2):
	return float(value.quantize(Decimal("1").scaleb(-precision), rounding=ROUND_HALF_UP))


def hourly_rate(annual_salary, weekly_hours=WEEKLY_HOURS_STD, precision=2):
	"""hourly_rate = annual_salary / (52 x weekly_hours)."""
	if _decimal(annual_salary) < 0:
		raise ValueError("annual salary cannot be negative")
	if _decimal(weekly_hours) <= 0:
		raise ValueError("weekly hours must be greater than zero")
	rate = _decimal(annual_salary) / (Decimal("52") * _decimal(weekly_hours))
	return float(rate) if precision is None else _round(rate, precision)


def hourly_rate_for_group(annual_salary, group="other", precision=2):
	"""40-hour basis for workmen/surveillant/shift/roster/staggered/40h officers;
	otherwise the 33.75-hour basis."""
	group = str(group or "other").strip().lower()
	wh = WEEKLY_HOURS_40 if group in FORTY_HOUR_GROUPS else WEEKLY_HOURS_STD
	return hourly_rate(annual_salary, wh, precision)


def overtime_multiplier(period):
	if period not in MULTIPLIERS:
		raise ValueError("invalid overtime rate period")
	return MULTIPLIERS[period]


def overtime_eligibility(
	monthly_basic,
	urgent=False,
	ceiling_full=CEILING_FULL,
	ceiling_80=CEILING_80,
	middle_band_factor=MIDDLE_BAND_FACTOR,
	middle_band_requires_urgent=False,
):
	"""Return overtime eligibility and the salary-band factor.

	ATT-CALC-001/002 pays the middle band at 80% without an additional urgency
	condition.  ``middle_band_requires_urgent`` keeps the older PRB
	16.5.62-16.5.63 interpretation available as a configurable policy.
	"""
	monthly_basic = _decimal(monthly_basic)
	ceiling_full = _decimal(ceiling_full)
	ceiling_80 = _decimal(ceiling_80)
	middle_band_factor = _decimal(middle_band_factor)
	if monthly_basic < 0:
		raise ValueError("monthly basic salary cannot be negative")
	if ceiling_full <= 0 or ceiling_80 < ceiling_full:
		raise ValueError("invalid overtime salary ceilings")
	if not Decimal("0") <= middle_band_factor <= Decimal("1"):
		raise ValueError("middle-band factor must be between zero and one")
	if monthly_basic < ceiling_full:
		return True, 1.0
	if monthly_basic <= ceiling_80:
		if middle_band_requires_urgent and not urgent:
			return False, 0.0
		return True, float(middle_band_factor)
	return False, 0.0


def overtime_amount(
	hours, hourly, period="weekday_day", monthly_basic=0, urgent=False, precision=2,
	ceiling_full=CEILING_FULL, ceiling_80=CEILING_80,
	middle_band_factor=MIDDLE_BAND_FACTOR, middle_band_requires_urgent=False,
	multiplier=None,
):
	"""Overtime pay after the ceiling gate: hours x hourly x multiplier x factor."""
	if _decimal(hours) < 0:
		raise ValueError("overtime hours cannot be negative")
	if _decimal(hourly) < 0:
		raise ValueError("hourly rate cannot be negative")
	eligible, factor = overtime_eligibility(
		monthly_basic,
		urgent,
		ceiling_full,
		ceiling_80,
		middle_band_factor,
		middle_band_requires_urgent,
	)
	if not eligible:
		return 0.0
	applied_multiplier = _decimal(overtime_multiplier(period) if multiplier is None else multiplier)
	if applied_multiplier < 0:
		raise ValueError("overtime multiplier cannot be negative")
	amount = _decimal(hours) * _decimal(hourly) * applied_multiplier * _decimal(factor)
	return _round(amount, precision)


def overtime_amount_from_salary(
	monthly_salary,
	hours,
	*,
	group="other",
	period="weekday_day",
	monthly_basic=None,
	urgent=False,
	precision=2,
	ceiling_full=CEILING_FULL,
	ceiling_80=CEILING_80,
	middle_band_factor=MIDDLE_BAND_FACTOR,
	middle_band_requires_urgent=False,
	multiplier=None,
):
	"""Compute overtime without rounding the intermediate hourly rate.

	This is the canonical PRB 2026 calculation path used by payroll runs and the
	client worked examples. ``monthly_basic`` controls the salary-ceiling gate and
	defaults to ``monthly_salary``; the hourly basis may include an approved Acting
	or Responsibility Allowance.
	"""
	hourly = hourly_rate_for_group(_decimal(monthly_salary) * Decimal("12"), group, precision=None)
	return overtime_amount(
		hours,
		hourly,
		period=period,
		monthly_basic=monthly_salary if monthly_basic is None else monthly_basic,
		urgent=urgent,
		precision=precision,
		ceiling_full=ceiling_full,
		ceiling_80=ceiling_80,
		middle_band_factor=middle_band_factor,
		middle_band_requires_urgent=middle_band_requires_urgent,
		multiplier=multiplier,
	)


def night_duty_amount(hours, hourly, precision=2, percentage=25):
	"""ND-01: 25% of the normal hourly rate for hours worked 23:00-05:00
	(including up to 2 hours lying-in period, counted in `hours`)."""
	if _decimal(hours) < 0:
		raise ValueError("night-duty hours cannot be negative")
	if _decimal(hourly) < 0:
		raise ValueError("hourly rate cannot be negative")
	if not Decimal("0") <= _decimal(percentage) <= Decimal("100"):
		raise ValueError("night-duty percentage must be between zero and 100")
	amount = _decimal(hours) * _decimal(hourly) * (_decimal(percentage) / Decimal("100"))
	return _round(amount, precision)


def night_duty_eligibility(group="other", overtime_eligible=False, hourly_paid=False):
	"""Whether the employee can receive the separate Night Duty Allowance.

	PRB 16.5.46 excludes employees operating on shift, roster or staggered hours
	and otherwise requires either overtime eligibility or hourly-paid status.
	"""
	group = str(group or "other").strip().lower()
	return group not in SHIFT_PATTERN_GROUPS and bool(overtime_eligible or hourly_paid)


def night_duty_amount_from_salary(
	monthly_salary,
	hours,
	*,
	group="other",
	overtime_eligible=False,
	hourly_paid=False,
	lying_in_hours=0,
	precision=2,
	percentage=25,
):
	"""Compute the PRB night-duty allowance from the unrounded normal hourly rate."""
	if not night_duty_eligibility(group, overtime_eligible, hourly_paid):
		return 0.0
	if _decimal(hours) < 0:
		raise ValueError("night-duty hours cannot be negative")
	if not Decimal("0") <= _decimal(lying_in_hours) <= Decimal("2"):
		raise ValueError("lying-in hours must be between 0 and 2")
	hourly = hourly_rate_for_group(_decimal(monthly_salary) * Decimal("12"), group, precision=None)
	return night_duty_amount(hours, hourly, precision, percentage)


def night_window_hours(actual_start, actual_end, precision=6):
	"""Return hours inside the PRB night window (23:00 through 05:00).

	The interval may cross midnight or cover more than one day.  Endpoints are
	actual clock times; any permitted lying-in period is added separately and is
	therefore never inferred from an oversized interval.
	"""
	start = actual_start if isinstance(actual_start, datetime) else datetime.fromisoformat(str(actual_start))
	end = actual_end if isinstance(actual_end, datetime) else datetime.fromisoformat(str(actual_end))
	if end <= start:
		raise ValueError("actual end must be after actual start")
	total_seconds = 0.0
	day = start.date() - timedelta(days=1)
	while day <= end.date():
		window_start = datetime.combine(day, time(23, 0))
		window_end = datetime.combine(day + timedelta(days=1), time(5, 0))
		overlap_start = max(start, window_start)
		overlap_end = min(end, window_end)
		if overlap_end > overlap_start:
			total_seconds += (overlap_end - overlap_start).total_seconds()
		day += timedelta(days=1)
	return round(total_seconds / 3600, precision)


def overtime_period_hours(actual_start, actual_end, period, precision=6):
	"""Return clock hours covered by one prescribed PRB rate period.

	Each authorisation is deliberately rate-homogeneous.  Public-holiday and
	declared-cyclone rows are supported by an external declaration/reference;
	their whole interval is at twice the hourly rate.  Sunday rows must fall on a
	Sunday.  Ordinary daytime rows cover 06:00-23:00 on days other than Sunday,
	while weekday-night rows cover the 23:00-06:00 window.  A night spanning into
	Sunday remains valid because both portions carry the same 2.0 multiplier.
	"""
	start = actual_start if isinstance(actual_start, datetime) else datetime.fromisoformat(str(actual_start))
	end = actual_end if isinstance(actual_end, datetime) else datetime.fromisoformat(str(actual_end))
	if end <= start:
		raise ValueError("actual end must be after actual start")
	if period not in MULTIPLIERS:
		raise ValueError("invalid overtime rate period")
	if period in {"public_holiday", "cyclone", "sunday_holiday_cyclone"}:
		return round((end - start).total_seconds() / 3600, precision)
	total_seconds = 0.0
	day = start.date() - timedelta(days=1)
	while day <= end.date():
		windows = []
		if period == "sunday" and day.weekday() == 6:
			windows = [(datetime.combine(day, time.min), datetime.combine(day + timedelta(days=1), time.min))]
		elif period == "weekday_day" and day.weekday() != 6:
			windows = [(datetime.combine(day, time(6, 0)), datetime.combine(day, time(23, 0)))]
		elif period == "weekday_night":
			windows = [(datetime.combine(day, time(23, 0)), datetime.combine(day + timedelta(days=1), time(6, 0)))]
		for window_start, window_end in windows:
			overlap_start = max(start, window_start)
			overlap_end = min(end, window_end)
			if overlap_end > overlap_start:
				total_seconds += (overlap_end - overlap_start).total_seconds()
		day += timedelta(days=1)
	return round(total_seconds / 3600, precision)


def overtime_period_covers_interval(actual_start, actual_end, period, tolerance_seconds=1):
	"""Whether all recorded time belongs to the selected prescribed rate."""
	start = actual_start if isinstance(actual_start, datetime) else datetime.fromisoformat(str(actual_start))
	end = actual_end if isinstance(actual_end, datetime) else datetime.fromisoformat(str(actual_end))
	total = (end - start).total_seconds() / 3600
	covered = overtime_period_hours(start, end, period, precision=9)
	return abs(total - covered) * 3600 <= tolerance_seconds


def mbc_night_duty_amount(
	monthly_gross,
	hours,
	precision=2,
	*,
	annual_months=12,
	hours_denominator=2080,
	rate_multiplier=2,
	night_duty_pct=25,
):
	"""ATT-CALC-005: ((gross × months) / divisor) × multiplier × % × hours."""
	if _decimal(monthly_gross) < 0:
		raise ValueError("monthly gross salary cannot be negative")
	if _decimal(hours) < 0:
		raise ValueError("night-duty hours cannot be negative")
	if _decimal(hours_denominator) <= 0:
		raise ValueError("night-duty hours denominator must be greater than zero")
	if _decimal(annual_months) <= 0 or _decimal(rate_multiplier) < 0:
		raise ValueError("invalid night-duty formula parameter")
	if not Decimal("0") <= _decimal(night_duty_pct) <= Decimal("100"):
		raise ValueError("night-duty percentage must be between zero and 100")
	amount = (
		(_decimal(monthly_gross) * _decimal(annual_months) / _decimal(hours_denominator))
		* _decimal(rate_multiplier)
		* (_decimal(night_duty_pct) / Decimal("100"))
		* _decimal(hours)
	)
	return _round(amount, precision)


def public_holiday_overtime_units(hours):
	"""MBC PH tier: <2h nil, 2-<4h .5, 4-<8h 1, and >=8h 2 units."""
	hours = float(hours or 0)
	if hours < 0:
		raise ValueError("hours cannot be negative")
	if hours < 2:
		return 0.0
	if hours < 4:
		return 0.5
	if hours < 8:
		return 1.0
	return 2.0


def weather_amount(hours, hourly, overtime_eligible=True, precision=2):
	"""Extreme weather / cyclone (WEA-01/02/03): 2x hourly if overtime-eligible,
	otherwise the normal hourly rate."""
	mult = 2.0 if overtime_eligible else 1.0
	return round(hours * hourly * mult, precision)


# --- Weekly eligibility (PRB 2026 paragraphs 16.5.49 to 16.5.54, 16.5.71) ---

WEEKLY_THRESHOLD_STANDARD = 40
WEEKLY_THRESHOLD_SURVEILLANT = 60
EXCESS_HOURS_WEEKLY_MINIMUM = 5
EXCESS_HOURS_MONTHLY_MINIMUM = 15
SHIFT_PATTERN_GROUPS = {"shift", "roster", "staggered"}
DISCIPLINED_FORCE_GROUPS = {"disciplined_force", "fire", "police", "prisons"}


def weekly_threshold(group="other"):
	"""Hours that must be exceeded in a week before overtime is payable."""
	return WEEKLY_THRESHOLD_SURVEILLANT if group == "surveillant" else WEEKLY_THRESHOLD_STANDARD


def eligible_overtime_hours(hours_worked, normal_weekly_hours=WEEKLY_HOURS_STD, group="other", weeks=1):
	"""Hours that qualify for overtime payment (16.5.49 to 16.5.51).

	Overtime is payable only once the weekly threshold is exceeded — 40 hours,
	or 60 for a Surveillant. An employee whose normal week is shorter than 40
	hours is then paid for everything above their own normal hours, so the
	hours between the normal week and 40 become payable at that point. Over a
	continuous overtime period of several weeks the same test is applied to the
	weekly average.
	"""
	weeks = int(weeks or 1)
	if weeks < 1:
		raise ValueError("weeks must be at least 1")
	worked = _decimal(hours_worked)
	normal = _decimal(normal_weekly_hours)
	if normal <= 0:
		raise ValueError("normal weekly hours must be positive")
	threshold = _decimal(weekly_threshold(group)) * weeks
	if worked <= threshold:
		return 0.0
	if group == "surveillant":
		# PRB fixes the Surveillant baseline at 60 hours a week.
		return float(worked - threshold)
	baseline = min(normal, _decimal(weekly_threshold(group))) * weeks
	return float(max(Decimal("0"), worked - baseline))


def overtime_claim_eligibility(
	*,
	claimed_hours,
	total_actual_hours,
	deemed_worked_hours=0,
	normal_weekly_hours=WEEKLY_HOURS_STD,
	group="other",
	weeks=1,
	period="weekday_day",
	outside_normal_schedule=True,
	days_worked=0,
	authorised_in_advance=True,
):
	"""Apply the non-salary PRB controls to one authorised overtime claim.

	``total_actual_hours`` is the complete work total for the covered week or
	cycle, not only the claimed overtime interval.  ``deemed_worked_hours`` is the
	approved leave/public-holiday credit from 16.5.53-16.5.54.  The result keeps
	the reason code so payroll snapshots can explain why a claim was reduced or
	rejected.
	"""
	group = (group or "other").strip().lower()
	claimed = _decimal(claimed_hours)
	actual = _decimal(total_actual_hours)
	deemed = _decimal(deemed_worked_hours)
	if claimed < 0 or actual < 0 or deemed < 0:
		raise ValueError("worked and claimed hours cannot be negative")
	if not authorised_in_advance:
		return {"eligible": False, "hours": 0.0, "reason": "NOT_AUTHORISED_IN_ADVANCE"}
	if group in DISCIPLINED_FORCE_GROUPS:
		return {"eligible": False, "hours": 0.0, "reason": "DISCIPLINED_FORCE_EXCLUDED"}
	if group == "shift" and int(days_worked or 0) > 6:
		return {"eligible": False, "hours": 0.0, "reason": "SHIFT_WEEK_EXCEEDS_SIX_DAYS"}
	if group in SHIFT_PATTERN_GROUPS and not outside_normal_schedule:
		return {"eligible": False, "hours": 0.0, "reason": "INSIDE_NORMAL_SHIFT"}
	pool = _decimal(
		eligible_overtime_hours(actual + deemed, normal_weekly_hours, group, weeks)
	)
	payable = max(Decimal("0"), min(claimed, pool))
	return {
		"eligible": payable > 0,
		"hours": float(payable),
		"reason": "ELIGIBLE" if payable > 0 else "WEEKLY_THRESHOLD_NOT_MET",
	}


def deemed_hours(normal_daily_hours, reason="worked", shift_worker=False, shift_hours=None):
	"""Hours counted as worked for the weekly test (16.5.53 and 16.5.54).

	Approved leave on a working day, and a public holiday falling on a weekday
	for a non-shift worker, both count as eight hours or the normal hours for
	that day, whichever is less. A shift worker on approved leave is credited
	with the hours of the shift they would have performed.
	"""
	if reason == "worked":
		return float(_decimal(normal_daily_hours))
	if reason not in ("approved_leave", "public_holiday"):
		raise ValueError("reason must be worked, approved_leave or public_holiday")
	if shift_worker:
		if reason == "public_holiday":
			# A public holiday inside a shift worker's normal roster is ordinary
			# shift work, not a deemed day (16.5.52).
			return 0.0
		return float(_decimal(shift_hours if shift_hours is not None else normal_daily_hours))
	return float(min(Decimal("8"), _decimal(normal_daily_hours)))


def excess_hours_payable(excess_hours, group="other", monthly_basic=0, basis="week", ceiling_80=CEILING_80):
	"""Whether hours between 33 3/4 and 40 are paid at the normal rate (16.5.71).

	Payment applies only where equivalent time off cannot be granted, and only
	from five excess hours in a week or fifteen in a month. Officers on shift,
	roster or staggered hours, and officers at or above the upper salary point,
	are excluded.
	"""
	group = str(group or "other").strip().lower()
	basis = str(basis or "week").strip().lower()
	if basis not in {"week", "month"}:
		raise ValueError("excess-hours basis must be week or month")
	if group in SHIFT_PATTERN_GROUPS:
		return False
	if _decimal(monthly_basic) >= _decimal(ceiling_80):
		return False
	minimum = EXCESS_HOURS_MONTHLY_MINIMUM if basis == "month" else EXCESS_HOURS_WEEKLY_MINIMUM
	return _decimal(excess_hours) >= _decimal(minimum)


def excess_hours_amount(
	excess_hours, hourly, group="other", monthly_basic=0, basis="week", precision=2, ceiling_80=CEILING_80
):
	"""Payment for qualifying excess hours: the normal hourly rate, no multiplier."""
	if not excess_hours_payable(excess_hours, group, monthly_basic, basis, ceiling_80):
		return 0.0
	return _round(_decimal(excess_hours) * _decimal(hourly), precision)
