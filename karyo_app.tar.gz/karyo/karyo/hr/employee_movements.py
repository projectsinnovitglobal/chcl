"""Map structured movement inputs to native, reversible employee history."""
import frappe
from frappe import _
from frappe.utils import getdate

FIELD_MAPPING = {
    'karyo_new_grade': 'grade',
    'karyo_new_department': 'department',
    'karyo_new_section': 'karyo_section',
    'karyo_new_location': 'karyo_location',
    'karyo_employment_type': 'employment_type',
    'karyo_probation_start': 'karyo_probation_start_date',
    'karyo_probation_end': 'scheduled_confirmation_date',
    'karyo_vacancy_reference': 'karyo_vacancy_reference',
    'karyo_seniority': 'karyo_level_of_seniority',
    'karyo_date_appointed': 'karyo_date_appointed',
}


def prepare(doc):
    if not doc.get('employee') or doc.docstatus == 2:
        return
    employee = frappe.get_doc('Employee', doc.employee)
    employee.check_permission('write')
    table = 'promotion_details' if doc.doctype == 'Employee Promotion' else 'transfer_details'
    rows = {row.fieldname: row for row in doc.get(table) or []}
    for field, target in FIELD_MAPPING.items():
        # Native property-table inputs remain supported by the same flow.
        if doc.get(field) in (None, '') and target in rows:
            doc.set(field, rows[target].new)
    doc.karyo_new_department = doc.get('karyo_new_department') or employee.department
    department = doc.karyo_new_department
    company = doc.get('new_company') or employee.company
    if department:
        dept = frappe.db.get_value('Department', department, ['company', 'disabled'], as_dict=True)
        if not dept or dept.disabled or (dept.company and dept.company != company):
            frappe.throw(_('Select an active Department belonging to the target Company.'))
    # A move to another department must not carry the old hierarchy forward.
    section = doc.get('karyo_new_section')
    location = doc.get('karyo_new_location')
    if not section and department == employee.department:
        section = employee.get('karyo_section')
    if not location and department == employee.department and section == employee.get('karyo_section'):
        location = employee.get('karyo_location')
    doc.karyo_new_section, doc.karyo_new_location = section, location
    from karyo.karyo.doctype.employee_location.employee_location import validate_organisation_scope, location_context
    hierarchy_changed = any(str(doc.get(field) or '') != str(employee.get(target) or '')
        for field, target in [('karyo_new_department', 'department'), ('karyo_new_section', 'karyo_section'), ('karyo_new_location', 'karyo_location')])
    if hierarchy_changed:
        validate_organisation_scope(doc, 'karyo_new_department', 'karyo_new_section', 'karyo_new_location')
    if section and hierarchy_changed:
        section_company = frappe.db.get_value('Employee Section', section, 'company')
        if section_company and section_company != company:
            frappe.throw(_('The selected Section does not belong to the target Company.'))
    doc.karyo_site = location_context(location).get('address_site') if location else None
    start = doc.get('promotion_date') or doc.get('transfer_date')
    if doc.get('karyo_end_date') and start and getdate(doc.karyo_end_date) < getdate(start):
        frappe.throw(_('End Date cannot precede Start Date.'))
    if doc.get('karyo_probation_start') and doc.get('karyo_probation_end') and getdate(doc.karyo_probation_end) < getdate(doc.karyo_probation_start):
        frappe.throw(_('Probation End Date cannot precede Probation Start Date.'))
    for field, target in FIELD_MAPPING.items():
        value = doc.get(field)
        # Section and Location can be cleared during a department move.
        if value in (None, '') and target not in ('karyo_section', 'karyo_location'):
            continue
        current = employee.get(target)
        if str(value or '') == str(current or ''):
            if target in rows:
                doc.remove(rows[target])
            continue
        row = rows.get(target) or doc.append(table, {})
        row.update({'property': employee.meta.get_field(target).label, 'fieldname': target,
                    'current': current, 'new': value})
