"""Approved salary scales and effective-dated employee basic salary allocations.

Reference: Salary scale_SalaryPointCalculation_Grade linkage_EmployeeBasicSalary,
version 1.0, 20 July 2026. Scale-local point numbers are not PRB conversion IDs.
"""
import csv
import io
import re
from decimal import Decimal, InvalidOperation

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import cint, flt, get_first_day, getdate, now_datetime, nowdate

END = '9999-12-31'
ADMIN_ROLES = {'System Manager', 'HR Manager', 'HR User', 'Payroll Manager', 'Payroll User'}

SECONDARY_ACCOUNT_PROFILE_FIELDS = {
    'secondary_bank': 'karyo_secondary_payroll_bank',
    'secondary_bank_branch': 'karyo_secondary_payroll_bank_branch',
    'secondary_bank_account': 'karyo_secondary_bank_account_no',
    'secondary_bank_account_holder': 'karyo_secondary_bank_account_holder',
    'secondary_bank_fixed_amount': 'karyo_secondary_bank_fixed_amount',
    'secondary_bank_effective_from': 'karyo_secondary_bank_effective_from',
    'secondary_bank_effective_to': 'karyo_secondary_bank_effective_to',
}

PAYROLL_PROFILE_FIELDS = {
    'payroll_group': 'karyo_payroll_group',
    'payroll_type': 'karyo_payroll_type',
    'pay_day': 'karyo_pay_day',
    'work_pattern': 'karyo_work_pattern',
    'salary_currency': 'salary_currency',
    'payment_mode': 'salary_mode',
    'bank': 'karyo_payroll_bank',
    'bank_branch': 'karyo_payroll_bank_branch',
    'bank_account': 'bank_ac_no',
    'bank_account_holder_name': 'karyo_bank_account_holder_name',
    'bank_account_is_primary': 'karyo_bank_account_is_primary',
    'bank_account_effective_from': 'karyo_bank_account_effective_from',
    'bank_account_effective_to': 'karyo_bank_account_effective_to',
    **SECONDARY_ACCOUNT_PROFILE_FIELDS,
    'cheque_number': 'karyo_cheque_number',
    'cheque_date': 'karyo_cheque_date',
    'cheque_bank': 'karyo_cheque_bank',
    'cheque_reference': 'karyo_cheque_reference',
    'cash_receipt_number': 'karyo_cash_receipt_number',
    'cash_reference': 'karyo_cash_reference',
    'cash_collection_point': 'karyo_cash_collection_point',
    'prb_opted_in': 'karyo_prb_opted_in',
    'prb_grade': 'karyo_prb_grade',
    'prb_salary_point': 'karyo_prb_salary_point',
}

PAYROLL_SETUP_CSV_COLUMNS = [
    'employee_id', 'payroll_group', 'payroll_type', 'pay_day', 'work_pattern',
    'salary_currency', 'payment_mode', 'bank', 'bank_branch', 'bank_account',
    'bank_account_holder_name', 'bank_account_is_primary',
    'bank_account_effective_from', 'bank_account_effective_to',
    *SECONDARY_ACCOUNT_PROFILE_FIELDS,
    'prb_opted_in', 'prb_grade', 'prb_salary_point', 'grade', 'salary_point',
    'cheque_number', 'cheque_date', 'cheque_bank', 'cheque_reference',
    'cash_receipt_number', 'cash_reference', 'cash_collection_point',
    'effective_from', 'effective_to', 'salary_structure', 'income_tax_slab',
    'appointment_type', 'authority_reference',
]


def money(value):
    try:
        number = Decimal(str(value))
        if not number.is_finite() or number != number.quantize(Decimal('.01')):
            raise ValueError
        return number
    except (InvalidOperation, ValueError, TypeError):
        frappe.throw(_('Enter finite salary amounts and point values with at most two decimal places.'))


def generate_points(lowest_salary, upper_salary, bands):
    """Generate exact cents without rounding a gap or overshooting a breakpoint."""
    low, high = money(lowest_salary), money(upper_salary)
    if low < 0 or high < low:
        frappe.throw(_('Lowest Salary must be non-negative and cannot exceed Upper Salary.'))
    if not bands:
        frappe.throw(_('Enter at least one salary and increment band.'))
    values = [(money(row.get('salary')), money(row.get('increment', 0))) for row in bands]
    if values[0][0] != low or values[-1][0] != high:
        frappe.throw(_('The first band must equal Lowest Salary and the final band must equal Upper Salary.'))
    if values[-1][1] != 0:
        frappe.throw(_('The Upper Salary band must have Point Value 0.'))
    points = [low]
    for index, (salary, increment) in enumerate(values[:-1]):
        stop = values[index + 1][0]
        if stop <= salary:
            frappe.throw(_('Salary breakpoints must be unique and in ascending order.'))
        if increment <= 0:
            frappe.throw(_('Every band below Upper Salary must have a positive Point Value.'))
        count = (stop - salary) / increment
        if count != count.to_integral_value():
            frappe.throw(_('Increment {0} cannot reach breakpoint {1} exactly; correct the gap.').format(increment, stop))
        if len(points) + int(count) > 10000:
            frappe.throw(_('A salary scale cannot contain more than 10,000 points.'))
        points.extend(salary + increment * step for step in range(1, int(count) + 1))
    return [{'salary_point': index, 'salary': float(value)} for index, value in enumerate(points, 1)]


def is_flat_scale(scale):
    """Keep legacy scale types step-based while supporting the new flat model."""
    return str(scale.get('scale_type') or '').strip().lower() == 'flat salary'


def normalized_scale_type(scale):
    return 'Flat Salary' if is_flat_scale(scale) else 'Step Salary'


def period(start, end):
    if not start:
        frappe.throw(_('Effective From is required.'))
    start, end = getdate(start), getdate(end or END)
    if end < start:
        frappe.throw(_('Effective To cannot precede Effective From.'))
    return start, end


def contains(outer_start, outer_end, start, end):
    a, b = period(outer_start, outer_end)
    c, d = period(start, end)
    return a <= c and d <= b


def require_admin():
    if not ADMIN_ROLES.intersection(frappe.get_roles()):
        frappe.throw(_('Only HR administrators can maintain salary allocations.'), frappe.PermissionError)


class SalaryIncrementBand(Document):
    """Reusable breakpoint/increment master selected inside a salary scale."""

    def validate(self):
        self.band_code = (self.band_code or '').strip().upper()
        if not self.band_code:
            frappe.throw(_('Increment Band Code is required.'))
        if money(self.salary_breakpoint) < 0:
            frappe.throw(_('From Salary cannot be negative.'))
        if money(self.increment_amount) < 0:
            frappe.throw(_('Point Value cannot be negative. Use 0 only for a final upper-salary band.'))
        period(self.effective_from, self.effective_to)

        if self.is_new():
            return
        protected_fields = ('salary_breakpoint', 'increment_amount', 'currency', 'effective_from', 'effective_to')
        if not any(self.has_value_changed(fieldname) for fieldname in protected_fields):
            return
        approved_scale = frappe.db.sql('''select parent from `tabSalary Scale Band`
            where increment_band=%s and parenttype='Salary Scale' and parent in
            (select name from `tabSalary Scale` where docstatus=1) limit 1''', (self.name,))
        if approved_scale:
            frappe.throw(_('Increment Band {0} is used by approved Salary Scale {1}. Create a new band so salary history remains unchanged.').format(
                self.name, approved_scale[0][0]
            ))

    def on_trash(self):
        linked_scale = frappe.db.get_value('Salary Scale Band', {'increment_band': self.name}, 'parent')
        if linked_scale:
            frappe.throw(_('Increment Band {0} is used by Salary Scale {1}. Remove or replace that row first.').format(
                self.name, linked_scale
            ))


def _workspace_bands(lowest_salary, upper_salary, bands):
    rows = bands if isinstance(bands, list) else frappe.parse_json(bands or '[]')
    normalized = []
    for row in rows:
        increment_band = row.get('increment_band')
        salary = row.get('salary')
        increment = row.get('increment')
        if increment_band:
            band = frappe.get_cached_doc('Salary Increment Band', increment_band)
            salary = band.salary_breakpoint
            increment = band.increment_amount
        if salary in (None, ''):
            continue
        normalized.append({
            'increment_band': increment_band,
            'salary': salary,
            'increment': increment or 0,
        })
    rows = normalized
    if not rows:
        return rows
    upper = money(upper_salary)
    last_salary = money(rows[-1].get('salary'))
    last_increment = money(rows[-1].get('increment') or 0)
    if last_salary != upper or last_increment != Decimal('0.00'):
        rows.append({'salary': float(upper), 'increment': 0})
    return rows


def workspace_band_rows(doc):
    rows = [{
        'increment_band': row.increment_band,
        'band_description': row.band_description,
        'salary': row.salary,
        'increment': row.increment or 0,
    } for row in (doc.get('bands') or [])]
    if rows and money(rows[-1]['salary']) == money(doc.upper_salary) and money(rows[-1]['increment'] or 0) == Decimal('0.00'):
        rows = rows[:-1]
    return rows


def serialize_increment_band(doc):
    return {
        'name': doc.name,
        'band_code': doc.band_code,
        'description': doc.description,
        'salary_breakpoint': doc.salary_breakpoint,
        'increment_amount': doc.increment_amount,
        'currency': doc.currency,
        'effective_from': doc.effective_from,
        'effective_to': doc.effective_to,
        'disabled': doc.disabled,
    }


def workspace_increment_bands(currency=None):
    filters = {'disabled': 0}
    if currency:
        filters['currency'] = currency
    return frappe.get_all(
        'Salary Increment Band',
        filters=filters,
        fields=['name', 'band_code', 'description', 'salary_breakpoint', 'increment_amount', 'currency', 'effective_from', 'effective_to', 'disabled'],
        order_by='salary_breakpoint asc, band_code asc',
        limit_page_length=200,
    )


def workspace_scale_doc(name):
    doc = frappe.get_doc('Salary Scale', name)
    doc.check_permission('read')
    return {
        'name': doc.name, 'scale_code': doc.scale_code, 'description': doc.description,
        'scale_type': normalized_scale_type(doc), 'prb_year': doc.prb_year, 'currency': doc.currency,
        'basic_salary': doc.basic_salary, 'lowest_salary': doc.lowest_salary, 'upper_salary': doc.upper_salary,
        'valid_from': doc.valid_from, 'valid_to': doc.valid_to, 'source_reference': doc.source_reference,
        'docstatus': doc.docstatus, 'point_count': doc.point_count,
        'bands': workspace_band_rows(doc),
        'points': [{'salary_point': row.salary_point, 'salary': row.salary} for row in (doc.get('points') or [])],
    }


@frappe.whitelist()
def calculate_points(lowest_salary, upper_salary, bands, scale_type=None, basic_salary=None):
    require_admin()
    if not frappe.has_permission('Salary Scale', 'create'):
        frappe.throw(_('Not permitted to calculate salary scales.'), frappe.PermissionError)
    if scale_type == 'Flat Salary':
        amount = money(basic_salary or lowest_salary or upper_salary)
        if amount <= 0:
            frappe.throw(_('Basic Salary must be greater than zero for a Flat Salary scale.'))
        return []
    return generate_points(lowest_salary, upper_salary, _workspace_bands(lowest_salary, upper_salary, bands))


@frappe.whitelist()
def save_workspace_scale(values, submit=0):
    require_admin()
    values = frappe.parse_json(values or '{}')
    name = values.get('name')
    if name:
        doc = frappe.get_doc('Salary Scale', name)
        doc.check_permission('write')
        if doc.docstatus:
            frappe.throw(_('Submitted salary scales cannot be edited. Create a new scale for revised rates.'))
    else:
        if not frappe.has_permission('Salary Scale', 'create'):
            frappe.throw(_('Not permitted to create salary scales.'), frappe.PermissionError)
        doc = frappe.new_doc('Salary Scale')
    for fieldname in ('scale_code', 'description', 'scale_type', 'prb_year', 'currency',
            'basic_salary', 'lowest_salary', 'upper_salary', 'valid_from', 'valid_to', 'source_reference'):
        doc.set(fieldname, values.get(fieldname))
    doc.currency = doc.currency or frappe.db.get_default('currency') or 'MUR'
    doc.valid_from = doc.valid_from or nowdate()
    doc.source_reference = doc.source_reference or _('Salary Scale Setup')
    if normalized_scale_type(doc) == 'Flat Salary':
        doc.basic_salary = doc.basic_salary or doc.lowest_salary or doc.upper_salary
        doc.set('bands', [])
    else:
        doc.set('bands', _workspace_bands(doc.lowest_salary, doc.upper_salary, values.get('bands')))
    doc.save()
    if cint(submit):
        doc.submit()
    return {'name': doc.name, 'doc': workspace_scale_doc(doc.name),
        'message': _('{0} submitted.').format(doc.scale_code) if cint(submit) else _('{0} saved.').format(doc.scale_code)}


@frappe.whitelist()
def create_workspace_increment_band(values):
    require_admin()
    if not frappe.has_permission('Salary Increment Band', 'create'):
        frappe.throw(_('Not permitted to create Salary Increment Band.'), frappe.PermissionError)
    values = frappe.parse_json(values or '{}')
    doc = frappe.new_doc('Salary Increment Band')
    for fieldname in ('band_code', 'description', 'salary_breakpoint', 'increment_amount', 'currency',
            'effective_from', 'effective_to'):
        doc.set(fieldname, values.get(fieldname))
    doc.currency = doc.currency or frappe.db.get_default('currency') or 'MUR'
    doc.effective_from = doc.effective_from or nowdate()
    doc.insert()
    return {
        'band': serialize_increment_band(doc),
        'message': _('Increment Band {0} created.').format(doc.band_code),
    }


class SalaryJobFamily(Document):
    pass


class SalaryScale(Document):
    def before_validate(self):
        self.scale_type = normalized_scale_type(self)

    def validate(self):
        self.scale_type = normalized_scale_type(self)
        period(self.valid_from, self.valid_to)
        if not 1900 <= cint(self.prb_year) <= 9999:
            frappe.throw(_('Enter a valid PRB Year.'))
        if is_flat_scale(self):
            amount = money(self.get('basic_salary'))
            if amount <= 0:
                frappe.throw(_('Basic Salary must be greater than zero for a Flat Salary scale.'))
            self.lowest_salary = self.upper_salary = float(amount)
            self.set('bands', [])
            self.set('points', [])
        else:
            self.basic_salary = None
            self.apply_increment_band_masters()
            self.set('points', generate_points(self.lowest_salary, self.upper_salary, self.bands))
        self.point_count = len(self.points)
        if self.docstatus == 0:
            self.approved_by = self.approved_on = None

    def apply_increment_band_masters(self):
        for row_number, row in enumerate(self.bands or [], 1):
            if not row.increment_band:
                continue
            band = frappe.get_cached_doc('Salary Increment Band', row.increment_band)
            if band.disabled:
                frappe.throw(_('Step 2 — Increment band {0} is disabled. Select an active band on row {1}.').format(
                    band.name, row_number
                ))
            if band.currency != self.currency:
                frappe.throw(_('Step 2 — Increment band {0} uses {1}, but this salary scale uses {2}.').format(
                    band.name, band.currency, self.currency
                ))
            if not contains(band.effective_from, band.effective_to, self.valid_from, self.valid_to):
                frappe.throw(_('Step 2 — Increment band {0} is not valid for the full salary-scale period.').format(band.name))
            row.band_description = band.description
            row.salary = band.salary_breakpoint
            row.increment = band.increment_amount

    def before_submit(self):
        self.approved_by, self.approved_on = frappe.session.user, now_datetime()

    def on_update(self):
        sync_scale_steps(self)

    def on_update_after_submit(self):
        sync_scale_steps(self)

    def before_cancel(self):
        if frappe.db.exists('Salary Grade Scale Link', {'salary_scale': self.name}):
            frappe.throw(_('This approved scale is linked to a grade. Preserve it for salary history and create a new scale for revised rates.'))
        if frappe.db.exists('Employee Salary Appointment', {'salary_scale': self.name, 'docstatus': 1}):
            frappe.throw(_('This scale has approved employee appointments and cannot be cancelled.'))

    def on_trash(self):
        for name in frappe.get_all('Salary Scale Step', filters={'salary_scale': self.name}, pluck='name'):
            if frappe.db.exists('Employee Recurring PDB', {'salary_step': name}):
                frappe.throw(_('Salary scale step {0} is used by a recurring payment or deduction.').format(name))
            frappe.delete_doc('Salary Scale Step', name, ignore_permissions=True)


def sync_scale_steps(scale):
    """Expose generated scale points through the dependent Salary Scale Step master."""
    expected = set()
    points = list(scale.points or [])
    for index, point in enumerate(points):
        sequence = cint(point.salary_point)
        name = f'{scale.name}-{sequence}'
        expected.add(name)
        salary = flt(point.salary, 2)
        next_salary = flt(points[index + 1].salary, 2) if index + 1 < len(points) else salary
        values = {
            'salary_scale': scale.name,
            'step_sequence': sequence,
            'salary_point': salary,
            # An increment belongs to the employee's current point and moves
            # them to the next point.  The top point is the only zero-increment
            # row.  This matches the increment posting engine in bulk.py.
            'increment_amount': flt(next_salary - salary, 2),
            'effective_from': scale.valid_from,
            'effective_to': scale.valid_to,
        }
        if frappe.db.exists('Salary Scale Step', name):
            frappe.db.set_value('Salary Scale Step', name, values, update_modified=False)
        else:
            frappe.get_doc({'doctype': 'Salary Scale Step', 'name': name, **values}).insert(
                ignore_permissions=True, set_name=name
            )

    stale = set(frappe.get_all('Salary Scale Step', filters={'salary_scale': scale.name}, pluck='name')) - expected
    for name in stale:
        if frappe.db.exists('Employee Recurring PDB', {'salary_step': name}):
            frappe.throw(_('Salary scale step {0} is used by a recurring payment or deduction. Preserve the step or amend the linked record first.').format(name))
        frappe.delete_doc('Salary Scale Step', name, ignore_permissions=True)


def validate_grade(doc, method=None):
    doc.karyo_grade_code = doc.name
    links = doc.get('karyo_salary_scales') or []
    if not (doc.get('karyo_grade_description') or '').strip():
        frappe.throw(_('Grade Description is required.'))
    if not links:
        frappe.throw(_('Select at least one approved Salary Scale Code for this grade.'))
    category = doc.get('karyo_employee_category')
    if category and cint(frappe.db.get_value('Employee Category', category, 'disabled')):
        frappe.throw(_('Select an active Employee Category / Grade Group.'))
    periods = []
    for row in links:
        scale = frappe.get_doc('Salary Scale', row.salary_scale)
        if scale.docstatus != 1:
            frappe.throw(_('Select an approved salary scale for each grade period.'))
        start, end = period(row.effective_from, row.effective_to)
        if not contains(scale.valid_from, scale.valid_to, start, end):
            frappe.throw(_('The grade-link period must fall within salary scale {0} validity.').format(scale.name))
        if any(start <= last_end and last_start <= end for last_start, last_end in periods):
            frappe.throw(_('A grade can have only one salary scale for any effective date; periods cannot overlap.'))
        periods.append((start, end))
        row.scale_description = scale.description
    # Never rewrite an approved allocation's historical grade-to-scale mapping.
    if not doc.is_new():
        for appointment in frappe.get_all('Employee Salary Appointment', filters={'grade': doc.name, 'docstatus': 1},
                fields=['name', 'salary_scale', 'effective_from', 'effective_to']):
            if not any(row.salary_scale == appointment.salary_scale and contains(row.effective_from, row.effective_to,
                    appointment.effective_from, appointment.effective_to) for row in links):
                frappe.throw(_('Grade linkage is used by approved appointment {0}; preserve its effective period.').format(appointment.name))


def grade_scale(grade, date):
    grade_doc = frappe.get_doc('Employee Grade', grade)
    if not cint(grade_doc.get('karyo_is_active')):
        frappe.throw(_('Grade {0} is inactive. Select an active Grade Code.').format(grade))
    day = getdate(date)
    links = [row for row in (grade_doc.get('karyo_salary_scales') or [])
             if getdate(row.effective_from) <= day <= getdate(row.effective_to or END)]
    if len(links) != 1:
        frappe.throw(_('Grade {0} must have exactly one approved salary scale on {1}.').format(grade, date))
    link = links[0]
    scale = frappe.get_doc('Salary Scale', link.salary_scale)
    if scale.docstatus != 1 or not getdate(scale.valid_from) <= day <= getdate(scale.valid_to or END):
        frappe.throw(_('The linked salary scale is not approved or is outside its effective period.'))
    return link, scale


@frappe.whitelist()
def allocation_options(grade, effective_from, company=None):
    require_admin()
    grade_doc = frappe.get_doc('Employee Grade', grade)
    grade_doc.check_permission('read')
    link, scale = grade_scale(grade, effective_from)
    scale.check_permission('read')
    points = []
    scale_points = list(scale.points or [])
    for index, row in enumerate(scale_points):
        salary = flt(row.salary, 2)
        next_salary = flt(scale_points[index + 1].salary, 2) if index + 1 < len(scale_points) else salary
        points.append({
            'salary_point': row.salary_point,
            'salary': salary,
            'increment_amount': flt(next_salary - salary, 2),
        })
    default_structure = grade_doc.get('default_salary_structure')
    if default_structure and company:
        valid_structure = frappe.db.exists('Salary Structure', {
            'name': default_structure, 'company': company, 'docstatus': 1,
            'is_active': 'Yes', 'payroll_frequency': 'Monthly',
        })
        if not valid_structure:
            default_structure = None
    return {'salary_scale': scale.name, 'description': scale.description, 'currency': scale.currency,
            'prb_year': scale.prb_year, 'effective_to': link.effective_to,
            'scale_type': scale.scale_type, 'flat_salary': is_flat_scale(scale),
            'basic_salary': flt(scale.get('basic_salary') or scale.lowest_salary, 2) if is_flat_scale(scale) else None,
            'grade_description': grade_doc.get('karyo_grade_description'),
            'job_family': grade_doc.get('karyo_job_family'),
            'employee_category': grade_doc.get('karyo_employee_category'),
            'default_salary_structure': default_structure, 'points': points}


def prb_allocation(grade, salary_point, company=None, effective_date=None, review_year=None):
    """Resolve an official PRB grade/point and its effective phased amount."""
    if not grade or not frappe.db.exists('PRB Grade Scale', grade):
        frappe.throw(_('Select a PRB Grade from the PRB Grade Scale master.'))
    point = str(salary_point or '').strip()
    if not point:
        frappe.throw(_('Select a PRB Salary Point.'))
    from karyo.setup.payroll_profiles import _point_in_grade, prb_salary_value
    if not _point_in_grade(point, grade):
        frappe.throw(_('PRB Salary Point {0} is outside PRB Grade {1}.').format(point, grade))
    year = review_year or frappe.db.get_value('PRB Salary Point', {}, 'max(review_year)')
    amount = prb_salary_value(point, year, effective_date)
    full_amount = prb_salary_value(point, year)
    if amount is None:
        frappe.throw(_('PRB Salary Point {0} has no Row 3 salary for review year {1}.').format(
            point, year or _('current')
        ))
    scale = frappe.db.get_value(
        'PRB Grade Scale', grade,
        ['grade_id', 'organisation', 'sector', 'volume_part', 'effective_from'], as_dict=True,
    )
    currency = frappe.db.get_value('Company', company, 'default_currency') if company else None
    return {
        'grade': grade,
        'grade_description': ' · '.join(filter(None, [scale.grade_id, scale.organisation, scale.volume_part])),
        'salary_point': point,
        'basic_salary': flt(amount, 2),
        'full_salary': flt(full_amount, 2),
        'phase_percentage': 100 if cint(year) != 2026 else 50 if effective_date and getdate(effective_date) < getdate('2027-01-01') and getdate(effective_date) >= getdate('2026-01-01') else 100 if effective_date and getdate(effective_date) >= getdate('2027-01-01') else 0,
        'currency': currency or 'MUR',
        'prb_year': year,
    }


def _assignment_at(employee, effective_from):
    """Return the submitted native assignment in force on a given date."""
    return frappe.db.get_value(
        'Salary Structure Assignment',
        {'employee': employee, 'docstatus': 1, 'from_date': ['<=', getdate(effective_from)]},
        ['name', 'salary_structure', 'from_date', 'base', 'income_tax_slab'],
        order_by='from_date desc, creation desc', as_dict=True,
    )


def _appointment_mapping(appointment):
    if not appointment:
        return {}
    return {
        'karyo_salary_appointment': appointment.name,
        'karyo_salary_scale': appointment.salary_scale,
        'karyo_salary_point': cint(appointment.salary_point),
    }


def _set_supported(doc, values):
    """Set cross-links after their idempotent custom fields are installed."""
    for fieldname, value in values.items():
        if doc.meta.has_field(fieldname):
            doc.set(fieldname, value)


def salary_structure_pdb_status(salary_structure):
    """Return the PDB integrity of the native template used by payroll."""
    rows = frappe.get_all(
        'Salary Detail',
        filters={'parent': salary_structure, 'parenttype': 'Salary Structure'},
        fields=['parentfield', 'salary_component'], order_by='parentfield asc, idx asc',
    )
    components = list(dict.fromkeys(row.salary_component for row in rows if row.salary_component))
    mappings = frappe.get_all(
        'Payroll PDB Code',
        filters={'salary_component': ('in', components), 'is_active': 1},
        fields=['pdb_code', 'pdb_type', 'salary_component'],
    ) if components else []
    by_component = {}
    for mapping in mappings:
        by_component.setdefault(mapping.salary_component, []).append(mapping)
    missing, duplicate, invalid_type, resolved = [], [], [], []
    for row in rows:
        component_mappings = by_component.get(row.salary_component, [])
        if not component_mappings:
            missing.append(row.salary_component)
            continue
        if len(component_mappings) > 1:
            duplicate.append(row.salary_component)
            continue
        mapping = component_mappings[0]
        classification = frappe.db.get_value('Payroll PDB Type', mapping.pdb_type, 'classification')
        classification_matches = (
            classification == 'Deduction' if row.parentfield == 'deductions'
            else classification != 'Deduction'
        )
        if not classification_matches:
            invalid_type.append(mapping.pdb_code)
            continue
        resolved.append({'pdb_type': mapping.pdb_type, 'pdb_code': mapping.pdb_code,
                         'salary_component': row.salary_component, 'section': row.parentfield})
    return {
        'valid': not (missing or duplicate or invalid_type), 'rows': resolved,
        'missing': list(dict.fromkeys(missing)),
        'duplicate': list(dict.fromkeys(duplicate)),
        'invalid_type': list(dict.fromkeys(invalid_type)),
    }


def validate_salary_structure_pdb_mapping(salary_structure):
    """Block governed employee setup when a payroll template is not PDB-safe."""
    status = salary_structure_pdb_status(salary_structure)
    issues = []
    if status['missing']:
        issues.append(_('missing PDB Codes for {0}').format(', '.join(status['missing'])))
    if status['duplicate']:
        issues.append(_('duplicate active PDB Codes for {0}').format(', '.join(status['duplicate'])))
    if status['invalid_type']:
        issues.append(_('PDB Type does not match earning/deduction section for {0}').format(
            ', '.join(status['invalid_type'])
        ))
    if issues:
        frappe.throw(_(
            'PDB Payroll Template {0} cannot be assigned: {1}. Correct the PDB Type/Code mapping first.'
        ).format(salary_structure, '; '.join(issues)))
    return status


def _assign_structure(employee, salary_structure, effective_from, amount, income_tax_slab=None,
                      appointment=None):
    """Create the effective native assignment used by every payroll formula."""
    emp = frappe.get_doc('Employee', employee)
    structure = frappe.get_doc('Salary Structure', salary_structure)
    structure.check_permission('read')
    if (structure.docstatus != 1 or structure.is_active != 'Yes'
            or structure.payroll_frequency != 'Monthly' or structure.company != emp.company):
        frappe.throw(_('Select an active, submitted monthly Salary Structure for company {0}.').format(emp.company))
    validate_salary_structure_pdb_mapping(structure.name)

    effective = getdate(effective_from)
    current_row = _assignment_at(employee, effective)
    current = frappe.get_doc('Salary Structure Assignment', current_row.name) if current_row else None
    if (current and getdate(current.from_date) == effective
            and current.salary_structure == salary_structure
            and abs(flt(current.base) - flt(amount)) < .005
            and (not income_tax_slab or current.income_tax_slab == income_tax_slab)):
        mapping = {
            key: value for key, value in _appointment_mapping(appointment).items()
            if current.meta.has_field(key)
        }
        if mapping:
            frappe.db.set_value('Salary Structure Assignment', current.name, mapping, update_modified=False)
        return current.name

    assignment = frappe.copy_doc(current) if current else frappe.new_doc('Salary Structure Assignment')
    assignment.update({
        'employee': employee,
        'company': emp.company,
        'salary_structure': salary_structure,
        'from_date': effective,
        'base': flt(amount),
        'docstatus': 0,
        'amended_from': None,
    })
    if income_tax_slab:
        assignment.income_tax_slab = income_tax_slab
    _set_supported(assignment, _appointment_mapping(appointment))
    if current and getdate(current.from_date) == effective:
        current.flags.ignore_permissions = True
        current.cancel()
        assignment.amended_from = current.name
    assignment.flags.ignore_permissions = True
    assignment.insert(ignore_permissions=True)
    assignment.submit()
    return assignment.name


def _refresh_draft_salary_slips(employee, start, end=END):
    """Rebuild draft slips after an effective-dated salary mapping changes.

    Submitted slips are historical payroll records and are blocked by callers.
    Draft slips are working documents, so reload their applicable structure and
    calculations instead of leaving stale salary rows in Payroll.
    """
    rows = frappe.get_all(
        'Salary Slip',
        filters={
            'employee': employee,
            'docstatus': 0,
            'end_date': ['>=', getdate(start)],
            'start_date': ['<=', getdate(end)],
        },
        fields=['name'],
        order_by='start_date asc, creation asc',
    )
    refreshed = []
    for row in rows:
        slip = frappe.get_doc('Salary Slip', row.name)
        slip.flags.ignore_permissions = True
        slip.get_emp_and_working_day_details()
        slip.save(ignore_permissions=True)
        refreshed.append(slip.name)
    return refreshed


@frappe.whitelist(methods=['POST'])
def bulk_salary_setup(employees, grade, salary_point, effective_from, authority_reference,
                      salary_structure=None, income_tax_slab=None, effective_to=None,
                      appointment_type='Appointment', pay_basis='Grade Scale',
                      prb_grade=None, prb_salary_point=None):
    """Apply one governed grade/point/structure selection to one or many employees."""
    require_admin()
    if not frappe.has_permission('Employee Salary Appointment', 'create'):
        frappe.throw(_('Not permitted to create Salary Appointments.'), frappe.PermissionError)
    selected = list(dict.fromkeys(frappe.parse_json(employees) if isinstance(employees, str) else (employees or [])))
    if not selected:
        frappe.throw(_('Select at least one employee.'))
    if len(selected) > 200:
        frappe.throw(_('A maximum of 200 employees can be processed at once.'))
    if not str(authority_reference or '').strip():
        frappe.throw(_('Approval Authority / Reference is required.'))

    pay_basis = 'PRB' if pay_basis == 'PRB' else 'Grade Scale'
    if pay_basis == 'PRB':
        point = prb_allocation(prb_grade, prb_salary_point, frappe.db.get_value(
            'Employee', selected[0], 'company'
        ))
        point_number = None
    else:
        options = allocation_options(grade, effective_from)
        if options.get('flat_salary'):
            point_number = None
            point = {'salary': options['basic_salary']}
        else:
            try:
                selected_point = Decimal(str(salary_point))
            except (InvalidOperation, TypeError, ValueError):
                selected_point = Decimal('-1')
            if not selected_point.is_finite() or selected_point != selected_point.to_integral_value():
                frappe.throw(_('Select a Salary Point belonging to the selected Grade.'))
            point_number = int(selected_point)
            point = next((row for row in options['points'] if cint(row['salary_point']) == point_number), None)
            if not point:
                frappe.throw(_('Select a Salary Point belonging to the selected Grade.'))

    created, failed = [], []
    for index, employee in enumerate(selected):
        savepoint = 'bulk_salary_setup_{0}'.format(index)
        frappe.db.savepoint(savepoint)
        try:
            emp = frappe.get_doc('Employee', employee)
            emp.check_permission('write')
            values = {
                'doctype': 'Employee Salary Appointment',
                'employee': employee,
                'appointment_type': appointment_type or 'Appointment',
                'pay_basis': pay_basis,
                'grade': grade if pay_basis != 'PRB' else None,
                'prb_grade': prb_grade if pay_basis == 'PRB' else None,
                'prb_salary_point': str(prb_salary_point) if pay_basis == 'PRB' else None,
                'effective_from': effective_from,
                'effective_to': effective_to,
                'salary_point': point_number if pay_basis != 'PRB' else None,
                'salary_structure': salary_structure,
                'income_tax_slab': income_tax_slab,
                'authority_reference': str(authority_reference).strip(),
            }
            existing_name = frappe.db.get_value(
                'Employee Salary Appointment',
                {'employee': employee, 'effective_from': getdate(effective_from), 'docstatus': ['<', 2]},
                'name', order_by='docstatus desc, modified desc',
            )
            status = _('Completed')
            if existing_name:
                existing = frappe.get_doc('Employee Salary Appointment', existing_name)
                if existing.docstatus == 0:
                    existing.update(values)
                    existing.save()
                    appointment = existing
                    status = _('Updated')
                else:
                    requested_structure = salary_structure or (_assignment_at(employee, effective_from) or {}).get('salary_structure')
                    unchanged = (
                        (existing.get('pay_basis') or 'Grade Scale') == pay_basis
                        and (existing.prb_grade == prb_grade if pay_basis == 'PRB' else existing.grade == grade)
                        and (str(existing.prb_salary_point or '') == str(prb_salary_point or '')
                             if pay_basis == 'PRB' else (
                                 not existing.salary_point if options.get('flat_salary')
                                 else cint(existing.salary_point) == point_number
                             ))
                        and getdate(existing.effective_to or END) == getdate(effective_to or END)
                        and existing.appointment_type == (appointment_type or 'Appointment')
                        and existing.salary_structure == requested_structure
                        and (existing.income_tax_slab or None) == (income_tax_slab or existing.income_tax_slab or None)
                        and (existing.authority_reference or '').strip() == str(authority_reference).strip()
                    )
                    if unchanged:
                        assignment = _assign_structure(
                            employee, existing.salary_structure, existing.effective_from,
                            existing.basic_salary, existing.income_tax_slab, appointment=existing,
                        )
                        if existing.salary_structure_assignment != assignment:
                            frappe.db.set_value('Employee Salary Appointment', existing.name,
                                'salary_structure_assignment', assignment, update_modified=False)
                        appointment = frappe.get_doc('Employee Salary Appointment', existing.name)
                        status = _('Already complete')
                    else:
                        existing.flags.ignore_permissions = True
                        existing.cancel()
                        values['amended_from'] = existing.name
                        appointment = frappe.get_doc(values).insert()
                        status = _('Updated')
            else:
                appointment = frappe.get_doc(values).insert()
            if appointment.docstatus == 0:
                appointment.submit()
            created.append({
                'employee': employee,
                'employee_name': emp.employee_name,
                'appointment': appointment.name,
                'salary_structure_assignment': appointment.salary_structure_assignment,
                'salary_structure': appointment.salary_structure,
                'salary_scale': appointment.salary_scale,
                'salary_point': appointment.prb_salary_point if appointment.pay_basis == 'PRB' else appointment.salary_point,
                'basic_salary': appointment.basic_salary,
                'currency': appointment.currency,
                'status': status,
            })
        except Exception as error:
            frappe.db.rollback(save_point=savepoint)
            failed.append({
                'employee': employee,
                'message': frappe.utils.strip_html(str(error)),
            })
    return {'created': created, 'failed': failed, 'requested': len(selected)}


def _payroll_setup_employees(employees):
    selected = frappe.parse_json(employees) if isinstance(employees, str) else (employees or [])
    selected = list(dict.fromkeys(str(employee).strip() for employee in selected if str(employee).strip()))
    if not selected:
        frappe.throw(_('Select at least one employee.'))
    if len(selected) > 200:
        frappe.throw(_('A maximum of 200 employees can be processed at once.'))
    return selected


def _payroll_setup_profile(profile):
    values = frappe.parse_json(profile) if isinstance(profile, str) else (profile or {})
    if not isinstance(values, dict):
        frappe.throw(_('Payroll profile values must be an object.'))
    return {key: values[key] for key in PAYROLL_PROFILE_FIELDS if key in values}


def _payroll_setup_snapshot(employee):
    fields = ['name', 'employee_name', 'company', 'status', *PAYROLL_PROFILE_FIELDS.values(),
              'department', 'designation', 'grade', 'branch', 'date_of_joining',
              'karyo_employment_start_date',
              'employment_type', 'karyo_employment_category',
              'karyo_salary_appointment', 'karyo_salary_scale', 'karyo_scale_salary_point',
              'karyo_scale_basic_salary', 'karyo_payroll_setup_pending_activation',
              'karyo_employee_group', 'default_shift', 'holiday_list', 'karyo_roster_schedule',
              'karyo_shift_schedule_assignment', 'karyo_shift_code']
    row = frappe.db.get_value('Employee', employee, fields, as_dict=True)
    if not row:
        return None
    appointment = frappe.db.get_value(
        'Employee Salary Appointment',
        {'employee': employee, 'docstatus': 1},
        ['name', 'pay_basis', 'grade', 'prb_grade', 'prb_salary_point',
         'salary_point', 'salary_scale', 'basic_salary', 'salary_structure',
         'salary_structure_assignment', 'effective_from', 'effective_to', 'income_tax_slab',
         'appointment_type', 'authority_reference'],
        as_dict=True, order_by='effective_from desc',
    )
    group_type = frappe.db.get_value('Employee Group', row.karyo_employee_group, 'karyo_prb_group') if row.karyo_employee_group else None
    from karyo.hr.roster import SHIFT_SETUP_GROUPS
    roster_required = group_type in SHIFT_SETUP_GROUPS
    roster_complete = bool(
        row.karyo_employee_group and row.karyo_work_pattern and row.default_shift and row.holiday_list
        and (row.karyo_shift_schedule_assignment or not roster_required)
    )
    recommended_effective_from = _recommended_payroll_effective_from(row)
    return {
        'employee': row.name,
        'employee_name': row.employee_name,
        'company': row.company,
        'status': row.status,
        'identity': {
            'department': row.department,
            'designation': row.designation,
            'grade': row.grade,
            'branch': row.branch,
            'date_of_joining': row.date_of_joining,
            'employment_start_date': row.karyo_employment_start_date,
            'employment_type': row.employment_type,
            'employment_category': row.karyo_employment_category,
        },
        'pending_activation': cint(row.get('karyo_payroll_setup_pending_activation')),
        'recommended_effective_from': recommended_effective_from,
        'profile': {key: row.get(fieldname) for key, fieldname in PAYROLL_PROFILE_FIELDS.items()},
        'attendance': {
            'employee_group': row.karyo_employee_group,
            'work_pattern': row.karyo_work_pattern,
            'shift_type': row.default_shift,
            'shift_code': row.karyo_shift_code,
            'holiday_list': row.holiday_list,
            'roster_schedule': row.karyo_roster_schedule,
            'assignment': row.karyo_shift_schedule_assignment,
            'requires_assignment': roster_required,
            'complete': roster_complete,
        },
        'appointment': appointment,
    }


def _recommended_payroll_effective_from(employee):
    """Choose the date payroll will actually require for the current period."""
    today = getdate(nowdate())
    cycle = frappe.db.get_value(
        'Payroll Cycle',
        {
            'company': employee.company,
            'payroll_type': employee.karyo_payroll_type,
            'status': ('not in', ['Closed', 'Cancelled']),
            'start_date': ('<=', today),
            'end_date': ('>=', today),
        },
        ['start_date', 'end_date'], as_dict=True, order_by='start_date desc',
    )
    effective = getdate(cycle.start_date) if cycle else getdate(get_first_day(today))
    joining = employee.date_of_joining or employee.karyo_employment_start_date
    if joining:
        effective = max(effective, getdate(joining))
    return str(effective)


def employee_payroll_setup_state(employee):
    """Authoritative completion state shown on the Employee Payroll tab."""
    snapshot = _payroll_setup_snapshot(employee)
    if not snapshot:
        frappe.throw(_('Employee {0} does not exist.').format(employee))
    profile = snapshot['profile']
    appointment = snapshot.get('appointment') or {}
    prb_applicable = bool(cint(profile.get('prb_opted_in')))
    payment_mode = profile.get('payment_mode')
    bank_mode = payment_mode == 'Bank'
    checks = [
        ('payroll_group', _('Payroll Group'), 2, bool(profile.get('payroll_group'))),
        ('payroll_type', _('Payroll Type'), 2, bool(profile.get('payroll_type'))),
        ('pay_day', _('Pay Day'), 2, bool(profile.get('pay_day'))),
        ('work_pattern', _('Work Pattern'), 2, bool(profile.get('work_pattern'))),
        ('payment_mode', _('Payment Mode'), 2, bool(profile.get('payment_mode'))),
        ('bank', _('Bank'), 2, not bank_mode or bool(profile.get('bank'))),
        ('bank_branch', _('Bank Branch'), 2, not bank_mode or bool(profile.get('bank_branch'))),
        ('bank_account', _('Bank Account Number'), 2, not bank_mode or bool(profile.get('bank_account'))),
        ('grade', _('Grade Code'), 3, bool(appointment.get('grade'))),
        ('salary_point', _('Salary Point'), 3, bool(appointment.get('salary_point'))),
        ('salary_scale', _('Salary Scale'), 3, bool(appointment.get('salary_scale'))),
        ('basic_salary', _('Basic Salary'), 3, appointment.get('basic_salary') not in (None, '')),
        ('salary_structure', _('Salary Structure'), 3, bool(appointment.get('salary_structure'))),
        ('salary_appointment', _('Submitted Salary Appointment'), 3, bool(appointment.get('name'))),
        ('salary_structure_assignment', _('Submitted Salary Structure Assignment'), 3,
         bool(appointment.get('salary_structure_assignment'))),
        ('employee_activation', _('Employee Payroll Activation'), 5,
         not bool(snapshot.get('pending_activation'))),
    ]
    if prb_applicable:
        checks[8:8] = [
            ('prb_grade', _('PRB Grade'), 3, bool(profile.get('prb_grade'))),
            ('prb_salary_point', _('PRB Salary Point'), 3, bool(profile.get('prb_salary_point'))),
        ]
    missing = [
        {'fieldname': fieldname, 'label': label, 'step': step,
         'message': _('Complete {0} in Payroll Setup Step {1}.').format(label, step)}
        for fieldname, label, step, complete in checks if not complete
    ]
    return {'complete': not missing, 'missing': missing, 'snapshot': snapshot,
            'completed': len(checks) - len(missing), 'total': len(checks)}


@frappe.whitelist()
def employee_payroll_setup_status(employee):
    require_admin()
    doc = frappe.get_doc('Employee', employee)
    doc.check_permission('read')
    return employee_payroll_setup_state(employee)


@frappe.whitelist(methods=['POST'])
def delete_employee_payroll_setup(employee, appointment=None):
    """Remove the selected employee's governed current Payroll Setup mapping."""
    require_admin()
    employee_doc = frappe.get_doc('Employee', employee)
    employee_doc.check_permission('write')
    if appointment:
        appointment_name = frappe.db.get_value(
            'Employee Salary Appointment',
            {'name': appointment, 'employee': employee, 'docstatus': ['<', 2]}, 'name',
        )
    else:
        appointment_name = frappe.db.get_value(
            'Employee Salary Appointment', {'employee': employee, 'docstatus': 1}, 'name',
            order_by='effective_from desc, modified desc',
        )
    if not appointment_name:
        frappe.throw(_('No active Payroll Setup was found for employee {0}.').format(employee))
    appointment_doc = frappe.get_doc('Employee Salary Appointment', appointment_name)
    assignment = appointment_doc.salary_structure_assignment
    if assignment and frappe.db.exists('Salary Structure Assignment', assignment):
        from karyo.desk.payroll_drawer import record_action
        result = record_action('salarysetup', 'Salary Structure Assignment', assignment, 'delete')
        return {'employee': employee, 'appointment': appointment_name,
                'salary_structure_assignment': assignment, 'message': result['message']}
    if appointment_doc.docstatus == 1:
        appointment_doc.cancel()
    frappe.delete_doc('Employee Salary Appointment', appointment_name)
    return {'employee': employee, 'appointment': appointment_name,
            'message': _('Payroll Setup for {0} was deleted.').format(employee)}


@frappe.whitelist()
def payroll_setup_context(employees):
    """Return employee-bound values used by both onboarding and Payroll Setup."""
    require_admin()
    selected = _payroll_setup_employees(employees)
    rows = []
    for employee in selected:
        doc = frappe.get_doc('Employee', employee)
        doc.check_permission('read')
        rows.append(_payroll_setup_snapshot(employee))

    common = {}
    for key in PAYROLL_PROFILE_FIELDS:
        values = {str(row['profile'].get(key) or '') for row in rows}
        common[key] = values.pop() if len(values) == 1 else ''
    appointment_keys = (
        'grade', 'salary_point', 'salary_structure', 'income_tax_slab',
        'effective_from', 'effective_to', 'appointment_type', 'authority_reference',
    )
    common_appointment = {}
    for key in appointment_keys:
        values = {str((row.get('appointment') or {}).get(key) or '') for row in rows}
        common_appointment[key] = values.pop() if len(values) == 1 else ''
    # A newly onboarded employee has a governed Employee Grade before the first
    # salary appointment exists. Reuse that common Grade so opening Payroll
    # Setup immediately resolves its linked scale, points and increments.
    if not common_appointment.get('grade'):
        grades = {str((row.get('identity') or {}).get('grade') or '') for row in rows}
        if len(grades) == 1:
            common_appointment['grade'] = grades.pop()
    if not common_appointment.get('effective_from'):
        recommended_dates = {row.get('recommended_effective_from') or '' for row in rows}
        if len(recommended_dates) == 1:
            common_appointment['effective_from'] = recommended_dates.pop()
    companies = {row['company'] for row in rows}
    return {
        'employees': rows,
        'common_profile': common,
        'common_appointment': common_appointment,
        'company': next(iter(companies)) if len(companies) == 1 else None,
        'same_company': len(companies) == 1,
    }


def repair_payroll_assignment_dates(payroll_cycle):
    """Backdate wizard-created assignments that miss an open cycle's actual start.

    This is deliberately an explicit administrative repair, not a side effect of
    readiness. It only touches linked appointment/assignment pairs, refuses to
    change employees with payroll slips, and leaves genuinely missing assignments
    blocked for user action.
    """
    require_admin()
    cycle = frappe.get_doc('Payroll Cycle', payroll_cycle)
    if cycle.status in ('Closed', 'Cancelled') or cycle.docstatus == 2:
        frappe.throw(_('Closed or cancelled payroll cycles cannot be repaired.'))

    from karyo.payroll.readiness import get_cycle_employees, salary_assignment_required_from

    repaired, skipped = [], []
    for employee in get_cycle_employees(cycle):
        joining = frappe.db.get_value('Employee', employee, 'date_of_joining')
        required_from = salary_assignment_required_from(cycle, joining)
        if frappe.db.exists('Salary Structure Assignment', {
            'employee': employee, 'company': cycle.company,
            'from_date': ('<=', required_from), 'docstatus': 1,
        }):
            continue
        candidate = frappe.db.get_value(
            'Salary Structure Assignment',
            {
                'employee': employee, 'company': cycle.company,
                'from_date': ('between', [required_from, cycle.end_date]), 'docstatus': 1,
            },
            ['name', 'from_date', 'karyo_salary_appointment'], as_dict=True,
            order_by='from_date asc',
        )
        if not candidate or not candidate.karyo_salary_appointment:
            skipped.append({'employee': employee, 'reason': _('No linked assignment can be repaired.')})
            continue
        appointment = frappe.db.get_value(
            'Employee Salary Appointment', candidate.karyo_salary_appointment,
            ['name', 'effective_from', 'salary_structure_assignment', 'docstatus'], as_dict=True,
        )
        if (not appointment or appointment.docstatus != 1
                or appointment.salary_structure_assignment != candidate.name
                or getdate(appointment.effective_from) != getdate(candidate.from_date)):
            skipped.append({'employee': employee, 'reason': _('The appointment and assignment are not a matching submitted pair.')})
            continue
        if frappe.db.exists('Salary Slip', {
            'employee': employee, 'docstatus': ('<', 2),
            'start_date': ('<=', cycle.end_date), 'end_date': ('>=', cycle.start_date),
        }):
            skipped.append({'employee': employee, 'reason': _('A salary slip already exists for this period.')})
            continue

        previous = getdate(candidate.from_date)
        frappe.db.set_value('Salary Structure Assignment', candidate.name, 'from_date', required_from)
        frappe.db.set_value('Employee Salary Appointment', appointment.name, 'effective_from', required_from)
        note = _(
            'Payroll effective date corrected from {0} to {1} so it matches the actual start of payroll cycle {2}.'
        ).format(previous, required_from, cycle.name)
        frappe.get_doc('Salary Structure Assignment', candidate.name).add_comment('Info', note)
        frappe.get_doc('Employee Salary Appointment', appointment.name).add_comment('Info', note)
        repaired.append({
            'employee': employee, 'assignment': candidate.name,
            'appointment': appointment.name, 'from_date': str(required_from),
        })
    return {'payroll_cycle': cycle.name, 'repaired': repaired, 'skipped': skipped}


def _validate_employee_payroll_profile(doc):
    required = {
        'karyo_payroll_group': _('Payroll Group'),
        'karyo_payroll_type': _('Payroll Type'),
        'karyo_pay_day': _('Pay Day'),
        'karyo_work_pattern': _('Work Pattern'),
        'salary_mode': _('Payment Mode'),
    }
    missing = [label for fieldname, label in required.items() if not doc.get(fieldname)]
    if doc.get('salary_mode') == 'Bank':
        missing.extend(label for fieldname, label in {
            'karyo_payroll_bank': _('Bank'),
            'karyo_payroll_bank_branch': _('Bank Branch'),
            'bank_ac_no': _('Bank Account Number'),
        }.items() if not doc.get(fieldname))
    if cint(doc.get('karyo_prb_opted_in')):
        missing.extend(label for fieldname, label in {
            'karyo_prb_grade': _('PRB Grade'),
            'karyo_prb_salary_point': _('PRB Salary Point'),
        }.items() if not doc.get(fieldname))
    if missing:
        frappe.throw(_('Complete the employee payroll dependencies: {0}.').format(', '.join(missing)))


@frappe.whitelist(methods=['POST'])
def complete_payroll_setup(employees, profile, grade, salary_point, effective_from,
                           authority_reference, salary_structure=None, income_tax_slab=None,
                           effective_to=None, appointment_type='Appointment'):
    """Save the employee profile and governed salary mapping as one employee-bound flow."""
    require_admin()
    selected = _payroll_setup_employees(employees)
    profile_values = _payroll_setup_profile(profile)
    completed, failed = [], []

    employee_docs = []
    for employee in selected:
        doc = frappe.get_doc('Employee', employee)
        doc.check_permission('write')
        pending_activation = cint(doc.get('karyo_payroll_setup_pending_activation'))
        if doc.status != 'Active' and not pending_activation:
            frappe.throw(_('Employee {0} is not Active.').format(employee))
        employee_docs.append(doc)
    companies = {doc.company for doc in employee_docs}
    if len(companies) != 1:
        frappe.throw(_('Common payroll setup can only be applied to employees in the same Company.'))

    for index, doc in enumerate(employee_docs):
        employee = doc.name
        savepoint = 'complete_payroll_setup_{0}'.format(index)
        frappe.db.savepoint(savepoint)
        try:
            for key, fieldname in PAYROLL_PROFILE_FIELDS.items():
                value = profile_values.get(key)
                if value not in (None, ''):
                    doc.set(fieldname, value)
                elif key in SECONDARY_ACCOUNT_PROFILE_FIELDS and key in profile_values:
                    # Explicit blank values clear a secondary route; omitted
                    # fields in older clients and CSVs preserve existing data.
                    doc.set(fieldname, None)
            if profile_values.get('prb_opted_in') not in (None, '') and not cint(profile_values.get('prb_opted_in')):
                doc.karyo_prb_opted_in = 0
                doc.karyo_prb_grade = None
                doc.karyo_prb_salary_point = None
            _validate_employee_payroll_profile(doc)
            # Existing incomplete records may already be marked On Payroll.
            # Save the profile as inactive inside this savepoint, create and
            # synchronize the governed appointment, then activate atomically.
            if doc.meta.has_field('karyo_on_payroll'):
                doc.karyo_on_payroll = 0
            # The governed appointment below owns the requested effective date
            # and native assignment. Avoid the general Employee hook creating
            # an interim assignment dated today while this wizard is running.
            doc.flags.skip_prb_assignment_sync = True
            doc.save()
            result = bulk_salary_setup(
                [employee], grade, salary_point, effective_from, authority_reference,
                salary_structure=salary_structure, income_tax_slab=income_tax_slab,
                effective_to=effective_to, appointment_type=appointment_type,
                # PRB opt-in is an employee eligibility/profile attribute.  It
                # must not replace the governed Employee Grade -> Salary Scale
                # appointment selected in this wizard.
                pay_basis='Grade Scale',
            )
            if result.get('failed'):
                frappe.throw(result['failed'][0]['message'])
            row = result['created'][0]
            activation = {}
            if doc.meta.has_field('karyo_on_payroll'):
                activation['karyo_on_payroll'] = 1
            if doc.meta.has_field('karyo_payroll_setup_pending_activation'):
                activation['karyo_payroll_setup_pending_activation'] = 0
                if cint(doc.get('karyo_payroll_setup_pending_activation')):
                    activation['status'] = 'Active'
            if activation:
                frappe.db.set_value('Employee', employee, activation, update_modified=False)
            row['snapshot'] = _payroll_setup_snapshot(employee)
            completed.append(row)
        except Exception as error:
            frappe.db.rollback(save_point=savepoint)
            failed.append({'employee': employee, 'message': frappe.utils.strip_html(str(error))})

    return {'created': completed, 'failed': failed, 'requested': len(selected)}


@frappe.whitelist()
def payroll_setup_csv_sample():
    """A ready-to-download example with the exact bulk setup column contract."""
    require_admin()
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=PAYROLL_SETUP_CSV_COLUMNS, lineterminator='\n')
    writer.writeheader()
    writer.writerow({
        'employee_id': 'EMP-0001', 'payroll_group': 'MONTHLY', 'payroll_type': 'Major',
        'pay_day': 'MONTHLY-25', 'work_pattern': 'STANDARD-40', 'salary_currency': 'MUR',
        'payment_mode': 'Bank',
        'bank': 'Example Bank', 'bank_branch': 'MAIN-001', 'bank_account': '000123456789',
        'bank_account_holder_name': 'Example Employee One', 'bank_account_is_primary': '1',
        'bank_account_effective_from': nowdate(),
        'prb_opted_in': '0', 'prb_grade': '', 'prb_salary_point': '',
        'grade': 'GRADE-01', 'salary_point': '1', 'effective_from': nowdate(),
        'salary_structure': 'Monthly Payroll', 'appointment_type': 'Appointment',
        'authority_reference': 'HR-APPROVAL-001',
    })
    writer.writerow({
        'employee_id': 'EMP-0002', 'payroll_group': 'MONTHLY', 'payroll_type': 'Major',
        'pay_day': 'MONTHLY-25', 'work_pattern': 'STANDARD-40', 'salary_currency': 'MUR',
        'payment_mode': 'Bank',
        'bank': 'Example Bank', 'bank_branch': 'MAIN-001', 'bank_account': '000987654321',
        'bank_account_holder_name': 'Example Employee Two', 'bank_account_is_primary': '1',
        'bank_account_effective_from': nowdate(),
        'prb_opted_in': '0', 'prb_grade': '', 'prb_salary_point': '',
        'grade': 'GRADE-01', 'salary_point': '2', 'effective_from': nowdate(),
        'salary_structure': 'Monthly Payroll', 'appointment_type': 'Appointment',
        'authority_reference': 'HR-APPROVAL-001',
    })
    return {'filename': 'payroll_setup_sample.csv', 'content': output.getvalue(),
            'columns': PAYROLL_SETUP_CSV_COLUMNS}


@frappe.whitelist(methods=['POST'])
def import_payroll_setup_csv(csv_content):
    """Apply employee payroll profiles and salary appointments row by row from CSV."""
    require_admin()
    text = (csv_content or '').lstrip('\ufeff')
    if not text.strip():
        frappe.throw(_('Choose a non-empty CSV file.'))
    reader = csv.DictReader(io.StringIO(text))
    headers = [str(value or '').strip() for value in (reader.fieldnames or [])]
    missing = [column for column in PAYROLL_SETUP_CSV_COLUMNS if column not in headers]
    if missing:
        frappe.throw(_('CSV is missing columns: {0}. Download the sample and keep its header row.').format(', '.join(missing)))

    completed, failed = [], []
    for row_number, raw in enumerate(reader, 2):
        row = {key: str(value or '').strip() for key, value in raw.items()}
        employee = row.get('employee_id')
        if not employee:
            failed.append({'row': row_number, 'employee': '', 'message': _('Employee ID is required.')})
            continue
        try:
            result = complete_payroll_setup(
                [employee], {key: row[key] for key in PAYROLL_PROFILE_FIELDS if key in row},
                row.get('grade'), row.get('salary_point'), row.get('effective_from'),
                row.get('authority_reference'), salary_structure=row.get('salary_structure') or None,
                income_tax_slab=row.get('income_tax_slab') or None,
                effective_to=row.get('effective_to') or None,
                appointment_type=row.get('appointment_type') or 'Appointment',
            )
        except Exception as error:
            failed.append({'row': row_number, 'employee': employee,
                           'message': frappe.utils.strip_html(str(error))})
            continue
        if result.get('created'):
            completed.append({'row': row_number, **result['created'][0]})
        else:
            failed.append({'row': row_number, **result['failed'][0]})
    return {'created': completed, 'failed': failed, 'requested': len(completed) + len(failed)}



def governed_scale_amount(scale, salary_point, values):
    """Resolve a scale salary, including an explicitly approved long-service amount."""
    authorized = cint(values.get('beyond_scale_authorized'))
    if is_flat_scale(scale):
        if authorized:
            frappe.throw(_('Long Service Increment is only available on a step salary scale.'))
        return scale.get('basic_salary') or scale.lowest_salary
    try:
        selected_point = float(salary_point)
    except (TypeError, ValueError):
        selected_point = -1
    matches = [row for row in scale.points if row.salary_point == cint(salary_point)]
    if len(matches) != 1 or selected_point != cint(salary_point):
        frappe.throw(_('Select a salary point belonging to the grade salary scale.'))
    amount = matches[0].salary
    if authorized:
        if not {'System Manager', 'HR Manager', 'Payroll Manager'}.intersection(frappe.get_roles()):
            frappe.throw(_('Only an HR or Payroll Manager can authorize Long Service Increment.'), frappe.PermissionError)
        if matches[0].salary_point != scale.points[-1].salary_point:
            frappe.throw(_('Long Service Increment can only be authorized from the top salary point.'))
        if money(values.get('beyond_scale_salary')) <= money(amount):
            frappe.throw(_('Authorized Basic Salary must be greater than the scale maximum.'))
        if not str(values.get('beyond_scale_authority') or '').strip() or not str(values.get('beyond_scale_reason') or '').strip():
            frappe.throw(_('Beyond-Scale Authority / Reference and Long-Service Justification are required.'))
        amount = float(money(values.get('beyond_scale_salary')))
    return amount


class EmployeeSalaryAppointment(Document):
    def validate(self):
        employee = frappe.get_doc('Employee', self.employee)
        employee.check_permission('write')
        start, end = period(self.effective_from, self.effective_to)
        if employee.date_of_joining and start < getdate(employee.date_of_joining):
            frappe.throw(_('Salary appointment cannot begin before Date of Joining.'))
        if employee.relieving_date and end > getdate(employee.relieving_date):
            frappe.throw(_('Salary appointment cannot extend beyond the employee relieving date.'))
        self.company, self.employee_name = employee.company, employee.employee_name
        self.pay_basis = self.get('pay_basis') or 'Grade Scale'
        if self.pay_basis == 'PRB':
            if cint(self.get('beyond_scale_authorized')):
                frappe.throw(_('Long Service Increment requires a Grade Scale salary appointment.'))
            if not cint(employee.get('karyo_prb_opted_in')):
                frappe.throw(_('Employee must be opted into PRB before creating a PRB salary appointment.'))
            allocation = prb_allocation(self.prb_grade, self.prb_salary_point, employee.company, start,
                review_year=self.get('prb_year'))
            self.grade = self.salary_scale = self.salary_point = None
            self.grade_description = allocation['grade_description']
            self.job_family = None
            self.employee_category = None
            amount = allocation['basic_salary']
            self.currency = allocation['currency']
            self.prb_year = allocation['prb_year']
            self.prb_phase_percent = allocation['phase_percentage']
            self.prb_full_salary = allocation['full_salary']
            self.scale_description = _('PRB Grade {0}, Salary Point {1}').format(
                self.prb_grade, self.prb_salary_point
            )
        else:
            grade_doc = frappe.get_doc('Employee Grade', self.grade)
            self.grade_description = grade_doc.get('karyo_grade_description')
            self.job_family = grade_doc.get('karyo_job_family')
            self.employee_category = grade_doc.get('karyo_employee_category')
            link, scale = grade_scale(self.grade, start)
            if not contains(link.effective_from, link.effective_to, start, end):
                frappe.throw(_('The appointment must remain within the grade salary-scale period. Set Effective To if required.'))
            if scale.currency != frappe.db.get_value('Company', employee.company, 'default_currency'):
                frappe.throw(_('The salary scale currency must match the employee company currency.'))
            if self.salary_scale and self.salary_scale != scale.name:
                frappe.throw(_('The selected salary scale does not belong to the grade for this effective date.'))
            amount = governed_scale_amount(scale, self.salary_point, self)
            if is_flat_scale(scale):
                self.salary_point = None
            self.salary_scale, self.scale_description = scale.name, scale.description
            self.currency, self.prb_year = scale.currency, scale.prb_year
        if not cint(self.get('beyond_scale_authorized')) and self.basic_salary not in (None, 0, '') and money(self.basic_salary) != money(amount):
            frappe.throw(_('Basic Salary must match the governed amount for the selected salary point.'))
        self.basic_salary = amount
        native = _assignment_at(self.employee, start)
        if not self.salary_structure and native:
            self.salary_structure = native.salary_structure
            self.income_tax_slab = self.income_tax_slab or native.income_tax_slab
        if self.salary_structure:
            structure = frappe.get_doc('Salary Structure', self.salary_structure)
            if (structure.docstatus != 1 or structure.is_active != 'Yes'
                    or structure.payroll_frequency != 'Monthly' or structure.company != employee.company):
                frappe.throw(_('Select an active, submitted monthly Salary Structure for company {0}.').format(employee.company))
        elif self.docstatus == 1:
            frappe.throw(_('Select a Salary Structure, or first create a submitted Salary Structure Assignment for this employee.'))
        # Serialize changes for an employee, including two simultaneous inserts.
        frappe.db.sql('select name from `tabEmployee` where name=%s for update', (self.employee,))
        overlaps = frappe.db.sql('''select name from `tabEmployee Salary Appointment`
            where employee=%s and name!=%s and docstatus<2 and effective_from<=%s
            and coalesce(effective_to,'9999-12-31')>=%s limit 1''',
            (self.employee, self.name or '', end, start))
        if overlaps:
            frappe.throw(_('Appointment period overlaps {0}. Close or correct the existing period first.').format(overlaps[0][0]))
        if self.docstatus == 0:
            self.approved_by = self.approved_on = None

    def before_submit(self):
        self.approved_by, self.approved_on = frappe.session.user, now_datetime()
        self.salary_structure_assignment = _assign_structure(
            self.employee, self.salary_structure, self.effective_from, self.basic_salary,
            self.income_tax_slab, appointment=self,
        )

    def before_update_after_submit(self):
        self.check_permission("submit")
        self.validate()
        used = frappe.get_all('PRB Payroll Run', filters={'karyo_salary_appointment': self.name, 'docstatus': ['<', 2]},
                              fields=['name', 'calculation_date'])
        for run in used:
            if not getdate(self.effective_from) <= getdate(run.calculation_date) <= getdate(self.effective_to or END):
                frappe.throw(_('The revised period would exclude payroll run {0}. Cancel or recalculate that run first.').format(run.name))

    def before_cancel(self):
        if frappe.db.exists('PRB Payroll Run', {'karyo_salary_appointment': self.name, 'docstatus': ['<', 2]}):
            frappe.throw(_('This appointment is used by payroll. Cancel the linked payroll runs before cancelling the appointment.'))
        if frappe.db.exists('Salary Slip', {'karyo_salary_appointment': self.name, 'docstatus': ['<', 2]}):
            frappe.throw(_('This appointment is used by a Salary Slip. Cancel the linked Salary Slips before cancelling the appointment.'))

    def on_submit(self):
        sync_employee(self.employee)
        sync_salary_structure_base(
            self.employee, self.effective_from, self.effective_to, self.basic_salary, appointment=self
        )

    def on_update_after_submit(self):
        sync_employee(self.employee)
        if self.flags.prb_revision_closing:
            return
        sync_salary_structure_base(
            self.employee, self.effective_from, self.effective_to, self.basic_salary, appointment=self
        )

    def on_cancel(self):
        for assignment_name in frappe.get_all('Salary Structure Assignment',
                filters={'karyo_salary_appointment': self.name, 'docstatus': 1}, pluck='name'):
            assignment = frappe.get_doc('Salary Structure Assignment', assignment_name)
            assignment.flags.ignore_permissions = True
            assignment.cancel()
        sync_employee(self.employee)


def approved_appointment(employee, date):
    rows = frappe.db.sql('''select name, pay_basis, grade, prb_grade, prb_salary_point,
        salary_scale, salary_point, basic_salary, beyond_scale_authorized,
        currency, prb_year, effective_from, effective_to, approved_by, approved_on
        from `tabEmployee Salary Appointment` where employee=%s and docstatus=1
        and effective_from<=%s and coalesce(effective_to,'9999-12-31')>=%s
        order by effective_from desc limit 2''', (employee, getdate(date), getdate(date)), as_dict=True)
    if len(rows) > 1:
        frappe.throw(_('Multiple approved salary appointments cover this date. Contact HR to resolve the overlap.'))
    current = rows[0] if rows else None
    if current and current.pay_basis == 'PRB':
        from karyo.setup.payroll_profiles import prb_salary_value
        from karyo.prb.salary_phases import phase_percentage
        amount = prb_salary_value(current.prb_salary_point, current.prb_year, date)
        if amount is None:
            frappe.throw(_('The approved PRB appointment has no salary-point master for its review year.'))
        current.basic_salary = amount
        current.prb_phase_percent = phase_percentage(date) if cint(current.prb_year) == 2026 else 100
    return current


def employee_hourly_rate_snapshot(employee, date=None, monthly_basic=None, work_pattern=None):
    """Return the governed PRB normal hourly rate and a user-readable formula.

    Salary comes from the effective approved appointment. The weekly-hour
    denominator follows the employee's work-pattern group: 40 hours for
    workmen/surveillant/shift/roster/staggered/40-hour groups, otherwise 33.75.
    """
    from karyo.prb.overtime import FORTY_HOUR_GROUPS, hourly_rate

    on_date = getdate(date or nowdate())
    employee_doc = employee if hasattr(employee, "doctype") else frappe.get_doc("Employee", employee)
    appointment = approved_appointment(employee_doc.name, on_date)
    structure_result = None
    if not appointment and monthly_basic is None:
        from karyo.payroll.basic_salary import from_salary_structure

        structure_result = from_salary_structure(frappe._dict(
            employee=employee_doc.name, company=employee_doc.company, calculation_date=on_date
        ))
    basic = flt(
        monthly_basic if monthly_basic is not None
        else appointment.basic_salary if appointment
        else structure_result.get("amount") if structure_result
        else employee_doc.get("karyo_scale_basic_salary")
    )
    pattern_name = work_pattern if work_pattern is not None else employee_doc.get("karyo_work_pattern")
    pattern = frappe.db.get_value(
        "Employee Work Pattern", pattern_name, ["prb_group", "normal_weekly_hours"], as_dict=True
    ) if pattern_name else None
    group = str((pattern or {}).get("prb_group") or "other").strip().lower()
    denominator = 40.0 if group in FORTY_HOUR_GROUPS else 33.75
    currency = (appointment.currency if appointment else None) or frappe.db.get_value(
        "Company", employee_doc.company, "default_currency"
    ) or "MUR"
    rate = hourly_rate(basic * 12, denominator, precision=6) if basic else 0.0
    if basic:
        source = (
            _("Approved Salary Appointment {0}").format(appointment.name)
            if appointment else structure_result.get("rule_ref") if structure_result
            else _("Employee salary allocation")
        )
        calculation = _(
            "{0} {1:,.2f} monthly basic × 12 ÷ (52 × {2:g} hours) = {0} {3:,.6f} per hour. Source: {4}."
        ).format(currency, basic, denominator, rate, source)
    else:
        source = _("Missing approved Salary Appointment or submitted Salary Structure Assignment")
        calculation = _("Complete an approved Salary Appointment or submitted Salary Structure Assignment to calculate the hourly rate.")
    return {
        "employee": employee_doc.name,
        "as_of": str(on_date),
        "salary_appointment": appointment.name if appointment else None,
        "salary_structure": structure_result.get("salary_structure") if structure_result else None,
        "salary_structure_assignment": structure_result.get("salary_structure_assignment") if structure_result else None,
        "salary_source": source,
        "monthly_basic": basic,
        "currency": currency,
        "work_pattern": pattern_name,
        "employee_group": group,
        "weekly_hours_denominator": denominator,
        "hourly_rate": rate,
        "calculation": calculation,
    }


@frappe.whitelist()
def employee_hourly_rate_context(employee, date=None, work_pattern=None):
    doc = frappe.get_doc("Employee", employee)
    doc.check_permission("read")
    return employee_hourly_rate_snapshot(doc, date, work_pattern=work_pattern)


def sync_salary_structure_base(employee, effective_from, effective_to, amount, appointment=None):
    if not appointment or appointment.get('pay_basis') != 'PRB':
        return _sync_salary_structure_period(employee, effective_from, effective_to, amount, appointment)
    from karyo.setup.payroll_profiles import prb_salary_value
    from frappe.utils import add_days

    start, end = period(effective_from, effective_to)
    # A shortened appointment must not leave its old phase assignment in force.
    for row in frappe.get_all('Salary Structure Assignment',
            filters={'employee': employee, 'docstatus': 1, 'karyo_salary_appointment': appointment.name,
                     'from_date': ['>', end]}, fields=['name']):
        owned = frappe.get_doc('Salary Structure Assignment', row.name)
        owned.flags.ignore_permissions = True
        owned.cancel()
    starts = [start] + [getdate(date) for date in ['2026-01-01', '2027-01-01']
                       if cint(appointment.prb_year) == 2026 and start < getdate(date) <= end]
    changed = []
    for index, date in enumerate(starts):
        stop = add_days(starts[index + 1], -1) if index + 1 < len(starts) else end
        phase_amount = prb_salary_value(appointment.prb_salary_point, appointment.prb_year, date)
        changed.extend(_sync_salary_structure_period(employee, date, stop, phase_amount, appointment))
    return changed


def _sync_salary_structure_period(employee, effective_from, effective_to, amount, appointment=None):
    """Carry the governed appointment amount into native HRMS calculations.

    Salary Structure controls which earnings and deductions apply; its
    effective assignment carries the base used by every formula.  Preserve
    history by creating/amending effective-dated assignments instead of
    rewriting a submitted row in place.
    """
    start, end = period(effective_from, effective_to)
    if frappe.db.exists('Salary Slip', {
        'employee': employee, 'docstatus': 1,
        'end_date': ['>=', start], 'start_date': ['<=', end],
    }):
        frappe.throw(_('Cancel submitted Salary Slips in the salary appointment period before changing its calculated salary.'))
    current_name = frappe.db.get_value(
        'Salary Structure Assignment',
        {'employee': employee, 'docstatus': 1, 'from_date': ['<=', start]},
        'name', order_by='from_date desc, creation desc',
    )
    if not current_name:
        return []
    assignments = frappe.get_all(
        'Salary Structure Assignment',
        filters={
            'employee': employee, 'docstatus': 1,
            'from_date': ['between', [start, end]],
        },
        fields=['name', 'from_date', 'base'], order_by='from_date asc, creation asc',
    )
    by_date = {str(row.from_date): row for row in assignments}
    current = frappe.get_doc('Salary Structure Assignment', current_name)
    by_date.setdefault(str(start), frappe._dict(name=current.name, from_date=current.from_date, base=current.base))
    changed = []
    for target_date, row in sorted(by_date.items()):
        if abs(flt(row.base) - flt(amount)) < .005 and getdate(row.from_date) == getdate(target_date):
            mapping = _appointment_mapping(appointment)
            if mapping:
                source = frappe.get_doc('Salary Structure Assignment', row.name)
                supported = {key: value for key, value in mapping.items() if source.meta.has_field(key)}
                if supported:
                    frappe.db.set_value('Salary Structure Assignment', row.name, supported, update_modified=False)
            continue
        source = frappe.get_doc('Salary Structure Assignment', row.name)
        replacement = frappe.copy_doc(source)
        replacement.update({'from_date': getdate(target_date), 'base': flt(amount), 'docstatus': 0, 'amended_from': None})
        _set_supported(replacement, _appointment_mapping(appointment))
        if getdate(source.from_date) == getdate(target_date):
            source.flags.ignore_permissions = True
            source.cancel()
            replacement.amended_from = source.name
        replacement.flags.ignore_permissions = True
        replacement.insert(ignore_permissions=True)
        replacement.submit()
        changed.append(replacement.name)
    _refresh_draft_salary_slips(employee, start, end)
    return changed


def validate_structure_assignment(doc, method=None):
    """An approved salary appointment owns the assignment's formula base."""
    if not (doc.get('employee') and doc.get('from_date')):
        return
    appointment = approved_appointment(doc.employee, doc.from_date)
    if appointment:
        doc.base = appointment.basic_salary
        _set_supported(doc, {
            'karyo_salary_appointment': appointment.name,
            'karyo_salary_scale': appointment.salary_scale,
            'karyo_salary_point': cint(appointment.salary_point),
        })
    elif flt(doc.get('base')) <= 0 and doc.get('salary_structure'):
        structure = frappe.get_cached_doc('Salary Structure', doc.salary_structure)
        uses_base = any(
            cint(row.get('amount_based_on_formula'))
            and re.search(r'\bbase\b', row.get('formula') or '', flags=re.IGNORECASE)
            for row in structure.get('earnings') or []
        )
        if uses_base:
            frappe.throw(_(
                'Base salary must be greater than zero because Salary Structure {0} '
                'uses base in an earning formula.'
            ).format(doc.salary_structure))


def _salary_slip_assignment_date(doc):
    """Return the exact date HRMS uses to select a Salary Structure Assignment."""
    start = getdate(doc.get('start_date') or doc.get('end_date') or doc.get('posting_date') or nowdate())
    end = getdate(doc.get('end_date') or start)
    joining = doc.get('joining_date') or frappe.db.get_value('Employee', doc.employee, 'date_of_joining')
    joining = getdate(joining) if joining else None
    if joining and start < joining <= end:
        return joining
    return start


def prepare_prb_salary_slip(doc, method=None):
    """Ensure the effective PRB base before native HRMS evaluates formulas."""
    if not doc.get('employee') or doc.docstatus == 2 or getattr(frappe.flags, 'preparing_prb_phase', False):
        return
    from karyo.hr.final_settlement import is_post_exit_run
    if is_post_exit_run(doc.employee, doc.get('start_date')):
        return
    date = _salary_slip_assignment_date(doc)
    appointment = approved_appointment(doc.employee, date)
    if appointment and appointment.pay_basis != 'PRB':
        return
    amount = appointment.basic_salary if appointment else None
    if not appointment:
        # Support legacy PRB profiles only before appointment governance begins.
        if frappe.db.exists('Employee Salary Appointment', {'employee': doc.employee,
                'docstatus': ['in', [1, 2]], 'effective_from': ['<=', date]}):
            return
        profile = frappe.db.get_value('Employee', doc.employee,
            ['karyo_prb_opted_in', 'karyo_prb_salary_point'], as_dict=True)
        if not profile or not profile.karyo_prb_opted_in or not profile.karyo_prb_salary_point:
            return
        from karyo.setup.payroll_profiles import prb_salary_value
        amount = prb_salary_value(profile.karyo_prb_salary_point, effective_date=date)
        if amount is None:
            frappe.throw(_('No salary master exists for the employee PRB point.'))
    current = _assignment_at(doc.employee, date)
    if current and abs(flt(current.base) - amount) < .005:
        return
    frappe.flags.preparing_prb_phase = True
    try:
        _sync_salary_structure_period(doc.employee, date, date, amount, appointment)
    finally:
        frappe.flags.preparing_prb_phase = False


def validate_salary_slip_base(doc, method=None):
    """Audit and reject a slip if it was calculated from a non-governed base."""
    if not doc.get('employee'):
        return
    calculation_date = doc.get('end_date') or doc.get('posting_date') or nowdate()
    from karyo.hr.final_settlement import is_post_exit_run
    if is_post_exit_run(doc.employee, doc.get('start_date')):
        calculation_date = frappe.db.get_value('Employee', doc.employee, 'relieving_date')
    assignment_date = _salary_slip_assignment_date(doc)
    appointment = approved_appointment(doc.employee, calculation_date)
    if not appointment:
        # Once effective-dated appointment governance has begun, never fall back
        # silently to an older native assignment across a salary-history gap.
        if frappe.db.exists('Employee Salary Appointment', {
            'employee': doc.employee, 'docstatus': ['in', [1, 2]],
            'effective_from': ['<=', calculation_date],
        }):
            frappe.throw(_(
                'No approved Salary Appointment covers {0}. '
                'Complete the salary assignment before calculating payroll.'
            ).format(calculation_date))
        return
    assignment = frappe.db.get_value(
        'Salary Structure Assignment',
        {
            'employee': doc.employee, 'salary_structure': doc.salary_structure,
            'from_date': ['<=', assignment_date], 'docstatus': 1,
        },
        ['name', 'base'], order_by='from_date desc, creation desc', as_dict=True,
    )
    if not assignment or abs(flt(assignment.base) - flt(appointment.basic_salary)) >= .005:
        frappe.throw(_(
            'Salary Slip base does not match approved Salary Appointment {0}. '
            'The Salary Structure Assignment effective on {1} must carry base {2}. '
            'Correct the assignment effective date/base before calculating payroll.'
        ).format(
            appointment.name,
            frappe.format(assignment_date, {'fieldtype': 'Date'}),
            frappe.format(appointment.basic_salary, {'fieldtype': 'Currency'}),
        ))
    doc.karyo_salary_appointment = appointment.name
    doc.karyo_salary_scale = appointment.salary_scale
    doc.karyo_salary_point = cint(appointment.salary_point)
    doc.karyo_salary_base = appointment.basic_salary


PAY_ADJUSTMENT_COMPONENT = 'Pay Adjustment'


def _clamp_zero_net_pay(doc):
    """Avoid a sub-cent floating-point remainder blocking Salary Slip submit."""
    if flt(doc.get('net_pay'), doc.precision('net_pay')) != 0:
        return
    doc.net_pay = 0
    doc.rounded_total = 0
    doc.base_net_pay = 0
    doc.base_rounded_total = 0
    doc.set_net_total_in_words()


def enforce_non_negative_net_pay(doc, method=None):
    """Keep the full EMI and fund its shortfall through a pay adjustment.

    A loan deduction must remain visible and recoverable in full. When it would
    make Net Pay negative, add a non-taxable earnings-side Pay Adjustment for
    exactly the shortfall. PAYE is reduced only when no loan deduction caused
    the negative balance.
    """
    # A previously balanced adjustment can leave a negative binary-float trace
    # (for example -4.5e-13).  Treat it as zero before calculating a new
    # shortfall; otherwise the existing adjustment would be overwritten by
    # that trace amount and the slip would become genuinely negative again.
    if flt(doc.get('net_pay'), doc.precision('net_pay')) >= 0:
        _clamp_zero_net_pay(doc)
        return
    deficit = abs(flt(doc.net_pay))
    paye_component = frappe.db.get_value(
        'Payroll PDB Code', {'pdb_code': 'PAYE', 'is_active': 1}, 'salary_component'
    )
    loan_components = {'Karyo Loan Capital', 'Karyo Loan Interest', 'Karyo Loan Insurance'}
    if any(flt(row.amount) > 0 and row.salary_component in loan_components
           for row in doc.get('deductions') or []):
        if not frappe.db.exists('Salary Component', PAY_ADJUSTMENT_COMPONENT):
            frappe.throw(_('Salary Component {0} is not configured.').format(PAY_ADJUSTMENT_COMPONENT))
        from hrms.payroll.doctype.salary_slip.salary_slip import get_salary_component_data
        doc.update_component_row(
            get_salary_component_data(PAY_ADJUSTMENT_COMPONENT),
            deficit,
            'earnings',
            default_amount=deficit,
        )
        # The controller calculated Gross Pay before document-event hooks ran.
        # Refresh both gross totals so the newly appended earning participates in
        # Net Pay immediately and remains consistent in the persisted draft.
        doc.gross_pay = doc.get_component_totals('earnings', depends_on_payment_days=1)
        doc.base_gross_pay = flt(doc.gross_pay) * flt(doc.exchange_rate or 1)
        doc.set_net_pay()
        _clamp_zero_net_pay(doc)
        return
    adjustable = [row for row in doc.get('deductions') or []
                  if paye_component and row.salary_component == paye_component]
    for row in adjustable:
        if deficit <= 0.005:
            break
        reduction = min(flt(row.amount), deficit)
        if reduction <= 0:
            continue
        row.amount = flt(row.amount) - reduction
        deficit -= reduction
    doc.set_net_pay()
    _clamp_zero_net_pay(doc)


def sync_employee(employee):
    current = approved_appointment(employee, nowdate())
    fields = {'karyo_salary_appointment': current.name if current else None,
              'karyo_salary_scale': current.salary_scale if current else None,
              'karyo_scale_salary_point': cint(current.salary_point) if current else 0,
              'karyo_scale_basic_salary': current.basic_salary if current else 0,
              'ctc': current.basic_salary if current else (
                  frappe.db.get_value('Employee', employee, 'karyo_prb_row3_salary') or 0
              ),
              'karyo_salary_effective_from': current.effective_from if current else None}
    if frappe.get_meta('Employee').has_field('karyo_hourly_rate'):
        rate = employee_hourly_rate_snapshot(employee, monthly_basic=current.basic_salary if current else None)
        fields.update({
            'karyo_hourly_rate': rate['hourly_rate'],
            'karyo_hourly_rate_calculation': rate['calculation'],
        })
    if current and current.pay_basis == 'PRB':
        fields.update({
            'karyo_prb_opted_in': 1,
            'karyo_prb_grade': current.prb_grade,
            'karyo_prb_salary_point': current.prb_salary_point,
            'karyo_prb_row3_salary': current.basic_salary,
        })
    elif current:
        fields['grade'] = current.grade
        grade = frappe.db.get_value(
            'Employee Grade', current.grade,
            ['karyo_grade_description', 'karyo_job_family', 'karyo_employee_category'], as_dict=True,
        )
        if grade:
            fields.update({
                'karyo_grade_description': grade.karyo_grade_description,
                'karyo_job_family': grade.karyo_job_family,
            })
            if grade.karyo_employee_category:
                category = frappe.db.get_value(
                    'Employee Category', grade.karyo_employee_category,
                    ['employment_type', 'category_name'], as_dict=True,
                )
                if category:
                    fields.update({
                        'employment_type': category.employment_type,
                        'karyo_employment_category': grade.karyo_employee_category,
                        'karyo_employment_category_description': category.category_name,
                    })
    old = frappe.db.get_value('Employee', employee, list(fields), as_dict=True)
    if old and any(str(old.get(key) or '') != str(value or '') for key, value in fields.items()):
        frappe.db.set_value('Employee', employee, fields)
        from karyo.hr.self_service import notify_employee_request
        notify_employee_request(frappe._dict(doctype='Employee Salary Appointment', employee=employee,
                                           name=current.name if current else None))


def sync_current_appointments():
    for employee in frappe.get_all('Employee Salary Appointment', filters={'docstatus': 1}, pluck='employee', distinct=True):
        sync_employee(employee)


def resync_promoted_employee(doc, method=None):
    """Do not let the legacy Promotion CTC field override governed base salary."""
    if doc.get('employee'):
        sync_employee(doc.employee)


def validate_employee(doc, method=None):
    if doc.is_new():
        return
    current = approved_appointment(doc.name, nowdate())
    if current and current.pay_basis != 'PRB' and doc.grade != current.grade:
        frappe.throw(_('Grade is controlled by the approved salary appointment. Record a new effective-dated appointment to change it.'))
    expected = {'karyo_salary_appointment': current.name if current else None,
                'karyo_salary_scale': current.salary_scale if current else None,
                'karyo_scale_salary_point': cint(current.salary_point) if current else 0,
                'karyo_scale_basic_salary': current.basic_salary if current else 0,
                'ctc': current.basic_salary if current else (doc.get('karyo_prb_row3_salary') or 0),
                'karyo_salary_effective_from': current.effective_from if current else None}
    if doc.meta.has_field('karyo_hourly_rate'):
        rate = employee_hourly_rate_snapshot(
            doc, monthly_basic=current.basic_salary if current else None, work_pattern=doc.get('karyo_work_pattern')
        )
        expected.update({
            'karyo_hourly_rate': rate['hourly_rate'],
            'karyo_hourly_rate_calculation': rate['calculation'],
        })
    for key, value in expected.items():
        doc.set(key, value)


def sync_all_employee_hourly_rates():
    for employee in frappe.get_all('Employee', pluck='name', limit_page_length=0):
        sync_employee(employee)


def salary_history(employee):
    rows = frappe.get_all('Employee Salary Appointment', filters={'employee': employee, 'docstatus': ['in', [1, 2]]},
        fields=['name', 'pay_basis', 'grade', 'prb_grade', 'prb_salary_point',
                'salary_scale', 'salary_point', 'basic_salary', 'beyond_scale_authorized', 'currency', 'effective_from',
                'effective_to', 'docstatus', 'approved_by', 'approved_on'], order_by='effective_from desc, creation desc')
    return {'as_of': nowdate(), 'current': approved_appointment(employee, nowdate()), 'history': rows}


@frappe.whitelist()
def employee_salary(employee):
    require_admin()
    frappe.get_doc('Employee', employee).check_permission('read')
    return salary_history(employee)


@frappe.whitelist()
def my_salary():
    from karyo.hr.clocking import _own_employee
    employee = _own_employee(required=True)
    return salary_history(employee.name)


def from_appointment(run):
    """Resolve pay by calculation date; never confuse local points with PRB IDs."""
    current = approved_appointment(run.employee, run.calculation_date)
    if not current:
        return None
    if run.review_year and cint(run.review_year) != current.prb_year:
        frappe.throw(_('Payroll Review Year must match the approved salary appointment PRB Year.'))
    if run.increment_due:
        frappe.throw(_('Record and approve the new salary-point appointment before calculating an increment.'))
    run.karyo_salary_appointment = current.name
    rule = ('PRB-' + str(current.prb_year) + '/PHASE-' + str(current.prb_phase_percent)
            if current.pay_basis == 'PRB' else 'SALARY-SCALE/' + current.salary_scale)
    return {'amount': current.basic_salary, 'rule_ref': rule,
            'pay_basis': current.pay_basis, 'prb_salary_point': current.prb_salary_point,
            'phase_percentage': current.get('prb_phase_percent'),
            'appointment': current.name, 'grade': current.grade, 'salary_scale': current.salary_scale,
            'salary_point': current.salary_point, 'effective_from': str(current.effective_from)}
