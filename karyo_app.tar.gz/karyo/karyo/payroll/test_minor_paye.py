"""Minor PAYE acceptance tests using isolated, rollback-only payroll records."""
import unittest
from unittest.mock import patch
from uuid import uuid4

import frappe
from frappe.utils import flt

from karyo.desk.payroll_management import employee_payslip, employee_payslips, payslip, report_catalogue
from karyo.payroll.computation import apply_salary_slip_computation, salary_slip_computation
from karyo.payroll.process import calculate_cycle_statutory
from karyo.payroll.statutory import apply_cycle_results, review_cycle_results
from karyo.setup.workspace import create_reports


class TestMinorPAYE(unittest.TestCase):
	def setUp(self):
		self.original_user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("minor_paye_acceptance")
		self.mail = patch("frappe.sendmail"); self.mail.start()
		self.realtime = patch("frappe.publish_realtime"); self.realtime_mock = self.realtime.start()
		self.token = "minor-paye-qa-" + uuid4().hex[:10]
		self.user = self.token + "@example.invalid"
		self._insert({"doctype": "User", "name": self.user, "email": self.user,
			"first_name": "Minor PAYE QA", "enabled": 1, "user_type": "System User"})
		self._insert({"doctype": "Has Role", "parent": self.user, "parenttype": "User",
			"parentfield": "roles", "role": "Employee"})
		self.employee = self.token
		self.company = "MBC"
		self._insert({"doctype": "Employee", "name": self.employee, "employee_number": self.employee,
			"first_name": "Minor PAYE QA", "employee_name": "Minor PAYE QA", "user_id": self.user,
			"company": self.company, "status": "Active", "gender": "Male",
			"date_of_birth": "1985-01-01", "date_of_joining": "2020-01-01"})
		self.structure = frappe.copy_doc(frappe.get_doc("Salary Structure", "MAI Staff Structure"))
		self.structure.name = self.token + "-structure"
		self.structure.set("earnings", [r for r in self.structure.earnings if r.salary_component == "Basic"])
		self.structure.set("deductions", [r for r in self.structure.deductions if r.salary_component == "PAYE"])
		self.structure.docstatus = 1
		self._insert(self.structure)
		self.assignment = self._insert({"doctype": "Salary Structure Assignment", "name": self.token + "-assignment",
			"employee": self.employee, "company": self.company, "salary_structure": self.structure.name,
			"from_date": "2026-07-01", "base": 150000, "currency": "MUR", "docstatus": 1,
			"income_tax_slab": "Mauritius PAYE 2025-26"})
		self.edf = self._insert({"doctype": "Employee Tax Declaration", "name": self.token + "-edf",
			"employee": self.employee, "tax_year": "2026-2027-1", "company": self.company,
			"declaration_status": "Submitted", "docstatus": 1, "effective_from": "2026-07-01",
			"annual_iet": 0, "annual_reliefs": 0, "no_edf_rate_option": 15})
		# Native HRMS must see attendance for a real draft-slip rebuild.
		for day in range(1, 31):
			self._insert({"doctype": "Attendance", "name": f"{self.token}-att-{day}", "employee": self.employee,
				"company": self.company, "status": "Present", "attendance_date": f"2026-09-{day:02d}", "docstatus": 1})
		frappe.clear_cache(user=self.user)

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="minor_paye_acceptance")
		self.mail.stop(); self.realtime.stop()
		frappe.clear_cache(user=self.user)
		frappe.set_user(self.original_user)

	def _insert(self, values):
		doc = values if hasattr(values, "db_insert") else frappe.get_doc(values)
		doc.db_insert()
		for row in doc.get_all_children(): row.db_insert()
		return doc

	def _cycle(self, payroll_type="Minor", payment_date="2026-09-15", period=3):
		cycle = self._insert({"doctype": "Payroll Cycle", "name": self.token + "-" + uuid4().hex[:6],
			"company": self.company, "payroll_type": payroll_type, "pay_period_label": "September 2026 QA",
			"start_date": "2026-09-01", "end_date": "2026-09-30", "payment_date": payment_date,
			"paye_period_index": period, "status": "Processing", "currency": "MUR"})
		entry = self._insert({"doctype": "Payroll Entry", "name": cycle.name + "-entry",
			"company": self.company, "start_date": cycle.start_date, "end_date": cycle.end_date,
			"posting_date": payment_date, "karyo_payroll_cycle": cycle.name, "payroll_frequency": "Monthly",
			"currency": "MUR", "exchange_rate": 1,
			"employees": [{"employee": self.employee}]})
		cycle.db_set("payroll_entry", entry.name, update_modified=False)
		return cycle

	def _slip(self, cycle, amount, docstatus=0, period_start=None, period_end=None, tax=0):
		return self._insert({"doctype": "Salary Slip", "name": cycle.name + "-slip",
			"employee": self.employee, "employee_name": "Minor PAYE QA", "company": self.company,
			"salary_structure": self.structure.name, "payroll_frequency": "Monthly", "docstatus": docstatus,
			"start_date": period_start or cycle.start_date, "end_date": period_end or cycle.end_date,
			"posting_date": cycle.payment_date, "currency": "MUR", "exchange_rate": 1,
			"payroll_entry": cycle.payroll_entry, "karyo_payroll_cycle": cycle.name,
			"total_working_days": 30, "payment_days": 30, "gross_pay": amount,
			"total_deduction": tax, "net_pay": amount-tax,
			"earnings": [{"salary_component": "Basic", "amount": amount, "is_tax_applicable": 1}],
			"deductions": [{"salary_component": "PAYE", "amount": tax}]})

	def _history(self):
		for month, tax in ((7, 1153), (8, 1154)):
			cycle = self._cycle("Major", f"2026-{month:02d}-28")
			self._slip(cycle, 50000, 1, f"2026-{month:02d}-01", f"2026-{month:02d}-31", tax)

	def _process_minor(self):
		self._history()
		cycle = self._cycle()
		slip = self._slip(cycle, 150000)
		self._insert({"doctype": "Payroll Cycle Employee", "name": cycle.name + "-person",
			"payroll_cycle": cycle.name, "employee": self.employee, "salary_slip": slip.name,
			"status": "Salary Slip Created", "business_key": cycle.name + "|" + self.employee})
		result = calculate_cycle_statutory(cycle.name)
		self.assertEqual(result["failed"], [], result)
		self.assertEqual(result["processed"], 1)
		cycle.db_set("status", "Review", update_modified=False)
		self.assertEqual(review_cycle_results(cycle.name)["reviewed"], 1)
		cycle.db_set("status", "Approved", update_modified=False)
		apply_cycle_results(cycle.name)
		apply_cycle_results(cycle.name)
		slip.reload(); cycle.reload()
		return cycle, slip

	def test_minor_calculation_review_apply_and_repeat_reconcile(self):
		cycle, slip = self._process_minor()
		self.assertEqual(slip.gross_pay, 150000)
		self.assertEqual(slip.karyo_calculated_paye, 13077)
		self.assertEqual(slip.total_deduction, 13077)
		self.assertEqual(slip.net_pay, 136923)
		self.assertEqual(len([r for r in slip.deductions if r.salary_component == "PAYE"]), 1)
		self.assertEqual(cycle.paye_total, 13077)
		self.assertEqual(cycle.total_deductions, 13077)
		self.assertEqual(cycle.net_pay, 136923)
		self.assertEqual(frappe.db.count("Payroll Statutory Result", {"payroll_cycle": cycle.name, "result_type": "PAYE"}), 1)
		self.assertEqual(frappe.db.count("Additional Salary", {"karyo_payroll_cycle": cycle.name}), 0)
		self.assertTrue(any(
			call.args[:1] == ("karyo_employee_request_updated",)
			and call.args[1]["doctype"] == "Salary Slip"
			and call.kwargs.get("user") == self.user
			and call.kwargs.get("after_commit")
			for call in self.realtime_mock.mock_calls
		))

	def test_major_includes_minor_once_at_the_same_paye_position(self):
		cycle, minor = self._process_minor()
		frappe.db.set_value("Salary Slip", minor.name, "docstatus", 1, update_modified=False)
		major_cycle = self._cycle("Major", "2026-09-28")
		major = self._slip(major_cycle, 50000)
		calculation = apply_salary_slip_computation(major)
		self.assertEqual(calculation["previous_emoluments"], 250000)
		self.assertEqual(calculation["previous_paye"], 15384)
		self.assertEqual(calculation["paye_period_index"], 3)
		self.assertEqual(calculation["paye"], 10000)
		self.assertEqual(calculation["net_pay"], 40000)
		# A recalculated Minor must not absorb a later submitted Major payment.
		major.docstatus = 1; major.db_update()
		for row in major.deductions: row.db_update()
		self.assertEqual(salary_slip_computation(minor)["paye"], 13077)

	def test_split_month_threshold_with_and_without_edf(self):
		minor_cycle = self._cycle(payment_date="2026-09-15", period=1)
		minor = self._slip(minor_cycle, 20000)
		self.assertEqual(apply_salary_slip_computation(minor)["paye"], 0)
		minor.docstatus = 1; minor.db_update()
		major_cycle = self._cycle("Major", "2026-09-28", period=1)
		major = self._slip(major_cycle, 25000)
		with_edf = salary_slip_computation(major)
		self.assertEqual(with_edf["monthly_emoluments_for_threshold"], 45000)
		self.assertEqual(with_edf["paye"], 653)
		frappe.db.delete("Employee Tax Declaration", {"name": self.edf.name})
		self.assertEqual(salary_slip_computation(major)["paye"], 6750)

	def test_effective_round_down_and_fair_share_are_used_on_salary_slips(self):
		self._history()
		frappe.db.set_value("Employee Tax Declaration", self.edf.name, "annual_iet", 110000)
		# Expected October scenario: 204,000 income, 110,000 annual EDF, prior tax 1,223.07.
		frappe.db.set_value("Salary Detail", {"parentfield": "earnings", "parent": ("like", self.token + "%slip")}, "amount", 76500)
		frappe.db.set_value("Salary Detail", {"parentfield": "deductions", "parent": ("like", self.token + "%slip")}, "amount", 611.535)
		cycle = self._cycle(payment_date="2026-10-15", period=4)
		slip = self._slip(cycle, 51000)
		self.assertEqual(salary_slip_computation(slip)["paye"], 407)
		for row in slip.earnings: row.amount = 4000000
		calculation = salary_slip_computation(slip)
		self.assertGreater(calculation["fair_share_contribution"], 0)
		self.assertEqual(calculation["paye"], calculation["paye_engine"]["current_paye"])

	def test_no_edf_minor_and_major_do_not_duplicate_flat_tax_or_fair_share(self):
		frappe.db.delete("Employee Tax Declaration", {"name": self.edf.name})
		for minor_income, major_income, expected_minor, expected_major in (
			(100000, 50000, 15000, 7500),
			(4000000, 500000, 784615, 150000),
		):
			with self.subTest(minor_income=minor_income):
				frappe.db.savepoint("minor_no_edf_case")
				minor = self._slip(self._cycle(), minor_income)
				self.assertEqual(apply_salary_slip_computation(minor)["paye"], expected_minor)
				minor.docstatus = 1; minor.db_update()
				for row in minor.deductions: row.db_update()
				major = self._slip(self._cycle("Major", "2026-09-28"), major_income)
				first = salary_slip_computation(major)
				self.assertEqual(first["paye"], expected_major)
				self.assertEqual(salary_slip_computation(major)["paye"], expected_major)
				frappe.db.rollback(save_point="minor_no_edf_case")

	def test_flat_tax_round_down_and_director_threshold_exception(self):
		cycle = self._cycle()
		slip = self._slip(cycle, 40005)
		frappe.db.delete("Employee Tax Declaration", {"name": self.edf.name})
		self.assertEqual(salary_slip_computation(slip)["paye"], 6000)
		self._insert({"doctype": "Employee Tax Declaration", "name": self.token + "-director",
			"employee": self.employee, "tax_year": "2026-2027-1", "company": self.company,
			"declaration_status": "No EDF", "docstatus": 1, "effective_from": "2026-07-01",
			"emolument_type": "Director or Board Member Fees", "no_edf_rate_option": 15})
		for row in slip.earnings: row.amount = 104
		self.assertEqual(salary_slip_computation(slip)["paye"], 15)

	def test_minor_uses_edf_effective_on_payment_date_instead_of_month_end(self):
		frappe.db.set_value("Employee Tax Declaration", self.edf.name, "effective_from", "2026-09-20")
		minor = self._slip(self._cycle(), 150000)
		before_edf = salary_slip_computation(minor)
		self.assertIsNone(before_edf["source_declaration"])
		self.assertEqual(before_edf["paye"], 22500)
		major = self._slip(self._cycle("Major", "2026-09-28"), 150000)
		self.assertEqual(salary_slip_computation(major)["source_declaration"], self.edf.name)

	def test_dashboard_mapping_and_employee_access(self):
		cycle, slip = self._process_minor()
		hr = payslip(slip.name)
		frappe.set_user(self.user)
		ess = employee_payslip(slip.name)
		listed = next(r for r in employee_payslips(month="2026-09")["rows"] if r.name == slip.name)
		for result in (hr, ess, listed):
			self.assertEqual(result["payroll_type"], "Minor")
			self.assertEqual(result["payroll_cycle"], cycle.name)
			self.assertEqual(result["karyo_calculated_paye"], 13077)
			self.assertEqual(result["paye_amount"], 13077)
			self.assertEqual(result["net_pay"], 136923)
		frappe.set_user("Guest")
		with self.assertRaises(frappe.PermissionError): employee_payslip(slip.name)

	def test_dashboard_tax_uses_saved_deduction_when_legacy_audit_is_stale(self):
		cycle, slip = self._process_minor()
		frappe.db.set_value("Salary Slip", slip.name, "karyo_calculated_paye", 50000)
		self.assertEqual(payslip(slip.name)["paye_amount"], 13077)
		frappe.set_user(self.user)
		self.assertEqual(employee_payslip(slip.name)["paye_amount"], 13077)
		row = next(r for r in employee_payslips(month="2026-09")["rows"] if r.name == slip.name)
		self.assertEqual(row.paye_amount, 13077)

	def test_statutory_reports_include_minor_and_exclude_reversed(self):
		cycle, slip = self._process_minor()
		create_reports(["MBC PAYE Generated Detail", "MBC MRA Annual Return"])
		catalogue = {r["key"]: r for r in report_catalogue()}
		self.assertTrue(catalogue["paye_generated"]["runnable"])
		detail = frappe.get_doc("Report", "MBC PAYE Generated Detail")
		row = next(r for r in frappe.db.sql(detail.query, as_dict=True) if r["Cycle:Link/Payroll Cycle:150"] == cycle.name)
		self.assertEqual(row["Payroll Type::100"], "Minor")
		self.assertEqual(flt(row["Current PAYE:Currency:130"]), 13077)
		self.assertEqual(flt(row["Prior PAYE:Currency:130"]), 2307)
		frappe.db.set_value("Salary Slip", slip.name, "docstatus", 1, update_modified=False)
		annual = frappe.get_doc("Report", "MBC MRA Annual Return")
		row = next(r for r in frappe.db.sql(annual.query, as_dict=True) if r["Employee:Link/Employee:140"] == self.employee)
		self.assertEqual(row["Income Year::110"], "2026/2027")
		self.assertEqual(flt(row["PAYE Withheld:Currency:150"]), 15384)
		frappe.db.set_value("Payroll Statutory Result", {"payroll_cycle": cycle.name}, "status", "Reversed")
		self.assertFalse(any(r["Cycle:Link/Payroll Cycle:150"] == cycle.name for r in frappe.db.sql(detail.query, as_dict=True)))
