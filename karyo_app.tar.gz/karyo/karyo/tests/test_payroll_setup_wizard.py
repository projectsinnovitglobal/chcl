"""Regression coverage for the ordered Payroll Setup menu."""

import unittest
from unittest.mock import patch

from karyo.desk.payroll_screens import _setup_wizard
from karyo.payroll.screen_specs import SCREENS, SCREEN_DOCTYPES


class TestPayrollSetupWizard(unittest.TestCase):
	def _wizard(self, counts, grade_links=1):
		with patch("karyo.desk.payroll_screens._count", side_effect=lambda doctype, filters=None: counts.get(doctype, 0)), \
			patch("karyo.desk.payroll_screens.frappe.has_permission", return_value=True), \
			patch("karyo.desk.payroll_screens.frappe.db.count", return_value=grade_links), \
			patch("karyo.desk.payroll_screens._ready_payroll_employees", return_value=[]):
			return _setup_wizard("payrollsetup", SCREENS["payrollsetup"], {})

	def test_setup_menu_has_five_ordered_steps(self):
		counts = {doctype: 1 for doctype in SCREEN_DOCTYPES["payrollsetup"]}
		data = self._wizard(counts)

		self.assertEqual(SCREENS["payrollsetup"]["layout"], "setup_wizard")
		self.assertEqual([step["number"] for step in data["steps"]], [1, 2, 3, 4, 5])
		self.assertTrue(data["all_complete"])
		self.assertEqual(data["completed"], 5)
		self.assertTrue(all(step["available"] for step in data["steps"]))
		self.assertEqual(data["ready_employees"], [])
		links = [link for step in data["steps"] for link in step["links"]]
		self.assertTrue(all(link.get("doctype") or link.get("direct") for link in links))
		self.assertTrue(all(link.get("doctype") for link in links if not link.get("direct")))
		appointment_links = [link for link in links if link.get("doctype") == "Employee Salary Appointment"]
		self.assertEqual(len(appointment_links), 1)
		self.assertEqual(appointment_links[0].get("screen"), "master-employee-salary-appointment")
		self.assertEqual(
			{link["doctype"] for link in links if link.get("doctype")},
			{
				"Company", "Payroll Type", "Employee Payroll Group", "Pay Day", "Salary Increment Band", "Salary Scale",
				"Employee Grade", "Salary Scale Step", "Payroll PDB Type", "Payroll PDB Code",
				"Payroll Operation Code", "Salary Structure",
				"Payroll Contribution Scheme", "Payroll Compensation Scheme", "Payroll PAYE Year",
				"Bank", "Payroll Bank Branch", "Employee Salary Appointment",
				"Salary Structure Assignment", "Employee",
			},
		)

	def test_next_step_waits_for_current_dependencies(self):
		counts = {doctype: 1 for doctype in SCREEN_DOCTYPES["payrollsetup"]}
		data = self._wizard(counts, grade_links=0)
		steps = data["steps"]

		self.assertTrue(steps[0]["complete"])
		self.assertTrue(steps[1]["available"])
		self.assertTrue(steps[1]["current"])
		self.assertIn("Grade-to-scale links", steps[1]["missing"])
		self.assertTrue(all(not step["available"] for step in steps[2:]))
		self.assertTrue(all(not step["complete"] for step in steps[2:]))
		self.assertTrue(all("Complete Step 2" in step["guidance"] for step in steps[2:]))

	def test_first_incomplete_step_is_actionable(self):
		counts = {doctype: 1 for doctype in SCREEN_DOCTYPES["payrollsetup"]}
		counts["Payroll Type"] = 0
		data = self._wizard(counts)

		self.assertTrue(data["steps"][0]["available"])
		self.assertTrue(data["steps"][0]["current"])
		self.assertFalse(data["steps"][1]["available"])
		self.assertIn("Active payroll types", data["steps"][0]["guidance"])
