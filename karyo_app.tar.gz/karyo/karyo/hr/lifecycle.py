"""Cross-document controls for employee promotion, transfer and separation."""

from __future__ import annotations

import frappe
from frappe import _
from frappe.utils import add_days, cint, flt, getdate


PROMOTION_REFERENCE_PREFIX = "Employee Promotion "


def _property_change(doc, fieldname):
	rows = doc.get("promotion_details") or doc.get("transfer_details") or []
	return next((row for row in rows if row.get("fieldname") == fieldname), None)


def prepare_employee_transfer(doc, method=None):
	"""The source company always comes from the selected employee."""
	if not doc.get("employee"):
		return
	company = frappe.db.get_value("Employee", doc.employee, "company")
	if company:
		doc.company = company
	prepare_employee_promotion_salary(doc)


def prepare_employee_transfer_submission(doc, method=None):
	"""Clear a Section when the transfer moves outside its mapped scope."""
	prepare_employee_transfer(doc)
	if doc.get('employee'):
		prepare_employee_promotion(doc)


def _promotion_grade(doc):
	change = _property_change(doc, "grade")
	if change:
		return change.get("new")
	if cint(doc.get('beyond_scale_authorized')):
		return doc.get('karyo_new_grade') or frappe.db.get_value('Employee', doc.employee, 'grade')
	if doc.get('karyo_new_grade') and doc.get('karyo_new_salary_point'):
		from karyo.payroll.salary_scales import approved_appointment
		current = approved_appointment(doc.employee, doc.get('promotion_date') or doc.get('transfer_date'))
		if current and cint(doc.karyo_new_salary_point) != cint(current.salary_point):
			return doc.karyo_new_grade
	return None


def _promotion_appointment_reference(name):
	return f"{PROMOTION_REFERENCE_PREFIX}{name}"


def _promotion_salary_details(employee, promotion_date, target_grade=None):
	from karyo.payroll.salary_scales import allocation_options, approved_appointment

	effective_from = getdate(promotion_date)
	current = approved_appointment(employee, effective_from)
	details = {
		"current": current,
		"current_basic_salary": flt(current.basic_salary, 2) if current else 0,
		"current_salary_point": cint(current.salary_point) if current and current.pay_basis != "PRB" else None,
		"points": [],
		"effective_to": None,
	}
	if not target_grade:
		return details
	allocation = allocation_options(target_grade, effective_from)
	options = allocation.get("points") or []
	details["allocation"] = allocation
	details["effective_to"] = allocation.get("effective_to")
	details["points"] = [
		{"salary_point": cint(row.get("salary_point")), "basic_salary": flt(row.get("salary"), 2)}
		for row in options
	]
	return details


@frappe.whitelist()
def promotion_salary_options(employee, promotion_date, grade=None, doctype="Employee Promotion"):
	"""Return only governed basic-salary choices for the promotion form."""
	if doctype not in ("Employee Promotion", "Employee Transfer") or not frappe.has_permission(doctype, "write"):
		frappe.throw(_("Not permitted to prepare this employee movement."), frappe.PermissionError)
	frappe.get_doc("Employee", employee).check_permission("read")
	details = _promotion_salary_details(employee, promotion_date, grade)
	return {
		"current_basic_salary": details["current_basic_salary"],
		"current_salary_point": details["current_salary_point"],
		"points": details["points"],
		"allocation": details.get("allocation"),
	}


def prepare_employee_promotion_salary(doc, method=None):
	"""Derive movement salary from its scale and explicit long-service authority."""
	if doc.docstatus == 2 or not doc.get('employee'):
		return
	from karyo.hr.employee_movements import prepare
	from karyo.payroll.salary_scales import governed_scale_amount, grade_scale, employee_hourly_rate_snapshot
	prepare(doc)
	date = doc.get('promotion_date') or doc.get('transfer_date')
	if not date:
		return
	target_grade = _promotion_grade(doc)
	details = _promotion_salary_details(doc.employee, date, target_grade)
	doc.current_ctc = details['current_basic_salary']
	if not target_grade:
		doc.revised_ctc = 0
		doc.karyo_salary_display = details['current_basic_salary']
		current = details.get('current')
		doc.karyo_salary_scale = current.salary_scale if current else None
		doc.karyo_rate = employee_hourly_rate_snapshot(doc.employee, date=date, monthly_basic=doc.karyo_salary_display)['hourly_rate']
		return
	allocation = details['allocation']
	doc.karyo_salary_scale = allocation['salary_scale']
	selected = str(doc.get('karyo_new_salary_point') or '').strip()
	if not allocation['flat_salary'] and not any(str(row['salary_point']) == selected for row in details['points']):
		doc.revised_ctc = doc.karyo_salary_display = 0
		return
	_, scale = grade_scale(target_grade, date)
	doc.revised_ctc = governed_scale_amount(scale, selected, doc)
	doc.karyo_salary_display = doc.revised_ctc
	doc.karyo_rate = employee_hourly_rate_snapshot(doc.employee, date=date, monthly_basic=doc.revised_ctc)['hourly_rate']


def prepare_employee_promotion(doc, method=None):
	"""Create the effective-dated salary appointment required by a Grade promotion."""
	prepare_employee_promotion_salary(doc)
	target_grade = _promotion_grade(doc)
	if not doc.get("employee"):
		return
	if not target_grade:
		# A designation-only promotion must leave the existing grade scale and
		# salary point untouched for the next EOY increment process.
		doc.revised_ctc = 0
		return

	from karyo.payroll.salary_scales import approved_appointment

	effective_from = getdate(doc.get('promotion_date') or doc.get('transfer_date'))
	current = approved_appointment(doc.employee, effective_from)
	if not current and doc.get("karyo_appointment_type") != "Appointment":
		frappe.throw(_(
			"Select Appointment to create an initial salary allocation, or approve the current Salary Appointment before a promotion or transfer."
		))
	if current and current.pay_basis == "PRB":
		frappe.throw(_(
			"A PRB-based employee cannot be moved to a Grade Scale through Employee Promotion. Create the required Salary Appointment instead."
		))
	if current and current.grade == target_grade and not cint(doc.get('beyond_scale_authorized')) and cint(doc.get('karyo_new_salary_point')) == cint(current.salary_point):
		frappe.throw(_("Select a different Grade for a grade promotion."))
	if current and getdate(current.effective_from) == effective_from:
		frappe.throw(_(
			"The current Salary Appointment starts on the Promotion Date. Amend that appointment before submitting the promotion."
		))

	if not frappe.has_permission("Employee Salary Appointment", "submit"):
		frappe.throw(_("Salary Appointment approval permission is required to change salary through a movement."), frappe.PermissionError)
	current_doc = frappe.get_doc("Employee Salary Appointment", current.name) if current else None
	details = _promotion_salary_details(doc.employee, effective_from, target_grade)
	allocation = details['allocation']
	point = next((row for row in details['points']
		if str(row['salary_point']) == str(doc.get('karyo_new_salary_point') or '').strip()), None)
	if not point and not allocation['flat_salary']:
		frappe.throw(_('Select a Salary Point from the approved salary scale for Grade {0}.').format(target_grade))
	if doc.doctype == 'Employee Transfer' and (doc.get('create_new_employee_id') or (doc.get('new_company') and doc.new_company != doc.company)):
		frappe.throw(_('Complete the company transfer first, then create a Salary Appointment for the target employee.'))

	if current_doc:
		doc.karyo_previous_salary_appointment = current_doc.name
		doc.karyo_previous_salary_effective_to = current_doc.effective_to
		current_doc.effective_to = add_days(effective_from, -1)
		current_doc.flags.ignore_permissions = True
		# Derived display fields can change while only the closing date is edited.
		current_doc.flags.ignore_validate_update_after_submit = True
		current_doc.save()

	appointment_ends = [
		getdate(value) for value in (doc.karyo_previous_salary_effective_to, details["effective_to"], doc.get("karyo_end_date"))
		if value
	]
	appointment = frappe.get_doc({
		"doctype": "Employee Salary Appointment",
		"employee": doc.employee,
		"appointment_type": doc.get("karyo_appointment_type") or ("Promotion" if doc.doctype == "Employee Promotion" else "Transfer"),
		"pay_basis": "Grade Scale",
		"grade": target_grade,
		"effective_from": effective_from,
		"effective_to": min(appointment_ends) if appointment_ends else None,
		"salary_point": cint(point["salary_point"]) if point else None,
		"basic_salary": doc.revised_ctc,
		"beyond_scale_authorized": cint(doc.get("beyond_scale_authorized")),
		"beyond_scale_salary": doc.get("beyond_scale_salary"),
		"beyond_scale_authority": doc.get("beyond_scale_authority"),
		"beyond_scale_reason": doc.get("beyond_scale_reason"),
		"salary_structure": doc.get("karyo_salary_structure") or (current_doc.salary_structure if current_doc else allocation.get("default_salary_structure")),
		"income_tax_slab": doc.get("karyo_income_tax_slab") or (current_doc.income_tax_slab if current_doc else None),
		"authority_reference": f"{doc.doctype} {doc.name}",
		"notes": doc.get("karyo_movement_remarks") or _("Created automatically from {0} {1}.").format(doc.doctype, doc.name),
	})
	appointment.flags.ignore_permissions = True
	appointment.insert(ignore_permissions=True)
	appointment.flags.ignore_permissions = True
	appointment.submit()
	doc.karyo_salary_appointment = appointment.name


def restore_employee_promotion_appointment(doc, method=None):
	"""Reverse an automatically-created appointment before the Promotion controller runs."""
	appointment_name = doc.get("karyo_salary_appointment") or frappe.db.get_value(
		"Employee Salary Appointment",
		{"authority_reference": f"{doc.doctype} {doc.name}", "docstatus": 1},
		"name",
	)
	if appointment_name and frappe.db.exists("Employee Salary Appointment", appointment_name):
		# Remove the audit link first so Frappe's backlink guard permits the
		# appointment cancellation inside this same Promotion cancellation.
		doc.karyo_salary_appointment = None
		frappe.db.set_value(
			doc.doctype, doc.name, "karyo_salary_appointment", None, update_modified=False
		)
		appointment = frappe.get_doc("Employee Salary Appointment", appointment_name)
		if appointment.docstatus == 1:
			appointment.flags.ignore_permissions = True
			appointment.cancel()

	previous_name = doc.get("karyo_previous_salary_appointment")
	if previous_name and frappe.db.exists("Employee Salary Appointment", previous_name):
		previous = frappe.get_doc("Employee Salary Appointment", previous_name)
		if previous.docstatus == 1:
			previous.effective_to = doc.get("karyo_previous_salary_effective_to") or None
			previous.flags.ignore_permissions = True
			previous.save()


def disable_employee_user(employee_name):
	user = frappe.db.get_value("Employee", employee_name, "user_id")
	if not user or user in ("Administrator", "Guest") or not frappe.db.exists("User", user):
		return None
	if frappe.db.get_value("User", user, "enabled"):
		user_doc = frappe.get_doc("User", user)
		user_doc.enabled = 0
		user_doc.flags.ignore_permissions = True
		user_doc.save(ignore_permissions=True)

	# User.save clears sessions during normal web requests. The after-commit
	# callback also covers background/API submissions without a LoginManager.
	from frappe.sessions import clear_sessions

	frappe.db.after_commit.add(lambda user=user: clear_sessions(user=user, force=True))
	return user


def restore_employee_user(employee_name, was_enabled):
	if not cint(was_enabled):
		return
	user = frappe.db.get_value("Employee", employee_name, "user_id")
	if not user or user in ("Administrator", "Guest") or not frappe.db.exists("User", user):
		return
	if not frappe.db.get_value("User", user, "enabled"):
		user_doc = frappe.get_doc("User", user)
		user_doc.enabled = 1
		user_doc.flags.ignore_permissions = True
		user_doc.save(ignore_permissions=True)
