import json
from datetime import datetime, time

import frappe
from frappe import _
from frappe.utils import getdate


SENSITIVE_PARTS = ("password", "secret", "token", "api_key", "private_key")


def execute(filters=None):
	filters = frappe._dict(filters or {})
	frappe.has_permission("Version", "read", throw=True)
	rows = _data(filters)
	return _columns(), rows, None, None, [
		{"label": _("Audit events"), "value": len(rows), "indicator": "Blue", "datatype": "Int"}
	]


def _data(filters):
	conditions = {}
	if filters.get("ref_doctype"):
		conditions["ref_doctype"] = filters.ref_doctype
	if filters.get("document_name"):
		conditions["docname"] = filters.document_name
	if filters.get("changed_by"):
		conditions["owner"] = filters.changed_by
	if filters.get("from_date") and filters.get("to_date"):
		conditions["creation"] = ["between", [_day_start(filters.from_date), _day_end(filters.to_date)]]
	elif filters.get("from_date"):
		conditions["creation"] = [">=", _day_start(filters.from_date)]
	elif filters.get("to_date"):
		conditions["creation"] = ["<=", _day_end(filters.to_date)]

	versions = frappe.get_list(
		"Version",
		filters=conditions,
		fields=["name", "ref_doctype", "docname", "owner", "creation", "data"],
		order_by="creation desc",
		limit_page_length=1000,
	)
	result = []
	for version in versions:
		if not _can_read(version.ref_doctype):
			continue
		result.extend(_events(version))
	action = filters.get("action")
	return [row for row in result if not action or row["action"] == action]


def _events(version):
	try:
		data = json.loads(version.data or "{}")
	except (TypeError, ValueError):
		data = {}
	base = {
		"changed_at": version.creation,
		"changed_by": version.owner,
		"ref_doctype": version.ref_doctype,
		"document_name": version.docname,
		"version": version.name,
		"reason": data.get("comment") or "",
	}
	rows = []
	for change in data.get("changed") or []:
		if len(change) < 3:
			continue
		rows.append({**base, "action": "Changed", "field_or_row": change[0],
			"old_value": _safe_value(change[0], change[1]), "new_value": _safe_value(change[0], change[2])})
	for key, label in (("added", "Row added"), ("removed", "Row removed")):
		for item in data.get(key) or []:
			fieldname = item[0] if isinstance(item, (list, tuple)) and item else ""
			value = item[1] if isinstance(item, (list, tuple)) and len(item) > 1 else item
			rows.append({**base, "action": label, "field_or_row": fieldname,
				"old_value": _safe_value(fieldname, value) if key == "removed" else "",
				"new_value": _safe_value(fieldname, value) if key == "added" else ""})
	for item in data.get("row_changed") or []:
		if not isinstance(item, (list, tuple)) or len(item) < 3:
			continue
		child_field, row_name, changes = item[0], item[1], item[2]
		for change in changes or []:
			if len(change) < 3:
				continue
			fieldname = f"{child_field} / {row_name} / {change[0]}"
			rows.append({**base, "action": "Row changed", "field_or_row": fieldname,
				"old_value": _safe_value(change[0], change[1]), "new_value": _safe_value(change[0], change[2])})
	return rows or [{**base, "action": "Changed", "field_or_row": "Document",
		"old_value": "", "new_value": "Updated"}]


def _safe_value(fieldname, value):
	if any(part in (fieldname or "").lower() for part in SENSITIVE_PARTS):
		return "••••••"
	if isinstance(value, (dict, list, tuple)):
		return frappe.as_json(value)
	return "" if value is None else str(value)


def _can_read(doctype):
	try:
		return bool(doctype and frappe.has_permission(doctype, "read"))
	except Exception:
		return False


def _day_start(value):
	return datetime.combine(getdate(value), time.min)


def _day_end(value):
	return datetime.combine(getdate(value), time.max)


def _columns():
	return [
		{"fieldname": "changed_at", "label": _("Changed At"), "fieldtype": "Datetime", "width": 155},
		{"fieldname": "changed_by", "label": _("Changed By"), "fieldtype": "Link", "options": "User", "width": 155},
		{"fieldname": "ref_doctype", "label": _("Reference Type"), "fieldtype": "Link", "options": "DocType", "width": 155},
		{"fieldname": "document_name", "label": _("Reference"), "fieldtype": "Dynamic Link", "options": "ref_doctype", "width": 170},
		{"fieldname": "action", "label": _("Action"), "fieldtype": "Data", "width": 105},
		{"fieldname": "field_or_row", "label": _("Field / Row"), "fieldtype": "Data", "width": 190},
		{"fieldname": "old_value", "label": _("Old Value"), "fieldtype": "Small Text", "width": 220},
		{"fieldname": "new_value", "label": _("New Value"), "fieldtype": "Small Text", "width": 220},
		{"fieldname": "reason", "label": _("Reason"), "fieldtype": "Small Text", "width": 180},
	]
