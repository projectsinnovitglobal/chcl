"""Employee accommodations supplement the category and shift attendance rules."""
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	create_custom_fields({
		"Employee": [
			{"fieldname": "karyo_attendance_grace_section", "fieldtype": "Section Break",
			 "label": "Attendance Grace", "insert_after": "karyo_leave_block_list"},
			{"fieldname": "karyo_override_attendance_grace", "fieldtype": "Check", "default": "0",
			 "label": "Override Category / Shift Grace", "insert_after": "karyo_attendance_grace_section",
			 "description": "Individual grace takes priority over Employee Category and Shift Type. When disabled, the active category's override applies, otherwise the shift default. Changes apply when attendance is processed; approved lateness remains an audit snapshot."},
			{"fieldname": "karyo_start_grace_minutes", "fieldtype": "Float", "default": "0",
			 "label": "Start Grace (minutes)", "insert_after": "karyo_override_attendance_grace",
			 "depends_on": "eval:doc.karyo_override_attendance_grace"},
			{"fieldname": "karyo_end_grace_minutes", "fieldtype": "Float", "default": "0",
			 "label": "End Grace (minutes)", "insert_after": "karyo_start_grace_minutes",
			 "depends_on": "eval:doc.karyo_override_attendance_grace"},
		],
		"Attendance": [
			{"fieldname": "karyo_grace_source", "fieldtype": "Data", "read_only": 1,
			 "label": "Grace Source", "insert_after": "karyo_early_exit_grace_minutes"},
		],
	}, update=True)


setup = apply
