"""Approved, effective-dated PRB conversions with atomic employee/payroll mapping."""
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, cint, getdate, now_datetime, nowdate

from karyo.payroll.salary_scales import (
    END, _assignment_at, approved_appointment, prb_allocation, sync_employee,
)


def require_manager():
    if not {'System Manager', 'HR Manager'}.intersection(frappe.get_roles()):
        frappe.throw(_('Only an HR Manager or System Manager can apply PRB changes.'), frappe.PermissionError)


def source_mapping(employee, date):
    current = approved_appointment(employee.name, add_days(date, -1))
    if current:
        if current.pay_basis != 'PRB':
            frappe.throw(_('Employee has a Grade Scale appointment. Review the pay basis before PRB conversion.'))
        return current.prb_grade, str(current.prb_salary_point), cint(current.prb_year)
    if frappe.db.exists('Employee Salary Appointment', {'employee': employee.name,
            'docstatus': ['in', [1, 2]], 'effective_from': ['<=', date]}):
        frappe.throw(_('Salary appointment history has a gap or an appointment starts on the change date. Resolve it first.'))
    return employee.karyo_prb_grade, str(employee.karyo_prb_salary_point or ''), None


def conversion(revision, employee):
    grade, point, year = source_mapping(employee, revision.effective_from)
    if year and year != cint(revision.source_review_year):
        frappe.throw(_('Existing appointment review year does not match this PRB change.'))
    rules = [row for row in revision.mappings if row.from_grade == grade and str(row.from_point) == point]
    if len(rules) != 1:
        frappe.throw(_('No unique conversion rule for existing grade {0}, point {1}.').format(grade or 'Missing', point or 'Missing'))
    rule = rules[0]
    allocation = prb_allocation(rule.to_grade, rule.to_point, employee.company,
        revision.effective_from, review_year=revision.review_year)
    return rule, allocation


class PRBSalaryRevision(Document):
    def validate(self):
        if cint(self.source_review_year) < 1900 or cint(self.review_year) < cint(self.source_review_year):
            frappe.throw(_('Select valid existing and revised review years.'))
        if not self.mappings:
            frappe.throw(_('Enter the official grade and salary point conversion mappings.'))
        seen = set()
        from karyo.setup.payroll_profiles import _point_in_grade, prb_salary_value
        for row in self.mappings:
            row.from_point = str(row.from_point or '').strip()
            row.to_point = str(row.to_point or '').strip()
            key = (row.from_grade, row.from_point)
            if key in seen:
                frappe.throw(_('Duplicate conversion rule for {0}, point {1}.').format(*key))
            seen.add(key)
            if (not _point_in_grade(row.from_point, row.from_grade)
                    or prb_salary_value(row.from_point, self.source_review_year) is None):
                frappe.throw(_('Existing grade/point is invalid for the source review year.'))
            prb_allocation(row.to_grade, row.to_point, self.company, self.effective_from,
                review_year=self.review_year)
        if not self.docstatus:
            self.status = 'Draft'
            self.set('results', [])
            self.applied_count = self.blocked_count = 0

    def before_submit(self):
        require_manager()
        if not self.official_rules_confirmed:
            frappe.throw(_('Verify the official conversion rules before submitting this PRB change.'))
        frappe.db.sql('select name from `tabCompany` where name=%s for update', (self.company,))
        conflicts = frappe.get_all('PRB Salary Revision', filters={'company': self.company,
            'effective_from': self.effective_from, 'docstatus': 1}, pluck='name')
        if conflicts:
            frappe.throw(_('Another submitted PRB change exists for this company and effective date: {0}.').format(conflicts[0]))
        self.set('results', [])
        self.applied_count = self.blocked_count = 0
        self.last_checked_on = None
        self.status = 'Scheduled'

    def before_update_after_submit(self):
        frappe.throw(_('Approved PRB conversion rules and results cannot be edited. Use Apply / Retry Due Change to refresh results.'))

    def on_submit(self):
        if getdate(self.effective_from) <= getdate(nowdate()):
            apply_revision(self.name)

    def before_cancel(self):
        require_manager()
        if self.applied_count:
            frappe.throw(_('Applied PRB changes cannot be cancelled. Create a new approved revision to preserve salary history.'))
        self.status = 'Cancelled'


def _apply_employee(revision, employee, rule, allocation):
    date = getdate(revision.effective_from)
    employee.check_permission('write')
    if employee.relieving_date and getdate(employee.relieving_date) < date:
        frappe.throw(_('Employee has left before the PRB effective date.'))
    current = approved_appointment(employee.name, add_days(date, -1))
    end = current.effective_to if current else employee.relieving_date
    if employee.relieving_date:
        end = min(getdate(end or END), getdate(employee.relieving_date))
    end = getdate(end or END)
    # Posted payroll remains immutable, including a slip spanning the boundary.
    if frappe.db.exists('Salary Slip', {'employee': employee.name, 'docstatus': 1,
            'end_date': ['>=', date], 'start_date': ['<=', end]}):
        frappe.throw(_('Submitted Salary Slips cover the revision period. Resolve them before retrying.'))
    if frappe.db.exists('PRB Payroll Run', {'employee': employee.name, 'docstatus': ['<', 2],
            'calculation_date': ['between', [date, end]]}):
        frappe.throw(_('Existing PRB Payroll Runs cover the revision period. Cancel or recalculate them before retrying.'))
    native = _assignment_at(employee.name, date)
    structure = current and frappe.get_doc('Employee Salary Appointment', current.name).salary_structure
    structure = structure or (native and native.salary_structure)
    if not structure:
        frappe.throw(_('No submitted payroll Salary Structure Assignment is available. Complete payroll setup first.'))
    if current and getdate(current.effective_to or END) >= date:
        old = frappe.get_doc('Employee Salary Appointment', current.name)
        old.effective_to = add_days(date, -1)
        old.flags.prb_revision_closing = True
        old.save()
        # Remove only old future phase assignments; historical bases stay intact.
        for name in frappe.get_all('Salary Structure Assignment', filters={'employee': employee.name,
                'docstatus': 1, 'karyo_salary_appointment': old.name, 'from_date': ['>=', date]}, pluck='name'):
            assignment = frappe.get_doc('Salary Structure Assignment', name)
            assignment.flags.ignore_permissions = True
            assignment.cancel()
    appointment = frappe.get_doc({
        'doctype': 'Employee Salary Appointment', 'employee': employee.name,
        'pay_basis': 'PRB', 'appointment_type': 'Salary Change',
        'prb_grade': rule.to_grade, 'prb_salary_point': rule.to_point,
        'prb_year': revision.review_year,
        'effective_from': date, 'effective_to': None if end == getdate(END) else end,
        'salary_structure': structure, 'income_tax_slab': native and native.income_tax_slab,
        'authority_reference': revision.source_reference,
        'notes': 'Automatic PRB change: {0}; conversion rule: {1}; {2}/{3} → {4}/{5}'.format(
            revision.name, rule.rule_reference, rule.from_grade, rule.from_point, rule.to_grade, rule.to_point),
    }).insert().submit()
    sync_employee(employee.name)
    return appointment


@frappe.whitelist(methods=['POST'])
def apply_revision(name):
    require_manager()
    revision = frappe.get_doc('PRB Salary Revision', name)
    revision.check_permission('submit')
    if revision.docstatus != 1:
        frappe.throw(_('Submit the approved PRB change first.'))
    if getdate(revision.effective_from) > getdate(nowdate()):
        return {'status': revision.status, 'applied': 0, 'blocked': 0, 'message': 'Waiting for effective date'}
    frappe.db.sql('select name from `tabPRB Salary Revision` where name=%s for update', (name,))
    revision.reload()
    previous = {row.employee: row for row in revision.results}
    employees = frappe.get_all('Employee', filters={'company': revision.company,
        'status': 'Active', 'karyo_prb_opted_in': 1}, pluck='name', order_by='name', limit_page_length=0)
    for index, employee_name in enumerate(employees):
        row = previous.get(employee_name)
        if row and row.status == 'Applied':
            continue
        if not row:
            row = revision.append('results', {'employee': employee_name})
        savepoint = 'prb_revision_employee_{0}'.format(index)
        frappe.db.savepoint(savepoint)
        try:
            frappe.db.sql('select name from `tabEmployee` where name=%s for update', (employee_name,))
            employee = frappe.get_doc('Employee', employee_name)
            if employee.status != 'Active' or not employee.karyo_prb_opted_in:
                frappe.throw(_('Employee is no longer an active PRB participant.'))
            rule, allocation = conversion(revision, employee)
            row.update({'from_grade': rule.from_grade, 'from_point': rule.from_point,
                'to_grade': rule.to_grade, 'to_point': rule.to_point, 'basic_salary': allocation['basic_salary']})
            appointment = _apply_employee(revision, employee, rule, allocation)
            row.update({'status': 'Applied', 'appointment': appointment.name,
                'salary_structure_assignment': appointment.salary_structure_assignment,
                'detail': 'Employee profile, effective salary history and payroll base synchronized.'})
        except Exception as error:
            frappe.db.rollback(save_point=savepoint)
            row.update({'status': 'Blocked', 'appointment': None, 'salary_structure_assignment': None,
                'detail': frappe.utils.strip_html(str(error))})
    revision.applied_count = sum(row.status == 'Applied' for row in revision.results)
    revision.blocked_count = sum(row.status == 'Blocked' for row in revision.results)
    revision.status = 'Partially Applied' if revision.blocked_count else 'Applied'
    revision.last_checked_on = now_datetime()
    # Only governed runtime fields are persisted; approved rules remain immutable.
    for row in revision.results:
        if frappe.db.exists('PRB Salary Revision Result', row.name):
            row.db_update()
        else:
            row.db_insert()
    revision.db_set({'status': revision.status, 'applied_count': revision.applied_count,
        'blocked_count': revision.blocked_count, 'last_checked_on': revision.last_checked_on})
    return {'status': revision.status, 'applied': revision.applied_count, 'blocked': revision.blocked_count}


def apply_due_revisions():
    """Scheduler retries blocked employees; successful results are idempotent."""
    previous_user = frappe.session.user
    frappe.set_user('Administrator')
    try:
        for name in frappe.get_all('PRB Salary Revision', filters={'docstatus': 1,
                'status': ['in', ['Scheduled', 'Partially Applied']],
                'effective_from': ['<=', nowdate()]}, pluck='name', order_by='effective_from asc, creation asc'):
            savepoint = 'prb_revision_job'
            frappe.db.savepoint(savepoint)
            try:
                apply_revision(name)
            except Exception:
                frappe.db.rollback(save_point=savepoint)
                frappe.log_error(title='PRB auto-assignment failed: ' + name, message=frappe.get_traceback())
    finally:
        frappe.set_user(previous_user)
