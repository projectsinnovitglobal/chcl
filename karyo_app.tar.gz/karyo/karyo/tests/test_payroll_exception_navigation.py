import unittest
from uuid import uuid4
import frappe
from karyo.desk.payroll_screens import _wizard, payslip_period_options
from karyo.payroll.screen_specs import SCREENS
from karyo.desk.payroll_management import screen_data
from karyo.payroll.completion import readiness_exception_details

class TestPayrollExceptionNavigation(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('exception_navigation_test')
    def tearDown(self):
        frappe.db.rollback(save_point='exception_navigation_test')
        frappe.set_user(self.user)
    def test_wizard_period_values_and_scoped_pay_days(self):
        options = payslip_period_options()
        for option in options:
            data = screen_data('process', payroll_period=option['key'], pay_day='invalid-day')
            self.assertEqual(data['cycles'], options)
            self.assertEqual(data['period_context'], option)
            for day in data['pay_days']:
                self.assertEqual(day.name, option['pay_day'])
                self.assertGreaterEqual(day.start_date, option['start_date'])
                self.assertLessEqual(day.end_date, option['end_date'])
            if data['cycle']:
                self.assertIn(data['selected_pay_day'], [d.name for d in data['pay_days']])
    def test_exception_details_restrict_cycle_code_status_and_permission(self):
        cycle = frappe.db.get_value('Payroll Cycle', {'docstatus': 0}, 'name')
        code = 'TEST-' + uuid4().hex
        for suffix, status, validation in [('-open','Open',code),('-resolved','Resolved',code),('-other','Open',code+'other')]:
            frappe.get_doc({'doctype':'Payroll Readiness Exception','name':code+suffix,'payroll_cycle':cycle,
                'validation_code':validation,'status':status,'severity':'Blocking','message':'Correct test record',
                'fingerprint':code+suffix,'remediation_doctype':'Employee','remediation_name':'MBC/HR/00001'}).db_insert()
        rows = readiness_exception_details(cycle, code)
        self.assertEqual([r.name for r in rows], [code+'-open'])
        self.assertEqual(rows[0].remediation_name, 'MBC/HR/00001')
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            readiness_exception_details(cycle, code)
