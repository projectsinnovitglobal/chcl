"""Payroll Cycle statutory calculation orchestration and persistence."""

import hashlib
import json

import frappe
from frappe import _
from frappe.utils import cint, flt, now_datetime

from karyo.payroll.contributions import calculate_contribution
from karyo.payroll.governance import configured_role, has_actor_role
from karyo.payroll.paye import calculate_employee_paye
from karyo.payroll.currency import company_currency


def _canonical(value):
	return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _save_result(identity, inputs, outputs, values):
	business_key = "|".join(
		(identity["payroll_cycle"], identity["employee"], identity["result_type"], identity["rule_reference"])
	)
	digest = hashlib.sha256(f"{_canonical(inputs)}|{_canonical(outputs)}".encode()).hexdigest()
	name = frappe.db.get_value("Payroll Statutory Result", {"business_key": business_key}, "name")
	if not name and identity["result_type"] == "PAYE":
		# A cycle has exactly one PAYE result per employee.  This fallback lets a
		# legacy custom-PAYE result be migrated to its Income Tax Slab identity
		# without leaving a second tax result behind.
		name = frappe.db.get_value(
			"Payroll Statutory Result",
			{
				"payroll_cycle": identity["payroll_cycle"],
				"employee": identity["employee"],
				"result_type": "PAYE",
				"status": ("!=", "Reversed"),
			},
			"name",
		)
	doc = frappe.get_doc("Payroll Statutory Result", name) if name else frappe.new_doc("Payroll Statutory Result")
	if doc.get("status") in {"Applied", "Reversed"}:
		if doc.calculation_hash != digest:
			frappe.throw(_("Applied statutory result {0} cannot be recalculated with different inputs.").format(doc.name))
		return doc
	doc.update(
		{
			**identity,
			**values,
			"company": frappe.db.get_value("Payroll Cycle", identity["payroll_cycle"], "company"),
			"currency": company_currency(frappe.db.get_value("Payroll Cycle", identity["payroll_cycle"], "company")),
			"business_key": business_key,
			"input_snapshot": _canonical(inputs),
			"output_snapshot": _canonical(outputs),
			"calculation_hash": digest,
			"status": "Calculated",
		}
	)
	doc.save(ignore_permissions=True)
	return doc


def calculate_paye_result(
	payroll_cycle,
	employee,
	*,
	period_index,
	cumulative_emoluments,
	previous_paye=0,
	current_emoluments=None,
):
	"""Calculate and idempotently persist one employee PAYE result."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if cycle.status not in {"Input Open", "Processing", "Review"}:
		frappe.throw(_("PAYE can be calculated only while payroll is open for processing or review."))
	result = calculate_employee_paye(
		employee=employee,
		on_date=cycle.payment_date,
		period_index=period_index,
		cumulative_emoluments=cumulative_emoluments,
		previous_paye=previous_paye,
		company=cycle.company,
		current_emoluments=current_emoluments,
	)
	inputs = {
		"employee": employee,
		"payment_date": cycle.payment_date,
		"period_index": period_index,
		"cumulative_emoluments": flt(cumulative_emoluments),
		"current_emoluments": flt(current_emoluments) if current_emoluments is not None else None,
		"previous_paye": flt(previous_paye),
		"declaration": result["declaration"],
		"configuration_version": result["configuration_version"],
	}
	doc = _save_result(
		{
			"payroll_cycle": cycle.name,
			"employee": employee,
			"result_type": "PAYE",
			"rule_reference": result["paye_year"],
		},
		inputs,
		result,
		{
			"salary_basis": result["cumulative_emoluments"],
			"chargeable_income": result["chargeable_income"],
			"current_amount": result["current_paye"],
			"cumulative_amount": result["cumulative_tax"],
			"period_index": period_index,
			"configuration_version": result["configuration_version"],
			"source_declaration": result["declaration"],
		},
	)
	return {"name": doc.name, **result}


def calculate_salary_slip_paye_result(payroll_cycle, slip, component):
	"""Persist the governed EDF/PAYE result applied to the draft Salary Slip."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if cycle.status not in {"Input Open", "Processing", "Review"}:
		frappe.throw(_("PAYE can be calculated only while payroll is open for processing or review."))
	_rebuild_draft_salary_slip(slip)
	if flt(slip.net_pay, slip.precision("net_pay")) < 0:
		frappe.throw(
			_(
				"Salary Slip {0} for employee {1} has a negative Net Pay ({2}). "
				"Reduce or defer deductions before continuing."
			).format(slip.name, slip.employee, slip.net_pay)
		)
	assignment = frappe.db.get_value(
		"Salary Structure Assignment",
		{
			"employee": slip.employee,
			"salary_structure": slip.salary_structure,
			"from_date": ("<=", slip.start_date),
			"docstatus": 1,
		},
		["name", "income_tax_slab"],
		order_by="from_date desc",
		as_dict=True,
	)
	if not assignment or not assignment.income_tax_slab:
		frappe.throw(
			_("Income Tax Slab is not set for employee {0}.").format(slip.employee)
		)
	amount = sum(
		flt(row.amount)
		for row in slip.deductions
		if row.salary_component == component and not row.additional_salary
	)
	from karyo.payroll.computation import salary_slip_computation

	calculation = salary_slip_computation(slip)
	if flt(amount, 2) != flt(calculation["paye"], 2):
		frappe.throw(
			_("Salary Slip {0} PAYE does not match the governed EDF calculation: {1} versus {2}.").format(
				slip.name, amount, calculation["paye"]
			)
		)
	inputs = {
		"employee": slip.employee,
		"salary_slip": slip.name,
		"salary_structure_assignment": assignment.name,
		"income_tax_slab": assignment.income_tax_slab,
		"gross_pay": flt(slip.gross_pay),
		"payment_date": cycle.payment_date,
		"paye_year": calculation["paye_year"],
		"declaration": calculation["source_declaration"],
		"period_index": calculation["paye_period_index"],
		"payroll_type": cycle.payroll_type,
		"pay_period_label": cycle.pay_period_label,
		"current_emoluments": calculation["current_gross_emoluments"],
		"cumulative_emoluments": calculation["total_emoluments"],
		"previous_paye": calculation["previous_paye"],
	}
	outputs = {
		"current_paye": amount,
		"income_tax_slab": assignment.income_tax_slab,
		"salary_slip": slip.name,
		"calculation": calculation,
	}
	doc = _save_result(
		{
			"payroll_cycle": cycle.name,
			"employee": slip.employee,
			"result_type": "PAYE",
			"rule_reference": calculation["paye_year"],
		},
		inputs,
		outputs,
		{
			"salary_basis": calculation["total_emoluments"],
			"chargeable_income": calculation["chargeable_income"],
			"current_amount": amount,
			"cumulative_amount": calculation["net_paye_payable"],
			"period_index": calculation["paye_period_index"],
			"configuration_version": calculation["configuration_version"],
			"source_declaration": calculation["source_declaration"],
			"salary_slip": slip.name,
		},
	)
	return {"name": doc.name, **outputs}


def _rebuild_draft_salary_slip(slip):
	"""Rebuild calculated rows once, instead of incrementally accumulating them."""
	if slip.docstatus != 0:
		frappe.throw(_("Salary Slip {0} must be Draft for recalculation.").format(slip.name))
	slip.set("earnings", [])
	slip.set("deductions", [])
	slip.flags.ignore_permissions = True
	slip.save()
	slip.reload()
	return slip


def calculate_contribution_results(payroll_cycle, employee, salary_basis, schemes):
	"""Calculate and persist employee/employer results for configured schemes."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	created = []
	for scheme in schemes:
		result = calculate_contribution(scheme, salary_basis, cycle.payment_date, cycle.company)
		for result_type, amount_key in (
			("Employee Contribution", "employee_amount"),
			("Employer Contribution", "employer_amount"),
		):
			doc = _save_result(
				{
					"payroll_cycle": cycle.name,
					"employee": employee,
					"result_type": result_type,
					"rule_reference": scheme,
				},
				{"employee": employee, "salary_basis": flt(salary_basis), "scheme": scheme},
				result,
				{
					"salary_basis": salary_basis,
					"current_amount": result[amount_key],
					"cumulative_amount": result[amount_key],
					"configuration_version": frappe.db.get_value("Payroll Contribution Scheme", scheme, "configuration_version"),
				},
			)
			created.append(doc.name)
	return created


def _cycle_results(payroll_cycle, status=None, employees=None):
	filters = {"payroll_cycle": payroll_cycle}
	if employees is not None: filters["employee"] = ("in", employees)
	if status:
		filters["status"] = status
	return frappe.get_all(
		"Payroll Statutory Result",
		filters=filters,
		fields=["name", "status", "result_type", "rule_reference", "current_amount", "additional_salary"],
		order_by="employee, result_type, rule_reference",
	)


def _assert_actor(actor):
	if not has_actor_role(actor):
		frappe.throw(
			_("Only users with role {0} may perform this statutory payroll action.").format(
				configured_role(actor)
			),
			frappe.PermissionError,
		)


@frappe.whitelist()
def review_cycle_results(payroll_cycle, employees=None):
	"""Freeze calculated statutory results for cycle approval review."""
	_assert_actor("reviewer")
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if employees is not None:
		from karyo.payroll.employee_completion import validate_stage
		employees = validate_stage(cycle, employees, "Review Statutory Results")
	elif cycle.status != "Review":
		frappe.throw(_("Payroll Cycle must be in Review before statutory results can be reviewed."))
	results = _cycle_results(cycle.name, employees=employees)
	if not results:
		frappe.throw(_("No statutory results have been calculated for this Payroll Cycle."))
	if any(row.status == "Reversed" for row in results):
		frappe.throw(_("Reversed statutory results cannot be reviewed. Recalculate the employee first."))
	calculated = sum(row.status == "Calculated" for row in results)
	already_reviewed = sum(row.status == "Reviewed" for row in results)
	already_applied = sum(row.status == "Applied" for row in results)
	frappe.db.set_value(
		"Payroll Statutory Result",
		{"payroll_cycle": cycle.name, "status": "Calculated", **({"employee": ("in", employees)} if employees is not None else {})},
		"status",
		"Reviewed",
		update_modified=False,
	)
	_update_cycle_statutory_totals(cycle.name)
	return {
		"payroll_cycle": cycle.name,
		"reviewed": calculated,
		"already_reviewed": already_reviewed,
		"already_applied": already_applied,
	}


def _salary_component(result):
	if result.result_type == "PAYE":
		component = frappe.db.get_value(
			"Payroll PDB Code", {"pdb_code": "PAYE", "is_active": 1}, "salary_component"
		)
	else:
		pdb_code = frappe.db.get_value(
			"Payroll Contribution Scheme", result.rule_reference, "employee_pdb_code"
		)
		component = frappe.db.get_value("Payroll PDB Code", pdb_code, "salary_component")
	if not component:
		frappe.throw(
			_("No active Salary Component mapping is available for statutory result {0}.").format(
				result.name
			)
		)
	return component


def _overwrite_structure_amount(employee, component, payroll_date):
	"""Overwrite only when the statutory component is already in the structure.

	Contribution components that are not part of the employee's base structure
	must be posted as additive deductions. Native HRMS otherwise disables the
	overwrite flag and emits a misleading validation message during Apply PAYE.
	"""
	structure = frappe.db.get_value(
		"Salary Structure Assignment",
		{
			"employee": employee,
			"docstatus": 1,
			"from_date": ("<=", payroll_date),
		},
		"salary_structure",
		order_by="from_date desc",
	)
	return int(bool(structure and frappe.db.exists("Salary Detail", {
		"parenttype": "Salary Structure",
		"parent": structure,
		"salary_component": component,
	})))


def _prepare_statutory_component(result, component):
	"""Prevent PAYE from being prorated a second time by attendance days."""
	if result.result_type != "PAYE":
		return
	if frappe.db.get_value("Salary Component", component, "depends_on_payment_days"):
		frappe.db.set_value(
			"Salary Component", component, "depends_on_payment_days", 0,
			update_modified=False,
		)
		frappe.clear_document_cache("Salary Component", component)


def _apply_employee_result(cycle, result):
	if result.result_type == "PAYE":
		# PAYE remains the variable tax row calculated by the Income Tax Slab.
		# Posting it as Additional Salary would require overwrite mode and would
		# explicitly bypass slab calculation in HRMS.
		result.db_set(
			{"additional_salary": None, "status": "Applied"}, update_modified=False
		)
		return None, True
	if result.additional_salary:
		docstatus = frappe.db.get_value("Additional Salary", result.additional_salary, "docstatus")
		if docstatus in (0, 1):
			return result.additional_salary, True
	component = _salary_component(result)
	_prepare_statutory_component(result, component)
	doc = frappe.get_doc(
		{
			"doctype": "Additional Salary",
			"employee": result.employee,
			"company": cycle.company,
			"salary_component": component,
			"amount": result.current_amount,
			"payroll_date": cycle.payment_date,
			"overwrite_salary_structure_amount": _overwrite_structure_amount(
				result.employee, component, cycle.payment_date
			),
			"ref_doctype": result.doctype,
			"ref_docname": result.name,
			"karyo_transaction_category": "Other",
			"karyo_payroll_cycle": cycle.name,
		}
	).insert(ignore_permissions=True)
	doc.submit()
	result.db_set(
		{"additional_salary": doc.name, "status": "Applied"}, update_modified=False
	)
	return doc.name, False


@frappe.whitelist()
def apply_cycle_results(payroll_cycle, employees=None):
	"""Post reviewed employee deductions idempotently through Additional Salary."""
	_assert_actor("approver")
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if employees is not None:
		from karyo.payroll.employee_completion import validate_stage
		employees = validate_stage(cycle, employees, "Apply Employee Deductions")
	elif cycle.status != "Approved":
		frappe.throw(_("Payroll Cycle must be Approved before statutory results can be applied."))
	results = frappe.get_all(
		"Payroll Statutory Result",
		filters={
			"payroll_cycle": cycle.name,
			"result_type": ("in", ["PAYE", "Employee Contribution"]),
			"status": ("in", ["Reviewed", "Applied"]),
			**({"employee": ("in", employees)} if employees is not None else {}),
		},
		pluck="name",
	)
	if not results:
		frappe.throw(_("No reviewed employee statutory results are available to apply."))
	posted = []
	already_posted = []
	for name in results:
		result = frappe.get_doc("Payroll Statutory Result", name)
		if not flt(result.current_amount):
			result.db_set("status", "Applied", update_modified=False)
			continue
		additional_salary, existed = _apply_employee_result(cycle, result)
		if additional_salary:
			(already_posted if existed else posted).append(additional_salary)
	_update_cycle_statutory_totals(cycle.name)
	reconciliation = _refresh_and_reconcile_slips(cycle, employees=employees)
	_update_cycle_statutory_totals(cycle.name)
	return {
		"payroll_cycle": cycle.name,
		"posted": posted,
		"already_posted": already_posted,
		"reconciliation": reconciliation,
		"applied_on": now_datetime(),
	}


def _refresh_and_reconcile_slips(cycle, employees=None):
	population = frappe.get_all(
		"Payroll Cycle Employee",
		filters={"payroll_cycle": cycle.name, "status": ("!=", "Excluded"), **({"employee": ("in", employees)} if employees is not None else {})},
		fields=["name", "employee", "salary_slip"],
	)
	if not population:
		return {"salary_slips": 0, "gross_pay": 0, "total_deductions": 0, "net_pay": 0}
	if any(not row.salary_slip for row in population):
		frappe.throw(_("Every included employee must have a linked Salary Slip before apply."))
	totals = {"gross_pay": 0, "total_deductions": 0, "net_pay": 0}
	for row in population:
		slip = frappe.get_doc("Salary Slip", row.salary_slip)
		if slip.docstatus != 0:
			frappe.throw(_("Salary Slip {0} must be Draft during statutory apply.").format(slip.name))
		# Rebuild PAYE from the assigned Income Tax Slab after contribution
		# Additional Salaries have been added.
		_rebuild_draft_salary_slip(slip)
		if flt(slip.net_pay, slip.precision("net_pay")) < 0:
			frappe.throw(
				_(
					"Salary Slip {0} for employee {1} would have a negative Net Pay ({2}). "
					"Reduce or defer deductions before applying payroll."
				).format(slip.name, row.employee, slip.net_pay)
			)
		results = frappe.get_all(
			"Payroll Statutory Result",
			filters={
				"payroll_cycle": cycle.name,
				"employee": row.employee,
				"result_type": ("in", ["PAYE", "Employee Contribution"]),
				"status": "Applied",
			},
			fields=["name", "result_type", "current_amount", "additional_salary"],
		)
		for result in results:
			if not flt(result.current_amount):
				frappe.db.set_value(
					"Payroll Statutory Result", result.name, "salary_slip", slip.name, update_modified=False
				)
				continue
			if result.result_type == "PAYE":
				result_doc = frappe.get_doc("Payroll Statutory Result", result.name)
				component = _salary_component(result_doc)
				actual = sum(
					flt(deduction.amount)
					for deduction in slip.deductions
					if deduction.salary_component == component and not deduction.additional_salary
				)
				_sync_paye_result_to_salary_slip(result_doc, slip, actual)
				continue
			else:
				actual = sum(
					flt(deduction.amount)
					for deduction in slip.deductions
					if deduction.additional_salary == result.additional_salary
				)
			if flt(actual, 2) != flt(result.current_amount, 2):
				frappe.throw(
					_("Salary Slip {0} does not reconcile statutory result {1}: {2} versus {3}.").format(
						slip.name, result.name, actual, result.current_amount
					)
				)
			frappe.db.set_value(
				"Payroll Statutory Result", result.name, "salary_slip", slip.name, update_modified=False
			)
		for fieldname in totals:
			totals[fieldname] += flt(slip.get("total_deduction" if fieldname == "total_deductions" else fieldname))
		frappe.db.set_value(
			"Payroll Cycle Employee",
			row.name,
			{"status": "Reconciled", "last_processed_on": now_datetime(), "exclusion_reason": None},
			update_modified=False,
		)
	cycle_totals = totals
	if employees is not None:
		from karyo.payroll.employee_closing import slips
		all_slips = frappe.get_all("Salary Slip", filters={"name": ("in", [row.name for row in slips(cycle)] or [""])}, fields=["gross_pay", "total_deduction", "net_pay"])
		cycle_totals = {"gross_pay": sum(flt(row.gross_pay) for row in all_slips), "total_deductions": sum(flt(row.total_deduction) for row in all_slips), "net_pay": sum(flt(row.net_pay) for row in all_slips)}
	frappe.db.set_value(
		"Payroll Cycle",
		cycle.name,
		{
			"gross_pay": cycle_totals["gross_pay"],
			"total_deductions": cycle_totals["total_deductions"],
			"net_pay": cycle_totals["net_pay"],
		},
		update_modified=False,
	)
	return {"salary_slips": len(population), **totals}


def _sync_paye_result_to_salary_slip(result, slip, amount):
	"""Make the final Income Tax Slab calculation the authoritative PAYE result."""
	inputs = json.loads(result.input_snapshot or "{}")
	outputs = json.loads(result.output_snapshot or "{}")
	calculation = outputs.get("calculation") if isinstance(outputs.get("calculation"), dict) else {}
	outputs.update({"current_paye": flt(amount), "salary_slip": slip.name})
	if calculation:
		calculation["paye"] = flt(amount)
		outputs["calculation"] = calculation
	cumulative_amount = flt(
		calculation.get("net_paye_payable") or calculation.get("cumulative_tax")
		or flt(inputs.get("previous_paye")) + flt(amount)
	)
	digest = hashlib.sha256(f"{_canonical(inputs)}|{_canonical(outputs)}".encode()).hexdigest()
	frappe.db.set_value(
		"Payroll Statutory Result",
		result.name,
		{
			"current_amount": amount,
			"cumulative_amount": cumulative_amount,
			"salary_basis": flt(calculation.get("total_emoluments") or calculation.get("cumulative_emoluments") or result.salary_basis),
			"chargeable_income": flt(calculation.get("chargeable_income") or result.chargeable_income),
			"period_index": cint(calculation.get("paye_period_index") or inputs.get("period_index") or result.period_index),
			"salary_slip": slip.name,
			"additional_salary": None,
			"output_snapshot": _canonical(outputs),
			"calculation_hash": digest,
			"status": "Applied",
		},
		update_modified=False,
	)


def _update_cycle_statutory_totals(payroll_cycle):
	totals = frappe.db.sql(
		"""select result_type, sum(current_amount) amount
		from `tabPayroll Statutory Result`
		where payroll_cycle=%s and status != 'Reversed'
		group by result_type""",
		payroll_cycle,
		as_dict=True,
	)
	by_type = {row.result_type: flt(row.amount) for row in totals}
	frappe.db.set_value(
		"Payroll Cycle",
		payroll_cycle,
		{
			"paye_total": by_type.get("PAYE", 0),
			"employee_contributions": by_type.get("Employee Contribution", 0),
			"employer_contributions": by_type.get("Employer Contribution", 0),
			"calculated_on": now_datetime(),
		},
		update_modified=False,
	)


def repair_cycle_paye_from_income_tax_slabs(payroll_cycle):
	"""Replace legacy PAYE override postings on an open cycle with slab PAYE."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if cycle.status in {"Closed", "Cancelled"}:
		frappe.throw(_("Closed or cancelled payroll cannot be repaired."))
	component = frappe.db.get_value(
		"Payroll PDB Code", {"pdb_code": "PAYE", "is_active": 1}, "salary_component"
	)
	if not component:
		frappe.throw(_("No active PAYE Salary Component mapping is configured."))
	population = frappe.get_all(
		"Payroll Cycle Employee",
		filters={"payroll_cycle": cycle.name, "status": ("!=", "Excluded")},
		fields=["name", "employee", "salary_slip"],
	)
	frappe.db.savepoint("repair_slab_paye")
	previous_flag = frappe.flags.payroll_employee_completion
	frappe.flags.payroll_employee_completion = True
	try:
		for row in population:
			if not row.salary_slip:
				frappe.throw(_("Employee {0} has no linked Salary Slip.").format(row.employee))
			slip = frappe.get_doc("Salary Slip", row.salary_slip)
			if slip.docstatus != 0:
				frappe.throw(_("Salary Slip {0} must be Draft for PAYE repair.").format(slip.name))
			income_tax_slab = frappe.db.get_value(
				"Salary Structure Assignment",
				{
					"employee": row.employee,
					"salary_structure": slip.salary_structure,
					"from_date": ("<=", slip.start_date),
					"docstatus": 1,
				},
				"income_tax_slab",
				order_by="from_date desc",
			)
			paye_results = frappe.get_all(
				"Payroll Statutory Result",
				filters={
					"payroll_cycle": cycle.name,
					"employee": row.employee,
					"result_type": "PAYE",
					"status": ("!=", "Reversed"),
				},
				fields=["name", "rule_reference", "current_amount", "additional_salary"],
			)
			if not paye_results:
				frappe.throw(_("Employee {0} has no PAYE result to repair.").format(row.employee))
			preferred = next(
				(result for result in paye_results if result.rule_reference == income_tax_slab),
				paye_results[0],
			)
			for duplicate in paye_results:
				if duplicate.name == preferred.name:
					continue
				if flt(duplicate.current_amount) or duplicate.additional_salary:
					frappe.throw(
						_("Employee {0} has more than one non-zero PAYE result.").format(row.employee)
					)
				frappe.delete_doc(
					"Payroll Statutory Result", duplicate.name, ignore_permissions=True, force=True
				)
			result_name = preferred.name
			result = frappe.get_doc("Payroll Statutory Result", result_name)
			legacy_additional_salary = result.additional_salary
			if result.additional_salary and frappe.db.exists("Additional Salary", result.additional_salary):
				additional = frappe.get_doc("Additional Salary", result.additional_salary)
				if additional.docstatus == 1:
					additional.flags.ignore_permissions = True
					additional.cancel()
			result.db_set(
				{"status": "Calculated", "additional_salary": None}, update_modified=False
			)
			slip.reload()
			if legacy_additional_salary:
				slip.set(
					"deductions",
					[
						deduction
						for deduction in slip.deductions
						if deduction.additional_salary != legacy_additional_salary
					],
				)
			calculated = calculate_salary_slip_paye_result(cycle.name, slip, component)
			frappe.db.set_value(
				"Payroll Statutory Result",
				calculated["name"],
				{"status": "Applied", "salary_slip": slip.name, "additional_salary": None},
				update_modified=False,
			)
			frappe.db.set_value(
				"Payroll Cycle Employee",
				row.name,
				{"status": "Reconciled", "last_processed_on": now_datetime()},
				update_modified=False,
			)
		_update_cycle_statutory_totals(cycle.name)
		_refresh_and_reconcile_slips(cycle)
		_update_cycle_statutory_totals(cycle.name)
	except Exception:
		frappe.db.rollback(save_point="repair_slab_paye")
		raise
	finally:
		frappe.flags.payroll_employee_completion = previous_flag
	return {"payroll_cycle": cycle.name, "repaired": len(population)}


def delete_generated_result(name, ignore_permissions=False):
	"""Roll back one generated statutory row while payroll is still open."""
	result = frappe.get_doc("Payroll Statutory Result", name)
	cycle = frappe.get_doc("Payroll Cycle", result.payroll_cycle)
	if cycle.status in ("Closed", "Cancelled"):
		frappe.throw(_("Closed or cancelled payroll results cannot be deleted."))
	slip = frappe.get_doc("Salary Slip", result.salary_slip) if result.salary_slip else None
	if slip and slip.docstatus != 0 and (flt(result.current_amount) or result.additional_salary):
		frappe.throw(_("Cancel Salary Slip {0} before deleting this generated result.").format(slip.name))
	if slip and slip.docstatus != 0:
		# A zero result has no posting on the submitted slip, so deleting only its
		# generated audit row is safe and does not require reopening the payslip.
		slip = None
	additional = frappe.get_doc("Additional Salary", result.additional_salary) if result.additional_salary else None
	if additional:
		additional.flags.ignore_permissions = ignore_permissions
		if additional.docstatus == 1:
			additional.cancel()
		frappe.delete_doc("Additional Salary", additional.name, ignore_permissions=ignore_permissions)
	if slip:
		# Recalculate the still-draft slip so the cancelled posting disappears from
		# its deductions before the user regenerates statutory results.
		slip.reload()
		slip.calculate_net_pay(skip_tax_breakup_computation=True)
		slip.flags.ignore_permissions = ignore_permissions
		slip.save()
	frappe.delete_doc("Payroll Statutory Result", result.name, ignore_permissions=ignore_permissions)
	_update_cycle_statutory_totals(cycle.name)
	return {"name": name, "message": _("Generated result {0} and its payroll posting were deleted. Regenerate the employee's statutory calculations before closing payroll.").format(name)}
