frappe.query_reports["Loan Agreement Listing"] = {
	filters: [
		{ fieldname: "from_date", label: __("Generated From"), fieldtype: "Date" },
		{ fieldname: "to_date", label: __("Generated To"), fieldtype: "Date" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "workflow_state", label: __("Loan State"), fieldtype: "Data" },
		{ fieldname: "generated_status", label: __("Generated"), fieldtype: "Select", options: "\nGenerated\nNot Generated" },
		{ fieldname: "signed_status", label: __("Signed"), fieldtype: "Select", options: "\nSigned\nNot Signed" },
		{ fieldname: "verified_status", label: __("Verified"), fieldtype: "Select", options: "\nVerified\nPending Verification\nNot Signed" },
		{ fieldname: "missing_documents", label: __("Missing Required Documents Only"), fieldtype: "Check" },
	],
};
