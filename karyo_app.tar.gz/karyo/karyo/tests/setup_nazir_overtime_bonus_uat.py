"""Idempotent, explicitly-invoked live UAT setup for Nazir's ESS checks."""

import frappe
from frappe.sessions import Session

from karyo.payroll.overtime_process import decide


EMPLOYEE = "MBC/HR/00001"
REFERENCE = "UAT-ESS-OT-BONUS-2026-09"


def _authorization(kind, start, end, **values):
	existing = frappe.db.get_value(
		"PRB Overtime Authorization",
		{"employee": EMPLOYEE, "authority_reference": f"{REFERENCE}-{kind.upper().replace(' ', '-')}", "docstatus": ("<", 2)},
		"name",
	)
	if existing:
		return frappe.get_doc("PRB Overtime Authorization", existing)
	doc = frappe.get_doc({
		"doctype": "PRB Overtime Authorization",
		"employee": EMPLOYEE,
		"claim_type": kind,
		"planned_start": start,
		"planned_end": end,
		"period_weeks": 1,
		"overtime_period": values.pop("overtime_period", "weekday_day"),
		"authority_reference": f"{REFERENCE}-{kind.upper().replace(' ', '-')}",
		**values,
	}).insert(ignore_permissions=True)
	doc.submit()
	doc.actual_start = start
	doc.actual_end = end
	doc.claimed_hours = doc.planned_hours
	if kind == "Overtime":
		doc.total_actual_hours = 43
	doc.save(ignore_permissions=True)
	return doc


def _higher_duty():
	existing = frappe.db.get_value(
		"PRB Higher Duty Assignment",
		{"employee": EMPLOYEE, "authority_reference": REFERENCE, "docstatus": ("<", 2)},
		"name",
	)
	if existing:
		return frappe.get_doc("PRB Higher Duty Assignment", existing)
	doc = frappe.get_doc({
		"doctype": "PRB Higher Duty Assignment",
		"employee": EMPLOYEE,
		"assignment_type": "Acting",
		"from_date": "2026-09-23",
		"to_date": "2026-09-29",
		"higher_post": "Managing Director",
		"higher_grade_scale": "EDU-SECONDARY-EDUCATOR",
		"authority_reference": REFERENCE,
	}).insert(ignore_permissions=True)
	doc.submit()
	return doc


def _bonus_run():
	existing = frappe.db.get_value(
		"PRB Payroll Run",
		{
			"employee": EMPLOYEE,
			"payroll_cycle": "PAYC-2026-00016",
			"run_purpose": "PRB Attendance Bonuses",
			"docstatus": 0,
		},
		"name",
	)
	if existing:
		return frappe.get_doc("PRB Payroll Run", existing)
	return frappe.get_doc({
		"doctype": "PRB Payroll Run",
		"employee": EMPLOYEE,
		"review_year": 2026,
		"payroll_period": "2026-2027 (MBC)",
		"payroll_cycle": "PAYC-2026-00016",
		"calculation_date": "2026-09-30",
		"run_purpose": "PRB Attendance Bonuses",
		"employee_inputs": [
			{"category": "Allowance", "input_code": "ATTENDANCE_BONUS", "description": "Attendance Bonus"},
			{"category": "Allowance", "input_code": "INCENTIVE_ATTENDANCE", "description": "Incentive Attendance Bonus"},
		],
	}).insert(ignore_permissions=True)


def execute():
	frappe.set_user("Administrator")
	overtime = _authorization(
		"Overtime", "2026-09-23 18:00:00", "2026-09-23 21:00:00",
		unavoidable_service_need=1, overtime_period="weekday_day",
	)
	if overtime.payroll_approval_status != "Approved":
		decide([overtime.name], "Approved")
		overtime.reload()
	extra = _authorization(
		"Excess Hours", "2026-09-24 15:00:00", "2026-09-24 21:00:00",
		equivalent_time_off_unavailable=1, excess_hours_basis="Week",
	)
	night = _authorization(
		"Night Duty", "2026-09-23 23:00:00", "2026-09-24 05:00:00",
		overtime_period="weekday_night",
	)
	duty = _higher_duty()
	bonus = _bonus_run()
	frappe.db.commit()
	return {
		"employee": EMPLOYEE,
		"overtime": overtime.name,
		"extra_hours": extra.name,
		"night_duty": night.name,
		"higher_duty": duty.name,
		"bonus_run": bonus.name,
	}


def create_ess_session():
	"""Create a short-lived local UAT session without changing Nazir's password."""
	user = frappe.db.get_value("Employee", EMPLOYEE, "user_id")
	if not user:
		frappe.throw("Nazir has no linked user account.")
	info = frappe.db.get_value("User", user, ["first_name", "last_name", "user_type"], as_dict=True)
	frappe.local.request = frappe._dict(cookies={})
	frappe.local.request_ip = "127.0.0.1"
	session = Session(
		user=user,
		full_name=" ".join(filter(None, [info.first_name, info.last_name])),
		user_type=info.user_type,
	)
	return {"sid": session.sid}
