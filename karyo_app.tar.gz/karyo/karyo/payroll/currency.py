"""One authoritative currency: the selected Company's default currency."""

import frappe


DEFAULT_CURRENCY = "MUR"


def company_currency(company=None):
	return (
		frappe.db.get_value("Company", company, "default_currency") if company else None
	) or frappe.db.get_default("currency") or DEFAULT_CURRENCY


def apply_company_currency(doc, method=None):
	"""Fill calculation currency from Company without blocking a user's Company change."""
	company = doc.get("company")
	if not company:
		return
	currency = company_currency(company)
	if doc.meta.has_field("currency"):
		doc.currency = currency
	if doc.meta.has_field("exchange_rate"):
		doc.exchange_rate = 1

