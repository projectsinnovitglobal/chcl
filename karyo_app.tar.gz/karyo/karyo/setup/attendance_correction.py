"""Schema for employee attendance correction requests and audit markers."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	create_custom_fields(
		{
			"Attendance Request": [
				{
					"fieldname": "karyo_request_status",
					"label": "Correction Status",
					"fieldtype": "Select",
					"options": "Pending Approval\nApproved\nRejected\nCancelled",
					"default": "Pending Approval",
					"insert_after": "employee_name",
					"read_only": 1,
					"in_list_view": 1,
					"allow_on_submit": 1,
					"no_copy": 1,
				},
				{
					"fieldname": "karyo_attendance",
					"label": "Attendance Record",
					"fieldtype": "Link",
					"options": "Attendance",
					"insert_after": "karyo_request_status",
					"read_only": 1,
					"no_copy": 1,
				},
				{
					"fieldname": "karyo_requested_status",
					"label": "Correct Attendance To",
					"fieldtype": "Select",
					"options": "Present\nHalf Day\nWork From Home",
					"insert_after": "to_date",
					"reqd": 1,
				},
				{
					"fieldname": "karyo_rejection_reason",
					"label": "Rejection Reason",
					"fieldtype": "Small Text",
					"insert_after": "explanation",
					"read_only": 1,
					"allow_on_submit": 1,
					"no_copy": 1,
				},
				{
					"fieldname": "karyo_batch_id",
					"label": "Correction Batch",
					"fieldtype": "Data",
					"insert_after": "karyo_rejection_reason",
					"read_only": 1,
					"hidden": 1,
					"no_copy": 1,
				},
			],
			"Attendance": [
				{
					"fieldname": "karyo_is_corrected",
					"label": "Corrected",
					"fieldtype": "Check",
					"insert_after": "attendance_request",
					"read_only": 1,
					"in_list_view": 1,
					"no_copy": 1,
				},
				{
					"fieldname": "karyo_correction_request",
					"label": "Correction Request",
					"fieldtype": "Link",
					"options": "Attendance Request",
					"insert_after": "karyo_is_corrected",
					"read_only": 1,
					"no_copy": 1,
				},
				{
					"fieldname": "karyo_corrected_on",
					"label": "Corrected On",
					"fieldtype": "Datetime",
					"insert_after": "karyo_correction_request",
					"read_only": 1,
					"no_copy": 1,
				},
			],
		},
		update=True,
	)
	# Preserve the meaning of native records created before these explicit status
	# and audit fields existed.
	frappe.db.sql(
		"""update `tabAttendance Request`
		set karyo_request_status = case
			when docstatus=1 then 'Approved'
			when docstatus=2 then 'Cancelled'
			else 'Pending Approval' end
		where coalesce(karyo_request_status, '')=''
			or (docstatus=1 and karyo_request_status!='Approved')
			or (docstatus=2 and karyo_request_status!='Cancelled')"""
	)
	frappe.db.sql(
		"""update `tabAttendance`
		set karyo_is_corrected=1,
			karyo_correction_request=attendance_request,
			karyo_corrected_on=modified
		where docstatus != 2 and coalesce(attendance_request, '') != ''
			and coalesce(karyo_is_corrected, 0)=0"""
	)
	frappe.clear_cache(doctype="Attendance Request")
	frappe.clear_cache(doctype="Attendance")


def setup():
	apply()
