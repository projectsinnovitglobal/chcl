frappe.query_reports["Loan Portfolio"] = {
	filters: [
		{ fieldname: "as_at_date", label: __("As At Date"), fieldtype: "Date", reqd: 1, default: frappe.datetime.get_today() },
		{ fieldname: "status", label: __("Loan Status"), fieldtype: "Select", options: "\nActive\nSettled\nClosed", default: "Active" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department" },
		{ fieldname: "location", label: __("Location / Branch"), fieldtype: "Link", options: "Branch" },
		{ fieldname: "deduction_health", label: __("Deduction Health"), fieldtype: "Select", options: "\nHealthy\nPartial\nMissing\nNot Applicable" },
	],
};
