"""Payroll dashboard counters are derived from exact runtime mappings."""

import unittest
from unittest.mock import call, patch

import frappe

from karyo.desk.payroll_screens import cycle_totals, decorate_cycle
from karyo.desk.payroll_drawer import _actions
from karyo.karyo.doctype.payroll_cycle.payroll_cycle import PayrollCycle
from karyo.payroll.employee_processing import resolve_employees


class TestPayrollRuntimeMetrics(unittest.TestCase):
	@patch("karyo.desk.payroll_drawer._is_admin_user", return_value=True)
	@patch("karyo.desk.payroll_drawer.frappe.db.get_value")
	def test_open_pay_day_routes_to_close_payroll_until_cycle_closes(self, get_value, _admin):
		get_value.return_value = frappe._dict(name="PAYC-TEST", status="Processing")
		actions = _actions({"actions": [{
			"key": "close_pay_day", "label": "Close Pay Day", "handler": "pay_day_status",
			"args": {"status": "Closed"}, "when": {"status": ["Active", "Processing"]},
			"role": "finance", "primary": True,
		}]}, frappe._dict(doctype="Payroll Pay Day", name="DAY-TEST", status="Processing"), True)
		self.assertEqual(actions[0]["label"], "Complete Close Payroll")
		self.assertEqual(actions[0]["screen"], "close")
		self.assertTrue(actions[0]["available"])

	@patch("karyo.karyo.doctype.payroll_cycle.payroll_cycle.frappe.db.set_value")
	@patch("karyo.karyo.doctype.payroll_cycle.payroll_cycle.frappe.db.get_value", return_value="Processing")
	def test_closed_cycle_synchronizes_dependent_pay_day(self, _get_value, set_value):
		PayrollCycle._sync_pay_day_status(frappe._dict(
			name="PAYC-TEST", status="Closed", pay_day="DAY-TEST"))
		set_value.assert_called_once_with(
			"Payroll Pay Day", "DAY-TEST", "status", "Closed", update_modified=False)

	@patch("karyo.desk.payroll_management.employee_run_eligibility", return_value={"eligible": True, "reason": None})
	@patch("karyo.payroll.employee_processing.frappe.get_all")
	@patch("karyo.payroll.employee_processing.frappe.get_list")
	def test_excluded_cycle_member_stays_out_of_refreshed_scope(self, get_list, get_all, _eligible):
		get_list.return_value = [
			frappe._dict(name="EMP-A", employee_name="A", company="MBC", status="Active"),
			frappe._dict(name="EMP-B", employee_name="B", company="MBC", status="Active"),
		]
		get_all.return_value = [frappe._dict(
			employee="EMP-B", exclusion_reason="Removed because a Salary Slip already exists.")]
		cycle = frappe._dict(name="PAYC-TEST", company="MBC", start_date="2026-07-01", end_date="2026-07-31")
		selected, options = resolve_employees(cycle, [])
		self.assertEqual(selected, ["EMP-A"])
		self.assertEqual([row.name for row in options], ["EMP-A"])
		with self.assertRaisesRegex(frappe.ValidationError, "Salary Slip already exists"):
			resolve_employees(cycle, ["EMP-B"])

	@patch("karyo.desk.payroll_screens.frappe.db.sql")
	def test_cycle_without_entry_uses_exact_cycle_link_not_shared_dates(self, sql):
		sql.return_value = [{
			"slips": 0, "submitted": 0, "draft": 0,
			"gross_pay": 0, "total_deductions": 0, "net_pay": 0,
		}]
		cycle_totals({
			"name": "PAYC-TEST-MAJOR", "company": "MBC",
			"start_date": "2026-07-01", "end_date": "2026-07-31",
		})
		query, params = sql.call_args.args[:2]
		self.assertIn("karyo_payroll_cycle = %s", query)
		self.assertNotIn("company = %s", query)
		self.assertEqual(params, ["PAYC-TEST-MAJOR"])

	@patch("karyo.desk.payroll_screens.frappe.db.set_value")
	@patch("karyo.desk.payroll_screens.frappe.db.count")
	@patch("karyo.desk.payroll_screens.cycle_totals")
	def test_decorate_cycle_synchronizes_live_blocks(self, totals, count, set_value):
		totals.return_value = {
			"slips": 2, "submitted": 1, "draft": 1,
			"gross_pay": 2500, "total_deductions": 300, "net_pay": 2200,
		}
		count.side_effect = [5, 1, 2]
		cycle = decorate_cycle({
			"name": "PAYC-TEST", "pay_period_label": "Test", "status": "Processing",
			"payroll_entry": "ENTRY-TEST", "employee_count": 9,
			"gross_pay": 0, "total_deductions": 0, "net_pay": 0, "exception_count": 0,
		})
		self.assertEqual(cycle["employee_count"], 4)
		self.assertEqual(cycle["exception_count"], 2)
		self.assertEqual(cycle["gross_pay"], 2500)
		self.assertEqual(cycle["net_pay"], 2200)
		set_value.assert_called_once_with("Payroll Cycle", "PAYC-TEST", {
			"employee_count": 4,
			"gross_pay": 2500.0,
			"total_deductions": 300.0,
			"net_pay": 2200.0,
			"exception_count": 2,
		}, update_modified=False)
		self.assertEqual(count.call_args_list, [
			call("Payroll Cycle Employee", {"payroll_cycle": "PAYC-TEST"}),
			call("Payroll Cycle Employee", {"payroll_cycle": "PAYC-TEST", "status": "Excluded"}),
			call("Payroll Readiness Exception", {
				"payroll_cycle": "PAYC-TEST", "status": "Open",
				"severity": ("in", ["Blocking", "Approval Required"]),
			}),
		])


if __name__ == "__main__":
	unittest.main()
