"""Role access for loan configuration, inquiry pages, and read-only reports."""

import frappe


CONFIGURATION_DOCTYPES = (
	"Loan Type", "Loan Insurance Rate", "Loan Condition", "Loan Operation Code",
	"Loan Recomputation Parameter", "Loan Document Requirement", "Loan Approval Authority",
	"Loan Accounting Mapping", "Karyo Settings",
)
REPORT_ROLES = (
	"System Manager", "Loan Officer", "Karyo Loan Committee", "Loan Approver",
	"Karyo Finance", "Payroll Finance", "Loan Auditor",
)
LOAN_REPORTS = (
	"Loan Application Register", "Pending Loan Applications", "Loan Committee Review",
	"Loan Approval Outcomes", "Loan Agreement Listing", "Active Loans", "Loan Portfolio",
	"Loan Repayment Schedule", "Loan Schedule", "Loan Statement", "Loan Ledger",
	"Outstanding Loan Balances", "Loan Budget - Interest Element", "Loan Deduction Report",
	"Static Deduction", "Loan Guarantor Exposure", "Pending Lien Registration",
	"Settled Loans", "Loan Payroll Reconciliation", "Loan Ledger to GL Reconciliation",
	"Loanees Without Deductions", "Loan Disbursement Register",
)


def _upsert_permission(meta, role, values):
	row = next((item for item in meta.permissions if item.role == role), None)
	if not row:
		row = meta.append("permissions", {"role": role})
	for fieldname, value in values.items():
		row.set(fieldname, value)


def configure_doctype_permissions():
	if frappe.db.exists("DocType", "Loan Type"):
		frappe.db.set_value("DocType", "Loan Type", "allow_rename", 0)
		frappe.db.set_value("DocField", {"parent": "Loan Type", "fieldname": "max_period_months"}, "reqd", 1)
	for fieldname, label in {
		"min_age": "Age From", "max_age": "Age To",
		"min_term_months": "Term From (Months)", "max_term_months": "Term To (Months)",
	}.items():
		frappe.db.set_value("DocField", {"parent": "Loan Insurance Rate", "fieldname": fieldname}, "label", label)
	for doctype in CONFIGURATION_DOCTYPES:
		if not frappe.db.exists("DocType", doctype):
			continue
		meta = frappe.get_doc("DocType", doctype)
		_upsert_permission(meta, "Loan Configuration Administrator", {
			"read": 1, "write": 1, "create": 1, "delete": 0, "report": 1, "export": 1,
		})
		# The client function overview explicitly names Payroll and Finance as
		# primary configuration roles.  They may maintain governed versions, but
		# cannot delete reference history; approved/active versions remain
		# immutable through validate_governance().
		for role in ("Karyo Finance", "Payroll Finance"):
			_upsert_permission(meta, role, {
				"read": 1, "write": 1, "create": 1, "delete": 0, "report": 1, "export": 1,
			})
		_upsert_permission(meta, "Loan Auditor", {
			"read": 1, "write": 0, "create": 0, "delete": 0, "report": 1, "export": 1,
		})
		meta.save(ignore_permissions=True)

	if frappe.db.exists("DocType", "Loan Document Requirement"):
		meta = frappe.get_doc("DocType", "Loan Document Requirement")
		meta.set("permissions", [])
		for role, maintain in (
			("System Manager", True), ("Loan Configuration Administrator", True),
			("Karyo Finance", True), ("Payroll Finance", True),
			("HR Manager", False), ("Loan Auditor", False),
		):
			meta.append("permissions", {"role": role, "read": 1, "report": 1,
				"export": 1, "print": 1, "create": int(maintain),
				"write": int(maintain), "delete": 0, "share": 0})
		meta.save(ignore_permissions=True)

	# Reports resolve row access through Karyo Loan itself; Loan Auditor already
	# has canonical read/report/export permission there. Financial child records
	# remain inaccessible as standalone lists, preserving least privilege.


def configure_pages_and_reports():
	page_roles = REPORT_ROLES + ("HR Manager", "HR User", "Employee")
	for page in ("loan-center", "loan-inquiry"):
		if frappe.db.exists("Page", page):
			doc = frappe.get_doc("Page", page)
			doc.set("roles", [{"role": role} for role in page_roles])
			doc.save(ignore_permissions=True)
	if frappe.db.exists("Page", "my-loans"):
		doc = frappe.get_doc("Page", "my-loans")
		doc.set("roles", [{"role": "Employee"}])
		doc.save(ignore_permissions=True)
	for report in LOAN_REPORTS:
		if frappe.db.exists("Report", report):
			doc = frappe.get_doc("Report", report)
			roles = list(REPORT_ROLES)
			if report in {
				"Loan Application Register", "Pending Loan Applications", "Loan Committee Review",
				"Loan Approval Outcomes", "Loan Agreement Listing",
			}:
				roles.extend(["HR Manager", "HR User"])
			elif report not in {"Loan Ledger to GL Reconciliation"}:
				roles.append("HR Manager")
			doc.set("roles", [{"role": role} for role in dict.fromkeys(roles)])
			doc.save(ignore_permissions=True)


def setup():
	print("Karyo Loan access setup:")
	configure_doctype_permissions()
	configure_pages_and_reports()
	frappe.clear_cache()
	frappe.db.commit()
	print("Done (configuration, page, and read-only report roles aligned).")
