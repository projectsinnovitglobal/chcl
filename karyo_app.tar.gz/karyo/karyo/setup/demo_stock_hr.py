"""Deepen the stock-HRMS demo data for the category Overview dashboards.

demo_hr.seed() populates the masters and Feb–Jul 2026 transactions, but the
overview charts need *history*: this module backfills Aug 2025 → Jan 2026
(leave, attendance, salary slips), mixes statuses so donuts aren't one color,
spreads recruitment over the year, and fills the truly-empty exit doctypes
(Employee Separation, Full & Final, Gratuity).

Standalone, idempotent and fail-soft — NOT part of install.SETUP_SEQUENCE or
before_tests. Never touches Global Defaults, `_Test Company` rows or shared
masters (see the "Karyo Test SS" company-mismatch incident).

    bench --site dev.localhost execute karyo.setup.demo_stock_hr.seed
    bench --site dev.localhost execute karyo.setup.demo_stock_hr.verify
"""

import random
import unicodedata
from datetime import date, timedelta

import frappe
from frappe.utils import add_days, get_last_day

from karyo.setup.demo_hr import (
	COMPANY,
	MU_FIRST,
	MU_LAST,
	STAFF,
	STRUCTURE,
	TAX_SLAB,
	TODAY,
	_account,
	_block,
	_emp,
	_exists,
	_insert,
)

R = random.Random(20260711)
HIST_START = date(2025, 8, 1)
HIST_END = date(2026, 1, 25)


def _actives(**filters):
	base = {"company": COMPANY, "status": "Active"}
	base.update(filters)
	return frappe.get_all("Employee", filters=base, fields=["name", "employee_name", "date_of_joining"])


def _backdate(doctype, name, day):
	frappe.db.set_value(
		doctype, name, "creation", f"{day} 09:{R.randint(10, 55):02d}:00", update_modified=False
	)


def _skip(e):
	print("       skip:", str(e)[:120])


# ------------------------------------------------------------------ 1. leave


def leave_history_setup():
	if not _exists(
		"Leave Period",
		{
			"company": COMPANY,
			"from_date": ("<=", "2025-12-31"),
			"to_date": (">=", "2025-01-01"),
		},
	):
		_insert(
			{
				"doctype": "Leave Period",
				"from_date": "2025-01-01",
				"to_date": "2025-12-31",
				"company": COMPANY,
				"is_active": 0,
			}
		)
	made = 0
	for emp in _actives(date_of_joining=["<=", "2025-01-01"]):
		for lt, days in (("Annual Leave", 21), ("Sick Leave", 21), ("Casual Leave", 11)):
			if _exists(
				"Leave Allocation",
				{
					"employee": emp.name,
					"leave_type": lt,
					"docstatus": 1,
					"from_date": ("<=", "2025-12-31"),
					"to_date": (">=", "2025-01-01"),
				},
			):
				continue
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Leave Allocation",
						"employee": emp.name,
						"leave_type": lt,
						"from_date": "2025-01-01",
						"to_date": "2025-12-31",
						"new_leaves_allocated": days,
					},
					submit=True,
				)
				made += 1
			except Exception as e:
				frappe.db.rollback(save_point="demo_sp")
				_skip(e)
	print(f"       2025 allocations: {made}")


def leave_history():
	if frappe.db.count("Leave Application", {"company": COMPANY, "from_date": ["<", "2026-02-01"]}) >= 30:
		return
	reasons = {
		"Annual Leave": [
			"Family holiday",
			"Wedding in the family",
			"Travel to Rodrigues",
			"Personal matters",
		],
		"Sick Leave": ["Flu and fever", "Medical appointment", "Back pain", "Physiotherapy"],
		"Casual Leave": ["Household emergency", "Child's school event", "Religious ceremony"],
	}
	# Midweek starts only (Mon–Wed, 1–3 days) — stays clear of weekends so the
	# 2026-only holiday list on employees never distorts 2025 leave-day counts.
	starts = []
	d = HIST_START
	while d <= HIST_END:
		if d.weekday() in (0, 1, 2):
			starts.append(d)
		d += timedelta(days=1)
	existing = {}
	for row in frappe.get_all(
		"Leave Application",
		filters={"docstatus": ["<", 2], "status": ["in", ["Open", "Approved"]]},
		fields=["employee", "from_date", "to_date"],
	):
		existing.setdefault(row.employee, []).append((row.from_date, row.to_date))
	made = 0
	for emp in _actives(date_of_joining=["<=", "2025-01-01"]):
		for _ in range(R.randint(1, 2)):
			lt = R.choice(["Annual Leave", "Annual Leave", "Sick Leave", "Casual Leave"])
			start = R.choice(starts)
			end = start + timedelta(days=R.randint(1, 3 if lt == "Annual Leave" else 2) - 1)
			if any(s <= end and start <= e for (s, e) in existing.get(emp.name, [])):
				continue
			existing.setdefault(emp.name, []).append((start, end))
			status = "Approved" if R.random() < 0.8 else "Rejected"
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Leave Application",
						"employee": emp.name,
						"leave_type": lt,
						"from_date": start,
						"to_date": end,
						"description": R.choice(reasons[lt]),
						"status": status,
						"leave_approver": "Administrator",
						"posting_date": start - timedelta(days=R.randint(2, 10)),
					},
					submit=True,
				)
				made += 1
			except Exception as e:
				frappe.db.rollback(save_point="demo_sp")
				_skip(e)
	print(f"       historic leave applications: {made}")


# -------------------------------------------------------------- 2. attendance


def attendance_history():
	if frappe.db.count("Attendance", {"company": COMPANY, "attendance_date": ["<", "2026-02-01"]}) > 800:
		return
	emps = sorted(_actives(date_of_joining=["<=", "2025-01-01"]), key=lambda e: e.date_of_joining)[:14]
	names = [e.name for e in emps]
	have = set()
	for row in frappe.get_all(
		"Attendance",
		filters={"employee": ["in", names], "attendance_date": ["<", "2026-02-06"]},
		fields=["employee", "attendance_date"],
	):
		have.add((row.employee, row.attendance_date))
	onleave = {}
	for row in frappe.get_all(
		"Leave Application",
		filters={"employee": ["in", names], "status": "Approved", "docstatus": 1},
		fields=["employee", "from_date", "to_date"],
	):
		onleave.setdefault(row.employee, []).append((row.from_date, row.to_date))
	made = 0
	d = HIST_START
	while d <= date(2026, 2, 5):
		if d.weekday() < 5:
			for emp in names:
				if (emp, d) in have:
					continue
				if any(s <= d <= e for (s, e) in onleave.get(emp, [])):
					continue
				roll = R.random()
				status = "Present" if roll < 0.93 else ("Half Day" if roll < 0.97 else "Absent")
				frappe.db.savepoint("demo_sp")
				try:
					_insert(
						{
							"doctype": "Attendance",
							"employee": emp,
							"attendance_date": d,
							"status": status,
							"company": COMPANY,
						},
						submit=True,
					)
					made += 1
				except Exception as e:
					frappe.db.rollback(save_point="demo_sp")
					_skip(e)
		d += timedelta(days=1)
	print(f"       historic attendance records: {made}")


# ------------------------------------------------------------------ 3. payroll


def payroll_history():
	base_by_name = {s[0]: s[6] for s in STAFF}
	emps = _actives(date_of_joining=["<=", "2025-07-01"])[:12]
	for e in emps:
		if _exists(
			"Salary Structure Assignment",
			{"employee": e.name, "from_date": ["<=", "2025-07-01"], "docstatus": 1},
		):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Salary Structure Assignment",
					"employee": e.name,
					"salary_structure": STRUCTURE,
					"company": COMPANY,
					"from_date": "2025-07-01",
					"base": base_by_name.get(e.employee_name) or 35000,
					"income_tax_slab": TAX_SLAB,
				},
				submit=True,
			)
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	months = [date(2025, m, 1) for m in range(8, 13)] + [date(2026, m, 1) for m in range(1, 6)]
	made = 0
	for e in emps:
		for month_start in months:
			if _exists("Salary Slip", {"employee": e.name, "start_date": month_start}):
				continue
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Salary Slip",
						"employee": e.name,
						"company": COMPANY,
						"salary_structure": STRUCTURE,
						"start_date": month_start,
						"end_date": get_last_day(month_start),
						"posting_date": get_last_day(month_start),
					},
					submit=True,
				)
				made += 1
			except Exception as ex:
				frappe.db.rollback(save_point="demo_sp")
				_skip(ex)
	print(f"       historic salary slips: {made}")


# -------------------------------------------------------------------- 4. exits


def exits():
	left = frappe.get_all(
		"Employee",
		filters={"company": COMPANY, "status": "Left"},
		fields=["name", "employee_name", "relieving_date"],
	)
	for e in left:
		if e.relieving_date and not _exists("Employee Separation", {"employee": e.name}):
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Employee Separation",
						"employee": e.name,
						"company": COMPANY,
						"boarding_begins_on": add_days(e.relieving_date, -21),
						"boarding_status": "Completed" if e.relieving_date < TODAY else "In Process",
						"activities": [
							{"activity_name": "Exit interview", "role": "HR Manager"},
							{"activity_name": "Return of assets and ID badge", "role": "HR User"},
							{"activity_name": "Revoke system and building access", "role": "System Manager"},
							{"activity_name": "Final settlement computation", "role": "HR Manager"},
						],
					}
				)
			except Exception as ex:
				frappe.db.rollback(save_point="demo_sp")
				_skip(ex)
		if e.relieving_date and not _exists("Full and Final Statement", {"employee": e.name}):
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Full and Final Statement",
						"employee": e.name,
						"company": COMPANY,
						"transaction_date": add_days(e.relieving_date, 5),
					}
				)
			except Exception as ex:
				frappe.db.rollback(save_point="demo_sp")
				_skip(ex)

	# Gratuity draft for one Left employee — the most fragile chain (rule +
	# a submitted salary slip carrying the applicable component), all fail-soft.
	rule = "MAI Gratuity Rule"
	component = frappe.db.get_value(
		"Salary Detail", {"parent": STRUCTURE, "parentfield": "earnings"}, "salary_component"
	)
	frappe.db.savepoint("demo_sp")
	try:
		if component and not frappe.db.exists("Gratuity Rule", rule):
			_insert(
				{
					"doctype": "Gratuity Rule",
					"__newname": rule,
					"name": rule,
					"calculate_gratuity_amount_based_on": "Current Slab",
					"work_experience_calculation_function": "Round off Work Experience",
					"total_working_days_per_year": 365,
					"minimum_year_for_gratuity": 1,
					"applicable_earnings_component": [{"salary_component": component}],
					"gratuity_rule_slabs": [
						{"from_year": 0, "to_year": 0, "fraction_of_applicable_earnings": 0.5}
					],
				}
			)
		emp = _emp("Rakesh Domun")
		if not _exists("Salary Slip", {"employee": emp, "start_date": date(2026, 4, 1)}):
			_insert(
				{
					"doctype": "Salary Slip",
					"employee": emp,
					"company": COMPANY,
					"salary_structure": STRUCTURE,
					"start_date": date(2026, 4, 1),
					"end_date": date(2026, 4, 30),
					"posting_date": date(2026, 4, 30),
				},
				submit=True,
			)
		if not _exists("Gratuity", {"employee": emp}):
			_insert(
				{
					"doctype": "Gratuity",
					"employee": emp,
					"company": COMPANY,
					"gratuity_rule": rule,
					"posting_date": date(2026, 5, 5),
					"pay_via_salary_slip": 0,
					"expense_account": _account("Salary") or _account("Indirect Expenses"),
					"payable_account": _account("Creditors"),
					"mode_of_payment": "Cash",
				}
			)
		print("       gratuity chain: OK")
	except Exception as ex:
		frappe.db.rollback(save_point="demo_sp")
		_skip(ex)


# -------------------------------------------------------------- 5. recruitment


def recruitment_history():
	# Spread the fresh applicants (all created on the same demo day) over the year.
	fresh = frappe.get_all(
		"Job Applicant", filters={"creation": ["between", ["2026-07-11", "2026-07-12"]]}, pluck="name"
	)
	for i, name in enumerate(fresh):
		day = HIST_START + timedelta(days=int(i * 300 / max(len(fresh) - 1, 1)) + R.randint(0, 9))
		_backdate("Job Applicant", name, day)
	if fresh:
		print(f"       backdated applicants: {len(fresh)}")

	openings = frappe.get_all("Job Opening", pluck="name")
	sources = frappe.get_all("Job Applicant Source", pluck="name")
	statuses = ["Open", "Replied", "Open", "Hold", "Rejected", "Accepted"]
	made = 0
	for i in range(18):
		first = MU_FIRST[(i + 5) % len(MU_FIRST)]
		last = MU_LAST[(i * 7 + 3) % len(MU_LAST)]
		ascii_first = unicodedata.normalize("NFKD", first).encode("ascii", "ignore").decode()
		email = f"{ascii_first}.{last}@example.com".lower()
		if _exists("Job Applicant", {"email_id": email}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			doc = _insert(
				{
					"doctype": "Job Applicant",
					"applicant_name": f"{first} {last}",
					"email_id": email,
					"status": statuses[i % len(statuses)],
					"job_title": R.choice(openings) if openings else None,
					"source": R.choice(sources) if sources else None,
					"country": "Mauritius",
				}
			)
			_backdate("Job Applicant", doc.name, HIST_START + timedelta(days=R.randint(0, 330)))
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       new applicants: {made}")

	designation = (
		frappe.db.get_value("Designation", {"name": ["like", "Account%"]})
		or frappe.get_all("Designation", limit_page_length=1, pluck="name")[0]
	)
	for title, status, posted, closed in (
		("Accounts Clerk", "Closed", "2025-10-06", "2025-12-19"),
		("Communications Officer", "Open", "2026-03-02", None),
	):
		if _exists("Job Opening", {"job_title": title}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			doc = {
				"doctype": "Job Opening",
				"job_title": title,
				"designation": designation,
				"company": COMPANY,
				"status": status,
				"posted_on": f"{posted} 09:00:00",
			}
			if closed:
				doc["closed_on"] = closed
			_insert(doc)
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)

	# One interview round + a mix of scheduled/decided interviews.
	frappe.db.savepoint("demo_sp")
	try:
		itype = frappe.get_all("Interview Type", limit_page_length=1, pluck="name")
		itype = itype[0] if itype else _insert({"doctype": "Interview Type", "__newname": "HR Round"}).name
		if not frappe.db.exists("Interview Round", "HR Screening"):
			_insert(
				{
					"doctype": "Interview Round",
					"__newname": "HR Screening",
					"round_name": "HR Screening",
					"interview_type": itype,
					"interviewers": [{"user": "Administrator"}],
				}
			)
	except Exception as ex:
		frappe.db.rollback(save_point="demo_sp")
		_skip(ex)

	if frappe.db.count("Interview") >= 10:
		print("       interviews: enough already")
		return
	interviewed = set(frappe.get_all("Interview", pluck="job_applicant"))
	candidates = [
		a
		for a in frappe.get_all("Job Applicant", filters={"status": ["!=", "Rejected"]}, pluck="name")
		if a not in interviewed
	]
	plan = [
		("Cleared", date(2025, 11, 18)),
		("Cleared", date(2026, 2, 10)),
		("Rejected", date(2026, 1, 21)),
		("Pending", TODAY + timedelta(days=6)),
		("Under Review", TODAY - timedelta(days=4)),
		("Pending", TODAY + timedelta(days=12)),
	]
	made = 0
	for (status, day), applicant in zip(plan, candidates):
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Interview",
					"job_applicant": applicant,
					"interview_round": "HR Screening",
					"scheduled_on": day,
					"from_time": "10:00:00",
					"to_time": "11:00:00",
					"status": status,
				},
				submit=status in ("Cleared", "Rejected"),
			)
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       interviews: {made}")

	if frappe.db.count("Job Offer") >= 8:
		print("       job offers: enough already")
		return
	offered = set(frappe.get_all("Job Offer", pluck="job_applicant"))
	offerable = [a for a in candidates if a not in offered]
	offer_plan = [
		("Accepted", date(2025, 12, 15)),
		("Accepted", date(2026, 2, 24)),
		("Rejected", date(2026, 4, 14)),
		("Awaiting Response", date(2026, 6, 29)),
	]
	made = 0
	for (status, day), applicant in zip(offer_plan, offerable):
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Job Offer",
					"job_applicant": applicant,
					"offer_date": day,
					"designation": designation,
					"company": COMPANY,
					"status": status,
				},
				submit=status in ("Accepted", "Rejected"),
			)
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       job offers: {made}")


# ----------------------------------------------------------------- 6. expenses


def expenses_travel_history():
	payable = _account("Creditors")
	cost_center = frappe.db.get_value("Company", COMPANY, "cost_center")
	# Only claim types with a default account configured for this company —
	# others fail validation ("Set the default account for the Expense Claim Type").
	types = frappe.get_all(
		"Expense Claim Account",
		filters={"company": COMPANY, "parenttype": "Expense Claim Type"},
		pluck="parent",
		distinct=True,
	)
	if not types or not payable:
		print("       expense claim types/account missing — skipped")
		return
	descriptions = [
		"Field mission — cane replantation survey, north",
		"Fuel — extension officer rounds, Flacq",
		"Taxi — Ministry of Agro-Industry meeting",
		"Overnight stay — cyclone damage assessment",
		"Working lunch — grower cooperative committee",
		"Registration — regional agritech seminar",
		"Fuel — Curepipe nursery inspections",
		"Ferry and taxi — Rodrigues field school",
		"Accommodation — southern irrigation audit",
		"Team meals — harvest campaign kickoff",
		"Bus and taxi — soil lab sample runs",
		"Conference fee — Indian Ocean agronomy forum",
		"Fuel — weekly Réduit station shuttle",
		"Catering — farmer open day, Port Louis",
		"Taxi — customs clearance for lab reagents",
		"Overnight stay — biosecurity inspection, east",
	]
	emps = _actives()
	made = 0
	if frappe.db.count("Expense Claim") >= 22:
		descriptions = []
	for i, desc in enumerate(descriptions):
		day = HIST_START + timedelta(days=int(i * 340 / len(descriptions)) + R.randint(0, 12))
		emp = R.choice(emps).name
		if _exists("Expense Claim", {"employee": emp, "posting_date": day}):
			continue
		approval = "Approved" if i < 10 else ("Rejected" if i < 13 else "Draft")
		amount = R.choice([650, 980, 1450, 1850, 2400, 3600, 5200, 8400])
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Expense Claim",
					"employee": emp,
					"expense_approver": "Administrator",
					"approval_status": approval,
					"company": COMPANY,
					"payable_account": payable,
					"cost_center": cost_center,
					"posting_date": day,
					"expenses": [
						{
							"expense_date": day,
							"expense_type": R.choice(types),
							"description": desc,
							"amount": amount,
							"sanctioned_amount": amount if approval == "Approved" else 0,
							"cost_center": cost_center,
						}
					],
				},
				submit=approval in ("Approved", "Rejected"),
			)
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       expense claims: {made}")

	if frappe.db.count("Travel Request") >= 10:
		print("       travel requests: enough already")
		return
	purposes = frappe.get_all("Purpose of Travel", pluck="name")
	made = 0
	for i in range(6):
		emp = R.choice(emps)
		if _exists("Travel Request", {"employee": emp.name}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			doc = _insert(
				{
					"doctype": "Travel Request",
					"employee": emp.name,
					"travel_type": "Domestic" if i % 3 else "International",
					"travel_funding": "Require Full Funding",
					"purpose_of_travel": R.choice(purposes) if purposes else None,
					"description": "Planned mission travel — see itinerary.",
				}
			)
			_backdate("Travel Request", doc.name, HIST_START + timedelta(days=R.randint(0, 330)))
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       travel requests: {made}")


# ------------------------------------------------------------------- 7. shifts


def shift_history():
	if not frappe.db.exists("Shift Type", "Early Field Shift"):
		_insert(
			{
				"doctype": "Shift Type",
				"__newname": "Early Field Shift",
				"start_time": "05:30:00",
				"end_time": "13:30:00",
			}
		)
	if frappe.db.count("Shift Assignment") >= 15:
		print("       shift assignments: enough already")
		return
	shift_types = frappe.get_all("Shift Type", pluck="name")
	assigned = set(frappe.get_all("Shift Assignment", pluck="employee"))
	candidates = [e for e in _actives() if e.name not in assigned][:9]
	made = 0
	for i, emp in enumerate(candidates):
		start = HIST_START + timedelta(days=R.randint(0, 280))
		past = i < 3
		doc = {
			"doctype": "Shift Assignment",
			"employee": emp.name,
			"company": COMPANY,
			"shift_type": R.choice(shift_types),
			"start_date": start,
			"status": "Inactive" if past else "Active",
		}
		if past:
			doc["end_date"] = min(start + timedelta(days=R.randint(60, 160)), TODAY - timedelta(days=7))
		frappe.db.savepoint("demo_sp")
		try:
			_insert(doc, submit=True)
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       shift assignments: {made}")


# ----------------------------------------------------------------- 8. training


def training_history():
	program = "First Aid & Occupational Safety"
	if not frappe.db.exists("Training Program", program):
		_insert(
			{
				"doctype": "Training Program",
				"training_program": program,
				"trainer_name": "Mauritius Red Cross",
				"description": "Workplace first aid, fire drill and machinery safety refresher.",
				"status": "Completed",
			}
		)
	emps = [e.employee_name for e in _actives()][:8]
	events = [
		("First Aid Refresher — Sep 2025", "2025-09-16 09:00:00", "2025-09-16 16:00:00", True),
		("Machinery Safety Drill — Nov 2025", "2025-11-12 09:00:00", "2025-11-13 16:00:00", True),
		("Fire Warden Training — Feb 2026", "2026-02-19 09:00:00", "2026-02-19 16:00:00", True),
		("Advanced First Aid — Sep 2026", "2026-09-10 09:00:00", "2026-09-11 16:00:00", False),
	]
	for event_name, start, end, past in events:
		if _exists("Training Event", {"event_name": event_name}):
			continue
		attendees = R.sample(emps, min(5, len(emps)))
		frappe.db.savepoint("demo_sp")
		try:
			ev = frappe.get_doc(
				{
					"doctype": "Training Event",
					"event_name": event_name,
					"training_program": program,
					"type": R.choice(["Workshop", "Seminar", "Theory"]),
					"level": "Beginner",
					"trainer_name": "Mauritius Red Cross",
					"company": COMPANY,
					"start_time": start,
					"end_time": end,
					"introduction": "Safety compliance training for field and depot staff.",
					"location": "Port Louis HQ",
					"employees": [{"employee": _emp(n), "attendance": "Present"} for n in attendees],
				}
			)
			ev.insert(ignore_permissions=True, ignore_mandatory=True)
			ev.submit()
			if past:
				ev.db_set("event_status", "Completed")
				result = frappe.get_doc(
					{
						"doctype": "Training Result",
						"training_event": ev.name,
						"employees": [
							{
								"employee": _emp(n),
								"hours": 7,
								"grade": R.choice(["A", "B+", "B"]),
								"comments": "Passed practical assessment.",
							}
							for n in attendees[:3]
						],
					}
				)
				result.insert(ignore_permissions=True, ignore_mandatory=True)
				result.submit()
				for n in attendees[:2]:
					_insert(
						{
							"doctype": "Training Feedback",
							"employee": _emp(n),
							"training_event": ev.name,
							"feedback": "Practical, well paced and directly useful in the field.",
						},
						submit=True,
					)
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print("       training events seeded")


# ---------------------------------------------------------------- 9. lifecycle


def lifecycle_history():
	designations = frappe.get_all("Designation", pluck="name")
	emps = _actives(date_of_joining=["<=", "2025-01-01"])

	promo_plan = [(date(2025, 10, 1), True), (date(2026, 3, 2), True), (TODAY + timedelta(days=30), False)]
	made = 0
	if frappe.db.count("Employee Promotion") >= 6:
		promo_plan = []
	for (day, submit), emp in zip(promo_plan, emps[3:6]):
		if _exists("Employee Promotion", {"employee": emp.name}):
			continue
		current = frappe.db.get_value("Employee", emp.name, "designation")
		new = R.choice([d for d in designations if d != current])
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Employee Promotion",
					"employee": emp.name,
					"promotion_date": day,
					"company": COMPANY,
					"promotion_details": [
						{
							"property": "Designation",
							"current": current,
							"new": new,
							"fieldname": "designation",
						}
					],
				},
				submit=submit,
			)
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       promotions: {made}")

	branches = frappe.get_all("Branch", pluck="name")
	made = 0
	transfer_plan = [] if frappe.db.count("Employee Transfer") >= 3 else [date(2025, 11, 3), date(2026, 5, 4)]
	for day, emp in zip(transfer_plan, emps[6:8]):
		if _exists("Employee Transfer", {"employee": emp.name}):
			continue
		current = frappe.db.get_value("Employee", emp.name, "branch")
		new = R.choice([b for b in branches if b != current] or branches)
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Employee Transfer",
					"employee": emp.name,
					"transfer_date": day,
					"company": COMPANY,
					"transfer_details": [
						{"property": "Branch", "current": current, "new": new, "fieldname": "branch"}
					],
				},
				submit=True,
			)
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       transfers: {made}")

	gtypes = frappe.get_all("Grievance Type", pluck="name")
	grievances = [
		("Rostering dispute — weekend field duty", date(2025, 9, 22), "Resolved"),
		("Depot ventilation and heat complaints", date(2026, 1, 14), "Investigated"),
		("Overtime payment delay — harvest season", date(2026, 6, 18), "Open"),
	]
	made = 0
	for (subject, day, status), emp in zip(grievances, emps[8:11]):
		if not gtypes or _exists("Employee Grievance", {"subject": subject}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Employee Grievance",
					"subject": subject,
					"raised_by": emp.name,
					"date": day,
					"grievance_type": R.choice(gtypes),
					"status": status,
					"description": subject,
				}
			)
			made += 1
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)
	print(f"       grievances: {made}")

	# One onboarding in progress for a recently accepted offer.
	offer = frappe.get_all(
		"Job Offer",
		filters={"status": "Accepted", "docstatus": 1},
		fields=["name", "job_applicant"],
		limit_page_length=1,
		order_by="offer_date desc",
	)
	if offer and not _exists("Employee Onboarding", {"job_offer": offer[0].name}):
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Employee Onboarding",
					"job_applicant": offer[0].job_applicant,
					"job_offer": offer[0].name,
					"company": COMPANY,
					"date_of_joining": TODAY + timedelta(days=20),
					"boarding_begins_on": TODAY + timedelta(days=5),
					"boarding_status": "In Process",
					"activities": [
						{"activity_name": "Contract signature", "role": "HR Manager"},
						{"activity_name": "Workstation and system accounts", "role": "System Manager"},
						{"activity_name": "Induction and safety briefing", "role": "HR User"},
					],
				}
			)
			print("       onboarding: 1")
		except Exception as ex:
			frappe.db.rollback(save_point="demo_sp")
			_skip(ex)


# ------------------------------------------------------------------ orchestra


def seed():
	print(f"Karyo stock-HRMS history seed (company: {COMPANY}, anchor: {TODAY}):")
	_block("leave history setup (2025 allocations)", leave_history_setup)
	_block("leave history (Aug 2025 – Jan 2026)", leave_history)
	_block("attendance history backfill", attendance_history)
	_block("payroll history (salary slips)", payroll_history)
	_block("exits (separation / FnF / gratuity)", exits)
	_block("recruitment history", recruitment_history)
	_block("expenses & travel history", expenses_travel_history)
	_block("shift assignments", shift_history)
	_block("training history", training_history)
	_block("employee lifecycle history", lifecycle_history)
	print("Done. Now run: bench --site dev.localhost execute karyo.setup.demo_stock_hr.verify")


def verify():
	checks = [
		("Leave Application", "from_date"),
		("Leave Allocation", "from_date"),
		("Attendance", "attendance_date"),
		("Salary Slip", "start_date"),
		("Expense Claim", "posting_date"),
		("Travel Request", "creation"),
		("Job Applicant", "creation"),
		("Job Opening", "creation"),
		("Job Offer", "offer_date"),
		("Interview", "scheduled_on"),
		("Shift Assignment", "start_date"),
		("Training Event", "start_time"),
		("Training Result", "creation"),
		("Employee Promotion", "promotion_date"),
		("Employee Transfer", "transfer_date"),
		("Employee Grievance", "date"),
		("Employee Separation", "boarding_begins_on"),
		("Full and Final Statement", "transaction_date"),
		("Gratuity", "posting_date"),
		("Employee Onboarding", "boarding_begins_on"),
	]
	for doctype, field in checks:
		row = frappe.db.sql(
			f"SELECT COUNT(*) AS n, MIN(`{field}`) AS lo, MAX(`{field}`) AS hi FROM `tab{doctype}`",
			as_dict=True,
		)[0]
		print(f"  {doctype:32} {row.n:5}  {row.lo} → {row.hi}")
