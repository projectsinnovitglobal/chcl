from uuid import uuid4
from unittest.mock import patch
import frappe
import unittest
from frappe.utils import nowdate, add_days
from karyo.tests.test_live_menus import TestLiveMenus
from karyo.desk.overview import eligible_loan_types, preview_ess_loan_application, submit_ess_loan_application, approvals
from karyo.loan import closing_documents, self_service
from frappe.model.workflow import apply_workflow


class TestLiveLoans(unittest.TestCase):
	tearDown = TestLiveMenus.tearDown
	def setUp(self):
		TestLiveMenus.setUp(self)
		self.token=uuid4().hex[:12]
		self.kind='ESS-'+self.token
		self.component=frappe.db.get_value('Salary Component',{'type':'Earning'},'name')
		self.period='ESS-period-'+self.token
		self.cycle='ESS-cycle-'+self.token
		for values in [
			{'doctype':'Loan Type','name':self.kind,'loan_code':self.kind,'loan_name':'ESS test','loan_category':'Personal','is_active':1,'interest_rate':6,'max_amount':100000,'max_period_months':60,'pdb_capital':self.component,'pdb_interest':self.component},
			{'doctype':'Payroll Period','name':self.period,'company':self.employee.company,'start_date':nowdate(),'end_date':add_days(nowdate(),30)},
			{'doctype':'Payroll Cycle','name':self.cycle,'company':self.employee.company,'payroll_period':self.period,'start_date':nowdate(),'end_date':add_days(nowdate(),30),'status':'Closed'},
			{'doctype':'Loan Operation Code','name':'ESS-op-'+self.token,'function':'Eligible Salary','is_active':1},
			{'doctype':'Loan Operation Code Item','name':'ESS-item-'+self.token,'parent':'ESS-op-'+self.token,'parenttype':'Loan Operation Code','parentfield':'items','salary_component':self.component,'percentage':100},
			{'doctype':'Salary Slip','name':'ESS-salary-'+self.token,'karyo_payroll_cycle':self.cycle,'employee':self.employee.name,'company':self.employee.company,'docstatus':1,'start_date':nowdate(),'end_date':add_days(nowdate(),30)},
			{'doctype':'Salary Detail','name':'ESS-detail-'+self.token,'parent':'ESS-salary-'+self.token,'parenttype':'Salary Slip','parentfield':'earnings','salary_component':self.component,'amount':50000},
		]:frappe.get_doc(values).db_insert()
		self.values={'loan_type':self.kind,'amount':12000,'period_months':12,'purpose':'Test application','payroll_period':self.period}
		frappe.set_user(self.email)

	def test_preview_and_submission_share_calculation_and_approval_queue(self):
		before=frappe.db.count('Karyo Loan',{'employee':self.employee.name})
		preview=preview_ess_loan_application(**self.values)
		self.assertTrue(preview['valid'],preview)
		self.assertEqual((preview['interest_rate'],preview['monthly_refund'],preview['total_interest']),(6,1032.5,390))
		self.assertEqual(frappe.db.count('Karyo Loan',{'employee':self.employee.name}),before)
		with patch('frappe.publish_realtime') as realtime:
			created=submit_ess_loan_application(**self.values)
			self.assertTrue(any(call.args and call.args[0]=='karyo_employee_request_updated' and call.kwargs.get('after_commit') for call in realtime.call_args_list))
		self.assertEqual(created['workflow_state'],'Approval Pending')
		doc=frappe.get_doc('Karyo Loan',created['name'])
		self.assertEqual((doc.employee,doc.interest_rate,doc.monthly_refund),(self.employee.name,6,preview['monthly_refund']))
		self.assertEqual(self_service._process(doc)['state'],'Approval Pending')
		self.assertFalse(frappe.has_permission('Karyo Loan','write',doc=doc))
		frappe.set_user('Administrator')
		self.assertIn(doc.name,str(approvals()))
		with patch('frappe.sendmail') as mail:
			for action in ['Schedule Committee','Start Review','Recommend','Approve']:
				doc=apply_workflow(doc.as_dict(),action)
			self.assertTrue(any(self.email in call.kwargs.get('recipients',[]) and 'Approved' in call.kwargs.get('subject','') for call in mail.call_args_list))
		self.assertEqual(doc.workflow_state,'Approved')
		self.assertTrue(frappe.db.exists('Notification Log',{'for_user':self.email,'document_name':doc.name,'subject':['like','%Approved%']}))

	def test_annex_ess_upload_populates_sicom_gate_and_document_register(self):
		from karyo.desk.overview import _attach_ess_supporting_document

		file_url=f'/private/files/sicom-{self.token}.pdf'
		frappe.get_doc({'doctype':'File','name':'SICOM-'+self.token,
			'file_name':'sicom-'+self.token+'.pdf','file_url':file_url,
			'is_private':1,'owner':self.email}).db_insert()
		doc=frappe.new_doc('Karyo Loan')
		_attach_ess_supporting_document(doc,file_url,'SICOM',annex_policy_enabled=True)
		self.assertEqual(doc.sicom_form_attachment,file_url)
		self.assertEqual(len(doc.documents),1)
		self.assertEqual(doc.documents[0].attachment,file_url)
		self.assertEqual(doc.documents[0].remarks,'SICOM')

	def test_settled_loan_issues_employee_closing_document(self):
		frappe.set_user('Administrator')
		name='ESS-CLOSED-'+self.token
		loan=frappe.get_doc({'doctype':'Karyo Loan','name':name,'employee':self.employee.name,'employee_name':self.employee.employee_name,
			'loan_type':self.kind,'company':self.employee.company,'date_applied':nowdate(),'amount_applied':12000,'approved_amount':12000,
			'workflow_state':'Settled','status':'Settled','docstatus':1,'settlement_date':nowdate(),'outstanding_capital':0,
			'outstanding_interest':0,'outstanding_insurance':0})
		loan.db_insert()
		closing_documents.issue(loan)
		self.assertTrue(loan.closing_document_issued_on)
		self.assertIn('Loan Closing Certificate',loan.issued_closing_document_html)
		frappe.set_user(self.email)
		view=closing_documents.view(name)
		self.assertEqual(view['reference'],'CLOSE-'+name)
		self.assertIn('download_pdf',view['pdf_url'])
		row=next(item for item in self_service.loans() if item['name']==name)
		self.assertTrue(row['closing_document']['available'])
		self.assertEqual(row['process']['progress'],100)

	def test_missing_payroll_shows_estimate_and_blocks_submission(self):
		frappe.db.set_value('Payroll Cycle',self.cycle,'status','Draft')
		values={**self.values,'payroll_period':None}
		p=preview_ess_loan_application(**values)
		self.assertFalse(p['valid']);self.assertEqual(p['monthly_refund'],1032.5)
		with self.assertRaises(frappe.ValidationError):submit_ess_loan_application(**values)

	def test_named_test_override_allows_flow_without_completed_payroll(self):
		frappe.set_user('Administrator')
		frappe.db.set_value('Payroll Cycle',self.cycle,'status','Draft')
		frappe.db.set_value('Employee',self.employee.name,'karyo_loan_payroll_period',None)
		override={'employee':self.employee.name,'user':self.email,
			'expires_on':str(add_days(nowdate(),30)),'reason':'Automated loan-flow verification'}
		values={**self.values,'payroll_period':None}
		frappe.set_user(self.email)
		with patch('karyo.desk.overview.active_override',return_value=override), \
			patch('karyo.karyo.doctype.karyo_loan.karyo_loan.active_override',return_value=override):
			self.assertIn(self.kind,{row['value'] for row in eligible_loan_types()['loan_types']})
			preview=preview_ess_loan_application(**values)
			self.assertTrue(preview['valid'],preview)
			self.assertEqual(preview['appraisal_status'],'Pass')
			self.assertEqual(preview['test_override']['employee'],self.employee.name)
			created=submit_ess_loan_application(**values)
			self.assertEqual(created['workflow_state'],'Approval Pending')
			loan=frappe.get_doc('Karyo Loan',created['name'])
			self.assertEqual(loan.employee,self.employee.name)
			self.assertIn('eligibility_test_override',loan.appraisal_snapshot)

	def test_amount_term_and_affordability_cannot_bypass_rules(self):
		for changes in [{'amount':100001},{'period_months':61},{'period_months':1.5},{'amount':100000,'period_months':1}]:
			p=preview_ess_loan_application(**{**self.values,**changes});self.assertFalse(p['valid'],p)
			with self.assertRaises(frappe.ValidationError):submit_ess_loan_application(**{**self.values,**changes})
		with self.assertRaises(TypeError):submit_ess_loan_application(**self.values,interest_rate=0)

	def test_rate_change_revalidates_and_preview_is_employee_scoped(self):
		frappe.set_user('Administrator');frappe.db.set_value('Loan Type',self.kind,'interest_rate',9)
		frappe.set_user(self.email)
		p=preview_ess_loan_application(**self.values);self.assertEqual(p['interest_rate'],9)
		with self.assertRaises(TypeError):preview_ess_loan_application(**self.values,employee='another-employee')
		frappe.set_user('Guest')
		with self.assertRaises(frappe.PermissionError):preview_ess_loan_application(**self.values)

	def test_return_and_rejection_notify_employee(self):
		created=submit_ess_loan_application(**self.values)
		frappe.set_user('Administrator')
		doc=frappe.get_doc('Karyo Loan',created['name'])
		for action in ['Schedule Committee','Start Review']:
			doc=apply_workflow(doc.as_dict(),action)
		doc.return_reason='Please clarify the application purpose';doc.save()
		with patch('frappe.sendmail') as mail:
			doc=apply_workflow(doc.as_dict(),'Return for Rework')
			self.assertEqual(doc.workflow_state,'Returned')
			self.assertTrue(any(self.email in call.kwargs.get('recipients',[]) and 'Returned' in call.kwargs.get('subject','') for call in mail.call_args_list))
		self.assertTrue(frappe.db.exists('Notification Log',{'for_user':self.email,'document_name':doc.name,'subject':['like','%Returned%']}))
		for action in ['Resubmit','Schedule Committee','Start Review']:
			doc=apply_workflow(doc.as_dict(),action)
		doc.rejection_reason='Disposable test decision';doc.committee_remarks='Disposable test decision';doc.save()
		with patch('frappe.sendmail') as mail:
			doc=apply_workflow(doc.as_dict(),'Reject')
			self.assertEqual(doc.workflow_state,'Rejected')
			self.assertTrue(any(self.email in call.kwargs.get('recipients',[]) and 'Rejected' in call.kwargs.get('subject','') for call in mail.call_args_list))
		self.assertTrue(frappe.db.exists('Notification Log',{'for_user':self.email,'document_name':doc.name,'subject':['like','%Rejected%']}))

	def test_retirement_limits_preview_and_submission_identically(self):
		from frappe.utils import add_months
		frappe.set_user('Administrator')
		frappe.db.set_value('Employee',self.employee.name,'date_of_retirement',add_months(nowdate(),6))
		frappe.set_user(self.email)
		p=preview_ess_loan_application(**self.values)
		self.assertTrue(p['valid']);self.assertEqual(p['period_months'],6)
		created=submit_ess_loan_application(**self.values)
		self.assertEqual(frappe.db.get_value('Karyo Loan',created['name'],'period_months'),6)

	def test_salary_band_conditions_use_selected_payroll(self):
		frappe.set_user('Administrator')
		frappe.get_doc({'doctype':'Loan Condition','name':'ESS-condition-'+self.token,'loan_type':self.kind,'is_active':1,'salary_from':40000,'salary_to':60000,'max_duration_months':6}).db_insert()
		original=frappe.db.get_single_value
		def setting(doctype,field,*args,**kwargs):
			if doctype=='Karyo Settings' and field=='enforce_loan_conditions':return 1
			return original(doctype,field,*args,**kwargs)
		frappe.set_user(self.email)
		with patch.object(frappe.db,'get_single_value',side_effect=setting):
			self.assertFalse(preview_ess_loan_application(**self.values)['valid'])
			p=preview_ess_loan_application(**{**self.values,'period_months':6})
			self.assertTrue(p['valid'],p)

	def test_dropdown_returns_all_eligible_types_and_backend_rejects_ineligible_type(self):
		frappe.set_user('Administrator')
		rows = [
			('eligible', 'Personal', 40000, 60000, 1),
			('other-category', 'Medical', 40000, 60000, 1),
			('wrong-salary', 'Personal', 60001, 90000, 1),
			('inactive', 'Personal', 40000, 60000, 0),
		]
		for suffix, category, salary_from, salary_to, active in rows:
			name=f'ESS-{suffix}-{self.token}'
			frappe.get_doc({'doctype':'Loan Type','name':name,'loan_code':name,
				'loan_name':suffix,'loan_category':category,'is_active':active,'interest_rate':5,
				'max_amount':50000,'max_period_months':24,'pdb_capital':self.component,
				'pdb_interest':self.component}).db_insert()
			frappe.get_doc({'doctype':'Loan Condition','name':f'LC-{suffix}-{self.token}',
				'loan_type':name,'is_active':1,'salary_from':salary_from,'salary_to':salary_to,
				'max_duration_months':12}).db_insert()
		frappe.get_doc({'doctype':'Loan Condition','name':'LC-main-'+self.token,
			'loan_type':self.kind,'is_active':1,'salary_from':40000,'salary_to':60000,
			'max_duration_months':18}).db_insert()
		original=frappe.db.get_single_value
		def setting(doctype,field,*args,**kwargs):
			if doctype=='Karyo Settings' and field=='enforce_loan_conditions':return 1
			return original(doctype,field,*args,**kwargs)
		frappe.set_user(self.email)
		with patch.object(frappe.db,'get_single_value',side_effect=setting):
			all_types=eligible_loan_types()['loan_types']
			self.assertEqual({self.kind,f'ESS-eligible-{self.token}',f'ESS-other-category-{self.token}'},
				{row['value'] for row in all_types})
			personal=eligible_loan_types('Personal')['loan_types']
			self.assertEqual({self.kind,f'ESS-eligible-{self.token}'},{row['value'] for row in personal})
			self.assertTrue(all(row['value'] != f'ESS-inactive-{self.token}' for row in all_types))
			with self.assertRaises(frappe.PermissionError):
				submit_ess_loan_application(**{**self.values,'loan_type':f'ESS-wrong-salary-{self.token}'})

	def test_employee_admin_period_defaults_to_loan_form_and_submission(self):
		from karyo.desk.overview import my_loans
		from karyo.loan.employee_period import validate_employee_period
		frappe.set_user('Administrator')
		doc=frappe.get_doc('Employee',self.employee.name);doc.karyo_loan_payroll_period=self.period;doc.save()
		frappe.set_user(self.email)
		view=my_loans()
		self.assertEqual(view['default_payroll_period'],self.period)
		self.assertIn(self.period,[p.value for p in view['payroll_periods']])
		values={**self.values,'payroll_period':None}
		self.assertTrue(preview_ess_loan_application(**values)['valid'])
		created=submit_ess_loan_application(**values)
		self.assertEqual(frappe.db.get_value('Karyo Loan',created['name'],'appraisal_payroll_period'),self.period)
		doc=frappe.get_doc('Employee',self.employee.name);doc.load_doc_before_save();doc.karyo_loan_payroll_period=None
		with self.assertRaises(frappe.PermissionError):validate_employee_period(doc)

	def test_period_options_include_unclosed_period_but_never_other_company(self):
		from karyo.loan.employee_period import period_options, validate_employee_period
		frappe.set_user('Administrator')
		frappe.db.set_value('Payroll Cycle',self.cycle,'status','Draft')
		foreign=frappe.db.get_value('Company',{'name':['!=',self.employee.company]},'name')
		if not foreign:
			foreign="ESS-foreign-"+self.token
			frappe.get_doc({"doctype":"Company","name":foreign,"company_name":foreign,"abbr":"FX"+self.token[:4],"default_currency":"MUR"}).db_insert()
		other='ESS-other-'+self.token
		frappe.get_doc({'doctype':'Payroll Period','name':other,'company':foreign,'start_date':nowdate(),'end_date':add_days(nowdate(),30)}).db_insert()
		options={p.value for p in period_options(self.employee.name)}
		self.assertIn(self.period,options);self.assertNotIn(other,options)
		doc=frappe.get_doc('Employee',self.employee.name);doc.karyo_loan_payroll_period=other
		with self.assertRaises(frappe.ValidationError):validate_employee_period(doc)
		frappe.set_user(self.email)
		preview=preview_ess_loan_application(**self.values)
		self.assertFalse(preview['valid'])
		with self.assertRaises(frappe.ValidationError):submit_ess_loan_application(**self.values)

	def test_individually_closed_payroll_allows_eligible_ess_application(self):
		from karyo.payroll.employee_processing import mark
		from karyo.payroll.employee_closing import close_employees
		frappe.set_user('Administrator')
		frappe.db.set_value('Payroll Cycle',self.cycle,'status','Processing')
		cycle=frappe.get_doc('Payroll Cycle',self.cycle)
		mark(cycle,self.employee.name,status='Processed',salary_slip='ESS-salary-'+self.token)
		frappe.db.set_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle,'employee':self.employee.name},'employee_approved_on',frappe.utils.now_datetime())
		frappe.get_doc({'doctype':'Payroll Statutory Result','name':'ESS-statutory-'+self.token,'payroll_cycle':self.cycle,'employee':self.employee.name,'result_type':'PAYE','status':'Applied'}).db_insert()
		result=close_employees(self.cycle,[self.employee.name])
		self.assertEqual(result['closed'],[self.employee.name])
		self.assertEqual(result['cycle_status'],'Processing')
		frappe.set_user(self.email)
		preview=preview_ess_loan_application(**self.values)
		self.assertTrue(preview['valid'],preview.get('message'))
		created=submit_ess_loan_application(**self.values)
		self.assertEqual(created['workflow_state'],'Approval Pending')
		self.assertEqual(frappe.db.get_value('Karyo Loan',created['name'],'appraisal_payroll_cycle'),self.cycle)

	def test_ess_period_is_automatic_and_cannot_be_overridden(self):
		values={key:value for key,value in self.values.items() if key!='payroll_period'}
		preview=preview_ess_loan_application(**values)
		self.assertTrue(preview['valid'],preview.get('message'))
		self.assertEqual(preview['payroll_period'],self.period)
		values['payroll_period']='UNAUTHORIZED-PERIOD'
		preview=preview_ess_loan_application(**values)
		self.assertTrue(preview['valid'],preview.get('message'))
		self.assertEqual(preview['payroll_period'],self.period)
		created=submit_ess_loan_application(**values)
		self.assertEqual(frappe.db.get_value('Karyo Loan',created['name'],'appraisal_payroll_period'),self.period)

	def test_unbacked_configured_period_does_not_mask_eligible_payroll(self):
		from karyo.desk.overview import my_loans
		pending='ESS-pending-'+self.token
		frappe.set_user('Administrator')
		frappe.get_doc({'doctype':'Payroll Period','name':pending,'company':self.employee.company,'start_date':nowdate(),'end_date':add_days(nowdate(),30)}).db_insert()
		frappe.db.set_value('Employee',self.employee.name,'karyo_loan_payroll_period',pending)
		frappe.set_user(self.email)
		self.assertEqual(my_loans()['default_payroll_period'],self.period)
		preview=preview_ess_loan_application(**self.values)
		self.assertTrue(preview['valid'],preview.get('message'))
		self.assertEqual(preview['payroll_period'],self.period)
		created=submit_ess_loan_application(**self.values)
		self.assertEqual(frappe.db.get_value('Karyo Loan',created['name'],'appraisal_payroll_period'),self.period)
