"""Persisted payroll readiness checks with remediation links."""

import hashlib

import frappe
from frappe import _
from frappe.utils import flt, getdate, now_datetime

from karyo.payroll.banking import get_employee_bank_readiness


def issue(code, severity, message, remediation_doctype=None, remediation_name=None, **values):
	return {
		"validation_code": code,
		"severity": severity,
		"message": message,
		"remediation_doctype": remediation_doctype,
		"remediation_name": remediation_name,
		**values,
	}


def get_cycle_employees(cycle):
	pay_day_master = frappe.db.get_value("Payroll Pay Day", cycle.pay_day, "pay_day_master")
	filters = {
		"company": cycle.company,
		"date_of_joining": ("<=", cycle.end_date),
		"karyo_payroll_type": cycle.payroll_type,
	}
	if pay_day_master:
		filters["karyo_pay_day"] = pay_day_master
	employees = frappe.get_all(
		"Employee",
		filters=filters,
		pluck="name",
		order_by="name",
	)
	excluded = set(frappe.get_all(
		"Payroll Cycle Employee",
		filters={"payroll_cycle": cycle.name, "status": "Excluded"},
		pluck="employee",
	))
	return [employee for employee in employees if employee not in excluded]


def salary_assignment_required_from(cycle, joining_date=None):
	"""Return the start date used by Salary Slip assignment selection."""
	required_from = getdate(cycle.start_date)
	if joining_date:
		joining_date = getdate(joining_date)
		if required_from <= joining_date <= getdate(cycle.end_date):
			required_from = joining_date
	return required_from


def validate_employee(cycle, employee_name):
	employee = frappe.db.get_value(
		"Employee",
		employee_name,
		[
			"status",
			"date_of_joining",
			"relieving_date",
			"karyo_post_exit_payroll_enabled", "karyo_post_exit_payroll_until", "karyo_post_exit_payment_reference",
			"salary_mode",
			"pan_number",
			"payroll_cost_center",
			"karyo_prb_opted_in",
			"karyo_prb_grade",
			"karyo_prb_salary_point",
			"karyo_payroll_setup_pending_activation",
		],
		as_dict=True,
	)
	if not employee:
		return [issue("EMPLOYEE_MISSING", "Blocking", _("Employee record no longer exists."))]
	issues = []
	from karyo.desk.payroll_management import employee_run_eligibility
	if not employee_run_eligibility(employee, cycle.start_date, cycle.end_date)["eligible"]:
		return [
			issue(
				"EMPLOYEE_INACTIVE",
				"Warning",
				_("Employee is outside the active payroll population and has been retained as an exclusion."),
				"Employee",
				employee_name,
				excluded_doctype="Employee",
				excluded_name=employee_name,
			)
		]
	if employee.karyo_payroll_setup_pending_activation:
		return [
			issue(
				"EMPLOYEE_PAYROLL_SETUP_PENDING",
				"Warning",
				_("Employee payroll setup is still pending and is excluded until setup is completed."),
				"Employee",
				employee_name,
				excluded_doctype="Employee",
				excluded_name=employee_name,
			)
		]
	# Salary Slip uses the employee's joining date as the actual period start
	# when the employee joins during this payroll cycle. Readiness must use the
	# same date; checking the calendar start incorrectly blocks valid new hires.
	required_from = salary_assignment_required_from(cycle, employee.date_of_joining)
	assignment = frappe.db.get_value(
		"Salary Structure Assignment",
		{
			"employee": employee_name,
			"company": cycle.company,
			"from_date": ("<=", required_from),
			"docstatus": 1,
		},
		["name", "salary_structure", "base"],
		order_by="from_date desc",
		as_dict=True,
	)
	if not assignment:
		issues.append(
			issue(
				"SALARY_ASSIGNMENT_MISSING",
				"Blocking",
				_("No submitted Salary Structure Assignment is effective from {0}.").format(
					frappe.format(required_from, {"fieldtype": "Date"})
				),
				"Salary Structure Assignment",
				None,
			)
		)
	else:
		basic_pdb = frappe.db.get_value(
			"PRB Payroll Component Mapping",
			{"component_code": "BASIC", "is_active": 1},
			"pdb_code",
		)
		basic_component = (
			frappe.db.get_value("Payroll PDB Code", basic_pdb, "salary_component")
			if basic_pdb else None
		)
		if (
			basic_component
			and frappe.db.exists("Salary Detail", {
				"parent": assignment.salary_structure,
				"parenttype": "Salary Structure",
				"parentfield": "earnings",
				"salary_component": basic_component,
			})
			and flt(assignment.base) <= 0
		):
			issues.append(
				issue(
					"SALARY_ASSIGNMENT_BASE_INVALID",
					"Blocking",
					_("Salary Structure Assignment {0} has zero Basic Pay for a structure that uses {1}.").format(
						assignment.name, basic_component
					),
					"Salary Structure Assignment",
					assignment.name,
				)
			)
		appointments = frappe.db.sql(
			"""select name, salary_structure, basic_salary
			from `tabEmployee Salary Appointment`
			where employee=%s and docstatus=1 and effective_from<=%s
			and coalesce(effective_to, '9999-12-31')>=%s
			order by effective_from desc limit 1""",
			(employee_name, cycle.end_date, cycle.end_date),
			as_dict=True,
		)
		appointment = appointments[0] if appointments else None
		if appointment and (
			assignment.salary_structure != appointment.salary_structure
			or abs(flt(assignment.base) - flt(appointment.basic_salary)) >= 0.005
		):
			issues.append(
				issue(
					"SALARY_ASSIGNMENT_BASE_MISMATCH",
					"Blocking",
					_(
						"Salary Structure Assignment {0}, used from {1}, does not match "
						"approved Salary Appointment {2} (base {3})."
					).format(
						assignment.name,
						frappe.format(required_from, {"fieldtype": "Date"}),
						appointment.name,
						frappe.format(appointment.basic_salary, {"fieldtype": "Currency"}),
					),
					"Salary Structure Assignment",
					assignment.name,
				)
			)
		issues.extend(_validate_pdb_mappings(assignment.salary_structure, employee_name))
	bank = get_employee_bank_readiness(employee_name, cycle.payment_date)
	for message in bank["errors"]:
		issues.append(issue("BANK_DETAILS_INVALID", "Blocking", message, "Employee", employee_name))
	if not employee.pan_number:
		issues.append(
			issue(
				"TAX_IDENTIFIER_MISSING",
				"Approval Required",
				_("Employee tax identifier is missing."),
				"Employee",
				employee_name,
			)
		)
	if not employee.payroll_cost_center:
		issues.append(
			issue(
				"COST_CENTER_MISSING",
				"Approval Required",
				_("Payroll cost centre is missing."),
				"Employee",
				employee_name,
			)
		)
	issues.extend(_prb_readiness_issues(employee, employee_name))
	issues.extend(_duplicate_transaction_issues(cycle, employee_name))
	return issues


def _prb_readiness_issues(employee, employee_name):
	"""Treat an explicit unchecked PRB flag as Not Applicable.

	A Check field has only two saved states, so zero is the governed negative
	answer rather than an unknown third state. Employees marked applicable must
	still have a complete grade and salary point.
	"""
	applicable = bool(employee.karyo_prb_opted_in)
	if not applicable:
		return []
	grade = bool(employee.karyo_prb_grade)
	point = bool(employee.karyo_prb_salary_point)
	if not (grade and point):
		return [issue(
			"PRB_GRADE_POINT_INCOMPLETE",
			"Blocking",
			_("Employees marked PRB applicable must have both a PRB grade and salary point."),
			"Employee",
			employee_name,
		)]
	return []


def _validate_pdb_mappings(salary_structure, employee):
	components = frappe.get_all(
		"Salary Detail",
		filters={"parent": salary_structure, "parenttype": "Salary Structure"},
		pluck="salary_component",
	)
	issues = []
	for component in sorted(set(components)):
		if not frappe.db.exists("Payroll PDB Code", {"salary_component": component, "is_active": 1}):
			issues.append(
				issue(
					"PDB_MAPPING_MISSING",
					"Blocking",
					_("Salary Component {0} has no active PDB mapping.").format(component),
					"Salary Component",
					component,
					excluded_doctype="Salary Component",
					excluded_name=component,
				)
			)
	return issues


def _duplicate_transaction_issues(cycle, employee):
	rows = frappe.get_all(
		"Payroll Transaction Allocation",
		filters={
			"employee": employee,
			"pay_period_label": cycle.pay_period_label,
			"status": ("in", ["Reserved", "Paid"]),
			"payroll_cycle": ("!=", cycle.name),
		},
		fields=[
			"name", "source_doctype", "source_name", "payroll_cycle",
			"payroll_type", "pay_period_label", "status", "reconciled_in_major_cycle",
		],
	)
	# A paid Minor once-off is an expected input to the matching Major run.
	# reserve_transaction() reconciles it instead of paying it twice, so the
	# readiness screen must not reject the exact hand-off that sequencing allows.
	rows = [
		row for row in rows
		if not (
			cycle.payroll_type == "Major"
			and row.payroll_type == "Minor"
			and row.pay_period_label == cycle.pay_period_label
			and (
				row.status == "Paid"
				or (row.status == "Reconciled" and row.reconciled_in_major_cycle == cycle.name)
			)
		)
	]
	return [
		issue(
			"DUPLICATE_TRANSACTION",
			"Blocking",
			_("Transaction {0} is already allocated to another payroll run.").format(row.source_name),
			row.source_doctype,
			row.source_name,
			excluded_doctype=row.source_doctype,
			excluded_name=row.source_name,
		)
		for row in rows
	]


@frappe.whitelist()
def run_readiness(payroll_cycle, employees=None, update_cycle=True):
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if cycle.docstatus == 2:
		frappe.throw(_("Cancelled Payroll Cycles cannot be revalidated."))
	employees = employees or get_cycle_employees(cycle)
	if isinstance(employees, str):
		employees = frappe.parse_json(employees)
	now = now_datetime()
	seen = set()
	for employee in employees:
		for result in validate_employee(cycle, employee):
			fingerprint = _fingerprint(cycle.name, employee, result)
			seen.add(fingerprint)
			_upsert_exception(cycle.name, employee, fingerprint, result, now)
	_open_stale_exceptions(cycle.name, employees, seen, now)
	# An explicit run exclusion is a governed population decision. Its former
	# readiness issues remain auditable but must not keep the remaining cycle
	# blocked after the employee has been removed from this run.
	excluded = frappe.get_all(
		"Payroll Cycle Employee",
		filters={"payroll_cycle": cycle.name, "status": "Excluded"},
		pluck="employee",
	)
	if excluded:
		frappe.db.set_value(
			"Payroll Readiness Exception",
			{"payroll_cycle": cycle.name, "employee": ("in", excluded), "status": "Open"},
			{
				"status": "Resolved",
				"resolution_note": _("Resolved because the employee was explicitly excluded from this payroll run."),
				"resolved_by": frappe.session.user,
				"resolved_on": now,
			},
			update_modified=False,
		)
	counts = get_open_counts(cycle.name)
	if update_cycle:
		frappe.db.set_value(
			"Payroll Cycle",
			cycle.name,
			{
				"readiness_status": "Blocked" if counts["blocking"] else "Ready",
				"readiness_checked_on": now,
				"employee_count": len(employees),
				"exception_count": counts["blocking"],
			},
			update_modified=False,
		)
	return {"employees": len(employees), **counts}


def _fingerprint(cycle, employee, result):
	raw = "::".join(
		str(value or "")
		for value in (
			cycle,
			employee,
			result["validation_code"],
			result.get("excluded_doctype"),
			result.get("excluded_name"),
			result["message"],
		)
	)
	return hashlib.sha256(raw.encode()).hexdigest()


def _upsert_exception(cycle, employee, fingerprint, result, checked_on):
	existing = frappe.db.get_value(
		"Payroll Readiness Exception", {"fingerprint": fingerprint}, ["name", "status"], as_dict=True
	)
	values = {
		"payroll_cycle": cycle,
		"employee": employee,
		"fingerprint": fingerprint,
		"status": "Waived" if existing and existing.status == "Waived" else "Open",
		"last_checked_on": checked_on,
		**result,
	}
	if existing:
		frappe.db.set_value("Payroll Readiness Exception", existing.name, values, update_modified=False)
	else:
		frappe.get_doc({"doctype": "Payroll Readiness Exception", **values}).insert(
			ignore_permissions=True
		)


def _open_stale_exceptions(cycle, employees, seen, checked_on):
	for row in frappe.get_all(
		"Payroll Readiness Exception",
		filters={"payroll_cycle": cycle, "employee": ("in", employees), "status": "Open"},
		fields=["name", "fingerprint"],
	):
		if row.fingerprint not in seen:
			frappe.db.set_value(
				"Payroll Readiness Exception",
				row.name,
				{
					"status": "Resolved",
					"resolution_note": "Resolved by readiness revalidation",
					"resolved_by": frappe.session.user,
					"resolved_on": checked_on,
				},
				update_modified=False,
			)


def get_open_counts(cycle):
	rows = frappe.get_all(
		"Payroll Readiness Exception",
		filters={"payroll_cycle": cycle, "status": "Open"},
		fields=["severity", "count(name) as count"],
		group_by="severity",
	)
	counts = {"blocking": 0, "approval_required": 0, "warnings": 0}
	keys = {"Blocking": "blocking", "Approval Required": "approval_required", "Warning": "warnings"}
	for row in rows:
		counts[keys[row.severity]] = row.count
	counts["blocking"] += counts["approval_required"]
	return counts
