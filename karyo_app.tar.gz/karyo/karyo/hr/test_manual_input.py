"""Governed administrator manual attendance and payroll input coverage."""

from datetime import timedelta
from unittest.mock import patch

import frappe
from erpnext.setup.doctype.employee.employee import is_holiday
from frappe.tests.utils import FrappeTestCase
from frappe.utils import add_days, getdate, nowdate

from karyo.desk.hr_surface import actions
from karyo.hr.clocking import _additional_hours_by_employee_date, employee_checkin_daily_status
from karyo.hr.manual_input import (
	create_manual_input,
	delete_manual_attendance,
	manual_additional_hours_context,
	attendance_edit_detail,
	manual_attendance_detail,
	manual_attendance_rows,
	manual_bonus_context,
	manual_entry_context,
	update_manual_input,
)
from karyo.payroll.attendance_bonus import presence_leave_units
from karyo.prb.allowances import attendance_bonus


class TestManualAttendanceInput(FrappeTestCase):
	def setUp(self):
		self.previous_user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("manual_attendance_input")

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="manual_attendance_input")
		frappe.set_user(self.previous_user)

	def _employee_and_free_day(self):
		rows = frappe.get_all(
			"Employee",
			filters={"status": "Active", "default_shift": ("is", "set")},
			fields=["name", "date_of_joining"],
			order_by="date_of_joining asc",
			limit_page_length=100,
		)
		for employee in rows:
			date = self._free_day_for_employee(employee.name)
			if date:
				return employee.name, date
		self.skipTest("No active employee and unused duty date fixture")

	def _free_day_for_employee(self, employee):
		joining = frappe.db.get_value("Employee", employee, "date_of_joining")
		start = max(getdate(joining), getdate(add_days(nowdate(), -730)))
		for offset in range(730):
			date = start + timedelta(days=offset)
			if date >= getdate(nowdate()):
				break
			if frappe.db.exists("Attendance", {"employee": employee, "attendance_date": date, "docstatus": ("!=", 2)}):
				continue
			if is_holiday(employee, date, raise_exception=False):
				continue
			return date
		return None

	@patch("erpnext.setup.doctype.employee.employee.is_holiday", return_value=False)
	@patch("frappe.get_all")
	def test_bonus_absence_units_merge_approved_leave_without_double_counting_attendance(self, get_all, _holiday):
		def rows(doctype, **_kwargs):
			if doctype == "Attendance":
				return [frappe._dict(attendance_date=getdate("2026-09-01"), status="Absent")]
			if doctype == "Leave Application":
				return [frappe._dict(
					name="LEAVE-1", from_date=getdate("2026-09-01"), to_date=getdate("2026-09-03"),
					half_day=0, half_day_date=None, total_leave_days=3,
				)]
			return []

		get_all.side_effect = rows
		result = presence_leave_units("EMP-1", "2026-09-01", "2026-09-30")
		self.assertEqual(result.attendance, 1)
		self.assertEqual(result.approved_leave, 3)
		self.assertEqual(result.total, 3)
		self.assertEqual(attendance_bonus(result.total), 0)

	def test_present_manual_input_uses_shift_window_and_creates_audited_checkins(self):
		employee, date = self._employee_and_free_day()
		context = manual_entry_context(employee, date)
		self.assertTrue(context["shift"])
		self.assertTrue(context["clock_in"])
		self.assertTrue(context["clock_out"])
		result = create_manual_input({
			"entry_type": "Attendance",
			"employee": employee,
			"attendance_date": date,
			"status": "Present",
			"manual_reference": "TEST-MANUAL-SHIFT",
		})
		self.assertEqual(len(result["created"]), 1)
		attendance = frappe.get_doc("Attendance", result["created"][0]["name"])
		self.assertEqual(attendance.docstatus, 1)
		self.assertEqual(attendance.custom_entry_source, "Manual Input")
		self.assertEqual(attendance.custom_manual_by, "Administrator")
		self.assertEqual(attendance.custom_attendance_remark, "Manually Adjusted")
		self.assertEqual(attendance.shift, context["shift"])
		self.assertAlmostEqual(attendance.working_hours, context["duty_hours"], places=2)
		checkins = frappe.get_all(
			"Employee Checkin",
			filters={"attendance": attendance.name},
			fields=["log_type", "custom_entry_source", "custom_manual_reference"],
			order_by="time asc",
		)
		self.assertEqual([row.log_type for row in checkins], ["IN", "OUT"])
		self.assertTrue(all(row.custom_entry_source == "Manual Input" for row in checkins))
		self.assertTrue(all(row.custom_manual_reference == "TEST-MANUAL-SHIFT" for row in checkins))

	def test_bulk_manual_attendance_uses_each_dated_shift_and_skips_existing_days(self):
		employee, date = self._employee_and_free_day()
		result = create_manual_input({
			"entry_type": "Attendance",
			"employee": employee,
			"from_date": date,
			"to_date": add_days(date, 1),
			"status": "Present",
			"manual_reference": "TEST-MANUAL-BULK",
		})
		self.assertGreaterEqual(len(result["created"]), 1)
		self.assertEqual(len(result["created"]) + len(result["skipped"]), 2)
		for created in result["created"]:
			attendance = frappe.get_doc("Attendance", created["name"])
			self.assertEqual(attendance.custom_attendance_remark, "Manually Adjusted")
			self.assertTrue(attendance.shift)
			self.assertGreater(attendance.working_hours, 0)

	def test_manual_attendance_register_edit_and_delete_stay_synchronized(self):
		employee, date = self._employee_and_free_day()
		created = create_manual_input({
			"entry_type": "Attendance", "employee": employee, "attendance_date": date,
			"status": "Present", "manual_reference": "TEST-MANUAL-REGISTER",
		})
		name = created["created"][0]["name"]
		doc = frappe.get_doc("Attendance", name)
		new_out = doc.out_time - timedelta(hours=1)
		updated = update_manual_input(name, {
			"entry_type": "Attendance", "employee": employee, "attendance_date": date,
			"status": "Present", "clock_in": doc.in_time, "clock_out": new_out,
			"manual_reference": "TEST-MANUAL-REGISTER-EDIT",
		})
		self.assertEqual(updated["name"], name)
		self.assertAlmostEqual(updated["working_hours"], doc.working_hours - 1, places=4)
		self.assertEqual(frappe.db.count("Employee Checkin", {"attendance": name}), 2)
		row = next(row for row in manual_attendance_rows()["rows"] if row.name == name)
		self.assertEqual(row.custom_attendance_remark, "Manually Adjusted")
		self.assertEqual(row.custom_manual_reference, "TEST-MANUAL-REGISTER-EDIT")
		for field in ("overtime_hours", "excess_hours", "night_duty_hours", "total_hours", "attendance_bonus", "incentive_bonus"):
			self.assertIn(field, row)
		detail = manual_attendance_detail(name)
		self.assertEqual(detail["employee"], employee)
		self.assertEqual(detail["attendance_date"], date)
		self.assertEqual(detail["clock_out"], new_out)
		deleted = delete_manual_attendance(name)
		self.assertEqual(deleted["name"], name)
		self.assertFalse(frappe.db.exists("Attendance", name))
		self.assertEqual(frappe.db.count("Employee Checkin", {"attendance": name}), 0)

	def test_automatic_attendance_uses_shared_editor_and_becomes_audited_adjustment(self):
		employee, date = self._employee_and_free_day()
		created = create_manual_input({
			"entry_type": "Attendance", "employee": employee, "attendance_date": date,
			"status": "Present", "manual_reference": "TEST-AUTOMATIC-SEED",
		})
		name = created["created"][0]["name"]
		frappe.db.set_value("Attendance", name, {
			"custom_entry_source": "Automatic Clocking",
			"custom_attendance_remark": "Automatic (ESS Clock In/Out)",
			"custom_manual_reference": None,
		}, update_modified=False)
		for checkin in frappe.get_all("Employee Checkin", filters={"attendance": name}, pluck="name"):
			frappe.db.set_value("Employee Checkin", checkin, {
				"custom_entry_source": "Automatic Clocking", "custom_manual_reference": None,
			}, update_modified=False)

		detail = attendance_edit_detail(name)
		self.assertEqual(detail["entry_source"], "Automatic Clocking")
		self.assertEqual(detail["employee"], employee)
		new_out = detail["clock_out"] - timedelta(minutes=30)
		result = update_manual_input(name, {
			"entry_type": "Attendance", "employee": employee, "attendance_date": date,
			"status": "Half Day", "clock_in": detail["clock_in"], "clock_out": new_out,
			"manual_reference": "TEST-AUTOMATIC-CORRECTION",
		})
		self.assertEqual(result["name"], name)
		attendance = frappe.get_doc("Attendance", name)
		self.assertEqual(attendance.status, "Half Day")
		self.assertEqual(attendance.out_time, new_out)
		self.assertEqual(attendance.custom_entry_source, "Manual Input")
		self.assertEqual(attendance.custom_attendance_remark, "Manually Adjusted")
		checkins = frappe.get_all(
			"Employee Checkin", filters={"attendance": name},
			fields=["log_type", "time", "custom_entry_source", "custom_manual_reference"], order_by="time asc",
		)
		self.assertEqual(len(checkins), 2)
		self.assertEqual([row.log_type for row in checkins], ["IN", "OUT"])
		self.assertEqual(checkins[-1].time, new_out)
		self.assertTrue(all(row.custom_entry_source == "Manual Input" for row in checkins))
		self.assertTrue(all(row.custom_manual_reference == "TEST-AUTOMATIC-CORRECTION" for row in checkins))

	def test_backdated_night_duty_runs_existing_eligibility_engine(self):
		employee = frappe.db.get_value(
			"Employee", {"status": "Active", "default_shift": ("is", "set")}, "name"
		)
		if not employee:
			self.skipTest("No active employee fixture")
		date = getdate(add_days(nowdate(), -14))
		result = create_manual_input({
			"entry_type": "Night Duty",
			"employee": employee,
			"clock_in": f"{date} 23:00:00",
			"clock_out": f"{add_days(date, 1)} 05:00:00",
			"overtime_period": "weekday_night",
			"manual_reference": "TEST-MANUAL-NIGHT",
		})
		doc = frappe.get_doc("PRB Overtime Authorization", result["name"])
		self.assertEqual(doc.docstatus, 1)
		self.assertEqual(doc.authorization_status, "Recorded")
		self.assertEqual(doc.custom_entry_source, "Manual Input")
		self.assertEqual(doc.actual_hours, 6)
		self.assertTrue(doc.eligibility_reason)

	def test_additional_hours_preview_returns_requested_eligible_and_projected_total(self):
		employee = frappe.db.get_value(
			"Employee", {"status": "Active", "default_shift": ("is", "set")}, "name"
		)
		if not employee:
			self.skipTest("No active employee fixture")
		before = frappe.db.count("PRB Overtime Authorization")
		result = manual_additional_hours_context(
			employee=employee,
			attendance_date=add_days(nowdate(), -14),
			entry_type="Overtime",
			requested_hours=2,
		)
		self.assertEqual(result["requested_hours"], 2)
		self.assertGreaterEqual(result["eligible_hours"], 0)
		self.assertAlmostEqual(
			result["projected_total_hours"], result["base_hours"] + result["eligible_hours"], places=4
		)
		self.assertEqual(frappe.db.count("PRB Overtime Authorization"), before)

	def test_eligible_additional_hours_extend_clock_out_and_total(self):
		rows = frappe.db.sql(
			"""select e.name, e.date_of_joining
			from `tabEmployee` e
			join `tabEmployee Work Pattern` wp on wp.name=e.karyo_work_pattern
			where e.status='Active' and coalesce(e.default_shift, '')!=''
				and coalesce(wp.prb_group, '') not in ('shift', 'roster', 'staggered')
			order by e.name""", as_dict=True,
		)
		fixture = None
		for employee in rows:
			start = max(getdate(employee.date_of_joining), getdate(add_days(nowdate(), -365)))
			for offset in range(365):
				date = getdate(add_days(start, offset))
				if date >= getdate(nowdate()):
					break
				if not frappe.db.exists("Attendance", {"employee": employee.name, "attendance_date": date, "docstatus": ("!=", 2)}):
					fixture = (employee.name, date)
					break
			if fixture:
				break
		if not fixture:
			self.skipTest("No non-shift employee with a free back date")
		employee, date = fixture
		attendance_result = create_manual_input({
			"entry_type": "Attendance", "employee": employee, "attendance_date": date,
			"status": "Present", "manual_reference": "TEST-BASE-FOR-NIGHT",
		})
		attendance_name = attendance_result["created"][0]["name"]
		before = frappe.db.get_value("Attendance", attendance_name, ["out_time", "working_hours"], as_dict=True)
		result = create_manual_input({
			"entry_type": "Night Duty", "employee": employee, "attendance_date": date,
			"clock_in": f"{date} 23:00:00", "requested_hours": 2,
			"overtime_period": "weekday_night", "manual_reference": "TEST-NIGHT-EXTENSION",
		})
		self.assertEqual(result["approved_hours"], 2)
		after = frappe.db.get_value("Attendance", attendance_name, ["out_time", "working_hours"], as_dict=True)
		self.assertEqual(after.out_time, before.out_time + timedelta(hours=2))
		self.assertAlmostEqual(after.working_hours, before.working_hours + 2, places=4)
		mapped = _additional_hours_by_employee_date([
			frappe._dict(employee=employee, attendance_date=date)
		])[(employee, date)]
		self.assertEqual(mapped["night_duty_status"], "Eligible")
		self.assertEqual(mapped["night_duty_hours"], 2)
		detail = manual_attendance_detail(attendance_name)
		self.assertEqual(detail["additional_inputs"]["Night Duty"]["claimed_hours"], 2)
		created_claim = frappe.get_doc("PRB Overtime Authorization", result["name"])
		self.assertEqual(created_claim.custom_entry_source, "Manual Input")
		self.assertEqual(getdate(created_claim.actual_start), date)
		claims_before_update = set(frappe.get_all(
			"PRB Overtime Authorization",
			filters={"employee": employee, "claim_type": "Night Duty", "custom_entry_source": "Manual Input"},
			pluck="name",
		))
		updated = update_manual_input(attendance_name, {
			"entry_type": "Night Duty", "employee": employee, "attendance_date": date,
			"requested_hours": 1, "overtime_period": "weekday_night",
			"manual_reference": "TEST-NIGHT-EXTENSION-EDIT",
		})
		self.assertEqual(updated["name"], result["name"])
		self.assertIn(updated["approved_hours"], {0, 1})
		self.assertEqual(set(frappe.get_all(
			"PRB Overtime Authorization",
			filters={"employee": employee, "claim_type": "Night Duty", "custom_entry_source": "Manual Input"},
			pluck="name",
		)), claims_before_update)
		after_update = frappe.db.get_value("Attendance", attendance_name, ["out_time", "working_hours"], as_dict=True)
		self.assertEqual(after_update.out_time, before.out_time + timedelta(hours=updated["approved_hours"]))
		self.assertAlmostEqual(after_update.working_hours, before.working_hours + updated["approved_hours"], places=4)

	def test_employee_checkin_daily_status_includes_active_employees_without_logs(self):
		result = employee_checkin_daily_status(nowdate())
		self.assertEqual(result["date"], getdate(nowdate()))
		self.assertEqual(result["total"], len(result["rows"]))
		if result["rows"]:
			self.assertEqual(
				{"employee", "employee_name", "shift", "clock_in", "clock_out", "clock_status"},
				set(result["rows"][0]),
			)

	def test_manual_bonus_creates_draft_using_configured_formula_base(self):
		cycle = frappe.db.get_value(
			"Payroll Cycle", {"docstatus": ("<", 2), "status": ("not in", ["Closed", "Cancelled"])},
			["name", "company", "payment_date"], as_dict=True, order_by="end_date desc",
		)
		if not cycle:
			self.skipTest("No open Payroll Cycle fixture")
		employee = frappe.db.get_value(
			"Employee", {"status": "Active", "company": cycle.company, "default_shift": ("is", "set")}, "name"
		)
		if not employee:
			self.skipTest("No active employee in Payroll Cycle company")
		preview = manual_bonus_context(employee, cycle.name, "Incentive Attendance Bonus")
		self.assertIn(preview["eligibility_status"], {"Eligible", "Not Eligible"})
		self.assertTrue(preview["eligibility_reason"])
		result = create_manual_input({
			"entry_type": "Incentive Attendance Bonus",
			"employee": employee,
			"attendance_date": cycle.payment_date,
			"payroll_cycle": cycle.name,
			"manual_reference": "TEST-MANUAL-BONUS",
		})
		doc = frappe.get_doc("PRB Payroll Run", result["name"])
		self.assertEqual(doc.docstatus, 0)
		self.assertEqual(doc.run_purpose, "Incentive Attendance Bonus")
		self.assertEqual(doc.custom_entry_source, "Manual Input")
		self.assertEqual(doc.custom_eligibility_status, preview["eligibility_status"])
		self.assertEqual(doc.custom_eligibility_reason, preview["eligibility_reason"])
		self.assertEqual(doc.employee_inputs[0].input_code, "INCENTIVE_ATTENDANCE")
		self.assertGreater(doc.employee_inputs[0].amount, 0)
		date = self._free_day_for_employee(employee)
		if not date:
			self.skipTest("No free past attendance date for the bonus employee")
		attendance = create_manual_input({
			"entry_type": "Attendance", "employee": employee, "attendance_date": date,
			"status": "Present", "manual_reference": "TEST-BONUS-EDIT-ANCHOR",
		})["created"][0]["name"]
		updated = update_manual_input(attendance, {
			"entry_type": "Incentive Attendance Bonus", "employee": employee,
			"attendance_date": date, "payroll_cycle": cycle.name,
			"incentive_attendance_bonus_base": 1234,
			"manual_reference": "TEST-MANUAL-BONUS-EDIT",
		})
		self.assertEqual(updated["name"], result["name"])
		doc.reload()
		self.assertEqual(doc.employee_inputs[0].amount, 1234)
		detail = manual_attendance_detail(attendance)
		self.assertEqual(detail["bonus_inputs"]["Incentive Attendance Bonus"]["name"], doc.name)
		self.assertEqual(
			detail["bonus_inputs"]["Incentive Attendance Bonus"]["base_amounts"]["INCENTIVE_ATTENDANCE"],
			1234,
		)

	def test_employee_checkin_action_probe_is_silent_and_read_only(self):
		name = frappe.db.get_value("Employee Checkin", {}, "name", order_by="modified desc")
		if not name:
			self.skipTest("No Employee Checkin fixture")
		user = "mbc.admin@mbc.mu"
		if not frappe.db.exists("User", user):
			self.skipTest("MBC administrator fixture unavailable")
		frappe.set_user(user)
		try:
			frappe.clear_messages()
			result = actions("Employee Checkin", [name])
			self.assertEqual(result[name], {"edit": False, "delete": False})
			self.assertFalse(frappe.get_message_log())
		finally:
			frappe.set_user("Administrator")

	def test_synthetic_attendance_rows_are_ignored_by_action_probe(self):
		self.assertEqual(actions("Attendance", ["live-team-2026-09-22-HR-EMP-00032"]), {})
