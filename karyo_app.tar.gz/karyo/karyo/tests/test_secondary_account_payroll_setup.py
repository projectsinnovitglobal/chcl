"""Secondary-account setup persists to Employee and salary remittance."""
import unittest

import frappe
from karyo.tests import test_long_service_movements as fixtures
from karyo.payroll.salary_scales import complete_payroll_setup, _payroll_setup_snapshot
from karyo.payroll.bank_split import split_for_employee


class TestSecondaryAccountPayrollSetup(unittest.TestCase):
    setUp = fixtures.TestLongServiceMovements.setUp
    tearDown = fixtures.TestLongServiceMovements.tearDown
    make_scale = fixtures.TestLongServiceMovements.make_scale
    appointment = fixtures.TestLongServiceMovements.appointment

    def profile(self):
        profile = _payroll_setup_snapshot(self.employee.name)['profile']
        bank = frappe.db.get_value('Bank', {'karyo_payroll_active': 1}, 'name')
        branch = frappe.db.get_value('Payroll Bank Branch', {'bank': bank, 'is_active': 1}, 'name')
        profile.update(payment_mode='Bank', bank=bank, bank_branch=branch,
            bank_account='PRIMARY-TEST-' + self.uid, bank_account_is_primary=0,
            secondary_bank=bank, secondary_bank_branch=branch,
            secondary_bank_account='SECONDARY-TEST-' + self.uid,
            secondary_bank_account_holder='Isolated test account', secondary_bank_fixed_amount=1000,
            secondary_bank_effective_from='2026-01-01', secondary_bank_effective_to='2026-12-31')
        return profile

    def apply_profile(self, profile):
        return complete_payroll_setup([self.employee.name], profile, self.grade.name, '1', '2026-01-01',
            'Secondary payroll wizard TEST', salary_structure=self.structure,
            income_tax_slab=self.income_tax_slab, effective_to='2026-12-31')

    def test_secondary_fields_save_reload_and_feed_remittance(self):
        profile = self.profile()
        result = self.apply_profile(profile)
        self.assertFalse(result['failed'], result)
        persisted = _payroll_setup_snapshot(self.employee.name)['profile']
        for key in ['secondary_bank', 'secondary_bank_branch', 'secondary_bank_account',
                'secondary_bank_account_holder', 'secondary_bank_fixed_amount']:
            self.assertEqual(persisted[key], profile[key])
        self.assertEqual(persisted['bank_account_is_primary'], 0)
        split = split_for_employee(self.employee.name, 10000, '2026-10-01')
        self.assertEqual((split.primary_amount, split.secondary_amount), (9000, 1000))
        self.assertEqual(split.secondary_account, profile['secondary_bank_account'])
        capped = split_for_employee(self.employee.name, 500, '2026-10-01')
        self.assertEqual((capped.primary_amount, capped.secondary_amount), (0, 500))
        expired = split_for_employee(self.employee.name, 10000, '2027-01-01')
        self.assertEqual(expired.secondary_amount, 0)

    def test_partial_secondary_route_rolls_back_setup(self):
        profile = self.profile()
        profile['secondary_bank_account'] = ''
        before = _payroll_setup_snapshot(self.employee.name)['profile']
        result = self.apply_profile(profile)
        self.assertEqual(len(result['failed']), 1)
        self.assertIn('Secondary Account Number', result['failed'][0]['message'])
        self.assertEqual(before, _payroll_setup_snapshot(self.employee.name)['profile'])
        self.assertFalse(frappe.db.exists('Employee Salary Appointment', {'employee': self.employee.name}))

    def test_explicit_clearing_and_older_profile_preservation(self):
        profile = self.profile()
        self.assertFalse(self.apply_profile(profile)['failed'])
        # Existing clients without secondary keys must preserve the routing.
        older = {key: value for key, value in profile.items() if not key.startswith('secondary_')}
        self.assertFalse(self.apply_profile(older)['failed'])
        self.assertEqual(_payroll_setup_snapshot(self.employee.name)['profile']['secondary_bank_fixed_amount'], 1000)
        cleared = {**older, 'secondary_bank_fixed_amount': 0, 'secondary_bank_account': '',
            'secondary_bank_effective_to': ''}
        self.assertFalse(self.apply_profile(cleared)['failed'])
        persisted = _payroll_setup_snapshot(self.employee.name)['profile']
        self.assertEqual(persisted['secondary_bank_fixed_amount'], 0)
        self.assertFalse(persisted['secondary_bank_account'])
        self.assertFalse(persisted['secondary_bank_effective_to'])
        self.assertEqual(split_for_employee(self.employee.name, 10000, '2026-10-01').secondary_amount, 0)
