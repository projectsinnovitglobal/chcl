import unittest
from pathlib import Path

from karyo.tools.build_phase0_registers import collect_rules, infer_module, infer_version


class TestPhase0Registers(unittest.TestCase):
	def test_rule_metadata_inference(self):
		self.assertEqual(infer_module("MBC-LV-CAS-001"), "Leave")
		self.assertEqual(infer_module("MBC-PAY-TAX-001"), "Payroll")
		self.assertEqual(infer_version("Rules V1.0.docx"), "1.0")

	def test_empty_source_directory_has_no_rules(self):
		# Keep this test independent of proprietary source documents.
		self.assertEqual(collect_rules(Path("/path/which/does/not/exist")), [])
