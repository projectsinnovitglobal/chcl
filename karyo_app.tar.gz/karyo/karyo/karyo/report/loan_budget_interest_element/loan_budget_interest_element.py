import frappe
from frappe import _
from frappe.utils import getdate
from karyo.karyo.report.loan_report_utils import add_loan_permission_condition


def execute(filters=None):
	filters = frappe._dict(filters or {})
	_validate_filters(filters)

	month_wise = (filters.get("projection_view") or "Year-wise") == "Month-wise"
	period_select = (
		"year(s.due_date) budget_year, month(s.due_date) budget_month, "
		"date_format(s.due_date, '%%b') budget_month_name, "
		if month_wise
		else "year(s.due_date) budget_year, null budget_month, null budget_month_name, "
	)
	period_group = "year(s.due_date), month(s.due_date)" if month_wise else "year(s.due_date)"
	conditions = [
		"s.is_current = 1",
		"l.docstatus = 1",
		"l.status = 'Active'",
		"s.due_date between %(budget_from_date)s and %(budget_to_date)s",
	]
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	for field in ("company", "loan_type", "employee"):
		if filters.get(field):
			conditions.append(f"l.{field} = %({field})s")
	if filters.get("loan"):
		conditions.append("l.name = %(loan)s")

	rows = frappe.db.sql(
		f"""
		select {period_select}
			l.company, l.loan_type,
			count(distinct l.name) active_loans,
			count(s.name) scheduled_instalments,
			sum(s.interest) scheduled_interest,
			sum(least(coalesce(s.paid_interest, 0), s.interest)) interest_already_paid,
			sum(greatest(s.interest - coalesce(s.paid_interest, 0), 0)) projected_interest
		from `tabKaryo Loan Schedule` s
		inner join `tabKaryo Loan` l on l.name = s.parent
		where {' and '.join(conditions)}
		group by {period_group}, l.company, l.loan_type
		order by budget_year, budget_month, l.company, l.loan_type
		""",
		filters,
		as_dict=True,
	)
	for row in rows:
		row.period = (
			f"{row.budget_month_name} {row.budget_year}"
			if month_wise
			else str(row.budget_year)
		)
		row.currency = frappe.get_cached_value("Company", row.company, "default_currency")

	return _columns(), rows


def _validate_filters(filters):
	if not filters.get("budget_from_date") or not filters.get("budget_to_date"):
		frappe.throw(_("Budget From Date and Budget To Date are required."))
	if getdate(filters.budget_from_date) > getdate(filters.budget_to_date):
		frappe.throw(_("Budget From Date cannot be after Budget To Date."))
	if (filters.get("projection_view") or "Year-wise") not in ("Year-wise", "Month-wise"):
		frappe.throw(_("Projection View must be Year-wise or Month-wise."))


def _columns():
	def column(fieldname, label, fieldtype="Data", width=120, options=None):
		value = {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width}
		if options:
			value["options"] = options
		return value

	return [
		column("period", "Budget Period", width=110),
		column("budget_year", "Budget Year", "Int", 90),
		column("budget_month", "Month No.", "Int", 80),
		column("company", "Company", "Link", 150, "Company"),
		column("loan_type", "Loan Type", "Link", 145, "Loan Type"),
		column("active_loans", "Active Loans", "Int", 105),
		column("scheduled_instalments", "Instalments", "Int", 95),
		column("scheduled_interest", "Scheduled Interest", "Currency", 145, "currency"),
		column("interest_already_paid", "Interest Already Paid", "Currency", 150, "currency"),
		column("projected_interest", "Projected Interest", "Currency", 145, "currency"),
		column("currency", "Currency", width=85),
	]
