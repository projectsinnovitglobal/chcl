import unittest
from unittest.mock import patch
import frappe
from karyo.tests.test_employee_closing import TestEmployeeClosing
from karyo.payroll.employee_completion import run_step, state
from karyo.payroll.employee_processing import mark

class TestEmployeeCompletion(unittest.TestCase):
    def setUp(self):
        TestEmployeeClosing.setUp(self)
        frappe.db.set_value('Payroll Cycle',self.cycle.name,{'status':'Processing','docstatus':0,'exception_count':0})
        self.cycle.reload()
        for employee,slip in zip(self.employees,self.slips):
            frappe.db.set_value('Salary Slip',slip.name,'docstatus',0)
            mark(self.cycle,employee,status='Processed',salary_slip=slip.name)
        frappe.db.set_value('Payroll Statutory Result',{'payroll_cycle':self.cycle.name},'status','Calculated')
    tearDown=TestEmployeeClosing.tearDown
    def active(self,employees):
        self.cycle.reload()
        return [s['action'] for s in state(self.cycle,employees)['steps'] if s['available']]
    def test_single_then_group_review_approve_apply_submit_and_close(self):
        a,b=self.employees
        self.assertEqual(self.active([a]),['Send for Review'])
        for action in ('Send for Review','Review Statutory Results','Approve Payroll'):run_step(self.cycle.name,action,[a])
        self.assertFalse(frappe.db.get_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':b},'employee_approved_on'))
        with patch('karyo.payroll.statutory._refresh_and_reconcile_slips',return_value={}) as reconcile:
            run_step(self.cycle.name,'Apply Employee Deductions',[a])
            self.assertEqual(reconcile.call_args.kwargs['employees'],[a])
        submitted=[]
        def submit(slip):
            submitted.append(slip.employee);frappe.db.set_value('Salary Slip',slip.name,'docstatus',1)
        with patch.object(type(self.slips[0]),'submit',submit):run_step(self.cycle.name,'Submit Salary Slips',[a])
        self.assertEqual(submitted,[a])
        result=run_step(self.cycle.name,'Close Payroll',[a])
        self.assertEqual(result['closed'],[a]);self.assertEqual(result['cycle_status'],'Processing')
        self.assertEqual(self.active([a,b]),['Send for Review'])
        for action in ('Send for Review','Review Statutory Results','Approve Payroll'):run_step(self.cycle.name,action,[a,b])
        with patch('karyo.payroll.statutory._refresh_and_reconcile_slips',return_value={}) as reconcile:
            run_step(self.cycle.name,'Apply Employee Deductions',[a,b]);self.assertEqual(reconcile.call_args.kwargs['employees'],[b])
        with patch.object(type(self.slips[0]),'submit',submit):run_step(self.cycle.name,'Submit Salary Slips',[a,b])
        self.assertEqual(submitted,[a,b])
        result=run_step(self.cycle.name,'Close Payroll',[a,b]);self.assertEqual(result['closed'],[b])
        for action in ('Send for Review','Approve Payroll','Close Payroll'):
            self.assertIn('Finalize overall cycle: '+action,self.active([a,b]))
            run_step(self.cycle.name,'Finalize overall cycle: '+action,[a,b])
        self.assertEqual(frappe.db.get_value('Payroll Cycle',self.cycle.name,'status'),'Closed')
    def test_cannot_skip_review_or_approve_without_role(self):
        with self.assertRaises(frappe.ValidationError):run_step(self.cycle.name,'Approve Payroll',self.employees)
        with patch('karyo.payroll.employee_completion.has_actor_role',return_value=False),self.assertRaises(frappe.ValidationError):run_step(self.cycle.name,'Send for Review',self.employees)

    def test_salary_slip_cannot_be_submitted_during_paye(self):
        from karyo.payroll.employee_completion import guard_salary_slip_submission
        slip = frappe.get_doc('Salary Slip', self.slips[0].name)
        with self.assertRaisesRegex(frappe.ValidationError, 'must remain Draft while PAYE'):
            guard_salary_slip_submission(slip)
        self.assertEqual(frappe.db.get_value('Salary Slip', slip.name, 'docstatus'), 0)

    def test_statutory_component_missing_from_structure_is_additive(self):
        from karyo.payroll.statutory import _overwrite_structure_amount
        with patch(
            'karyo.payroll.statutory.frappe.db.get_value',
            return_value='MAI Staff Structure',
        ), patch(
            'karyo.payroll.statutory.frappe.db.exists',
            return_value=False,
        ):
            overwrite = _overwrite_structure_amount(
                self.employees[0], 'Pension Contribution DC (Employee)', self.cycle.payment_date
            )
        self.assertEqual(overwrite, 0)

    def test_paye_is_applied_from_income_tax_slab_without_additional_salary(self):
        from karyo.payroll.statutory import _apply_employee_result
        result = frappe.get_doc('Payroll Statutory Result', {
            'payroll_cycle': self.cycle.name,
            'employee': self.employees[0],
            'result_type': 'PAYE',
        })
        result.db_set({'status': 'Reviewed', 'additional_salary': None}, update_modified=False)
        with patch('karyo.payroll.statutory.frappe.get_doc', wraps=frappe.get_doc) as get_doc:
            additional_salary, existed = _apply_employee_result(self.cycle, result)
        self.assertIsNone(additional_salary)
        self.assertTrue(existed)
        self.assertEqual(frappe.db.get_value('Payroll Statutory Result', result.name, 'status'), 'Applied')
        self.assertFalse(any(
            call.args and call.args[0] == 'Additional Salary'
            for call in get_doc.call_args_list
        ))

    def test_statutory_apply_rejects_negative_net_pay_before_saving(self):
        from karyo.payroll.statutory import _refresh_and_reconcile_slips
        employee = self.employees[0]
        slip = self.slips[0]
        frappe.db.set_value('Payroll Statutory Result', {
            'payroll_cycle': self.cycle.name,
            'employee': employee,
        }, 'status', 'Applied')
        saved = []
        def rebuild(doc):
            doc.net_pay = -1
            return doc
        def save(doc):
            saved.append(doc.name)
        with patch('karyo.payroll.statutory._rebuild_draft_salary_slip', side_effect=rebuild), \
                patch.object(type(slip), 'save', save), \
                self.assertRaisesRegex(frappe.ValidationError, 'negative Net Pay'):
            _refresh_and_reconcile_slips(self.cycle, employees=[employee])
        self.assertEqual(saved, [])

    def test_paye_screen_contains_the_full_ordered_employee_workflow(self):
        from karyo.desk.payroll_management import screen_data
        from karyo.payroll.employee_completion import ACTIONS
        selected = self.employees[:1]
        data = screen_data('applypaye', payroll_period='payday::'+self.cycle.pay_day, employees=selected)
        self.assertEqual(data['closing_scope']['employees'], selected)
        self.assertEqual([s['action'] for s in data['screen_steps']], list(ACTIONS[:5]))
        self.assertEqual([s['action'] for s in data['screen_steps'] if s['available']], ['Send for Review'])
        for action in ACTIONS[1:4]:
            run_step(self.cycle.name, action, selected)
            data = screen_data('applypaye', payroll_period='payday::'+self.cycle.pay_day, employees=selected)
            self.assertEqual([s['action'] for s in data['screen_steps'] if s['available']], [ACTIONS[ACTIONS.index(action)+1]])
        with patch('karyo.payroll.statutory._refresh_and_reconcile_slips', return_value={}):
            run_step(self.cycle.name, ACTIONS[4], selected)
        data = screen_data('applypaye', payroll_period='payday::'+self.cycle.pay_day, employees=selected)
        self.assertTrue(all(s['done'] for s in data['screen_steps']))
        data = screen_data('close', payroll_period='payday::'+self.cycle.pay_day, employees=selected)
        self.assertEqual(data['closing_scope']['employees'], selected)
        self.assertEqual([s['action'] for s in data['screen_steps']], list(ACTIONS[5:]))
        self.assertEqual([s['action'] for s in data['screen_steps'] if s['available']], ['Submit Salary Slips'])
    def test_direct_approval_fields_cannot_be_written(self):
        doc=frappe.get_doc('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':self.employees[0]})
        doc.employee_approved_on=frappe.utils.now_datetime()
        with self.assertRaises(frappe.ValidationError):doc.save()

    def test_approval_failure_explains_handoff_and_does_not_advance(self):
        selected = self.employees[:1]
        for action in ('Send for Review', 'Review Statutory Results'):
            run_step(self.cycle.name, action, selected)
        frappe.db.set_value('Payroll Cycle', self.cycle.name, 'processed_by', 'processor@example.com')
        get_setting = frappe.db.get_single_value
        def setting(doctype, field, *args, **kwargs):
            if doctype == 'Karyo Payroll Settings' and field == 'enforce_segregation_of_duties':
                return 1
            return get_setting(doctype, field, *args, **kwargs)
        from karyo.payroll.governance import assert_segregation_of_duties as check_segregation
        with patch('frappe.db.get_single_value', side_effect=setting), patch('frappe.get_roles', return_value=['Payroll Approver']), patch('karyo.payroll.employee_completion.assert_segregation_of_duties', side_effect=lambda cycle: check_segregation(cycle, user='processor@example.com')):
            for _ in range(2):
                with self.assertRaisesRegex(frappe.PermissionError, 'Ask a different user.*run Approve Payroll'):
                    run_step(self.cycle.name, 'Approve Payroll', selected)
                self.assertFalse(frappe.db.get_value('Payroll Cycle Employee',
                    {'payroll_cycle':self.cycle.name, 'employee':selected[0]}, 'employee_approved_on'))
                self.assertEqual(self.active(selected), ['Approve Payroll'])
            from karyo.payroll.governance import assert_segregation_of_duties
            assert_segregation_of_duties(frappe._dict(status='Approved', processed_by='Administrator'), user='other-approver')
    def test_empty_selection_means_all_employees(self):
        self.assertEqual(set(state(self.cycle,[])['employees']),set(self.employees))

    def test_admin_can_approve_own_processing_as_fallback(self):
        from karyo.payroll.governance import has_actor_role
        for actor in ('processor','reviewer','approver'):
            self.assertTrue(has_actor_role(actor, roles=['System Manager'], user='fallback-admin'))
            self.assertFalse(has_actor_role(actor, roles=['Employee'], user='employee'))
        for action in ('Send for Review','Review Statutory Results'):
            run_step(self.cycle.name, action, self.employees[:1])
        frappe.db.set_value('Payroll Cycle', self.cycle.name, 'processed_by', 'mbc.admin@mbc.mu')
        frappe.set_user('mbc.admin@mbc.mu')
        run_step(self.cycle.name, 'Approve Payroll', self.employees[:1])
        self.assertEqual(frappe.db.get_value('Payroll Cycle Employee',
            {'payroll_cycle':self.cycle.name,'employee':self.employees[0]},'employee_approved_by'), 'mbc.admin@mbc.mu')
        self.assertFalse(frappe.db.get_value('Payroll Cycle Employee',
            {'payroll_cycle':self.cycle.name,'employee':self.employees[1]},'employee_approved_on'))
        from karyo.payroll.employee_completion import reject_payroll
        with self.assertRaises(frappe.PermissionError):
            reject_payroll(self.cycle.name, self.employees, 'Must not reset an approved employee')

    def test_admin_rejects_only_selection_and_requires_recalculation(self):
        from karyo.payroll.employee_completion import reject_payroll
        for action in ('Send for Review','Review Statutory Results'):
            run_step(self.cycle.name, action, self.employees)
        frappe.set_user('mbc.admin@mbc.mu')
        with self.assertRaises(frappe.ValidationError):
            reject_payroll(self.cycle.name, self.employees[:1], '')
        reject_payroll(self.cycle.name, self.employees[:1], 'Correct the draft earnings')
        self.assertEqual(self.active(self.employees[:1]), ['Calculate PAYE and Contributions'])
        self.assertEqual(self.active(self.employees[1:]), ['Approve Payroll'])
        with self.assertRaises(frappe.ValidationError):
            run_step(self.cycle.name, 'Approve Payroll', self.employees[:1])
        with self.assertRaises(frappe.PermissionError):
            reject_payroll(self.cycle.name, self.employees[:1], 'Repeated rejection')
        self.assertTrue(frappe.db.exists('Comment', {'reference_doctype':'Payroll Cycle',
            'reference_name':self.cycle.name,'content':('like','%Correct the draft earnings%')}))

    def prepare_submission(self):
        for action in ('Send for Review','Review Statutory Results','Approve Payroll'):
            run_step(self.cycle.name,action,self.employees)
        with patch('karyo.payroll.statutory._refresh_and_reconcile_slips',return_value={}):
            run_step(self.cycle.name,'Apply Employee Deductions',self.employees)

    def test_re_review_skips_applied_results(self):
        from karyo.payroll.statutory import review_cycle_results
        self.prepare_submission()
        frappe.db.set_value('Payroll Cycle', self.cycle.name, 'status', 'Review')
        result = review_cycle_results(self.cycle.name)
        self.assertGreater(result['already_applied'], 0)
        self.assertFalse(frappe.db.exists('Payroll Statutory Result', {
            'payroll_cycle': self.cycle.name,
            'result_type': ('in', ['PAYE', 'Employee Contribution']),
            'status': ('!=', 'Applied'),
        }))

    def test_accrual_uses_only_selected_slips(self):
        self.prepare_submission()
        entry_type=type(frappe.get_doc('Payroll Entry',self.cycle.payroll_entry))
        names=[]
        def native_list(entry, ss_status, as_dict=False):
            return [frappe._dict(name=s.name) if as_dict else (s.name,) for s in self.slips]
        def accrue(entry, selected):
            names.extend(s.name for s in selected)
            self.assertEqual([r.name for r in entry.get_sal_slip_list(1,as_dict=True)],names)
            self.assertEqual([r[0] for r in entry.get_sal_slip_list(1)],names)
        def submit(slip):frappe.db.set_value('Salary Slip',slip.name,'docstatus',1)
        with patch.object(entry_type,'get_sal_slip_list',native_list),patch.object(entry_type,'make_accrual_jv_entry',accrue),patch.object(type(self.slips[0]),'submit',submit):
            run_step(self.cycle.name,'Submit Salary Slips',self.employees[:1])
        self.assertEqual(names,[self.slips[0].name])
        self.assertEqual(frappe.db.get_value('Salary Slip',self.slips[1].name,'docstatus'),0)
        self.assertFalse(frappe.db.get_value('Payroll Entry',self.cycle.payroll_entry,'salary_slips_submitted'))

    def test_accrual_failure_rolls_back_submission(self):
        self.prepare_submission()
        entry_type=type(frappe.get_doc('Payroll Entry',self.cycle.payroll_entry))
        def submit(slip):frappe.db.set_value('Salary Slip',slip.name,'docstatus',1)
        with patch.object(entry_type,'make_accrual_jv_entry',side_effect=frappe.ValidationError('Accounting configuration incomplete')),patch.object(type(self.slips[0]),'submit',submit):
            with self.assertRaisesRegex(frappe.ValidationError,'Accounting configuration'):
                run_step(self.cycle.name,'Submit Salary Slips',self.employees)
        self.assertTrue(all(frappe.db.get_value('Salary Slip',s.name,'docstatus')==0 for s in self.slips))
        self.assertFalse(frappe.flags.via_payroll_entry)

    def test_zero_components_submit_without_empty_journal_or_account_lookup(self):
        self.prepare_submission()
        entry_type = type(frappe.get_doc('Payroll Entry', self.cycle.payroll_entry))
        def components(entry, component_type):
            return [frappe._dict(salary_component='PAYE', amount=0, employee=self.employees[0])]
        def submit(slip):
            frappe.db.set_value('Salary Slip', slip.name, 'docstatus', 1)
        with patch.object(entry_type, 'get_salary_components', components), \
                patch.object(entry_type, 'get_salary_component_account', side_effect=AssertionError('Zero rows need no account')), \
                patch.object(entry_type, 'make_journal_entry', side_effect=AssertionError('Must not create empty journal')), \
                patch.object(type(self.slips[0]), 'submit', submit):
            run_step(self.cycle.name, 'Submit Salary Slips', self.employees[:1])
        self.assertEqual(frappe.db.get_value('Salary Slip', self.slips[0].name, 'docstatus'), 1)
        self.assertEqual(frappe.db.get_value('Salary Slip', self.slips[1].name, 'docstatus'), 0)

    def test_accrual_preserves_nonzero_components_even_when_they_net_to_zero(self):
        self.prepare_submission()
        entry_type = type(frappe.get_doc('Payroll Entry', self.cycle.payroll_entry))
        def components(entry, component_type):
            return [frappe._dict(amount=amount) for amount in (0, 100, -100)]
        def accrue(entry, selected):
            self.assertEqual([row.amount for row in entry.get_salary_components('deductions')], [100, -100])
        def submit(slip):
            frappe.db.set_value('Salary Slip', slip.name, 'docstatus', 1)
        with patch.object(entry_type, 'get_salary_components', components), \
                patch.object(entry_type, 'make_accrual_jv_entry', accrue), \
                patch.object(type(self.slips[0]), 'submit', submit):
            run_step(self.cycle.name, 'Submit Salary Slips', self.employees[:1])

    def test_overall_finalization_cannot_skip_open_employees(self):
        with self.assertRaises(frappe.ValidationError):
            run_step(self.cycle.name,'Finalize overall cycle: Approve Payroll',self.employees[:1])

    def test_minor_approval_is_scoped(self):
        from karyo.payroll.sequencing import major_sequence_requirement
        major=frappe._dict(payroll_type='Major',company=self.cycle.company,pay_period_label=self.cycle.pay_period_label,minor_sequence_waived=0)
        with patch('karyo.payroll.sequencing.frappe.db.get_single_value',return_value=1):
            self.assertTrue(major_sequence_requirement(major,self.employees[:1])[0])
            for action in ('Send for Review','Review Statutory Results','Approve Payroll'):
                run_step(self.cycle.name,action,self.employees[:1])
            self.assertIsNone(major_sequence_requirement(major,self.employees[:1])[0])
            self.assertTrue(major_sequence_requirement(major,self.employees)[0])

    def test_reconciliation_preserves_unselected_payroll(self):
        from karyo.payroll.statutory import _refresh_and_reconcile_slips
        a,b=self.employees
        frappe.db.set_value('Payroll Statutory Result',{'payroll_cycle':self.cycle.name,'employee':a},'status','Applied')
        touched=[]
        def rebuild(slip):touched.append(slip.employee);return slip
        with patch('karyo.payroll.statutory._rebuild_draft_salary_slip',side_effect=rebuild):
            _refresh_and_reconcile_slips(self.cycle,employees=[a])
        self.assertEqual(touched,[a])
        self.assertEqual(frappe.db.get_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':a},'status'),'Reconciled')
        self.assertEqual(frappe.db.get_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':b},'status'),'Processed')
        self.assertEqual(frappe.db.get_value('Payroll Cycle',self.cycle.name,'gross_pay'),2000)
