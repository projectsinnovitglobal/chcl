import unittest

from karyo.passage_benefit.bank_migration import (
	_load_source,
	_reconciliation_difference,
	_validate_row,
)


class TestPassageBenefitBankMigration(unittest.TestCase):
	def test_live_sheet_snapshot_excludes_sample_and_captures_real_rows(self):
		payload = _load_source()
		self.assertEqual(payload["workbook_title"], "PBB")
		self.assertEqual(payload["sheet"], "Sheet2")
		self.assertEqual(payload["range"], "A1:K6")
		self.assertEqual(payload["excluded_rows"], [4])
		self.assertEqual([row["sheet_row"] for row in payload["rows"]], [5, 6])

	def test_source_exceptions_are_not_silently_reconciled(self):
		rows = _load_source()["rows"]
		self.assertIsNone(_reconciliation_difference(rows[0]))
		self.assertEqual(_reconciliation_difference(rows[1]), -0.01)
		_employee, _difference, first_errors = _validate_row(rows[0])
		_employee, difference, second_errors = _validate_row(rows[1])
		self.assertIn("MISSING_OPENING_BALANCE", {code for code, _message in first_errors})
		self.assertIn("MISSING_CLOSING_BALANCE", {code for code, _message in first_errors})
		self.assertEqual(difference, -0.01)
		self.assertIn("BALANCE_MISMATCH", {code for code, _message in second_errors})

	def test_employee_mapping_is_required_before_loading(self):
		for row in _load_source()["rows"]:
			_employee, _difference, errors = _validate_row(row)
			self.assertIn("EMPLOYEE_NOT_MAPPED", {code for code, _message in errors})
