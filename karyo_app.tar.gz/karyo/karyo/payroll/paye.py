"""Mauritius cumulative PAYE calculation engine for income year 2025/2026.

The engine is deliberately DB-free. Effective-dated bands, EDF/IET values and
employee tax treatment are resolved by the payroll orchestration layer and
passed in explicitly. Source: MRA Guide on PAYE (December 2025), section 6 and
the client ``PAYE Computation.xlsx`` workbook.

Cumulative PAYE apportions the *bands* as well as the reliefs. At period ``n``
of ``p`` periods the 0% bracket covers ``500,000 x n / p`` of cumulative
chargeable income, which is the "Cumulative Chargeable Income" table in the
client workbook (Rs 38,461.54 per period for a 13-period income year).
"""

from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal

import frappe
from frappe import _
from frappe.utils import getdate

from karyo.payroll.configuration import assert_production_eligible

DEFAULT_PERIODS_PER_YEAR = 13


def statutory_income_year_bounds(on_date):
	"""Return the Mauritius PAYE income year containing ``on_date``.

	The statutory year always runs from 1 July to 30 June.  Keeping this
	calendar rule in the calculation layer prevents an incorrectly dated PAYE
	configuration record from turning employee-facing positions into a
	January-to-December schedule.
	"""
	on_date = getdate(on_date)
	start_year = on_date.year if on_date.month >= 7 else on_date.year - 1
	return getdate(f"{start_year}-07-01"), getdate(f"{start_year + 1}-06-30")


def _decimal(value):
	return Decimal(str(value or 0))


def _money(value, precision=0):
	return value.quantize(Decimal("1").scaleb(-precision), rounding=ROUND_HALF_UP)


def _money_down(value, precision=0):
	return value.quantize(Decimal("1").scaleb(-precision), rounding=ROUND_DOWN)


def statutory_period_index(on_date, year_start, periods_per_year=DEFAULT_PERIODS_PER_YEAR):
	"""Return the MRA cumulative PAYE position for a monthly payment date.

	The December 2025 guide inserts the prescribed-bonus position between
	November and December.  Monthly positions are therefore July=1 .. November=5,
	bonus=6, December=7 .. June=13.  Non-13-period configurations retain the
	ordinary calendar-month sequence.
	"""
	on_date, year_start = getdate(on_date), getdate(year_start)
	if (
		int(periods_per_year) == DEFAULT_PERIODS_PER_YEAR
		and (year_start.month, year_start.day) != (7, 1)
	):
		# Mauritius monthly PAYE is a fixed July-to-June statutory calendar.
		# Normalise here as a defensive control; the PAYE-year master validates
		# the same rule and the data patch repairs legacy calendar-year records.
		year_start, _year_end = statutory_income_year_bounds(on_date)
	offset = (on_date.year - year_start.year) * 12 + on_date.month - year_start.month
	index = offset + 1
	if int(periods_per_year) == 13 and offset >= 5:
		index += 1
	return min(max(index, 1), int(periods_per_year))


def edf_scenario_diagnostics(declaration, year, on_date, previous_declaration=None, cumulative_iet=0):
	"""Evaluate every scenario in MBC Business Rules Validation §4.5.

	This is a diagnostic companion to :func:`cumulative_edf_deduction`; it does
	not invent a second tax engine. Exactly one source scenario should match a
	regular monthly payroll date and every non-match includes the submitted-data
	reason requested by Payroll/HR users.
	"""
	def value(record, fieldname, default=None):
		if record is None:
			return default
		if hasattr(record, "get"):
			return record.get(fieldname, default)
		return getattr(record, fieldname, default)

	year_start = getdate(value(year, "effective_from"))
	pay_date = getdate(on_date)
	appointment = getdate(value(declaration, "appointment_date") or year_start)
	effective = getdate(value(declaration, "effective_from") or year_start)
	status = value(declaration, "declaration_status")
	basis = value(declaration, "employment_basis")
	submitted = bool(declaration and status == "Submitted")
	one_edf = submitted and not previous_declaration
	duplicate_edf = submitted and bool(previous_declaration)
	first = basis == "First Employment"
	not_first = basis == "Not First Employment"
	new_employee = appointment > year_start
	existing_employee = appointment <= year_start

	# The source table names calendar-month bands explicitly. Keep the diagnostic
	# labels faithful even when a locally configured PAYE version has a different
	# effective-from date (that configuration issue is reported separately).
	pay_jul_nov = 7 <= pay_date.month <= 11
	pay_dec_jun = pay_date.month == 12 or 1 <= pay_date.month <= 6
	pay_jan_jun = 1 <= pay_date.month <= 6
	appointment_jul_dec = 7 <= appointment.month <= 12
	appointment_jan_jun = 1 <= appointment.month <= 6
	effective_jul_nov = 7 <= effective.month <= 11
	effective_dec_jun = effective.month == 12 or 1 <= effective.month <= 6
	effective_jul_dec = 7 <= effective.month <= 12
	effective_jan_jun = 1 <= effective.month <= 6

	common = {
		"one": (one_edf, "A previous submitted EDF exists, so this is a duplicate/fresh EDF." if duplicate_edf else "There is no single submitted EDF effective for this date."),
		"duplicate": (duplicate_edf, "No earlier submitted EDF is linked or effective before the current EDF."),
		"first": (first, f"Employment Basis is {basis or 'not provided'}, not First Employment."),
		"not_first": (not_first, f"Employment Basis is {basis or 'not provided'}, not Not First Employment."),
		"new": (new_employee, f"Appointment date {appointment} is on or before the financial-year start {year_start}."),
		"existing": (existing_employee, f"Appointment date {appointment} is after the financial-year start {year_start}."),
		"pay_jul_nov": (pay_jul_nov, f"Payroll date {pay_date} is not in July–November."),
		"pay_dec_jun": (pay_dec_jun, f"Payroll date {pay_date} is not in December–June."),
		"pay_jan_jun": (pay_jan_jun, f"Payroll date {pay_date} is not in January–June."),
		"effective_jul_nov": (effective_jul_nov, f"EDF effective date {effective} is not in July–November."),
		"effective_dec_jun": (effective_dec_jun, f"EDF effective date {effective} is not in December–June."),
		"effective_jul_dec": (effective_jul_dec, f"Latest EDF effective date {effective} is not in July–December."),
		"effective_jan_jun": (effective_jan_jun, f"Latest EDF effective date {effective} is not in January–June."),
		"appointment_jul_dec": (appointment_jul_dec, f"Appointment date {appointment} is not in July–December."),
		"appointment_jan_jun": (appointment_jan_jun, f"Appointment date {appointment} is not in January–June."),
	}

	scenarios = [
		(1, "One EDF · first employment · new employee · July–November", ["one", "first", "new", "effective_jul_nov", "pay_jul_nov"], "EDF Amount × (v_num + 1) ÷ (v_deno + 2)"),
		(2, "One EDF · first employment · new employee · December–June", ["one", "first", "new", "effective_dec_jun", "pay_dec_jun"], "EDF Amount × (v_num + 2) ÷ (v_deno + 2)"),
		(3, "One EDF · first employment · existing employee · July–November", ["one", "first", "existing", "pay_jul_nov"], "EDF Amount × (v_num + 1) ÷ (v_deno + 2)"),
		(4, "One EDF · first employment · existing employee · December–June", ["one", "first", "existing", "pay_dec_jun"], "EDF Amount × (v_num + 2) ÷ (v_deno + 2)"),
		(5, "One EDF · not first employment · new employee · July–November", ["one", "not_first", "new", "appointment_jul_dec", "pay_jul_nov"], "EDF Amount × (v_num + 1) ÷ (v_deno + 2)"),
		(6, "One EDF · not first employment · new employee · December–June", ["one", "not_first", "new", "appointment_jul_dec", "pay_dec_jun"], "EDF Amount × (v_num + 2) ÷ (v_deno + 2)"),
		(7, "One EDF · not first employment · new employee · January–June", ["one", "not_first", "new", "appointment_jan_jun", "pay_jan_jun"], "EDF Amount × (v_num + 1) ÷ (v_deno + 1)"),
		(8, "One EDF · not first employment · existing employee · July–November", ["one", "not_first", "existing", "pay_jul_nov"], "EDF Amount × (v_num + 1) ÷ (v_deno + 2)"),
		(9, "One EDF · not first employment · existing employee · December–June", ["one", "not_first", "existing", "pay_dec_jun"], "EDF Amount × (v_num + 2) ÷ (v_deno + 2)"),
		(10, "Duplicate EDF · latest EDF July–December · payroll July–November", ["duplicate", "effective_jul_dec", "pay_jul_nov"], "MAX[Previous IET + ((EDF Amount − Previous IET) ÷ (v_deno + 2) × (v_num + 1)), 0]"),
		(11, "Duplicate EDF · latest EDF July–December · payroll December–June", ["duplicate", "effective_jul_dec", "pay_dec_jun"], "MAX[Previous IET + ((EDF Amount − Previous IET) ÷ (v_deno + 2) × (v_num + 2)), 0]"),
		(12, "Duplicate EDF · latest EDF January–June", ["duplicate", "effective_jan_jun", "pay_jan_jun"], "MAX[Previous IET + ((EDF Amount − Previous IET) ÷ (v_deno + 1) × (v_num + 1)), 0]"),
	]
	rows = []
	for number, label, keys, formula in scenarios:
		failures = [common[key][1] for key in keys if not common[key][0]]
		eligible = not failures
		rows.append(
			{
				"scenario_id": number,
				"scenario": label,
				"eligible": eligible,
				"status": "Eligible" if eligible else "Not eligible",
				"reason": (
					f"Submitted data matches source scenario {number}."
					if eligible else " ".join(failures)
				),
				"formula": formula,
				"calculated_cumulative_iet": float(cumulative_iet) if eligible else None,
			}
		)
	no_edf = not submitted
	rows.append(
		{
			"scenario_id": 13,
			"scenario": "No EDF submitted",
			"eligible": no_edf,
			"status": "Eligible" if no_edf else "Not eligible",
			"reason": (
				"No submitted EDF is effective for this payroll date; cumulative IET is zero."
				if no_edf else "A submitted EDF is effective for this payroll date."
			),
			"formula": "Cumulative IET = 0",
			"calculated_cumulative_iet": 0.0 if no_edf else None,
		}
	)
	return rows


def cumulative_edf_deduction(
	*,
	annual_amount,
	period_index,
	periods_per_year=DEFAULT_PERIODS_PER_YEAR,
	year_start=None,
	appointment_date=None,
	first_employment=False,
	effective_from=None,
	previous_annual_amount=None,
	previous_cumulative_amount=None,
):
	"""Calculate cumulative EDF relief for first/new/fresh EDF scenarios.

	This implements MRA illustrations 5, 6, 7, 8 and 12.  A first employment
	uses the remaining statutory positions from appointment to year end.  A
	subsequent employment uses the full-year denominator.  A fresh EDF preserves
	the former cumulative entitlement and spreads only the variance over the
	remaining statutory positions.
	"""
	periods = int(periods_per_year)
	index = int(period_index)
	if periods < 1 or index < 1 or index > periods:
		raise ValueError("PAYE period index is outside the configured income year")
	amount = max(_decimal(annual_amount), Decimal("0"))
	start_index = 1
	if year_start and appointment_date:
		start_index = statutory_period_index(appointment_date, year_start, periods)

	if previous_annual_amount is not None:
		if not effective_from or not year_start:
			raise ValueError("Fresh EDF calculation requires its effective date and PAYE-year start")
		fresh_index = statutory_period_index(effective_from, year_start, periods)
		elapsed = max(0, index - fresh_index + 1)
		remaining = periods - fresh_index + 1
		previous = _decimal(previous_cumulative_amount)
		variance = amount - _decimal(previous_annual_amount)
		return max(Decimal("0"), previous + variance * Decimal(elapsed) / Decimal(remaining))

	elapsed = max(0, index - start_index + 1)
	denominator = periods - start_index + 1 if first_employment else periods
	return amount * Decimal(elapsed) / Decimal(denominator)


def progressive_tax(
	chargeable_income, bands, precision=0, band_factor=1, band_boundary_rounding="Exact Fraction"
):
	"""Calculate tax across ordered progressive bands and return an audit trace.

	Each band is a mapping with ``upper`` (blank for the final open band) and
	``rate`` expressed as a percentage, for example 10 for 10%. ``band_factor``
	scales every boundary, which is how a cumulative PAYE period sees only its
	share of the annual brackets.
	"""
	income = max(_decimal(chargeable_income), Decimal("0"))
	factor = _decimal(band_factor)
	lower = Decimal("0")
	total = Decimal("0")
	trace = []
	previous_upper = None
	for band in bands:
		upper = None if band.get("upper") in (None, "") else _decimal(band["upper"]) * factor
		if upper is not None and band_boundary_rounding == "Whole Rupee":
			upper = _money(upper, 0)
		rate = _decimal(band.get("rate"))
		if upper is not None and previous_upper is not None and upper < previous_upper:
			raise ValueError("PAYE bands must be ordered by ascending upper boundary")
		if upper is not None and upper < lower:
			raise ValueError("PAYE bands must be ordered by ascending upper boundary")
		taxable = max(Decimal("0"), income - lower)
		if upper is not None:
			taxable = min(taxable, upper - lower)
		# The client workbook rounds each bracket before adding it up, so the
		# engine rounds per band rather than once on the total.
		band_tax = _money(taxable * rate / Decimal("100"), precision)
		total += band_tax
		trace.append(
			{
				"from": float(lower),
				"to": None if upper is None else float(upper),
				"rate": float(rate),
				"taxable": float(taxable),
				"tax": float(band_tax),
			}
		)
		if upper is None or income <= upper:
			break
		previous_upper = upper
		lower = upper
	return {"tax": float(total), "bands": trace}


def calculate_cumulative_paye(
	*,
	cumulative_emoluments,
	period_index,
	bands,
	annual_reliefs=0,
	cumulative_iet=0,
	previous_paye=0,
	edf_submitted=True,
	no_edf_rate=15,
	periods_per_year=DEFAULT_PERIODS_PER_YEAR,
	precision=0,
	current_emoluments=None,
	no_paye_threshold=0,
	flat_rate=None,
	fair_share_threshold=0,
	fair_share_rate=0,
	cumulative_dividends=0,
	band_boundary_rounding="Exact Fraction",
	current_rounding="Round Half Up",
):
	"""Return cumulative and current-period PAYE with a reproducible trace.

	For an EDF case, the allowed cumulative fraction of the reliefs and of every
	band boundary is ``x period_index / periods_per_year``. End-of-year bonus is
	a separate PAYE period, hence 13 periods for monthly payroll. Without an EDF,
	tax applies at the configured flat 15%/20% rate without reliefs.

	``flat_rate`` forces the director / Board member treatment (MRA guide 6.2 and
	6.3): the fee is taxed at a flat rate with no relief and no exempt threshold.
	``no_paye_threshold`` is the monthly emolument level below which no tax is
	withheld; it never applies to a ``flat_rate`` payment.
	"""
	period_index = int(period_index)
	periods_per_year = int(periods_per_year)
	if period_index < 1 or period_index > periods_per_year:
		raise ValueError("PAYE period index is outside the configured income year")
	if periods_per_year < 1:
		raise ValueError("PAYE periods per year must be positive")

	emoluments = max(_decimal(cumulative_emoluments), Decimal("0"))
	previous = max(_decimal(previous_paye), Decimal("0"))
	band_factor = Decimal(period_index) / Decimal(periods_per_year)

	if flat_rate is not None:
		allowed_reliefs = Decimal("0")
		chargeable = emoluments
		rate = _decimal(flat_rate)
		taxable_payment = (
			max(_decimal(current_emoluments), Decimal("0"))
			if current_emoluments is not None else chargeable
		)
		period_tax = _money(taxable_payment * rate / Decimal("100"), max(precision, 2) if current_rounding == "Round Down" else precision)
		cumulative_tax = previous + period_tax if current_emoluments is not None else period_tax
		calculation_mode = "Director or Board Member Flat Rate"
		band_trace = [
			{"from": 0.0, "to": None, "rate": float(rate), "taxable": float(taxable_payment), "tax": float(period_tax)}
		]
	elif edf_submitted:
		allowed_reliefs = _decimal(annual_reliefs) * band_factor
		chargeable = max(Decimal("0"), emoluments - allowed_reliefs - _decimal(cumulative_iet))
		result = progressive_tax(
			chargeable,
			bands,
			max(precision, 2) if current_rounding == "Round Down" else precision,
			band_factor,
			band_boundary_rounding,
		)
		cumulative_tax = _decimal(result["tax"])
		calculation_mode = "Cumulative EDF"
		band_trace = result["bands"]
	else:
		allowed_reliefs = Decimal("0")
		chargeable = emoluments
		rate = _decimal(no_edf_rate)
		taxable_payment = (
			max(_decimal(current_emoluments), Decimal("0"))
			if current_emoluments is not None else chargeable
		)
		period_tax = _money(taxable_payment * rate / Decimal("100"), max(precision, 2) if current_rounding == "Round Down" else precision)
		cumulative_tax = previous + period_tax if current_emoluments is not None else period_tax
		calculation_mode = "No EDF Flat Rate"
		band_trace = [
			{"from": 0.0, "to": None, "rate": float(rate), "taxable": float(taxable_payment), "tax": float(period_tax)}
		]

	# Fair Share Contribution (Finance Act 2025) is collected through PAYE on
	# leviable income above the threshold, apportioned over the income year.
	fsc_threshold = _decimal(fair_share_threshold) * band_factor
	fsc_rate = _decimal(fair_share_rate)
	leviable = chargeable + _decimal(cumulative_dividends)
	fair_share = Decimal("0")
	if fsc_rate > 0 and fsc_threshold > 0 and leviable > fsc_threshold:
		fair_share = _money((leviable - fsc_threshold) * fsc_rate / Decimal("100"), max(precision, 2) if current_rounding == "Round Down" else precision)
	cumulative_tax = cumulative_tax + fair_share

	current = max(Decimal("0"), cumulative_tax - previous)
	exempt_period = False
	if flat_rate is None and current_emoluments is not None:
		threshold = _decimal(no_paye_threshold)
		if threshold > 0 and _decimal(current_emoluments) <= threshold:
			# MRA: no PAYE is withheld for a month whose emoluments do not exceed
			# the exempt threshold. The cumulative position is unchanged, so any
			# tax due is picked up by a later period.
			exempt_period = True
			current = Decimal("0")

	return {
		"mode": calculation_mode,
		"period_index": period_index,
		"periods_per_year": periods_per_year,
		"band_boundary_rounding": band_boundary_rounding,
		"band_factor": float(band_factor),
		"cumulative_emoluments": float(emoluments),
		"current_emoluments": None if current_emoluments is None else float(_decimal(current_emoluments)),
		"allowed_reliefs": float(_money(allowed_reliefs, 2)),
		"cumulative_iet": float(_decimal(cumulative_iet)),
		"chargeable_income": float(_money(chargeable, 2)),
		"fair_share_contribution": float(fair_share),
		"cumulative_tax": float(cumulative_tax),
		"previous_paye": float(previous),
		"current_paye": float(
			_money_down(current, precision) if current_rounding == "Round Down" else _money(current, precision)
		),
		"exempt_period": exempt_period,
		"bands": band_trace,
	}


def get_effective_paye_year(on_date, company=None):
	"""Resolve one active PAYE year/version for a payroll date and company."""
	on_date = getdate(on_date)
	rows = frappe.get_all(
		"Payroll PAYE Year",
		filters={"is_active": 1, "effective_from": ("<=", on_date)},
		fields=["name", "company", "effective_to", "effective_from"],
		order_by="effective_from desc, modified desc",
	)
	rows = [
		row
		for row in rows
		if (not row.company or row.company == company)
		and (not row.effective_to or getdate(row.effective_to) >= on_date)
	]
	if not rows:
		frappe.throw(_("No effective PAYE year exists for {0}.").format(on_date))
	doc = frappe.get_doc("Payroll PAYE Year", rows[0].name)
	if (frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo") == "Production":
		assert_production_eligible(doc.configuration_version)
	return doc


def get_employee_tax_declaration(employee, paye_year, on_date):
	"""Resolve the employee EDF/IET version effective on the payment date."""
	on_date = getdate(on_date)
	name = frappe.db.get_value(
		"Employee Tax Declaration",
		{
			"employee": employee,
			"tax_year": paye_year,
			"declaration_status": ("in", ["Submitted", "No EDF"]),
			"effective_from": ("<=", on_date),
		},
		"name",
		order_by="effective_from desc, modified desc",
	)
	if not name:
		return None
	doc = frappe.get_doc("Employee Tax Declaration", name)
	return doc if not doc.effective_to or getdate(doc.effective_to) >= on_date else None


def _previous_submitted_declaration(declaration):
	"""Return the prior submitted EDF version, excluding No-EDF placeholders."""
	if declaration.get("previous_declaration"):
		previous = frappe.get_doc("Employee Tax Declaration", declaration.previous_declaration)
		return previous if previous.declaration_status == "Submitted" else None
	name = frappe.db.get_value(
		"Employee Tax Declaration",
		{
			"name": ("!=", declaration.name),
			"employee": declaration.employee,
			"tax_year": declaration.tax_year,
			"declaration_status": "Submitted",
			"effective_from": ("<", declaration.effective_from),
		},
		"name",
		order_by="effective_from desc, modified desc",
	)
	return frappe.get_doc("Employee Tax Declaration", name) if name else None


def cumulative_declaration_deduction(declaration, year, period_index):
	"""Resolve the cumulative deduction for a versioned employee EDF."""
	if not declaration or declaration.declaration_status != "Submitted":
		return Decimal("0")
	annual = _decimal(declaration.annual_iet) + _decimal(declaration.annual_reliefs)
	previous = _previous_submitted_declaration(declaration)
	if previous:
		previous_cumulative = cumulative_declaration_deduction(previous, year, period_index)
		previous_annual = _decimal(previous.annual_iet) + _decimal(previous.annual_reliefs)
		return cumulative_edf_deduction(
			annual_amount=annual,
			period_index=period_index,
			periods_per_year=year.periods_per_year,
			year_start=year.effective_from,
			effective_from=declaration.effective_from,
			previous_annual_amount=previous_annual,
			previous_cumulative_amount=previous_cumulative,
		)
	return cumulative_edf_deduction(
		annual_amount=annual,
		period_index=period_index,
		periods_per_year=year.periods_per_year,
		year_start=year.effective_from,
		appointment_date=declaration.get("appointment_date") or year.effective_from,
		first_employment=declaration.get("employment_basis") == "First Employment",
	)


def calculate_employee_paye(
	*,
	employee,
	on_date,
	period_index,
	cumulative_emoluments,
	previous_paye=0,
	company=None,
	current_emoluments=None,
):
	"""Resolve effective rules/declaration and calculate employee PAYE."""
	year = get_effective_paye_year(on_date, company)
	declaration = get_employee_tax_declaration(employee, year.name, on_date)
	bands = [
		{
			"upper": None if row.is_open_ended else row.upper_chargeable_income,
			"rate": row.tax_rate,
		}
		for row in year.bands
	]
	edf_submitted = bool(declaration and declaration.declaration_status == "Submitted")
	cumulative_iet = cumulative_declaration_deduction(declaration, year, period_index)
	prior_emoluments = declaration.prior_employment_emoluments if declaration else 0
	prior_paye = declaration.prior_employment_paye if declaration else 0
	no_edf_rate = (
		declaration.no_edf_rate_option
		if declaration and declaration.declaration_status == "No EDF"
		else year.no_edf_rate
	)
	# Director and Board member fees are taxed at a flat rate with no threshold,
	# whether or not an EDF was filed (MRA guide 6.2 and 6.3).
	flat_rate = None
	if declaration and declaration.get("emolument_type") == "Director or Board Member Fees":
		flat_rate = declaration.get("no_edf_rate_option") or year.get("director_flat_rate") or 15
	result = calculate_cumulative_paye(
		cumulative_emoluments=_decimal(cumulative_emoluments) + _decimal(prior_emoluments),
		period_index=period_index,
		bands=bands,
		annual_reliefs=0,
		cumulative_iet=cumulative_iet,
		previous_paye=_decimal(previous_paye) + _decimal(prior_paye),
		edf_submitted=edf_submitted,
		no_edf_rate=no_edf_rate,
		periods_per_year=year.periods_per_year,
		precision=year.currency_precision,
		current_emoluments=current_emoluments,
		no_paye_threshold=year.get("monthly_no_paye_threshold") or 0,
		flat_rate=flat_rate,
		fair_share_threshold=year.get("fair_share_threshold") or 0,
			fair_share_rate=year.get("fair_share_rate") or 0,
			band_boundary_rounding=year.get("band_boundary_rounding") or "Exact Fraction",
			current_rounding=year.get("current_paye_rounding") or (
				"Round Half Up" if str(year.tax_year) == "2025/2026" else "Round Down"
			),
		)
	result.update(
		{
			"employee": employee,
			"paye_year": year.name,
			"configuration_version": year.configuration_version,
			"declaration": declaration.name if declaration else None,
			"source_reference": year.source_reference,
		}
	)
	return result
