import frappe
from frappe import _
from frappe.utils import flt
from karyo.karyo.report.loan_report_utils import add_loan_permission_condition


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = []
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	if filters.get("active_only") is None:
		filters.active_only = 1
	if filters.active_only:
		conditions.append("l.status = 'Active'")
	if filters.guarantor:
		conditions.append("g.guarantor = %(guarantor)s")
	if filters.borrower:
		conditions.append("l.employee = %(borrower)s")
	if filters.loan:
		conditions.append("l.name = %(loan)s")
	if filters.loan_type:
		conditions.append("l.loan_type = %(loan_type)s")
	if filters.company:
		conditions.append("l.company = %(company)s")
	if filters.loan_status:
		conditions.append("l.status = %(loan_status)s")

	where = " and ".join(conditions) or "1=1"
	rows = frappe.db.sql(
		f"""
		select
			g.guarantor, coalesce(g.guarantor_name, ge.employee_name) as guarantor_name,
			coalesce(g.guarantor_status, ge.status) as guarantor_status,
			l.employee as borrower, l.employee_name as borrower_name, l.name as loan,
			l.loan_type, l.company, l.disbursement_date, l.repayment_start_date,
			(select max(s.due_date) from `tabKaryo Loan Schedule` s
				where s.parent = l.name and coalesce(s.is_current, 1) = 1) as repayment_end_date,
			l.status as loan_status, l.approved_amount,
			greatest(0, coalesce(l.outstanding_capital, 0)) as outstanding_capital,
			greatest(0, coalesce(l.outstanding_interest, 0)) as outstanding_interest,
			greatest(0, coalesce(l.outstanding_insurance, 0)) as outstanding_insurance
		from `tabKaryo Loan Guarantor` g
		inner join `tabKaryo Loan` l on l.name = g.parent and g.parenttype = 'Karyo Loan'
		left join `tabEmployee` ge on ge.name = g.guarantor
		where {where}
		order by g.guarantor, l.disbursement_date, l.name
		""",
		filters,
		as_dict=True,
	)

	active_counts = {}
	active_amounts = {}
	for row in rows:
		row.guaranteed_amount = (
			flt(row.outstanding_capital) + flt(row.outstanding_interest) + flt(row.outstanding_insurance)
		)
		if row.loan_status == "Active":
			active_counts[row.guarantor] = active_counts.get(row.guarantor, 0) + 1
			active_amounts[row.guarantor] = active_amounts.get(row.guarantor, 0) + row.guaranteed_amount
	for row in rows:
		row.active_guarantee_count = active_counts.get(row.guarantor, 0)
		row.active_exposure = active_amounts.get(row.guarantor, 0)
		row.exposure_status = "Active" if row.loan_status == "Active" and row.guaranteed_amount > 0.005 else "Inactive"
	return _columns(), rows


def _columns():
	def column(fieldname, label, fieldtype="Data", width=120, options=None):
		return {
			"fieldname": fieldname,
			"label": _(label),
			"fieldtype": fieldtype,
			"width": width,
			**({"options": options} if options else {}),
		}

	return [
		column("guarantor", "Guarantor", "Link", 130, "Employee"),
		column("guarantor_name", "Guarantor Name", width=170),
		column("guarantor_status", "Employee Status", width=105),
		column("active_guarantee_count", "Active Guarantees", "Int", 115),
		column("active_exposure", "Total Active Exposure", "Currency", 145),
		column("borrower", "Borrower", "Link", 130, "Employee"),
		column("borrower_name", "Borrower Name", width=165),
		column("loan", "Loan", "Link", 145, "Karyo Loan"),
		column("loan_type", "Loan Type", "Link", 120, "Loan Type"),
		column("loan_status", "Loan Status", width=90),
		column("exposure_status", "Exposure Status", width=105),
		column("approved_amount", "Approved Amount", "Currency", 125),
		column("outstanding_capital", "Capital Exposure", "Currency", 125),
		column("outstanding_interest", "Interest Exposure", "Currency", 125),
		column("outstanding_insurance", "Insurance Exposure", "Currency", 130),
		column("guaranteed_amount", "Loan Exposure", "Currency", 125),
		column("disbursement_date", "Disbursement Date", "Date", 115),
		column("repayment_start_date", "Start Date", "Date", 95),
		column("repayment_end_date", "End Date", "Date", 95),
		column("company", "Company", "Link", 130, "Company"),
	]
