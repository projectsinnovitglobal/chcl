"""Move legacy PB exclusion selections to the authoritative Leave Type flag."""

import frappe


def execute():
	if not frappe.db.has_column("Leave Type", "karyo_pb_not_earned"):
		return
	for leave_type in frappe.get_all(
		"Passage Benefit Not Earned Leave Type",
		filters={"parenttype": "Passage Benefit Settings"},
		pluck="leave_type",
	):
		if frappe.db.exists("Leave Type", leave_type):
			frappe.db.set_value("Leave Type", leave_type, "karyo_pb_not_earned", 1, update_modified=False)
