"""Controlled late-entry/early-exit deductions from Casual Leave.

MBC confirmed the operating rules on 2026-09-24: accumulate by Payroll Cycle,
apply each Shift Type's late/early grace, start at two hours, and round upward
to half-day units.  The employee's configured Leave Approver (or an
administrator) authorises both the attendance minutes and the conversion.
"""

from __future__ import annotations

from calendar import monthrange
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP

import frappe
from frappe import _
from frappe.utils import cint, flt, get_datetime, get_time, getdate, now_datetime, nowdate


ADMIN_ROLES = {"System Manager"}
ROUNDING_MODES = {
	"Up": ROUND_CEILING,
	"Down": ROUND_FLOOR,
	"Nearest": ROUND_HALF_UP,
}


def convert_lateness_to_days(minutes, working_minutes, rounding_mode="None", rounding_increment=0):
	"""Convert approved minutes to leave days using deterministic decimal rounding."""
	minutes = Decimal(str(minutes or 0))
	working_minutes = Decimal(str(working_minutes or 0))
	if minutes < 0:
		raise ValueError("Approved lateness minutes cannot be negative")
	if working_minutes <= 0:
		raise ValueError("Scheduled working minutes must be greater than zero")
	days = minutes / working_minutes
	if rounding_mode in (None, "", "None"):
		return float(days)
	if rounding_mode not in ROUNDING_MODES:
		raise ValueError(f"Unsupported rounding mode: {rounding_mode}")
	increment = Decimal(str(rounding_increment or 0))
	if increment <= 0:
		raise ValueError("Rounding increment must be greater than zero")
	return float((days / increment).quantize(Decimal("1"), rounding=ROUNDING_MODES[rounding_mode]) * increment)


def posted_lateness_days(employee, leave_type, from_date=None, to_date=None):
	"""Return posted custom-ledger consumption ignored by native HRMS helpers."""
	filters = {
		"employee": employee,
		"leave_type": leave_type,
		"transaction_type": "Lateness Leave Deduction",
		"docstatus": 1,
	}
	if from_date and to_date:
		filters["from_date"] = ("between", [from_date, to_date])
	elif to_date:
		filters["from_date"] = ("<=", to_date)
	return abs(flt(frappe.db.get_value("Leave Ledger Entry", filters, "sum(leaves)")))


def effective_leave_balance(employee, leave_type, on_date):
	"""Native allocation balance less posted lateness deductions."""
	from hrms.hr.doctype.leave_application.leave_application import get_leave_allocation_records, get_leave_balance_on

	native = flt(get_leave_balance_on(employee, leave_type, on_date))
	allocation = get_leave_allocation_records(employee, on_date, leave_type).get(leave_type)
	if not allocation:
		return native
	from karyo.hr.leave_controls import casual_permission_balance_correction

	permission_correction = casual_permission_balance_correction(
		employee, leave_type, allocation.from_date, allocation.to_date
	)
	return native + permission_correction - posted_lateness_days(employee, leave_type, allocation.from_date, on_date)


def validate_lateness_settings(doc, method=None):
	"""Prevent activation until each client-decision field is explicitly governed."""
	if not cint(doc.get("enable_lateness_leave_deduction")):
		return
	required = {
		"lateness_divisor_source": _("Working-day divisor source"),
		"lateness_accumulation_period": _("Accumulation period"),
		"lateness_rounding_mode": _("Rounding rule"),
		"lateness_approval_workflow": _("Approval workflow"),
		"lateness_policy_approval_reference": _("Policy approval reference"),
	}
	missing = [label for fieldname, label in required.items() if not doc.get(fieldname)]
	if missing:
		frappe.throw(_("Complete these lateness policy decisions before enabling deductions: {0}.").format(", ".join(missing)))
	if doc.lateness_divisor_source == "Fixed Minutes" and flt(doc.get("lateness_fixed_working_minutes")) <= 0:
		frappe.throw(_("Fixed working minutes must be greater than zero."))
	if flt(doc.get("lateness_minimum_minutes")) < 0:
		frappe.throw(_("Minimum lateness minutes cannot be negative."))
	if doc.lateness_rounding_mode != "None" and flt(doc.get("lateness_rounding_increment_days")) <= 0:
		frappe.throw(_("Rounding increment must be greater than zero when rounding is enabled."))
	if doc.lateness_accumulation_period != "Payroll Period":
		frappe.throw(_("MBC lateness must accumulate within the applicable Payroll Cycle."))
	if doc.lateness_divisor_source != "Scheduled Shift":
		frappe.throw(_("MBC lateness must use the employee's scheduled shift hours."))
	if flt(doc.get("lateness_minimum_minutes")) != 120:
		frappe.throw(_("MBC lateness minimum must be 120 minutes (2 hours)."))
	if doc.lateness_rounding_mode != "Up" or flt(doc.get("lateness_rounding_increment_days")) != 0.5:
		frappe.throw(_("MBC lateness must round upward to the next half day."))
	if doc.lateness_approval_workflow != "Leave Approver Submits Deduction":
		frappe.throw(_("MBC lateness conversion must be submitted by the employee's Leave Approver."))


def _scheduled_window(attendance):
	"""Return the authoritative window, shift and working minutes for attendance."""
	from karyo.hr.roster import current_duty, shift_context

	duty = current_duty(attendance.employee, attendance.attendance_date)
	shift_name = duty.shift_type if duty else attendance.shift
	if not shift_name:
		return None, None, None, None
	shift = frappe.get_cached_doc("Shift Type", shift_name)
	start_time = duty.start_time if duty else shift.start_time
	end_time = duty.end_time if duty else shift.end_time
	if not start_time or not end_time:
		return None, None, None, shift
	start = datetime.combine(getdate(attendance.attendance_date), get_time(start_time))
	end = datetime.combine(getdate(attendance.attendance_date), get_time(end_time))
	if end <= start:
		end += timedelta(days=1)
	duty_hours = flt(duty.duty_hours if duty else shift_context(shift_name).duty_hours)
	working_minutes = duty_hours * 60 if duty_hours > 0 else (end - start).total_seconds() / 60
	return start, end, working_minutes, shift


def employee_grace_minutes(employee, shift):
	"""Resolve explicit employee > active category > shift, including zero overrides."""
	default_start = flt(shift.late_entry_grace_period) if shift and cint(shift.enable_late_entry_marking) else 0
	default_end = flt(shift.early_exit_grace_period) if shift and cint(shift.enable_early_exit_marking) else 0
	person = frappe.db.get_value("Employee", employee,
		["karyo_employment_category", "karyo_override_attendance_grace",
		 "karyo_start_grace_minutes", "karyo_end_grace_minutes"], as_dict=True) if employee else None
	if person and cint(person.karyo_override_attendance_grace):
		return flt(person.karyo_start_grace_minutes), flt(person.karyo_end_grace_minutes), "Employee"
	category = person.karyo_employment_category if person else None
	values = frappe.db.get_value(
		"Employee Category", category,
		["override_attendance_grace", "start_grace_minutes", "end_grace_minutes", "disabled"], as_dict=True,
	) if category else None
	if values and not cint(values.disabled) and cint(values.override_attendance_grace):
		return flt(values.start_grace_minutes), flt(values.end_grace_minutes), "Employee Category"
	return default_start, default_end, "Shift Type"


def lateness_after_grace_threshold(actual_minutes, grace_minutes):
	"""Grace is a tolerance: beyond it, display the full scheduled-time variance."""
	minutes = max(0, flt(actual_minutes))
	return minutes if minutes > max(0, flt(grace_minutes)) else 0


def attendance_lateness_values(attendance):
	"""Derive chargeable late/early minutes after the effective employee grace."""
	if isinstance(attendance, str):
		attendance = frappe.get_doc("Attendance", attendance)
	start, end, scheduled_minutes, shift = _scheduled_window(attendance)
	in_time = get_datetime(attendance.in_time) if attendance.in_time else None
	out_time = get_datetime(attendance.out_time) if attendance.out_time else None
	employee = getattr(attendance, "employee", None)
	if employee:
		late_grace, early_grace, grace_source = employee_grace_minutes(employee, shift)
	else:
		late_grace = flt(shift.late_entry_grace_period) if shift and cint(shift.enable_late_entry_marking) else 0
		early_grace = flt(shift.early_exit_grace_period) if shift and cint(shift.enable_early_exit_marking) else 0
		grace_source = "Shift Type"
	late_minutes = (
		max(0, (in_time - start).total_seconds() / 60 - late_grace)
		if in_time and start and shift and cint(shift.enable_late_entry_marking) else 0
	)
	early_minutes = (
		max(0, (end - out_time).total_seconds() / 60 - early_grace)
		if out_time and end and shift and cint(shift.enable_early_exit_marking) else 0
	)
	return frappe._dict(
		late_minutes=round(late_minutes, 2),
		early_minutes=round(early_minutes, 2),
		total_minutes=round(late_minutes + early_minutes, 2),
		scheduled_minutes=round(scheduled_minutes or 0, 2),
		late_grace_minutes=round(late_grace, 2),
		early_grace_minutes=round(early_grace, 2),
		grace_source=grace_source,
	)


def sync_attendance_lateness(doc, method=None):
	"""Snapshot grace-adjusted late/early minutes; approval remains human."""
	if doc.get("karyo_lateness_status") in ("Approved", "Deducted", "Reversed"):
		return
	calculation = attendance_lateness_values(doc)
	values = {
		"karyo_detected_late_minutes": calculation.total_minutes,
		"karyo_detected_late_entry_minutes": calculation.late_minutes,
		"karyo_detected_early_exit_minutes": calculation.early_minutes,
		"karyo_late_entry_grace_minutes": calculation.late_grace_minutes,
		"karyo_early_exit_grace_minutes": calculation.early_grace_minutes,
		"karyo_grace_source": calculation.grace_source,
		"karyo_scheduled_working_minutes": calculation.scheduled_minutes,
	}
	if calculation.total_minutes <= 0:
		values["karyo_lateness_status"] = ""
	elif calculation.total_minutes > 0 and not doc.get("karyo_lateness_status"):
		values["karyo_lateness_status"] = "Pending Approval"
	frappe.db.set_value("Attendance", doc.name, values, update_modified=False)
	doc.update(values)


def apply_attendance_grace_flags(doc, method=None):
	"""Align manual/imported attendance flags where actual clock evidence exists."""
	if not doc.get("shift") or not (doc.get("in_time") or doc.get("out_time")):
		return
	if doc.get("karyo_lateness_status") in ("Approved", "Deducted", "Reversed"):
		return
	calculation = attendance_lateness_values(doc)
	if doc.get("in_time") and doc.get("shift"):
		doc.late_entry = int(calculation.late_minutes > 0)
	if doc.get("out_time") and doc.get("shift"):
		doc.early_exit = int(calculation.early_minutes > 0)


def prevent_attendance_cancellation_with_deduction(doc, method=None):
	if doc.get("karyo_lateness_deduction") and frappe.db.get_value(
		"Lateness Leave Deduction", doc.karyo_lateness_deduction, "docstatus"
	) == 1:
		frappe.throw(_("Cancel the linked Lateness Leave Deduction before cancelling this attendance."))


def _is_administrator():
	return frappe.session.user == "Administrator" or bool(ADMIN_ROLES.intersection(frappe.get_roles()))


def _leave_approver(employee):
	approver = frappe.db.get_value("Employee", employee, "leave_approver")
	if not approver:
		from hrms.hr.doctype.leave_application.leave_application import get_leave_approver
		approver = get_leave_approver(employee)
	return approver


def _require_leave_approver(employee):
	"""Restrict conversion to the employee's configured Leave Approver or admin."""
	if _is_administrator():
		return
	approver = _leave_approver(employee)
	if frappe.session.user != approver:
		frappe.throw(
			_("Only the employee's configured Leave Approver or an administrator may approve this conversion."),
			frappe.PermissionError,
		)


def _settings(require_enabled=True):
	settings = frappe.get_cached_doc("MBC Leave Settings")
	validate_lateness_settings(settings)
	if require_enabled and not cint(settings.enable_lateness_leave_deduction):
		frappe.throw(_("Lateness-to-leave deduction is disabled pending approved policy settings."))
	return settings


@frappe.whitelist(methods=["POST"])
def approve_lateness(attendance, approved_minutes, approval_reference):
	"""Approve grace-adjusted late/early minutes for conversion."""
	settings = _settings()
	doc = frappe.get_doc("Attendance", attendance)
	_require_leave_approver(doc.employee)
	if doc.docstatus != 1:
		frappe.throw(_("Only submitted attendance can supply approved lateness."))
	calculation = attendance_lateness_values(doc)
	detected, scheduled = calculation.total_minutes, calculation.scheduled_minutes
	approved = flt(approved_minutes, 2)
	if approved <= 0 or approved > detected:
		frappe.throw(_("Approved lateness must be greater than zero and cannot exceed {0} detected minutes.").format(detected))
	if not str(approval_reference or "").strip():
		frappe.throw(_("An attendance lateness approval reference is required."))
	if doc.get("karyo_lateness_deduction") and frappe.db.get_value(
		"Lateness Leave Deduction", doc.karyo_lateness_deduction, "docstatus"
	) == 1:
		frappe.throw(_("This attendance lateness has already been deducted."))
	frappe.db.set_value("Attendance", doc.name, {
		"karyo_detected_late_minutes": detected,
		"karyo_detected_late_entry_minutes": calculation.late_minutes,
		"karyo_detected_early_exit_minutes": calculation.early_minutes,
		"karyo_late_entry_grace_minutes": calculation.late_grace_minutes,
		"karyo_early_exit_grace_minutes": calculation.early_grace_minutes,
		"karyo_scheduled_working_minutes": scheduled,
		"karyo_approved_late_minutes": approved,
		"karyo_grace_source": calculation.grace_source,
		"karyo_lateness_status": "Approved",
		"karyo_lateness_approval_reference": str(approval_reference).strip(),
		"karyo_lateness_approved_by": frappe.session.user,
		"karyo_lateness_approved_on": now_datetime(),
		"late_entry": int(calculation.late_minutes > 0) if doc.in_time and doc.shift else doc.late_entry,
		"early_exit": int(calculation.early_minutes > 0) if doc.out_time and doc.shift else doc.early_exit,
	}, update_modified=False)
	result = {"attendance": doc.name, "approved_minutes": approved, "status": "Approved"}
	if settings.lateness_approval_workflow == "Post Automatically After Approval" and settings.lateness_accumulation_period == "Per Attendance":
		result["deductions"] = process_approved_lateness([doc.name])
	return result


def _period_key(row, accumulation):
	date = getdate(row.attendance_date)
	if accumulation == "Per Attendance":
		return row.employee, date, date, row.name
	if accumulation == "Daily":
		return row.employee, date, date, ""
	if accumulation == "Monthly":
		return row.employee, date.replace(day=1), date.replace(day=monthrange(date.year, date.month)[1]), ""
	cycle_filters = {
		"company": row.company,
		"start_date": ("<=", date),
		"end_date": (">=", date),
		"status": ("!=", "Cancelled"),
	}
	# Employees can be paid on different cut-offs (for example the 15th or
	# 25th). Resolve the cycle through the employee's Pay Day master rather than
	# choosing an arbitrary overlapping company cycle.
	pay_day_master = frappe.db.get_value("Employee", row.employee, "karyo_pay_day")
	if pay_day_master:
		pay_days = frappe.get_all(
			"Payroll Pay Day",
			filters={
				"company": row.company,
				"pay_day_master": pay_day_master,
				"start_date": ("<=", date),
				"end_date": (">=", date),
				"status": ("!=", "Cancelled"),
			},
			pluck="name",
		)
		if not pay_days:
			frappe.throw(_("No payroll period for employee {0}'s Pay Day covers attendance {1}.").format(row.employee, row.name))
		cycle_filters["pay_day"] = ("in", pay_days)
	cycle = frappe.db.get_value(
		"Payroll Cycle",
		cycle_filters,
		["name", "start_date", "end_date"], as_dict=True,
	)
	if not cycle:
		frappe.throw(_("No payroll period covers attendance {0}.").format(row.name))
	return row.employee, getdate(cycle.start_date), getdate(cycle.end_date), cycle.name


def _complete_period(period_end, accumulation, as_of_date):
	return accumulation == "Per Attendance" or getdate(period_end) < getdate(as_of_date)


@frappe.whitelist(methods=["POST"])
def process_approved_lateness(attendance_names=None, as_of_date=None):
	"""Group approved attendance under the configured period and create deductions."""
	settings = _settings()
	if isinstance(attendance_names, str):
		attendance_names = frappe.parse_json(attendance_names)
	filters = {
		"docstatus": 1,
		"karyo_lateness_status": "Approved",
		"karyo_approved_late_minutes": (">", 0),
		"karyo_lateness_deduction": ("is", "not set"),
	}
	rows = frappe.get_all(
		"Attendance", filters=filters,
		fields=["name", "employee", "employee_name", "company", "attendance_date", "karyo_detected_late_minutes",
			"karyo_detected_late_entry_minutes", "karyo_detected_early_exit_minutes",
			"karyo_late_entry_grace_minutes", "karyo_early_exit_grace_minutes",
			"karyo_approved_late_minutes", "karyo_scheduled_working_minutes", "karyo_lateness_approval_reference"],
		order_by="attendance_date asc, employee asc", limit_page_length=0,
	)
	if not _is_administrator():
		requested_names = set(attendance_names or [])
		for employee in {row.employee for row in rows if not requested_names or row.name in requested_names}:
			_require_leave_approver(employee)
		rows = [
			row for row in rows
			if _leave_approver(row.employee) == frappe.session.user
		]
	if attendance_names:
		requested = set(attendance_names)
		target_keys = {
			_period_key(row, settings.lateness_accumulation_period)
			for row in rows if row.name in requested
		}
		rows = [
			row for row in rows
			if _period_key(row, settings.lateness_accumulation_period) in target_keys
		]
	groups = {}
	for row in rows:
		key = _period_key(row, settings.lateness_accumulation_period)
		groups.setdefault(key, []).append(row)
	created = []
	for (employee, period_from, period_to, period_reference), group in groups.items():
		if not _complete_period(period_to, settings.lateness_accumulation_period, as_of_date or nowdate()):
			continue
		doc = frappe.get_doc({
			"doctype": "Lateness Leave Deduction",
			"employee": employee,
			"period_from": period_from,
			"period_to": period_to,
			"period_reference": period_reference,
			"policy_approval_reference": settings.lateness_policy_approval_reference,
			"attendance_rows": [{
				"attendance": row.name,
				"attendance_date": row.attendance_date,
				"detected_late_minutes": row.karyo_detected_late_minutes,
				"detected_late_entry_minutes": row.karyo_detected_late_entry_minutes,
				"detected_early_exit_minutes": row.karyo_detected_early_exit_minutes,
				"late_entry_grace_minutes": row.karyo_late_entry_grace_minutes,
				"early_exit_grace_minutes": row.karyo_early_exit_grace_minutes,
				"approved_late_minutes": row.karyo_approved_late_minutes,
				"scheduled_working_minutes": row.karyo_scheduled_working_minutes,
				"approval_reference": row.karyo_lateness_approval_reference,
			} for row in group],
		})
		doc.insert(ignore_permissions=True)
		if settings.lateness_approval_workflow == "Post Automatically After Approval":
			doc.submit()
		created.append({"name": doc.name, "docstatus": doc.docstatus, "employee": employee})
	return created


def scheduled_process_approved_lateness():
	"""Manual Leave Approver policy makes the scheduler a safe no-op."""
	settings = frappe.get_cached_doc("MBC Leave Settings")
	if not cint(settings.enable_lateness_leave_deduction) or settings.lateness_approval_workflow != "Post Automatically After Approval":
		return []
	return process_approved_lateness(as_of_date=nowdate())
