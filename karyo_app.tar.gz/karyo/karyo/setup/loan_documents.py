"""Karyo Loan — classified document register (Phase 4D).

    bench --site dev.localhost execute karyo.setup.loan_documents.setup

Adds the Karyo Loan Document child table (classified uploads: Application,
Approval, Agreement, Registration, Lien, Insurance, Disbursement, Other) to
Karyo Loan and the allowed-format / max-size / retention controls to Karyo
Settings (§12). Format + size are validated in the loan controller (VAL-FAR-019).
Idempotent.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype

DEFAULT_FORMATS = "PDF,JPG,JPEG,PNG,CSV,DOC,DOCX,XLS,XLSX,TIFF,ZIP"


def create_doctype():
	make_doctype(
		"Karyo Loan Document",
		istable=1,
		fields=[
			f(
				"document_type",
				"Select",
				"Document Type",
				options="Application\nApproval\nAgreement\nRegistration\nLien\nInsurance\nDisbursement\nOther",
				reqd=1,
				in_list_view=1,
			),
			f("attachment", "Attach", "File", reqd=1, in_list_view=1),
			f("remarks", "Data", "Remarks", in_list_view=1),
			f("cb", "Column Break"),
			f("uploaded_by", "Data", "Uploaded By", read_only=1),
			f("uploaded_on", "Date", "Uploaded On", read_only=1),
		],
	)
	make_doctype(
		"Loan Document Requirement",
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="LDR-.#####", default="LDR-.#####"),
			f("loan_type", "Link", "Loan Type (blank = all)", options="Loan Type", in_list_view=1),
			f("document_type", "Select", "Document Type", options="Application\nApproval\nAgreement\nRegistration\nLien\nInsurance\nDisbursement\nOther", reqd=1, in_list_view=1),
			f("required_before", "Select", "Required Before", options="Approval\nAgreement\nReady for Disbursement\nDisbursement\nActivation", reqd=1, in_list_view=1),
			f("classification", "Select", "Classification", options="Internal\nConfidential\nRestricted", default="Confidential"),
			f("requires_verification", "Check", "Requires Verification", default="1"),
			f("requires_expiry_date", "Check", "Requires Expiry Date"),
			f("rules_cb", "Column Break"),
			f("when_insurance_required", "Check", "Only When Insurance Required"),
			f("when_lien_required", "Check", "Only When Lien Required"),
			f("allowed_extensions", "Data", "Allowed Extensions (optional override)"),
			f("start_date", "Date", "Start Date", reqd=1),
			f("end_date", "Date", "End Date"),
			f("is_active", "Check", "Active", default="1"),
			f("governance_sb", "Section Break", "Configuration Governance"),
			f("configuration_status", "Select", "Configuration Status", options="Demo\nDraft\nValidated\nApproved\nActive\nSuperseded\nRetired", default="Demo", reqd=1),
			f("configuration_version", "Data", "Version", default="1.0"),
			f("is_production_eligible", "Check", "Approved for Production"),
			f("source_reference", "Data", "Source Reference"),
			f("approval_reference", "Data", "Approval Reference"),
			f("governance_cb", "Column Break"),
			f("approved_by", "Link", "Approved By", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
		],
	)


def add_fields():
	create_custom_fields(
		{
			"Karyo Loan Document": [
				{"fieldname": "document_status", "fieldtype": "Select", "label": "Document Status", "options": "Draft\nSigned\nVerified\nRejected\nExpired\nReturned\nSuperseded", "default": "Draft", "reqd": 1, "insert_after": "document_type"},
				{"fieldname": "status_reason", "fieldtype": "Small Text", "label": "Status Reason", "insert_after": "document_status"},
				{"fieldname": "supersedes", "fieldtype": "Data", "label": "Supersedes Document Row", "insert_after": "status_reason"},
				{"fieldname": "classification", "fieldtype": "Select", "label": "Classification", "options": "Internal\nConfidential\nRestricted", "default": "Confidential", "insert_after": "document_type"},
				{"fieldname": "document_reference", "fieldtype": "Data", "label": "Document Reference", "insert_after": "attachment"},
				{"fieldname": "issue_date", "fieldtype": "Date", "label": "Issue Date", "insert_after": "document_reference"},
				{"fieldname": "expiry_date", "fieldtype": "Date", "label": "Expiry Date", "insert_after": "issue_date"},
				{"fieldname": "verified", "fieldtype": "Check", "label": "Verified", "insert_after": "expiry_date"},
				{"fieldname": "verified_by", "fieldtype": "Link", "label": "Verified By", "options": "User", "read_only": 1, "insert_after": "verified"},
				{"fieldname": "verified_on", "fieldtype": "Datetime", "label": "Verified On", "read_only": 1, "insert_after": "verified_by"},
				{"fieldname": "malware_scan_status", "fieldtype": "Select", "label": "Malware Scan", "options": "Pending\nClean\nInfected\nFailed", "default": "Pending", "insert_after": "verified_on"},
				{"fieldname": "mime_type", "fieldtype": "Data", "label": "Detected MIME Type", "read_only": 1, "insert_after": "malware_scan_status"},
			],
			"Karyo Loan": [
				{
					"fieldname": "documents_tab",
					"fieldtype": "Tab Break",
					"label": "Documents",
					"insert_after": "agreement_printed_on",
				},
				{
					"fieldname": "documents",
					"fieldtype": "Table",
					"label": "Documents",
					"options": "Karyo Loan Document",
					"insert_after": "documents_tab",
				},
			],
			"Karyo Settings": [
				{
					"fieldname": "document_controls_sb",
					"fieldtype": "Section Break",
					"label": "Loan Document Controls",
					"insert_after": "enforce_loan_conditions",
				},
				{
					"fieldname": "allowed_document_formats",
					"fieldtype": "Small Text",
					"label": "Allowed Document Formats",
					"default": DEFAULT_FORMATS,
					"insert_after": "document_controls_sb",
				},
				{
					"fieldname": "max_document_size_mb",
					"fieldtype": "Int",
					"label": "Max Document Size (MB)",
					"default": "12",
					"insert_after": "allowed_document_formats",
				},
				{
					"fieldname": "document_retention_years",
					"fieldtype": "Int",
					"label": "Document Retention (Years)",
					"default": "10",
					"insert_after": "max_document_size_mb",
				},
				{
					"fieldname": "document_retention_enforcement",
					"fieldtype": "Data",
					"label": "Retention Enforcement Status",
					"default": "Informational only — no automatic archive/purge (MBC decision pending)",
					"read_only": 1,
					"insert_after": "document_retention_years",
					"description": "The retention period is informational until MBC approves archive, purge, legal-hold and deletion authority rules.",
				},
			],
		},
		ignore_validate=True,
	)
	print("  + Karyo Loan document register fields ensured")


def seed_defaults():
	"""Populate the Karyo Settings document controls if unset (§12 defaults)."""
	defaults = {
		"allowed_document_formats": DEFAULT_FORMATS,
		"max_document_size_mb": 12,
		"document_retention_years": 10,
		"document_retention_enforcement": "Informational only — no automatic archive/purge (MBC decision pending)",
	}
	for field, value in defaults.items():
		if not frappe.db.get_single_value("Karyo Settings", field):
			frappe.db.set_single_value("Karyo Settings", field, value)


def setup():
	print("Karyo Loan document register setup:")
	create_doctype()
	add_fields()
	seed_defaults()
	frappe.db.commit()
	print("Done.")
