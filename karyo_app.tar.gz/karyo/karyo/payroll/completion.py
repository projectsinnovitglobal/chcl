"""Admin payroll completion actions and employee loan prerequisites."""
import frappe
from frappe import _
from frappe.model.workflow import get_transitions, apply_workflow
from karyo.payroll.governance import has_actor_role


@frappe.whitelist()
def cycle_status(payroll_cycle):
	cycle=frappe.get_doc('Payroll Cycle',payroll_cycle);cycle.check_permission('read')
	statutory=frappe.get_all('Payroll Statutory Result',filters={'payroll_cycle':cycle.name},fields=['status','result_type'])
	slips=frappe.get_all('Salary Slip',filters={'payroll_entry':cycle.payroll_entry,'docstatus':['<',2]},fields=['name','employee','docstatus']) if cycle.payroll_entry else []
	exceptions=frappe.get_all('Payroll Readiness Exception',filters={'payroll_cycle':cycle.name,'status':'Open'},fields=['name','employee','severity','message','remediation_doctype','remediation_name'],limit=50)
	return {'status':cycle.status,'docstatus':cycle.docstatus,'readiness':cycle.readiness_status,'payroll_entry':cycle.payroll_entry,
		'actions':[{'action':t.action,'next_state':t.next_state} for t in get_transitions(cycle)],
		'can_process':has_actor_role('processor'),'can_review':has_actor_role('reviewer'),'can_approve':has_actor_role('approver'),
		'can_submit_slips':has_actor_role('processor') or has_actor_role('approver'),
		'statutory_count':len(statutory),'statutory_unreviewed':sum(r.status not in ('Reviewed','Applied') for r in statutory),
		'statutory_unapplied':sum(r.result_type in ('PAYE','Employee Contribution') and r.status!='Applied' for r in statutory),
		'draft_slips':sum(r.docstatus==0 for r in slips),'submitted_slips':sum(r.docstatus==1 for r in slips),'slips':slips,'exceptions':exceptions,
		'loan_operations':frappe.db.count('Loan Operation Code',{'is_active':1})}


@frappe.whitelist()
def run_step(payroll_cycle, action):
	cycle=frappe.get_doc('Payroll Cycle',payroll_cycle);cycle.check_permission('write')
	if cycle.docstatus==2:frappe.throw(_('Cancelled payroll cycles cannot be processed.'))
	if action=='Run Readiness Checks':
		if not has_actor_role('processor'):frappe.throw(_('A payroll processor must run readiness checks.'),frappe.PermissionError)
		from karyo.payroll.readiness import run_readiness
		result=run_readiness(cycle.name)
	elif action=='Submit Salary Slips':
		if not (has_actor_role('processor') or has_actor_role('approver')):frappe.throw(_('Only a payroll processor or approver can submit Salary Slips.'),frappe.PermissionError)
		if cycle.status!='Approved' or cycle.docstatus!=1:frappe.throw(_('Approve and submit the payroll cycle before submitting Salary Slips.'))
		from karyo.payroll.input_posting import assert_no_pending_cycle_inputs
		assert_no_pending_cycle_inputs(cycle)
		status=cycle_status(cycle.name)
		if not status['statutory_count'] or status['statutory_unreviewed'] or status['statutory_unapplied']:
			frappe.throw(_('Review and apply statutory deductions before submitting Salary Slips.'))
		if not cycle.payroll_entry or not status['draft_slips']:frappe.throw(_('No draft Salary Slips are available for this payroll cycle.'))
		entry=frappe.get_doc('Payroll Entry',cycle.payroll_entry)
		if entry.company!=cycle.company or entry.get('karyo_payroll_cycle')!=cycle.name:frappe.throw(_('Payroll Entry does not belong to this payroll cycle.'))
		from karyo.payroll.component_accounts import ensure_payroll_entry_component_accounts
		ensure_payroll_entry_component_accounts(entry.name)
		entry.submit_salary_slips();result={'message':_('Salary Slip submission requested. Check the submitted count and Payroll Entry for any processing errors.')}
	else:
		methods={'Prepare Payroll':'karyo.payroll.process.prepare_payroll','Generate Draft Salary Slips':'karyo.payroll.process.generate_salary_slips',
			'Calculate PAYE and Contributions':'karyo.payroll.process.calculate_cycle_statutory','Review Statutory Results':'karyo.payroll.statutory.review_cycle_results',
			'Apply Employee Deductions':'karyo.payroll.statutory.apply_cycle_results'}
		if action in methods:result=frappe.get_attr(methods[action])(cycle.name)
		else:
			if action in ('Send for Review', 'Approve Payroll'):
				from karyo.payroll.input_posting import assert_no_pending_cycle_inputs
				assert_no_pending_cycle_inputs(cycle)
			allowed={t.action for t in get_transitions(cycle)}
			if action not in allowed:frappe.throw(_('This action is not available at the current payroll stage.'),frappe.PermissionError)
			updated=apply_workflow(cycle.as_dict(),action)
			result={'message':_('Payroll cycle is now {0} ({1}).').format(updated.status,_('Submitted') if updated.docstatus==1 else _('Draft'))}
			if updated.status=='Closed':
				# Training manual: staff are emailed to verify their payslip on ESS
				# once the period is closed.
				from karyo.payroll.payslip_notice import notify_on_close
				notice=notify_on_close(cycle.name)
				if notice.get('sent'):
					result['message']+=' '+_('Payslip notice emailed to {0} employee(s).').format(notice['sent'])
	frappe.get_doc('Payroll Cycle',cycle.name).notify_update()
	return result


@frappe.whitelist()
def employee_status(employee):
	doc=frappe.get_doc('Employee',employee);doc.check_permission('write')
	from karyo.loan.employee_period import default_period
	period=default_period(employee)
	cycles=frappe.get_all('Payroll Cycle',filters={'company':doc.company,'payroll_period':period,'docstatus':['<',2]},fields=['name','status','start_date','end_date'],order_by='end_date desc') if period else []
	return {'employee':employee,'period':period,'cycles':cycles,
		'operations':frappe.db.count('Loan Operation Code',{'is_active':1}),
		'slips':frappe.get_all('Salary Slip',filters={'employee':employee,'docstatus':['<',2]},fields=['name','docstatus','start_date','end_date'],order_by='start_date desc',limit=10),
		'prb_runs':frappe.get_all('PRB Payroll Run',filters={'employee':employee,'docstatus':['<',2]},fields=['name','docstatus','exception_code','exception_detail'],order_by='modified desc',limit=5)}


@frappe.whitelist()
def salary_points(run):
	doc=frappe.get_doc('PRB Payroll Run',run);doc.check_permission('write')
	return frappe.get_all('PRB Salary Point',filters={'review_year':doc.review_year},fields=['salary_point','revised_2026'],order_by='salary_point asc')


@frappe.whitelist()
def set_salary_point(run, point):
	"""Update the authoritative employee value before recalculating a draft run."""
	doc=frappe.get_doc('PRB Payroll Run',run);doc.check_permission('write')
	if doc.docstatus!=0:frappe.throw(_('Only a draft PRB run can be recalculated.'))
	if not frappe.db.exists('PRB Salary Point',{'review_year':doc.review_year,'salary_point':str(point)}):
		frappe.throw(_('Select a salary point configured for this review year.'))
	employee=frappe.get_doc('Employee',doc.employee);employee.check_permission('write')
	# The point was validated above against the run's review year. Update only
	# that field so unrelated legacy Employee links do not block remediation.
	from karyo.setup.payroll_profiles import prb_salary_value
	employee.db_set({
		'karyo_prb_salary_point': str(point),
		'karyo_prb_row3_salary': prb_salary_value(point, doc.review_year, doc.calculation_date) or 0,
	})
	from karyo.payroll.employee_salary_workspace import sync_base_from_prb_point
	sync_base_from_prb_point(employee.name, str(point), doc.calculation_date)
	doc.salary_point=str(point);doc.save()
	return {'name':doc.name,'salary_point':doc.salary_point,'exception_code':doc.exception_code,'exception_detail':doc.exception_detail}


@frappe.whitelist()
def run_period_options(employee, payroll_period=None):
	if not frappe.has_permission('PRB Payroll Run','read'):
		frappe.throw(_('Not permitted'),frappe.PermissionError)
	doc=frappe.get_doc('Employee',employee);doc.check_permission('read')
	from karyo.loan.employee_period import period_options
	periods=period_options(employee)
	valid={p.value for p in periods}
	if payroll_period and payroll_period not in valid:frappe.throw(_('Payroll Period must belong to the employee company.'))
	cycles=frappe.get_all('Payroll Cycle',filters={'company':doc.company,'payroll_period':payroll_period,'docstatus':['<',2]},fields=['name','pay_period_label','status'],order_by='end_date desc') if payroll_period else []
	return {'company':doc.company,'periods':periods,'default_period':doc.get('karyo_loan_payroll_period') if doc.get('karyo_loan_payroll_period') in valid else None,'cycles':cycles}


PROCESS_ACTIONS = (
    "Open Inputs", "Run Readiness Checks", "Start Processing",
    "Prepare Payroll", "Generate Draft Salary Slips",
)


def process_steps(payroll_cycle, employees=None):
    """Five sequential actions, with completion derived from persisted outputs."""
    if employees is not None:
        from karyo.payroll.employee_processing import state
        cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
        cycle.check_permission("read")
        return state(cycle, employees)["steps"]
    from karyo.desk.payroll_management import _step_availability
    cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
    cycle.check_permission("read")
    entry = frappe.db.get_value("Payroll Entry", cycle.payroll_entry,
        ["name", "docstatus", "status"], as_dict=True) if cycle.payroll_entry else None
    prepared = bool(entry and entry.docstatus != 2)
    if prepared:
        from karyo.payroll.employee_processing import prepared_population
        expected = prepared_population(cycle, frappe.get_doc("Payroll Entry", entry.name))
    else:
        expected = set()
    actual = set(frappe.get_all("Salary Slip", filters={"payroll_entry": entry.name,
        "docstatus": ("<", 2)}, pluck="employee")) if prepared else set()
    from karyo.payroll.input_posting import pending_cycle_inputs
    pending_inputs = pending_cycle_inputs(cycle)
    generated = bool(expected and expected.issubset(actual)
        and not pending_inputs['recurring'] and not pending_inputs['once_off_batches'])
    later = cycle.status in ("Review", "Approved", "Closed")
    completed = {
        "Open Inputs": cycle.status in ("Input Open", "Processing", "Reopened") or later,
        "Run Readiness Checks": cycle.readiness_status == "Ready" or later,
        "Start Processing": cycle.status == "Processing" or later,
        "Prepare Payroll": prepared,
        "Generate Draft Salary Slips": generated,
    }
    active = next((action for action in PROCESS_ACTIONS if not completed[action]), None)
    available = {s["action"]: s for s in _step_availability(cycle.as_dict())}
    from karyo.payroll.sequencing import major_sequence_requirement
    sequence_reason, _minor = major_sequence_requirement(cycle)
    steps = []
    for action in PROCESS_ACTIONS:
        step = dict(available[action])
        step["done"] = completed[action]
        step["running"] = bool(action == "Generate Draft Salary Slips" and prepared
            and entry.status == "Queued" and not generated)
        reason = step["blocked_reason"]
        if completed[action]:
            reason = _("Completed.")
        elif action != active:
            reason = _("Complete {0} first.").format(active)
        elif step["running"]:
            reason = _("Payslip generation is queued. Refresh to check completion.")
        elif not has_actor_role("processor"):
            reason = _("A payroll processor must run this step.")
        elif action in ("Open Inputs", "Start Processing") and action not in {
            t.action for t in get_transitions(cycle)
        }:
            reason = _("Your role cannot perform this payroll transition.")
        if not reason and action == "Start Processing":
            reason = sequence_reason
        step["available"] = not reason
        step["next"] = action == active
        step["blocked_reason"] = reason
        steps.append(step)
    return steps


@frappe.whitelist()
def run_process_step(payroll_cycle, action, employees=None):
    """Execute exactly one active step; serialize duplicate requests per cycle."""
    cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
    cycle.check_permission("write")
    if not has_actor_role("processor"):
        frappe.throw(_("A payroll processor must run this step."), frappe.PermissionError)
    frappe.db.sql("select name from `tabPayroll Cycle` where name=%s for update", payroll_cycle)
    if employees is not None:
        from karyo.payroll.employee_processing import run
        cycle.reload()
        return run(cycle, action, employees)
    step = next((s for s in process_steps(payroll_cycle) if s["action"] == action), None)
    if not step or not step["available"]:
        frappe.throw(step["blocked_reason"] if step else _("Select one of the five payroll processing steps."))
    result = run_step(payroll_cycle, action) or {}
    if action == "Run Readiness Checks":
        result["message"] = (_("Readiness has {0} blocking items. Resolve them, then run this step again.").format(result["blocking"])
            if result.get("blocking") else _("Readiness checks passed. Review the Start Processing step for any remaining prerequisites."))
    elif result.get("queued"):
        result["message"] = _("Payslip generation queued. Refresh to check completion.")
    else:
        result.setdefault("message", _("{0} completed.").format(action))
    return result


@frappe.whitelist()
def readiness_exception_details(payroll_cycle, validation_code, employees=None, employee_scope=None):
    cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
    cycle.check_permission("read")
    if not frappe.has_permission("Payroll Readiness Exception", "read"):
        frappe.throw(_("Not permitted to read readiness exceptions."), frappe.PermissionError)
    extra, alternatives = {}, None
    if employee_scope == "closing":
        from karyo.payroll.employee_closing import state
        selected = state(cycle, employees)["employees"]
        alternatives = [["employee", "in", selected or [""]], ["employee", "is", "not set"]]
    elif employees is not None:
        from karyo.payroll.employee_processing import resolve_employees
        selected, _options = resolve_employees(cycle, employees)
        extra["employee"] = ("in", selected)
    rows = frappe.get_list("Payroll Readiness Exception", filters={
        "payroll_cycle": cycle.name, "validation_code": validation_code, "status": "Open", **extra},
        or_filters=alternatives,
        fields=["name", "employee", "severity", "message", "remediation_doctype", "remediation_name"],
        order_by="employee asc", limit_page_length=0)
    employee_names = {
        row.name: row.employee_name
        for row in frappe.get_all(
            "Employee",
            filters={"name": ("in", [row.employee for row in rows if row.employee])},
            fields=["name", "employee_name"],
        )
    } if any(row.employee for row in rows) else {}
    for row in rows:
        row["employee_name"] = employee_names.get(row.employee)
    return rows


@frappe.whitelist()
def recheck_process_employees(payroll_cycle, employees=None):
    cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
    cycle.check_permission("write")
    if not has_actor_role("processor"):
        frappe.throw(_("A payroll processor must rerun readiness."), frappe.PermissionError)
    frappe.db.sql("select name from `tabPayroll Cycle` where name=%s for update", payroll_cycle)
    cycle.reload()
    if cycle.docstatus != 0 or cycle.status not in ("Draft", "Input Open", "Processing", "Reopened"):
        frappe.throw(_("This payroll cycle is locked for processing."))
    from karyo.payroll.employee_processing import resolve_employees, recheck
    selected, _options = resolve_employees(cycle, employees)
    if not selected:
        frappe.throw(_("No eligible employees are selected."))
    return recheck(cycle, selected)
