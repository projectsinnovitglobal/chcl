"""Leave Application behaviour for fractional Casual Leave permissions."""

import frappe
from frappe import _
from frappe.utils import cint, flt
from hrms.hr.doctype.leave_application.leave_application import (
	LeaveApplication,
	get_leave_allocation_records,
	get_leave_balance_on,
	get_number_of_leave_days,
	is_lwp,
)

from karyo.hr.leave_controls import (
	_normalize_hour_request,
	casual_permission_balance_correction,
	is_two_hour_casual_permission,
)


class KaryoLeaveApplication(LeaveApplication):
	"""Keep a two-hour permission fractional in the ledger and out of day attendance."""

	def validate_balance_leaves(self):
		code = self.get("karyo_leave_code") or frappe.db.get_value(
			"Leave Type", self.leave_type, "karyo_mbc_leave_code"
		)
		permission = is_two_hour_casual_permission(self)
		if code != "CASL01":
			return super().validate_balance_leaves()

		working_days = get_number_of_leave_days(
			self.employee,
			self.leave_type,
			self.from_date,
			self.to_date,
			self.half_day,
			self.half_day_date,
		)
		if working_days <= 0:
			frappe.throw(
				_("The requested date is a holiday. You need not apply for leave.")
			)
		if permission:
			# Retain the employee-specific fractional duration instead of native's
			# same-date full-day value.
			_normalize_hour_request(self)
		else:
			self.total_leave_days = working_days
		if is_lwp(self.leave_type):
			return

		precision = cint(frappe.db.get_single_value("System Settings", "float_precision")) or 2
		leave_balance = get_leave_balance_on(
			self.employee,
			self.leave_type,
			self.from_date,
			self.to_date,
			consider_all_leaves_in_the_allocation_period=True,
			for_consumption=True,
		)
		available = flt(leave_balance.get("leave_balance_for_consumption"), precision)
		allocation = get_leave_allocation_records(
			self.employee, self.from_date, self.leave_type
		).get(self.leave_type)
		if allocation:
			available += casual_permission_balance_correction(
				self.employee, self.leave_type, allocation.from_date, allocation.to_date
			)
		if self.status != "Rejected" and (available < flt(self.total_leave_days) or not available):
			self.show_insufficient_balance_message(available)

	def validate_attendance(self):
		# A two-hour permission coexists with attendance for the worked portion of
		# the day; it must not be rejected merely because Present attendance exists.
		if is_two_hour_casual_permission(self):
			return
		return super().validate_attendance()

	def update_attendance(self):
		# The permission deducts fractional leave but does not turn the whole date
		# into On Leave (or a half day) in Attendance.
		if is_two_hour_casual_permission(self):
			return
		return super().update_attendance()

	def cancel_attendance(self):
		if is_two_hour_casual_permission(self):
			return
		return super().cancel_attendance()
