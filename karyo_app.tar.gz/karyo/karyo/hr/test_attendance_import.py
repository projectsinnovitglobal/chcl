from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase
from frappe.utils.csvutils import UnicodeWriter

from karyo.hr.attendance_import import TEMPLATE_COLUMNS, _find_header, add_header, prepare_attendance_row
from karyo.setup.attendance_import import apply as apply_attendance_import_fields


class TestAttendanceImport(FrappeTestCase):
	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		apply_attendance_import_fields()

	def test_sample_has_complete_mapping_contract(self):
		labels = [label for _fieldname, label in TEMPLATE_COLUMNS]
		for expected in (
			"Employee Code", "Shift", "Shift Code", "Roster Code", "Roster Schedule",
			"Clock In", "Clock Out", "Working Hours", "Overtime Hours", "Bonus Amount",
		):
			self.assertIn(expected, labels)
		writer = add_header(UnicodeWriter())
		content = writer.getvalue()
		self.assertIn("Employee Code", content)
		self.assertIn("governed payroll approvals remain authoritative", content)

	def test_old_and_new_headings_are_recognised(self):
		index, columns = _find_header([
			["Notes:"],
			["ID", "Employee", "Employee Name", "Date", "Status", "Overtime", "Bonus"],
		])
		self.assertEqual(index, 1)
		self.assertEqual(
			columns,
			["name", "employee_code", "employee_name", "attendance_date", "status", "overtime_hours", "bonus_amount"],
		)

	def test_employee_and_shift_codes_map_to_authoritative_records(self):
		employee = frappe.get_all(
			"Employee", filters={"status": "Active"},
			fields=["name", "employee_name", "company", "department"], limit_page_length=1,
		)[0]
		shift = frappe.get_all(
			"Shift Type", filters={"karyo_shift_code": ("is", "set")},
			fields=["name", "karyo_shift_code"], limit_page_length=1,
		)[0]
		duty = frappe._dict(name="TEST-SHIFT-ASSIGNMENT", shift_type=shift.name, schedule=None)
		with patch("karyo.hr.attendance_import._dated_duty", return_value=duty), patch(
			"karyo.hr.attendance_import._validate_roster_assignment", return_value=None
		):
			row = prepare_attendance_row(
				{
					"employee_code": employee.name,
					"employee_name": employee.employee_name,
					"attendance_date": "2099-01-05",
					"status": "Present",
					"shift_code": shift.karyo_shift_code,
					"in_time": "08:00:00",
					"out_time": "16:30:00",
					"overtime_hours": "1.5",
					"bonus_amount": "250",
				},
				8,
			)
		self.assertEqual(row.employee, employee.name)
		self.assertEqual(row.company, employee.company)
		self.assertEqual(row.shift, shift.name)
		self.assertEqual(row.get("karyo_roster_assignment"), duty.name)
		self.assertEqual(row.working_hours, 8.5)
		self.assertEqual(row.get("karyo_overtime_hours"), 1.5)
		self.assertEqual(row.get("karyo_bonus_amount"), 250)
