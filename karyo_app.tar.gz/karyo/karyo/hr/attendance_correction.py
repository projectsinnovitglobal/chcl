"""Employee-scoped attendance correction requests and approval side effects."""

import uuid

import frappe
from frappe import _
from frappe.utils import getdate, now_datetime
from hrms.hr.doctype.attendance_request.attendance_request import AttendanceRequest

from karyo.hr.clocking import ADMIN_ROLES, _own_employee


REQUESTED_STATUSES = ("Present", "Half Day", "Work From Home")
MAX_BATCH_SIZE = 31


class KaryoAttendanceRequest(AttendanceRequest):
	"""Use the selected row exactly and let employees retry rejected dates."""

	def get_attendance_doc(self, attendance_date):
		if self.get("karyo_attendance"):
			attendance = frappe.db.get_value(
				"Attendance",
				self.karyo_attendance,
				["employee", "attendance_date", "docstatus"],
				as_dict=True,
			)
			if (
				attendance
				and attendance.employee == self.employee
				and getdate(attendance.attendance_date) == getdate(attendance_date)
				and attendance.docstatus != 2
			):
				return frappe.get_doc("Attendance", self.karyo_attendance)
		return super().get_attendance_doc(attendance_date)

	def validate_request_overlap(self):
		if not self.name:
			self.name = "New Attendance Request"
		values = {
			"employee": self.employee,
			"name": self.name,
			"from_date": self.from_date,
			"to_date": self.to_date,
			"shift": self.shift,
		}
		shift_condition = "and shift=%(shift)s" if self.shift else ""
		overlap = frappe.db.sql(
			f"""select name from `tabAttendance Request`
			where employee=%(employee)s and docstatus < 2 and name != %(name)s
				and from_date <= %(to_date)s and to_date >= %(from_date)s
				and coalesce(karyo_request_status, '') != 'Rejected'
				{shift_condition}
			limit 1""",
			values,
		)
		if overlap:
			self.throw_overlap_error(overlap[0][0])


def _apply_requested_status(doc):
	"""Translate the employee-facing correction into native HRMS request fields."""
	status = doc.get("karyo_requested_status") or (
		"Work From Home" if doc.get("reason") == "Work From Home" else "Half Day" if doc.get("half_day") else "Present"
	)
	if status not in REQUESTED_STATUSES:
		frappe.throw(_("Choose a valid corrected attendance status."))
	doc.karyo_requested_status = status
	doc.reason = "Work From Home" if status == "Work From Home" else "On Duty"
	doc.half_day = 1 if status == "Half Day" else 0
	doc.half_day_date = doc.from_date if status == "Half Day" else None


def prepare_request(doc, method=None):
	"""Keep request identity, target row and native status fields consistent."""
	roles = set(frappe.get_roles())
	if ("Employee" in roles or "Employee Self Service" in roles) and not ADMIN_ROLES.intersection(roles):
		person = _own_employee(required=True)
		if doc.employee and doc.employee != person.name:
			frappe.throw(_("You can only request a correction for your own attendance."), frappe.PermissionError)
		doc.employee = person.name
	if doc.get("karyo_attendance"):
		attendance = frappe.db.get_value(
			"Attendance",
			doc.karyo_attendance,
			["employee", "attendance_date", "shift"],
			as_dict=True,
		)
		if not attendance:
			frappe.throw(_("The selected attendance record is no longer available."))
		if doc.employee and doc.employee != attendance.employee:
			frappe.throw(_("The attendance record does not belong to this employee."))
		doc.employee = attendance.employee
		doc.from_date = attendance.attendance_date
		doc.to_date = attendance.attendance_date
		doc.shift = attendance.shift

	_apply_requested_status(doc)
	if not doc.get("karyo_request_status") or doc.karyo_request_status == "Draft":
		doc.karyo_request_status = (
			"Approved" if doc.docstatus == 1 else "Cancelled" if doc.docstatus == 2 else "Pending Approval"
		)


def approve_request(doc, method=None):
	"""Submitting is the native HRMS approval event that updates Attendance."""
	if doc.get("karyo_request_status") == "Rejected":
		frappe.throw(_("A rejected correction request cannot be approved."))
	_apply_requested_status(doc)
	doc.karyo_request_status = "Approved"


def mark_attendance_corrected(doc, method=None):
	"""Persist an explicit audit marker after native HRMS updates Attendance."""
	filters = {"attendance_request": doc.name, "docstatus": ("!=", 2)}
	names = set(frappe.get_all("Attendance", filters=filters, pluck="name"))
	if doc.get("karyo_attendance") and frappe.db.exists("Attendance", doc.karyo_attendance):
		names.add(doc.karyo_attendance)
	for name in names:
		frappe.db.set_value(
			"Attendance",
			name,
			{
				"karyo_is_corrected": 1,
				"karyo_correction_request": doc.name,
				"karyo_corrected_on": now_datetime(),
			},
			update_modified=False,
		)
	_notify(doc)


def cancel_request(doc, method=None):
	frappe.db.set_value(
		"Attendance Request", doc.name, "karyo_request_status", "Cancelled", update_modified=False
	)
	_notify(doc)


def _notify(doc):
	from karyo.hr.self_service import notify_employee_request

	notify_employee_request(doc)
	frappe.publish_realtime(
		"karyo_attendance_corrected",
		{"employee": doc.employee, "request": doc.name},
		after_commit=True,
	)


def _parse_attendance_names(attendance_names):
	values = frappe.parse_json(attendance_names) if isinstance(attendance_names, str) else attendance_names
	if not isinstance(values, list):
		frappe.throw(_("Select one or more attendance records."))
	values = list(dict.fromkeys(value for value in values if isinstance(value, str) and value.strip()))
	if not values:
		frappe.throw(_("Select at least one attendance record."))
	if len(values) > MAX_BATCH_SIZE:
		frappe.throw(_("Select no more than {0} attendance records at a time.").format(MAX_BATCH_SIZE))
	return values


@frappe.whitelist(methods=["POST"])
def request_corrections(attendance_names, requested_status, explanation):
	"""Create one independently approvable request for each selected own row."""
	person = _own_employee(required=True)
	names = _parse_attendance_names(attendance_names)
	requested_status = str(requested_status or "").strip()
	if requested_status not in REQUESTED_STATUSES:
		frappe.throw(_("Choose a valid corrected attendance status."))
	explanation = str(explanation or "").strip()
	if not explanation:
		frappe.throw(_("Explain why these attendance records need correction."))
	if len(explanation) > 1000:
		frappe.throw(_("Keep the correction explanation within 1000 characters."))

	rows = frappe.get_all(
		"Attendance",
		filters={"name": ("in", names), "employee": person.name, "docstatus": ("!=", 2)},
		fields=["name", "attendance_date", "shift", "company"],
		limit_page_length=MAX_BATCH_SIZE,
	)
	rows_by_name = {row.name: row for row in rows}
	missing = [name for name in names if name not in rows_by_name]
	if missing:
		frappe.throw(_("One or more selected attendance records are unavailable or do not belong to you."), frappe.PermissionError)

	existing = frappe.get_all(
		"Attendance Request",
		filters={
			"karyo_attendance": ("in", names),
			"docstatus": ("<", 2),
			"karyo_request_status": ("!=", "Rejected"),
		},
		fields=["name", "karyo_attendance"],
		limit_page_length=MAX_BATCH_SIZE,
	)
	if existing:
		dates = [str(rows_by_name[row.karyo_attendance].attendance_date) for row in existing]
		frappe.throw(
			_("A correction request already exists for: {0}.").format(", ".join(sorted(dates)))
		)

	batch_id = uuid.uuid4().hex
	created = []
	for name in names:
		row = rows_by_name[name]
		doc = frappe.get_doc(
			{
				"doctype": "Attendance Request",
				"employee": person.name,
				"from_date": getdate(row.attendance_date),
				"to_date": getdate(row.attendance_date),
				"shift": row.shift,
				"company": row.company,
				"reason": "Work From Home" if requested_status == "Work From Home" else "On Duty",
				"half_day": 1 if requested_status == "Half Day" else 0,
				"half_day_date": row.attendance_date if requested_status == "Half Day" else None,
				"explanation": explanation,
				"karyo_attendance": name,
				"karyo_requested_status": requested_status,
				"karyo_request_status": "Pending Approval",
				"karyo_batch_id": batch_id,
			}
		)
		# The endpoint fixes identity to the signed-in employee; ignore_permissions
		# avoids requiring broad Employee/Attendance read access merely to request.
		doc.insert(ignore_permissions=True)
		created.append({"name": doc.name, "attendance": name, "date": row.attendance_date})

	return {"requests": created, "count": len(created), "batch_id": batch_id}


@frappe.whitelist(methods=["POST"])
def approve_correction(name):
	"""Approve a pending correction from the HR queue and run native attendance sync."""
	if not ADMIN_ROLES.intersection(frappe.get_roles()):
		frappe.throw(_("Only HR may approve an attendance correction."), frappe.PermissionError)
	doc = frappe.get_doc("Attendance Request", name)
	doc.check_permission("submit")
	if doc.docstatus != 0 or doc.get("karyo_request_status") != "Pending Approval":
		frappe.throw(_("Only a pending correction request can be approved."))
	doc.submit()
	return {"name": doc.name, "status": doc.karyo_request_status}


@frappe.whitelist(methods=["POST"])
def reject_correction(name, reason):
	if not ADMIN_ROLES.intersection(frappe.get_roles()):
		frappe.throw(_("Only HR may reject an attendance correction."), frappe.PermissionError)
	doc = frappe.get_doc("Attendance Request", name)
	doc.check_permission("write")
	if doc.docstatus != 0 or doc.get("karyo_request_status") != "Pending Approval":
		frappe.throw(_("Only a pending correction request can be rejected."))
	reason = str(reason or "").strip()
	if not reason:
		frappe.throw(_("Enter a rejection reason."))
	doc.db_set(
		{
			"karyo_request_status": "Rejected",
			"karyo_rejection_reason": reason[:1000],
		},
	)
	doc.add_comment("Info", _("Attendance correction rejected: {0}").format(reason[:1000]))
	_notify(doc)
	return {"name": doc.name, "status": "Rejected"}
