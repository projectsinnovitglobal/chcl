import json

import frappe
from frappe import _
from frappe.utils import flt
from karyo.karyo.report.loan_report_utils import add_loan_permission_condition, mask_reference


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = ["s.docstatus = 1", "l.docstatus = 1", "l.status = 'Settled'"]
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	for field, expression in (("company", "l.company"), ("loan", "l.name"), ("employee", "l.employee"), ("loan_type", "l.loan_type"), ("payment_type", "s.payment_type"), ("lien_status", "l.lien_status"), ("ewf_waive_interest", "s.ewf_waive_interest")):
		if filters.get(field) not in (None, ""):
			conditions.append(f"{expression} = %({field})s")
	if filters.from_date:
		conditions.append("s.refund_date >= %(from_date)s")
	if filters.to_date:
		conditions.append("s.refund_date <= %(to_date)s")
	rows = frappe.db.sql(
		f"""select s.name settlement, s.loan, l.employee, l.employee_name, l.loan_type, l.company,
			s.refund_date settlement_date, s.payment_type, s.payment_reference, s.cheque_no,
			s.capital_due, s.interest_due, s.insurance_due, s.total_balance_due,
			s.amount_received, s.ewf_waive_interest, s.prior_state_snapshot,
			s.receipt_reference, l.lien_status, l.lien_released_date
		from `tabKaryo Loan Settlement` s inner join `tabKaryo Loan` l on l.name=s.loan
		where {' and '.join(conditions)} order by s.refund_date desc, s.name desc""",
		filters, as_dict=True,
	)
	for row in rows:
		row.interest_waived = _waived_interest(row)
		row.payment_reference_display = mask_reference(row.cheque_no if row.payment_type == "Cheque" else row.payment_reference)
	return _columns(), rows


def _waived_interest(row):
	if not row.ewf_waive_interest:
		return 0
	try:
		return flt(json.loads(row.prior_state_snapshot or "{}").get("outstanding_interest"))
	except (TypeError, ValueError):
		return 0


def _columns():
	def c(fieldname, label, fieldtype="Data", width=120, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("settlement", "Settlement", "Link", 145, "Karyo Loan Settlement"), c("loan", "Loan", "Link", 145, "Karyo Loan"),
		c("employee", "Employee", "Link", 125, "Employee"), c("employee_name", "Employee Name", width=155), c("loan_type", "Loan Type", "Link", 130, "Loan Type"),
		c("company", "Company", "Link", 140, "Company"), c("settlement_date", "Settlement Date", "Date", 105), c("payment_type", "Payment Type", width=100),
		c("payment_reference_display", "Payment / Cheque Reference", width=190), c("capital_due", "Capital", "Currency"), c("interest_due", "Interest", "Currency"),
		c("insurance_due", "Insurance", "Currency"), c("interest_waived", "Interest Waived", "Currency", 125), c("total_balance_due", "Settlement Total", "Currency", 130),
		c("amount_received", "Amount Received", "Currency", 130), c("receipt_reference", "Receipt Reference", width=165), c("lien_status", "Lien Release Status", width=130),
		c("lien_released_date", "Lien Released On", "Date", 110)]
