"""Stage the current Passage Benefit Bank opening-balance spreadsheet."""

from karyo.passage_benefit.bank_migration import stage_current_sheet


def execute():
	stage_current_sheet(commit=False)
