"""Transactionally isolated PRB 2026 payroll and phase-transition tests."""
import unittest
from unittest.mock import patch

import frappe
from karyo.tests import test_long_service_movements as fixtures
from karyo.prb.salary_phases import phased_salary, preview
from karyo.payroll.salary_scales import (
    approved_appointment, _assignment_at, prepare_prb_salary_slip, validate_salary_slip_base,
)
from karyo.setup.payroll_profiles import prb_salary_value


class TestPRBTwoPhases(unittest.TestCase):
    setUp = fixtures.TestLongServiceMovements.setUp
    tearDown = fixtures.TestLongServiceMovements.tearDown
    make_scale = fixtures.TestLongServiceMovements.make_scale
    appointment = fixtures.TestLongServiceMovements.appointment

    def prb_appointment(self, **values):
        frappe.db.set_value('Employee', self.employee.name, {'karyo_prb_opted_in': 1,
            'karyo_prb_grade': 'EDU-PRIMARY-EDUCATOR', 'karyo_prb_salary_point': '081'})
        return frappe.get_doc({'doctype': 'Employee Salary Appointment', 'employee': self.employee.name,
            'pay_basis': 'PRB', 'prb_grade': 'EDU-PRIMARY-EDUCATOR', 'prb_salary_point': '081',
            'effective_from': '2026-01-01', 'effective_to': '2027-12-31',
            'salary_structure': self.structure, 'income_tax_slab': self.income_tax_slab,
            'authority_reference': 'PRB phased integration TEST', **values}).insert().submit()

    def test_boundaries_and_rounding(self):
        for date, expected in [('2025-12-31', 40000), ('2026-01-01', 42000),
                ('2026-12-31', 42000), ('2027-01-01', 44000), ('2028-01-01', 44000)]:
            self.assertEqual(phased_salary(40000, 44000, date), expected)
        self.assertEqual(phased_salary('40000.00', '40000.01', '2026-01-01'), 40000.01)
        for baseline, full in [(None, 44000), (0, 44000), (40000, 39999), ('NaN', 44000)]:
            with self.subTest(baseline=baseline), self.assertRaises(frappe.ValidationError):
                phased_salary(baseline, full, '2026-01-01')

    def test_appointment_and_native_assignments_cross_2027(self):
        appointment = self.prb_appointment()
        half = prb_salary_value('081', 2026, '2026-01-01')
        full = prb_salary_value('081', 2026, '2027-01-01')
        self.assertLess(half, full)
        self.assertEqual(appointment.basic_salary, half)
        self.assertEqual(appointment.prb_phase_percent, 50)
        for date, expected, percent in [('2026-01-31', half, 50), ('2026-12-31', half, 50), ('2027-01-01', full, 100)]:
            with self.subTest(date=date):
                self.assertEqual(approved_appointment(self.employee.name, date).basic_salary, expected)
                assignment = _assignment_at(self.employee.name, date)
                self.assertEqual(assignment.base, expected)
                self.assertEqual(frappe.db.get_value('Salary Structure Assignment', assignment.name,
                    'karyo_salary_appointment'), appointment.name)
                run = frappe.get_doc({'doctype': 'PRB Payroll Run', 'employee': self.employee.name,
                    'calculation_date': date, 'review_year': 2026})
                run._compute_basic()
                self.assertFalse(run.exception_code)
                self.assertEqual(run.basic_salary, expected)
                self.assertEqual(run._basic_rule_ref, 'PRB-2026/PHASE-' + str(percent))
        for year, expected in [(2026, half), (2027, full)]:
            slip = frappe._dict(employee=self.employee.name, docstatus=0, salary_structure=self.structure,
                start_date=f'{year}-01-01', end_date=f'{year}-01-31', posting_date=f'{year}-01-31')
            prepare_prb_salary_slip(slip)
            validate_salary_slip_base(slip)
            self.assertEqual(slip.karyo_salary_base, expected)

    def test_cancel_removes_both_phase_assignments(self):
        appointment = self.prb_appointment()
        self.assertEqual(frappe.db.count('Salary Structure Assignment',
            {'employee': self.employee.name, 'docstatus': 1}), 2)
        appointment.cancel()
        self.assertFalse(frappe.db.exists('Salary Structure Assignment',
            {'employee': self.employee.name, 'docstatus': 1, 'karyo_salary_appointment': appointment.name}))

    def test_shortened_period_removes_future_phase(self):
        appointment = self.prb_appointment()
        appointment.effective_to = '2026-12-31'
        appointment.save()
        self.assertFalse(frappe.db.exists('Salary Structure Assignment',
            {'employee': self.employee.name, 'docstatus': 1, 'from_date': '2027-01-01'}))

    def test_legacy_full_base_is_repaired_before_slip_calculation(self):
        appointment = self.prb_appointment()
        assignment = _assignment_at(self.employee.name, '2026-01-01')
        frappe.db.set_value('Salary Structure Assignment', assignment.name, 'base', appointment.prb_full_salary)
        slip = frappe._dict(employee=self.employee.name, docstatus=0, start_date='2026-10-01', end_date='2026-10-31')
        prepare_prb_salary_slip(slip)
        self.assertEqual(_assignment_at(self.employee.name, '2026-10-01').base, appointment.basic_salary)

    def test_native_salary_slip_uses_each_phase_in_basic_formula(self):
        from hrms.payroll.doctype.salary_structure.salary_structure import make_salary_slip
        self.prb_appointment()
        for year in [2026, 2027]:
            date = f'{year}-01-31'
            target = frappe.new_doc("Salary Slip")
            target.start_date, target.end_date = f"{year}-01-01", date
            slip = make_salary_slip(self.structure, target_doc=target, employee=self.employee.name,
                posting_date=date, for_preview=1)
            expected = prb_salary_value('081', 2026, date)
            self.assertEqual(slip._salary_structure_assignment.base, expected)
            validate_salary_slip_base(slip)
            self.assertEqual(slip.karyo_salary_base, expected)
            basic = next(row for row in slip.earnings if row.salary_component == 'Basic')
            self.assertEqual(basic.default_amount, expected)

    def test_posted_salary_slip_prevents_phase_base_rewrite(self):
        appointment = self.prb_appointment()
        assignment = _assignment_at(self.employee.name, '2026-01-01')
        frappe.db.set_value('Salary Structure Assignment', assignment.name, 'base', appointment.prb_full_salary)
        original = frappe.db.exists
        def exists(doctype, *args, **kwargs):
            return 'POSTED-TEST' if doctype == 'Salary Slip' else original(doctype, *args, **kwargs)
        slip = frappe._dict(employee=self.employee.name, docstatus=0, start_date='2026-10-01')
        with patch.object(frappe.db, 'exists', side_effect=exists), self.assertRaises(frappe.ValidationError):
            prepare_prb_salary_slip(slip)
        self.assertEqual(_assignment_at(self.employee.name, '2026-10-01').base, appointment.prb_full_salary)

    def test_raw_conversion_payroll_uses_phase(self):
        for date, expected in [('2026-01-01', prb_salary_value('081', 2026, '2026-01-01')),
                ('2027-01-01', prb_salary_value('081', 2026))]:
            run = frappe.get_doc({'doctype': 'PRB Payroll Run', 'employee': self.employee.name,
                'calculation_date': date, 'review_year': 2026, 'salary_point': '081'})
            run._compute_basic()
            self.assertFalse(run.exception_code)
            self.assertEqual(run.basic_salary, expected)

    def test_legacy_prb_native_assignment_rolls_into_2027(self):
        from karyo.payroll.salary_scales import _assign_structure
        frappe.db.set_value('Employee', self.employee.name,
            {'karyo_prb_opted_in': 1, 'karyo_prb_salary_point': '081'})
        half = prb_salary_value('081', 2026, '2026-01-01')
        _assign_structure(self.employee.name, self.structure, '2026-01-01', half, self.income_tax_slab)
        slip = frappe._dict(employee=self.employee.name, docstatus=0, start_date='2027-01-01')
        prepare_prb_salary_slip(slip)
        self.assertEqual(_assignment_at(self.employee.name, '2027-01-01').base, 60600)
        self.assertEqual(_assignment_at(self.employee.name, '2026-12-31').base, half)

    def test_non_prb_appointment_keeps_grade_scale_salary(self):
        appointment = self.appointment(salary_point='38').insert().submit()
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').basic_salary, 34825)
        self.assertEqual(appointment.basic_salary, 34825)

    def test_nazir_read_only_preview_preserves_salary(self):
        employee = 'MBC/HR/00001'
        before = frappe.db.get_value('Employee', employee,
            ['modified', 'ctc', 'karyo_prb_opted_in', 'karyo_prb_salary_point', 'karyo_salary_appointment'], as_dict=True)
        result = preview(employee, 'EDU-PRIMARY-EDUCATOR', '081')
        self.assertEqual(result['employee_name'], 'Nazir Hasan Zaidi')
        self.assertFalse(result['profile_mapping_matches'])
        self.assertEqual(result['phases'][0]['basic_salary'],
            (result['baseline_salary'] + result['recommended_salary']) / 2)
        self.assertEqual(result['phases'][1]['basic_salary'], result['recommended_salary'])
        self.assertEqual(before, frappe.db.get_value('Employee', employee, list(before), as_dict=True))
        with patch('frappe.get_roles', return_value=['Employee']), self.assertRaises(frappe.PermissionError):
            preview(employee, 'EDU-PRIMARY-EDUCATOR', '081')
