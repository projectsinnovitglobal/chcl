"""Pay-day master edits must propagate to payslip selectors."""
import unittest
import frappe
from karyo.desk.payroll_screens import payslip_period_options

class TestPayslipPeriodSync(unittest.TestCase):
    def test_every_payday_is_an_option_with_database_status(self):
        user=frappe.session.user
        frappe.set_user('Administrator')
        try:
            options=payslip_period_options()
            days=frappe.get_all('Payroll Pay Day',fields=['name','status','pay_period_label','payroll_type'])
            self.assertEqual(len(options),len(days))
            by_key={o['key']:o for o in options}
            for day in days:
                option=by_key['payday::'+day.name]
                self.assertEqual(option['status'],day.status)
                self.assertEqual(option['kind'],'pay_day')
                self.assertIn(day.pay_period_label,option['label'])
                self.assertIn(day.payroll_type,option['label'])
        finally:frappe.set_user(user)
