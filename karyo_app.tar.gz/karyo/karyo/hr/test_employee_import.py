import csv
import io
import uuid

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.employee_import import _import_content, _template_content


class TestEmployeeCSVImport(FrappeTestCase):
	def test_template_contains_three_examples_and_required_columns(self):
		rows = list(csv.DictReader(io.StringIO(_template_content().lstrip("\ufeff"))))
		self.assertEqual(len(rows), 3)
		self.assertTrue({"first_name", "gender", "date_of_birth", "date_joined_organisation", "company"}.issubset(rows[0]))

	def test_import_creates_new_employee_and_skips_duplicates(self):
		company = frappe.db.get_value("Company", {}, "name")
		gender = frappe.db.get_value("Gender", {}, "name")
		existing = frappe.db.get_value("Employee", {}, "name")
		self.assertTrue(company and gender and existing)
		token = uuid.uuid4().hex[:10]
		headers = [
			"employee_code", "nic_passport", "personal_email", "first_name", "surname",
			"gender", "date_of_birth", "date_joined_organisation", "company",
		]
		rows = [
			[existing, "", "", "Existing", "Employee", gender, "1990-01-01", "2026-01-01", company],
			["", f"CSV-{token}", f"csv-{token}@example.invalid", "CSV", "Import", gender, "1990-01-01", "2026-01-01", company],
			["", f"CSV-{token}", f"second-{token}@example.invalid", "Duplicate", "Identity", gender, "1991-01-01", "2026-01-02", company],
		]
		stream = io.StringIO()
		writer = csv.writer(stream, lineterminator="\n")
		writer.writerow(headers)
		writer.writerows(rows)
		created = None
		try:
			report = _import_content(stream.getvalue())
			created = report["created"][0]
			self.assertEqual(report["created_count"], 1)
			self.assertEqual(report["skipped_count"], 2)
			self.assertEqual(report["error_count"], 0)
			self.assertEqual(frappe.db.get_value("Employee", created, "karyo_national_id"), f"CSV-{token}")
		finally:
			if created and frappe.db.exists("Employee", created):
				frappe.delete_doc("Employee", created, force=True)

