"""PRB Payroll Settings — all PRB rates/thresholds as configuration (GEN-001:
no hard-coded business values). Engine constants remain only as fallbacks; the
production controllers read from here.

    bench --site dev.localhost execute karyo.setup.prb_settings.setup
"""

import frappe

from karyo.setup.foundation import f, make_doctype

DEFAULTS = {
	"meal_rate": 175,
	"subsistence_none": 1420,
	"subsistence_lodging": 655,
	"subsistence_half_board": 340,
	"out_of_pocket_rate": 220,
	"car_rate_first_800": 14.50,
	"car_rate_beyond": 9.05,
	"motorcycle_rate": 4.70,
	"autocycle_rate": 3.85,
	"ot_multiplier_day": 1.5,
	"ot_multiplier_night": 2.0,
	"ot_multiplier_holiday": 2.0,
	"ot_ceiling_full": 60600,
	"ot_ceiling_80": 77750,
	"ot_middle_band_factor": 80,
	"ot_middle_band_requires_urgent": 1,
	"night_duty_pct": 25,
	"night_duty_annual_months": 12,
	"night_duty_hours_denominator": 2080,
	"night_duty_rate_multiplier": 2,
	"attendance_bonus_base": 2140,
	"incentive_attendance_bonus_base": 1500,
	"incentive_presence_base": 1500,
	"era_minimum_hours": 15,
	"era_full_payment_hours": 30,
	"era_lower_salary_max": 31525,
	"era_lower_rate": 15,
	"era_lower_cap": 3940,
	"era_upper_salary_min": 32350,
	"era_upper_salary_max": 54200,
	"era_upper_rate": 13,
	"era_upper_cap": 4435,
	"era_working_days_divisor": 22,
	"era_casual_leave_exemption": 1,
	"slb_annual_entitlement": 21,
	"slb_ceiling": 110,
	"slb_refund_cap": 16,
	"slb_advance_recovery_days": 14,
	"leave_refund_divisor": 22,
	"casual_leave_days": 11,
	"lsi_exclusion_max": 86750,
}


def create_doctype():
	make_doctype(
		"PRB Payroll Settings",
		issingle=1,
		fields=[
			f("allow_sb", "Section Break", "Allowance Rates (Rs)"),
			f("meal_rate", "Currency", "Meal Rate", default="175"),
			f("subsistence_none", "Currency", "Subsistence — No Board/Lodging", default="1420"),
			f("subsistence_lodging", "Currency", "Subsistence — Lodging Provided", default="655"),
			f("subsistence_half_board", "Currency", "Subsistence — Half Board", default="340"),
			f("out_of_pocket_rate", "Currency", "Out-of-Pocket Rate", default="220"),
			f("mile_sb", "Section Break", "Mileage Rates (Rs/km)"),
			f("car_rate_first_800", "Float", "Car — First 800 km", default="14.50"),
			f("car_rate_beyond", "Float", "Car — Beyond 800 km", default="9.05"),
			f("mile_cb", "Column Break"),
			f("motorcycle_rate", "Float", "Motorcycle", default="4.70"),
			f("autocycle_rate", "Float", "Autocycle", default="3.85"),
			f("ot_sb", "Section Break", "Overtime"),
			f("ot_multiplier_day", "Float", "Weekday Day Multiplier", default="1.5"),
			f("ot_multiplier_night", "Float", "Weekday Night Multiplier", default="2.0"),
			f("ot_multiplier_holiday", "Float", "Sunday/Holiday/Cyclone Multiplier", default="2.0"),
			f("ot_cb", "Column Break"),
			f("ot_ceiling_full", "Currency", "Full-Overtime Ceiling", default="60600"),
			f("ot_ceiling_80", "Currency", "80%-Overtime Ceiling", default="77750"),
			f("ot_middle_band_factor", "Percent", "Middle-Band Pay Factor", default="80"),
			f("ot_middle_band_requires_urgent", "Check", "Middle Band Requires Urgent Work", default="1"),
			f("night_duty_pct", "Percent", "Night Duty %", default="25"),
			f("night_duty_annual_months", "Float", "Night Duty Annual Months", default="12"),
			f("night_duty_hours_denominator", "Float", "Night Duty Hours Denominator", default="2080"),
			f("night_duty_rate_multiplier", "Float", "Night Duty Rate Multiplier", default="2"),
			f("attendance_calc_sb", "Section Break", "Attendance Calculation Rules"),
			f("attendance_bonus_base", "Currency", "Attendance Bonus Base", default="2140",
				description="Default for the Attendance Bonus component. Each calculation can override this base."),
			f("incentive_attendance_bonus_base", "Currency", "Incentive Attendance Bonus Base", default="1500",
				description="Default for Incentive Attendance Bonus (INC_A), including the combined PRB Attendance Bonus."),
			f("incentive_presence_base", "Currency", "Incentive Presence Base", default="1500",
				description="Used only by the separate Incentive Presence component (INPB)."),
			f("era_minimum_hours", "Float", "ERA Minimum Excess Hours", default="15"),
			f("era_full_payment_hours", "Float", "ERA Full-Payment Hours", default="30"),
			f("era_cb", "Column Break"),
			f("era_lower_salary_max", "Currency", "ERA Lower Band Maximum", default="31525"),
			f("era_lower_rate", "Percent", "ERA Lower Band Rate", default="15"),
			f("era_lower_cap", "Currency", "ERA Lower Band Cap", default="3940"),
			f("era_upper_salary_min", "Currency", "ERA Upper Band Minimum", default="32350"),
			f("era_upper_salary_max", "Currency", "ERA Upper Band Maximum", default="54200"),
			f("era_upper_rate", "Percent", "ERA Upper Band Rate", default="13"),
			f("era_upper_cap", "Currency", "ERA Upper Band Cap", default="4435"),
			f("era_working_days_divisor", "Float", "ERA Working Days Divisor", default="22"),
			f("era_casual_leave_exemption", "Float", "ERA Casual Leave Exemption", default="1"),
			f("leave_sb", "Section Break", "Leave / Sick Leave Bank"),
			f("slb_annual_entitlement", "Int", "Sick Leave Annual Entitlement (days)", default="21"),
			f("slb_ceiling", "Int", "Sick Leave Bank Ceiling (days)", default="110"),
			f("slb_refund_cap", "Int", "Sick Leave Refund Cap (days)", default="16"),
			f("slb_advance_recovery_days", "Int", "Advance Sick Leave Annual Recovery (days)", default="14"),
			f("leave_cb", "Column Break"),
			f("casual_leave_days", "Int", "Casual Leave (days/year)", default="11"),
			f("leave_refund_divisor", "Int", "Leave Refund Salary Divisor", default="22"),
			f("lsi_exclusion_max", "Currency", "LSI Exclusion Scale Max", default="86750"),
		],
	)


def seed_defaults():
	for key, value in DEFAULTS.items():
		frappe.db.set_single_value("PRB Payroll Settings", key, value)


def setup():
	print("Karyo PRB Payroll Settings setup:")
	create_doctype()
	seed_defaults()
	frappe.db.commit()
	print("Done (rates seeded to 2026 defaults; all configurable).")
