"""Role-facing Notification records (email + desk bell) for Karyo events.

    bench --site dev.localhost execute karyo.setup.notifications.setup

Idempotent delete-recreate. These cover role-directed alerts only; employee- and
guarantor-directed messages need an Employee → User resolution that the
Notification doctype's recipients cannot express, so those live in karyo/notify.py
(wired via doc_events in hooks.py).
"""

import frappe

NOTIFICATIONS = [
	{
		"name": "Loan Settlement Completed",
		"document_type": "Karyo Loan Settlement",
		"event": "Submit",
		"recipients": [
			{"receiver_by_role": "Loan Officer"},
			{"receiver_by_role": "Payroll Finance"},
			{"receiver_by_role": "Karyo Finance"},
		],
		"subject": "Loan {{ doc.loan }} settled — {{ doc.receipt_reference }}",
		"message": (
			"<p>Loan <b>{{ doc.loan }}</b> for employee {{ doc.employee }} was settled for "
			"{{ frappe.utils.fmt_money(doc.total_balance_due) }} on {{ frappe.utils.formatdate(doc.refund_date) }}.</p>"
			'<p><a href="/app/karyo-loan-settlement/{{ doc.name }}">Open settlement and receipt</a></p>'
		),
	},
	{
		"name": "Loan Settlement Reversed",
		"document_type": "Karyo Loan Settlement",
		"event": "Cancel",
		"recipients": [
			{"receiver_by_role": "Loan Officer"},
			{"receiver_by_role": "Payroll Finance"},
			{"receiver_by_role": "Karyo Finance"},
		],
		"subject": "Loan settlement {{ doc.name }} reversed",
		"message": (
			"<p>Settlement {{ doc.name }} for loan <b>{{ doc.loan }}</b> was reversed. "
			"Loan balances, schedule, deductions and lien state were restored.</p>"
			'<p><a href="/app/karyo-loan-settlement/{{ doc.name }}">Open reversal audit</a></p>'
		),
	},
	{
		"name": "PB Run Exception Alert",
		"document_type": "Passage Benefit Computation Run",
		"event": "Value Change",
		"value_changed": "status",
		"condition": 'doc.status in ("Completed with Exceptions", "Failed")',
		"recipients": [{"receiver_by_role": "Passage Benefit Officer"}],
		"subject": "Passage Benefit run {{ doc.name }} requires attention",
		"message": (
			"<p>Run {{ doc.name }} for {{ doc.pay_period }} completed with "
			"{{ doc.total_failed }} failure(s) and {{ doc.total_skipped }} skip(s).</p>"
			'<p><a href="/app/passage-benefit-computation-run/{{ doc.name }}">Open run</a></p>'
		),
	},
	{
		"name": "External Integration Failure",
		"document_type": "MBC Integration Event",
		"event": "Value Change",
		"value_changed": "status",
		"condition": 'doc.status == "Failed"',
		"recipients": [{"receiver_by_role": "Integration Manager"}],
		"subject": "Integration {{ doc.integration_profile }} failed",
		"message": (
			"<p>Integration event {{ doc.name }} failed on attempt {{ doc.attempt }}: "
			"{{ doc.error_message }}.</p>"
			'<p><a href="/app/mbc-integration-event/{{ doc.name }}">Open event</a></p>'
		),
	},
	{
		"name": "PB Claim Awaiting Approval",
		"document_type": "Passage Benefit Application",
		"event": "Value Change",
		"value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Pending Approval"',
		"recipients": [{"receiver_by_role": "HR Manager"}],
		"subject": "PB claim {{ doc.name }} from {{ doc.employee_name }} awaits approval",
		"message": (
			"<p>{{ doc.employee_name }} submitted a passage benefit claim for "
			"<b>{{ doc.usage_item }}</b> — claimable "
			"{{ frappe.utils.fmt_money(doc.claimable_amount) }}.</p>"
			'<p><a href="/app/passage-benefit-application/{{ doc.name }}">Review {{ doc.name }}</a></p>'
		),
	},
	{
		"name": "Loan Pending Committee",
		"document_type": "Karyo Loan",
		"event": "Value Change",
		"value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Loan Committee Scheduled"',
		"recipients": [{"receiver_by_role": "Karyo Loan Committee"}],
		"subject": "Loan {{ doc.name }} ({{ doc.employee_name }}) awaits committee review",
		"message": (
			"<p>{{ doc.employee_name }} applied for a <b>{{ doc.loan_type }}</b> loan of "
			"{{ frappe.utils.fmt_money(doc.approved_amount) }}.</p>"
			'<p><a href="/app/karyo-loan/{{ doc.name }}">Review {{ doc.name }}</a></p>'
		),
	},
	{
		"name": "Loan Approval Pending",
		"document_type": "Karyo Loan", "event": "Value Change", "value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Approval Pending"',
		"recipients": [{"receiver_by_role": "Loan Officer"}],
		"subject": "Loan {{ doc.name }} submitted for approval",
		"message": '<p>Application for {{ doc.employee_name }} is ready for approval routing.</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
	},
	{
		"name": "Loan Approved Decision",
		"document_type": "Karyo Loan", "event": "Value Change", "value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Approved"',
		"recipients": [{"receiver_by_role": "Loan Officer"}],
		"subject": "Loan {{ doc.name }} approved",
		"message": '<p>The loan is approved. Print the agreement and complete prerequisites.</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
	},
	{
		"name": "Loan Rejected Decision",
		"document_type": "Karyo Loan", "event": "Value Change", "value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Rejected"',
		"recipients": [{"receiver_by_role": "Loan Officer"}],
		"subject": "Loan {{ doc.name }} rejected",
		"message": '<p>Reason: {{ doc.rejection_reason }}</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
	},
	{
		"name": "Loan Returned for Rework",
		"document_type": "Karyo Loan", "event": "Value Change", "value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Returned"',
		"recipients": [{"receiver_by_role": "Loan Officer"}, {"receiver_by_role": "HR User"}],
		"subject": "Loan {{ doc.name }} returned for rework",
		"message": '<p>Reason: {{ doc.return_reason }}</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
	},
	{
		"name": "Loan Ready to Disburse",
		"document_type": "Karyo Loan",
		"event": "Value Change",
		"value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Ready for Disbursement"',
		"recipients": [{"receiver_by_role": "Karyo Finance"}],
		"subject": "Loan {{ doc.name }} ({{ doc.employee_name }}) approved — ready to disburse",
		"message": (
			"<p>The <b>{{ doc.loan_type }}</b> loan of "
			"{{ frappe.utils.fmt_money(doc.approved_amount) }} for {{ doc.employee_name }} "
			"is approved and awaits disbursement.</p>"
			'<p><a href="/app/karyo-loan/{{ doc.name }}">Open {{ doc.name }}</a></p>'
		),
	},
	{
		"name": "Loan Awaiting Final Approval",
		"document_type": "Karyo Loan", "event": "Value Change", "value_changed": "workflow_state",
		"condition": 'doc.workflow_state in ("Recommended", "Managing Director Approval Pending")',
		"recipients": [{"receiver_by_role": "Loan Approver"}],
		"subject": "Loan {{ doc.name }} awaits final approval",
		"message": '<p>Review the approval evidence for {{ doc.employee_name }}.</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
	},
	{
		"name": "Loan Activated for Payroll",
		"document_type": "Karyo Loan", "event": "Value Change", "value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Active Loan"',
		"recipients": [{"receiver_by_role": "Loan Officer"}, {"receiver_by_role": "Payroll Finance"}],
		"subject": "Loan {{ doc.name }} activated for payroll recovery",
		"message": '<p>Loan deductions are active.</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
	},
	{
		"name": "Loan Successfully Disbursed",
		"document_type": "Karyo Loan", "event": "Value Change", "value_changed": "workflow_state",
		"condition": 'doc.workflow_state == "Disbursed"',
		"recipients": [{"receiver_by_role": "Loan Officer"}, {"receiver_by_role": "Payroll Finance"}],
		"subject": "Loan {{ doc.name }} successfully disbursed",
		"message": '<p>Disbursement completed and activation is pending.</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
	},
	{
		"name": "Payroll Run Exception",
		"document_type": "PRB Payroll Run",
		"event": "Value Change",
		"value_changed": "exception_code",
		"condition": "doc.exception_code",
		"recipients": [{"receiver_by_role": "HR Manager"}],
		"subject": "Payroll run {{ doc.name }} blocked: {{ doc.exception_code }}",
		"message": (
			"<p>The PRB payroll run for {{ doc.employee_name }} ({{ doc.period }}) raised "
			"exception <b>{{ doc.exception_code }}</b> and needs manual review.</p>"
			'<p><a href="/app/prb-payroll-run/{{ doc.name }}">Open {{ doc.name }}</a></p>'
		),
	},
]


LOAN_LIEN_NOTIFICATION = {
	"name":"Loan Lien Verified for Finance", "document_type":"Karyo Loan", "event":"Value Change",
	"value_changed":"lien_verified", "condition":'doc.lien_verified and doc.lien_status == "Registered"',
	"recipients":[{"receiver_by_role":"Karyo Finance"}],
	"subject":"Loan {{ doc.name }} vehicle lien verified",
	"message":'<p>Registration and lien verification are complete for {{ doc.employee_name }}. Check the remaining agreement and disbursement prerequisites.</p><p><a href="/app/karyo-loan/{{ doc.name }}">Open loan</a></p>',
}
NOTIFICATIONS.append(LOAN_LIEN_NOTIFICATION)


def ensure_loan_lien_notification():
	"""Add the missing alert without replacing the site's recipient configuration."""
	if not frappe.db.exists("Notification",LOAN_LIEN_NOTIFICATION["name"]):
		frappe.get_doc({"doctype":"Notification","__newname":LOAN_LIEN_NOTIFICATION["name"],
			"channel":_channel(),"send_system_notification":1,"enabled":1,"module":"Karyo","is_standard":0,
			"message_type":"HTML",**LOAN_LIEN_NOTIFICATION}).insert(ignore_permissions=True)


def _channel():
	"""Email (+ bell) when outgoing email works; bell-only otherwise.

	The framework sends the system notification and the email in one guarded
	block — an OutgoingEmailError would swallow the bell too. Re-run this setup
	after configuring a default outgoing Email Account to upgrade the channel.
	"""
	if frappe.db.exists("Email Account", {"default_outgoing": 1, "enabled": 1}):
		return "Email"
	print("  ! no default outgoing Email Account — using bell-only System Notification channel")
	return "System Notification"


def setup():
	print("Karyo notifications:")
	channel = _channel()
	for n in NOTIFICATIONS:
		if frappe.db.exists("Notification", n["name"]):
			frappe.delete_doc("Notification", n["name"], ignore_permissions=True, force=True)
		doc = frappe.get_doc(
			{
				"doctype": "Notification",
				"__newname": n["name"],
				"channel": channel,
				"send_system_notification": 1,
				"enabled": 1,
				"module": "Karyo",
				"is_standard": 0,
				"message_type": "HTML",
				**n,
			}
		)
		doc.insert(ignore_permissions=True)
		print(f"  + Notification: {n['name']} [{channel}]")
	frappe.db.commit()
	print("Done.")
