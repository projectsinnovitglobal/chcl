import json

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.loan_approval_outcomes.loan_approval_outcomes import _decision_rows, _matches


class TestLoanApprovalOutcomes(FrappeTestCase):
	def test_version_history_preserves_return_and_reapproval(self):
		loan = frappe._dict(name="LOAN-1", employee="EMP-1", employee_name="Test", loan_type="Staff",
			amount_applied=1200, approved_amount=1000, is_approval_required=1, approval_route="Final Approval",
			approval_role="HR Manager", approval_authority_version="2", committee_remarks="Reviewed", return_reason="Fix amount")
		versions = [
			frappe._dict(owner="committee@example.com", creation="2026-08-01 10:00:00", data=json.dumps({"changed": [["workflow_state", "Review", "Recommended"], ["committee_remarks", "", "Affordable"]]})),
			frappe._dict(owner="manager@example.com", creation="2026-08-02 10:00:00", data=json.dumps({"changed": [["workflow_state", "Recommended", "Returned"], ["return_reason", "", "Correct documents"]]})),
			frappe._dict(owner="manager@example.com", creation="2026-08-03 10:00:00", data=json.dumps({"changed": [["workflow_state", "Recommended", "Approved"], ["approval_route", "", "Final Approval"]]})),
		]
		rows = _decision_rows(loan, versions)
		self.assertEqual([r.outcome for r in rows], ["Recommended", "Returned", "Approved"])
		self.assertEqual(rows[1].remarks, "Correct documents")
		self.assertEqual(rows[2].decision_user, "manager@example.com")
		self.assertTrue(_matches(rows[2], frappe._dict(from_date="2026-08-03", outcome="Approved")))

