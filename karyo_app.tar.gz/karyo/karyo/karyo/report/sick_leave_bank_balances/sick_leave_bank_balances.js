frappe.query_reports["Sick Leave Bank Balances"] = {
	filters: [
		{fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company", default: frappe.defaults.get_user_default("Company")},
		{fieldname: "year", label: __("Posting Year"), fieldtype: "Int", default: new Date().getFullYear()},
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
		{fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department"},
		{fieldname: "status", label: __("Bank Status"), fieldtype: "Select", options: "\nActive\nInactive", default: "Active"},
		{fieldname: "with_refund", label: __("With Refund Only"), fieldtype: "Check"},
	],
};
