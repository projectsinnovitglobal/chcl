"""Expose the authoritative system time zone in Admin Settings."""

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


def apply():
	"""Allow System Managers to choose the default time zone on System Settings."""
	make_property_setter("System Settings", "time_zone", "read_only", 0, "Check")
	make_property_setter("System Settings", "time_zone", "label", "Default Time Zone", "Data")
	make_property_setter(
		"System Settings",
		"time_zone",
		"description",
		"Default time zone used for system dates, attendance, payroll and scheduled processing.",
		"Text",
	)
	frappe.clear_cache(doctype="System Settings")
