"""Module-scoped editors for sequential document naming."""
import re
import frappe
from frappe import _
from frappe.model.naming import NamingSeries, parse_naming_series
from frappe.custom.doctype.property_setter.property_setter import make_property_setter

MODULES = {
 'hr': ['Employee', 'Employee Grievance', 'Employee Promotion', 'Employee Separation', 'Employee Separation Template', 'Employee Transfer', 'Exit Interview', 'Full and Final Statement'],
 'attendance': ['Attendance', 'Attendance Request', 'Employee Checkin', 'Shift Assignment', 'Shift Request', 'Shift Schedule Assignment'],
 'leaves': ['Leave Application', 'Leave Allocation', 'Compensatory Leave Request', 'Leave Encashment', 'Leave Period', 'Leave Policy', 'Leave Policy Assignment', 'Sick Leave Bank Posting', 'Vacation Leave Posting'],
 'payroll': ['Additional Salary', 'Bulk Payroll Run', 'Employee Benefit Application', 'Employee Benefit Claim', 'Employee Incentive', 'Employee Other Income', 'Employee Recurring PDB', 'Employee Tax Exemption Declaration', 'Employee Tax Exemption Proof Submission', 'EOY Bonus', 'Gratuity', 'Once-Off PDB Batch', 'Exceptional Payroll Batch', 'Payroll Entry', 'Payroll Transaction Import', 'PRB Grade Scale Dataset', 'PRB Payroll Run', 'Retention Bonus', 'Salary Structure Assignment', 'Salary Withholding'],
 'expenses': ['Employee Advance', 'Expense Claim', 'Travel Request', 'Vehicle Log'],
 'benefits': ['Passage Benefit Adjustment', 'Passage Benefit Application', 'Passage Benefit Computation', 'Passage Benefit Computation Run', 'Passage Benefit Ledger Entry'],
 'loans': ['Karyo Loan', 'Karyo Loan Correction', 'Karyo Loan History', 'Karyo Loan Interest Change', 'Karyo Loan Ledger Entry', 'Karyo Loan Recast', 'Karyo Loan Settlement', 'Loan Accounting Mapping', 'Loan Approval Authority', 'Loan Condition', 'Loan Document Requirement', 'Loan Insurance Rate', 'Loan Recomputation Parameter'],
}
CUSTOM_DEFAULTS = {'Employee Recurring PDB': 'RPDB-.YYYY.-.#####', 'Once-Off PDB Batch': 'ONCE-.YYYY.-.#####', 'Exceptional Payroll Batch': 'EXCP-.YYYY.-.#####'}


def controller_series(doctype):
 return frappe.db.get_value('Property Setter', {'doc_type':doctype, 'property':'autoname', 'doctype_or_field':'DocType'}, 'value') or CUSTOM_DEFAULTS[doctype]


def _access(module, doctype=None, write=False):
 frappe.only_for('System Manager')
 if module not in MODULES or (doctype and doctype not in MODULES[module]):
  frappe.throw(_('This record type does not belong to this settings module.'), frappe.PermissionError)
 if doctype:
  frappe.has_permission(doctype, 'write' if write else 'read', throw=True)


def _default(doctype):
 meta=frappe.get_meta(doctype)
 field=meta.get_field('naming_series')
 if field:
  options=[s.strip() for s in (field.options or '').splitlines() if s.strip()]
  return field.default or (options[0] if options else ''), options, 'field'
 if doctype in CUSTOM_DEFAULTS:
  return controller_series(doctype), [], 'autoname'
 raw=meta.autoname or ''
 if raw.startswith('format:'):
  raw=raw[7:]
  # Simple date/number formats have an equivalent native series.
  raw=re.sub(r'\{(YYYY|YY|MM|DD|#+)\}',r'.\1.',raw).strip('.')
 return raw, [], 'autoname'


def _pattern(value):
 pattern=NamingSeries(str(value or '').strip())
 pattern.validate()
 if not re.fullmatch(r'[A-Za-z0-9_ /.-]+\.#{1,10}', pattern.series):
  frappe.throw(_('Use a prefix and optional date tokens followed by numeric placeholders, for example HR-ATT-.YYYY.-.#####.'))
 return pattern


def _highest(doctype, prefix):
 # The table is allowlisted above; prefix is always a bound value.
 return int(frappe.db.sql(f'select coalesce(max(cast(substring(name,%s) as unsigned)),0) from `tab{doctype}` where name regexp %s', (len(prefix)+1, '^'+re.escape(prefix)+'[0-9]+$'))[0][0])


@frappe.whitelist()
def listing(module):
 _access(module)
 return [dt for dt in MODULES[module] if frappe.db.exists('DocType',dt) and frappe.has_permission(dt,'read')]


@frappe.whitelist()
def current(module, doctype, series=None):
 _access(module,doctype)
 default,options,kind=_default(doctype)
 pattern=_pattern(series or default)
 prefix=pattern.get_prefix()
 counter=int(frappe.db.get_value('Series',prefix,'current',order_by='name') or 0)
 number=max(counter,_highest(doctype,prefix))+1
 return {'series':pattern.series, 'default_series':default, 'options':options, 'prefix':pattern.series.split('.')[0], 'resolved_prefix':prefix, 'current_number':counter, 'next_number':number, 'preview':parse_naming_series(pattern.series,number_generator=lambda p,d:str(number).zfill(d)), 'can_manage':frappe.has_permission(doctype,'write')}


@frappe.whitelist(methods=['POST'])
def save(module, doctype, series, next_number, expected_default):
 _access(module,doctype,write=True)
 pattern=_pattern(series)
 if not re.fullmatch(r'[0-9]+',str(next_number)) or not 1 <= int(next_number) <= 2147483647:
  frappe.throw(_('Next Number must be a positive whole number up to 2147483647.'))
 number=int(next_number)
 frappe.db.sql('select name from `tabDocType` where name=%s for update',doctype)
 default,options,kind=_default(doctype)
 if default != expected_default:
  frappe.throw(_('Numbering has changed. Reload this editor before saving.'))
 counter=pattern.get_current_value()
 if number <= max(counter,_highest(doctype,pattern.get_prefix())):
  frappe.throw(_('This number has already been used. Choose a higher next number.'))
 # Counters are shared by resolved prefix across record types.
 for other in (dt for types in MODULES.values() for dt in types if dt != doctype):
  if not frappe.db.exists('DocType',other):continue
  value,other_options,other_kind=_default(other)
  for candidate in other_options or [value]:
   if candidate and _pattern(candidate).get_prefix()==pattern.get_prefix():
    frappe.throw(_('This prefix is already used by {0}.').format(other))
 settings=frappe.get_single('Document Naming Settings')
 if kind=='field':
  settings.transaction_type=doctype
  settings.naming_series_options='\n'.join([pattern.series]+[s for s in options if s!=pattern.series])
  settings.user_must_always_select=0
  settings.check_duplicate()
  settings.set_series_options_in_meta(doctype,settings.naming_series_options)
 else:
  make_property_setter(doctype,None,'autoname',pattern.series,'Data',for_doctype=True)
 pattern.update_counter(number-1)
 settings.create_version_log_for_change(pattern.get_prefix(),counter,number-1)
 version=frappe.new_doc('Version')
 version.update({'ref_doctype':'DocType','docname':doctype,'data':frappe.as_json({'changed':[['naming_series',default,pattern.series]]})})
 version.insert(ignore_permissions=True)
 frappe.clear_cache(doctype=doctype)
 return current(module,doctype)
