"""Additional audit fields for dashboard clocking; native check-ins remain authoritative."""
import frappe

from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	audit_fields = [
		{"fieldname": "custom_entry_source", "label": "Entry Source", "fieldtype": "Select",
			"options": "Automatic\nAutomatic Clocking\nManual Input\nAttendance Import", "default": "Automatic",
			"read_only": 1, "in_list_view": 1, "no_copy": 1},
		{"fieldname": "custom_manual_reference", "label": "Manual Input Reference", "fieldtype": "Small Text",
			"read_only": 1, "no_copy": 1},
		{"fieldname": "custom_manual_by", "label": "Manual Input By", "fieldtype": "Link", "options": "User",
			"read_only": 1, "no_copy": 1},
		{"fieldname": "custom_manual_on", "label": "Manual Input On", "fieldtype": "Datetime",
			"read_only": 1, "no_copy": 1},
	]
	create_custom_fields({
		"Employee Checkin": [
			{"fieldname": "custom_clock_note", "label": "Clocking Note", "fieldtype": "Small Text", "insert_after": "device_id", "read_only": 1},
			{"fieldname": "custom_clock_request_id", "label": "Clocking Request ID", "fieldtype": "Data", "insert_after": "custom_clock_note", "read_only": 1, "hidden": 1, "unique": 1, "no_copy": 1},
			{**audit_fields[0], "insert_after": "custom_clock_note"},
			{**audit_fields[1], "insert_after": "custom_entry_source"},
			{**audit_fields[2], "insert_after": "custom_manual_reference"},
			{**audit_fields[3], "insert_after": "custom_manual_by"},
		],
		"Attendance": [
			{**audit_fields[0], "insert_after": "out_time"},
			{"fieldname": "custom_attendance_remark", "label": "Remark", "fieldtype": "Data",
				"insert_after": "custom_entry_source", "read_only": 1, "in_list_view": 1, "no_copy": 1},
			{**audit_fields[1], "insert_after": "custom_attendance_remark"},
			{**audit_fields[2], "insert_after": "custom_manual_reference"},
			{**audit_fields[3], "insert_after": "custom_manual_by"},
		],
		"PRB Overtime Authorization": [
			{**audit_fields[0], "insert_after": "authority_reference"},
			{**audit_fields[1], "insert_after": "custom_entry_source"},
			{**audit_fields[2], "insert_after": "custom_manual_reference"},
			{**audit_fields[3], "insert_after": "custom_manual_by"},
		],
		"PRB Payroll Run": [
			{**audit_fields[0], "insert_after": "run_purpose"},
			{"fieldname": "custom_eligibility_status", "label": "Eligibility", "fieldtype": "Select",
				"options": "Eligible\nNot Eligible", "insert_after": "custom_entry_source", "read_only": 1,
				"in_list_view": 1, "no_copy": 1},
			{"fieldname": "custom_eligibility_reason", "label": "Eligibility Reason", "fieldtype": "Small Text",
				"insert_after": "custom_eligibility_status", "read_only": 1, "no_copy": 1},
			{**audit_fields[1], "insert_after": "custom_eligibility_reason"},
			{**audit_fields[2], "insert_after": "custom_manual_reference"},
			{**audit_fields[3], "insert_after": "custom_manual_by"},
		],
	}, update=True)
	frappe.db.sql(
		"""update `tabAttendance`
		set custom_attendance_remark='Manually Adjusted'
		where custom_entry_source='Manual Input'
			and coalesce(custom_attendance_remark, '')=''"""
	)
	frappe.db.sql(
		"""update `tabAttendance`
		set custom_attendance_remark='Automatic (ESS Clock In/Out)'
		where custom_entry_source='Automatic Clocking'
			and coalesce(custom_attendance_remark, '')=''"""
	)
	frappe.db.sql(
		"""update `tabAttendance` attendance
		join (
			select distinct attendance from `tabEmployee Checkin`
			where coalesce(attendance, '')!='' and custom_entry_source='Automatic Clocking'
		) checkin on checkin.attendance=attendance.name
		set attendance.custom_entry_source='Automatic Clocking',
			attendance.custom_attendance_remark='Automatic (ESS Clock In/Out)'
		where coalesce(attendance.custom_entry_source, '')!='Manual Input'"""
	)
	frappe.db.sql(
		"""update `tabPRB Payroll Run`
		set custom_eligibility_status=case when coalesce(gross_pay, 0)>0 then 'Eligible' else 'Not Eligible' end,
			custom_eligibility_reason=case when coalesce(gross_pay, 0)>0
				then 'Attendance rule produced a payable bonus.'
				else 'Attendance rule produced zero payable bonus.' end
		where run_purpose in ('Attendance Bonus', 'Incentive Attendance Bonus', 'PRB Attendance Bonuses')
			and coalesce(custom_eligibility_status, '')=''"""
	)
