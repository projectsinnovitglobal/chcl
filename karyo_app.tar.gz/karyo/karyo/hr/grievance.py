"""Confidential employee-owned grievance controls."""

import frappe
from frappe import _
from frappe.utils import nowdate

from karyo.hr.clocking import _own_employee
from karyo.security import GRIEVANCE_PRIVILEGED_ROLES


HR_FIELDS = {
	"status",
	"cause_of_grievance",
	"resolved_by",
	"resolution_date",
	"employee_responsible",
	"resolution_detail",
}


def _is_hr_user(user=None):
	return bool(set(frappe.get_roles(user or frappe.session.user)) & GRIEVANCE_PRIVILEGED_ROLES)


def validate_employee_grievance(doc, method=None):
	"""Bind ESS submissions to the signed-in employee and protect HR findings."""
	if _is_hr_user():
		return
	person = _own_employee(required=True)
	if doc.is_new():
		doc.raised_by = person.name
		doc.date = doc.date or nowdate()
		doc.status = "Open"
		for field in HR_FIELDS - {"status"}:
			doc.set(field, None)
		return

	stored = frappe.db.get_value(
		"Employee Grievance", doc.name,
		["raised_by", "status", *sorted(HR_FIELDS - {"status"})], as_dict=True,
	)
	if not stored or stored.raised_by != person.name:
		frappe.throw(_("You can only update your own grievance."), frappe.PermissionError)
	if stored.status != "Open":
		frappe.throw(_("Only an open grievance can be edited by the employee."))
	doc.raised_by = stored.raised_by
	for field in HR_FIELDS:
		if doc.get(field) != stored.get(field):
			frappe.throw(_("Investigation and resolution details can only be updated by HR."), frappe.PermissionError)


def notify_employee(doc, method=None):
	from karyo.hr.self_service import notify_employee_request

	notify_employee_request(doc, method)
