"""Fields the client's Payroll Management manual expects on standard doctypes.

The payroll desk screens (karyo.payroll.screen_specs) show these with the
manual's own labels; everything here is idempotent and safe to re-run.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	create_custom_fields(
		{
			"Company": [
				{
					"fieldname": "karyo_payroll_profile_sb",
					"fieldtype": "Section Break",
					"label": "Payroll Profile",
					"insert_after": "website",
					"collapsible": 0,
				},
				{"fieldname": "karyo_address_line_1", "fieldtype": "Data", "label": "Address Line 1",
					"insert_after": "karyo_payroll_profile_sb"},
				{"fieldname": "karyo_address_line_2", "fieldtype": "Data", "label": "Address Line 2",
					"insert_after": "karyo_address_line_1"},
				{"fieldname": "karyo_address_line_3", "fieldtype": "Data", "label": "Address Line 3",
					"insert_after": "karyo_address_line_2"},
				{"fieldname": "karyo_postal_code", "fieldtype": "Data", "label": "Postal Code",
					"insert_after": "karyo_address_line_3"},
				{"fieldname": "karyo_payroll_profile_cb", "fieldtype": "Column Break",
					"insert_after": "karyo_postal_code"},
				{"fieldname": "karyo_contact_person", "fieldtype": "Data", "label": "Contact Person",
					"insert_after": "karyo_payroll_profile_cb"},
				{"fieldname": "karyo_paye_number", "fieldtype": "Data", "label": "PAYE Employer Registration No",
					"insert_after": "karyo_contact_person"},
			],
			"Bank": [
				{"fieldname": "karyo_address_line_1", "fieldtype": "Data", "label": "Address Line 1",
					"insert_after": "karyo_bank_other_code"},
				{"fieldname": "karyo_address_line_2", "fieldtype": "Data", "label": "Address Line 2",
					"insert_after": "karyo_address_line_1"},
				{"fieldname": "karyo_address_line_3", "fieldtype": "Data", "label": "Address Line 3",
					"insert_after": "karyo_address_line_2"},
				{"fieldname": "karyo_phone", "fieldtype": "Data", "label": "Phone",
					"insert_after": "karyo_address_line_3"},
				{"fieldname": "karyo_email", "fieldtype": "Data", "label": "Email", "options": "Email",
					"insert_after": "karyo_phone"},
			],
			"Employee": [
				{"fieldname": "karyo_national_id", "fieldtype": "Data", "label": "National ID (NID)",
					"insert_after": "karyo_legacy_employee_id"},
				{"fieldname": "karyo_temporary_grade", "fieldtype": "Data", "label": "Temporary Grade",
					"insert_after": "grade"},
			],
			"Salary Slip": [
				{
					"fieldname": "karyo_payroll_computation_sb",
					"fieldtype": "Section Break",
					"label": "Payroll Computation (PAY-CALC-001–017)",
					"insert_after": "net_pay",
					"collapsible": 1,
				},
				{"fieldname": "karyo_monthly_taxable_emolument", "fieldtype": "Currency",
					"label": "Monthly Taxable Emolument", "options": "currency", "read_only": 1,
					"insert_after": "karyo_payroll_computation_sb"},
				{"fieldname": "karyo_taxable_travelling", "fieldtype": "Currency",
					"label": "Taxable Travelling", "options": "currency", "read_only": 1,
					"insert_after": "karyo_monthly_taxable_emolument"},
				{"fieldname": "karyo_taxable_benefits", "fieldtype": "Currency",
					"label": "Taxable Benefits", "options": "currency", "read_only": 1,
					"insert_after": "karyo_taxable_travelling"},
				{"fieldname": "karyo_current_gross_emoluments", "fieldtype": "Currency",
					"label": "Current Gross Emoluments", "options": "currency", "read_only": 1,
					"insert_after": "karyo_taxable_benefits"},
				{"fieldname": "karyo_previous_emoluments", "fieldtype": "Currency",
					"label": "Previous Emoluments", "options": "currency", "read_only": 1,
					"insert_after": "karyo_current_gross_emoluments"},
				{"fieldname": "karyo_total_emoluments", "fieldtype": "Currency",
					"label": "Total Emoluments", "options": "currency", "read_only": 1,
					"insert_after": "karyo_previous_emoluments"},
				{"fieldname": "karyo_payroll_computation_cb", "fieldtype": "Column Break",
					"insert_after": "karyo_total_emoluments"},
				{"fieldname": "karyo_monthly_iet", "fieldtype": "Currency",
					"label": "Monthly/Cumulative IET", "options": "currency", "read_only": 1,
					"insert_after": "karyo_payroll_computation_cb"},
				{"fieldname": "karyo_chargeable_income", "fieldtype": "Currency",
					"label": "Chargeable Income", "options": "currency", "read_only": 1,
					"insert_after": "karyo_monthly_iet"},
				{"fieldname": "karyo_net_paye_payable", "fieldtype": "Currency",
					"label": "Net PAYE Payable", "options": "currency", "read_only": 1,
					"insert_after": "karyo_chargeable_income"},
				{"fieldname": "karyo_previous_paye", "fieldtype": "Currency",
					"label": "Previous PAYE Paid", "options": "currency", "read_only": 1,
					"insert_after": "karyo_net_paye_payable"},
				{"fieldname": "karyo_calculated_paye", "fieldtype": "Currency",
					"label": "Calculated PAYE", "options": "currency", "read_only": 1,
					"insert_after": "karyo_previous_paye"},
				{"fieldname": "karyo_employer_contributions", "fieldtype": "Currency",
					"label": "Employer Contributions", "options": "currency", "read_only": 1,
					"insert_after": "karyo_calculated_paye"},
				{"fieldname": "karyo_employer_cost", "fieldtype": "Currency",
					"label": "Employer Cost", "options": "currency", "read_only": 1,
					"insert_after": "karyo_employer_contributions"},
				{"fieldname": "karyo_computation_trace", "fieldtype": "Code",
					"label": "PAY-CALC Audit Trace", "options": "JSON", "read_only": 1,
					"insert_after": "karyo_employer_cost"},
			],
		},
		ignore_validate=True,
	)
	# Payroll groups are maintained as an Employee Setup master.
	group = frappe.db.get_value("Custom Field", {"dt": "Employee", "fieldname": "karyo_payroll_group"}, "name")
	if group:
		frappe.db.set_value(
			"Custom Field", group,
			{"fieldtype": "Link", "options": "Employee Payroll Group"},
			update_modified=False,
		)
		frappe.clear_cache(doctype="Employee")
	print("  + Payroll desk fields ensured")
