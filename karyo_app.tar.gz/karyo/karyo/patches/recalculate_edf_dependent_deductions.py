"""Recalculate EDF amounts saved against superseded PAYE dependent values."""

import frappe


def execute():
	from karyo.karyo.doctype.employee_tax_declaration.employee_tax_declaration import (
		recalculate_declarations_for_paye_year,
	)

	for row in frappe.get_all(
		"Payroll PAYE Year", filters={"is_active": 1}, fields=["name"], limit_page_length=0
	):
		recalculate_declarations_for_paye_year(row.name)
