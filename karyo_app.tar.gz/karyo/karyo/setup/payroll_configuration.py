"""Configurable payroll rule registry and safe demo seeds (PAY-001/PAY-010)."""

import json

import frappe

from karyo.setup.foundation import f, make_doctype


DEMO_CONFIGURATIONS = [
	("DEMO-PDB-2026", "PDB Catalogue", {"codes": ["BASIC", "PAYE", "NSF", "EOY", "LOAN1"]}),
	(
		"DEMO-PAYE-2026",
		"PAYE",
		{"tax_year": "2026", "bands": [], "warning": "Placeholder only; supply signed PAYE bands."},
	),
	(
		"DEMO-CONTRIBUTIONS-2026",
		"Contribution",
		{"schemes": [], "warning": "Placeholder only; supply signed rates and ceilings."},
	),
	(
		"DEMO-COMPENSATION-2026",
		"Compensation",
		{"schemes": [], "warning": "Placeholder only; supply signed compensation bands."},
	),
	(
		"DEMO-PAY-CALENDAR-2026",
		"Payroll Calendar",
		{"major_minor_enabled": True, "warning": "Dates and cutoffs require client approval."},
	),
	(
		"DEMO-BOARD-SITTING-2026",
		"Board Sitting",
		{"maximum_sittings": 5, "warning": "Manual example; not an approved policy."},
	),
	(
		"DEMO-BANK-FORMATS-2026",
		"Bank Export",
		{"formats": ["MCB-DEMO", "SBM-DEMO", "BARCLAYS-DEMO"], "not_for_submission": True},
	),
	(
		"DEMO-STATUTORY-EXPORTS-2026",
		"Statutory Export",
		{"formats": ["MRA-DEMO", "MNS-DEMO", "NSF-DEMO"], "not_for_submission": True},
	),
	(
		"DEMO-PRB-GRADE-SCALES-2026",
		"PRB Grade Scale",
		{"dataset": "Existing sample grade scales", "warning": "Replace with official Volume 2."},
	),
]

SETTINGS_FIELDS = [
	f("safety_sb", "Section Break", "Environment and Safety"),
	f(
		"environment_mode",
		"Select",
		"Payroll Environment",
		options="Demo\nProduction",
		default="Demo",
		reqd=1,
	),
	f(
		"enforce_production_approval",
		"Check",
		"Require Approved Production Configuration",
		default="1",
		read_only=1,
		description="Always enforced in Production mode.",
	),
	f(
		"demo_warning",
		"Small Text",
		"Demo Warning",
		default="DEMO CONFIGURATION — NOT APPROVED FOR PAYMENTS OR STATUTORY SUBMISSION",
	),
	f("defaults_sb", "Section Break", "Payroll Defaults"),
	f("default_company", "Link", "Default Company", options="Company"),
	f("default_currency", "Link", "Default Currency", options="Currency"),
	f(
		"default_payroll_frequency",
		"Select",
		"Default Payroll Frequency",
		options="Monthly\nBimonthly\nFortnightly\nWeekly\nDaily",
		default="Monthly",
		reqd=1,
	),
	f("defaults_cb", "Column Break"),
	f("payroll_cycle_prefix", "Data", "Payroll Cycle Prefix", default="PAYC-", reqd=1),
	f("transaction_batch_prefix", "Data", "Transaction Batch Prefix", default="PAYT-", reqd=1),
	f("rounding_sb", "Section Break", "Rounding and Exception Controls"),
	f("rounding_precision", "Int", "Currency Rounding Precision", default="2", reqd=1),
	f(
		"rounding_method",
		"Select",
		"Rounding Method",
		options="Round Half Up\nRound Half to Even",
		default="Round Half Up",
		reqd=1,
	),
	f("variance_warning_percent", "Percent", "Variance Warning Threshold", default="20"),
	f("rounding_cb", "Column Break"),
	f(
		"negative_net_pay_policy",
		"Select",
		"Negative Net Pay Policy",
		options="Block\nAllow with Approval\nAllow",
		default="Block",
		reqd=1,
	),
	f("negative_net_pay_limit", "Currency", "Negative Net Pay Limit", default="0"),
	f(
		"enforce_segregation_of_duties",
		"Check",
		"Enforce Processor / Approver Segregation",
		default="1",
	),
	f("payslip_notice_sb", "Section Break", "Payslip Availability Notice"),
	f(
		"notify_payslip_on_close",
		"Check",
		"Email Staff When Payroll Closes",
		default="1",
		description="Training manual: staff are told to verify their payslip on ESS once the period is closed.",
	),
	f(
		"payslip_group_email",
		"Data",
		"Payslip Group Email",
		options="Email",
		description="Group mailbox replies are sent to, for example viewpayslip@company.mu (PS_GROUP_MAIL).",
	),
	f("roles_sb", "Section Break", "Operational Roles"),
	f("input_role", "Link", "Payroll Input Role", options="Role", default="HR User"),
	f("processor_role", "Link", "Payroll Processor Role", options="Role", default="HR Manager"),
	f("reviewer_role", "Link", "Payroll Reviewer Role", options="Role", default="HR Manager"),
	f("roles_cb", "Column Break"),
	f("approver_role", "Link", "Payroll Approver Role", options="Role", default="System Manager"),
	f("finance_role", "Link", "Finance Role", options="Role", default="Karyo Finance"),
	f("auditor_role", "Link", "Payroll Auditor Role", options="Role", default="Auditor"),
	f("config_sb", "Section Break", "Default Effective Configuration Versions"),
	f(
		"default_pdb_configuration",
		"Link",
		"PDB Catalogue",
		options="Payroll Configuration Version",
	),
	f(
		"default_calendar_configuration",
		"Link",
		"Payroll Calendar",
		options="Payroll Configuration Version",
	),
	f(
		"default_paye_configuration",
		"Link",
		"PAYE Configuration",
		options="Payroll Configuration Version",
	),
	f("config_cb", "Column Break"),
	f(
		"default_contribution_configuration",
		"Link",
		"Contribution Configuration",
		options="Payroll Configuration Version",
	),
	f(
		"default_bank_export_configuration",
		"Link",
		"Bank Export Configuration",
		options="Payroll Configuration Version",
	),
	f(
		"default_statutory_export_configuration",
		"Link",
		"Statutory Export Configuration",
		options="Payroll Configuration Version",
	),
]


def create_doctypes():
	make_doctype(
		"Karyo Payroll Settings",
		issingle=1,
		fields=SETTINGS_FIELDS,
	)
	make_doctype(
		"Payroll Configuration Version",
		autoname="format:{config_key}-{version}",
		title_field="config_key",
		fields=[
			f("identity_sb", "Section Break", "Configuration Identity"),
			f("config_key", "Data", "Configuration Key", reqd=1, in_list_view=1),
			f(
				"configuration_type",
				"Select",
				"Configuration Type",
				options=(
					"PDB Catalogue\nOperation Codes\nPAYE\nEDF / IET\nContribution\nCompensation\n"
					"Payroll Calendar\nBoard Sitting\nBank Export\nStatutory Export\n"
					"Payslip / Report Layout\nPRB Grade Scale\nLeave Rules\nAttendance Rules\n"
					"Passage Benefit Rules\nLoan Rules\nLoan Insurance\nLoan Operation Codes"
				),
				reqd=1,
				in_list_view=1,
			),
			f("company", "Link", "Company", options="Company", in_standard_filter=1),
			f("version", "Data", "Version", reqd=1, default="DEMO-1"),
			f("status_cb", "Column Break"),
			f(
				"configuration_status",
				"Select",
				"Status",
				options="Demo\nDraft\nValidated\nApproved\nActive\nSuperseded\nRetired",
				default="Demo",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f("is_production_eligible", "Check", "Approved for Production", default="0", in_list_view=1),
			f("effective_sb", "Section Break", "Validity and Approval"),
			f("effective_from", "Date", "Effective From", reqd=1, in_list_view=1),
			f("effective_to", "Date", "Effective To"),
			f("source_reference", "Data", "Source Reference"),
			f("approval_reference", "Data", "Approval Reference"),
			f("approval_cb", "Column Break"),
			f("approved_by", "Link", "Approved By", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
			f(
				"supersedes",
				"Link",
				"Supersedes",
				options="Payroll Configuration Version",
			),
			f("payload_sb", "Section Break", "Configurable Payload"),
			f(
				"configuration_json",
				"Code",
				"Configuration JSON",
				options="JSON",
				description="Temporary generic payload; specialized payroll masters link to this approved version.",
			),
			f("reference_doctype", "Link", "Specialized Configuration Type", options="DocType"),
			f(
				"reference_name",
				"Dynamic Link",
				"Specialized Configuration",
				options="reference_doctype",
			),
			f("notes", "Small Text", "Notes"),
		],
	)
	_ensure_settings_fields()


def _ensure_settings_fields():
	"""Add newly introduced settings fields on sites where the DocType already exists."""
	meta = frappe.get_doc("DocType", "Karyo Payroll Settings")
	existing = {row.fieldname for row in meta.fields}
	changed = False
	for field in SETTINGS_FIELDS:
		if field["fieldname"] not in existing:
			meta.append("fields", field)
			changed = True
	if changed:
		meta.save(ignore_permissions=True)


def seed_demo_configurations():
	for config_key, configuration_type, payload in DEMO_CONFIGURATIONS:
		if frappe.db.exists(
			"Payroll Configuration Version", {"config_key": config_key, "version": "DEMO-1"}
		):
			continue
		frappe.get_doc(
			{
				"doctype": "Payroll Configuration Version",
				"config_key": config_key,
				"configuration_type": configuration_type,
				"version": "DEMO-1",
				"configuration_status": "Demo",
				"is_production_eligible": 0,
				"effective_from": "2026-01-01",
				"source_reference": "Payroll manual / development placeholder",
				"configuration_json": json.dumps(payload, indent=2),
				"notes": "DEMO ONLY — replace and approve authoritative client configuration before production.",
			}
		).insert(ignore_permissions=True)


def seed_setting_defaults():
	values = {
		"default_payroll_frequency": "Monthly",
		"payroll_cycle_prefix": "PAYC-",
		"transaction_batch_prefix": "PAYT-",
		"rounding_precision": 2,
		"rounding_method": "Round Half Up",
		"variance_warning_percent": 20,
		"negative_net_pay_policy": "Block",
		"negative_net_pay_limit": 0,
		"input_role": "HR User",
		"processor_role": "HR Manager",
		"reviewer_role": "HR Manager",
		"approver_role": "System Manager",
		"finance_role": "Karyo Finance",
		"auditor_role": "Auditor",
	}
	# Existing sites receive the group once. Never overwrite values after initialization.
	if not frappe.db.get_single_value("Karyo Payroll Settings", "default_payroll_frequency"):
		for fieldname, value in values.items():
			frappe.db.set_single_value("Karyo Payroll Settings", fieldname, value)
	links = {
		"default_pdb_configuration": "DEMO-PDB-2026",
		"default_calendar_configuration": "DEMO-PAY-CALENDAR-2026",
		"default_paye_configuration": "DEMO-PAYE-2026",
		"default_contribution_configuration": "DEMO-CONTRIBUTIONS-2026",
		"default_bank_export_configuration": "DEMO-BANK-FORMATS-2026",
		"default_statutory_export_configuration": "DEMO-STATUTORY-EXPORTS-2026",
	}
	for fieldname, config_key in links.items():
		if frappe.db.get_single_value("Karyo Payroll Settings", fieldname):
			continue
		name = frappe.db.get_value(
			"Payroll Configuration Version",
			{"config_key": config_key, "version": "DEMO-1"},
			"name",
		)
		if name:
			frappe.db.set_single_value("Karyo Payroll Settings", fieldname, name)


def setup():
	print("Karyo Payroll configuration foundation:")
	create_doctypes()
	if not frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode"):
		frappe.db.set_single_value("Karyo Payroll Settings", "environment_mode", "Demo")
	frappe.db.set_single_value("Karyo Payroll Settings", "enforce_production_approval", 1)
	from karyo.install import samples_enabled

	if samples_enabled():
		seed_demo_configurations()
	seed_setting_defaults()
	frappe.db.commit()
	print("Done (safe demo configurations seeded; none are production eligible).")
