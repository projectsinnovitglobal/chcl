"""Reusable ordered loan committees and per-loan approval snapshots."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def setup():
	create_custom_fields(
		{
			"Loan Type": [
				{"fieldname": "lien_configuration_sb", "fieldtype": "Section Break", "label": "Lien Configuration", "insert_after": "lien_required", "depends_on": "eval:doc.lien_required"},
				{"fieldname": "lien_default_status", "fieldtype": "Select", "label": "Initial Lien Status", "options": "Pending\nNot Applicable", "default": "Pending", "insert_after": "lien_configuration_sb", "depends_on": "eval:doc.lien_required"},
				{"fieldname": "lien_registration_authority", "fieldtype": "Data", "label": "Lien Registration Authority", "insert_after": "lien_default_status", "depends_on": "eval:doc.lien_required"},
				{"fieldname": "lien_document_required", "fieldtype": "Check", "label": "Lien Document Required", "default": "1", "insert_after": "lien_registration_authority", "depends_on": "eval:doc.lien_required"},
				{"fieldname": "lien_instructions", "fieldtype": "Small Text", "label": "Lien Instructions", "insert_after": "lien_document_required", "depends_on": "eval:doc.lien_required"},
				{"fieldname": "approval_configuration_sb", "fieldtype": "Section Break", "label": "Approval Routing", "insert_after": "requires_md_approval"},
				{"fieldname": "multiple_approval_required", "fieldtype": "Check", "label": "Require Every Selected Approver in Sequence", "default": "1", "insert_after": "approval_configuration_sb"},
				{"fieldname": "loan_committee", "fieldtype": "Link", "label": "Loan Committee", "options": "Loan Committee", "insert_after": "multiple_approval_required"},
				{"fieldname": "direct_approval_group", "fieldtype": "Link", "label": "Direct Approval Group", "options": "Loan Committee", "insert_after": "loan_committee"},
				{"fieldname": "final_approval_group", "fieldtype": "Link", "label": "Final Approval Group", "options": "Loan Committee", "insert_after": "direct_approval_group"},
				{"fieldname": "md_approval_group", "fieldtype": "Link", "label": "Managing Director Approval Group", "options": "Loan Committee", "insert_after": "final_approval_group", "depends_on": "eval:doc.requires_md_approval"},
			],
			"Karyo Loan": [
				{"fieldname": "lien_registration_authority", "fieldtype": "Data", "label": "Lien Registration Authority", "read_only": 1, "insert_after": "vehicle_lien_sb", "depends_on": "eval:doc.lien_status && doc.lien_status != 'Not Applicable'"},
				{"fieldname": "lien_instructions", "fieldtype": "Small Text", "label": "Lien Instructions", "read_only": 1, "insert_after": "lien_registration_authority", "depends_on": "eval:doc.lien_status && doc.lien_status != 'Not Applicable'"},
				{"fieldname": "approval_chain_sb", "fieldtype": "Section Break", "label": "Selected Approval Chain", "insert_after": "approval_delegated_from", "collapsible": 1},
				{"fieldname": "approval_chain_source", "fieldtype": "Data", "label": "Approval Chain Source", "hidden": 1, "read_only": 1, "insert_after": "approval_chain_sb"},
				{"fieldname": "approval_steps", "fieldtype": "Table", "label": "Approval Steps", "options": "Karyo Loan Approval Step", "read_only": 1, "insert_after": "approval_chain_source"},
			],
		},
		ignore_validate=True,
	)
	_ensure_workspace_link()
	frappe.db.commit()
	print("Loan committee masters and ordered approval-chain fields ensured.")


def _ensure_workspace_link():
	"""Keep the master discoverable even when a domain workspace predates it."""
	if not frappe.db.exists("Workspace", "Loans"):
		return
	workspace = frappe.get_doc("Workspace", "Loans")
	if any(row.link_to == "Loan Committee" for row in workspace.links):
		for row in workspace.links:
			if row.link_to == "Loan Committee":
				row.label = "Loan Committee Master"
		workspace.save(ignore_permissions=True)
		return
	workspace.append("links", {
		"type": "Link", "label": "Loan Committee Master", "link_type": "DocType",
		"link_to": "Loan Committee", "hidden": 0, "onboard": 0,
	})
	workspace.save(ignore_permissions=True)
