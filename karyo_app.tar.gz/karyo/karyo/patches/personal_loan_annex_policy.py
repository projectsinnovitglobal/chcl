from karyo.setup.loan_personal_policy import setup


def execute():
	setup()
