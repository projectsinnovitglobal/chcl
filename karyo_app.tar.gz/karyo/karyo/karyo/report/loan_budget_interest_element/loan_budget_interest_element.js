frappe.query_reports["Loan Budget - Interest Element"] = {
	filters: [
		{
			fieldname: "budget_from_date",
			label: __("Budget From Date"),
			fieldtype: "Date",
			reqd: 1,
			default: frappe.datetime.year_start(),
		},
		{
			fieldname: "budget_to_date",
			label: __("Budget To Date"),
			fieldtype: "Date",
			reqd: 1,
			default: frappe.datetime.year_end(),
		},
		{
			fieldname: "projection_view",
			label: __("Projection View"),
			fieldtype: "Select",
			options: "Year-wise\nMonth-wise",
			default: "Year-wise",
		},
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
	],
};
