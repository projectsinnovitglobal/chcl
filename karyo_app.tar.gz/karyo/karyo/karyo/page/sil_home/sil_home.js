// SIL Home — Cloudflare-style AI landing page: greeting hero, omnibox
// (inline KaryoPalette), quick-list columns. Reuses karyo.ai from karyo_ai.js.

frappe.pages["sil-home"].on_page_load = function (wrapper) {
	frappe.ui.make_app_page({
		parent: wrapper,
		title: __("MBC Home"),
		single_column: true,
	});
	$(wrapper).addClass("karyo-home-page");

	const greeting = () => {
		const h = new Date().getHours();
		const part =
			h < 12 ? __("Good morning") : h < 17 ? __("Good afternoon") : __("Good evening");
		const first = (frappe.boot.user.first_name || frappe.session.user_fullname || "").split(" ")[0];
		return first ? `${part}, ${first}.` : part + ".";
	};

	const $body = $(wrapper).find(".layout-main-section");
	if (karyo.shell && karyo.shell.is_ess_user && karyo.shell.is_ess_user()) {
		render_ess_home($body, greeting);
		return;
	}
	$body.empty().append(`
		<div class="karyo-home">
			<div class="karyo-home-hero">
				<div class="karyo-home-kicker">${__("TODAY")}</div>
				<div class="karyo-home-title">${greeting()}</div>
				<div class="karyo-page-subtitle">${__("Start with the work that needs your attention.")}</div>
				<div class="karyo-home-search"></div>
			</div>
			<div class="karyo-home-widgets"></div>
			<div class="karyo-home-needs"></div>
			<div class="karyo-home-columns">
				<div class="karyo-home-col" data-col="employees">
					<div class="karyo-home-col-head">
						<span>${__("Employees")}</span><a href="/app/employee">${__("View all")} →</a>
					</div>
					<div class="karyo-home-card"><div class="karyo-home-empty">${__("Loading…")}</div></div>
				</div>
				<div class="karyo-home-col" data-col="payroll">
					<div class="karyo-home-col-head">
						<span>${__("Payroll")}</span><a href="/app/prb-payroll-run">${__("View all")} →</a>
					</div>
					<div class="karyo-home-card"><div class="karyo-home-empty">${__("Loading…")}</div></div>
				</div>
			</div>
		</div>
	`);

	// Inline command palette as the hero omnibox
	new karyo.ai.KaryoPalette({
		mode: "inline",
		parent: $body.find(".karyo-home-search"),
		placeholder: __("Search MBC HRMS, jump to a record, or ask AI…"),
	});

	const fill = ($card, items, columns) => {
		$card.empty();
		if (!items || !items.length) {
			$card.append(`<div class="karyo-home-empty">${__("Nothing here yet")}</div>`);
			return;
		}
		const $wrap = $('<div class="karyo-home-table-wrap"></div>').appendTo($card);
		const $table = $('<table class="karyo-home-table pm-table"><thead><tr></tr></thead><tbody></tbody></table>').appendTo($wrap);
		columns.forEach((column) => $("<th scope=\"col\"></th>").text(column.label).appendTo($table.find("thead tr")));
		items.forEach((item) => {
			const $row = $("<tr tabindex=\"0\"></tr>").appendTo($table.find("tbody"));
			columns.forEach((column) => {
				const value = item[column.field] || "—";
				const $cell = $("<td></td>").appendTo($row);
				if (column.pill) $cell.append(karyo.pages.pill(value));
				else $cell.text(value);
			});
			const open = () => frappe.set_route(item.route.replace(/^\/app\//, ""));
			$row.on("click", open).on("keydown", (event) => {
				if (event.key !== "Enter" && event.key !== " ") return;
				event.preventDefault();
				open();
			});
		});
	};

	karyo.live.request(wrapper, {
		method: "karyo.ai.api.home_data",
		callback: (r) => {
			const data = r.message || {};

			// Keep the live, clickable operating measures immediately below search.
			const $w = $body.find(".karyo-home-widgets").empty();
			if ((data.stats || []).length) karyo.pages.stats($w, data.stats);
			if ((data.module_tiles || []).length) karyo.pages.tiles($w, data.module_tiles);
			if (data.headcount_trend) {
				const $cgrid = karyo.pages.grid($w, 1);
				karyo.pages.chart_card($cgrid, {
					title: __("New joiners by month"),
					type: "bar",
					data: data.headcount_trend,
					is_series: 1,
					height: 180,
					colors: ["#0b6cfb"],
					link: "/app/employee",
				});
			}

			// Real, role-gated "needs you" queue (from the shared approvals feed).
			karyo.pages.task_queue($body.find(".karyo-home-needs").empty(), {
				title: __("Needs you today"),
				tasks: data.needs || [],
				action: { label: __("View all"), route: "karyo-approvals" },
			});

			fill($body.find('[data-col="employees"] .karyo-home-card'), data.employees, [
				{ label: __("Employee name"), field: "label" },
				{ label: __("Employee ID"), field: "description" },
				{ label: __("Status"), field: "status", pill: true },
			]);
			fill($body.find('[data-col="payroll"] .karyo-home-card'), data.payroll, [
				{ label: __("Payroll run"), field: "label" },
				{ label: __("Period"), field: "description" },
				{ label: __("Status"), field: "status", pill: true },
			]);
		},
	});
};

function render_ess_home($body, greeting) {
	const actions = [
		[__("My time"), __("Leave, attendance & balances in one place"), "clock", "my-time"],
		[__("Request leave"), __("Plan time away and follow approval"), "calendar", "leave-application/new-leave-application"],
		[__("Overtime Claim"), __("View approved overtime hours and payroll claim status"), "clock", "my-overtime-bonuses"],
		[__("Raise a grievance"), __("Send a confidential workplace concern to HR"), "message", "employee-grievance/new-employee-grievance"],
		[__("Submit a claim"), __("Claim work expenses and attach receipts"), "receipt", "expense-claim/new-expense-claim"],
		[__("Fix attendance"), __("Select attendance records and request a correction"), "clock", "my-attendance"],
		[__("View payslips"), __("Open your salary history and payslips"), "pay", "my-payroll"],
	];
	if (karyo.migration?.can_upload?.()) {
		actions.splice(2, 0, [__("Migration Upload"), __("Upload previous Leave, Employee and Passage Benefit balances"), "receipt", "my-migration"]);
	}
	const services = [
		[__("My Calendar"), __("Holidays, birthdays and your approved leave this month"), "calendar", "my-calendar"],
		[__("My Leave Bank"), __("Allocated, taken and available leave balances"), "calendar", "my-leave-bank"],
		[__("My Documents"), __("View and download issued letters and documents"), "receipt", "my-documents"],
		[__("My PB Bank"), __("Balance, redemptions and benefit history"), "pay", "my-pb-bank"],
		[__("My Leaves"), __("Balances, applications and holidays"), "calendar", "leave-application"],
		[__("My Attendance"), __("Attendance records and check-ins"), "clock", "my-attendance"],
		[__("Overtime Claim"), __("Overtime request, approval and claim calculation"), "clock", "my-overtime-bonuses"],
		[__("Expense Claims"), __("Expense claims and their approval status"), "receipt", "my-claims"],
		[__("My Grievances"), __("Track concerns raised with HR"), "message", "employee-grievance"],
		[__("Employee Advances"), __("Request and track an advance"), "pay", "employee-advance"],
		[__("Request a shift change"), __("Current shift, requested shift, reason, duration and live status"), "clock", "request-shift-change"],
		[__("My Profile"), __("Personal information and account settings"), "calendar", "user-profile"],
	];
	const card = ([label, description, symbol, route], compact = false) => `
		<a class="karyo-ess-action${compact ? " karyo-ess-service" : ""}" href="/app/${route}" data-route="${route}">
			<span class="karyo-ess-action-icon karyo-ess-icon-${symbol}"></span>
			<span class="karyo-ess-action-copy"><strong>${label}</strong><small>${description}</small></span>
			<span class="karyo-ess-action-arrow">→</span>
		</a>`;

	$body.empty().append(`
		<div class="karyo-home karyo-ess-home">
			<header class="karyo-ess-hero">
				<div class="karyo-home-kicker">${__("EMPLOYEE SELF SERVICE")}</div>
				<h1>${greeting()}</h1>
				<p>${__("Everything you need for your workday, requests and pay—in one place.")}</p>
			</header>
			<section class="karyo-ess-section">
				<div class="karyo-ess-section-head"><h2>${__("Popular actions")}</h2><span>${__("Start a new request")}</span></div>
				<div class="karyo-ess-actions">${actions.map((item) => card(item)).join("")}</div>
			</section>
			<section class="karyo-ess-section">
				<div class="karyo-ess-section-head"><h2>${__("My self service")}</h2><span>${__("View and manage your information")}</span></div>
				<div class="karyo-ess-services">${services.map((item) => card(item, true)).join("")}</div>
			</section>
		</div>`);
	const $resources = $('<section class="karyo-ess-section">').appendTo($body.find('.karyo-ess-home'));
	karyo.employee_resources.mount($resources, 'home-employee-resources');
	const $payslips = $('<section class="karyo-ess-section pm-home-payslips"><div class="karyo-ess-section-head"><h2></h2><a href="/app/my-payroll"></a></div><div class="pm-home-payslip-table"></div></section>');
	$payslips.find('h2').text(__('Generated payslips'));
	$payslips.find('a').text(__('All payslips / filter by month'));
	$payslips.insertAfter($body.find('.karyo-ess-hero'));
	let previousPayslips;
	const loadPayslips = async () => {
		try {
			const result = await frappe.xcall('karyo.desk.payroll_management.employee_payslips');
			const rows = (result?.rows || []).slice(0, 6), serialized = JSON.stringify(rows);
			if (serialized === previousPayslips) return;
			previousPayslips = serialized;
			const $table = $payslips.find('.pm-home-payslip-table').empty();
			if (rows.length) karyo.payroll.employee_payslip_table($table, rows, {view:name=>frappe.set_route('my-payroll',name)});
			else $('<p class="text-muted">').text(__('No generated payslips yet.')).appendTo($table);
		} catch (error) {
			const $table = $payslips.find('.pm-home-payslip-table').empty();
			$('<p class="text-muted">').text(__('Payslips could not be loaded. Refresh the page or contact Payroll.')).appendTo($table);
			throw error;
		}
	};
	karyo.live.watch('employee-home-payslips', loadPayslips, ['Salary Slip'], () => frappe.get_route()[0] === 'sil-home')(true);
	$body.find("[data-route]").on("click", function (event) {
		if (event.ctrlKey || event.metaKey) return;
		event.preventDefault();
		const route = $(this).attr("data-route");
		if (route === "request-shift-change") karyo.shift_change.open();
		else if (route === "migration-upload") karyo.migration.open_upload();
		else frappe.set_route(route);
	});
}
