from uuid import uuid4
import frappe
from frappe.utils import nowdate, add_days, getdate
from karyo.tests.test_live_menus import TestLiveMenus
from karyo.hr.self_service import my_leaves, allocation_balances, leave_balances


class TestLeaveBalanceCalculation(TestLiveMenus):
	def make_allocation(self):
		suffix=uuid4().hex[:8]
		kind=frappe.get_doc({'doctype':'Leave Type','leave_type_name':'Balance test '+suffix,'karyo_mbc_leave_code':'TBAL'+suffix,'karyo_code_description':'Balance calculation test','include_holiday':1}).insert()
		allocation=frappe.get_doc({'doctype':'Leave Allocation','employee':self.employee.name,'leave_type':kind.name,'from_date':nowdate(),'to_date':add_days(nowdate(),30),'new_leaves_allocated':12}).insert()
		allocation.submit()
		return kind.name

	def assert_balances(self,kind,taken,pending,available):
		frappe.set_user('Administrator')
		admin=next(b for b in allocation_balances(self.employee.name)['balances'] if b['leave_type']==kind)
		frappe.set_user(self.email)
		employee=next(b for b in my_leaves()['balances'] if b['leave_type']==kind)
		for row in (employee,admin):
			self.assertEqual((row['total'],row['taken'],row['pending'],row['remaining']),(12,taken,pending,available))
		frappe.set_user('Administrator')

	def test_pending_approved_rejected_cancelled_counts_match(self):
		kind=self.make_allocation()
		self.assert_balances(kind,0,0,12)
		doc=frappe.get_doc({'doctype':'Leave Application','employee':self.employee.name,'leave_type':kind,'from_date':add_days(nowdate(),2),'to_date':add_days(nowdate(),5),'status':'Open','leave_approver':'Administrator','description':'Balance test request'}).insert()
		self.assert_balances(kind,0,4,8)
		doc.status='Approved';doc.save()
		self.assert_balances(kind,0,4,8)
		doc.submit()
		self.assert_balances(kind,4,0,8)
		doc.karyo_cancellation_reason='Balance test cancellation'
		doc.cancel()
		self.assert_balances(kind,0,0,12)
		rejected=frappe.copy_doc(doc);rejected.docstatus=0;rejected.status='Open';rejected.insert()
		self.assert_balances(kind,0,4,8)
		rejected.status='Rejected';rejected.save();rejected.submit()
		self.assert_balances(kind,0,0,12)

	def test_half_day_pending_reserves_only_half_day(self):
		kind=self.make_allocation();day=add_days(nowdate(),2)
		frappe.get_doc({'doctype':'Leave Application','employee':self.employee.name,'leave_type':kind,'from_date':day,'to_date':day,'half_day':1,'half_day_date':day,'status':'Open','leave_approver':'Administrator','description':'Half-day balance test'}).insert()
		self.assert_balances(kind,0,0.5,11.5)

	def test_legacy_balance_and_later_transactions_feed_employee_dashboard(self):
		as_at = add_days(nowdate(), -1)
		frappe.get_doc({
			"doctype": "Leave Balance", "employee": self.employee.name,
			"leave_year": getdate(as_at).year, "leave_code": "CASL01",
			"closing_balance": 9, "as_at_date": as_at,
		}).insert()
		frappe.get_doc({
			"doctype": "Leave Transaction", "leave_request_id": "LEGACY-" + uuid4().hex,
			"employee": self.employee.name, "leave_code": "CASL01",
			"start_date": nowdate(), "end_date": nowdate(), "duration_units": 1,
			"legacy_status": "Approved", "source_record_audit_ref": "Legacy leave row",
		}).insert()
		balance = next(row for row in leave_balances(self.employee.name) if row["leave_code"] == "CASL01")
		self.assertEqual((balance["total"], balance["taken"], balance["remaining"]), (9, 1, 8))
		self.assertEqual(balance["source"], "Leave Balance")

	def test_submitted_allocation_syncs_leave_balance_register(self):
		leave_type = self.make_allocation()
		code = frappe.db.get_value("Leave Type", leave_type, "karyo_mbc_leave_code")
		row = frappe.db.get_value(
			"Leave Balance",
			{"employee": self.employee.name, "leave_code": code, "as_at_date": nowdate()},
			["closing_balance", "is_system_synced"], as_dict=True,
		)
		self.assertTrue(row)
		self.assertEqual(row.closing_balance, 12)
		self.assertEqual(row.is_system_synced, 1)
