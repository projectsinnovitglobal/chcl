import frappe
from frappe.core.doctype.document_naming_settings.document_naming_settings import DocumentNamingSettings
from frappe.model.naming import NamingSeries


HRMS_NAMING_MODULES = frozenset({"HR", "Payroll", "Karyo"})
HRMS_NAMING_DOCTYPES = frozenset({"Employee"})


class HRMSDocumentNamingSettings(DocumentNamingSettings):
	"""Limit naming controls to the HRMS product boundary."""

	def _get_transactions(self) -> list[str]:
		readable_transactions = super()._get_transactions()
		if not readable_transactions:
			return []

		doctypes = frappe.get_all(
			"DocType",
			filters={"name": ("in", readable_transactions)},
			fields=["name", "module"],
			limit_page_length=0,
		)
		return sorted(
			row.name
			for row in doctypes
			if row.module in HRMS_NAMING_MODULES or row.name in HRMS_NAMING_DOCTYPES
		)

	def _get_prefixes(self, doctypes) -> list[str]:
		"""Return only prefixes configured by the allowed HRMS documents."""
		series_templates = set()
		for doctype in doctypes:
			try:
				series_templates.update(frappe.get_meta(doctype).get_naming_series_options())
			except frappe.DoesNotExistError:
				frappe.clear_last_message()

		prefixes = set()
		for series_template in series_templates:
			if not series_template:
				continue
			try:
				prefix = NamingSeries(series_template).get_prefix()
				if prefix and "{" not in prefix:
					prefixes.add(prefix)
			except Exception:
				frappe.clear_last_message()
		return sorted(prefixes)
