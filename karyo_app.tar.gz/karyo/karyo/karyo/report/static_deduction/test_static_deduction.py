from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.static_deduction.static_deduction import execute


class TestStaticDeduction(FrappeTestCase):
	@patch("karyo.karyo.report.loan_report_utils.permitted_loan_names", return_value=("L-1",))
	@patch("frappe.db.sql")
	def test_statuses_usage_totals_and_filters(self, sql, _permitted):
		sql.return_value = [
			frappe._dict(additional_salary="AS-OLD", loan="L-1", employee="E-1", component="Capital", monthly_amount=100,
				effective_from="2026-01-01", effective_to="2027-01-01", creation="2026-01-01", additional_salary_docstatus=1,
				disabled=1, deduction_row_status="Active", payroll_use_count=2),
			frappe._dict(additional_salary="AS-NEW", loan="L-1", employee="E-1", component="Capital", monthly_amount=125,
				effective_from="2026-06-01", effective_to="2027-06-01", creation="2026-06-01", additional_salary_docstatus=1,
				disabled=0, deduction_row_status="Active", payroll_use_count=1),
		]
		_columns, rows, _message, _chart, summary = execute({"status": "Superseded", "component": "Capital"})
		self.assertEqual([row.additional_salary for row in rows], ["AS-OLD"])
		self.assertEqual(rows[0].status, "Superseded")
		self.assertEqual(summary[0]["value"], 1)
		query = sql.call_args.args[0]
		self.assertIn("tabSalary Detail", query)
		self.assertIn("ss.docstatus=1", query)

	@patch("karyo.karyo.report.loan_report_utils.permitted_loan_names", return_value=("L-2", "L-3"))
	@patch("frappe.db.sql")
	def test_cancelled_and_ended_states(self, sql, _permitted):
		sql.return_value = [
			frappe._dict(additional_salary="AS-C", loan="L-2", employee="E-2", component="Interest", monthly_amount=10,
				effective_from="2025-01-01", effective_to="2028-01-01", creation="2025-01-01", additional_salary_docstatus=2,
				disabled=1, deduction_row_status="Cancelled", payroll_use_count=0),
			frappe._dict(additional_salary="AS-E", loan="L-3", employee="E-3", component="Insurance", monthly_amount=20,
				effective_from="2020-01-01", effective_to="2020-12-31", creation="2020-01-01", additional_salary_docstatus=1,
				disabled=0, deduction_row_status="Active", payroll_use_count=3),
		]
		_columns, rows, *_rest = execute()
		self.assertEqual([row.status for row in rows], ["Cancelled", "Ended"])

	@patch("karyo.karyo.report.loan_report_utils.permitted_loan_names", return_value=("L-1",))
	@patch("frappe.db.sql")
	def test_combines_components_into_one_loan_row(self, sql, _permitted):
		base = dict(loan="L-1", employee="E-1", employee_name="Employee One",
			effective_from="2026-01-01", effective_to="2027-01-01", creation="2026-01-01",
			additional_salary_docstatus=1, disabled=0, deduction_row_status="Active",
			payroll_use_count=1)
		sql.return_value = [
			frappe._dict(**base, additional_salary="AS-C", component="Capital", monthly_amount=1000),
			frappe._dict(**base, additional_salary="AS-I", component="Interest", monthly_amount=100),
			frappe._dict(**base, additional_salary="AS-N", component="Insurance", monthly_amount=10),
		]
		_columns, rows, *_rest = execute()
		self.assertEqual(len(rows), 1)
		self.assertEqual(rows[0].capital_amount, 1000)
		self.assertEqual(rows[0].interest_amount, 100)
		self.assertEqual(rows[0].insurance_amount, 10)
		self.assertEqual(rows[0].total_monthly_emi, 1110)

	def test_rejects_inverted_dates(self):
		with self.assertRaises(frappe.ValidationError):
			execute({"from_date": "2026-08-01", "to_date": "2026-07-01"})
