"""Payment progress is separate from Salary Slip submission and accounting."""
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
    create_custom_fields({'Salary Slip': [{
        'fieldname': 'karyo_payment_status', 'label': 'Payment Status', 'fieldtype': 'Select',
        'options': 'Draft\nProcessing\nPAID', 'default': 'Draft', 'insert_after': 'status',
        'read_only': 1, 'allow_on_submit': 1, 'no_copy': 1,
        'description': 'Managed from the payroll table. Downloads are available after PAID.'
    }]}, update=True)
