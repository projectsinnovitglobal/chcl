from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.payroll.bank_split import split_for_employee


class TestSalaryBankSplit(FrappeTestCase):
	@patch("karyo.payroll.bank_split.frappe.db.get_value")
	def test_fixed_secondary_and_net_balance_to_primary(self, get_value):
		get_value.return_value = frappe._dict(
			salary_mode="Bank", karyo_payroll_bank="PRIMARY", karyo_payroll_bank_branch="P-01",
			bank_ac_no="111", karyo_secondary_payroll_bank="SECONDARY",
			karyo_secondary_payroll_bank_branch="S-01", karyo_secondary_bank_account_no="222",
			karyo_secondary_bank_fixed_amount=5000, karyo_secondary_bank_effective_from="2026-01-01",
			karyo_secondary_bank_effective_to=None,
		)
		result = split_for_employee("EMP-1", 18000, "2026-10-01")
		self.assertEqual(result.secondary_amount, 5000)
		self.assertEqual(result.primary_amount, 13000)

	@patch("karyo.payroll.bank_split.frappe.db.get_value")
	def test_secondary_never_exceeds_net_pay(self, get_value):
		get_value.return_value = frappe._dict(
			salary_mode="Bank", karyo_payroll_bank="PRIMARY", karyo_payroll_bank_branch="P-01",
			bank_ac_no="111", karyo_secondary_payroll_bank="SECONDARY",
			karyo_secondary_payroll_bank_branch="S-01", karyo_secondary_bank_account_no="222",
			karyo_secondary_bank_fixed_amount=5000, karyo_secondary_bank_effective_from=None,
			karyo_secondary_bank_effective_to=None,
		)
		result = split_for_employee("EMP-1", 3200, "2026-10-01")
		self.assertEqual(result.secondary_amount, 3200)
		self.assertEqual(result.primary_amount, 0)
