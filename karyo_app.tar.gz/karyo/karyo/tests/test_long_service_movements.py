"""Transactional tests for long-service salary and structured employee movements."""
import unittest
from unittest.mock import patch

import frappe
from frappe.utils import add_days, getdate
from karyo.tests import test_salary_scales as fixtures
from karyo.payroll.salary_scales import approved_appointment, governed_scale_amount, validate_salary_slip_base


class TestLongServiceMovements(unittest.TestCase):
    def setUp(self):
        fixtures.TestSalaryScales.setUp(self)
        department=frappe.get_doc({'doctype':'Department','department_name':'SOURCE-'+self.uid,
            'company':self.employee.company}).insert()
        frappe.db.set_value('Employee',self.employee.name,{'department':department.name,'karyo_on_payroll':0,
            'karyo_section':None,'karyo_location':None,'date_of_birth':'1970-01-01'})
        self.employee.reload()
    tearDown = fixtures.TestSalaryScales.tearDown
    make_scale = fixtures.TestSalaryScales.make_scale
    appointment = fixtures.TestSalaryScales.appointment

    def lsi(self, **values):
        return self.appointment(salary_point='38', beyond_scale_authorized=1,
            beyond_scale_salary=36000, beyond_scale_authority='HR Board approval TEST',
            beyond_scale_reason='Long-term service at the scale maximum', **values)

    def test_long_service_salary_reaches_employee_assignment_and_payroll(self):
        appointment = self.lsi(basic_salary=34825).insert()
        self.assertEqual(appointment.basic_salary,36000)
        appointment.submit()
        employee = frappe.db.get_value('Employee',self.employee.name,
            ['karyo_scale_basic_salary','ctc','karyo_scale_salary_point'],as_dict=True)
        self.assertEqual((employee.karyo_scale_basic_salary,employee.ctc,employee.karyo_scale_salary_point),(36000,36000,38))
        self.assertEqual(frappe.db.get_value('Salary Structure Assignment',appointment.salary_structure_assignment,'base'),36000)
        run=frappe.get_doc({'doctype':'PRB Payroll Run','employee':self.employee.name,'calculation_date':'2026-10-01','review_year':2026})
        run._compute_basic()
        self.assertEqual(run.basic_salary,36000)
        self.assertEqual(run.karyo_salary_appointment,appointment.name)
        self.assertFalse(run.exception_code)
        slip=frappe._dict(employee=self.employee.name,salary_structure=appointment.salary_structure,
            start_date='2026-10-01',end_date='2026-10-31',posting_date='2026-10-31')
        validate_salary_slip_base(slip)
        self.assertEqual(slip.karyo_salary_base,36000)
        self.assertEqual(slip.karyo_salary_appointment,appointment.name)
        appointment.beyond_scale_salary=37000
        with self.assertRaises(frappe.ValidationError):
            appointment.save()

    def test_long_service_requires_top_point_more_than_max_and_authority(self):
        base={'beyond_scale_authorized':1,'beyond_scale_salary':36000,
              'beyond_scale_authority':'TEST','beyond_scale_reason':'Long service'}
        for point,change in [('1',{}),('38',{'beyond_scale_salary':34825}),
                             ('38',{'beyond_scale_salary':-1}),('38',{'beyond_scale_salary':'NaN'}),
                             ('38',{'beyond_scale_salary':'36000.001'}),
                             ('38',{'beyond_scale_authority':''}),('38',{'beyond_scale_reason':''})]:
            with self.subTest(point=point,change=change),self.assertRaises(frappe.ValidationError):
                governed_scale_amount(self.scale,point,{**base,**change})
        with patch('frappe.get_roles',return_value=['HR User']),self.assertRaises(frappe.PermissionError):
            governed_scale_amount(self.scale,'38',base)
        with self.assertRaises(frappe.ValidationError):
            governed_scale_amount(frappe._dict(scale_type='Flat Salary',basic_salary=20000),'',base)

    def target_grade(self):
        return frappe.get_doc({'doctype':'Employee Grade','name':'MOVE-GRADE-'+self.uid,
            'karyo_grade_description':'Movement target', 'karyo_salary_scales':[{
                'salary_scale':self.scale.name,'effective_from':'2026-01-01','effective_to':'2026-12-31'}]}).insert()

    def movement(self, doctype, **values):
        date=getdate()
        self.appointment(salary_point='38',effective_to='2026-12-31').insert().submit()
        target=self.target_grade()
        date_field='promotion_date' if doctype=='Employee Promotion' else 'transfer_date'
        return frappe.get_doc({'doctype':doctype,'employee':self.employee.name,date_field:date,
            'karyo_new_grade':target.name,'karyo_new_salary_point':'38',
            'karyo_end_date':'2026-12-31','beyond_scale_authorized':1,
            'beyond_scale_salary':36000,'beyond_scale_authority':'Board TEST',
            'beyond_scale_reason':'Long service approved','karyo_seniority':'Senior',
            'karyo_vacancy_reference':'VAC-TEST','karyo_date_appointed':date,
            'karyo_probation_start':date,'karyo_probation_end':add_days(date,10),**values})

    def assert_movement_salary_and_reversal(self,doctype):
        movement=self.movement(doctype).insert()
        movement.submit()
        current=approved_appointment(self.employee.name,getdate())
        self.assertEqual(current.basic_salary,36000)
        self.assertEqual(current.name,movement.karyo_salary_appointment)
        self.assertEqual(frappe.db.get_value('Employee',self.employee.name,'karyo_level_of_seniority'),'Senior')
        self.assertEqual(frappe.db.get_value('Employee',self.employee.name,'karyo_vacancy_reference'),'VAC-TEST')
        appointment=frappe.get_doc('Employee Salary Appointment',current.name)
        self.assertEqual(appointment.beyond_scale_authority,'Board TEST')
        self.assertEqual(frappe.db.get_value('Salary Structure Assignment',appointment.salary_structure_assignment,'base'),36000)
        movement.cancel()
        current=approved_appointment(self.employee.name,getdate())
        self.assertEqual(current.basic_salary,34825)
        self.assertEqual(current.grade,self.grade.name)
        self.assertEqual(frappe.db.get_value('Employee',self.employee.name,'ctc'),34825)
        self.assertFalse(frappe.db.get_value('Employee',self.employee.name,'karyo_level_of_seniority'))

    def test_promotion_maps_long_service_salary_and_cancellation(self):
        self.assert_movement_salary_and_reversal('Employee Promotion')

    def test_transfer_maps_long_service_salary_and_cancellation(self):
        self.assert_movement_salary_and_reversal('Employee Transfer')

    def test_department_transfer_preserves_salary_and_clears_old_scope(self):
        self.appointment(salary_point='38').insert().submit()
        department=frappe.get_doc({'doctype':'Department','department_name':'MOVE-'+self.uid,
            'company':self.employee.company}).insert()
        movement=frappe.get_doc({'doctype':'Employee Transfer','employee':self.employee.name,
            'transfer_date':getdate(),'karyo_new_department':department.name}).insert()
        before=approved_appointment(self.employee.name,getdate())
        movement.submit()
        employee=frappe.get_doc('Employee',self.employee.name)
        self.assertEqual(employee.department,department.name)
        self.assertFalse(employee.karyo_section)
        self.assertFalse(employee.karyo_location)
        self.assertEqual(approved_appointment(self.employee.name,getdate()).name,before.name)
        movement.cancel()
        self.assertEqual(frappe.db.get_value('Employee',self.employee.name,'department'),self.employee.department)

    def test_movement_date_and_scope_validation(self):
        date=getdate()
        department=frappe.get_doc({'doctype':'Department','department_name':'OTHER-'+self.uid,
            'company':self.employee.company}).insert()
        section=frappe.get_doc({'doctype':'Employee Section','section_code':'SEC-'+self.uid,
            'section_name':'Other scope','department':department.name,'company':self.employee.company}).insert()
        for values in [{'karyo_end_date':add_days(date,-1)},
                       {'karyo_probation_start':date,'karyo_probation_end':add_days(date,-1)},
                       {'karyo_new_section':section.name}]:
            with self.subTest(values=values),self.assertRaises(frappe.ValidationError):
                frappe.get_doc({'doctype':'Employee Transfer','employee':self.employee.name,
                    'transfer_date':date,**values}).insert()

    def test_long_service_can_be_recorded_without_changing_grade(self):
        self.appointment(salary_point='38').insert().submit()
        movement=frappe.get_doc({'doctype':'Employee Promotion','employee':self.employee.name,
            'promotion_date':getdate(),'karyo_new_grade':self.grade.name,'karyo_new_salary_point':'38',
            'beyond_scale_authorized':1,'beyond_scale_salary':36000,
            'beyond_scale_authority':'TEST','beyond_scale_reason':'Long service'}).insert()
        movement.submit()
        current=approved_appointment(self.employee.name,getdate())
        self.assertEqual((current.grade,current.basic_salary),(self.grade.name,36000))

    def test_department_section_location_and_site_mapping(self):
        self.appointment(salary_point='38').insert().submit()
        department=frappe.get_doc({'doctype':'Department','department_name':'TARGET-'+self.uid,
            'company':self.employee.company}).insert()
        section=frappe.get_doc({'doctype':'Employee Section','section_code':'TARGET-SEC-'+self.uid,
            'section_name':'Target section','department':department.name}).insert()
        location=frappe.get_doc({'doctype':'Employee Location','location_code':'TARGET-LOC-'+self.uid,
            'location_name':'Target location','department':department.name,'section':section.name,
            'address_site':'Test site'}).insert()
        movement=frappe.get_doc({'doctype':'Employee Transfer','employee':self.employee.name,
            'transfer_date':getdate(),'karyo_new_department':department.name,
            'karyo_new_section':section.name,'karyo_new_location':location.name}).insert()
        self.assertEqual(movement.karyo_site,'Test site')
        movement.submit()
        employee=frappe.get_doc('Employee',self.employee.name)
        self.assertEqual((employee.department,employee.karyo_section,employee.karyo_location),
                         (department.name,section.name,location.name))
        movement.cancel()
        employee.reload()
        self.assertEqual(employee.department,self.employee.department)
        self.assertFalse(employee.karyo_section)
        self.assertFalse(employee.karyo_location)

    def test_initial_appointment_maps_first_salary_structure(self):
        movement=frappe.get_doc({'doctype':'Employee Promotion','employee':self.employee.name,
            'promotion_date':getdate(),'karyo_appointment_type':'Appointment',
            'karyo_new_grade':self.grade.name,'karyo_new_salary_point':'1',
            'karyo_salary_structure':self.structure,'karyo_income_tax_slab':self.income_tax_slab}).insert()
        movement.submit()
        current=approved_appointment(self.employee.name,getdate())
        self.assertEqual(current.basic_salary,16785)
        appointment=frappe.get_doc('Employee Salary Appointment',current.name)
        self.assertEqual(appointment.appointment_type,'Appointment')
        self.assertEqual(appointment.salary_structure,self.structure)
        self.assertEqual(frappe.db.get_value('Salary Structure Assignment',appointment.salary_structure_assignment,'base'),16785)
        movement.cancel()
        self.assertFalse(approved_appointment(self.employee.name,getdate()))
