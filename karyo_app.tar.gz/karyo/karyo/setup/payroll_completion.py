import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	create_custom_fields({'Payroll Cycle':[{'fieldname':'karyo_completion','label':'Complete Payroll','fieldtype':'HTML','insert_after':'status'}],
		'PRB Payroll Run':[
			{'fieldname':'payroll_period','label':'Payroll Period','fieldtype':'Link','options':'Payroll Period','insert_after':'company','reqd':1},
			{'fieldname':'run_purpose','label':'Run Purpose','fieldtype':'Select','options':'Comprehensive\nAttendance Bonus\nIncentive Attendance Bonus\nPRB Attendance Bonuses\nERA Hours Payment\nAdditional Hours\nActing / Responsibility','default':'Comprehensive','read_only':1,'insert_after':'calculation_date'},
			{'fieldname':'karyo_submission_help','label':'Submission Readiness','fieldtype':'HTML','insert_after':'snapshot_status'}]},update=True)
