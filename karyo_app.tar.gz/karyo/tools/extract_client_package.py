#!/usr/bin/env python3
"""Extract searchable text from the supplied MBC client package.

Output is intended for a restricted/local evidence directory and must not be
committed when it contains client or employee data.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from bs4 import BeautifulSoup
from openpyxl import load_workbook
from pypdf import PdfReader

TEXT_TAG = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"
SLIDE_TEXT_TAG = "{http://schemas.openxmlformats.org/drawingml/2006/main}t"


def xml_text(path: Path, member_pattern: re.Pattern[str], text_tag: str) -> str:
	parts = []
	with zipfile.ZipFile(path) as archive:
		for member in sorted(name for name in archive.namelist() if member_pattern.fullmatch(name)):
			root = ET.fromstring(archive.read(member))
			text = " ".join(node.text or "" for node in root.iter(text_tag)).strip()
			if text:
				parts.append(f"[{member}]\n{text}")
	return "\n\n".join(parts)


def extract(path: Path) -> str:
	suffix = path.suffix.lower()
	if suffix == ".docx":
		return xml_text(path, re.compile(r"word/(?:document|header\d+|footer\d+|footnotes|endnotes)\.xml"), TEXT_TAG)
	if suffix == ".pptx":
		return xml_text(path, re.compile(r"ppt/slides/slide\d+\.xml"), SLIDE_TEXT_TAG)
	if suffix == ".xlsx":
		book = load_workbook(path, read_only=True, data_only=False)
		parts = []
		for sheet in book.worksheets:
			parts.append(f"[Sheet: {sheet.title}]")
			for row in sheet.iter_rows(values_only=True):
				values = [str(value).strip() for value in row if value not in (None, "")]
				if values:
					parts.append("\t".join(values))
		return "\n".join(parts)
	if suffix == ".pdf":
		return "\n\n".join(page.extract_text() or "" for page in PdfReader(path).pages)
	if suffix in {".html", ".htm"}:
		return BeautifulSoup(path.read_text(encoding="utf-8", errors="replace"), "html.parser").get_text("\n")
	if suffix == ".txt":
		return path.read_text(encoding="utf-8", errors="replace")
	if suffix in {".mp4", ".mov"}:
		return "Recording present; transcription not available in the supplied package."
	return "Unsupported file type."


def safe_name(relative: Path) -> str:
	return re.sub(r"[^A-Za-z0-9._-]+", "_", str(relative)).strip("_") + ".txt"


def main() -> None:
	parser = argparse.ArgumentParser()
	parser.add_argument("source", type=Path)
	parser.add_argument("output", type=Path)
	parser.add_argument("--manifest-output", type=Path)
	args = parser.parse_args()
	args.output.mkdir(parents=True, exist_ok=True)
	manifest = []
	for path in sorted(item for item in args.source.rglob("*") if item.is_file()):
		relative = path.relative_to(args.source)
		text = html.unescape(extract(path)).replace("\x00", "")
		output = args.output / safe_name(relative)
		output.write_text(text, encoding="utf-8")
		digest = hashlib.sha256(path.read_bytes()).hexdigest()
		manifest.append(f"{relative}\t{path.stat().st_size}\t{digest}\t{output.name}\t{len(text)}")
	header = "source_file\tsize_bytes\tsha256\textracted_file\textracted_characters"
	manifest_path = args.manifest_output or (args.output / "manifest.tsv")
	manifest_path.parent.mkdir(parents=True, exist_ok=True)
	manifest_path.write_text(header + "\n" + "\n".join(manifest) + "\n", encoding="utf-8")
	print(f"Extracted {len(manifest)} files to {args.output}")


if __name__ == "__main__":
	main()
