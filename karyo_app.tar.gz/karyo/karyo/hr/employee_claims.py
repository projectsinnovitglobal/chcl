"""Permission-checked claims for the signed-in employee dashboard."""
import re

import frappe
from frappe import _
from frappe.utils import cint, get_first_day, get_last_day, getdate
from karyo.hr.clocking import _own_employee

STATUSES = ('Approved', 'Rejected', 'Cancelled')
FIELDS = ['name', 'employee', 'posting_date', 'status', 'approval_status', 'total_claimed_amount',
          'total_sanctioned_amount', 'total_amount_reimbursed', 'company', 'docstatus']


@frappe.whitelist()
def get_claims(month=None, status=None, start=0):
    person = _own_employee(required=True)
    filters = {'employee': person.name}
    if month:
        if not re.fullmatch(r'\d{4}-\d{2}', month):
            frappe.throw(_('Select a valid claim month.'))
        try:
            first = get_first_day(getdate(month + '-01'))
            last = get_last_day(first)
        except (ValueError, TypeError):
            frappe.throw(_('Select a valid claim month.'))
        filters['posting_date'] = ('between', [first, last])
    if status:
        if status not in STATUSES:
            frappe.throw(_('Select a valid claim status.'))
        if status == 'Cancelled':
            filters['docstatus'] = 2
        else:
            filters['approval_status'] = status
    start = max(0, cint(start))
    rows = frappe.get_list('Expense Claim', filters=filters, fields=FIELDS,
                           order_by='posting_date desc, creation desc, name desc', start=start, page_length=26)
    total = frappe.get_list('Expense Claim', filters=filters, fields=['count(name) as total'])[0].total
    for row in rows:
        row.currency = frappe.get_cached_value('Company', row.company, 'default_currency')
        row.display_status = ('Cancelled' if row.docstatus == 2 else
                              row.approval_status if row.approval_status in ('Approved', 'Rejected') else row.status)
        row.can_edit = row.docstatus == 0 and row.approval_status in ('Draft', '', None) and frappe.has_permission('Expense Claim', 'write', doc=row.name)
    # Supply this small reference list with the employee-scoped response. Link
    # controls embedded in a Dialog table do not reliably run their async link
    # search when a row is first opened, leaving Expense Type visibly empty.
    expense_types = frappe.get_all('Expense Claim Type', pluck='name', order_by='expense_type asc')
    return {'employee': person.name, 'employee_name': person.employee_name, 'rows': rows[:25],
            'total': total, 'has_more': len(rows) > 25, 'can_create': frappe.has_permission('Expense Claim', 'create'),
            'expense_types': expense_types}


@frappe.whitelist()
def get_record(name):
    person = _own_employee(required=True)
    if frappe.db.get_value('Expense Claim', name, 'employee') != person.name:
        frappe.throw(_('You can only view your own claims.'), frappe.PermissionError)
    doc = frappe.get_doc('Expense Claim', name)
    doc.check_permission('read')
    display_status = ('Cancelled' if doc.docstatus == 2 else
                      doc.approval_status if doc.approval_status in ('Approved', 'Rejected') else doc.status)
    return {**{field: doc.get(field) for field in FIELDS},
            'display_status': display_status,
            'currency': frappe.get_cached_value('Company', doc.company, 'default_currency'),
            'can_edit': doc.docstatus == 0 and doc.approval_status in ('Draft', '', None) and doc.has_permission('write'),
            'remark': doc.remark,
            'expenses': [{field: row.get(field) for field in ('expense_date', 'expense_type', 'description', 'amount', 'sanctioned_amount')} for row in doc.expenses],
            'attachments': frappe.get_all('File', filters={'attached_to_doctype': 'Expense Claim', 'attached_to_name': doc.name}, fields=['file_name', 'file_url'])}


@frappe.whitelist(methods=['POST'])
def save_claim(values, name=None):
    """Only employee-editable claim inputs; accounting and approval stay server-owned."""
    from frappe.utils import flt, nowdate
    person = _own_employee(required=True)
    values = frappe.parse_json(values) if isinstance(values, str) else values
    if name:
        get_record(name)
        doc = frappe.get_doc('Expense Claim', name)
        doc.check_permission('write')
        if doc.docstatus != 0 or doc.approval_status not in ('Draft', '', None):
            frappe.throw(_('Only draft claims can be edited.'))
    else:
        if not frappe.has_permission('Expense Claim', 'create'):
            frappe.throw(_('You cannot create expense claims.'), frappe.PermissionError)
        doc = frappe.new_doc('Expense Claim')
        employee = frappe.get_doc('Employee', person.name)
        doc.employee = employee.name
        doc.company = employee.company
        doc.department = employee.department
        doc.expense_approver = employee.expense_approver
        if not doc.expense_approver and employee.department:
            doc.expense_approver = frappe.db.get_value('Department Approver',
                {'parent': employee.department, 'parentfield': 'expense_approvers'}, 'approver')
        doc.payable_account = frappe.get_cached_value('Company', employee.company, 'default_expense_claim_payable_account')
        doc.approval_status = 'Draft'
    doc.posting_date = getdate(values.get('posting_date') or nowdate())
    doc.remark = values.get('remark') or ''
    items = values.get('expenses') or []
    if not items:
        frappe.throw(_('Add at least one expense item.'))
    doc.set('expenses', [])
    for item in items:
        if not item.get('expense_date') or not item.get('expense_type') or flt(item.get('amount')) <= 0:
            frappe.throw(_('Each expense needs a date, type and amount greater than zero.'))
        doc.append('expenses', {field:item.get(field) for field in ('expense_date','expense_type','description','amount')})
    doc.save()
    receipt = values.get('receipt')
    if receipt:
        files = frappe.get_all('File', filters={'file_url':receipt}, fields=['name','owner','is_private','attached_to_doctype','attached_to_name'])
        file = next((f for f in files if f.is_private and ((f.owner == frappe.session.user and not f.attached_to_name) or (f.attached_to_doctype == 'Expense Claim' and f.attached_to_name == doc.name))), None)
        if not file:
            frappe.throw(_('Upload a private receipt for this claim.'), frappe.PermissionError)
        frappe.db.set_value('File',file.name,{'attached_to_doctype':'Expense Claim','attached_to_name':doc.name})
    return {'name':doc.name, 'status':doc.status}
