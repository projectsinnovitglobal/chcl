frappe.query_reports["Loan Approval Outcomes"] = {
	filters: [
		{ fieldname: "from_date", label: __("Decision From"), fieldtype: "Date" },
		{ fieldname: "to_date", label: __("Decision To"), fieldtype: "Date" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "outcome", label: __("Outcome"), fieldtype: "Select", options: "\nRecommended\nPending\nApproved\nRejected\nReturned" },
		{ fieldname: "approval_level", label: __("Approval Level"), fieldtype: "Select", options: "\nCommittee Recommendation\nDirect Approval\nFinal Approval\nManaging Director\nReturn / Rework" },
	],
};
