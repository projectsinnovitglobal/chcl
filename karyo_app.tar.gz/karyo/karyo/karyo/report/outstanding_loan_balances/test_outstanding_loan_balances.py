import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.doctype.karyo_loan_settlement import test_karyo_loan_settlement as settlement_helpers
from karyo.karyo.report.loan_schedule.loan_schedule import execute as schedule_report
from karyo.karyo.report.outstanding_loan_balances.outstanding_loan_balances import execute as balance_report


class TestOutstandingLoanBalances(FrappeTestCase):
	_assign_salary_structure = settlement_helpers.TestKaryoLoanSettlement._assign_salary_structure
	_activate_loan = settlement_helpers.TestKaryoLoanSettlement._activate_loan
	_settlement = settlement_helpers.TestKaryoLoanSettlement._settlement

	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		cls.company = frappe.db.get_value("Company", {}, "name")
		if cls.company and not frappe.db.exists("Loan Type", "PERSONAL"):
			frappe.get_doc({"doctype": "Loan Type", "loan_code": "PERSONAL", "loan_name": "Personal Loan",
				"loan_category": "Personal", "interest_rate": 6, "is_active": 1}).insert(ignore_permissions=True)

	def setUp(self):
		if not self.company:
			self.skipTest("no Company on site")
		frappe.db.set_single_value("Karyo Settings", "max_deduction_pct", 40)
		frappe.db.set_single_value("Karyo Settings", "require_appraisal_payroll_cycle", 0)
		frappe.db.set_value("Loan Type", "PERSONAL", {"pdb_capital": "Karyo Loan Capital", "pdb_interest": "Karyo Loan Interest", "pdb_insurance": "Karyo Loan Insurance"}, update_modified=False)
		self.emp = frappe.get_doc({"doctype": "Employee", "first_name": "Report", "last_name": "Borrower",
			"gender": frappe.db.get_value("Gender", {}, "name") or "Male", "date_of_birth": "1985-01-01",
			"date_of_joining": "2016-01-01", "company": self.company, "status": "Active"}).insert(ignore_permissions=True, ignore_mandatory=True)
		self._assign_salary_structure(self.emp.name)
		self.loan = self._activate_loan()

	def test_schedule_and_true_as_at_settlement_balance(self):
		_columns, schedule = schedule_report({"loan": self.loan.name})
		self.assertEqual(len(schedule), 36)
		self.assertTrue(all(row.is_current for row in schedule))
		self.assertTrue(all(row.due_date and row.capital_status and row.interest_status for row in schedule))

		_columns, before = balance_report({"as_at_date": "2026-08-31", "loan": self.loan.name})
		self.assertEqual(len(before), 1)
		self.assertEqual(before[0].outstanding_capital, self.loan.approved_amount)
		self.assertGreater(before[0].outstanding_total, self.loan.approved_amount)

		settlement = self._settlement(payment_reference="REPORT-SETTLEMENT")
		settlement.insert(ignore_permissions=True); settlement.submit()
		_columns, settled_schedule = schedule_report({"loan": self.loan.name})
		self.assertTrue(all(row.actual_repayment_date == settlement.refund_date for row in settled_schedule))
		_columns, after = balance_report({"as_at_date": "2026-09-01", "loan": self.loan.name, "include_settled": 1})
		self.assertEqual(len(after), 1)
		self.assertAlmostEqual(after[0].outstanding_total, 0, places=2)
		self.assertEqual(after[0].capital_paid, self.loan.approved_amount)
