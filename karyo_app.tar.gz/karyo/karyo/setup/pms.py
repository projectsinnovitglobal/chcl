"""PMS Appraisal DocType (PMS-*): officer weighted-competency or workman
points scoring, with the "one open PMS per employee" control (PMS-003).

    bench --site dev.localhost execute karyo.setup.pms.setup
"""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"PMS Competency",
		istable=1,
		fields=[
			f("competency", "Data", "Competency", reqd=1, in_list_view=1),
			f("rating", "Float", "Rating", in_list_view=1),
			f("weight", "Percent", "Weight %", in_list_view=1),
			f("score", "Float", "Score", read_only=1, in_list_view=1),
		],
	)
	make_doctype(
		"PMS Appraisal",
		is_submittable=1,
		autoname="naming_series:",
		title_field="employee_name",
		fields=[
			f("naming_series", "Select", "Series", options="PMS-.YYYY.-.#####", default="PMS-.YYYY.-.#####"),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("year", "Int", "Year", reqd=1, in_list_view=1),
			f(
				"appraisal_type",
				"Select",
				"Type",
				options="Officer\nWorkman",
				default="Officer",
				reqd=1,
				in_list_view=1,
			),
			f("hcb", "Column Break"),
			f(
				"max_rating",
				"Int",
				"Max Rating (Officer)",
				default="4",
				depends_on="eval:doc.appraisal_type=='Officer'",
			),
			f("points", "Float", "Points (Workman)", depends_on="eval:doc.appraisal_type=='Workman'"),
			f("max_points", "Float", "Max Points (Workman)", depends_on="eval:doc.appraisal_type=='Workman'"),
			f("comp_sb", "Section Break", "Competencies", depends_on="eval:doc.appraisal_type=='Officer'"),
			f(
				"components",
				"Table",
				"Competencies",
				options="PMS Competency",
				depends_on="eval:doc.appraisal_type=='Officer'",
			),
			f("res_sb", "Section Break", "Result"),
			f("overall_score", "Percent", "Overall Score", read_only=1, in_list_view=1),
		],
	)


def setup():
	print("Karyo PMS setup:")
	create_doctypes()
	frappe.db.commit()
	print("Done.")
