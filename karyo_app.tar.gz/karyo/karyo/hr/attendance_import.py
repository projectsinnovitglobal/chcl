"""Roster-aware CSV template and importer for Upload Attendance."""

from collections import defaultdict
from datetime import datetime, timedelta
import re

import frappe
from frappe import _
from frappe.utils import cstr, flt, get_datetime, getdate
from frappe.utils.csvutils import UnicodeWriter

from erpnext.setup.doctype.employee.employee import get_holiday_list_for_employee
from hrms.hr.doctype.upload_attendance.upload_attendance import get_dates, get_holidays_for_employees


TEMPLATE_COLUMNS = (
	("name", "ID"),
	("employee_code", "Employee Code"),
	("employee_name", "Employee Name"),
	("attendance_date", "Attendance Date"),
	("status", "Status"),
	("leave_type", "Leave Type"),
	("company", "Company"),
	("department", "Department"),
	("shift", "Shift"),
	("shift_code", "Shift Code"),
	("roster_code", "Roster Code"),
	("roster_schedule", "Roster Schedule"),
	("roster_assignment", "Roster Assignment"),
	("work_pattern", "Work Pattern"),
	("in_time", "Clock In"),
	("out_time", "Clock Out"),
	("working_hours", "Working Hours"),
	("late_entry", "Late Entry"),
	("early_exit", "Early Exit"),
	("overtime_hours", "Overtime Hours"),
	("bonus_amount", "Bonus Amount"),
	("half_day_status", "Half Day Status"),
	("attendance_request", "Attendance Request"),
	("naming_series", "Naming Series"),
)

HEADER_ALIASES = {
	"id": "name",
	"employee": "employee_code",
	"date": "attendance_date",
	"clock_in": "in_time",
	"clock_out": "out_time",
	"roster": "roster_code",
	"bonus": "bonus_amount",
	"overtime": "overtime_hours",
}

CUSTOM_IMPORT_FIELDS = {
	"shift_code": "karyo_shift_code",
	"roster_code": "karyo_roster_code",
	"roster_schedule": "karyo_roster_schedule",
	"roster_assignment": "karyo_roster_assignment",
	"work_pattern": "karyo_work_pattern",
	"overtime_hours": "karyo_overtime_hours",
	"bonus_amount": "karyo_bonus_amount",
}


def _scrub_header(value):
	from frappe.modules import scrub

	fieldname = scrub(cstr(value).replace("*", "").strip())
	return HEADER_ALIASES.get(fieldname, fieldname)


def _attendance_statuses():
	return [
		value for value in (frappe.get_meta("Attendance").get_field("status").options or "").split("\n")
		if value
	]


def add_header(writer):
	writer.writerow(["Notes:"])
	writer.writerow(
		["Do not rename or remove the required template headings; optional columns may be left blank."]
	)
	writer.writerow(["Employee Code, Attendance Date and Status are required for every imported row."])
	writer.writerow(
		["Status must be one of: " + ", ".join(_attendance_statuses()) + ". Holiday rows are ignored."]
	)
	writer.writerow(
		["Shift/roster identifiers are validated against the employee's dated duty. "
		"Use ID when updating submitted attendance."]
	)
	writer.writerow(
		["Overtime Hours are treated as requested hours: rule-eligible hours extend Clock Out and appear in the Overtime column. "
		"Clock Out should therefore contain the normal-shift end, not the already-extended end. "
		"governed payroll approvals remain authoritative; Bonus Amount remains a source reference."]
	)
	writer.writerow([label for _fieldname, label in TEMPLATE_COLUMNS])
	return writer


def _employee_fields():
	meta = frappe.get_meta("Employee")
	fields = [
		"name", "employee_name", "date_of_joining", "relieving_date", "company", "department",
		"default_shift", "holiday_list",
	]
	for fieldname in ("employee_number", "karyo_work_pattern", "karyo_roster_schedule"):
		if meta.has_field(fieldname):
			fields.append(fieldname)
	return fields


def get_active_employees():
	return frappe.db.get_all(
		"Employee",
		fields=_employee_fields(),
		filters={"docstatus": ["<", 2], "status": "Active"},
		order_by="name asc",
	)


def _existing_attendance(from_date, to_date):
	meta = frappe.get_meta("Attendance")
	fields = [
		"name", "employee", "attendance_date", "status", "leave_type", "company", "department",
		"shift", "in_time", "out_time", "working_hours", "late_entry", "early_exit",
		"half_day_status", "attendance_request", "naming_series",
	]
	fields.extend(field for field in CUSTOM_IMPORT_FIELDS.values() if meta.has_field(field))
	rows = frappe.get_all(
		"Attendance",
		filters={"attendance_date": ("between", [from_date, to_date]), "docstatus": ("<", 2)},
		fields=fields,
		limit_page_length=0,
	)
	return {(getdate(row.attendance_date), row.employee): row for row in rows}


def _shift_maps():
	meta = frappe.get_meta("Shift Type")
	fields = ["name"] + (["karyo_shift_code"] if meta.has_field("karyo_shift_code") else [])
	rows = frappe.get_all("Shift Type", fields=fields, limit_page_length=0)
	by_name = {row.name: row for row in rows}
	by_code = {row.karyo_shift_code: row for row in rows if row.get("karyo_shift_code")}
	return by_name, by_code


def _schedule_maps():
	meta = frappe.get_meta("Shift Schedule")
	fields = ["name"] + (["karyo_roster_code"] if meta.has_field("karyo_roster_code") else [])
	rows = frappe.get_all("Shift Schedule", fields=fields, limit_page_length=0)
	by_name = {row.name: row for row in rows}
	by_code = {row.karyo_roster_code: row for row in rows if row.get("karyo_roster_code")}
	return by_name, by_code


def _duty_rows(employee_names, from_date, to_date):
	if not employee_names:
		return defaultdict(list)
	rows = frappe.db.sql(
		"""select sa.name, sa.employee, sa.shift_type, sa.start_date, sa.end_date,
			sa.shift_schedule_assignment, ssa.shift_schedule
		from `tabShift Assignment` sa
		left join `tabShift Schedule Assignment` ssa on ssa.name=sa.shift_schedule_assignment
		where sa.docstatus=1 and sa.employee in %(employees)s
			and sa.start_date <= %(to_date)s
			and (sa.end_date is null or sa.end_date >= %(from_date)s)
		order by sa.employee, sa.start_date desc, sa.creation desc""",
		{"employees": tuple(employee_names), "from_date": from_date, "to_date": to_date},
		as_dict=True,
	)
	result = defaultdict(list)
	for row in rows:
		result[row.employee].append(row)
	return result


def _duty_on(duties, on_date):
	date = getdate(on_date)
	return next(
		(
			row for row in duties
			if getdate(row.start_date) <= date and (not row.end_date or getdate(row.end_date) >= date)
		),
		None,
	)


def _row_values(employee, on_date, attendance, duty, shift_by_name, schedule_by_name):
	shift = attendance.get("shift") if attendance else None
	shift = shift or (duty.shift_type if duty else None) or employee.default_shift
	shift_row = shift_by_name.get(shift) or {}
	schedule = (
		(attendance.get("karyo_roster_schedule") if attendance else None)
		or (duty.shift_schedule if duty else None)
		or employee.get("karyo_roster_schedule")
	)
	schedule_row = schedule_by_name.get(schedule) or {}
	values = {
		"name": attendance.get("name") if attendance else "",
		"employee_code": employee.name,
		"employee_name": employee.employee_name,
		"attendance_date": on_date,
		"status": attendance.get("status") if attendance else "",
		"leave_type": attendance.get("leave_type") if attendance else "",
		"company": (attendance.get("company") if attendance else None) or employee.company,
		"department": (attendance.get("department") if attendance else None) or employee.department,
		"shift": shift,
		"shift_code": (
			(attendance.get("karyo_shift_code") if attendance else None)
			or shift_row.get("karyo_shift_code")
		),
		"roster_code": (
			(attendance.get("karyo_roster_code") if attendance else None)
			or schedule_row.get("karyo_roster_code")
		),
		"roster_schedule": schedule,
		"roster_assignment": (
			(attendance.get("karyo_roster_assignment") if attendance else None)
			or (duty.name if duty else None)
		),
		"work_pattern": (
			(attendance.get("karyo_work_pattern") if attendance else None)
			or employee.get("karyo_work_pattern")
		),
		"in_time": attendance.get("in_time") if attendance else "",
		"out_time": attendance.get("out_time") if attendance else "",
		"working_hours": attendance.get("working_hours") if attendance else "",
		"late_entry": attendance.get("late_entry") if attendance else 0,
		"early_exit": attendance.get("early_exit") if attendance else 0,
		"overtime_hours": attendance.get("karyo_overtime_hours") if attendance else 0,
		"bonus_amount": attendance.get("karyo_bonus_amount") if attendance else 0,
		"half_day_status": attendance.get("half_day_status") if attendance else "",
		"attendance_request": attendance.get("attendance_request") if attendance else "",
		"naming_series": (attendance.get("naming_series") if attendance else None) or get_naming_series(),
	}
	return [values.get(fieldname) or "" for fieldname, _label in TEMPLATE_COLUMNS]


def get_template_data(args):
	from_date, to_date = getdate(args["from_date"]), getdate(args["to_date"])
	employees = get_active_employees()
	holidays = get_holidays_for_employees([employee.name for employee in employees], from_date, to_date)
	existing = _existing_attendance(from_date, to_date)
	shift_by_name, _shift_by_code = _shift_maps()
	schedule_by_name, _schedule_by_code = _schedule_maps()
	duties = _duty_rows([employee.name for employee in employees], from_date, to_date)
	data = []
	for on_date in get_dates({"from_date": from_date, "to_date": to_date}):
		date = getdate(on_date)
		for employee in employees:
			if date < getdate(employee.date_of_joining):
				continue
			if employee.relieving_date and date > getdate(employee.relieving_date):
				continue
			attendance = existing.get((date, employee.name))
			row = _row_values(
				employee, date, attendance, _duty_on(duties[employee.name], date), shift_by_name, schedule_by_name
			)
			holiday_list = get_holiday_list_for_employee(employee.name)
			if not attendance and holiday_list and date in holidays.get(holiday_list, []):
				row[4] = "Holiday"
			data.append(row)
	return data


def get_naming_series():
	series = (frappe.get_meta("Attendance").get_field("naming_series").options or "").strip().split("\n")
	series = [value for value in series if value]
	if not series:
		frappe.throw(_("Please set up a numbering series for Attendance."))
	return series[0]


@frappe.whitelist()
def get_template():
	if not frappe.has_permission("Attendance", "create"):
		raise frappe.PermissionError
	args = frappe.local.form_dict
	if not args.get("from_date") or not args.get("to_date"):
		frappe.throw(_("Attendance From Date and Attendance To Date are required."))
	if getdate(args.from_date) > getdate(args.to_date):
		frappe.throw(_("To Date should be greater than or equal to From Date."))
	writer = add_header(UnicodeWriter())
	for row in get_template_data(args):
		writer.writerow(row)
	frappe.response["result"] = cstr(writer.getvalue())
	frappe.response["type"] = "csv"
	frappe.response["doctype"] = "Attendance"
	frappe.response["filename"] = "attendance_import_sample.csv"


def _find_header(rows):
	for index, row in enumerate(rows):
		headers = [_scrub_header(value) for value in row]
		if "employee_code" in headers and "attendance_date" in headers:
			if len(set(headers)) != len(headers):
				frappe.throw(_("The attendance CSV contains duplicate headings."))
			missing = {"employee_code", "attendance_date", "status"} - set(headers)
			if missing:
				frappe.throw(_("Missing required attendance headings: {0}").format(", ".join(sorted(missing))))
			return index, headers
	frappe.throw(_("Could not find the attendance headings. Use the downloaded sample CSV."))


def _clean(value):
	return cstr(value).strip() if value is not None else ""


def _employee(code, row_number):
	code = _clean(code)
	if not code:
		frappe.throw(_("Row {0}: Employee Code is required.").format(row_number))
	name = code if frappe.db.exists("Employee", code) else None
	meta = frappe.get_meta("Employee")
	if not name and meta.has_field("employee_number"):
		name = frappe.db.get_value("Employee", {"employee_number": code}, "name")
	if not name:
		frappe.throw(_("Row {0}: Employee Code {1} does not exist.").format(row_number, frappe.bold(code)))
	fields = ["name", "employee_name", "company", "department", "default_shift", "status"]
	for fieldname in ("karyo_work_pattern", "karyo_roster_schedule"):
		if meta.has_field(fieldname):
			fields.append(fieldname)
	return frappe.db.get_value("Employee", name, fields, as_dict=True)


def _resolve_master(value, code, doctype, code_field, label, row_number):
	value, code = _clean(value), _clean(code)
	by_value = value if value and frappe.db.exists(doctype, value) else None
	by_code = frappe.db.get_value(doctype, {code_field: code}, "name") if code else None
	if value and not by_value:
		# Operators commonly put a code in the descriptive column; accept it when unambiguous.
		by_value = frappe.db.get_value(doctype, {code_field: value}, "name")
	if value and not by_value:
		frappe.throw(_("Row {0}: {1} {2} does not exist.").format(row_number, label, frappe.bold(value)))
	if code and not by_code:
		frappe.throw(_("Row {0}: {1} code {2} does not exist.").format(row_number, label, frappe.bold(code)))
	if by_value and by_code and by_value != by_code:
		frappe.throw(_("Row {0}: {1} and {1} Code refer to different records.").format(row_number, label))
	return by_value or by_code


def _datetime_value(value, attendance_date, field_label, row_number):
	value = _clean(value)
	if not value:
		return None, False
	time_only = bool(re.fullmatch(r"\d{1,2}:\d{2}(?::\d{2})?", value))
	try:
		return get_datetime(f"{attendance_date} {value}" if time_only else value), time_only
	except Exception:
		frappe.throw(_("Row {0}: {1} is not a valid date/time.").format(row_number, field_label))


def _validate_identity(row, employee, row_number):
	if (
		row.get("employee_name")
		and _clean(row.employee_name).casefold() != _clean(employee.employee_name).casefold()
	):
		frappe.throw(
			_("Row {0}: Employee Name does not match Employee Code {1}.").format(
				row_number, employee.name
			)
		)
	for fieldname, label in (("company", "Company"), ("department", "Department")):
		provided = _clean(row.get(fieldname))
		actual = _clean(employee.get(fieldname))
		if provided and provided != actual:
			frappe.throw(_("Row {0}: {1} does not match Employee Code {2}.").format(row_number, label, employee.name))


def _validate_roster_assignment(name, employee, attendance_date, shift, row_number):
	if not name:
		return None
	assignment = frappe.db.get_value(
		"Shift Assignment", name,
		["name", "employee", "shift_type", "start_date", "end_date", "shift_schedule_assignment", "docstatus"],
		as_dict=True,
	)
	if not assignment or assignment.docstatus != 1:
		frappe.throw(_("Row {0}: Roster Assignment {1} is not submitted.").format(row_number, frappe.bold(name)))
	date = getdate(attendance_date)
	if assignment.employee != employee.name or date < getdate(assignment.start_date) or (
		assignment.end_date and date > getdate(assignment.end_date)
	):
		frappe.throw(_("Row {0}: Roster Assignment does not cover this employee and date.").format(row_number))
	if shift and assignment.shift_type != shift:
		frappe.throw(_("Row {0}: Shift does not match the Roster Assignment.").format(row_number))
	return assignment


def _dated_duty(employee, attendance_date, row_number):
	"""Resolve the submitted duty that covered the date, including historical inactive rows."""
	date = getdate(attendance_date)
	rows = frappe.get_all(
		"Shift Assignment",
		filters={"employee": employee, "docstatus": 1, "start_date": ("<=", date)},
		fields=["name", "shift_type", "start_date", "end_date", "shift_schedule_assignment"],
		order_by="start_date desc, creation desc",
		limit_page_length=50,
	)
	rows = [row for row in rows if not row.end_date or getdate(row.end_date) >= date]
	if len(rows) > 1:
		frappe.throw(
			_("Row {0}: more than one submitted Roster Assignment covers this employee and date.").format(row_number)
		)
	if not rows:
		return None
	duty = rows[0]
	duty.schedule = (
		frappe.db.get_value("Shift Schedule Assignment", duty.shift_schedule_assignment, "shift_schedule")
		if duty.shift_schedule_assignment else None
	)
	return duty


def prepare_attendance_row(values, row_number):
	row = frappe._dict({key: _clean(value) for key, value in values.items()})
	employee = _employee(row.employee_code, row_number)
	_validate_identity(row, employee, row_number)
	if not row.attendance_date:
		frappe.throw(_("Row {0}: Attendance Date is required.").format(row_number))
	try:
		attendance_date = getdate(row.attendance_date)
	except Exception:
		frappe.throw(_("Row {0}: Attendance Date is invalid.").format(row_number))

	shift = _resolve_master(row.shift, row.shift_code, "Shift Type", "karyo_shift_code", "Shift", row_number)
	schedule = _resolve_master(
		row.roster_schedule, row.roster_code, "Shift Schedule", "karyo_roster_code", "Roster", row_number
	)
	duty = _dated_duty(employee.name, attendance_date, row_number)
	if duty:
		if shift and duty.shift_type != shift:
			frappe.throw(_("Row {0}: Shift does not match the employee's dated roster duty.").format(row_number))
		if schedule and duty.schedule and duty.schedule != schedule:
			frappe.throw(_("Row {0}: Roster Code does not match the employee's dated roster duty.").format(row_number))
		shift = shift or duty.shift_type
		schedule = schedule or duty.schedule
	elif schedule and employee.get("karyo_roster_schedule") and schedule != employee.karyo_roster_schedule:
		frappe.throw(_("Row {0}: Roster Code does not match the employee's configured roster.").format(row_number))
	shift = shift or employee.default_shift
	if (
		row.work_pattern
		and employee.get("karyo_work_pattern")
		and row.work_pattern != employee.karyo_work_pattern
	):
		frappe.throw(_("Row {0}: Work Pattern does not match Employee Code {1}.").format(row_number, employee.name))

	assignment_name = row.roster_assignment or (duty.name if duty else None)
	assignment = _validate_roster_assignment(assignment_name, employee, attendance_date, shift, row_number)
	if assignment and not schedule and assignment.shift_schedule_assignment:
		schedule = frappe.db.get_value(
			"Shift Schedule Assignment", assignment.shift_schedule_assignment, "shift_schedule"
		)
	shift_code = frappe.db.get_value("Shift Type", shift, "karyo_shift_code") if shift else None
	roster_code = frappe.db.get_value("Shift Schedule", schedule, "karyo_roster_code") if schedule else None

	in_time, _in_time_only = _datetime_value(row.in_time, attendance_date, "Clock In", row_number)
	out_time, out_time_only = _datetime_value(row.out_time, attendance_date, "Clock Out", row_number)
	if in_time and out_time and out_time <= in_time and out_time_only:
		out_time += timedelta(days=1)
	if in_time and out_time and out_time < in_time:
		frappe.throw(_("Row {0}: Clock Out cannot be before Clock In.").format(row_number))
	working_hours = flt(row.working_hours) if row.working_hours else None
	if working_hours is None and in_time and out_time:
		working_hours = round((out_time - in_time).total_seconds() / 3600, 4)
	if working_hours is not None and working_hours < 0:
		frappe.throw(_("Row {0}: Working Hours cannot be negative.").format(row_number))
	overtime_hours = flt(row.overtime_hours) if row.overtime_hours else 0
	bonus_amount = flt(row.bonus_amount) if row.bonus_amount else 0
	if overtime_hours < 0 or bonus_amount < 0:
		frappe.throw(_("Row {0}: Overtime Hours and Bonus Amount cannot be negative.").format(row_number))

	result = frappe._dict(
		name=row.name or None,
		doctype="Attendance",
		employee=employee.name,
		employee_name=employee.employee_name,
		attendance_date=attendance_date,
		status=row.status,
		leave_type=row.leave_type or None,
		company=employee.company,
		department=employee.department,
		shift=shift,
		in_time=in_time,
		out_time=out_time,
		working_hours=working_hours,
		late_entry=row.late_entry or 0,
		early_exit=row.early_exit or 0,
		half_day_status=row.half_day_status or None,
		attendance_request=row.attendance_request or None,
		naming_series=row.naming_series or get_naming_series(),
	)
	meta = frappe.get_meta("Attendance")
	custom_values = {
		"custom_entry_source": "Attendance Import",
		"karyo_shift_code": shift_code,
		"karyo_roster_code": roster_code,
		"karyo_roster_schedule": schedule,
		"karyo_roster_assignment": assignment_name,
		"karyo_work_pattern": row.work_pattern or employee.get("karyo_work_pattern"),
		"karyo_overtime_hours": overtime_hours,
		"karyo_bonus_amount": bonus_amount,
	}
	result.update({key: value for key, value in custom_values.items() if meta.has_field(key)})
	return result


@frappe.whitelist()
def upload():
	if not frappe.has_permission("Attendance", "create"):
		raise frappe.PermissionError
	from frappe.utils.csvutils import read_csv_content

	rows = read_csv_content(frappe.local.uploaded_file)
	if not rows:
		frappe.throw(_("Please select a CSV file."))
	frappe.enqueue(import_attendances, rows=rows, now=len(rows) < 200)


def import_attendances(rows):
	from frappe.utils.csvutils import check_record, import_doc

	rows = [row for row in rows if row and any(_clean(value) for value in row)]
	header_index, columns = _find_header(rows)
	data_rows = rows[header_index + 1 :]
	results, has_error = [], False
	for index, values in enumerate(data_rows, start=header_index + 2):
		if not values or not any(_clean(value) for value in values):
			continue
		raw = frappe._dict(zip(columns, values, strict=False))
		if _clean(raw.get("status")).casefold() == "holiday":
			continue
		try:
			doc = prepare_attendance_row(raw, index)
			if doc.name:
				doc.docstatus = frappe.db.get_value("Attendance", doc.name, "docstatus")
			check_record(doc)
			results.append(import_doc(doc, "Attendance", 1, index - 1, submit=True))
			if flt(raw.get("overtime_hours")) > 0:
				attendance_name = frappe.db.get_value(
					"Attendance",
					{"employee": doc.employee, "attendance_date": doc.attendance_date, "docstatus": 1},
					"name",
				)
				reference = _("Attendance Import: {0}").format(attendance_name or f"row {index}")
				exists = frappe.db.get_value(
					"PRB Overtime Authorization",
					{"employee": doc.employee, "claim_type": "Overtime", "authority_reference": reference,
					 "docstatus": ("!=", 2)}, "name",
				)
				if not exists:
					from frappe.utils import now_datetime
					from karyo.hr.manual_input import _create_additional_hours, _employee

					audit = {
						"custom_entry_source": "Attendance Import",
						"custom_manual_reference": reference,
						"custom_manual_by": frappe.session.user,
						"custom_manual_on": now_datetime(),
					}
					_create_additional_hours(frappe._dict(
						attendance_date=doc.attendance_date,
						requested_hours=flt(raw.get("overtime_hours")),
					), _employee(doc.employee), audit, "Overtime")
			frappe.publish_realtime(
				"import_attendance", {"progress": index - header_index - 1, "total": len(data_rows)}
			)
		except Exception as error:
			has_error = True
			results.append(
				_("Error for row (#{0}) {1}: {2}").format(
					index, raw.get("employee_code") or "", cstr(error)
				)
			)
			frappe.log_error(frappe.get_traceback(), _("Attendance import row {0}").format(index))
	if has_error:
		frappe.db.rollback()
	else:
		frappe.db.commit()
	frappe.publish_realtime("import_attendance", {"messages": results, "error": has_error})
	return {"messages": results, "error": has_error}
