frappe.pages['karyo-configure'].on_page_load = wrapper => {
 frappe.ui.make_app_page({parent:wrapper,title:__('Admin Settings'),single_column:true});
};
frappe.pages['karyo-configure'].on_page_show = wrapper => karyo.settings.render(wrapper);
