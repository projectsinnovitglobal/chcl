"""End-to-end smoke test for Passage Benefit: earn -> claim (workflow) -> settle.
Runs against the DB then rolls back (no persistence).

    bench --site dev.localhost execute karyo.setup.smoke.run
"""

import frappe
from frappe.model.workflow import apply_workflow


def run():
	try:
		_run()
	finally:
		frappe.db.rollback()
		print("(rolled back — no data persisted)")


def _make_employee(company):
	return frappe.get_doc(
		{
			"doctype": "Employee",
			"first_name": "Karyo",
			"last_name": "SmokeTest",
			"gender": frappe.db.get_value("Gender", {}, "name") or "Male",
			"date_of_birth": "1985-01-01",
			"date_of_joining": "2016-01-01",
			"company": company,
			"status": "Active",
			"pb_eligible": 1,
			"employment_type": "Permanent",
			"karyo_employment_category": "PERM",
			"karyo_permanent_pensionable": 1,
			"karyo_date_confirmed": "2021-01-01",
		}
	).insert(ignore_permissions=True, ignore_mandatory=True)


def _run():
	company = frappe.db.get_value("Company", {}, "name")
	if not company:
		print("SKIP: no Company on site")
		return

	emp = _make_employee(company)
	frappe.get_doc(
		{
			"doctype": "Passage Benefit Bank",
			"employee": emp.name,
			"opening_date": "2026-01-01",
			"opening_balance": 0,
		}
	).insert(ignore_permissions=True)

	# --- 1) EARN ---
	comp = frappe.get_doc(
		{
			"doctype": "Passage Benefit Computation",
			"employee": emp.name,
			"from_date": "2026-01-01",
			"to_date": "2026-04-30",
			"pay_period": "Apr-2026",
			"segments": [{"monthly_salary": 30000, "eligible_days": 120}],
		}
	)
	comp.insert(ignore_permissions=True)
	comp.submit()
	bank = frappe.get_doc("Passage Benefit Bank", emp.name)
	print(f"After EARN: balance = {bank.current_balance} (expect 5918.4)")
	assert bank.current_balance == 5918.40

	# --- 2) CLAIM through the workflow (Finance-final) ---
	frappe.get_doc(
		{
			"doctype": "Passage Benefit Usage Item",
			"usage_item_code": "AIRTICKET",
			"usage_item_name": "Air Ticket",
			"encash_rate": 100,
			"min_balance_credit": 1000,
			"is_active": 1,
		}
	).insert(ignore_permissions=True)

	app = frappe.get_doc(
		{
			"doctype": "Passage Benefit Application",
			"employee": emp.name,
			"usage_item": "AIRTICKET",
			"request_amount": 2000,
			"posting_date": "2026-05-10",
			"pay_period": "May-2026",
		}
	)
	app.insert(ignore_permissions=True)
	print(
		f"Claim computed: claimable={app.claimable_amount} available={app.available_balance} state={app.workflow_state}"
	)
	assert app.claimable_amount == 2000

	for action in ("Submit for Approval", "Recommend", "Approve", "Process"):
		app = apply_workflow(app, action)
	app.reload()
	bank.reload()
	print(
		f"After CLAIM ({app.workflow_state}): processed={app.processed} taken={app.amount_taken} balance={bank.current_balance}"
	)
	assert app.workflow_state == "Processed" and app.processed == 1
	assert app.amount_taken == 2000
	assert bank.current_balance == 3918.40, f"expected 3918.40 got {bank.current_balance}"
	assert bank.total_taken == 2000

	# --- 3) GUARDRAIL: min-balance breach must block ---
	blocked = frappe.get_doc(
		{
			"doctype": "Passage Benefit Application",
			"employee": emp.name,
			"usage_item": "AIRTICKET",
			"request_amount": 3500,  # would leave 418.40 < 1000 min balance
			"posting_date": "2026-05-11",
		}
	)
	try:
		blocked.insert(ignore_permissions=True)
		raise AssertionError("min-balance breach was NOT blocked")
	except frappe.ValidationError:
		print("Guardrail OK: min-balance breach blocked (PB-USG-008)")

	print("SMOKE PASS ✔  earn -> claim(workflow) -> balance reduced, guardrails enforced.")
