import unittest
from uuid import uuid4

import frappe

from karyo.payroll.bank_export import bank_artifact_exists, build_mcb_ascii
from karyo.payroll.paye import calculate_cumulative_paye


class TestMBCPayrollUATFlow(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("mbc_payroll_uat_flow")

	def tearDown(self):
		frappe.db.rollback(save_point="mbc_payroll_uat_flow")
		frappe.set_user(self.user)

	def test_october_2026_paye_rounds_current_deduction_down_to_uat_amount(self):
		bands = [
			{"upper": 500000, "rate": 0},
			{"upper": 1000000, "rate": 10},
			{"upper": 12000000, "rate": 20},
			{"upper": None, "rate": 35},
		]
		result = calculate_cumulative_paye(
			cumulative_emoluments=204000,
			period_index=4,
			bands=bands,
			annual_reliefs=110000,
			previous_paye=1223.07,
			periods_per_year=13,
			precision=0,
			current_emoluments=51000,
			current_rounding="Round Down",
		)
		self.assertEqual(result["allowed_reliefs"], 33846.15)
		self.assertEqual(result["chargeable_income"], 170153.85)
		self.assertEqual(result["current_paye"], 407)

	def test_mcb_ascii_includes_bank_paid_employees_once_and_excludes_cheque(self):
		cycle, entry = self._cycle_with_entry()
		self._salary_slip(
			entry.name, "EMP-2108", "Asha Raman", "Bank",
			"Mauritius Commercial Bank", "00000000004432", 48563,
		)
		self._salary_slip(
			entry.name, "EMP-2142", "Kevin Noor", "Bank",
			"Mauritius Commercial Bank", "00000000005510", 41000,
		)
		self._salary_slip(
			entry.name, "EMP-2167", "Lina Wong", "Cheque",
			"Mauritius Commercial Bank", "00000000006610", 39000,
		)

		result = build_mcb_ascii(cycle.name, file_name="MBC_OCT2026.txt")

		self.assertEqual(result["employees"], 2)
		self.assertEqual(result["total"], 89563)
		self.assertIn("EMP-2108", result["content"])
		self.assertIn("EMP-2142", result["content"])
		self.assertNotIn("EMP-2167", result["content"])
		self.assertTrue(bank_artifact_exists(cycle.name, "MCB"))

	def test_mcb_ascii_uses_primary_and_secondary_salary_bank_split(self):
		cycle, entry = self._cycle_with_entry()
		self._salary_slip(
			entry.name, "EMP-2108", "Asha Raman", "Bank",
			"Mauritius Commercial Bank", "00000000004432", 48563,
			split={
				"primary_account": "00000000004432",
				"primary_amount": 46563,
				"secondary_account": "00000000009999",
				"secondary_amount": 2000,
			},
		)

		result = build_mcb_ascii(cycle.name, file_name="MBC_SPLIT_OCT2026.txt")

		self.assertEqual(result["employees"], 1)
		self.assertEqual(result["payments"], 2)
		self.assertEqual(result["total"], 48563)
		self.assertIn("00000000004432|46563.00", result["content"])
		self.assertIn("00000000009999|2000.00", result["content"])

	def _cycle_with_entry(self):
		template = frappe.db.get_value("Payroll Pay Day", {"payroll_type": "Major"}, "name", order_by="start_date")
		day = frappe.copy_doc(frappe.get_doc("Payroll Pay Day", template))
		day.name = "uat-payday-" + uuid4().hex
		day.pay_day_code = day.name
		day.status = "Active"
		day.pay_period_label = "October 2026 Major UAT " + uuid4().hex[:6]
		day.start_date = "2026-10-01"
		day.end_date = "2026-10-31"
		day.payment_date = "2026-10-30"
		day.docstatus = 0
		day.db_insert()
		cycle = frappe.get_doc(
			{"doctype": "Payroll Cycle", "company": day.company, "pay_day": day.name, "status": "Draft"}
		).insert()
		entry = frappe.get_doc(
			{
				"doctype": "Payroll Entry",
				"name": "uat-entry-" + uuid4().hex,
				"company": cycle.company,
				"karyo_payroll_cycle": cycle.name,
				"start_date": cycle.start_date,
				"end_date": cycle.end_date,
				"posting_date": cycle.payment_date,
				"payroll_frequency": "Monthly",
			}
		)
		entry.db_insert()
		frappe.db.set_value("Payroll Cycle", cycle.name, "payroll_entry", entry.name)
		cycle.reload()
		return cycle, entry

	def _salary_slip(self, entry, employee, name, mode, bank, account, net_pay, split=None):
		data = {
			"doctype": "Salary Slip",
			"name": "uat-slip-" + uuid4().hex,
			"employee": employee,
			"employee_name": name,
			"company": frappe.db.get_value("Payroll Entry", entry, "company"),
			"payroll_entry": entry,
			"karyo_payroll_cycle": frappe.db.get_value("Payroll Entry", entry, "karyo_payroll_cycle"),
			"start_date": "2026-10-01",
			"end_date": "2026-10-31",
			"posting_date": "2026-10-30",
			"mode_of_payment": mode,
			"bank_name": bank,
			"bank_account_no": account,
			"gross_pay": net_pay,
			"net_pay": net_pay,
			"docstatus": 1,
		}
		doc = frappe.get_doc(data)
		if split:
			for fieldname, value in {
				"karyo_primary_remittance_bank": bank,
				"karyo_primary_remittance_account": split.get("primary_account"),
				"karyo_primary_remittance_amount": split.get("primary_amount"),
				"karyo_secondary_remittance_bank": bank,
				"karyo_secondary_remittance_account": split.get("secondary_account"),
				"karyo_secondary_remittance_amount": split.get("secondary_amount"),
			}.items():
				if doc.meta.has_field(fieldname):
					doc.set(fieldname, value)
		doc.db_insert()
