"""Employee series configuration exposed within HR Settings."""
import re

import frappe
from frappe import _
from frappe.model.naming import NamingSeries, parse_naming_series


def _access(write=False):
	frappe.get_doc("HR Settings").check_permission("write" if write else "read")
	if write:
		frappe.only_for("System Manager")


def _default():
	field = frappe.get_meta("Employee").get_field("naming_series")
	options = [value.strip() for value in (field.options or "").splitlines() if value.strip()]
	return field.default or (options[0] if options else ""), options


def _series(value):
	series = NamingSeries(str(value or "").strip())
	series.validate()
	if not re.fullmatch(r"[^#{}]+\.#{1,10}", series.series):
		frappe.throw(_("Use a series ending in numeric placeholders, for example HR-EMP-.#####."))
	return series


def _highest(prefix):
	return int(frappe.db.sql("""select coalesce(max(cast(substring(name,%s) as unsigned)),0)
		from `tabEmployee` where name regexp %s""", (len(prefix)+1, "^"+re.escape(prefix)+"[0-9]+$"))[0][0])


def _preview(series, number):
	return parse_naming_series(series.series, number_generator=lambda prefix,digits: str(number).zfill(digits))


@frappe.whitelist()
def current(series=None):
	_access()
	default, options = _default()
	pattern = _series(series or default)
	prefix = pattern.get_prefix()
	counter = int(frappe.db.get_value("Series", prefix, "current", order_by="name") or 0)
	next_number = max(counter, _highest(prefix)) + 1
	return {"series": pattern.series, "default_series":default, "prefix":pattern.series.split(".")[0],
		"resolved_prefix":prefix,"current_number":counter,"next_number":next_number,
		"preview":_preview(pattern,next_number),"can_manage": "System Manager" in frappe.get_roles()
		and frappe.has_permission("HR Settings","write")}


@frappe.whitelist(methods=["POST"])
def save(series, next_number, expected_default):
	_access(write=True)
	pattern = _series(series)
	if not re.fullmatch(r"[0-9]+",str(next_number)) or not 1 <= int(next_number) <= 2147483647:
		frappe.throw(_("Next Number must be a positive whole number up to 2147483647."))
	next_number = int(next_number)
	# Serialize configuration changes and reject a stale settings form.
	frappe.db.sql("select name from `tabDocType` where name='Employee' for update")
	default, options = _default()
	if default != expected_default:
		frappe.throw(_("Employee numbering has changed. Reload HR Settings before saving."))
	counter = pattern.get_current_value()
	if next_number <= max(counter, _highest(pattern.get_prefix())):
		frappe.throw(_("This number has already been used. Reload the current series and choose a higher next number."))
	settings = frappe.get_single("Document Naming Settings")
	settings.transaction_type = "Employee"
	settings.naming_series_options = "\n".join([pattern.series]+[option for option in options if option != pattern.series])
	settings.user_must_always_select = 0
	settings.check_duplicate()
	settings.set_series_options_in_meta("Employee",settings.naming_series_options)
	pattern.update_counter(next_number-1)
	settings.create_version_log_for_change(pattern.get_prefix(),counter,next_number-1)
	return current(pattern.series)
