"""Recurring/static employee PDB transactions and posting ledger (PAY-030)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Employee Recurring PDB History",
		istable=1,
		fields=[
			f("changed_on", "Datetime", "Changed On", read_only=1, in_list_view=1),
			f("changed_by", "Link", "Changed By", options="User", read_only=1),
			f("action", "Data", "Action", read_only=1, in_list_view=1),
			f("from_status", "Data", "From Status", read_only=1),
			f("to_status", "Data", "To Status", read_only=1, in_list_view=1),
			f("reason", "Small Text", "Reason", read_only=1),
		],
	)
	make_doctype(
		"Employee Recurring PDB",
		autoname="format:RPDB-{employee}-{pdb_code}-.#####",
		title_field="employee_name",
		fields=[
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1),
			f("company", "Link", "Company", options="Company", reqd=1),
			f("pdb_cb", "Column Break"),
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1, in_list_view=1),
			f("pdb_type", "Link", "PDB Type", options="Payroll PDB Type", read_only=1),
			f("salary_component", "Link", "Salary Component", options="Salary Component", read_only=1),
			f("transaction_type", "Select", "Payment / Deduction", options="Payment\nDeduction", read_only=1, in_list_view=1),
			f("calculation_sb", "Section Break", "Calculation"),
			f(
				"calculation_method",
				"Select",
				"Calculation Basis",
				options="Fixed Monthly\nPercentage of Basic Salary\nFormula",
				default="Fixed Monthly",
				reqd=1,
			),
			f("amount", "Currency", "Amount / Rate", depends_on="eval:doc.calculation_method!='Formula'"),
			f("formula", "Code", "Formula", depends_on="eval:doc.calculation_method=='Formula'"),
			f("balance_cb", "Column Break"),
			f("is_reducing_balance", "Check", "Reducing Balance", read_only=1),
			f("initial_balance", "Currency", "Outstanding / Reducing Balance"),
			f("remaining_balance", "Currency", "Remaining Balance", read_only=1),
			f("priority", "Int", "Priority", default="1"),
			f("period_sb", "Section Break", "Effective Period and Status"),
			f("start_date", "Date", "Effective From", reqd=1, in_list_view=1),
			f("end_date", "Date", "Effective To", in_list_view=1),
			f("period_cb", "Column Break"),
			f(
				"status",
				"Select",
				"Status",
				options="Draft\nActive\nSuspended\nCompleted\nCancelled\nAmended",
				default="Draft",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f("supersedes", "Link", "Supersedes", options="Employee Recurring PDB", read_only=1),
			f("remarks", "Small Text", "Remarks"),
			f("change_reason", "Small Text", "Status Change Reason"),
			f("history_sb", "Section Break", "History", collapsible=1),
			f("history", "Table", "History", options="Employee Recurring PDB History", read_only=1),
		],
	)
	make_doctype(
		"Employee Recurring PDB Posting",
		autoname="format:RPDBP-{payroll_cycle}-{recurring_pdb}",
		fields=[
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1),
			f(
				"recurring_pdb",
				"Link",
				"Recurring PDB",
				options="Employee Recurring PDB",
				reqd=1,
				in_list_view=1,
			),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1),
			f("salary_component", "Link", "Salary Component", options="Salary Component", reqd=1),
			f("amount", "Currency", "Posted Amount", reqd=1, in_list_view=1),
			f("balance_before", "Currency", "Balance Before"),
			f("balance_after", "Currency", "Balance After"),
			f("additional_salary", "Link", "Additional Salary", options="Additional Salary", read_only=1),
			f("status", "Select", "Status", options="Posted\nReversed", default="Posted", reqd=1),
			f("posted_on", "Datetime", "Posted On", read_only=1),
			f("posted_by", "Link", "Posted By", options="User", read_only=1),
		],
	)


def add_permissions():
	for doctype in ("Employee Recurring PDB", "Employee Recurring PDB Posting"):
		meta = frappe.get_doc("DocType", doctype)
		matrix = {
			"Payroll Input": {"read": 1, "write": 1, "create": 1, "report": 1},
			"Payroll Processor": {"read": 1, "write": 1, "create": 1, "report": 1},
			"Payroll Reviewer": {"read": 1, "report": 1},
			"Payroll Approver": {"read": 1, "write": 1, "report": 1},
			"Payroll Auditor": {"read": 1, "report": 1, "export": 1},
		}
		for role, values in matrix.items():
			row = next((permission for permission in meta.permissions if permission.role == role), None)
			if not row:
				row = meta.append("permissions", {"role": role})
			for fieldname, value in values.items():
				row.set(fieldname, value)
		meta.save(ignore_permissions=True)


def ensure_upgrade_fields():
	create_custom_fields(
		{
			"Employee Recurring PDB": [
				{
					"fieldname": "supersedes",
					"fieldtype": "Link",
					"label": "Supersedes",
					"options": "Employee Recurring PDB",
					"read_only": 1,
					"insert_after": "status",
				}
			]
		},
		ignore_validate=True,
	)
	meta = frappe.get_doc("DocType", "Employee Recurring PDB")
	legacy = next((row for row in meta.fields if row.fieldname == "amended_from"), None)
	if legacy:
		meta.remove(legacy)
		meta.save(ignore_permissions=True)


def setup():
	print("Karyo recurring PDB setup:")
	create_doctypes()
	ensure_upgrade_fields()
	add_permissions()
	frappe.db.commit()
	print("Done (recurring PDB controls and cycle posting ledger created).")
