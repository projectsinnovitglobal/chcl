frappe.query_reports["Loan Statement"] = {
	filters: [
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan", reqd: 1 },
		{ fieldname: "from_date", label: __("From Date"), fieldtype: "Date" },
		{ fieldname: "to_date", label: __("To Date"), fieldtype: "Date" },
		{ fieldname: "component", label: __("Component"), fieldtype: "Select", options: "\nCapital\nInterest\nInsurance\nOther" },
		{ fieldname: "include_reversals", label: __("Include Reversals"), fieldtype: "Check", default: 1 },
	],
};
