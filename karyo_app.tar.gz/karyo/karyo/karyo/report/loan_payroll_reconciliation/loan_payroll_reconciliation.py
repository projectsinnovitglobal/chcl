import frappe
from frappe import _
from frappe.utils import flt


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if not filters.from_date or not filters.to_date:
		frappe.throw(_("From Date and To Date are required."))
	conditions = ["s.due_date between %(from_date)s and %(to_date)s"]
	if filters.loan:
		conditions.append("l.name=%(loan)s")
	if filters.employee:
		conditions.append("l.employee=%(employee)s")
	rows = frappe.db.sql(
		f"""
		select l.name loan, l.employee, l.approved_amount, l.outstanding_capital,
			sum(s.capital) scheduled_capital, sum(s.interest) scheduled_interest,
			sum(s.insurance) scheduled_insurance,
			sum(s.paid_capital) paid_capital, sum(s.paid_interest) paid_interest,
			sum(s.paid_insurance) paid_insurance
		from `tabKaryo Loan` l inner join `tabKaryo Loan Schedule` s on s.parent=l.name
		where {' and '.join(conditions)} group by l.name, l.employee order by l.employee, l.name
		""",
		filters,
		as_dict=True,
	)
	loan_names = [row.loan for row in rows]
	ledger_by_loan = {}
	allocation_by_loan = {}
	allocation_flags = {}
	outstanding_by_loan = {}
	if loan_names:
		outstanding_by_loan = {r.loan: flt(r.expected) for r in frappe.db.sql(
			"""select parent loan, coalesce(sum(greatest(capital-paid_capital,0)),0) expected
			from `tabKaryo Loan Schedule` where parent in %(loans)s and is_current=1 group by parent""",
			{"loans": loan_names}, as_dict=True)}
		ledger_by_loan = {r.loan: flt(r.net) for r in frappe.db.sql(
			"""select loan, coalesce(sum(credit-debit),0) net from `tabKaryo Loan Ledger Entry`
			where loan in %(loans)s and transaction_date between %(from_date)s and %(to_date)s
			and ref_type in ('Loan Capital','Loan Interest','Loan Insurance','Loan Capital Reversal',
			'Loan Interest Reversal','Loan Insurance Reversal') group by loan""",
			{"loans": loan_names, "from_date": filters.from_date, "to_date": filters.to_date}, as_dict=True)}
		allocation_by_loan = {r.loan: flt(r.net) for r in frappe.db.sql(
			"""select loan, coalesce(sum(case when is_reversal=1 then -amount else amount end),0) net
			from `tabKaryo Loan Payroll Allocation` where loan in %(loans)s
			and posting_date between %(from_date)s and %(to_date)s group by loan""",
			{"loans": loan_names, "from_date": filters.from_date, "to_date": filters.to_date}, as_dict=True)}
		for flag in frappe.db.sql("""select a.loan,
			sum(case when s.name is null then 1 else 0 end) unmatched_count,
			sum(case when s.name is not null and s.due_date not between %(from_date)s and %(to_date)s then 1 else 0 end) out_of_period_count,
			sum(case when a.is_reversal=1 then 1 else 0 end) reversal_count
			from `tabKaryo Loan Payroll Allocation` a
			left join `tabKaryo Loan Schedule` s on s.name=a.schedule_row and s.parent=a.loan
			where a.loan in %(loans)s and a.posting_date between %(from_date)s and %(to_date)s group by a.loan""",
			{"loans": loan_names, "from_date": filters.from_date, "to_date": filters.to_date}, as_dict=True):
			allocation_flags[flag.loan] = flag
		for duplicate in frappe.db.sql("""select loan, count(*) duplicate_count from (
			select loan, salary_slip, schedule_row, component from `tabKaryo Loan Payroll Allocation`
			where loan in %(loans)s and posting_date between %(from_date)s and %(to_date)s and is_reversal=0
			group by loan, salary_slip, schedule_row, component having count(*) > 1
		) duplicates group by loan""", {"loans": loan_names, "from_date": filters.from_date,
			"to_date": filters.to_date}, as_dict=True):
			allocation_flags.setdefault(duplicate.loan, frappe._dict()).duplicate_count = duplicate.duplicate_count
	for row in rows:
		row.scheduled_total = flt(row.scheduled_capital)+flt(row.scheduled_interest)+flt(row.scheduled_insurance)
		row.paid_total = flt(row.paid_capital)+flt(row.paid_interest)+flt(row.paid_insurance)
		row.payroll_total = allocation_by_loan.get(row.loan, 0)
		row.schedule_difference = row.paid_total-row.payroll_total
		row.ledger_total = ledger_by_loan.get(row.loan, 0)
		row.ledger_difference = row.payroll_total-row.ledger_total
		row.expected_outstanding = outstanding_by_loan.get(row.loan, 0)
		row.outstanding_difference = flt(row.outstanding_capital)-row.expected_outstanding
		flags = allocation_flags.get(row.loan, frappe._dict())
		row.duplicate_count = int(flags.get("duplicate_count") or 0)
		row.unmatched_count = int(flags.get("unmatched_count") or 0)
		row.out_of_period_count = int(flags.get("out_of_period_count") or 0)
		row.reversal_count = int(flags.get("reversal_count") or 0)
		row.result = classify_reconciliation(row)
	return _columns(), rows


def classify_reconciliation(row):
	"""Return one deterministic, operationally actionable exception class."""
	if row.get("duplicate_count"):
		return "Duplicate Deduction"
	if row.get("unmatched_count"):
		return "Unmatched Deduction"
	if row.get("out_of_period_count"):
		return "Out-of-period Deduction"
	if row.get("reversal_count") and abs(flt(row.paid_total)) < 0.005:
		return "Reversed"
	if abs(flt(row.ledger_difference)) >= 0.005:
		return "Ledger Mismatch"
	if abs(flt(row.outstanding_difference)) >= 0.005:
		return "Outstanding Balance Mismatch"
	if abs(flt(row.schedule_difference)) >= 0.005:
		return "Payroll Allocation Mismatch"
	if flt(row.paid_total) == 0 and flt(row.scheduled_total):
		return "Missing Recovery"
	if flt(row.scheduled_total)-flt(row.paid_total) > 0.005:
		return "Partial / Arrears"
	if flt(row.scheduled_total)-flt(row.paid_total) < -0.005:
		return "Over-deduction"
	return "Reconciled"


def _columns():
	return [
		{"fieldname":"loan","label":_("Loan"),"fieldtype":"Link","options":"Karyo Loan","width":150},
		{"fieldname":"employee","label":_("Employee"),"fieldtype":"Link","options":"Employee","width":140},
		{"fieldname":"scheduled_total","label":_("Scheduled"),"fieldtype":"Currency","width":120},
		{"fieldname":"paid_total","label":_("Schedule Paid"),"fieldtype":"Currency","width":125},
		{"fieldname":"payroll_total","label":_("Payroll Allocated"),"fieldtype":"Currency","width":140},
		{"fieldname":"ledger_total","label":_("Ledger"),"fieldtype":"Currency","width":120},
		{"fieldname":"schedule_difference","label":_("Schedule vs Payroll"),"fieldtype":"Currency","width":150},
		{"fieldname":"ledger_difference","label":_("Ledger Difference"),"fieldtype":"Currency","width":140},
		{"fieldname":"outstanding_capital","label":_("Outstanding Balance"),"fieldtype":"Currency","width":145},
		{"fieldname":"expected_outstanding","label":_("Schedule Outstanding"),"fieldtype":"Currency","width":150},
		{"fieldname":"outstanding_difference","label":_("Outstanding Difference"),"fieldtype":"Currency","width":155},
		{"fieldname":"duplicate_count","label":_("Duplicates"),"fieldtype":"Int","width":90},
		{"fieldname":"unmatched_count","label":_("Unmatched"),"fieldtype":"Int","width":90},
		{"fieldname":"out_of_period_count","label":_("Out of Period"),"fieldtype":"Int","width":105},
		{"fieldname":"reversal_count","label":_("Reversals"),"fieldtype":"Int","width":85},
		{"fieldname":"result","label":_("Result"),"fieldtype":"Data","width":100},
	]
