"""Set the initial site currency once; later user changes remain untouched."""

import frappe


def execute():
	if not frappe.db.exists("Currency", "MUR"):
		frappe.get_doc({"doctype": "Currency", "currency_name": "MUR", "enabled": 1}).insert(ignore_permissions=True)
	frappe.db.set_default("currency", "MUR")
	for company in frappe.get_all("Company", filters={"default_currency": ["is", "not set"]}, pluck="name"):
		frappe.db.set_value("Company", company, "default_currency", "MUR", update_modified=False)

