"""Karyo Loan — payroll appraisal fields + recast transaction.

    bench --site dev.localhost execute karyo.setup.loan_appraisal_recast.setup

Adds: max deduction % (Karyo Settings), recast cap % (Loan Type), payroll
appraisal + outstanding-capital fields (Karyo Loan), and the Karyo Loan Recast
transaction DocType. Idempotent.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.utils import add_months, flt, getdate

from karyo.setup.foundation import f, make_doctype


def add_fields():
	create_custom_fields(
		{
			"Karyo Settings": [
				{
					"fieldname": "max_deduction_pct",
					"fieldtype": "Percent",
					"label": "Max Deduction % (Loan Appraisal)",
					"default": "40",
					"description": "Loan affordability ceiling (BR-FAR-LMS-PAY-007 / CF-004).",
					"insert_after": "day_count_basis",
				},
			],
			"Loan Type": [
				{
					"fieldname": "recast_cap_pct",
					"fieldtype": "Percent",
					"label": "Recast Cap %",
					"default": "0",
					"description": "Max % increase over current instalment on recast (0 = no cap, RCT-003/004).",
					"insert_after": "max_period_months",
				},
			],
			"Karyo Loan": [
				{"fieldname": "interest_recovery_method", "fieldtype": "Data", "label": "Interest Recovery Method", "read_only": 1, "insert_after": "total_interest"},
				{"fieldname": "schedule_version", "fieldtype": "Int", "label": "Current Schedule Version", "default": "1", "read_only": 1, "allow_on_submit": 1, "insert_after": "total_paid"},
				{
					"fieldname": "appraisal_sb",
					"fieldtype": "Section Break",
					"label": "Payroll Appraisal",
					"insert_after": "total_insurance",
				},
				{
					"fieldname": "eligible_salary",
					"fieldtype": "Currency",
					"label": "Eligible Salary (Monthly)",
					"read_only": 1,
					"insert_after": "appraisal_sb",
				},
				{
					"fieldname": "existing_deductions",
					"fieldtype": "Currency",
					"label": "Existing Monthly Deductions",
					"read_only": 1,
					"insert_after": "eligible_salary",
				},
				{"fieldname": "appr_cb", "fieldtype": "Column Break", "insert_after": "existing_deductions"},
				{
					"fieldname": "deduction_pct",
					"fieldtype": "Percent",
					"label": "Proposed / After-Loan Deduction %",
					"read_only": 1,
					"insert_after": "appr_cb",
				},
				{
					"fieldname": "appraisal_status",
					"fieldtype": "Select",
					"label": "Appraisal",
					"options": "\nPass\nFail\nNot Appraised",
					"read_only": 1,
					"insert_after": "deduction_pct",
				},
				{
					"fieldname": "override_deduction_limit",
					"fieldtype": "Check",
					"label": "Override Deduction Limit",
					"insert_after": "appraisal_status",
				},
				{
					"fieldname": "outstanding_capital",
					"fieldtype": "Currency",
					"label": "Outstanding Capital",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "override_deduction_limit",
				},
				{
					"fieldname": "outstanding_interest",
					"fieldtype": "Currency",
					"label": "Outstanding Interest",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "outstanding_capital",
				},
				{
					"fieldname": "outstanding_insurance",
					"fieldtype": "Currency",
					"label": "Outstanding Insurance",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "outstanding_interest",
				},
				{
					"fieldname": "total_paid",
					"fieldtype": "Currency",
					"label": "Total Recovered",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "outstanding_insurance",
				},
			],
		},
		ignore_validate=True,
	)
	create_custom_fields(
		{
			"Karyo Loan Schedule": [
				{"fieldname": "interest_generated", "fieldtype": "Currency", "label": "Reducing-Balance Interest Generated", "read_only": 1, "insert_after": "capital"},
				{"fieldname": "remarks", "fieldtype": "Small Text", "label": "Remarks", "insert_after": "status"},
				{"fieldname": "schedule_version", "fieldtype": "Int", "label": "Schedule Version", "default": "1", "read_only": 1, "in_list_view": 1, "insert_after": "month"},
				{"fieldname": "is_current", "fieldtype": "Check", "label": "Current", "default": "1", "read_only": 1, "insert_after": "schedule_version"},
				{"fieldname": "superseded_by", "fieldtype": "Link", "label": "Superseded By", "options": "Karyo Loan Recast", "read_only": 1, "insert_after": "is_current"},
				{"fieldname": "superseded_by_doctype", "fieldtype": "Link", "label": "Superseded By Type", "options": "DocType", "read_only": 1, "insert_after": "superseded_by"},
				{"fieldname": "superseded_by_name", "fieldtype": "Dynamic Link", "label": "Superseded By Transaction", "options": "superseded_by_doctype", "read_only": 1, "insert_after": "superseded_by_doctype"},
			],
			"Karyo Loan Recast": [
				{"fieldname": "reason", "fieldtype": "Small Text", "label": "Reason", "insert_after": "override_cap"},
				{"fieldname": "evidence", "fieldtype": "Attach", "label": "Supporting Evidence", "insert_after": "reason"},
				{"fieldname": "approval_reference", "fieldtype": "Data", "label": "Approval Reference", "insert_after": "evidence"},
				{"fieldname": "prior_state_snapshot", "fieldtype": "Long Text", "label": "Prior Loan State Snapshot", "read_only": 1, "hidden": 1, "insert_after": "override_cap"},
				{"fieldname": "applied_schedule_version", "fieldtype": "Int", "label": "Applied Schedule Version", "read_only": 1, "insert_after": "prior_state_snapshot"},
				{"fieldname": "idempotency_key", "fieldtype": "Data", "label": "Idempotency Key", "read_only": 1, "unique": 1, "insert_after": "applied_schedule_version"},
				{"fieldname": "reversal_processed", "fieldtype": "Check", "label": "Reversal Processed", "read_only": 1, "insert_after": "idempotency_key"},
			],
		},
		ignore_validate=True,
	)
	# Recast updates loan monthly_* summary fields after submit via db_set(),
	# which bypasses the update-after-submit guard — no allow_on_submit needed.
	print("  + appraisal / recast fields ensured")


def create_recast_doctype():
	make_doctype(
		"Karyo Loan Recast",
		is_submittable=1,
		autoname="naming_series:",
		title_field="loan",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="RCST-.YYYY.-.#####",
				default="RCST-.YYYY.-.#####",
			),
			f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
			f("employee", "Data", "Employee", read_only=1),
			f("loan_type", "Data", "Loan Type", read_only=1),
			f("hcb", "Column Break"),
			f("effective_date", "Date", "Effective Date", reqd=1),
			f("advance_payment", "Currency", "Advance Payment / Refund", default="0"),
			f("new_period", "Int", "New Period (Months)", reqd=1),
			f("inputs_sb", "Section Break", "Inputs"),
			f("interest_rate", "Percent", "Annual Interest Rate", read_only=1),
			f("insurance_rate", "Float", "Insurance Rate (per Rs 10,000)", read_only=1, precision=4),
			f("cap_pct", "Percent", "Recast Cap %"),
			f("icb", "Column Break"),
			f("current_instalment", "Currency", "Current Instalment"),
			f("outstanding_before", "Currency", "Outstanding Before", read_only=1),
			f("new_outstanding_capital", "Currency", "New Outstanding Capital", read_only=1),
			f("result_sb", "Section Break", "Recast Result"),
			f("monthly_capital", "Currency", "Monthly Capital", read_only=1),
			f("monthly_interest", "Currency", "Monthly Interest", read_only=1),
			f("monthly_insurance", "Currency", "Monthly Insurance", read_only=1),
			f("rcb", "Column Break"),
			f("total_monthly_deduction", "Currency", "Total Monthly Deduction", read_only=1),
			f("max_allowed_instalment", "Currency", "Max Allowed Instalment", read_only=1),
			f("raw_instalment", "Currency", "Raw Annuity Instalment", read_only=1),
			f("cap_result", "Data", "Cap Result", read_only=1),
			f("override_cap", "Check", "Override Cap"),
			f("sched_sb", "Section Break", "New Schedule"),
			f("schedule", "Table", "Schedule", options="Karyo Loan Schedule"),
			f("ded_sb", "Section Break", "New Static Deductions"),
			f("deductions", "Table", "Deductions", options="Karyo Loan Deduction"),
		],
	)


def backfill_loan_payroll_balances():
	"""Idempotently initialise payroll-control fields for loans created before this feature."""
	for name in frappe.get_all("Karyo Loan", pluck="name"):
		loan = frappe.get_doc("Karyo Loan", name)
		start = loan.repayment_start_date or loan.disbursement_date
		for row in loan.schedule or []:
			if start and not row.due_date:
				row.db_set("due_date", add_months(getdate(start), int(row.month) - 1), update_modified=False)
		interest = sum(max(0, flt(row.interest) - flt(row.paid_interest)) for row in loan.schedule or [])
		insurance = sum(max(0, flt(row.insurance) - flt(row.paid_insurance)) for row in loan.schedule or [])
		paid = sum(
			flt(row.paid_capital) + flt(row.paid_interest) + flt(row.paid_insurance)
			for row in loan.schedule or []
		)
		frappe.db.set_value(
			"Karyo Loan",
			name,
			{
				"outstanding_interest": interest,
				"outstanding_insurance": insurance,
				"total_paid": paid,
			},
			update_modified=False,
		)


def setup():
	print("Karyo Loan appraisal + recast setup:")
	add_fields()
	create_recast_doctype()
	backfill_loan_payroll_balances()
	frappe.db.commit()
	print("Done.")
