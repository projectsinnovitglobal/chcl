"""Leave encashment availability, analytics and payroll linkage."""

import frappe
from frappe import _
from frappe.utils import flt, getdate, nowdate
from hrms.hr.doctype.leave_encashment.leave_encashment import LeaveEncashment


ENCASHMENT_ADMIN_ROLES = {
	"System Manager", "HR Manager", "HR User", "Payroll Manager", "Payroll User",
	"Payroll Processor", "Payroll Reviewer", "Payroll Approver", "Payroll Finance",
}


class KaryoLeaveEncashment(LeaveEncashment):
	"""Use the governed refund divisor when no explicit daily rate is configured."""

	def set_encashment_days(self):
		"""Require an explicit requested quantity instead of defaulting to the maximum."""
		days = flt(self.encashment_days)
		if days < 0:
			frappe.throw(_("Encashment Days cannot be negative."))
		if days > flt(self.actual_encashable_days):
			frappe.throw(
				_("Encashment Days cannot exceed {0} qualified day(s).").format(
					self.actual_encashable_days,
				)
			)
		self.encashment_days = days

	def set_encashment_amount(self):
		super().set_encashment_amount()
		days = flt(self.encashment_days)
		if days <= 0:
			return
		per_day = flt(self.encashment_amount) / days if flt(self.encashment_amount) > 0 else 0
		if not per_day:
			assignment = frappe.db.get_value(
				"Salary Structure Assignment",
				filters={
					"employee": self.employee,
					"salary_structure": self._salary_structure,
					"docstatus": 1,
					"from_date": ("<=", self.encashment_date),
				},
				fieldname=["base", "leave_encashment_amount_per_day"],
				order_by="from_date desc",
				as_dict=True,
			) or frappe._dict()
			per_day = flt(assignment.leave_encashment_amount_per_day)
			if not per_day:
				divisor = flt(frappe.db.get_value(
					"Leave Type", self.leave_type, "karyo_refund_divisor",
				)) or flt(frappe.db.get_single_value("MBC Leave Settings", "leave_refund_divisor"))
				if divisor > 0 and flt(assignment.base) > 0:
					per_day = flt(assignment.base) / divisor
			if per_day > 0:
				self.encashment_amount = days * per_day
		if self.meta.has_field("karyo_encashment_rate_per_day"):
			self.karyo_encashment_rate_per_day = per_day


def _encashable_types():
	return {
		row.name: row
		for row in frappe.get_all(
			"Leave Type",
			filters={"allow_encashment": 1},
			fields=[
				"name", "earning_component", "non_encashable_leaves",
				"max_encashable_leaves", "karyo_mbc_leave_code",
			],
			limit_page_length=0,
		)
	}


def _is_encashment_admin():
	return frappe.session.user == "Administrator" or bool(
		ENCASHMENT_ADMIN_ROLES.intersection(frappe.get_roles())
	)


def _session_employee(required=False):
	"""Return the one active Employee linked to the signed-in user."""
	if frappe.session.user in (None, "", "Guest"):
		if required:
			frappe.throw(_("Please sign in to request leave encashment."), frappe.PermissionError)
		return None
	rows = frappe.get_all(
		"Employee", filters={"user_id": frappe.session.user, "status": "Active"},
		fields=["name", "employee_name", "department", "company"], limit_page_length=2,
	)
	if len(rows) > 1:
		frappe.throw(_("More than one active employee is linked to your account. Contact HR."))
	if required and not rows:
		frappe.throw(_("No active employee is linked to your account. Contact HR."))
	return rows[0] if rows else None


def _current_open_cycle(employee, company=None):
	"""Resolve the latest input-accepting cycle for the employee's payroll profile.

	The open payroll desk can legitimately still be processing an earlier period.
	Encashment therefore follows that open cycle instead of today's calendar date.
	"""
	if not employee:
		return None
	profile = frappe.db.get_value(
		"Employee", employee,
		["company", "karyo_payroll_type", "karyo_payroll_group"], as_dict=True,
	) or frappe._dict()
	company = company or profile.company
	if not company:
		return None
	rows = frappe.db.sql(
		"""
		select cycle.name, cycle.status, cycle.start_date, cycle.end_date,
			cycle.payment_date, cycle.pay_period_label, pay_day.payroll_type,
			pay_day.payroll_group
		from `tabPayroll Cycle` cycle
		inner join `tabPayroll Pay Day` pay_day on pay_day.name = cycle.pay_day
		where cycle.company = %(company)s and cycle.docstatus < 2
			and cycle.status in ('Draft', 'Input Open', 'Processing', 'Reopened')
		order by cycle.end_date desc, cycle.modified desc
		""",
		{"company": company}, as_dict=True,
	)
	if profile.karyo_payroll_type:
		rows = [row for row in rows if row.payroll_type == profile.karyo_payroll_type]
	if profile.karyo_payroll_group:
		exact = [row for row in rows if row.payroll_group == profile.karyo_payroll_group]
		rows = exact or [row for row in rows if not row.payroll_group]
	else:
		ungrouped = [row for row in rows if not row.payroll_group]
		if ungrouped:
			rows = ungrouped
	return rows[0] if rows else None


def _bind_employee_and_cycle(doc):
	"""Make employee identity and the receiving payroll cycle authoritative."""
	if not _is_encashment_admin():
		person = _session_employee(required=True)
		if doc.get("employee") and doc.employee != person.name:
			frappe.throw(_("You can request leave encashment only for your own employee code."), frappe.PermissionError)
		doc.employee = person.name
		doc.employee_name = person.employee_name
		doc.department = person.department
		doc.company = person.company
	if not doc.get("employee"):
		return None
	employee = frappe.db.get_value(
		"Employee", doc.employee, ["employee_name", "department", "company"], as_dict=True,
	) or frappe._dict()
	if employee.company:
		doc.company = employee.company
	cycle = _current_open_cycle(doc.employee, doc.get("company"))
	if not cycle:
		frappe.throw(_("No open Payroll Cycle matches employee {0}. Open the employee's cycle before saving this request.").format(doc.employee))
	doc.pay_via_payment_entry = 0
	if doc.meta.has_field("karyo_payroll_cycle"):
		doc.karyo_payroll_cycle = cycle.name
	# Native Additional Salary selection is date based. Keeping this date inside
	# the selected cycle guarantees the approved amount enters that exact run.
	if not doc.get("encashment_date") or not (
		getdate(cycle.start_date) <= getdate(doc.encashment_date) <= getdate(cycle.end_date)
	):
		doc.encashment_date = cycle.payment_date or cycle.end_date
	return cycle


@frappe.whitelist()
def encashment_defaults(employee=None):
	"""Defaults for the simple self-service form without exposing payroll masters."""
	if not _is_encashment_admin():
		person = _session_employee(required=True)
		employee = person.name
	elif not employee:
		person = _session_employee()
		employee = person.name if person else None
	if not employee:
		return {}
	person = frappe.db.get_value(
		"Employee", employee,
		["name", "employee_name", "department", "company"], as_dict=True,
	)
	if not person:
		return {}
	cycle = _current_open_cycle(employee, person.company)
	return {
		"employee": person.name,
		"employee_name": person.employee_name,
		"department": person.department,
		"company": person.company,
		"karyo_payroll_cycle": cycle.name if cycle else None,
		"payroll_cycle_label": cycle.pay_period_label if cycle else None,
		"payroll_cycle_status": cycle.status if cycle else None,
		"encashment_date": (cycle.payment_date or cycle.end_date) if cycle else None,
		"available_balances": encashable_balances(person.name),
	}


def encashable_balances(employee=None, permission_aware=False):
	"""Return balances that the native Leave Encashment form can consume."""
	from karyo.hr.self_service import leave_balances

	types = _encashable_types()
	if not types:
		return []
	filters = {
		"docstatus": 1,
		"from_date": ("<=", nowdate()),
		"to_date": (">=", nowdate()),
		"leave_type": ("in", list(types)),
	}
	if employee:
		filters["employee"] = employee
	getter = frappe.get_list if permission_aware else frappe.get_all
	allocations = getter(
		"Leave Allocation", filters=filters,
		fields=[
			"name", "employee", "employee_name", "leave_type", "leave_period",
			"from_date", "to_date",
		],
		limit_page_length=0,
	)
	by_employee = {}
	for allocation in allocations:
		by_employee.setdefault(allocation.employee, []).append(allocation)
	rows = []
	for employee_name, employee_allocations in by_employee.items():
		balances = {row["leave_type"]: row for row in leave_balances(employee_name)}
		seen = set()
		for allocation in employee_allocations:
			if allocation.leave_type in seen:
				continue
			seen.add(allocation.leave_type)
			balance = balances.get(allocation.leave_type)
			if not balance:
				continue
			settings = types[allocation.leave_type]
			confirmed = max(0, flt(balance.get("confirmed_remaining")))
			available = max(0, confirmed - flt(settings.non_encashable_leaves))
			if flt(settings.max_encashable_leaves) > 0:
				available = min(available, flt(settings.max_encashable_leaves))
			# Leave is requested and encashed only in full/half-day units.
			available = round(available * 2) / 2
			rows.append({
				"employee": employee_name,
				"employee_name": allocation.employee_name,
				"leave_type": allocation.leave_type,
				"leave_code": settings.karyo_mbc_leave_code,
				"leave_allocation": allocation.name,
				"leave_period": allocation.leave_period,
				"balance": confirmed,
				"protected_days": max(0, confirmed - available),
				"available_days": available,
				"earning_component": settings.earning_component,
				"from_date": allocation.from_date,
				"to_date": allocation.to_date,
			})
	return rows


def encashment_summary(employee=None, permission_aware=False):
	rows = encashable_balances(employee, permission_aware=permission_aware)
	filters = {"employee": employee} if employee else {}
	history_getter = frappe.get_list if permission_aware else frappe.get_all
	history = history_getter(
		"Leave Encashment", filters=filters,
		fields=[
			"name", "employee", "employee_name", "leave_type", "karyo_leave_code",
			"encashment_date", "encashment_days", "encashment_amount", "currency",
			"status", "docstatus", "additional_salary", "karyo_earning_component",
			"karyo_payroll_cycle",
		],
		order_by="encashment_date desc, modified desc", limit_page_length=100,
	)
	year_start = getdate(f"{getdate(nowdate()).year}-01-01")
	approved = [row for row in history if row.docstatus == 1 and getdate(row.encashment_date) >= year_start]
	return {
		"available_days": round(sum(flt(row["available_days"]) for row in rows) * 2) / 2,
		"available_balances": rows,
		"encashed_days_this_year": round(sum(flt(row.encashment_days) for row in approved) * 2) / 2,
		"encashed_amount_this_year": sum(flt(row.encashment_amount) for row in approved),
		"history": history,
	}


def available_encashment_stat():
	if not frappe.has_permission("Leave Encashment", "read"):
		return None
	summary = encashment_summary(permission_aware=True)
	return {
		"value": summary["available_days"],
		"sub": _("days currently eligible"),
		"icon": "badge-dollar-sign",
		"icon_color": "green",
	}


def encashed_days_stat():
	if not frappe.has_permission("Leave Encashment", "read"):
		return None
	rows = frappe.get_list(
		"Leave Encashment",
		filters={
			"docstatus": 1,
			"encashment_date": (">=", f"{getdate(nowdate()).year}-01-01"),
		},
		fields=["sum(encashment_days) as days"],
	)
	return {
		"value": flt(rows[0].days) if rows else 0,
		"sub": _("approved this year"),
		"icon": "coins",
		"icon_color": "blue",
	}


def prepare_payroll_mapping(doc, method=None):
	"""Expose the earning rule before approval and reject incomplete mappings."""
	if doc.get("employee") or not _is_encashment_admin():
		_bind_employee_and_cycle(doc)
	if not doc.get("leave_type"):
		return
	component = frappe.db.get_value("Leave Type", doc.leave_type, "earning_component")
	if doc.meta.has_field("karyo_earning_component"):
		doc.karyo_earning_component = component
	if not component:
		frappe.throw(_("Select an Earning Component on Leave Type {0} before approval.").format(doc.leave_type))
	row = frappe.db.get_value("Salary Component", component, ["type", "disabled"], as_dict=True)
	if not row or row.type != "Earning" or row.disabled:
		frappe.throw(_("Leave encashment requires an active Earning Salary Component."))


def sync_payroll_mapping(doc, method=None):
	"""Link the approved encashment to its employee earning and payroll cycle."""
	if doc.docstatus != 1 or doc.get("pay_via_payment_entry"):
		return
	additional_salary = frappe.db.get_value(
		"Additional Salary",
		{"ref_doctype": "Leave Encashment", "ref_docname": doc.name, "docstatus": 1},
		["name", "employee", "salary_component", "karyo_payroll_cycle"],
		as_dict=True,
	)
	if not additional_salary:
		frappe.throw(_("Approved leave encashment did not create its employee earning."))
	component = frappe.db.get_value("Leave Type", doc.leave_type, "earning_component")
	if additional_salary.employee != doc.employee or additional_salary.salary_component != component:
		frappe.throw(_("The leave encashment earning is not mapped to the selected employee and Leave Type rule."))
	if doc.get("karyo_payroll_cycle") and additional_salary.karyo_payroll_cycle != doc.karyo_payroll_cycle:
		frappe.throw(_("The leave encashment earning was not mapped to its selected Payroll Cycle."))
	values = {"additional_salary": additional_salary.name}
	if doc.meta.has_field("karyo_earning_component"):
		values["karyo_earning_component"] = additional_salary.salary_component
	if doc.meta.has_field("karyo_payroll_cycle"):
		values["karyo_payroll_cycle"] = additional_salary.karyo_payroll_cycle
	doc.db_set(values, update_modified=False)


def backfill_payroll_mappings():
	updated = 0
	for name in frappe.get_all("Leave Encashment", filters={"docstatus": 1}, pluck="name"):
		doc = frappe.get_doc("Leave Encashment", name)
		sync_payroll_mapping(doc)
		updated += 1
	return updated
