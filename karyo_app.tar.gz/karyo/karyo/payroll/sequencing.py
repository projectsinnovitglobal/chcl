"""Major/minor eligibility, sequencing, deduplication, and reconciliation."""

import frappe
from frappe import _
from frappe.utils import now_datetime


ELIGIBLE_CLASSES = {"Minor": {"Once-off"}, "Major": {"Static", "Once-off"}}
ACTIVE_ALLOCATION_STATUSES = ("Reserved", "Paid", "Reconciled")


def validate_transaction_class(payroll_type, transaction_class):
	if transaction_class not in ELIGIBLE_CLASSES.get(payroll_type, set()):
		frappe.throw(
			_('{0} transactions are not eligible for {1} payroll.').format(
				transaction_class, payroll_type
			)
		)
	if payroll_type == "Minor" and not frappe.db.get_single_value(
		"Karyo Payroll Settings", "minor_once_off_enabled"
	):
		frappe.throw(_("Once-off transactions are disabled for Minor payroll."))


def major_sequence_requirement(cycle, employees=None):
	"""Read-only prerequisite shared by the processing page and execution guard."""
	if cycle.payroll_type != "Major" or not frappe.db.get_single_value(
		"Karyo Payroll Settings", "require_minor_before_major"
	):
		return None, None
	if cycle.minor_sequence_waived:
		return (None, None) if cycle.minor_waiver_reason else (
			_("A reason is required to waive the Minor payroll requirement."), None
		)
	minor = frappe.db.get_value(
		"Payroll Cycle",
		{"company": cycle.company, "pay_period_label": cycle.pay_period_label,
		 "payroll_type": "Minor", "docstatus": ("<", 2)},
		["name", "status"], as_dict=True,
	)
	if not minor:
		return _("Create and approve the Minor payroll for {0} before starting this Major payroll. Select the matching Minor Pay Day to continue.").format(cycle.pay_period_label), None
	if minor.status not in ("Approved", "Closed") and employees:
		approved = set(frappe.get_all('Payroll Cycle Employee', filters={
			'payroll_cycle':minor.name, 'employee':('in',employees),
			'employee_approved_on':('is','set')}, pluck='employee'))
		if set(employees).issubset(approved):
			return None, minor.name
	if minor.status not in ("Approved", "Closed"):
		return _("The Minor payroll for {0} is {1}. Complete and approve it before starting this Major payroll. Select the matching Minor Pay Day to continue.").format(cycle.pay_period_label, _(minor.status)), minor.name
	return None, minor.name


def validate_major_sequence(cycle, employees=None):
	reason, minor = major_sequence_requirement(cycle, employees if employees is not None else frappe.flags.payroll_processing_employees)
	if reason:
		frappe.throw(reason, title=_("Minor payroll approval required"))
	if minor:
		cycle.preceding_minor_cycle = minor
	return minor


def reserve_transaction(
	cycle_name, source_doctype, source_name, transaction_class, amount, employee=None
):
	cycle = frappe.get_doc("Payroll Cycle", cycle_name)
	validate_transaction_class(cycle.payroll_type, transaction_class)
	key = f"{source_doctype}::{source_name}"
	existing = frappe.db.get_value(
		"Payroll Transaction Allocation",
		{"source_key": key, "status": ("in", ACTIVE_ALLOCATION_STATUSES)},
		["name", "payroll_cycle", "payroll_type", "pay_period_label", "status"],
		as_dict=True,
	)
	if existing:
		if existing.payroll_cycle == cycle.name:
			return frappe.get_doc("Payroll Transaction Allocation", existing.name)
		if (
			cycle.payroll_type == "Major"
			and existing.payroll_type == "Minor"
			and existing.pay_period_label == cycle.pay_period_label
			and existing.status in ("Paid", "Reconciled")
		):
			return reconcile_minor_allocation(existing.name, cycle.name)
		frappe.throw(_("Transaction {0} is already allocated to cycle {1}.").format(key, existing.payroll_cycle))
	released = frappe.db.get_value(
		"Payroll Transaction Allocation", {"source_key": key, "status": "Released"}, "name"
	)
	if released:
		allocation = frappe.get_doc("Payroll Transaction Allocation", released)
		allocation.update(
			{
				"payroll_cycle": cycle.name,
				"company": cycle.company,
				"pay_period_label": cycle.pay_period_label,
				"payroll_type": cycle.payroll_type,
				"employee": employee,
				"transaction_class": transaction_class,
				"amount": amount,
				"status": "Reserved",
				"reconciled_in_major_cycle": None,
				"reconciled_on": None,
			}
		)
		return allocation.save(ignore_permissions=True)
	return frappe.get_doc(
		{
			"doctype": "Payroll Transaction Allocation",
			"payroll_cycle": cycle.name,
			"company": cycle.company,
			"pay_period_label": cycle.pay_period_label,
			"payroll_type": cycle.payroll_type,
			"source_doctype": source_doctype,
			"source_name": source_name,
			"source_key": key,
			"employee": employee,
			"transaction_class": transaction_class,
			"amount": amount,
			"status": "Reserved",
		}
	).insert(ignore_permissions=True)


def reconcile_minor_allocation(allocation_name, major_cycle_name):
	allocation = frappe.get_doc("Payroll Transaction Allocation", allocation_name)
	allocation.status = "Reconciled"
	allocation.reconciled_in_major_cycle = major_cycle_name
	allocation.reconciled_on = now_datetime()
	allocation.save(ignore_permissions=True)
	_refresh_reconciled_total(major_cycle_name)
	return allocation


def mark_cycle_allocations_paid(cycle_name):
	frappe.db.set_value(
		"Payroll Transaction Allocation",
		{"payroll_cycle": cycle_name, "status": "Reserved"},
		"status",
		"Paid",
		update_modified=False,
	)


def release_cycle_allocations(cycle_name):
	frappe.db.set_value(
		"Payroll Transaction Allocation",
		{"reconciled_in_major_cycle": cycle_name, "status": "Reconciled"},
		{"status": "Paid", "reconciled_in_major_cycle": None, "reconciled_on": None},
		update_modified=False,
	)
	frappe.db.set_value(
		"Payroll Transaction Allocation",
		{"payroll_cycle": cycle_name, "status": ("in", ACTIVE_ALLOCATION_STATUSES)},
		{"status": "Released", "reconciled_in_major_cycle": None, "reconciled_on": None},
		update_modified=False,
	)


def _refresh_reconciled_total(major_cycle_name):
	total = frappe.db.sql(
		"""select coalesce(sum(amount), 0)
		from `tabPayroll Transaction Allocation`
		where reconciled_in_major_cycle = %s and status = 'Reconciled'""",
		major_cycle_name,
	)[0][0]
	frappe.db.set_value(
		"Payroll Cycle", major_cycle_name, "minor_reconciled_total", total, update_modified=False
	)
