"""Settings masters and readiness corrections use the shared payroll editor."""
import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.desk.payroll_drawer import _native_actions, record_form, record_save, record_action
from karyo.desk.payroll_screens import screen_data
from karyo.payroll.screen_specs import ENTITIES, PAYROLL_SETTINGS_MASTERS


class TestPayrollMasterEditor(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('master_editor')
        self.notify = patch('frappe.publish_realtime'); self.notify.start()

    def tearDown(self):
        self.notify.stop()
        frappe.set_user('Administrator')
        frappe.db.rollback(save_point='master_editor')
        frappe.clear_document_cache('Payroll Settings', 'Payroll Settings')
        frappe.set_user(self.user)

    def test_all_settings_masters_have_usable_editor(self):
        for dt in PAYROLL_SETTINGS_MASTERS:
            with self.subTest(doctype=dt):
                screen = 'master-' + dt.lower().replace(' ', '-')
                rows = screen_data(screen, {})['list']['rows']
                form = record_form(screen, dt, rows[0]['name'] if rows else None, is_admin=True)
                fields = {f['fieldname'] for s in form['sections'] for f in s['fields']} | {t['fieldname'] for t in form['tables']}
                for df in frappe.get_meta(dt).fields:
                    legacy_account = df.fieldtype == 'Link' and df.options in {'Account', 'Bank Account'}
                    if df.reqd and not df.read_only and not df.hidden and not legacy_account:
                        self.assertIn(df.fieldname, fields)

    def test_singleton_edits_existing_record_and_cannot_delete(self):
        dt = 'Payroll Settings'; screen = 'master-payroll-settings'
        form = record_form(screen, dt)
        self.assertEqual(form['name'], dt)
        self.assertFalse(form['record_tools']['can_delete'])
        old = frappe.get_single(dt).email_salary_slip_to_employee
        record_save(screen, dt, {'email_salary_slip_to_employee': 0 if old else 1})
        self.assertEqual(frappe.get_single(dt).email_salary_slip_to_employee, 0 if old else 1)
        with self.assertRaises(frappe.ValidationError): record_action(screen, dt, dt, 'delete')

    def test_mapping_defaults_preserve_shared_salary_component(self):
        name = 'Mapping-' + uuid4().hex[:8]
        record_save('salarysetup', 'Salary Component', {'salary_component': name,
            'salary_component_abbr': name, 'type': 'Earning', 'depends_on_payment_days': 1, 'is_tax_applicable': 1})
        before = frappe.get_doc('Salary Component', name).as_dict()
        form = record_form('pdb', 'Payroll PDB Code', defaults={'salary_component': name})
        fields = {f['fieldname']: f.get('value') for s in form['sections'] for f in s['fields']}
        self.assertEqual((fields['prorata'], fields['taxable'], fields['pdb_type']), (1, 1, 'PAY'))
        values = {'pdb_code': name.upper(), 'description': name, 'salary_component': name,
            'pdb_type': 'PAY', 'effective_from': '2026-01-01', 'is_active': 1, 'prorata': 0, 'taxable': 0}
        with self.assertRaises(frappe.ValidationError): record_save('pdb', 'Payroll PDB Code', values)
        self.assertEqual(frappe.get_doc('Salary Component', name).as_dict(), before)
        # Keep the matching payroll attributes, then the mapping may be created.
        values.update(prorata=1, taxable=1)
        record_save('pdb', 'Payroll PDB Code', values)
        self.assertEqual(frappe.get_doc('Salary Component', name).as_dict(), before)

    def test_legacy_erp_account_controls_are_not_exposed(self):
        pdb = record_form('pdb', 'Payroll PDB Code', is_admin=True)
        pdb_fields = [field for section in pdb['sections'] for field in section['fields']]
        pdb_fields += pdb.get('admin', {}).get('fields', [])
        self.assertNotIn('default_account', {field['fieldname'] for field in pdb_fields})
        self.assertFalse(any(field.get('options') in ('Account', 'Bank Account') for field in pdb_fields))

        company = frappe.get_all('Company', pluck='name', limit_page_length=1)[0]
        company_form = record_form('company', 'Company', company, is_admin=True)
        company_fields = [field for section in company_form['sections'] for field in section['fields']]
        options = {field['fieldname']: field.get('options') for field in company_fields}
        self.assertEqual(options['karyo_payroll_bank'], 'Bank')
        self.assertEqual(options['karyo_payroll_bank_branch'], 'Payroll Bank Branch')
        self.assertFalse(any(option in {'Account', 'Bank Account'} for option in options.values()))

    def test_salary_scale_draft_has_clear_approval_action(self):
        draft = frappe._dict(doctype='Salary Scale', name='TEST-SCALE', docstatus=0)
        actions = _native_actions(ENTITIES['Salary Scale'], frappe.get_meta('Salary Scale'), draft)
        self.assertEqual(actions[0]['key'], 'submit')
        self.assertEqual(actions[0]['label'], 'Approve & Submit')
        self.assertIn('Employee Grade linkage', actions[0]['confirm'])

    def test_missing_component_account_is_resolved_internally(self):
        from karyo.payroll.component_accounts import ensure_component_account

        company = frappe.get_all('Company', pluck='name', limit_page_length=1)[0]
        name = 'Internal Account Mapping ' + uuid4().hex[:8]
        component = frappe.get_doc({
            'doctype': 'Salary Component', 'salary_component': name,
            'salary_component_abbr': ('IAM' + uuid4().hex[:5]).upper(), 'type': 'Earning',
        }).insert(ignore_permissions=True)
        account = ensure_component_account(component.name, company)
        self.assertTrue(account)
        self.assertEqual(frappe.db.get_value('Account', account, 'company'), company)
        self.assertEqual(
            frappe.db.get_value('Salary Component Account', {'parent': component.name, 'company': company}, 'account'),
            account,
        )

    def test_salary_setup_only_loads_the_selected_tab(self):
        data = screen_data('salarysetup', {'tab': 'assignments', 'start': 0})
        self.assertEqual(data['selected_tab'], 'assignments')
        self.assertEqual(data['title'], 'PDB Payroll Templates & Employee Mappings')
        self.assertIn('PDB Type and PDB Code', data['note'])
        loaded = [tab['key'] for tab in data['tabs'] if tab['loaded']]
        self.assertEqual(loaded, ['assignments'])
        self.assertTrue(all(not tab['rows'] for tab in data['tabs'] if not tab['loaded']))
        assignments = next(tab for tab in data['tabs'] if tab['key'] == 'assignments')
        self.assertFalse(assignments['can_create'])
        self.assertTrue(all(row.get('karyo_salary_appointment') for row in assignments['rows']))

    def test_salary_template_uses_pdb_type_and_code_fields(self):
        structure = frappe.db.get_value('Salary Structure', {'docstatus': 1}, 'name')
        self.assertTrue(structure)
        form = record_form('salarysetup', 'Salary Structure', structure, is_admin=True)
        payroll_tables = [table for table in form['tables'] if table['fieldname'] in ('earnings', 'deductions')]
        self.assertTrue(payroll_tables)
        for table in payroll_tables:
            fields = {field['fieldname'] for field in table['fields']}
            self.assertIn('pdb_type', fields)
            self.assertIn('pdb_code', fields)
            self.assertNotIn('salary_component', fields)
            self.assertTrue(all(row.get('pdb_type') and row.get('pdb_code') for row in table['rows']))

    def test_master_permission_boundary(self):
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError): record_form('master-payroll-settings', 'Payroll Settings')
        with self.assertRaises(frappe.PermissionError): record_save('master-payroll-settings', 'Payroll Settings', {})
