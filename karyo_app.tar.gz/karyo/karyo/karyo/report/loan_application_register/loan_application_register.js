frappe.query_reports["Loan Application Register"] = {
	filters: [
		{fieldname: "from_date", label: __("Applied From"), fieldtype: "Date"},
		{fieldname: "to_date", label: __("Applied To"), fieldtype: "Date"},
		{fieldname: "workflow_state", label: __("Application Status"), fieldtype: "Link", options: "Workflow State"},
		{fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type"},
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
		{fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department"},
		{fieldname: "location", label: __("Location / Branch"), fieldtype: "Link", options: "Branch"}
	]
};
