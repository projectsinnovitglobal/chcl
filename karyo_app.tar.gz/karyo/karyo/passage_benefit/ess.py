"""Employee Self-Service channel for Passage Benefit (G11; PB-APP-001/010).

Lets an employee view *their own* Passage Benefit balance/history and lodge a
travel claim from the portal. Every entry point resolves the employee from the
logged-in user — the client never supplies an employee id — so an employee can
only ever see or act on their own record. Submission runs the identical server
validation as the desk form (``PassageBenefitApplication.validate``), then hands
the request to HR at the ``Pending Approval`` workflow state; approval/processing
stays with HR/Finance exactly as before (PB-WKF-*).
"""

import frappe
from frappe import _
from frappe.utils import getdate, today

from karyo.passage_benefit import inquiry
from karyo.passage_benefit.eligibility import evaluate as evaluate_eligibility


def _current_employee(required=True):
	"""Return the Employee linked to the user; optionally allow an unlinked Desk user."""
	user = frappe.session.user
	if not user or user == "Guest":
		frappe.throw(_("Please log in to access your Passage Benefit."), frappe.PermissionError)
	employee = frappe.db.get_value("Employee", {"user_id": user, "status": "Active"}, "name")
	if not employee and required:
		frappe.throw(_("No active Employee record is linked to your user account."), frappe.PermissionError)
	return employee


def _pay_period(d):
	d = getdate(d)
	return f"{d.year:04d}-{d.month:02d}"


def _record_ess_transition(doc, state, remarks):
	"""Apply the scoped ESS transition while preserving the real actor in audit."""
	doc.workflow_state = state
	if state == "Rejected":
		doc.remarks = remarks
	# Withdrawal must remain possible if eligibility or the balance changed.
	if state == "Rejected":
		doc._validate_workflow_requirements()
	else:
		doc.run_method("validate")
	values = {"workflow_state": state}
	if state == "Rejected":
		values["remarks"] = remarks
	frappe.db.set_value(doc.doctype, doc.name, values)
	frappe.get_doc(
		{
			"doctype": "Comment",
			"comment_type": "Workflow",
			"reference_doctype": doc.doctype,
			"reference_name": doc.name,
			"content": remarks,
		}
	).insert(ignore_permissions=True)
	doc.reload()
	doc.notify_update()
	from karyo.hr.self_service import notify_employee_request
	notify_employee_request(doc)


def _own_balance(employee):
	"""Bank header + period rows for one employee, read permission-free.

	ESS binds ``employee`` to the logged-in user, so this is always the caller's own
	record; reading via get_all/db.get_value (rather than get_doc) keeps it working
	for portal users who have no desk read permission on the PB Bank."""
	if not frappe.db.exists("Passage Benefit Bank", employee):
		return None, []
	bank = frappe.db.get_value(
		"Passage Benefit Bank",
		employee,
		[
			"status",
			"opening_date",
			"opening_balance",
			"total_earned",
			"total_taken",
			"total_adjustments",
			"current_balance",
			"eligible_from_date",
		],
		as_dict=True,
	)
	periods = frappe.get_all(
		"Passage Benefit Bank Period",
		filters={"parent": employee, "parenttype": "Passage Benefit Bank"},
		fields=[
			"period",
			"status",
			"opening_date",
			"opening_amount",
			"earned",
			"taken",
			"adjustments",
			"current_balance",
			"closing_date",
			"closing_amount",
		],
		order_by="idx asc",
	)
	return bank, periods


@frappe.whitelist()
def get_my_summary():
	"""Balance, period records, computation log and own applications for the portal."""
	employee = _current_employee(required=False)
	if not employee:
		# My HR is also available to administrative Desk users. Opening the employee-
		# only PB page from there must render an empty state, not raise a permission
		# dialog that a live dashboard refresh can repeatedly reopen.
		return {
			"employee": None,
			"employee_name": None,
			"bank": None,
			"periods": [],
			"computation_log": [],
			"applications": [],
			"eligible": False,
			"eligibility_status": _("Not eligible"),
			"eligibility_reason": _("No active Employee record is linked to your user account."),
			"block_reason": _("No active Employee record is linked to your user account."),
			"eligibility_rules": [],
			"eligible_from_date": None,
			"vacation_leave_type": None,
			"vacation_balance": 0,
			"has_bank": False,
			"pending_redemption_amount": 0,
			"approved_redemption_amount": 0,
			"currency": None,
			"ledger": [],
		}
	bank, periods = _own_balance(employee)
	summary = {
		"employee": employee,
		"employee_name": frappe.db.get_value("Employee", employee, "employee_name"),
		"bank": bank,
		"periods": periods,
		"computation_log": frappe.get_all(
			"Passage Benefit Computation",
			filters={"employee": employee, "docstatus": 1},
			fields=["name", "from_date", "to_date", "pay_period", "eligible_days_total", "earned_amount"],
			order_by="from_date asc",
		),
	}
	summary["applications"] = frappe.get_all(
		"Passage Benefit Application",
		filters={"employee": employee},
		fields=[
			"name",
			"posting_date",
			"usage_item_name",
			"request_amount",
			"claimable_amount",
			"amount_taken",
			"workflow_state",
			"pay_period",
			"travel_agent",
			"processed_reference",
		],
		order_by="posting_date desc, creation desc",
		limit=50,
	)
	res = inquiry.pb_and_vacation_balance(employee)
	summary["eligible"] = res["eligible"]
	summary["eligibility_status"] = res["eligibility_status"]
	summary["eligibility_reason"] = res["eligibility_reason"]
	summary["block_reason"] = res["block_reason"]
	summary["eligibility_mode"] = res["eligibility_mode"]
	summary["eligibility_rules"] = res["eligibility_rules"]
	summary["eligible_from_date"] = res["eligible_from_date"]
	summary["vacation_leave_type"] = res["vacation_leave_type"]
	summary["vacation_balance"] = res["vacation_balance"]
	summary["has_bank"] = bool(summary["bank"])
	requests = frappe.get_all("Passage Benefit Application", filters={
		"employee": employee, "docstatus": ["<", 2],
		"workflow_state": ["in", ["Pending Approval", "Recommended", "Approved"]],
	}, fields=["workflow_state", "claimable_amount"])
	summary["pending_redemption_amount"] = sum(float(row.claimable_amount or 0) for row in requests if row.workflow_state != "Approved")
	summary["approved_redemption_amount"] = sum(float(row.claimable_amount or 0) for row in requests if row.workflow_state == "Approved")
	company = frappe.db.get_value("Employee", employee, "company")
	summary["currency"] = frappe.db.get_value("Company", company, "default_currency")
	summary["ledger"] = frappe.get_all("Passage Benefit Ledger Entry", filters={"employee":employee}, fields=["name","posting_date","entry_type","amount","balance_after","pay_period","reference_doctype","reference_name","remarks"], order_by="posting_date desc, creation desc", limit_page_length=100)
	return summary


@frappe.whitelist()
def list_usage_items():
	"""Active usage items effective today, for the ESS request form (PB-USG-001/003)."""
	on = getdate(today())
	items = frappe.get_all(
		"Passage Benefit Usage Item",
		filters={"is_active": 1},
		fields=[
			"name",
			"usage_item_name",
			"encash_rate",
			"min_balance_credit",
			"requires_document",
			"effective_from",
			"effective_to",
		],
		order_by="usage_item_name asc",
	)
	out = []
	for it in items:
		if not it.encash_rate or it.encash_rate <= 0 or it.encash_rate > 100:
			continue
		if it.effective_from and on < getdate(it.effective_from):
			continue
		if it.effective_to and on > getdate(it.effective_to):
			continue
		out.append(it)
	return out


def _application_doc(usage_item, request_amount=None, posting_date=None, travel_agent=None,
	processing_route="Payroll", supporting_document=None, passengers=None, trips=None):
	employee = _current_employee()
	posting_date = getdate(posting_date) if posting_date else getdate(today())
	if posting_date > getdate(today()):
		frappe.throw(_("Request Date cannot be in the future."))
	if processing_route not in ("Payroll", "Internal"):
		frappe.throw(_("Select a valid payment route."))
	passengers = frappe.parse_json(passengers) if isinstance(passengers, str) else (passengers or [])
	trips = frappe.parse_json(trips) if isinstance(trips, str) else (trips or [])

	doc = frappe.get_doc(
		{
			"doctype": "Passage Benefit Application",
			"employee": employee,
			"company": frappe.db.get_value("Employee", employee, "company"),
			"posting_date": posting_date,
			"pay_period": _pay_period(posting_date),
			"usage_item": usage_item,
			"request_amount": request_amount,
			"travel_agent": travel_agent,
			"processing_route": processing_route,
			"supporting_document": supporting_document,
			"workflow_state": "Draft",
		}
	)
	for p in passengers:
		doc.append("passengers", p)
	for t in trips:
		doc.append("trips", t)

	return doc


@frappe.whitelist()
def preview_application(usage_item, request_amount=None, posting_date=None, travel_agent=None,
	processing_route="Payroll", supporting_document=None, passengers=None, trips=None):
	"""Read-only preview through the same controller as redemption submission."""
	employee = _current_employee()
	on_date = getdate(posting_date) if posting_date else getdate(today())
	eligibility = evaluate_eligibility(employee, on_date)
	base = {
		"eligible": bool(eligibility.eligible),
		"eligibility_status": eligibility.eligibility_status,
		"eligibility_reason": eligibility.message,
		"eligibility_rules": eligibility.rules,
	}
	if not eligibility.eligible:
		return {"ready": False, "message": eligibility.message,
			"block_reason": eligibility.block_reason, "request_rules": [], **base}
	muted = frappe.flags.mute_messages
	frappe.flags.mute_messages = True
	try:
		doc = _application_doc(usage_item, request_amount, posting_date, travel_agent,
			processing_route, supporting_document, passengers, trips)
		doc.run_method("validate")
		requires_document = bool(frappe.db.get_value(
			"Passage Benefit Usage Item", usage_item, "requires_document"
		))
		document_ok = bool(
			not requires_document
			or supporting_document
			or any(row.document for row in (doc.trips or []))
		)
		request_rules = [
			{"code": "pb_bank", "label": _("Active PB Bank"), "eligible": True,
				"status": _("Eligible"), "reason": _("An active PB Bank with an open period is available."), "blocking": False},
			{"code": "usage_item", "label": _("Redemption option"), "eligible": True,
				"status": _("Eligible"), "reason": _("The redemption option and encash rate are active for the request date."), "blocking": False},
			{"code": "balance", "label": _("Available balance"), "eligible": True,
				"status": _("Eligible"), "reason": _("The claim satisfies the available and minimum-balance rules."), "blocking": False},
			{"code": "supporting_document", "label": _("Supporting document"), "eligible": document_ok,
				"status": _("Eligible") if document_ok else _("Not eligible"),
				"reason": _("The required supporting document is attached.") if document_ok else
					_("A supporting document is required for this redemption option."),
				"blocking": not document_ok},
		]
		if not document_ok:
			return {"ready": False,
				"message": _("A supporting document is required for this redemption option."),
				"block_reason": _("A supporting document is required for this redemption option."),
				"request_rules": request_rules, **base}
		return {"ready": True, "request_amount": doc.request_amount,
			"claimable_amount": doc.claimable_amount, "available_balance": doc.available_balance,
			"min_balance_credit": doc.min_balance_credit, "encash_rate": doc.encash_rate,
			"requires_document": requires_document, "block_reason": "",
			"request_rules": request_rules, **base}
	except frappe.ValidationError as exc:
		message = str(exc)
		return {"ready": False, "message": message, "block_reason": message,
			"request_rules": [{"code": "request_validation", "label": _("Redemption rules"),
				"eligible": False, "status": _("Not eligible"), "reason": message, "blocking": True}], **base}
	finally:
		frappe.flags.mute_messages = muted


@frappe.whitelist(methods=["POST"])
def submit_application(
	usage_item,
	request_amount=None,
	posting_date=None,
	travel_agent=None,
	processing_route="Payroll",
	supporting_document=None,
	passengers=None,
	trips=None,
	submit_for_approval=1,
):
	"""Create the logged-in employee's PB Application via the shared validation path.

	The employee is always the current user's Employee; ``employee`` is never taken
	from the caller. Runs the full desk ``validate`` (eligibility, claim compute,
	balance and minimum-balance checks, document requirement) and, unless asked to
	keep it as a draft, moves it to ``Pending Approval`` for HR (PB-APP-001/010)."""
	doc = _application_doc(usage_item, request_amount, posting_date, travel_agent,
		processing_route, supporting_document, passengers, trips)
	submit_for_approval = int(submit_for_approval)

	# Draft insert runs the same validation as the desk form (self-service employees
	# act on their own record only, so permissions are applied on their behalf).
	doc.insert(ignore_permissions=True)

	if submit_for_approval:
		# Advance to Pending Approval so HR picks it up. The controller validate()
		# re-runs (enforcing the document requirement PB-APP-004 now the request has
		# left Draft); the workflow transition itself is brokered on the authenticated
		# employee's behalf, since ESS employees don't hold the desk HR role that owns
		# the "Submit for Approval" transition.
		_record_ess_transition(doc, "Pending Approval", _("Submitted for approval through ESS."))

	return {
		"name": doc.name,
		"workflow_state": doc.workflow_state,
		"request_amount": doc.request_amount,
		"claimable_amount": doc.claimable_amount,
		"available_balance": doc.available_balance,
		"amount_taken": doc.amount_taken,
	}


@frappe.whitelist(methods=["POST"])
def withdraw_application(application):
	"""Let an employee withdraw their own still-pending request (PB-APP-010)."""
	employee = _current_employee()
	owner_emp = frappe.db.get_value("Passage Benefit Application", application, "employee")
	if owner_emp != employee:
		frappe.throw(_("You can only withdraw your own requests."), frappe.PermissionError)
	frappe.db.sql("SELECT name FROM `tabPassage Benefit Application` WHERE name=%s FOR UPDATE", application)
	state = frappe.db.get_value("Passage Benefit Application", application, "workflow_state")
	if state != "Pending Approval":
		frappe.throw(_("Only a pending request can be withdrawn."))
	doc = frappe.get_doc("Passage Benefit Application", application)
	_record_ess_transition(doc, "Rejected", _("Withdrawn by employee through ESS."))
	return {"name": doc.name, "workflow_state": doc.workflow_state}


@frappe.whitelist()
def get_application_details(application):
	"""Return the signed-in employee's redemption details and itinerary only."""
	employee = _current_employee()
	if frappe.db.get_value("Passage Benefit Application", application, "employee") != employee:
		frappe.throw(_("You can only view your own requests."), frappe.PermissionError)
	doc = frappe.get_doc("Passage Benefit Application", application)
	out = {field:doc.get(field) for field in ("name","posting_date","usage_item_name","request_amount","claimable_amount","amount_taken","workflow_state","pay_period","travel_agent","processing_route","processed_reference","supporting_document","remarks")}
	out["passengers"] = [{field:row.get(field) for field in ("passenger_name","relationship","date_of_birth","passport_no")} for row in doc.passengers]
	out["trips"] = [{field:row.get(field) for field in ("destination","ticket_amount","travel_date","return_date","document")} for row in doc.trips]
	return out
