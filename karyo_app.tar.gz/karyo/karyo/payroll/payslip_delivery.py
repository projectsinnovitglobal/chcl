"""Individual payslip delivery to the employee's saved address."""
import re
from html import escape

import frappe
from frappe import _
from frappe.utils import validate_email_address


def _delivery(name):
    from karyo.desk.payroll_management import _admin
    _admin()
    doc = frappe.get_doc('Salary Slip', name)
    doc.check_permission('read')
    if doc.docstatus == 2:
        frappe.throw(_('Cancelled payslips cannot be emailed.'))
    from karyo.payroll.payslip_status import require_paid
    require_paid(name)
    employee = frappe.get_doc('Employee', doc.employee)
    recipient = next((str(employee.get(field)).strip() for field in
        ('prefered_email', 'company_email', 'personal_email', 'user_id')
        if employee.get(field) and validate_email_address(str(employee.get(field)).strip()) == str(employee.get(field)).strip()), None)
    if not recipient:
        frappe.throw(_('Add a valid email address to this employee’s profile before emailing the payslip.'))
    from karyo.desk.employee_account import _email_ready
    if not _email_ready():
        frappe.throw(_('Configure an outgoing Email Account before emailing payslips.'))
    return doc, recipient


@frappe.whitelist()
def details(name):
    doc, recipient = _delivery(name)
    return {'name': doc.name, 'recipient': recipient, 'employee_name': doc.employee_name,
        'status': _('Draft') if doc.docstatus == 0 else _('Submitted')}


@frappe.whitelist(methods=['POST'])
def send(name, expected_recipient):
    from frappe.utils.pdf import get_pdf
    from karyo.desk.payroll_management import payslip_print_html
    doc, recipient = _delivery(name)
    if recipient != expected_recipient:
        frappe.throw(_('The employee’s email address has changed. Reopen Email Payslip to confirm the current address.'))
    settings = frappe.get_single('Payroll Settings')
    options = {}
    message = _('Your payslip is attached. You can also download it from your Employee Dashboard.')
    if doc.docstatus == 0:
        message += '<br>' + _('This is a draft payslip. Amounts may change before payroll is submitted.')
    if settings.encrypt_salary_slips_in_emails:
        from hrms.payroll.doctype.salary_slip.salary_slip import generate_password_for_pdf
        password = generate_password_for_pdf(settings.password_policy, doc.employee)
        if not password:
            frappe.throw(_('The payslip password policy did not produce a password. Update Payroll Settings.'))
        options['password'] = password
        message += '<br>' + _('PDF password format: {0}').format(escape(settings.password_policy or ''))
    pdf = get_pdf(payslip_print_html(name), options=options)
    subject = '{0}Payslip: {1} to {2}'.format('DRAFT — ' if doc.docstatus == 0 else '', doc.start_date, doc.end_date)
    frappe.sendmail(recipients=[recipient], sender=settings.sender_email or None,
        subject=subject, message=message,
        attachments=[{'fname': re.sub(r'[^A-Za-z0-9._-]', '-', doc.name) + '.pdf', 'fcontent': pdf}],
        reference_doctype='Salary Slip', reference_name=doc.name)
    return {'queued': True, 'recipient': recipient, 'message': _('Payslip queued for email to {0}.').format(recipient)}
