"""Employee defaults for loan eligibility appraisal."""
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	create_custom_fields({"Employee": [
		{"fieldname": "karyo_loan_eligibility_section", "fieldtype": "Section Break", "label": "Loan Eligibility", "insert_after": "karyo_prb_pb_status"},
		{"fieldname": "karyo_loan_payroll_period", "fieldtype": "Link", "label": "Payroll Period for Eligibility", "options": "Payroll Period", "insert_after": "karyo_loan_eligibility_section", "no_copy": 1,
		 "description": "Default payroll period for this employee’s loan applications. Approved or closed payroll results are required for eligibility appraisal."},
	]}, update=True)
