"""Import the contribution catalogue captured in the client Google Sheet."""

import json
from collections import OrderedDict
from decimal import Decimal
from pathlib import Path

import frappe


DATA_FILE = Path(__file__).resolve().parent.parent / "payroll" / "data" / "legacy_contribution_catalogue.json"
CONFIG_KEY = "MBC-LEGACY-CONTRIBUTIONS-2026"
CONFIG_VERSION = "SHEET-1"
EFFECTIVE_FROM = "2026-01-01"
SCHEME_VERSION = "SHEET-1"


def _load_catalogue():
	with DATA_FILE.open(encoding="utf-8") as handle:
		payload = json.load(handle)
	columns = payload["columns"]
	return payload, [dict(zip(columns, values, strict=True)) for values in payload["rows"]]


def _decimal(value):
	return Decimal(str(value or 0))


def _meaningful_basis(row, party):
	value = _decimal(row[f"{party}_value"])
	return row[f"{party}_basis"].strip().upper() if value else None


def _calculation_mode(rows):
	bases = {
		basis
		for row in rows
		for party in ("employee", "employer")
		if (basis := _meaningful_basis(row, party))
	}
	if not bases:
		bases = {row["employer_basis"].strip().upper() for row in rows}
	if not bases <= {"F", "P"}:
		frappe.throw(f"Unsupported contribution basis: {', '.join(sorted(bases))}")
	if len(bases) > 1:
		frappe.throw("A contribution cannot mix non-zero flat and percentage values.")
	return "Percentage" if "P" in bases else "Flat Amount"


def _group_schemes(rows):
	grouped = OrderedDict()
	for row in rows:
		code = row["contribution_code"].strip().upper()
		grouped.setdefault(code, []).append(row)
	return grouped


def _single_value(rows, fieldname):
	values = {_decimal(row[fieldname]) for row in rows}
	if len(values) != 1:
		frappe.throw(f"Contribution {rows[0]['contribution_code']} has inconsistent {fieldname} values.")
	return float(values.pop())


def _bands(rows):
	seen = set()
	result = []
	for row in sorted(rows, key=lambda item: _decimal(item["lower_salary"])):
		key = (
			_decimal(row["lower_salary"]),
			_decimal(row["upper_salary"]),
			_decimal(row["employee_value"]),
			_decimal(row["employer_value"]),
		)
		if key in seen:
			continue
		seen.add(key)
		result.append({
			"lower_salary": float(key[0]),
			"upper_salary": float(key[1]),
			"is_open_ended": 0,
			"employee_value": float(key[2]),
			"employer_value": float(key[3]),
		})
	return result


def _has_band_gaps(bands):
	for previous, current in zip(bands, bands[1:]):
		if _decimal(current["lower_salary"]) != _decimal(previous["upper_salary"]) + Decimal("0.01"):
			return True
	return False


def _default_company():
	return (
		frappe.db.get_single_value("Karyo Payroll Settings", "default_company")
		or frappe.db.get_single_value("Global Defaults", "default_company")
	)


def _ensure_configuration(payload, scheme_count):
	name = f"{CONFIG_KEY}-{CONFIG_VERSION}"
	if frappe.db.exists("Payroll Configuration Version", name):
		return name, False
	doc = frappe.get_doc({
		"doctype": "Payroll Configuration Version",
		"config_key": CONFIG_KEY,
		"configuration_type": "Contribution",
		"version": CONFIG_VERSION,
		"configuration_status": "Draft",
		"is_production_eligible": 0,
		"effective_from": EFFECTIVE_FROM,
		"source_reference": payload["source_url"],
		"configuration_json": json.dumps({
			"sheet": payload["sheet"],
			"header_row": payload["header_row"],
			"excluded_rows": payload["excluded_rows"],
			"source_rows": len(payload["rows"]),
			"unique_schemes": scheme_count,
			"effective_date_fallback": EFFECTIVE_FROM,
		}, sort_keys=True),
		"notes": (
			"Imported from the client contribution sheet. The documented SAMPLE row is excluded. "
			"All source contribution-group and effective-date cells were blank, so schemes are global "
			f"and use the legacy migration default {EFFECTIVE_FROM}."
		),
	})
	doc.insert(ignore_permissions=True)
	return doc.name, True


def _ensure_pdb_configuration(payload):
	legacy_name = "MBC-LEGACY-PDB-2026-SHEET-1"
	if frappe.db.exists("Payroll Configuration Version", legacy_name):
		return legacy_name
	name = "MBC-CONTRIBUTION-PDB-2026-SHEET-1"
	if frappe.db.exists("Payroll Configuration Version", name):
		return name
	return frappe.get_doc({
		"doctype": "Payroll Configuration Version",
		"config_key": "MBC-CONTRIBUTION-PDB-2026",
		"configuration_type": "PDB Catalogue",
		"version": "SHEET-1",
		"configuration_status": "Draft",
		"is_production_eligible": 0,
		"effective_from": EFFECTIVE_FROM,
		"source_reference": payload["source_url"],
		"configuration_json": json.dumps({"purpose": "Contribution employee deduction dependencies"}),
		"notes": "Created only for employee PDB dependencies missing from the legacy PDB catalogue.",
	}).insert(ignore_permissions=True).name


def _unique_component_abbr(code):
	base = frappe.scrub(code).replace("_", "").upper()[:10] or "CONT"
	abbr = base
	index = 1
	while frappe.db.exists("Salary Component", {"salary_component_abbr": abbr}):
		index += 1
		abbr = f"{base[:max(1, 10 - len(str(index)))]}{index}"[:10]
	return abbr


def _ensure_component(name, code, description):
	if frappe.db.exists("Salary Component", name):
		component = frappe.get_doc("Salary Component", name)
		if not component.disabled and component.type == "Deduction":
			return name, False
		name = f"{description} ({code} Employer)"[:140]
	doc = frappe.get_doc({
		"doctype": "Salary Component",
		"salary_component": name,
		"salary_component_abbr": _unique_component_abbr(f"ER-{code}"),
		"type": "Deduction",
		"description": f"Employer contribution for {description}",
		"depends_on_payment_days": 0,
		"disabled": 0,
	})
	company = _default_company()
	if company:
		doc.append("accounts", {"company": company})
	doc.insert(ignore_permissions=True)
	return doc.name, True


def _ensure_employee_pdb(row, payload):
	code = row["contribution_code"].strip().upper()
	if frappe.db.exists("Payroll PDB Code", code):
		pdb_type = frappe.db.get_value("Payroll PDB Code", code, "pdb_type")
		classification = frappe.db.get_value("Payroll PDB Type", pdb_type, "classification")
		if classification != "Deduction":
			frappe.throw(f"Employee contribution PDB {code} is not a deduction.")
		return code, False, False
	if not frappe.db.exists("Payroll PDB Type", "CONT"):
		frappe.throw("Contribution PDB Type CONT is missing.")
	component_name = f"{row['description']} (Employee)"[:140]
	component_created = False
	if not frappe.db.exists("Salary Component", component_name):
		doc = frappe.get_doc({
			"doctype": "Salary Component",
			"salary_component": component_name,
			"salary_component_abbr": _unique_component_abbr(f"EE-{code}"),
			"type": "Deduction",
			"description": f"Employee contribution for {row['description']}",
			"depends_on_payment_days": 0,
			"disabled": 0,
		})
		company = _default_company()
		if company:
			doc.append("accounts", {"company": company})
		doc.insert(ignore_permissions=True)
		component_created = True
	configuration = _ensure_pdb_configuration(payload)
	frappe.get_doc({
		"doctype": "Payroll PDB Code",
		"pdb_code": code,
		"pdb_type": "CONT",
		"description": row["description"],
		"short_description": row["description"][:40],
		"salary_component": component_name,
		"transaction_mode": "Both",
		"taxable": 0,
		"exempt": 0,
		"prorata": 0,
		"reducing_balance": 0,
		"is_active": 1,
		"effective_from": EFFECTIVE_FROM,
		"configuration_version": configuration,
		"source_reference": f"Contribution-Setup Sheet1 row {row['sheet_row']}",
	}).insert(ignore_permissions=True)
	return code, True, component_created


def import_legacy_contribution_catalogue(commit=True):
	"""Create only contribution schemes absent from Payroll > Contribution."""
	payload, rows = _load_catalogue()
	grouped = _group_schemes(rows)
	configuration, configuration_created = _ensure_configuration(payload, len(grouped))
	created_schemes = []
	skipped_schemes = []
	created_pdb_codes = []
	created_components = []

	for code, scheme_rows in grouped.items():
		if frappe.db.exists("Payroll Contribution Scheme", {"scheme_code": code}):
			skipped_schemes.append(code)
			continue
		first = scheme_rows[0]
		pdb_code, pdb_created, employee_component_created = _ensure_employee_pdb(first, payload)
		if pdb_created:
			created_pdb_codes.append(pdb_code)
		if employee_component_created:
			created_components.append(f"{first['description']} (Employee)"[:140])
		employer_component, component_created = _ensure_component(
			f"{first['description']} (Employer)"[:140], code, first["description"]
		)
		if component_created:
			created_components.append(employer_component)
		bands = _bands(scheme_rows)
		frappe.get_doc({
			"doctype": "Payroll Contribution Scheme",
			"scheme_code": code,
			"version": SCHEME_VERSION,
			"description": first["description"],
			"calculation_mode": _calculation_mode(scheme_rows),
			"basis_operation_code": "GSAL",
			"employee_pdb_code": pdb_code,
			"employer_salary_component": employer_component,
			"employee_ceiling": _single_value(scheme_rows, "employee_ceiling"),
			"employer_ceiling": _single_value(scheme_rows, "employer_ceiling"),
			"rounding_precision": int(_single_value(scheme_rows, "rounding_precision")),
			"rounding_method": "Round Half Up",
			"allow_band_gaps": int(_has_band_gaps(bands)),
			"is_active": 1,
			"effective_from": EFFECTIVE_FROM,
			"configuration_version": configuration,
			"source_reference": f"Contribution-Setup Sheet1 rows {', '.join(str(r['sheet_row']) for r in scheme_rows)}",
			"notes": (
				"Imported from the client Google Sheet. Source contribution group and effective date were blank; "
				f"the scheme is global and uses {EFFECTIVE_FROM}."
			),
			"bands": bands,
		}).insert(ignore_permissions=True)
		created_schemes.append(code)

	if commit:
		frappe.db.commit()
	return {
		"source_rows": len(rows),
		"unique_schemes": len(grouped),
		"configuration": configuration,
		"configuration_created": configuration_created,
		"schemes_created": len(created_schemes),
		"scheme_names": created_schemes,
		"schemes_skipped_existing": len(skipped_schemes),
		"skipped_scheme_names": skipped_schemes,
		"pdb_codes_created": len(created_pdb_codes),
		"pdb_code_names": created_pdb_codes,
		"salary_components_created": len(created_components),
	}
