frappe.pages["training-overview"].on_page_load = function (wrapper) {
	karyo.overview.render(wrapper, "training-overview", {
		title: __("Training"),
		subtitle: __("Programs, events, results and feedback"),
		actions: [
			{ label: __("New Training Event"), primary: true, onclick: () => frappe.new_doc("Training Event") },
			{ label: __("New Program"), onclick: () => frappe.new_doc("Training Program") },
		],
	});
};
