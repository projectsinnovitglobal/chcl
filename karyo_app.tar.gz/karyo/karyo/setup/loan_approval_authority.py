"""Effective-dated loan approval authority matrix and decision audit fields."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.karyo.doctype.loan_approval_authority.loan_approval_authority import workflow_role
from karyo.setup.foundation import f, make_doctype


def create_authority_doctype():
	make_doctype(
		"Loan Approval Authority",
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="LAA-.#####", default="LAA-.#####"),
			f("company", "Link", "Company", options="Company", in_list_view=1),
			f("loan_type", "Link", "Loan Type", options="Loan Type", in_list_view=1),
			f("approval_level", "Select", "Approval Level", options="Direct Approval\nCommittee Recommendation\nFinal Approval\nManaging Director", reqd=1, in_list_view=1),
			f("amount_from", "Currency", "Amount From", default="0", in_list_view=1),
			f("amount_to", "Currency", "Amount To (blank = unlimited)", in_list_view=1),
			f("authority_cb", "Column Break"),
			f("approver_role", "Link", "Approver Role", options="Role"),
			f("approver_user", "Link", "Named Approver", options="User"),
			f("allow_self_approval", "Check", "Allow Maker to Approve", default="0"),
			f("validity_sb", "Section Break", "Validity"),
			f("start_date", "Date", "Start Date", reqd=1),
			f("end_date", "Date", "End Date"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("governance_sb", "Section Break", "Configuration Governance"),
			f("configuration_status", "Select", "Configuration Status", options="Demo\nDraft\nValidated\nApproved\nActive\nSuperseded\nRetired", default="Demo", reqd=1),
			f("configuration_version", "Data", "Version", default="1.0"),
			f("is_production_eligible", "Check", "Approved for Production", default="0"),
			f("source_reference", "Data", "Source Reference"),
			f("approval_reference", "Data", "Approval Reference"),
			f("governance_cb", "Column Break"),
			f("approved_by", "Link", "Approved By", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
		],
	)


def add_loan_fields():
	create_custom_fields(
		{
			"Karyo Loan": [
				{"fieldname": "approval_authority", "fieldtype": "Link", "label": "Approval Authority Rule", "options": "Loan Approval Authority", "read_only": 1, "insert_after": "approval_route"},
				{"fieldname": "approval_authority_version", "fieldtype": "Data", "label": "Authority Version", "read_only": 1, "insert_after": "approval_authority"},
				{"fieldname": "approval_role", "fieldtype": "Link", "label": "Approval Role", "options": "Role", "read_only": 1, "insert_after": "approval_authority_version"},
				{"fieldname": "approval_delegated_from", "fieldtype": "Link", "label": "Approval Delegated From", "options": "User", "read_only": 1, "insert_after": "approval_role"},
			]
		},
		ignore_validate=True,
	)


def sync_named_approver_roles():
	for row in frappe.get_all(
		"Loan Approval Authority",
		filters={"is_active": 1, "approver_user": ["is", "set"]},
		fields=["approver_user", "approval_level"],
	):
		if row.approver_user == "Administrator":
			continue
		role = workflow_role(row.approval_level)
		user = frappe.get_doc("User", row.approver_user)
		if role not in frappe.get_roles(row.approver_user):
			user.add_roles(role)


def setup():
	print("Karyo Loan approval authority setup:")
	create_authority_doctype()
	add_loan_fields()
	sync_named_approver_roles()
	frappe.db.commit()
	print("Done.")
