"""Performance Management System (PMS) scoring engine (pure, testable).

PRB PMS BRD (PMS-*): officers are scored on weighted competencies (rating out of
a max, times a percentage weight); workmen on a points-out-of-max basis.
"""


def officer_score(components, max_rating=4, precision=2):
	"""Weighted competency score for officers (PMS-001).

	`components`: iterable of {"rating": r, "weight": w%}. Each contributes
	(rating / max_rating) x weight; the total is the overall percentage.
	"""
	total = 0.0
	for c in components:
		total += (float(c["rating"]) / max_rating) * float(c["weight"])
	return round(total, precision)


def component_score(rating, weight, max_rating=4, precision=2):
	"""Single competency contribution (rating/max) x weight."""
	return round((float(rating) / max_rating) * float(weight), precision)


def workman_score(points, max_points, precision=2):
	"""Points-out-of-max percentage for workmen (PMS-002)."""
	if not max_points:
		return 0.0
	return round(points / max_points * 100.0, precision)
