import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.desk.loan_management import applications, application_statuses
from karyo.karyo.report.loan_approval_outcomes.loan_approval_outcomes import _row

class TestLoanRulesAudit(unittest.TestCase):
 def setUp(self):
  self.user=frappe.session.user;frappe.set_user('Administrator');frappe.db.savepoint('loan_rules_audit');self.prefix='rules-'+uuid4().hex
 def tearDown(self):
  frappe.set_user('Administrator');frappe.db.rollback(save_point='loan_rules_audit');frappe.set_user(self.user)
 def loan(self,state,status='Draft',date='2026-01-01',docstatus=0):
  doc=frappe.get_doc({'doctype':'Karyo Loan','name':self.prefix+'-'+uuid4().hex,'workflow_state':state,'status':status,'date_applied':date,'docstatus':docstatus});doc.db_insert();return doc
 def test_status_filters_match_displayed_state_before_pagination(self):
  approved=self.loan('Approved',date='2026-01-01');draft=self.loan('Draft',date='2026-09-01')
  approved_rows=applications(search=self.prefix,status='Approved',limit=1)['rows']
  draft_rows=applications(search=self.prefix,status='Draft')['rows']
  self.assertEqual([r['name'] for r in approved_rows],[approved.name]);self.assertTrue(approved_rows[0]['agreement_available'])
  self.assertEqual([r['name'] for r in draft_rows],[draft.name]);self.assertFalse(draft_rows[0]['agreement_available'])
 def test_legacy_active_and_cancelled_statuses(self):
  active=self.loan(None,'Active');cancelled=self.loan('Approved',docstatus=2)
  self.assertEqual(applications(search=self.prefix,status='Active Loan')['rows'][0]['display_status'],'Active Loan')
  self.assertEqual([r['name'] for r in applications(search=self.prefix,status='Cancelled')['rows']],[cancelled.name])
  self.assertEqual(applications(search=self.prefix,status='Approved')['rows'],[])
 def test_all_document_workflow_states_available(self):
  expected={'Draft','Printed','Approval Pending','Approved','Rejected','Returned','Agreement Printed','Ready for Disbursement','Disbursed','Active Loan','Settled','Pending'}
  self.assertTrue(expected.issubset(set(application_statuses())))
 def test_print_generation_uses_a_copy_and_fails_if_template_missing(self):
  doc=self.loan('Printed');doc.appraisal_status='Pass';doc.get_doc_before_save=lambda:frappe._dict(workflow_state='Draft')
  with patch('frappe.get_print') as render:
   def mutate(*args,**kw):kw['doc'].flags.in_print=True;return 'generated'
   render.side_effect=mutate;doc._validate_committee();self.assertFalse(doc.flags.in_print)
   self.assertEqual(render.call_args.args[2],'MBC Loan Application Form')
  with patch('frappe.db.exists',return_value=False):
   with self.assertRaises(frappe.ValidationError):doc._validate_committee()
 def test_disbursement_cannot_predate_approval(self):
  doc=frappe.get_doc({'doctype':'Karyo Loan','workflow_state':'Disbursed','disbursement_date':'2026-06-01','loan_approved_on':'2026-06-02 12:00:00'})
  with self.assertRaisesRegex(frappe.ValidationError,'cannot precede'):doc._validate_disbursement()
 def test_rejection_report_preserves_rejection_reason(self):
  loan=frappe._dict(name='test',employee='test',workflow_state='Rejected',rejection_reason='Missing evidence',committee_remarks='Older committee remark')
  self.assertEqual(_row(loan,'Rejected','Administrator','2026-06-01',{}).remarks,'Missing evidence')
 def test_status_register_permissions(self):
  frappe.set_user('Guest')
  with self.assertRaises(frappe.PermissionError):applications()

 def test_configurable_insurance_unit_matches_schedule_and_recast(self):
  from karyo.loan.engine import compute_loan,generate_schedule,recast
  args=dict(insurance_rate=24,insurance_unit=20000)
  result=compute_loan(100000,12,6,**args);self.assertEqual(result['monthly_insurance'],10)
  rows=generate_schedule(100000,12,6,equal_interest_recovery=True,**args)
  self.assertEqual(sum(row['insurance'] for row in rows),result['total_insurance'])
  self.assertEqual(recast(100000,12,6,10000,0,**args)['monthly_insurance'],10)
  with self.assertRaises(ValueError):compute_loan(1000,12,6,insurance_unit=0)
 def test_resolved_insurance_clears_when_no_longer_applicable(self):
  doc=frappe.get_doc({'doctype':'Karyo Loan','workflow_state':'Draft','insurance_rate_rule':'old-rule','insurance_rate':24,'insurance_confirmed':1,'insurance_snapshot_hash':'old'})
  doc._clear_inapplicable_insurance();self.assertEqual(doc.insurance_rate,0);self.assertFalse(doc.insurance_confirmed);self.assertFalse(doc.insurance_snapshot_hash)
 def test_approved_insurance_unit_cannot_be_changed(self):
  doc=frappe.get_doc({'doctype':'Karyo Loan','workflow_state':'Approved','insurance_calculation_unit':20000})
  doc.get_doc_before_save=lambda:frappe._dict(insurance_calculation_unit=10000)
  with self.assertRaises(frappe.ValidationError):doc._validate_insurance_controls()
