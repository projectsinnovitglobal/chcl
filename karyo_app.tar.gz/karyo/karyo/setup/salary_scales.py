"""Idempotent native metadata integration for salary allocation."""
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.utils import cint


def apply():
    for slug in ['salary_increment_band', 'salary_scale_band', 'salary_scale_point', 'salary_scale', 'salary_job_family',
                 'salary_scale_step', 'salary_grade_scale_link', 'employee_salary_appointment']:
        frappe.reload_doc('karyo', 'doctype', slug)
    create_custom_fields({
        'Employee Grade': [
            {'fieldname':'karyo_salary_setup','fieldtype':'Section Break','label':'Salary Scale Linkage','insert_after':'default_base_pay'},
            # The document name is the Grade Code. Keep this compatibility
            # mirror for integrations, but do not show a second code input.
            {'fieldname':'karyo_grade_code','fieldtype':'Data','label':'Grade Code','read_only':1,'hidden':1,'insert_after':'karyo_salary_setup'},
            {'fieldname':'karyo_grade_description','fieldtype':'Data','label':'Grade Description','reqd':1,'insert_after':'karyo_grade_code','in_list_view':1},
            {'fieldname':'karyo_job_family','fieldtype':'Link','label':'Job Family','options':'Salary Job Family','insert_after':'karyo_grade_description'},
            {'fieldname':'karyo_employee_category','fieldtype':'Link','label':'Employee Category / Grade Group','options':'Employee Category','insert_after':'karyo_job_family','in_list_view':1,'in_standard_filter':1},
            {'fieldname':'karyo_is_active','fieldtype':'Check','label':'Active?','default':'1','insert_after':'karyo_employee_category','in_list_view':1,'in_standard_filter':1},
            {'fieldname':'karyo_remarks','fieldtype':'Small Text','label':'Remarks','insert_after':'karyo_is_active'},
            {'fieldname':'karyo_salary_scales','fieldtype':'Table','label':'Salary Scale','options':'Salary Grade Scale Link','insert_after':'karyo_remarks','reqd':1,'description':'Select an approved salary scale. The description and validity dates are mapped automatically when the grade is saved.'},
        ],
        'Employee': [
            {'fieldname':'karyo_grade_description','fieldtype':'Data','label':'Grade Description','read_only':1,'fetch_from':'grade.karyo_grade_description','insert_after':'grade'},
            {'fieldname':'karyo_job_family','fieldtype':'Link','label':'Job Family','options':'Salary Job Family','read_only':1,'fetch_from':'grade.karyo_job_family','insert_after':'karyo_grade_description'},
            {'fieldname':'karyo_salary_appointment','fieldtype':'Link','label':'Current Salary Appointment','options':'Employee Salary Appointment','read_only':1,'insert_after':'karyo_prb_salary_point'},
            {'fieldname':'karyo_salary_scale','fieldtype':'Link','label':'Current Salary Scale','options':'Salary Scale','read_only':1,'insert_after':'karyo_salary_appointment'},
            {'fieldname':'karyo_scale_salary_point','fieldtype':'Int','label':'Scale Salary Point','read_only':1,'insert_after':'karyo_salary_scale'},
            {'fieldname':'karyo_scale_basic_salary','fieldtype':'Currency','label':'Scale Basic Salary','read_only':1,'insert_after':'karyo_scale_salary_point'},
            {'fieldname':'karyo_salary_effective_from','fieldtype':'Date','label':'Salary Effective From','read_only':1,'insert_after':'karyo_scale_basic_salary'},
        ],
        'PRB Payroll Run': [
            {'fieldname':'karyo_salary_appointment','fieldtype':'Link','label':'Approved Salary Appointment','options':'Employee Salary Appointment','read_only':1,'insert_after':'basic_salary','no_copy':1},
        ],
        'Salary Slip': [
            {'fieldname':'karyo_salary_appointment','fieldtype':'Link','label':'Approved Salary Appointment','options':'Employee Salary Appointment','read_only':1,'insert_after':'salary_structure','no_copy':1},
            {'fieldname':'karyo_salary_scale','fieldtype':'Link','label':'Salary Scale Code','options':'Salary Scale','read_only':1,'insert_after':'karyo_salary_appointment','no_copy':1},
            {'fieldname':'karyo_salary_point','fieldtype':'Int','label':'Salary Point','read_only':1,'insert_after':'karyo_salary_scale','no_copy':1},
            {'fieldname':'karyo_salary_base','fieldtype':'Currency','label':'Cost to Company (CTC)','options':'currency','read_only':1,'insert_after':'karyo_salary_point','no_copy':1},
            {'fieldname':'karyo_basic_pay','fieldtype':'Currency','label':'Basic Pay','options':'currency','read_only':1,'insert_after':'karyo_salary_base','no_copy':1},
            {'fieldname':'karyo_leave_days','fieldtype':'Float','label':'Leave Days','read_only':1,'insert_after':'leave_without_pay','no_copy':1},
            {'fieldname':'karyo_present_days','fieldtype':'Float','label':'Present Days','read_only':1,'insert_after':'karyo_leave_days','no_copy':1},
            {'fieldname':'karyo_attendance_summary','fieldtype':'Code','label':'Attendance / Leave Sync Trace','options':'JSON','read_only':1,'hidden':1,'insert_after':'karyo_present_days','no_copy':1},
        ],
        'Salary Structure Assignment': [
            {'fieldname':'karyo_salary_appointment','fieldtype':'Link','label':'Salary Appointment','options':'Employee Salary Appointment','read_only':1,'allow_on_submit':1,'insert_after':'salary_structure','no_copy':1},
            {'fieldname':'karyo_salary_scale','fieldtype':'Link','label':'Salary Scale Code','options':'Salary Scale','read_only':1,'allow_on_submit':1,'insert_after':'karyo_salary_appointment','no_copy':1},
            {'fieldname':'karyo_salary_point','fieldtype':'Int','label':'Salary Point','read_only':1,'allow_on_submit':1,'insert_after':'karyo_salary_scale','no_copy':1},
        ],
    }, update=True)
    for grade in frappe.get_all(
        'Employee Grade', fields=['name', 'karyo_grade_description', 'karyo_is_active']
    ):
        frappe.db.set_value('Employee Grade', grade.name, {
            'karyo_grade_code': grade.name,
            'karyo_grade_description': grade.karyo_grade_description or grade.name,
            # Custom Check columns can be NULL on records created before the
            # field existed. Existing grades remain usable after migration.
            'karyo_is_active': 1 if grade.karyo_is_active is None else grade.karyo_is_active,
        }, update_modified=False)

    make_property_setter('Employee Grade', 'karyo_grade_code', 'hidden', 1, 'Check')

    ensure_pay_adjustment_component()

    ensure_increment_band_masters()

    # Keep the dependent step master complete for scales created before this
    # master existed, then translate legacy integer selections to Link values.
    from karyo.payroll.salary_scales import sync_scale_steps
    for scale_name in frappe.get_all('Salary Scale', pluck='name'):
        scale = frappe.get_doc('Salary Scale', scale_name)
        if scale.points:
            sync_scale_steps(scale)
    for row in frappe.get_all(
        'Employee Recurring PDB',
        filters={'salary_step': ('is', 'set')},
        fields=['name', 'salary_scale', 'salary_step'],
    ):
        if not row.salary_scale and not cint(row.salary_step):
            frappe.db.set_value('Employee Recurring PDB', row.name, 'salary_step', None, update_modified=False)
            continue
        if row.salary_scale and not frappe.db.exists('Salary Scale Step', row.salary_step):
            step_name = f'{row.salary_scale}-{cint(row.salary_step)}'
            if cint(row.salary_step) and frappe.db.exists('Salary Scale Step', step_name):
                frappe.db.set_value('Employee Recurring PDB', row.name, 'salary_step', step_name, update_modified=False)
    for fieldname in ('karyo_salary_allocation_tab', 'karyo_salary_summary'):
        name = frappe.db.get_value('Custom Field', {'dt': 'Employee', 'fieldname': fieldname}, 'name')
        if name:
            frappe.delete_doc('Custom Field', name, ignore_permissions=True)
    from karyo.payroll.employee_salary_workspace import install
    install()
    from karyo.payroll.payslip_sync import backfill_salary_slip_fields
    backfill_salary_slip_fields()
    from karyo.setup.employee_numbering import apply as apply_employee_numbering
    apply_employee_numbering()
    frappe.clear_cache()


def ensure_pay_adjustment_component():
    """Non-taxable earning used only to prevent EMI recovery creating negative pay."""
    name = 'Pay Adjustment'
    values = {
        'salary_component': name,
        'salary_component_abbr': 'PAYADJ',
        'type': 'Earning',
        'is_tax_applicable': 0,
        'depends_on_payment_days': 0,
        'do_not_include_in_total': 0,
        'disabled': 0,
    }
    if frappe.db.exists('Salary Component', name):
        component = frappe.get_doc('Salary Component', name)
        component.update(values)
    else:
        component = frappe.get_doc({'doctype': 'Salary Component', **values})

    # It is a genuine earning and therefore participates in the Payroll Entry
    # accrual.  Reuse each company's Basic salary expense mapping so submission
    # cannot fail after the adjustment has already balanced the Salary Slip.
    mapped_companies = {row.company for row in component.get('accounts') or []}
    for row in frappe.get_all(
        'Salary Component Account',
        filters={'parent': 'Basic', 'parenttype': 'Salary Component'},
        fields=['company', 'account'],
        limit_page_length=0,
    ):
        if row.company and row.account and row.company not in mapped_companies:
            component.append('accounts', {'company': row.company, 'account': row.account})
            mapped_companies.add(row.company)
    if component.is_new():
        component.insert(ignore_permissions=True)
    else:
        component.save(ignore_permissions=True)


def ensure_increment_band_masters():
    """Give legacy scale rows reusable band masters without rewriting scale history."""
    for scale_name in frappe.get_all('Salary Scale', pluck='name'):
        scale = frappe.get_doc('Salary Scale', scale_name)
        for sequence, row in enumerate(scale.bands or [], 1):
            if row.increment_band and frappe.db.exists('Salary Increment Band', row.increment_band):
                continue
            code = f'{scale.name}-BAND-{sequence:02d}'[:140]
            if not frappe.db.exists('Salary Increment Band', code):
                frappe.get_doc({
                    'doctype': 'Salary Increment Band',
                    'band_code': code,
                    'description': f'{scale.name} breakpoint {sequence}',
                    'salary_breakpoint': row.salary,
                    'increment_amount': row.increment or 0,
                    'currency': scale.currency,
                    'effective_from': scale.valid_from,
                    'effective_to': scale.valid_to,
                }).insert(ignore_permissions=True)
            frappe.db.set_value('Salary Scale Band', row.name, {
                'increment_band': code,
                'band_description': frappe.db.get_value('Salary Increment Band', code, 'description'),
            }, update_modified=False)


def setup():
    apply()
