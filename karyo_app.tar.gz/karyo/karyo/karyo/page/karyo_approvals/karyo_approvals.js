// Approvals — unified pending-actions queue across the Karyo workflows
// (PB-WKF-001..003 visibility + LMS committee/approval pipeline §5.4).
// Content is permission-filtered server-side; approvers act on the form.

frappe.pages["karyo-approvals"].on_page_load = function (wrapper) {
	const $body = karyo.pages.scaffold(wrapper, {
		title: __("Approvals"),
		subtitle: __("Everything waiting for a decision, oldest first"),
		actions: [],
	});

	const render = (r) => {
			const d = r.message || {};
			$body.empty();
			const s = d.summary || {};
			const groups = d.groups || [];
			const total = s.total ?? groups.reduce((sum, group) => sum + (group.items || []).length, 0);
			const find_section = (doctype) =>
				$body.find(".karyo-approval-table-card").filter((_, element) => element.dataset.approvalDoctype === doctype).first();
			const reveal = (doctype = null) => {
				const $target = doctype ? find_section(doctype) : $body.find(".karyo-approval-tables").first();
				if ($target.length) return $target.get(0).scrollIntoView({ behavior: "smooth", block: "start" });
				if (doctype) frappe.set_route(frappe.router.slug(doctype));
			};
			const decide_additional_hours = async (item, decision, reason = null) => {
				try {
					const result = await frappe.xcall("karyo.payroll.overtime_process.decide", {
						names: JSON.stringify([item.name]),
						decision,
						reason,
					});
					frappe.show_alert({ message: result.message, indicator: decision === "Approved" ? "green" : "orange" });
					load();
				} catch (error) {
					console.error(error);
				}
			};
			const decide_leave = async (item, decision, reason = null) => {
				try {
					const result = await frappe.call({
						method: "karyo.hr.leave_controls.decide_leave_application",
						type: "POST",
						args: {name: item.name, decision, reason},
					});
					frappe.show_alert({message: result.message.message, indicator: decision === "Approved" ? "green" : "orange"});
					load();
				} catch (error) {
					console.error(error);
				}
			};
			const oldest = groups
				.flatMap((group) => group.items || [])
				.map((item) => ({ item, days: Number((item.description || "").match(/\d+/)?.[0] || 0) }))
				.sort((left, right) => right.days - left.days)[0]?.item;
			karyo.pages.stats($body, [
				{ label: __("Awaiting action"), value: total, onclick: () => reveal() },
				{
					label: __("Passage benefit claims"),
					value: s.pb_count ?? (d.pb || []).length,
					onclick: () => reveal("Passage Benefit Application"),
				},
				{
					label: __("Loan applications"),
					value: s.loan_count ?? (d.loans || []).length,
					onclick: () => reveal("Karyo Loan"),
				},
				{
					label: __("Oldest item"),
					value: s.oldest_days || 0,
					sub: __("days waiting"),
					onclick: () => oldest?.route
						? frappe.set_route(...oldest.route.replace(/^\/app\//, "").split("/"))
						: reveal(),
				},
			]);

			if (total) {
				const $charts = karyo.pages.grid($body, 1);
				karyo.pages.chart_card($charts, {
					title: __("Pending items by age"),
					type: "bar",
					height: 200,
					data: d.aging,
					colors: ["#0b6cfb", "#f6821f"],
				});
			}

			const $tables = $('<div class="karyo-approval-tables"></div>').appendTo($body);
			if (!groups.length) {
				karyo.pages.empty_state($tables, { title: __("All clear — nothing needs your approval") });
				return;
			}
			groups.forEach((group) => {
				const items = group.items || [];
				const $section = $('<section class="karyo-approval-table-card"></section>')
					.attr("data-approval-doctype", group.doctype || "")
					.appendTo($tables);
				karyo.pages.section_head($section, {
					title: group.title,
					count: items.length,
					action: group.doctype
						? { label: __("View all"), route: frappe.router.slug(group.doctype) }
						: null,
				});
				const $wrap = $('<div class="karyo-approval-table-wrap"></div>').appendTo($section);
				const $table = $('<table class="karyo-approval-table"><thead><tr></tr></thead><tbody></tbody></table>').appendTo($wrap);
				[__("Employee name"), __("Employee ID"), __("Request"), __("Waiting"), __("Status"), __("Amount"), __("Action")]
					.forEach((label) => $("<th scope=\"col\"></th>").text(label).appendTo($table.find("thead tr")));
				items.forEach((item) => {
					const $row = $("<tr></tr>").appendTo($table.find("tbody"));
					$("<td></td>").append($("<strong></strong>").text(item.employee_name || item.label || item.name || "—")).appendTo($row);
					$("<td></td>").text(item.employee || "—").appendTo($row);
					$("<td></td>").text(item.request || item.label || item.name || "—").appendTo($row);
					$("<td></td>").text(item.description || "—").appendTo($row);
					$("<td></td>").append(karyo.pages.pill(item.pill || __("Pending"), item.pill_color)).appendTo($row);
					const amount = item.amount == null
						? "—"
						: item.amount_type === "number"
							? format_number(flt(item.amount), null, Number.isInteger(flt(item.amount)) ? 0 : 2)
							: format_currency(item.amount || 0);
					$("<td class=\"text-right\"></td>").text(amount).appendTo($row);
					const $action = $("<td class=\"karyo-approval-action\"></td>").appendTo($row);
					$("<button type=\"button\" class=\"btn btn-xs btn-default\"></button>")
						.text(__("Review"))
						.on("click", () => frappe.set_route((item.route || "").replace(/^\/app\//, "")))
						.appendTo($action);
					if (item.decision_type === "additional_hours" && item.can_decide) {
						$("<button type=\"button\" class=\"btn btn-xs btn-primary\"></button>")
							.text(__("Approve"))
							.on("click", () => frappe.confirm(
								__("Approve {0} for payroll?", [item.label || item.name]),
								() => decide_additional_hours(item, "Approved")
							))
							.appendTo($action);
						$("<button type=\"button\" class=\"btn btn-xs btn-danger\"></button>")
							.text(__("Reject"))
							.on("click", () => frappe.prompt(
								[{ fieldname: "reason", fieldtype: "Small Text", label: __("Reason"), reqd: 1 }],
								(values) => decide_additional_hours(item, "Rejected", values.reason),
								__("Reject additional hours")
							))
							.appendTo($action);
					}
					if (item.decision_type === "leave" && item.can_decide) {
						$("<button type=\"button\" class=\"btn btn-xs btn-primary\"></button>")
							.text(__("Approve"))
							.on("click", () => frappe.confirm(
								__("Approve and lock leave request {0}?", [item.name]),
								() => decide_leave(item, "Approved")
							))
							.appendTo($action);
						$("<button type=\"button\" class=\"btn btn-xs btn-danger\"></button>")
							.text(__("Reject"))
							.on("click", () => frappe.prompt(
								[{fieldname: "reason", fieldtype: "Small Text", label: __("Rejection reason"), reqd: 1}],
								(values) => decide_leave(item, "Rejected", values.reason),
								__("Reject leave request"), __("Reject")
							))
							.appendTo($action);
					}
				});
			});
	};
	const load = () => karyo.live.request(wrapper, {
		method: "karyo.desk.overview.approvals",
		callback: render,
	});
	load();
};
