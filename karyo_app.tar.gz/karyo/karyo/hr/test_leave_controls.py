from unittest.mock import Mock, patch
from uuid import uuid4

import frappe
from frappe.tests.utils import FrappeTestCase
from frappe.utils import add_days, nowdate

from karyo.hr.leave_controls import (
	_is_employee_eligible,
	_employee_ineligibility_reason,
	_payroll_cycle_for_employee,
	_prorated_entitlement,
	activate_leave_allocation,
	decide_leave_application,
	eligible_leave_type_query,
	get_leave_type_details,
	leave_type_catalogue_query,
	sync_leave_type_payroll_rules,
	validate_leave_lifecycle,
	validate_closed_period_cancellation,
	validate_leave_correction,
	validate_mbc_leave_rules,
)
from karyo.payroll.source_trace import assign_payroll_cycle
from karyo.setup.leave import (
	LEAVE_TYPE_MATRIX,
	bind_leave_type_metadata,
	configure_encashment_integration,
	configure_lwp_integration_flags,
)


class TestLeaveControls(FrappeTestCase):
	@patch("karyo.hr.leave_controls.frappe.get_doc")
	def test_admin_activation_submits_leave_allocation(self, get_doc):
		doc = frappe._dict(name="ALLOC-1", docstatus=0, flags=frappe._dict())
		doc.check_permission = Mock()
		def submit():
			doc.docstatus = 1
		doc.submit = submit
		get_doc.return_value = doc
		frappe.set_user("Administrator")
		result = activate_leave_allocation("ALLOC-1")
		self.assertEqual(result["docstatus"], 1)
		doc.check_permission.assert_called_once_with("read")

	def test_admin_created_leave_is_approved_and_submitted(self):
		employee = frappe.db.get_value("Employee", {"status": "Active"}, "name")
		if not employee:
			self.skipTest("No active Employee fixture")
		suffix = uuid4().hex[:8]
		leave_type = frappe.get_doc({
			"doctype": "Leave Type", "leave_type_name": f"Admin submit {suffix}",
			"karyo_mbc_leave_code": f"ADM{suffix}",
			"karyo_code_description": "Admin-created submitted leave test",
			"is_lwp": 1, "include_holiday": 1,
		}).insert()
		day = add_days(nowdate(), 400)
		doc = frappe.get_doc({
			"doctype": "Leave Application", "employee": employee,
			"leave_type": leave_type.name, "from_date": day, "to_date": day,
			"leave_approver": "Administrator", "status": "Open",
			"description": "Entered by HR and submitted immediately",
		}).insert()
		result = decide_leave_application(doc.name, "Approved")
		doc.reload()
		self.assertEqual((result["status"], result["docstatus"]), ("Approved", 1))
		self.assertEqual((doc.status, doc.docstatus), ("Approved", 1))

	def test_complete_leave_catalogue_keeps_ineligible_types_selectable(self):
		rows = leave_type_catalogue_query("Leave Type", "Casual", "name", 0, 1000, {})
		self.assertIn("Casual Leave", {row[0] for row in rows})

	def test_service_rule_returns_displayable_ineligibility_reason(self):
		employee = frappe._dict(
			status="Active", date_of_joining="2026-08-01", karyo_date_joined_service=None,
			karyo_employment_category="PERM", gender="Male", contract_end_date=None,
		)
		rules = frappe._dict(
			karyo_min_service_months=12, karyo_eligible_employment_categories="PERM",
			karyo_eligible_gender="", karyo_requires_valid_contract=0,
		)
		self.assertIn("12 month", _employee_ineligibility_reason(employee, rules, "2026-09-25"))

	def test_decided_leave_is_locked_against_further_edits(self):
		doc = Mock()
		doc.is_new.return_value = False
		doc.flags = frappe._dict()
		doc.get_doc_before_save.return_value = frappe._dict(status="Approved")
		with self.assertRaisesRegex(frappe.ValidationError, "locked"):
			validate_leave_lifecycle(doc)

	@patch("karyo.hr.leave_controls.frappe.get_doc")
	def test_admin_decision_saves_and_submits_atomically(self, get_doc):
		doc = Mock()
		doc.name = "LEAVE-1"
		doc.docstatus = 0
		doc.status = "Open"
		doc.employee = None
		doc.from_date = None
		doc.to_date = None
		doc.flags = frappe._dict()
		doc.get.side_effect = lambda key: {"leave_approver": "other@example.com"}.get(key)
		doc.submit.side_effect = lambda: setattr(doc, "docstatus", 1)
		get_doc.return_value = doc
		with patch("karyo.hr.leave_controls.frappe.session", frappe._dict(user="Administrator")):
			result = decide_leave_application("LEAVE-1", "Approved")
		self.assertEqual(result["status"], "Approved")
		self.assertEqual(result["docstatus"], 1)
		doc.save.assert_called_once_with(ignore_permissions=True)
		doc.submit.assert_called_once()

	def test_prorated_entitlements_use_requestable_half_day_units(self):
		employee = frappe._dict(
			date_of_joining="2026-08-17", karyo_date_joined_service="2026-08-17",
			contract_end_date=None,
		)
		rules = frappe._dict(karyo_min_service_months=0, karyo_annual_entitlement_days=21)
		amount = _prorated_entitlement(employee, rules, 2026)
		self.assertEqual(amount * 2, round(amount * 2))

	def test_leave_type_master_uses_business_labels_and_has_no_source_reference(self):
		leave_type_meta = frappe.get_meta("Leave Type")
		settings_meta = frappe.get_meta("MBC Leave Settings")

		self.assertEqual(leave_type_meta.get_field("leave_type_name").label, "Leave Type / Category")
		self.assertEqual(leave_type_meta.get_field("karyo_mbc_leave_code").label, "Leave Code")
		self.assertEqual(leave_type_meta.get_field("karyo_code_description").label, "Leave Description")
		self.assertEqual(leave_type_meta.get_field("karyo_mbc_leave_code").in_list_view, 1)
		self.assertEqual(leave_type_meta.get_field("karyo_code_description").in_list_view, 1)
		self.assertEqual(leave_type_meta.get_field("karyo_mbc_leave_code").reqd, 1)
		self.assertEqual(leave_type_meta.get_field("karyo_code_description").reqd, 1)
		self.assertTrue(leave_type_meta.has_field("karyo_paid"))
		self.assertEqual(leave_type_meta.get_field("is_lwp").label, "Unpaid Leave / Payroll Deduction")
		self.assertTrue(leave_type_meta.has_field("karyo_affects_yos"))
		self.assertEqual(leave_type_meta.get_field("karyo_requires_attachment").label, "Attachment Required")
		self.assertEqual(leave_type_meta.get_field("is_carry_forward").label, "Carry Forward Allowed")
		self.assertEqual(leave_type_meta.get_field("maximum_carry_forwarded_leaves").label, "Maximum Carry Forward")
		self.assertFalse(leave_type_meta.has_field("karyo_source_reference"))
		self.assertFalse(settings_meta.has_field("source_reference"))
		self.assertTrue(settings_meta.has_field("annual_leave_entitlement"))
		self.assertFalse(frappe.db.exists("Leave Type", {"karyo_mbc_leave_code": ("is", "not set")}))
		self.assertFalse(frappe.db.exists("Leave Type", {"karyo_code_description": ("is", "not set")}))

	def test_leave_type_selection_fetches_and_binds_code_and_description(self):
		leave_type = frappe.db.get_value(
			"Leave Type", {"karyo_mbc_leave_code": "CASL01"},
			["name", "karyo_mbc_leave_code", "karyo_code_description"], as_dict=True,
		)
		self.assertTrue(leave_type)

		application_meta = frappe.get_meta("Leave Application")
		self.assertEqual(
			application_meta.get_field("karyo_leave_code").fetch_from,
			"leave_type.karyo_mbc_leave_code",
		)
		self.assertEqual(
			application_meta.get_field("karyo_leave_description").fetch_from,
			"leave_type.karyo_code_description",
		)

		doc = frappe.new_doc("Leave Application")
		doc.leave_type = leave_type.name
		bind_leave_type_metadata(doc)
		self.assertEqual(doc.karyo_leave_code, leave_type.karyo_mbc_leave_code)
		self.assertEqual(doc.karyo_leave_description, leave_type.karyo_code_description)
		self.assertEqual(doc.karyo_allow_encashment, 1)
		self.assertEqual(doc.karyo_payroll_component, "Leave Encashment")
		self.assertEqual(doc.karyo_payroll_impact, 1)

	def test_paternity_opens_only_for_an_eligible_substantive_male_employee(self):
		male = frappe.db.get_value(
			"Employee",
			{"status": "Active", "gender": "Male", "karyo_employment_category": "PERM"},
			"name",
		)
		female = frappe.db.get_value(
			"Employee",
			{"status": "Active", "gender": "Female", "karyo_employment_category": "PERM"},
			"name",
		)
		self.assertTrue(male)
		self.assertTrue(female)
		male_codes = {row[1] for row in eligible_leave_type_query(
			"Leave Type", "", "name", 0, 1000,
			{"employee": male, "on_date": "2026-09-19"},
		)}
		female_codes = {row[1] for row in eligible_leave_type_query(
			"Leave Type", "", "name", 0, 1000,
			{"employee": female, "on_date": "2026-09-19"},
		)}
		self.assertIn("PAT", male_codes)
		self.assertNotIn("PAT", female_codes)

		rules = frappe.db.get_value(
			"Leave Type", {"karyo_mbc_leave_code": "PAT"},
			[
				"name", "karyo_max_days_per_application", "karyo_max_days_per_year",
				"karyo_bank_type", "karyo_requires_leave_bank", "karyo_deducts_from_leave_type",
			], as_dict=True,
		)
		self.assertEqual(rules.karyo_max_days_per_application, 10)
		self.assertEqual(rules.karyo_max_days_per_year, 10)
		self.assertEqual(rules.karyo_bank_type, "None")
		self.assertFalse(rules.karyo_requires_leave_bank)
		self.assertFalse(rules.karyo_deducts_from_leave_type)
		doc = frappe._dict(
			name="NEW-PAT", employee=male, leave_type=rules.name,
			from_date="2026-10-01", to_date="2026-10-11", total_leave_days=11,
			description="Following confinement of spouse",
		)
		with self.assertRaisesRegex(frappe.ValidationError, "cannot exceed 10"):
			validate_mbc_leave_rules(doc)

	def test_leave_type_details_include_payroll_rules(self):
		details = get_leave_type_details("Leave Without Pay")
		self.assertEqual(details["karyo_leave_code"], "LWP02")
		self.assertEqual(details["karyo_unpaid_leave"], 1)
		self.assertEqual(details["karyo_payroll_impact"], 1)

	@patch("frappe.db.sql")
	@patch("frappe.db.get_value")
	def test_payroll_cycle_resolution_matches_employee_type_and_group(self, get_value, sql):
		get_value.return_value = frappe._dict(
			karyo_payroll_type="Major", karyo_payroll_group="Permanent",
		)
		sql.return_value = [
			frappe._dict(name="MINOR", payroll_type="Minor", payroll_group="Permanent"),
			frappe._dict(name="MAJOR", payroll_type="Major", payroll_group="Permanent"),
		]
		self.assertEqual(
			_payroll_cycle_for_employee("EMP-1", "MBC", "2026-09-01", "2026-09-30"),
			"MAJOR",
		)

	@patch("karyo.hr.leave_controls._payroll_cycle_for_employee", return_value="PAYC-1")
	def test_additional_salary_is_automatically_tagged_to_cycle(self, _resolve):
		doc = frappe._dict(
			employee="EMP-1", company="MBC", payroll_date="2026-09-25",
			from_date=None, karyo_payroll_cycle=None,
		)
		assign_payroll_cycle(doc)
		self.assertEqual(doc.karyo_payroll_cycle, "PAYC-1")

	@patch("frappe.db.exists", return_value="Leave Encashment")
	@patch("frappe.db.get_value", return_value=frappe._dict(type="Earning", disabled=0))
	def test_encashment_checkbox_defaults_active_earning_component(self, _get_value, _exists):
		doc = frappe._dict(is_lwp=0, karyo_paid=1, allow_encashment=1, earning_component=None)
		sync_leave_type_payroll_rules(doc)
		self.assertEqual(doc.earning_component, "Leave Encashment")

	@patch("frappe.db.set_value")
	@patch("frappe.get_all", return_value=["Casual Leave"])
	@patch("frappe.db.get_value", return_value="Leave Encashment")
	def test_existing_encashable_types_receive_missing_component(self, _get_value, _get_all, set_value):
		self.assertEqual(configure_encashment_integration(), 1)
		set_value.assert_called_once_with(
			"Leave Type", "Casual Leave", "earning_component", "Leave Encashment",
			update_modified=False,
		)

	def test_client_leave_code_matrix_is_fully_configured(self):
		expected = {row[2] for row in LEAVE_TYPE_MATRIX}
		configured = set(frappe.get_all(
			"Leave Type", filters={"karyo_mbc_leave_code": ("is", "set")},
			pluck="karyo_mbc_leave_code", limit_page_length=0,
		))
		self.assertTrue(expected.issubset(configured))
		self.assertEqual(len(expected), 37)

	def test_category_gender_service_and_contract_eligibility(self):
		employee = frappe._dict(status="Active", date_of_joining="2020-01-01", karyo_date_joined_service=None,
			karyo_employment_category="CONT", gender="Female", contract_end_date="2026-12-31")
		rules = frappe._dict(karyo_min_service_months=12, karyo_eligible_employment_categories="CONT",
			karyo_eligible_gender="Female", karyo_requires_valid_contract=1)
		self.assertTrue(_is_employee_eligible(employee, rules, "2026-09-18"))
		employee.contract_end_date = "2026-09-01"
		self.assertFalse(_is_employee_eligible(employee, rules, "2026-09-18"))

	@patch("frappe.db.set_value")
	@patch("frappe.get_all", return_value=["Leave Without Pay"])
	def test_lwp_integration_flags_are_owned_by_leave_type(self, _get_all, set_value):
		configure_lwp_integration_flags()
		values = set_value.call_args.args[2]
		self.assertEqual(values["karyo_affects_yos"], 1)
		self.assertEqual(values["karyo_pb_not_earned"], 1)
		self.assertEqual(values["karyo_vacation_not_earned"], 1)

	@patch("frappe.db.get_value")
	def test_configured_leave_eligibility_and_duration_are_enforced(self, get_value):
		get_value.side_effect = [
			frappe._dict(karyo_min_service_months=12, karyo_eligible_employment_categories="Permanent", karyo_eligible_gender="Male", karyo_max_days_per_application=10),
			frappe._dict(date_of_joining="2026-01-01", karyo_date_joined_service=None, karyo_employment_category="Permanent", gender="Male"),
		]
		doc = frappe._dict(employee="EMP-1", leave_type="Paternity Leave", from_date="2026-06-01", total_leave_days=10)
		with self.assertRaises(frappe.ValidationError):
			validate_mbc_leave_rules(doc)

	@patch("frappe.db.get_value")
	def test_unconfigured_leave_type_preserves_standard_hrms_behavior(self, get_value):
		get_value.return_value = None
		validate_mbc_leave_rules(frappe._dict(employee="EMP-1", leave_type="Other", from_date="2026-06-01", total_leave_days=1))

	@patch("karyo.hr.leave_controls.leave_days_by_code", return_value=180)
	@patch("karyo.hr.leave_controls._bank_values")
	@patch("karyo.hr.leave_controls._employee")
	@patch("karyo.hr.leave_controls._rules")
	def test_repaid_full_pay_sick_advance_starts_a_new_cycle(self, rules, employee, banks, _used):
		rules.return_value = frappe._dict(
			karyo_mbc_leave_code="SICK03", karyo_min_service_months=0,
			karyo_eligible_employment_categories="", karyo_eligible_gender="",
			karyo_requires_valid_contract=0, karyo_max_days_per_application=0,
			karyo_max_days_per_year=0, karyo_max_days_total=180,
			karyo_prerequisite_codes="", karyo_bank_type="Sick Leave Bank",
		)
		employee.return_value = frappe._dict(status="Active")
		banks.return_value = (frappe._dict(status="Active", bank_days=0, advance_balance_days=0), None)
		doc = frappe._dict(
			name="NEW", employee="EMP-1", leave_type="Advance Sick Leave Full Pay",
			from_date="2026-06-01", to_date="2026-06-01", total_leave_days=1,
			description="New advance after full recovery",
		)
		validate_mbc_leave_rules(doc)

	@patch("frappe.db.get_value", return_value=frappe._dict(employee="EMP-1", docstatus=2))
	def test_cancelled_application_can_be_replaced(self, _get_value):
		doc = frappe._dict(name="NEW", employee="EMP-1", karyo_replaces_leave_application="OLD", karyo_correction_reason="Correct type")
		validate_leave_correction(doc)

	@patch("frappe.db.get_value", return_value=frappe._dict(employee="EMP-1", docstatus=1))
	def test_submitted_application_cannot_be_replaced(self, _get_value):
		doc = frappe._dict(name="NEW", employee="EMP-1", karyo_replaces_leave_application="OLD", karyo_correction_reason="Correct type")
		with self.assertRaises(frappe.ValidationError):
			validate_leave_correction(doc)

	@patch("frappe.get_roles", return_value=["HR Manager"])
	@patch("frappe.db.exists", return_value="PAY-CYCLE-1")
	def test_closed_period_requires_payroll_approver(self, _exists, _roles):
		doc = frappe._dict(company="SIL", from_date="2026-07-01", to_date="2026-07-02", karyo_cancellation_approval_reference="APR-1")
		with self.assertRaises(frappe.ValidationError):
			validate_closed_period_cancellation(doc)
