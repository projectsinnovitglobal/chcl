frappe.query_reports["MBC Audit Trail"] = {
	filters: [
		{fieldname: "ref_doctype", label: __("Reference Type"), fieldtype: "Link", options: "DocType"},
		{fieldname: "document_name", label: __("Document"), fieldtype: "Data"},
		{fieldname: "changed_by", label: __("Changed By"), fieldtype: "Link", options: "User"},
		{fieldname: "from_date", label: __("Changed From"), fieldtype: "Date", default: frappe.datetime.add_days(frappe.datetime.get_today(), -30)},
		{fieldname: "to_date", label: __("Changed To"), fieldtype: "Date", default: frappe.datetime.get_today()},
		{fieldname: "action", label: __("Action"), fieldtype: "Select", options: "\nChanged\nRow added\nRow changed\nRow removed"},
	],
};
