"""Roster-aware attendance completion and display rules."""

from datetime import datetime, timedelta

import frappe
from frappe import _
from frappe.utils import add_days, get_datetime, get_time, getdate, now_datetime, nowdate

from karyo.hr.roster import current_duty, shift_context


SHIFT_GROUPS = {"shift", "roster", "staggered"}


def display_status(raw_status, clock_in_status=None, late_entry=False, confirmed_present=False):
	"""Show a timing result only when a clock-in actually produced one."""
	if raw_status in {"Absent", "On Leave", "Half Day", "Work From Home"}:
		return raw_status
	if clock_in_status in {"Late", "On-time"}:
		return clock_in_status
	if raw_status == "Present":
		# An approved attendance correction or audited manual entry is itself the
		# authority for presence.  It deliberately may not have a device punch,
		# so presenting it as "Awaiting Clock In" hides HR's approved outcome.
		if confirmed_present:
			return "Present"
		# ``late_entry`` is a legacy/manual flag and is not proof that the
		# employee clocked in.  Without a check-in the record remains pending
		# until the assigned duty finishes, when the scheduler marks it Absent.
		return "Awaiting Clock In"
	return raw_status or "Awaiting Clock In"


def _employee_duty(employee, duty_date):
	duty = current_duty(employee.name, duty_date)
	if duty:
		return duty
	group = None
	if employee.get("karyo_employee_group"):
		group = frappe.db.get_value("Employee Group", employee.karyo_employee_group, "karyo_prb_group")
	# A roster/shift employee needs a dated duty. Falling back would mark rest
	# days absent, which is worse than leaving the dependency visible.
	if group in SHIFT_GROUPS or not employee.default_shift:
		return None
	return shift_context(employee.default_shift)


def _duty_window(duty_date, duty):
	start = datetime.combine(getdate(duty_date), get_time(duty.start_time))
	end = datetime.combine(getdate(duty_date), get_time(duty.end_time))
	if end <= start:
		end += timedelta(days=1)
	return start, end


def _is_holiday(employee, duty_date):
	return bool(
		employee.holiday_list
		and frappe.db.exists("Holiday", {"parent": employee.holiday_list, "holiday_date": duty_date})
	)


def _approved_leave(employee, duty_date):
	return frappe.db.exists(
		"Leave Application",
		{
			"employee": employee,
			"docstatus": 1,
			"status": "Approved",
			"from_date": ["<=", duty_date],
			"to_date": [">=", duty_date],
		},
	)


def mark_completed_shifts_absent(reference_time=None):
	"""Mark absence only after an assigned/default duty has fully ended."""
	now = get_datetime(reference_time or now_datetime())
	created, updated, skipped, failed = [], [], [], []
	employees = frappe.get_all(
		"Employee",
		filters={"status": "Active", "date_of_joining": ["<=", now.date()]},
		fields=[
			"name", "employee_name", "company", "date_of_joining", "relieving_date",
			"default_shift", "holiday_list", "karyo_employee_group",
		],
		limit_page_length=0,
	)
	for duty_date in (getdate(add_days(now.date(), -1)), getdate(now.date())):
		for employee in employees:
			try:
				if employee.relieving_date and duty_date > getdate(employee.relieving_date):
					continue
				duty = _employee_duty(employee, duty_date)
				if not duty or not duty.start_time or not duty.end_time:
					continue
				start, end = _duty_window(duty_date, duty)
				if now <= end:
					continue
				if _is_holiday(employee, duty_date) or _approved_leave(employee.name, duty_date):
					skipped.append(employee.name)
					continue
				attendance_name = frappe.db.exists(
					"Attendance",
					{"employee": employee.name, "attendance_date": duty_date, "docstatus": ["<", 2]},
				)
				checkin = frappe.db.sql(
					"""select name from `tabEmployee Checkin`
					where employee=%s and time between %s and %s limit 1""",
					(employee.name, start - timedelta(hours=2), end + timedelta(hours=2)),
				)
				if checkin:
					skipped.append(employee.name)
					continue
				if attendance_name:
					# Older/manual records may have been saved as Present before a
					# punch existed.  Once duty has ended, absence is authoritative.
					# Attendance has no financial posting, so updating this status is
					# safe for submitted rows and preserves the original record/audit.
					if frappe.db.get_value("Attendance", attendance_name, "status") == "Present":
						frappe.db.set_value("Attendance", attendance_name, "status", "Absent")
						updated.append(attendance_name)
					else:
						skipped.append(employee.name)
					continue
				doc = frappe.get_doc(
					{
						"doctype": "Attendance",
						"employee": employee.name,
						"employee_name": employee.employee_name,
						"company": employee.company,
						"attendance_date": duty_date,
						"shift": duty.shift_type,
						"status": "Absent",
					}
				).insert(ignore_permissions=True)
				doc.submit()
				created.append(doc.name)
			except Exception as error:
				failed.append({"employee": employee.name, "date": str(duty_date), "error": str(error)})
	if failed:
		frappe.log_error(title=_("Roster attendance auto-absence failures"), message=frappe.as_json(failed))
	return {"created": created, "updated": updated, "skipped": skipped, "failed": failed}
