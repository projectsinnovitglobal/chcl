"""Use the same employee grace policy for native automatic attendance."""
import math
from datetime import timedelta

import frappe
from frappe import _
from frappe.utils import cint, flt
from hrms.hr.doctype.shift_type.shift_type import ShiftType

from karyo.hr.lateness import employee_grace_minutes


def validate_grace_values(start, end):
	for label, value in ((_("Start Grace"), start), (_("End Grace"), end)):
		minutes = flt(value)
		if not math.isfinite(minutes) or minutes < 0:
			frappe.throw(_("{0} must be a non-negative number of minutes.").format(label))


def validate_employee_grace(doc, method=None):
	validate_grace_values(doc.get("karyo_start_grace_minutes"), doc.get("karyo_end_grace_minutes"))
	fields = ("karyo_override_attendance_grace", "karyo_start_grace_minutes", "karyo_end_grace_minutes")
	if frappe.session.user == "Administrator" or doc.flags.ignore_permissions:
		return
	if any(doc.has_value_changed(field) for field in fields):
		# Self-service may permit edits to personal details; it must not permit
		# granting one's own attendance accommodation.
		edit_roles = {p.role for p in doc.meta.permissions if p.write
			and p.role not in ("Employee", "Employee Self Service")}
		if not edit_roles.intersection(frappe.get_roles()):
			frappe.throw(_("Only an authorized employee administrator can change attendance grace."),
				frappe.PermissionError)


def notify_grace_change(doc, method=None):
	fields = {
		"Employee": ("karyo_employment_category", "karyo_override_attendance_grace",
			"karyo_start_grace_minutes", "karyo_end_grace_minutes"),
		"Employee Category": ("override_attendance_grace", "start_grace_minutes", "end_grace_minutes", "disabled"),
		"Shift Type": ("enable_late_entry_marking", "late_entry_grace_period",
			"enable_early_exit_marking", "early_exit_grace_period"),
	}.get(doc.doctype, ())
	if any(doc.has_value_changed(field) for field in fields):
		# Only invalidate the permission-scoped views; no employee data is broadcast.
		frappe.publish_realtime("karyo_attendance_updated", after_commit=True)


class KaryoShiftType(ShiftType):
	def get_attendance(self, logs):
		status, hours, late, early, clock_in, clock_out = super().get_attendance(logs)
		start_grace, end_grace, _source = employee_grace_minutes(logs[0].employee, self)
		late = bool(cint(self.enable_late_entry_marking) and clock_in
			and clock_in > logs[0].shift_start + timedelta(minutes=start_grace))
		early = bool(cint(self.enable_early_exit_marking) and clock_out
			and clock_out < logs[0].shift_end - timedelta(minutes=end_grace))
		return status, hours, late, early, clock_in, clock_out
