"""Loan period selection must follow payroll actually available to the employee."""
import unittest
from unittest.mock import patch
import frappe
from frappe.utils import add_days, nowdate
from karyo.loan.employee_period import default_period

class TestLoanPayrollDefault(unittest.TestCase):
    def choose(self, configured, available, end_dates=None):
        end_dates=end_dates or {}
        with patch('karyo.loan.employee_period.frappe.db.get_value', return_value=configured), \
                patch('karyo.loan.employee_period.period_options', return_value=[frappe._dict(value=v,end_date=end_dates.get(v)) for v in ('old','closed')]), \
                patch('karyo.loan.employee_payroll.cycles', return_value=[frappe._dict(payroll_period=v) for v in available]):
            return default_period('employee')

    def test_stale_default_falls_back_to_closed_employee_payroll(self):
        self.assertEqual(self.choose('old', ['closed']), 'closed')

    def test_available_hr_selection_is_preserved(self):
        self.assertEqual(self.choose('old', ['closed','old']), 'old')

    def test_unbacked_future_selection_does_not_mask_available_payroll(self):
        self.assertEqual(
            self.choose('old', ['closed'], {'old': add_days(nowdate(), 30)}),
            'closed',
        )

    def test_future_selection_is_visible_when_employee_has_no_eligible_payroll(self):
        self.assertEqual(
            self.choose('old', [], {'old': add_days(nowdate(), 30)}),
            'old',
        )

    def test_missing_employee_payroll_does_not_invent_a_period(self):
        self.assertIsNone(self.choose(None, []))
        self.assertEqual(self.choose('old', []), 'old')

    def test_zero_salary_explains_blocker_and_correction(self):
        doc=frappe.get_doc({'doctype':'Karyo Loan','employee':'employee','appraisal_payroll_cycle':'cycle',
            'appraisal_payroll_period':'closed','workflow_state':'Draft'})
        result={'source_salary_slips':['slip'], 'eligible_salary':0}
        with patch('frappe.db.get_single_value', return_value=1), \
                patch('karyo.karyo.doctype.karyo_loan.karyo_loan.compute_appraisal', return_value=result):
            with self.assertRaisesRegex(frappe.ValidationError, 'payroll period closed is 0.*Ask HR'):
                doc._appraise()
        self.assertEqual(doc.eligible_salary, 0)
        self.assertEqual(doc.appraisal_status, 'Not Appraised')
