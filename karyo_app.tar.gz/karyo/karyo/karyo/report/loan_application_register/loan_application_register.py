import frappe
from frappe import _
from frappe.utils import flt


def execute(filters=None):
	filters = frappe._dict(filters or {})
	frappe.has_permission("Karyo Loan", "read", throw=True)
	loan_filters = {}
	for field in ("workflow_state", "loan_type", "employee"):
		if filters.get(field):
			loan_filters[field] = filters[field]
	if filters.from_date or filters.to_date:
		loan_filters["date_applied"] = ["between", [filters.from_date or "1900-01-01", filters.to_date or "2999-12-31"]]
	rows = frappe.get_list(
		"Karyo Loan",
		filters=loan_filters,
		fields=["name", "employee", "employee_name", "loan_type", "amount_applied", "approved_amount",
			"registration_fee", "net_loan_amount", "date_applied", "workflow_state", "owner", "creation"],
		order_by="date_applied desc, creation desc",
		limit_page_length=0,
	)
	_enrich_employee_organisation(rows)
	rows = [row for row in rows if (not filters.department or row.department == filters.department)
		and (not filters.location or row.location == filters.location)]
	for row in rows:
		row.variance = flt(row.amount_applied) - flt(row.approved_amount)
	return _columns(), rows, None, None, _summary(rows)


def _enrich_employee_organisation(rows):
	employees = {row.employee for row in rows if row.employee}
	organisation = {
		r.name: r for r in frappe.get_all("Employee", filters={"name": ["in", list(employees)]},
			fields=["name", "department", "branch"], limit_page_length=0)
	} if employees else {}
	for row in rows:
		employee = organisation.get(row.employee, frappe._dict())
		row.department = employee.get("department")
		row.location = employee.get("branch")


def _summary(rows):
	return [
		{"label": _("Applications"), "value": len(rows), "indicator": "Blue", "datatype": "Int"},
		{"label": _("Total Applied"), "value": sum(flt(r.amount_applied) for r in rows), "indicator": "Blue", "datatype": "Currency"},
		{"label": _("Total Approved"), "value": sum(flt(r.approved_amount) for r in rows), "indicator": "Green", "datatype": "Currency"},
		{"label": _("Applied less Approved"), "value": sum(flt(r.variance) for r in rows), "indicator": "Orange", "datatype": "Currency"},
	]


def _columns():
	def c(fieldname, label, fieldtype="Data", width=110, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width,
			**({"options": options} if options else {})}
	return [c("name", "Loan Application", "Link", 155, "Karyo Loan"), c("date_applied", "Date Applied", "Date", 100),
		c("employee", "Employee", "Link", 130, "Employee"), c("employee_name", "Employee Name", width=160),
		c("department", "Department", "Link", 130, "Department"), c("location", "Location / Branch", "Link", 125, "Branch"),
		c("loan_type", "Loan Type", "Link", 120, "Loan Type"), c("workflow_state", "Application Status", width=175),
		c("amount_applied", "Amount Applied", "Currency", 125), c("approved_amount", "Amount Approved", "Currency", 130),
		c("variance", "Applied less Approved", "Currency", 145), c("registration_fee", "Registration Fee", "Currency", 120),
		c("net_loan_amount", "Net Loan Amount", "Currency", 125), c("owner", "Created By", "Link", 150, "User")]
