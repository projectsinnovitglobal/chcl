"""PRB exception codes (PRB-15, PRB analysis §13.1).

Blocked/manual-review outcomes are surfaced with a stable code + meaning so they
can be queued and reported rather than silently mis-computed.
"""

EXCEPTION_CODES = {
	"NO_RULE": "No active rule version for the period/component.",
	"MISSING_GRADE_SCALE": "Grade schedule or top/initial point not loaded.",
	"APPROVAL_REQUIRED": "Payment/accrual requires approval.",
	"AMBIGUOUS_LEAVE_TYPE": "Leave type not mapped to PRB impact flags.",
	"SICK_LEAVE_BANK_CONFIG_MISSING": "Sick Leave Bank opening balance / status / advance missing.",
	"DUPLICATE_HOURS": "Same hours claimed under overlapping allowance/overtime types.",
	"PMS_POLICY_UNCONFIRMED": "PMS outcome requested to drive payroll without an approved policy.",
}


class PRBException(Exception):
	"""A blocked PRB computation carrying a stable exception code."""

	def __init__(self, code, detail=None):
		self.code = code
		self.meaning = EXCEPTION_CODES.get(code, "Unknown PRB exception.")
		self.detail = detail
		super().__init__(f"[{code}] {self.meaning}" + (f" — {detail}" if detail else ""))


def raise_exception(code, detail=None):
	raise PRBException(code, detail)
