"""Repair legacy 2026/27 PAYE master dates to the statutory July–June year."""

import frappe


ALIASES = ("2026-27", "2026-2027", "2026/2027")


def execute():
	name = frappe.db.get_value(
		"Payroll PAYE Year",
		{"tax_year": ("in", ALIASES), "company": "MBC"},
		"name",
		order_by="modified desc",
	)
	if not name:
		return

	doc = frappe.get_doc("Payroll PAYE Year", name)
	if doc.configuration_version:
		frappe.db.set_value(
			"Payroll Configuration Version",
			doc.configuration_version,
			{"effective_from": "2026-07-01", "effective_to": "2027-06-30"},
			update_modified=False,
		)

	doc.tax_year = "2026/2027"
	doc.effective_from = "2026-07-01"
	doc.effective_to = "2027-06-30"
	doc.periods_per_year = 13
	doc.save(ignore_permissions=True)
