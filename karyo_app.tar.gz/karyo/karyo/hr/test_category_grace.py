"""Transactional coverage of accommodations across native attendance and both views."""
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch
from uuid import uuid4
import frappe
from frappe.utils import add_days, getdate, nowdate
from karyo.hr.attendance_grace import validate_employee_grace, notify_grace_change
from karyo.hr.clocking import _attendance_metrics, attendance_times
from karyo.hr.lateness import employee_grace_minutes, attendance_lateness_values, sync_attendance_lateness


class TestEmployeeCategoryGrace(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user('Administrator'); frappe.db.savepoint('category_grace')
		self.events = patch('frappe.publish_realtime'); self.event_mock = self.events.start(); self.addCleanup(self.events.stop)
		self.mail = patch('frappe.sendmail'); self.mail.start(); self.addCleanup(self.mail.stop)
		self.uid = 'GRACE-' + uuid4().hex[:10]
		frappe.get_doc({'doctype': 'Employment Type', 'name': self.uid, 'docstatus': 0,
			'employee_type_name': self.uid}).db_insert()
		self.category = frappe.get_doc({'doctype': 'Employee Category', 'employment_type': self.uid,
			'category_code': self.uid, 'category_name': 'Disability test accommodation',
			'override_attendance_grace': 1, 'start_grace_minutes': 30, 'end_grace_minutes': 20,
			'map_dependencies': 0}).insert()
		source = frappe.db.get_value('Employee', {'status': 'Active'}, 'name')
		self.employee = frappe.copy_doc(frappe.get_doc('Employee', source))
		self.employee.name = self.uid; self.employee.docstatus = 0
		self.employee.user_id = None; self.employee.date_of_joining = '2000-01-01'
		self.employee.relieving_date = None; self.employee.employment_type = self.uid
		self.employee.karyo_employment_category = self.category.name
		self.employee.karyo_override_attendance_grace = 0; self.employee.karyo_post_exit_payroll_enabled = 0
		for field in self.employee.meta.fields:
			if field.unique: self.employee.set(field.fieldname, None)
		self.employee.db_insert()
		self.shift = frappe.get_doc({'doctype': 'Shift Type', 'name': self.uid, 'docstatus': 0,
			'start_time': '08:00:00', 'end_time': '16:00:00', 'enable_late_entry_marking': 1,
			'enable_early_exit_marking': 1, 'late_entry_grace_period': 10, 'early_exit_grace_period': 5,
			'determine_check_in_and_check_out': 'Strictly based on Log Type in Employee Checkin',
			'working_hours_calculation_based_on': 'First Check-in and Last Check-out'})
		self.shift.db_insert()
		self.date = add_days(nowdate(), -1)
		self.start = datetime.combine(getdate(self.date), datetime.min.time()) + timedelta(hours=8)
		self.end = self.start + timedelta(hours=8)

	def tearDown(self):
		frappe.db.rollback(save_point='category_grace')
		frappe.clear_document_cache('Shift Type', self.uid); frappe.set_user(self.user)

	def override(self, enabled=1, start=45, end=25):
		frappe.db.set_value('Employee', self.employee.name, {'karyo_override_attendance_grace': enabled,
			'karyo_start_grace_minutes': start, 'karyo_end_grace_minutes': end})

	def attendance(self, late=20, early=15):
		return frappe.get_doc({'doctype': 'Attendance', 'employee': self.employee.name,
			'company': self.employee.company, 'attendance_date': self.date, 'status': 'Present',
			'shift': self.shift.name, 'in_time': self.start + timedelta(minutes=late),
			'out_time': self.end - timedelta(minutes=early), 'late_entry': 1, 'early_exit': 1})

	def native(self, late=20, early=15):
		logs = [frappe._dict(employee=self.employee.name, log_type=kind, time=time,
			shift_start=self.start, shift_end=self.end) for kind, time in
			(('IN', self.start + timedelta(minutes=late)), ('OUT', self.end - timedelta(minutes=early)))]
		return self.shift.get_attendance(logs)

	def test_category_grace_applies_without_dependency_mapping(self):
		self.assertEqual(employee_grace_minutes(self.employee.name, self.shift), (30, 20, 'Employee Category'))
		self.assertEqual(self.native()[2:4], (False, False))
		self.assertEqual(attendance_lateness_values(self.attendance()).total_minutes, 0)

	def test_employee_override_takes_priority_and_zero_is_explicit(self):
		self.override()
		self.assertEqual(employee_grace_minutes(self.employee.name, self.shift), (45, 25, 'Employee'))
		self.override(start=0, end=0)
		self.assertEqual(employee_grace_minutes(self.employee.name, self.shift), (0, 0, 'Employee'))
		self.assertEqual(self.native()[2:4], (True, True))
		self.assertEqual(attendance_lateness_values(self.attendance()).total_minutes, 35)

	def test_disabled_employee_override_falls_back_to_category(self):
		self.override(enabled=0)
		self.assertEqual(employee_grace_minutes(self.employee.name, self.shift), (30, 20, 'Employee Category'))

	def test_disabled_or_unconfigured_category_falls_back_to_shift(self):
		for values in ({'disabled': 1}, {'disabled': 0, 'override_attendance_grace': 0}):
			frappe.db.set_value('Employee Category', self.category.name, values)
			self.assertEqual(employee_grace_minutes(self.employee.name, self.shift), (10, 5, 'Shift Type'))
			self.assertEqual(attendance_lateness_values(self.attendance()).total_minutes, 20)

	def test_no_category_falls_back_to_shift(self):
		frappe.db.set_value('Employee', self.employee.name, 'karyo_employment_category', None)
		self.assertEqual(employee_grace_minutes(self.employee.name, self.shift), (10, 5, 'Shift Type'))

	def test_category_zero_grace_is_an_explicit_override(self):
		frappe.db.set_value('Employee Category', self.category.name, {'start_grace_minutes': 0, 'end_grace_minutes': 0})
		self.assertEqual(employee_grace_minutes(self.employee.name, self.shift), (0, 0, 'Employee Category'))

	def test_employee_self_service_matches_hr_and_cannot_edit_grace(self):
		user = frappe.get_doc({'doctype': 'User', 'email': self.uid.lower() + '@example.invalid',
			'first_name': 'Grace Test', 'send_welcome_email': 0, 'user_type': 'System User',
			'roles': [{'role': 'Employee'}]}).insert(ignore_permissions=True)
		frappe.db.set_value('Employee', self.employee.name, 'user_id', user.name)
		# HRMS removes the Employee role from users until an Employee is linked.
		user.add_roles('Employee')
		doc = self.attendance(35, 25).insert().submit()
		hr = attendance_times([doc.name])[doc.name]
		frappe.set_user(user.name)
		from karyo.hr.employee_attendance import get_attendance
		ess = next(row for row in get_attendance(month=str(self.date)[:7])['rows'] if row.name == doc.name)
		for field in ('clock_in_status', 'clock_out_status', 'karyo_late_entry_grace_minutes',
			'karyo_early_exit_grace_minutes', 'karyo_grace_source', 'lateness_minutes',
			'late_arrival_minutes', 'early_departure_minutes'):
			self.assertEqual(ess[field], hr[field])
		self.assertEqual(ess.karyo_detected_late_minutes, 10)
		self.assertEqual(ess.lateness_minutes, 60)
		from karyo.hr.employee_attendance import get_record
		self.assertEqual(get_record(doc.name)['lateness_minutes'], 60)
		self.assertFalse(frappe.has_permission('Employee', 'write', doc=self.employee))
		frappe.set_user('Administrator'); user.add_roles('Employee Self Service')
		frappe.set_user(user.name); self.employee.reload()
		self.employee.karyo_override_attendance_grace = 1
		with self.assertRaises(frappe.PermissionError): validate_employee_grace(self.employee)

	def test_manual_flags_without_clock_evidence_are_preserved(self):
		doc = self.attendance(); doc.in_time = doc.out_time = None
		doc.insert().submit(); doc.reload()
		self.assertEqual((doc.late_entry, doc.early_exit), (1, 1))

	def test_boundary_and_fractional_minutes_match_native_and_deductions(self):
		self.override(start=30.5, end=20.5)
		self.assertEqual(self.native(30.5, 20.5)[2:4], (False, False))
		self.assertEqual(attendance_lateness_values(self.attendance(30.5, 20.5)).total_minutes, 0)
		self.assertEqual(self.native(31, 21)[2:4], (True, True))
		self.assertEqual(attendance_lateness_values(self.attendance(31, 21)).total_minutes, 1)

	def test_disabled_shift_marking_does_not_charge_or_mark(self):
		self.shift.enable_late_entry_marking = self.shift.enable_early_exit_marking = 0
		frappe.db.set_value('Shift Type', self.shift.name, {'enable_late_entry_marking': 0, 'enable_early_exit_marking': 0})
		frappe.clear_document_cache('Shift Type', self.shift.name)
		self.assertEqual(self.native(60, 60)[2:4], (False, False))
		self.assertEqual(attendance_lateness_values(self.attendance(60, 60)).total_minutes, 0)

	def test_overnight_shift_uses_next_day_end(self):
		frappe.db.set_value('Shift Type', self.shift.name, {'start_time': '22:00:00', 'end_time': '06:00:00'})
		frappe.clear_document_cache('Shift Type', self.shift.name)
		self.start += timedelta(hours=14); self.end += timedelta(hours=14)
		values = attendance_lateness_values(self.attendance(35, 25))
		self.assertEqual((values.late_minutes, values.early_minutes, values.scheduled_minutes), (5, 5, 480))

	def test_manual_submission_flags_snapshots_and_hr_view_match(self):
		doc = self.attendance().insert().submit(); doc.reload()
		self.assertEqual((doc.late_entry, doc.early_exit, doc.karyo_detected_late_minutes), (0, 0, 0))
		self.assertEqual((doc.karyo_late_entry_grace_minutes, doc.karyo_early_exit_grace_minutes, doc.karyo_grace_source), (30, 20, 'Employee Category'))
		metrics = attendance_times([doc.name])[doc.name]
		self.assertEqual((metrics['clock_in_status'], metrics['clock_out_status']), ('On-time', 'On-time'))
		self.assertEqual(metrics['karyo_grace_source'], doc.karyo_grace_source)

	def test_approved_snapshot_survives_configuration_change(self):
		doc = self.attendance(40, 30).insert().submit()
		from karyo.hr.lateness import approve_lateness
		with patch('karyo.hr.lateness._settings', return_value=frappe._dict(lateness_approval_workflow='Manual')):
			approve_lateness(doc.name, 20, 'GRACE-TEST-APPROVAL')
		doc.reload(); self.override(start=90, end=90)
		sync_attendance_lateness(doc); doc.reload()
		self.assertEqual((doc.karyo_detected_late_minutes, doc.karyo_late_entry_grace_minutes, doc.karyo_grace_source, doc.karyo_approved_late_minutes), (20, 30, 'Employee Category', 20))
		metrics = attendance_times([doc.name])[doc.name]
		self.assertEqual((metrics['clock_in_status'], metrics['clock_out_status']), ('Late', 'Early'))
		self.assertEqual(metrics['lateness_minutes'], 70)

	def test_ess_lateness_uses_full_delay_after_start_grace_threshold(self):
		frappe.db.set_value('Shift Type', self.shift.name, {'start_time': '14:00:00', 'end_time': '22:00:00'})
		frappe.clear_document_cache('Shift Type', self.shift.name)
		self.start += timedelta(hours=6); self.end += timedelta(hours=6)
		self.override(start=15, end=15)
		row = frappe._dict(attendance_date=self.date, shift=self.shift.name)
		for actual, expected in ((14, 0), (15, 0), (16, 16)):
			metrics = _attendance_metrics(row, self.start + timedelta(minutes=actual), self.end, self.employee.name)
			self.assertEqual(metrics['lateness_minutes'], expected)
			self.assertEqual(metrics['late_arrival_minutes'], expected)
			self.assertEqual(metrics['clock_in_status'], 'Late' if expected else 'On-time')
		doc = self.attendance(16, 0).insert().submit()
		metrics = attendance_times([doc.name])[doc.name]
		self.assertEqual(metrics['lateness_minutes'], 16)
		self.assertEqual(metrics['karyo_late_entry_grace_minutes'], 15)
		self.assertEqual(metrics['karyo_grace_source'], 'Employee')

	def test_end_grace_threshold_counts_full_early_departure(self):
		self.override(start=15, end=15)
		row = frappe._dict(attendance_date=self.date, shift=self.shift.name)
		for actual, expected in ((14, 0), (15, 0), (16, 16)):
			metrics = _attendance_metrics(row, self.start, self.end - timedelta(minutes=actual), self.employee.name)
			self.assertEqual(metrics['early_departure_minutes'], expected)
			self.assertEqual(metrics['lateness_minutes'], expected)
		metrics = _attendance_metrics(row, self.start - timedelta(minutes=30), self.end + timedelta(minutes=30), self.employee.name)
		self.assertEqual(metrics['lateness_minutes'], 0)

	def test_overnight_lateness_and_partial_clock_records(self):
		frappe.db.set_value('Shift Type', self.shift.name, {'start_time': '22:00:00', 'end_time': '06:00:00'})
		frappe.clear_document_cache('Shift Type', self.shift.name)
		self.start += timedelta(hours=14); self.end += timedelta(hours=14)
		self.override(start=15, end=15)
		row = frappe._dict(attendance_date=self.date, shift=self.shift.name)
		metrics = _attendance_metrics(row, self.start + timedelta(minutes=16), self.end - timedelta(minutes=16), self.employee.name)
		self.assertEqual((metrics['lateness_minutes'], metrics['late_arrival_minutes'], metrics['early_departure_minutes']), (32, 16, 16))
		metrics = _attendance_metrics(row, self.start + timedelta(minutes=16), None, self.employee.name)
		self.assertEqual((metrics['lateness_minutes'], metrics['early_departure_minutes']), (16, None))
		metrics = _attendance_metrics(row, None, None, self.employee.name)
		self.assertIsNone(metrics['lateness_minutes'])

	def test_saved_lateness_keeps_applied_grace_after_policy_change(self):
		self.override(start=15, end=15)
		doc = self.attendance(16, 0).insert().submit()
		self.override(start=45, end=45)
		metrics = attendance_times([doc.name])[doc.name]
		self.assertEqual((metrics['lateness_minutes'], metrics['karyo_late_entry_grace_minutes']), (16, 15))

	def test_live_rows_show_current_grace_and_notify_both_dashboards(self):
		self.override(); self.employee.reload(); notify_grace_change(self.employee)
		self.event_mock.assert_called_with('karyo_attendance_updated', after_commit=True)
		row = frappe._dict(attendance_date=self.date, shift=self.shift.name)
		metrics = _attendance_metrics(row, self.start + timedelta(minutes=35), self.end - timedelta(minutes=22), self.employee.name)
		self.assertEqual((metrics['clock_in_status'], metrics['clock_out_status'], metrics['karyo_grace_source']), ('On-time', 'On-time', 'Employee'))
		self.assertEqual(metrics['karyo_detected_late_minutes'], 0)
		self.override(start=10, end=5)
		metrics = _attendance_metrics(row, self.start + timedelta(minutes=35), self.end - timedelta(minutes=22), self.employee.name)
		self.assertEqual(metrics['karyo_detected_late_minutes'], 42)

	def test_negative_grace_rejected_for_employee_and_category(self):
		for field in ('karyo_start_grace_minutes', 'karyo_end_grace_minutes'):
			self.employee.set(field, -1)
			with self.assertRaises(frappe.ValidationError): validate_employee_grace(self.employee)
			self.employee.set(field, 0)
		for field in ('start_grace_minutes', 'end_grace_minutes'):
			self.category.set(field, -1)
			with self.assertRaises(frappe.ValidationError): self.category.save()
			self.category.set(field, 0)
