frappe.pages["cost-center-master"].on_page_load = function (wrapper) {
	let permissions = {};
	const default_company = () => frappe.defaults.get_user_default("Company") || frappe.boot.sysdefaults?.company || "";
	const $body = karyo.pages.scaffold(wrapper, {
		title: __("Cost Center Master"),
		subtitle: __("All Cost Center values in one master table"),
		actions: [{ label: __("Add Cost Center"), primary: true, onclick: () => open_editor(null, { company: selected_company() }) }],
	});
	const $filters = $(
		'<div class="accounts-master-filters">' +
		'<label><span class="accounts-master-company-label"></span><select class="form-control input-sm accounts-master-company"></select></label>' +
		'<label class="accounts-master-search"><span></span><input type="search" class="form-control input-sm"></label>' +
		'<div class="accounts-master-count"></div></div>'
	).appendTo($body);
	$filters.find(".accounts-master-company-label").text(__("Company"));
	$filters.find(".accounts-master-search span").text(__("Search"));
	const $company = $filters.find(".accounts-master-company");
	const $search = $filters.find("input").attr("placeholder", __("Cost Center code, name, company or parent…"));
	const $count = $filters.find(".accounts-master-count");
	const $card = $('<section class="accounts-master-card master-list-card"><div class="accounts-master-table-wrap"><table class="accounts-master-table master-list-table cost-center-master-list"><thead><tr><th class="master-list-check"><input type="checkbox" class="master-check-all"></th></tr></thead><tbody></tbody></table></div></section>').appendTo($body);
	[__("Cost Center Code"), __("Cost Center"), __("Company"), __("Actions")]
		.forEach((label) => $("<th scope=\"col\"></th>").text(label).appendTo($card.find("thead tr")));

	function selected_company() {
		return $company.val() || default_company();
	}

	async function open_editor(name = null, defaults = {}) {
		await frappe.model.with_doctype("Cost Center");
		let doc = { company: default_company(), is_group: 0, disabled: 0, ...defaults };
		if (name) doc = await frappe.db.get_doc("Cost Center", name);
		if (name && !doc.parent_cost_center) {
			frappe.show_alert({ indicator: "orange", message: __("The root Cost Center cannot be edited.") }, 6);
			return;
		}
		const meta = frappe.get_meta("Cost Center");
		const fields = [{ fieldtype: "Section Break", label: __("Cost Center Details") }];
		[["cost_center_name", "cost_center_number", "parent_cost_center"], ["company", "is_group", "disabled"]]
			.forEach((column, columnIndex) => {
				if (columnIndex) fields.push({ fieldtype: "Column Break" });
				column.forEach((fieldname) => {
					const source = meta.fields.find((field) => field.fieldname === fieldname);
					fields.push({
						fieldname,
						fieldtype: source.fieldtype,
						label: __(source.label),
						options: source.options,
						reqd: source.reqd,
						default: doc[fieldname],
						read_only: Boolean(name && fieldname === "company"),
					});
				});
			});
		const dialog = new frappe.ui.Dialog({
			title: name ? __("Edit Cost Center · {0}", [doc.cost_center_name || name]) : __("New Cost Center"),
			fields,
			primary_action_label: name ? __("Save Changes") : __("Create Cost Center"),
			primary_action: async (values) => {
				dialog.disable_primary_action();
				try {
					await frappe.xcall("karyo.desk.accounts_master.save", {
						master_type: "Cost Center",
						name,
						values,
					});
					dialog.hide();
					frappe.show_alert({ indicator: "green", message: name ? __("Cost Center updated") : __("Cost Center created") });
					await load();
				} catch (error) {
					frappe.show_alert({ indicator: "red", message: karyo.ui?.error_message(error) || error?.message || __("The Cost Center could not be saved.") }, 7);
				} finally {
					dialog.enable_primary_action();
				}
			},
		});
		dialog.$wrapper.addClass("mbc-company-drawer accounts-master-drawer").removeClass("karyo-managed-modal");
		dialog.set_secondary_action_label(__("Close"));
		dialog.set_secondary_action(() => dialog.hide());
		dialog.show();
		dialog.fields_dict.parent_cost_center.get_query = () => ({
			filters: {
				company: dialog.get_value("company"),
				is_group: 1,
				...(name ? { name: ["!=", name] } : {}),
			},
		});
	}

	function remove(row) {
		frappe.confirm(
			__("Delete Cost Center {0}? Linked or parent records remain protected.", [frappe.utils.escape_html(row.cost_center_name || row.name)]),
			async () => {
				try {
					await frappe.xcall("karyo.desk.accounts_master.delete", { master_type: "Cost Center", name: row.name });
					frappe.show_alert({ indicator: "green", message: __("Cost Center deleted") });
					await load();
				} catch (error) {
					frappe.show_alert({ indicator: "red", message: karyo.ui?.error_message(error) || error?.message || __("The Cost Center could not be deleted.") }, 7);
				}
			}
		);
	}

	async function load() {
		const response = await frappe.xcall("karyo.desk.accounts_master.cost_center_master", {
			company: $company.val() || "",
			search: $search.val() || "",
		});
		permissions = response.permissions || {};
		$body.closest(".karyo-page").find(".karyo-page-actions .btn-primary").toggle(Boolean(permissions.create));
		if (!$company.children().length) {
			$company.append($("<option></option>").val("").text(__("All Companies")));
			(response.companies || []).forEach((company) =>
				$company.append($("<option></option>").val(company).text(company))
			);
		}
		const rows = response.records || [];
		$count.text(__("{0} of {0}", [rows.length]));
		const $tbody = $card.find("tbody").empty();
		if (!rows.length) {
			$("<tr><td colspan=\"5\" class=\"accounts-master-empty\"></td></tr>")
				.find("td").text(__("No Cost Centers match these filters.")).end().appendTo($tbody);
			return;
		}
		rows.forEach((row) => {
			const $row = $("<tr></tr>").appendTo($tbody);
			$("<td class=\"master-list-check\"><input type=\"checkbox\" class=\"master-row-check\"></td>").appendTo($row);
			$("<td class=\"master-list-code\"><strong></strong></td>").find("strong").text(row.cost_center_number || row.name).end().appendTo($row);
			$("<td class=\"master-list-name\"><strong></strong><small></small></td>")
				.find("strong").text(row.cost_center_name || row.name).end()
				.find("small").text(row.is_group ? __("Group") : __("Ledger")).end()
				.appendTo($row);
			$("<td></td>").text(row.company || "—").appendTo($row);
			const $actions = $("<td class=\"accounts-master-actions\"></td>").appendTo($row);
			$("<button type=\"button\" class=\"btn btn-xs btn-default\"></button>").text(__("Edit")).prop("disabled", Boolean(row.locked) || !permissions.write).attr("title", row.locked ? __("The root Cost Center cannot be edited") : "").on("click", () => open_editor(row.name)).appendTo($actions);
			$("<button type=\"button\" class=\"btn btn-xs btn-danger\"></button>").text(__("Delete")).prop("disabled", Boolean(row.locked) || !permissions.delete).attr("title", row.locked ? __("The root Cost Center cannot be deleted") : "").on("click", () => remove(row)).appendTo($actions);
		});
	}

	let timer;
	$company.on("change", load);
	$card.find(".master-check-all").on("change", (event) =>
		$card.find(".master-row-check").prop("checked", event.currentTarget.checked)
	);
	$search.on("input", () => {
		clearTimeout(timer);
		timer = setTimeout(load, 250);
	});
	load().catch((error) => frappe.show_alert({
		indicator: "red",
		message: karyo.ui?.error_message(error) || __("Cost Centers could not be loaded."),
	}, 7));
};
