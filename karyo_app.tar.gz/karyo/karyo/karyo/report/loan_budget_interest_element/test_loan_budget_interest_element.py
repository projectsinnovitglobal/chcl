import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.doctype.karyo_loan_settlement import test_karyo_loan_settlement as loan_helpers
from karyo.karyo.report.loan_budget_interest_element.loan_budget_interest_element import execute


class TestLoanBudgetInterestElement(FrappeTestCase):
	_assign_salary_structure = loan_helpers.TestKaryoLoanSettlement._assign_salary_structure
	_activate_loan = loan_helpers.TestKaryoLoanSettlement._activate_loan

	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		cls.company = frappe.db.get_value("Company", {}, "name")
		if cls.company and not frappe.db.exists("Loan Type", "PERSONAL"):
			frappe.get_doc({
				"doctype": "Loan Type", "loan_code": "PERSONAL", "loan_name": "Personal Loan",
				"loan_category": "Personal", "interest_rate": 6, "is_active": 1,
			}).insert(ignore_permissions=True)

	def setUp(self):
		if not self.company:
			self.skipTest("no Company on site")
		frappe.db.set_single_value("Karyo Settings", "max_deduction_pct", 40)
		frappe.db.set_single_value("Karyo Settings", "require_appraisal_payroll_cycle", 0)
		frappe.db.set_value("Loan Type", "PERSONAL", {"pdb_capital": "Karyo Loan Capital", "pdb_interest": "Karyo Loan Interest", "pdb_insurance": "Karyo Loan Insurance"}, update_modified=False)
		self.emp = frappe.get_doc({
			"doctype": "Employee", "first_name": "Budget", "last_name": "Borrower",
			"gender": frappe.db.get_value("Gender", {}, "name") or "Male",
			"date_of_birth": "1985-01-01", "date_of_joining": "2016-01-01",
			"company": self.company, "status": "Active",
		}).insert(ignore_permissions=True, ignore_mandatory=True)
		self._assign_salary_structure(self.emp.name)
		self.loan = self._activate_loan()

	def test_year_and_month_projections_use_only_current_schedule(self):
		filters = {
			"budget_from_date": "2026-01-01", "budget_to_date": "2027-12-31",
			"loan": self.loan.name,
		}
		_columns, years = execute(filters)
		self.assertEqual([row.budget_year for row in years], [2026, 2027])
		self.assertTrue(all(row.projected_interest > 0 for row in years))

		filters["projection_view"] = "Month-wise"
		_columns, months = execute(filters)
		self.assertEqual(sum(row.scheduled_instalments for row in months), 19)
		self.assertAlmostEqual(
			sum(row.projected_interest for row in months),
			sum(row.projected_interest for row in years),
			places=2,
		)
		self.assertTrue(all(row.period and row.budget_month for row in months))

		current = frappe.get_all(
			"Karyo Loan Schedule",
			filters={"parent": self.loan.name, "is_current": 1},
			fields=["*"],
			order_by="idx",
		)[0]
		duplicate = dict(current)
		for field in ("name", "creation", "modified", "owner", "modified_by"):
			duplicate.pop(field, None)
		duplicate.update({"doctype": "Karyo Loan Schedule", "parent": self.loan.name,
			"parenttype": "Karyo Loan", "parentfield": "schedule", "is_current": 0})
		frappe.get_doc(duplicate).insert(ignore_permissions=True)
		_columns, after_superseded = execute(filters)
		self.assertEqual(sum(row.scheduled_instalments for row in after_superseded), 19)

	def test_invalid_budget_period_is_rejected(self):
		with self.assertRaises(frappe.ValidationError):
			execute({"budget_from_date": "2027-01-01", "budget_to_date": "2026-01-01"})
