"""Keep the names of linked HR masters aligned with their editable key fields.

Frappe stores a Link as the target document's ``name``.  Changing only the
field used to create that name (for example ``designation_name``) therefore
leaves existing links pointing at the old spelling.  These hooks turn a key
field correction into a real document rename so Frappe updates every Link and
Dynamic Link in the same transaction.
"""

import frappe
from frappe.model.rename_doc import rename_doc


MASTER_NAME_FIELDS = {
	"Company": "company_name",
	"Branch": "branch",
	"Department": "department_name",
	"Employee Section": "section_code",
	"Designation": "designation_name",
	"Education Level": "level_name",
	"Employee Location": "location_code",
	"Employee Category": "category_code",
	"Employee Payroll Group": "payroll_group_code",
	"Employee Work Pattern": "work_pattern_code",
	"Employee Loan Eligibility Group": "eligibility_group_code",
	"Salutation": "salutation",
}


def _name_inputs_changed(doc, previous, fieldname):
	if previous.get(fieldname) != doc.get(fieldname):
		return True
	# A Department's document name includes the Company abbreviation. Moving a
	# department must therefore rename it even when its visible name is unchanged.
	return doc.doctype == "Department" and previous.get("company") != doc.get("company")


def capture_linked_master_name(doc, method=None):
	"""Remember an edited key before Frappe restores ``field:`` autoname fields.

	Frappe intentionally keeps an existing document's autoname field equal to
	its current name during validation. Capture the user's correction first and
	perform the actual rename after the document and its children have saved.
	"""
	fieldname = MASTER_NAME_FIELDS.get(doc.doctype)
	previous = doc.get_doc_before_save()
	if not fieldname or not previous or not _name_inputs_changed(doc, previous, fieldname):
		return

	requested_name = str(doc.get(fieldname) or "").strip()
	if requested_name:
		doc.flags.karyo_requested_master_name = requested_name


def sync_linked_master_name(doc, method=None):
	"""Rename an edited master and let Frappe repair all of its references."""
	requested_name = doc.flags.get("karyo_requested_master_name")
	if not requested_name:
		return

	# Department.before_rename adds the company suffix. All other configured
	# masters use the edited field value directly. rename_doc also handles
	# Dynamic Links, user defaults, attachments, versions and nested-set links.
	old_name = doc.name
	new_name = rename_doc(
		doc=doc,
		new=requested_name,
		show_alert=False,
		rebuild_search=False,
	)
	# Keep the in-flight Document consistent so save/API responses and any later
	# on_update hooks operate on the new key rather than the now-missing old key.
	doc.name = new_name
	doc.set(MASTER_NAME_FIELDS[doc.doctype], requested_name)
	# Document.run_post_save_methods tracks the in-flight key for db_set and
	# removes it after all hooks finish. Move that marker with the rename.
	old_marker = (doc.doctype, old_name)
	if old_marker in frappe.flags.currently_saving:
		frappe.flags.currently_saving.remove(old_marker)
		frappe.flags.currently_saving.append((doc.doctype, new_name))
