from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch

import frappe

from karyo.payroll.process import _employee_contribution_schemes


class TestEmployeeContributionSchemes(TestCase):
	def setUp(self):
		self.cycle = SimpleNamespace(company="MBC", payment_date="2026-09-25")
		self.slip = frappe._dict(
			employee="EMP-001", salary_structure="MONTHLY", gross_pay=10000,
		)

	@patch("karyo.payroll.process.frappe.get_all")
	@patch("karyo.payroll.process.frappe.db.get_value")
	def test_explicit_employee_group_is_the_only_scheme(self, get_value, get_all):
		get_value.return_value = "NSF-SCHEME"
		self.assertEqual(
			_employee_contribution_schemes(
				self.cycle, self.slip, ["CSG-SCHEME", "NSF-SCHEME"]
			),
			["NSF-SCHEME"],
		)
		get_all.assert_not_called()

	@patch("karyo.payroll.process.frappe.get_all")
	@patch("karyo.payroll.process.frappe.db.get_value")
	def test_legacy_employee_uses_only_structure_deduction_components(self, get_value, get_all):
		def value(doctype, name, fieldname):
			if doctype == "Employee":
				return None
			return {"CSG-CODE": "CSG", "NSF-CODE": "NSF", "PENSION-CODE": "Pension"}[name]

		get_value.side_effect = value
		get_all.side_effect = [
			["CSG", "NSF", "PAYE"],
			[
				frappe._dict(name="CSG-SCHEME", employee_pdb_code="CSG-CODE"),
				frappe._dict(name="NSF-SCHEME", employee_pdb_code="NSF-CODE"),
				frappe._dict(name="PENSION-SCHEME", employee_pdb_code="PENSION-CODE"),
			],
		]
		self.assertEqual(
			_employee_contribution_schemes(
				self.cycle, self.slip,
				["CSG-SCHEME", "NSF-SCHEME", "PENSION-SCHEME"],
			),
			["CSG-SCHEME", "NSF-SCHEME"],
		)
