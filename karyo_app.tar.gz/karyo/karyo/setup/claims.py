"""Passage Benefit claim + approval workflow scaffolding.

    bench --site dev.localhost execute karyo.setup.claims.setup

Creates the Passage Benefit Application (claim) and Adjustment DocTypes, a
'Karyo Finance' role, and an approval Workflow (Finance is the final/processing
level, PB-WKF-002). Idempotent.
"""

import frappe

from karyo.setup.foundation import f, make_doctype

WORKFLOW_STATES = [
	("Draft", ""),
	("Pending Approval", "Warning"),
	("Recommended", "Info"),
	("Approved", "Success"),
	("Rejected", "Danger"),
	("Processed", "Success"),
]
WORKFLOW_ACTIONS = ["Submit for Approval", "Recommend", "Approve", "Reject", "Process"]
FINANCE_PROCESSING_ROLES = ("Karyo Finance", "Payroll Finance", "Payroll Processor", "System Manager")


def create_role(name):
	if not frappe.db.exists("Role", name):
		frappe.get_doc({"doctype": "Role", "role_name": name, "desk_access": 1}).insert(
			ignore_permissions=True
		)
		print(f"  + Role: {name}")


def add_role_perm(doctype, role, submit=True):
	dt = frappe.get_doc("DocType", doctype)
	if any(p.role == role for p in dt.permissions):
		return
	dt.append(
		"permissions",
		{
			"role": role,
			"read": 1,
			"write": 1,
			"create": 1,
			"delete": 1,
			"submit": 1 if submit else 0,
			"cancel": 1 if submit else 0,
			"amend": 1 if submit else 0,
			"report": 1,
			"export": 1,
			"print": 1,
			"email": 1,
			"share": 1,
		},
	)
	dt.save(ignore_permissions=True)


def create_claim_doctypes():
	make_doctype(
		"Passage Benefit Application",
		is_submittable=1,
		autoname="naming_series:",
		title_field="employee_name",
		fields=[
			f("naming_series", "Select", "Series", options="PBA-.YYYY.-.#####", default="PBA-.YYYY.-.#####"),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("pb_bank", "Link", "Passage Benefit Bank", options="Passage Benefit Bank", read_only=1),
			f("company", "Link", "Company", options="Company", read_only=1),
			f("opening_date", "Date", "Opening Date", read_only=1),
			f("opening_balance", "Currency", "Opening Balance", read_only=1),
			f("amount_earned", "Currency", "Amount Earned", read_only=1),
			f("hcb", "Column Break"),
			f("posting_date", "Date", "Application Date", reqd=1, default="Today"),
			f("pay_period", "Data", "Pay Period"),
			f(
				"workflow_state",
				"Select",
				"Status",
				options="Draft\nPending Approval\nRecommended\nApproved\nRejected\nProcessed",
				default="Draft",
				read_only=1,
				in_standard_filter=1,
			),
			f("claim_sb", "Section Break", "Claim Details"),
			f(
				"usage_item",
				"Link",
				"Usage Item",
				options="Passage Benefit Usage Item",
				reqd=1,
				in_list_view=1,
			),
			f(
				"usage_item_name",
				"Data",
				"Usage Item Name",
				fetch_from="usage_item.usage_item_name",
				read_only=1,
			),
			f("encash_rate", "Percent", "Encash Rate", fetch_from="usage_item.encash_rate", read_only=1),
			f(
				"min_balance_credit",
				"Currency",
				"Minimum Balance Credit",
				fetch_from="usage_item.min_balance_credit",
				read_only=1,
			),
			f("request_amount", "Currency", "Request Amount", reqd=1, in_list_view=1),
			f("claimable_amount", "Currency", "Claimable Amount", read_only=1, in_list_view=1),
			f(
				"approved_amount",
				"Currency",
				"Approved Amount",
				read_only=1,
				description="Amount frozen when the claim is approved and used for Finance or Payroll processing.",
			),
			f("approval_date", "Date", "Approval Date", read_only=1),
			f("ccb", "Column Break"),
			f("available_balance", "Currency", "Available Balance", read_only=1),
			f(
				"processing_route",
				"Select",
				"Processing Route",
				options="Payroll\nInternal",
				default="Payroll",
			),
			f("payroll_pdb_type", "Link", "Payroll PDB Type", options="Payroll PDB Type", read_only=1),
			f("payroll_pdb_code", "Link", "Payroll PDB Code", options="Payroll PDB Code", read_only=1),
			f("pdb_component", "Link", "Payroll Component (PDB)", options="Salary Component", read_only=1),
			f("supporting_document", "Attach", "Supporting Document"),
			f("travel_sb", "Section Break", "Travel Details"),
			f("travel_agent", "Data", "Travel Agent"),
			f("passengers", "Table", "Passengers", options="Passage Benefit Passenger"),
			f("trips_sb", "Section Break", "Trips"),
			f("trips", "Table", "Trips", options="Passage Benefit Trip"),
			f("proc_sb", "Section Break", "Processing & Audit"),
			f("processing_guidance", "HTML", "Processing Guidance"),
			f("processed", "Check", "Processed", read_only=1),
			f("amount_taken", "Currency", "Amount Taken", read_only=1),
			f("processed_reference", "Data", "Processing Reference"),
			f("processed_date", "Date", "Processed Date", read_only=1),
			f(
				"payment_reference",
				"Data",
				"PDB / Payment Reference",
				read_only=1,
				description="Final payroll or Finance payment reference captured when processing completes.",
			),
			f("pcb", "Column Break"),
			f("ledger_entry", "Link", "Ledger Entry", options="Passage Benefit Ledger Entry", read_only=1),
			f("additional_salary", "Link", "Payroll Entry (Additional Salary)", options="Additional Salary", read_only=1),
			f("remarks", "Small Text", "Remarks"),
			f("migration_sb", "Section Break", "Legacy Migration Audit", collapsible=1),
			f("migration_batch", "Link", "Migration Batch", options="MBC Migration Batch", read_only=1),
			f(
				"migration_status",
				"Select",
				"Migration Status",
				options="Not Migrated\nLoaded\nReconciled\nException",
				default="Not Migrated",
				read_only=1,
			),
			f("legacy_claim_reference", "Data", "Legacy Claim / Application Ref", read_only=1),
			f("legacy_employee_code", "Data", "Legacy Employee Code", read_only=1),
			f("legacy_claim_type", "Data", "Legacy PB Usage / Claim Type", read_only=1),
			f("legacy_request_date", "Date", "Legacy Request Date", read_only=1),
			f("legacy_requested_amount", "Currency", "Legacy Requested Amount", read_only=1),
			f("migration_cb", "Column Break"),
			f("legacy_approved_amount", "Currency", "Legacy Approved Amount", read_only=1),
			f("legacy_approval_date", "Date", "Legacy Approval Date", read_only=1),
			f("legacy_status", "Data", "Legacy Status", read_only=1),
			f("legacy_processed_date", "Date", "Legacy Processed Date", read_only=1),
			f("legacy_payment_reference", "Data", "Legacy PDB / Payment Reference", read_only=1),
			f("legacy_remarks", "Small Text", "Legacy Remarks", read_only=1),
		],
	)
	make_doctype(
		"Passage Benefit Adjustment",
		is_submittable=1,
		autoname="naming_series:",
		title_field="employee_name",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="PBADJ-.YYYY.-.#####",
				default="PBADJ-.YYYY.-.#####",
			),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("pb_bank", "Link", "Passage Benefit Bank", options="Passage Benefit Bank"),
			f("posting_date", "Date", "Posting Date", reqd=1, default="Today"),
			f("cb", "Column Break"),
			f(
				"amount",
				"Currency",
				"Adjustment Amount (signed)",
				reqd=1,
				in_list_view=1,
				description="Positive increases balance; negative decreases.",
			),
			f("ledger_entry", "Link", "Ledger Entry", options="Passage Benefit Ledger Entry", read_only=1),
			f("remarks_sb", "Section Break", "Reason"),
			f("remarks", "Small Text", "Remarks", reqd=1),
		],
	)
	add_role_perm("Passage Benefit Application", "Karyo Finance")
	add_role_perm("Passage Benefit Adjustment", "Karyo Finance")
	add_role_perm("Passage Benefit Application", "Payroll Finance")
	add_role_perm("Passage Benefit Application", "Payroll Processor")


def _ensure_finance_processing_transitions(workflow):
	"""Keep PB processing reachable by the finance roles used across Payroll."""
	existing = {
		(row.state, row.action, row.next_state, row.allowed)
		for row in workflow.transitions
	}
	changed = False
	for role in FINANCE_PROCESSING_ROLES:
		key = ("Approved", "Process", "Processed", role)
		if key in existing:
			continue
		workflow.append(
			"transitions",
			{
				"state": "Approved",
				"action": "Process",
				"next_state": "Processed",
				"allowed": role,
				"allow_self_approval": 1,
			},
		)
		changed = True
	if changed:
		workflow.save(ignore_permissions=True)
		frappe.clear_cache(doctype="Workflow")
	return changed


def _ensure_system_manager_transitions(workflow):
	"""Give the administrative fallback every PB decision without reassignment."""
	existing = {
		(row.state, row.action, row.next_state, row.allowed)
		for row in workflow.transitions
	}
	changed = False
	for row in list(workflow.transitions):
		if row.allowed == "System Manager":
			continue
		key = (row.state, row.action, row.next_state, "System Manager")
		if key in existing:
			continue
		workflow.append("transitions", {
			"state": row.state,
			"action": row.action,
			"next_state": row.next_state,
			"allowed": "System Manager",
			"allow_self_approval": 1,
		})
		existing.add(key)
		changed = True
	# Users who already hold the normal decision role should see one action, not
	# a duplicate copy contributed by their System Manager fallback role.
	for admin_row in (row for row in workflow.transitions if row.allowed == "System Manager"):
		roles = sorted({
			row.allowed for row in workflow.transitions
			if row.allowed != "System Manager"
			and (row.state, row.action, row.next_state)
			== (admin_row.state, admin_row.action, admin_row.next_state)
		})
		condition = " and ".join(
			"frappe.session.user != 'Administrator' and not "
			f"frappe.db.get_value('Has Role', {{'parent': frappe.session.user, 'role': {role!r}}}, 'name')"
			for role in roles
		)
		if condition and admin_row.condition != condition:
			admin_row.condition = condition
			changed = True
	if changed:
		workflow.save(ignore_permissions=True)
		frappe.clear_cache(doctype="Workflow")
	return changed


def create_workflow():
	for state, style in WORKFLOW_STATES:
		if not frappe.db.exists("Workflow State", state):
			frappe.get_doc(
				{"doctype": "Workflow State", "workflow_state_name": state, "style": style}
			).insert(ignore_permissions=True)
	for action in WORKFLOW_ACTIONS:
		if not frappe.db.exists("Workflow Action Master", action):
			frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": action}).insert(
				ignore_permissions=True
			)

	if frappe.db.exists("Workflow", "Passage Benefit Application"):
		workflow = frappe.get_doc("Workflow", "Passage Benefit Application")
		changed = _ensure_finance_processing_transitions(workflow)
		changed = _ensure_system_manager_transitions(workflow) or changed
		print(f"  {'~' if changed else '='} Workflow exists: Passage Benefit Application")
		return

	workflow = frappe.get_doc(
		{
			"doctype": "Workflow",
			"workflow_name": "Passage Benefit Application",
			"document_type": "Passage Benefit Application",
			"is_active": 1,
			"override_status": 1,
			"workflow_state_field": "workflow_state",
			"send_email_alert": 0,
			"states": [
				{"state": "Draft", "doc_status": "0", "allow_edit": "HR User"},
				{"state": "Pending Approval", "doc_status": "0", "allow_edit": "HR Manager"},
				{"state": "Recommended", "doc_status": "0", "allow_edit": "HR Manager"},
				{"state": "Approved", "doc_status": "0", "allow_edit": "Karyo Finance"},
				{"state": "Rejected", "doc_status": "0", "allow_edit": "HR User"},
				{"state": "Processed", "doc_status": "1", "allow_edit": "Karyo Finance"},
			],
			"transitions": [
				{
					"state": "Draft",
					"action": "Submit for Approval",
					"next_state": "Pending Approval",
					"allowed": "HR User",
				},
				{
					"state": "Pending Approval",
					"action": "Recommend",
					"next_state": "Recommended",
					"allowed": "HR Manager",
				},
				{
					"state": "Pending Approval",
					"action": "Reject",
					"next_state": "Rejected",
					"allowed": "HR Manager",
				},
				{
					"state": "Recommended",
					"action": "Approve",
					"next_state": "Approved",
					"allowed": "HR Manager",
				},
				{
					"state": "Recommended",
					"action": "Reject",
					"next_state": "Rejected",
					"allowed": "HR Manager",
				},
				{
					"state": "Approved",
					"action": "Process",
					"next_state": "Processed",
					"allowed": "Karyo Finance",
				},
				{
					"state": "Approved",
					"action": "Reject",
					"next_state": "Rejected",
					"allowed": "Karyo Finance",
				},
			],
		}
	).insert(ignore_permissions=True)
	_ensure_finance_processing_transitions(workflow)
	_ensure_system_manager_transitions(workflow)
	print("  + Workflow: Passage Benefit Application")


def setup():
	print("Karyo Passage Benefit claims setup:")
	create_role("Karyo Finance")
	create_claim_doctypes()
	create_workflow()
	frappe.db.commit()
	print("Done.")
