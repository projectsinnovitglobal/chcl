"""Karyo Loan — event-sourced ledger + history (Phase 2).

    bench --site dev.localhost execute karyo.setup.loan_ledger.setup

Creates Karyo Loan Ledger Entry (every capital/interest/insurance movement,
advance payment, refund and settlement as a debit/credit line — BR-FAR-LMS-QRY-004)
and Karyo Loan History (before/after snapshots for advance payment, change in
period, recompute and settlement — QRY-003). Both are append-only records posted
by the loan controllers via karyo.loan.ledger. Idempotent.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype

LEDGER_REF_TYPES = "\n".join(
	[
		"Application Created",
		"Workflow Transition",
		"Approval",
		"Rejection",
		"Return for Rework",
		"Disbursement",
		"Disbursement Reversal",
		"Payment",
		"Payment Reversal",
		"Loan Capital",
		"Loan Interest",
		"Loan Insurance",
		"Loan Capital Reversal",
		"Loan Interest Reversal",
		"Loan Insurance Reversal",
		"Advance Payment",
		"Advance Payment Reversal",
		"Refund",
		"Refund Reversal",
		"Settlement",
		"Settlement Reversal",
		"Interest Waiver",
		"Interest Waiver Reversal",
		"Recast",
	]
)

HISTORY_EVENT_TYPES = "\n".join(
	[
		"Advance Payment",
		"Change in Period",
		"Recast",
		"Interest Change",
		"Insurance Change",
		"Correction",
		"Settlement",
	]
)


def create_doctypes():
	make_doctype(
		"Karyo Loan Ledger Entry",
		autoname="naming_series:",
		title_field="loan",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="KLLE-.YYYY.-.#####",
				default="KLLE-.YYYY.-.#####",
			),
			f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
			f("employee", "Link", "Employee", options="Employee", in_list_view=1),
			f("ref_type", "Select", "Ref Type", options=LEDGER_REF_TYPES, reqd=1, in_list_view=1),
			f("period", "Data", "Pay Period"),
			f("cb1", "Column Break"),
			f("date_processed", "Date", "Date Processed", reqd=1, in_list_view=1),
			f("transaction_date", "Date", "Transaction Date"),
			f("reference", "Data", "Reference"),
			f("amounts_sb", "Section Break", "Amounts"),
			f("debit", "Currency", "Debit", in_list_view=1),
			f("credit", "Currency", "Credit", in_list_view=1),
			f("cb2", "Column Break"),
			f("balance_after", "Currency", "Balance After"),
			f("ref_sb", "Section Break", "Source & Audit"),
			f("source_doctype", "Link", "Source DocType", options="DocType"),
			f("source_name", "Dynamic Link", "Source Name", options="source_doctype"),
			f("remarks", "Small Text", "Remarks"),
		],
	)
	make_doctype(
		"Karyo Loan History",
		autoname="naming_series:",
		title_field="loan",
		fields=[
			f("naming_series", "Select", "Series", options="KLH-.YYYY.-.#####", default="KLH-.YYYY.-.#####"),
			f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
			f("serial_no", "Int", "Serial No.", in_list_view=1),
			f("event_type", "Select", "Event Type", options=HISTORY_EVENT_TYPES, reqd=1, in_list_view=1),
			f("effective_date", "Date", "Effective Date", in_list_view=1),
			f("cb1", "Column Break"),
			f("amount_paid", "Currency", "Amount Paid / Refunded"),
			f("new_duration", "Int", "New Duration (Months)"),
			f("reference", "Data", "Reference"),
			f("before_sb", "Section Break", "Position at Effective Date"),
			f("outstanding_capital", "Currency", "Outstanding Capital"),
			f("outstanding_interest", "Currency", "Outstanding Interest"),
			f("after_sb", "Section Break", "Recomputed Monthly Components"),
			f("new_monthly_capital", "Currency", "New Monthly Capital"),
			f("new_monthly_interest", "Currency", "New Monthly Interest"),
			f("cb2", "Column Break"),
			f("new_monthly_insurance", "Currency", "New Monthly Insurance"),
			f("remarks", "Small Text", "Remarks"),
		],
	)


def setup():
	print("Karyo Loan ledger setup:")
	create_doctypes()
	create_custom_fields({"Karyo Loan History": [
		{"fieldname": "source_doctype", "fieldtype": "Link", "label": "Source DocType", "options": "DocType", "read_only": 1, "insert_after": "reference"},
		{"fieldname": "source_name", "fieldtype": "Dynamic Link", "label": "Source Name", "options": "source_doctype", "read_only": 1, "insert_after": "source_doctype"},
		{"fieldname": "idempotency_key", "fieldtype": "Data", "label": "Idempotency Key", "read_only": 1, "unique": 1, "insert_after": "source_name"},
		{"fieldname": "before_snapshot", "fieldtype": "Long Text", "label": "Before Snapshot", "read_only": 1, "insert_after": "idempotency_key"},
		{"fieldname": "after_snapshot", "fieldtype": "Long Text", "label": "After Snapshot", "read_only": 1, "insert_after": "before_snapshot"},
	]}, ignore_validate=True)
	frappe.db.commit()
	print("Done.")
