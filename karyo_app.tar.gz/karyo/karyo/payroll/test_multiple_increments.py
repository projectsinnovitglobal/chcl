from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.payroll.bulk import _legacy_context, _scale_context


class TestMultipleIncrements(FrappeTestCase):
	@patch("karyo.payroll.bulk.frappe.get_doc")
	@patch("karyo.payroll.bulk.approved_appointment")
	def test_two_points_at_100_each_increase_salary_by_200(self, appointment, get_doc):
		appointment.return_value = frappe._dict(
			name="APT-1", pay_basis="Grade Scale", salary_scale="SCALE-1", salary_point=1,
		)
		get_doc.return_value = frappe._dict(
			docstatus=1,
			points=[frappe._dict(salary_point=1, salary=10000), frappe._dict(salary_point=2, salary=10100), frappe._dict(salary_point=3, salary=10200)],
			bands=[frappe._dict(salary=10000, increment=100, increment_band="BAND-1")],
		)
		result = _scale_context(frappe._dict(name="EMP-1"), "2026-07-01", True, 2)
		self.assertEqual(result["proposed_salary_point"], "3")
		self.assertEqual(result["increment_amount"], 200)
		self.assertEqual(result["increment_steps"], 2)
		self.assertEqual(result["applied_increment_points"], 2)
		appointment.assert_called_once_with("EMP-1", "2026-07-01")

	@patch("karyo.payroll.bulk.frappe.get_doc")
	@patch("karyo.payroll.bulk.approved_appointment")
	def test_points_are_capped_at_the_effective_scale_top(self, appointment, get_doc):
		appointment.return_value = frappe._dict(
			name="APT-1", pay_basis="Grade Scale", salary_scale="SCALE-1", salary_point=2,
		)
		get_doc.return_value = frappe._dict(
			docstatus=1,
			points=[frappe._dict(salary_point=1, salary=10000), frappe._dict(salary_point=2, salary=10100), frappe._dict(salary_point=3, salary=10200)],
			bands=[frappe._dict(salary=10000, increment=100, increment_band="BAND-1")],
		)
		result = _scale_context(frappe._dict(name="EMP-1"), "2026-07-01", True, 5)
		self.assertEqual(result["proposed_salary_point"], "3")
		self.assertEqual(result["increment_amount"], 100)
		self.assertEqual(result["increment_steps"], 5)
		self.assertEqual(result["applied_increment_points"], 1)

	@patch("karyo.payroll.bulk.frappe.db.get_value", return_value=None)
	@patch("karyo.payroll.bulk.build_lookups")
	def test_legacy_prb_employee_can_receive_multiple_points(self, lookups, _get_value):
		lookups.return_value = ({"001": 10000, "002": 10100, "003": 10200}, ["001", "002", "003"])
		employee = frappe._dict(name="EMP-1", karyo_prb_salary_point="001", karyo_prb_grade=None)
		with patch("karyo.payroll.bulk.convert_salary_point", return_value={"revised_salary_2026": 10000}), patch(
			"karyo.setup.payroll_profiles.prb_salary_value", side_effect=lambda point, **kwargs: {"001": 10000, "002": 10100, "003": 10200}[point]
		):
			result = _legacy_context(employee, True, 2)
		self.assertEqual(result["proposed_salary_point"], "003")
		self.assertEqual(result["increment_amount"], 200)
		self.assertEqual(result["applied_increment_points"], 2)
