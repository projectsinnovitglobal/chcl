"""Payroll master, employee mapping and dated Pay Day integration."""

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.desk.payroll_management import screen_data
from karyo.setup.payroll_profiles import (
	apply,
	company_profile_defaults,
	prepare_employee_profile,
	prb_salary_point_options,
	validate_employee_profile,
)


class TestPayrollProfiles(FrappeTestCase):
	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		apply()

	def test_seeded_masters_are_available_in_payroll_menu_screens(self):
		self.assertEqual(frappe.db.get_value("Payroll Type", "Major", "processing_scope"), "Regular and once-off")
		self.assertEqual(frappe.db.get_value("Payroll Type", "Minor", "processing_scope"), "Once-off only")
		types = screen_data("payrolltypes")["list"]
		groups = screen_data("payrollgroups")["list"]
		pay_days = screen_data("paydaymasters")["list"]
		self.assertEqual(types["doctype"], "Payroll Type")
		self.assertGreaterEqual(types["count"], 2)
		self.assertEqual(groups["doctype"], "Employee Payroll Group")
		self.assertGreater(groups["count"], 0)
		self.assertEqual(pay_days["doctype"], "Pay Day")
		self.assertGreater(pay_days["count"], 0)

	def test_dated_pay_days_and_employees_use_the_same_masters(self):
		pay_day = frappe.get_all(
			"Payroll Pay Day",
			filters={"pay_day_master": ("is", "set")},
			fields=["name", "company", "payroll_type", "pay_day_master"],
			limit_page_length=1,
		)[0]
		master = frappe.db.get_value(
			"Pay Day", pay_day.pay_day_master, ["company", "payroll_type", "payroll_group", "is_active"], as_dict=True
		)
		self.assertEqual(master.company, pay_day.company)
		self.assertEqual(master.payroll_type, pay_day.payroll_type)
		self.assertTrue(master.is_active)
		employee_filters = {"company": pay_day.company, "karyo_pay_day": pay_day.pay_day_master}
		if master.payroll_group:
			employee_filters["karyo_payroll_group"] = master.payroll_group
		employees = frappe.get_all(
			"Employee",
			filters=employee_filters,
			fields=["name", "company", "karyo_payroll_group", "karyo_payroll_type", "karyo_pay_day"],
			limit_page_length=1,
		)
		if not employees:
			self.skipTest("No employee is assigned to the selected dated Pay Day master")
		employee = employees[0]
		self.assertTrue(employee.karyo_payroll_type)
		self.assertTrue(employee.karyo_pay_day)
		validate_employee_profile(employee)

	def test_unambiguous_company_pay_day_defaults_its_payroll_group(self):
		pay_day = frappe.get_all(
			"Pay Day", filters={"is_active": 1, "payroll_group": ("is", "set")},
			fields=["name", "company", "payroll_type", "payroll_group"], limit_page_length=0,
		)
		candidate = next((row for row in pay_day if frappe.db.count("Pay Day", {
			"company": row.company, "payroll_type": row.payroll_type, "is_active": 1,
		}) == 1), None)
		if not candidate:
			self.skipTest("No company/payroll type has exactly one active Pay Day")
		defaults = company_profile_defaults(candidate.company, payroll_type=candidate.payroll_type)
		self.assertEqual(defaults["pay_day"], candidate.name)
		self.assertEqual(defaults["payroll_group"], candidate.payroll_group)
		self.assertEqual(
			defaults["salary_currency"],
			frappe.db.get_value("Company", candidate.company, "default_currency"),
		)

	def test_employee_mapping_rejects_cross_company_pay_day(self):
		companies = frappe.get_all("Company", pluck="name", limit_page_length=2)
		if len(companies) < 2:
			self.skipTest("Cross-company validation needs two companies")
		master = frappe.db.get_value("Pay Day", {"company": companies[0]}, ["name", "payroll_type"], as_dict=True)
		if not master:
			self.skipTest("First company has no Pay Day master")
		employee = frappe._dict(
			company=companies[1], karyo_payroll_type=master.payroll_type,
			karyo_pay_day=master.name, karyo_payroll_group=None,
		)
		with self.assertRaisesRegex(frappe.ValidationError, "different company"):
			validate_employee_profile(employee)

	def test_restricted_pay_day_supplies_its_payroll_group(self):
		master = frappe.db.get_value(
			"Pay Day", {"is_active": 1, "payroll_group": ("is", "set")},
			["name", "company", "payroll_type", "payroll_group"], as_dict=True,
		)
		self.assertTrue(master)
		employee = frappe.new_doc("Employee")
		employee.company = master.company
		employee.karyo_payroll_type = master.payroll_type
		employee.karyo_pay_day = master.name
		employee.karyo_payroll_group = "Wrong Group"
		prepare_employee_profile(employee)
		self.assertEqual(employee.karyo_payroll_group, master.payroll_group)
		validate_employee_profile(employee)

	def test_employee_payroll_uses_one_open_prb_pb_profile(self):
		fields = {
			row.fieldname: row for row in frappe.get_all(
				"Custom Field", filters={"dt": "Employee"},
				fields=["fieldname", "label", "fieldtype", "insert_after", "collapsible"],
				limit_page_length=0,
			)
		}
		self.assertEqual(fields["karyo_hr_sb"].label, "PRB & PB Settings")
		self.assertEqual(fields["karyo_hr_sb"].insert_after, "salary_information")
		self.assertFalse(fields["karyo_hr_sb"].collapsible)
		self.assertEqual(fields["karyo_payroll_group"].insert_after, "karyo_hr_sb")
		self.assertEqual(fields["karyo_prb_salary_point"].fieldtype, "Select")
		self.assertEqual(fields["karyo_pb_bank"].insert_after, "karyo_salary_effective_from")
		self.assertEqual(fields["karyo_legacy_employee_id"].insert_after, "employee_number")

	def test_confirmation_and_retirement_dates_sync_from_standard_fields(self):
		employee = frappe.new_doc("Employee")
		employee.final_confirmation_date = "2024-02-01"
		employee.date_of_retirement = "2044-02-01"
		prepare_employee_profile(employee)
		self.assertEqual(employee.karyo_date_confirmed, employee.final_confirmation_date)
		self.assertEqual(employee.karyo_retirement_date, employee.date_of_retirement)

	def test_prb_salary_point_dropdown_comes_from_master(self):
		options = prb_salary_point_options()
		self.assertTrue(options["review_year"])
		self.assertGreater(len(options["values"]), 1)
		self.assertTrue(frappe.db.exists("PRB Salary Point", {"salary_point": options["values"][0]}))
