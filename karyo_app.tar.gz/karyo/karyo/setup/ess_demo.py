"""Idempotent, realistic demo history for the controlled ESS test account."""

from datetime import date, datetime, time, timedelta

import frappe
from frappe.utils import add_days, get_last_day

USER = "employee.test@sil.mu"
EMPLOYEE = "HR-EMP-00078"
COMPANY = "MBC"
YEAR_START = date(2026, 1, 1)
YEAR_END = date(2026, 12, 31)


def _exists(doctype, filters):
	return frappe.db.exists(doctype, filters)


def _insert(values, submit=False):
	doc = frappe.get_doc(values)
	doc.insert(ignore_permissions=True, ignore_mandatory=True)
	if submit:
		doc.submit()
	return doc


def _safe(label, callback):
	frappe.db.savepoint("ess_demo")
	try:
		return callback()
	except Exception as exc:
		frappe.db.rollback(save_point="ess_demo")
		print(f"  skip {label}: {str(exc)[:180]}")


def _employee_foundation():
	emp = frappe.get_doc("Employee", EMPLOYEE)
	emp.department = "Administration - MAI" if frappe.db.exists("Department", "Administration - MAI") else None
	emp.designation = "Clerk" if frappe.db.exists("Designation", "Clerk") else None
	emp.holiday_list = "Mauritius Public Holidays 2026"
	emp.shift_request_approver = "hr.test@sil.mu"
	emp.date_of_joining = YEAR_START
	emp.company = COMPANY
	emp.user_id = USER
	emp.save(ignore_permissions=True)

	for leave_type, days in (("Annual Leave", 22), ("Sick Leave", 15), ("Casual Leave", 10)):
		if _exists("Leave Allocation", {"employee": EMPLOYEE, "leave_type": leave_type, "from_date": YEAR_START}):
			continue
		_safe(
			f"{leave_type} allocation",
			lambda lt=leave_type, n=days: _insert(
				{
					"doctype": "Leave Allocation",
					"employee": EMPLOYEE,
					"leave_type": lt,
					"from_date": YEAR_START,
					"to_date": YEAR_END,
					"new_leaves_allocated": n,
				},
				submit=True,
			),
		)

	if not _exists("Shift Assignment", {"employee": EMPLOYEE, "shift_type": "Day Shift"}):
		_safe(
			"shift assignment",
			lambda: _insert(
				{
					"doctype": "Shift Assignment",
					"employee": EMPLOYEE,
					"company": COMPANY,
					"shift_type": "Day Shift",
					"start_date": YEAR_START,
					"status": "Active",
				},
				submit=True,
			),
		)


def _leave_history():
	applications = (
		("Annual Leave", date(2026, 2, 16), date(2026, 2, 18), "Family staycation", "Approved", True),
		("Sick Leave", date(2026, 4, 7), date(2026, 4, 8), "Medical appointment and recovery", "Approved", True),
		("Casual Leave", date(2026, 6, 12), date(2026, 6, 12), "Personal appointment", "Approved", True),
		("Annual Leave", date(2026, 7, 20), date(2026, 7, 24), "Mid-year family holiday", "Approved", True),
		("Annual Leave", date(2026, 9, 14), date(2026, 9, 18), "Planned overseas travel", "Open", False),
		("Casual Leave", date(2026, 8, 28), date(2026, 8, 28), "Family commitment", "Open", False),
	)
	for leave_type, start, end, reason, status, submit in applications:
		if _exists("Leave Application", {"employee": EMPLOYEE, "from_date": start}):
			continue
		_safe(
			f"leave {start}",
			lambda lt=leave_type, s=start, e=end, r=reason, st=status, sub=submit: _insert(
				{
					"doctype": "Leave Application",
					"employee": EMPLOYEE,
					"company": COMPANY,
					"leave_type": lt,
					"from_date": s,
					"to_date": e,
					"posting_date": add_days(s, -10),
					"description": r,
					"status": st,
					"leave_approver": "hr.test@sil.mu",
				},
				submit=sub,
			),
		)


def _attendance_history():
	leave_dates = set()
	for row in frappe.get_all(
		"Leave Application",
		filters={"employee": EMPLOYEE, "docstatus": 1},
		fields=["from_date", "to_date"],
	):
		day = row.from_date
		while day <= row.to_date:
			leave_dates.add(day)
			day += timedelta(days=1)

	day = date(2026, 1, 5)
	end = date(2026, 8, 19)
	while day <= end:
		if day.weekday() < 5 and day not in leave_dates:
			status = "Absent" if day in (date(2026, 3, 13), date(2026, 5, 29)) else "Present"
			if not _exists("Attendance", {"employee": EMPLOYEE, "attendance_date": day}):
				_safe(
					f"attendance {day}",
					lambda d=day, st=status: _insert(
						{"doctype": "Attendance", "employee": EMPLOYEE, "attendance_date": d, "status": st},
						submit=True,
					),
				)
			if status == "Present":
				minute = (day.day * 7) % 25
				for log_type, at in (("IN", time(8, 32 + minute)), ("OUT", time(16, 35 + minute))):
					stamp = datetime.combine(day, at)
					if not _exists("Employee Checkin", {"employee": EMPLOYEE, "time": stamp}):
						_safe(
							f"checkin {stamp}",
							lambda t=stamp, kind=log_type: _insert(
								{"doctype": "Employee Checkin", "employee": EMPLOYEE, "time": t, "log_type": kind}
							),
						)
		day += timedelta(days=1)

	if not _exists("Attendance Request", {"employee": EMPLOYEE, "from_date": date(2026, 3, 13)}):
		_safe(
			"attendance request",
			lambda: _insert(
				{
					"doctype": "Attendance Request",
					"employee": EMPLOYEE,
					"from_date": date(2026, 3, 13),
					"to_date": date(2026, 3, 13),
					"reason": "Work From Home",
					"explanation": "Worked remotely while waiting for a home repair appointment.",
				},
			),
		)


def _payroll_history():
	if not _exists("Salary Structure Assignment", {"employee": EMPLOYEE, "salary_structure": "MAI Staff Structure"}):
		_safe(
			"salary assignment",
			lambda: _insert(
				{
					"doctype": "Salary Structure Assignment",
					"employee": EMPLOYEE,
					"salary_structure": "MAI Staff Structure",
					"company": COMPANY,
					"from_date": YEAR_START,
					"base": 38500,
					"variable": 0,
					"income_tax_slab": "Mauritius PAYE 2025-26",
				},
				submit=True,
			),
		)

	for month in range(1, 8):
		start = date(2026, month, 1)
		end = get_last_day(start)
		if _exists("Salary Slip", {"employee": EMPLOYEE, "start_date": start}):
			continue
		_safe(
			f"salary slip {start:%b}",
			lambda s=start, e=end: _insert(
				{
					"doctype": "Salary Slip",
					"employee": EMPLOYEE,
					"company": COMPANY,
					"start_date": s,
					"end_date": e,
					"posting_date": e,
				},
				submit=True,
			),
		)


def _claims_and_requests():
	claims = (
		(date(2026, 4, 17), "Travel", 780, "Taxi for client meeting in Ebène", True),
		(date(2026, 4, 24), "Meals", 1250, "Working lunch during quarterly workshop", True),
		(date(2026, 5, 14), "Fuel", 1680, "Fuel for field visit to Flacq", True),
		(date(2026, 7, 9), "Training & Seminars", 4500, "Excel reporting masterclass", True),
		(date(2026, 8, 17), "Travel", 920, "Transport for supplier site visit", False),
	)
	payable = frappe.db.get_value("Account", {"company": COMPANY, "account_type": "Payable", "is_group": 0}, "name")
	cost_center = frappe.db.get_value("Company", COMPANY, "cost_center")
	for posting_date, expense_type, amount, description, submit in claims:
		if _exists("Expense Claim", {"employee": EMPLOYEE, "posting_date": posting_date}):
			continue
		_safe(
			f"claim {posting_date}",
			lambda d=posting_date, et=expense_type, amt=amount, desc=description, sub=submit: _insert(
				{
					"doctype": "Expense Claim",
					"employee": EMPLOYEE,
					"company": COMPANY,
					"expense_approver": "hr.test@sil.mu",
					"approval_status": "Approved" if sub else "Draft",
					"posting_date": d,
					"payable_account": payable,
					"cost_center": cost_center,
					"expenses": [{"expense_date": d, "expense_type": et, "description": desc, "amount": amt, "sanctioned_amount": amt if sub else 0, "cost_center": cost_center}],
				},
				submit=sub,
			),
		)

	advance_account = frappe.db.get_value("Account", {"company": COMPANY, "account_type": "Receivable", "is_group": 0}, "name")
	if advance_account and not _exists("Employee Advance", {"employee": EMPLOYEE}):
		_safe(
			"employee advance",
			lambda: _insert(
				{
					"doctype": "Employee Advance", "employee": EMPLOYEE, "company": COMPANY,
					"posting_date": date(2026, 8, 10), "advance_amount": 6000,
					"purpose": "Advance for September training and travel", "advance_account": advance_account,
					"exchange_rate": 1,
				},
			),
		)

	if not _exists("Shift Request", {"employee": EMPLOYEE}):
		_safe(
			"shift request",
			lambda: _insert(
				{
					"doctype": "Shift Request", "employee": EMPLOYEE, "company": COMPANY,
					"shift_type": "Day Shift", "from_date": date(2026, 8, 24),
					"to_date": date(2026, 8, 28), "approver": "hr.test@sil.mu",
				},
			),
		)


def seed():
	if not frappe.db.exists("Employee", {"name": EMPLOYEE, "user_id": USER}):
		frappe.throw(f"Mapped employee not found for {USER}")
	print(f"Seeding ESS demo history for {EMPLOYEE} ({USER})")
	_employee_foundation()
	_leave_history()
	_attendance_history()
	_payroll_history()
	_claims_and_requests()
	frappe.db.commit()
	frappe.clear_cache(user=USER)
	print("ESS demo history ready")
