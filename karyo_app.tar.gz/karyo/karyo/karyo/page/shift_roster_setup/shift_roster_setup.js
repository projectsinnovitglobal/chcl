frappe.pages["shift-roster-setup"].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({
		parent: wrapper,
		title: __("Shift & Roster Setup"),
		single_column: true,
	});
	const esc = value => frappe.utils.escape_html(String(value ?? ""));
	const preset = Array.isArray(frappe.route_options?.shift_roster_employees)
		? [...frappe.route_options.shift_roster_employees] : [];
	if (frappe.route_options?.shift_roster_employees) delete frappe.route_options.shift_roster_employees;
	const state = {
		selected: preset,
		employee_group: "", work_pattern: "", shift_type: "", holiday_list: "",
		shift_location: "", assignment_mode: "direct", shift_schedule: "",
		effective_from: frappe.datetime.get_today(), defaults: {}, controls: {}, data: null,
		rostered: [], employee_control: null,
	};
	const $root = $('<div class="karyo-payroll-management karyo-shift-roster-setup"><div class="pm-content"></div></div>').appendTo(page.body);
	const $content = $root.find(".pm-content");

	const route = (...parts) => frappe.set_route(...parts);
	const common = (rows, getter) => {
		const values = rows.map(getter).map(value => value || "");
		return values.length && values.every(value => value === values[0]) ? values[0] : "";
	};
	const focusControl = fieldname => {
		const control = state.controls[fieldname];
		if (!control) return;
		control.$wrapper?.[0]?.scrollIntoView({behavior: "smooth", block: "center"});
		setTimeout(() => control.$input?.trigger("focus"), 250);
	};
	const blocker = (label, fieldname, targetRoute) => `<button type="button" class="srs-blocker" ${fieldname ? `data-focus="${esc(fieldname)}"` : ""} ${targetRoute ? `data-route="${esc(targetRoute)}"` : ""}>${esc(label)} <span aria-hidden="true">→</span></button>`;
	const step = ({number, label, complete, current, locked, description, body, blockers = []}) => `
		<section class="pm-steprow srs-step${complete ? " done" : ""}${current ? " next" : ""}${locked ? " blocked" : ""}" data-step="${number}">
			<span class="pm-stepno">${complete ? "✓" : number}</span>
			<div class="pm-stepbody"><div class="srs-step-title"><div><strong>${esc(__(`Step ${number} — ${label}`))}</strong><small>${esc(complete ? __("Complete") : current ? __("Current step") : locked ? __("Waiting for a dependency") : __("Ready"))}</small></div></div>
				<p class="pm-muted">${esc(description)}</p>${blockers.length ? `<div class="srs-blockers">${blockers.join("")}</div>` : ""}${body || ""}
			</div>
		</section>`;
	const rosteredTable = () => `<section class="pm-card srs-rostered-register"><div class="pm-card-head"><div><h3>${__("Employees with Roster Setup")}</h3><p class="pm-muted">${__("View every active recurring shift or roster assignment. Use Edit setup to load the employee's assigned values and update them through the guided steps below.")}</p></div><span class="pm-chip info">${__("{0} employees", [state.rostered.length])}</span></div><div class="pm-table-wrap"><table class="pm-table srs-rostered-table"><thead><tr><th>${__("Employee")}</th><th>${__("Group")}</th><th>${__("Work Pattern")}</th><th>${__("Roster Shift")}</th><th>${__("Roster Schedule")}</th><th>${__("Effective From")}</th><th>${__("Actions")}</th></tr></thead><tbody>${state.rostered.map(row => `<tr><td><strong>${esc(row.employee_name || row.name)}</strong><small>${esc(row.name)}</small></td><td>${esc(row.karyo_employee_group || "—")}</td><td>${esc(row.karyo_work_pattern || "—")}</td><td>${esc(row.assignment?.karyo_shift_type || "—")}</td><td>${esc(row.assignment?.shift_schedule || __("Direct recurring shift"))}</td><td>${esc(row.assignment?.karyo_rotation_anchor_date || (row.assignment?.create_shifts_after ? frappe.datetime.add_days(row.assignment.create_shifts_after, 1) : "—"))}</td><td><div class="srs-row-actions"><button type="button" class="pm-btn small srs-view-roster" data-employee="${esc(row.name)}">${__("View")}</button><button type="button" class="pm-btn small primary srs-edit-roster" data-employee="${esc(row.name)}">${__("Edit setup")}</button></div></td></tr>`).join("") || `<tr><td colspan="7">${__("No employees have an active recurring roster setup yet.")}</td></tr>`}</tbody></table></div></section>`;

	async function loadOptions() {
		const data = await frappe.xcall("karyo.hr.roster.shift_roster_setup_status");
		state.options = data.employee_options || [];
		state.master_counts = data.master_counts || {};
		state.rostered = data.rostered_rows || [];
		renderSelection();
	}

	function renderSelection() {
		$content.html(`<div class="pm-hero"><div class="pm-title"><h2>${__("Shift & Roster Setup")}</h2><p>${__("Bind attendance settings to one employee or apply the same setup to several employees. Each step unlocks only when its dependency is complete.")}</p><span class="pm-path">${__("Attendance")} → ${__("Employee selection")} → ${__("Group")} → ${__("Pattern & calendar")} → ${__("Shift")} → ${__("Roster assignment")}</span></div></div>
			<div class="pm-card srs-selection-card"><h3>${__("Step 1 — Employee Selection")}</h3><p class="pm-muted">${__("Select one employee for an individual setup, or several employees when the same group, pattern, shift and roster apply to all.")}</p><div class="pm-process-toolbar"><div class="pm-process-employee-filter"></div><button type="button" class="pm-btn primary srs-load">${__("Load Setup Steps")}</button></div><div class="srs-selection-feedback" role="status"></div></div>
			<div class="srs-wizard"></div>
			${rosteredTable()}`);
		let initializing = true;
		const control = frappe.ui.form.make_control({
			parent: $content.find(".pm-process-employee-filter"), render_input: true,
			df: {fieldname: "employees", fieldtype: "MultiSelectList", label: __("Employee(s)"),
				placeholder: __("Choose one or more employees"), options: state.options,
				get_data: txt => {
					const term = String(txt || "").toLowerCase();
					return state.options.filter(option => !term || `${option.label} ${option.value} ${option.description}`.toLowerCase().includes(term));
				}, onchange: () => {
					if (!initializing) state.selected = [...(control.get_value() || [])];
				}},
		});
		state.employee_control = control;
		Promise.resolve(control.set_value(state.selected)).finally(() => { initializing = false; });
		$content.find(".srs-load").on("click", async function () {
			state.selected = [...(control.get_value() || [])];
			if (!state.selected.length) {
				$content.find(".srs-selection-feedback").text(__("Select at least one employee to open the remaining steps."));
				control.$input?.trigger("focus");
				return;
			}
			$(this).prop("disabled", true).text(__("Loading…"));
			try { await loadSetup(true); }
			finally { $(this).prop("disabled", false).text(__("Load Setup Steps")); }
		});
		$content.find(".srs-view-roster").on("click", function () { route("Form", "Employee", this.dataset.employee); });
		$content.find(".srs-edit-roster").on("click", async function () {
			state.selected = [this.dataset.employee];
			await control.set_value(state.selected);
			await loadSetup(true);
			$content.find(".srs-selection-card")[0]?.scrollIntoView({behavior: "smooth", block: "start"});
		});
		if (state.selected.length) setTimeout(() => $content.find(".srs-load").trigger("click"), 0);
	}

	async function resolveDefaults() {
		if (!state.employee_group && !state.work_pattern && !state.shift_type) {
			state.defaults = {};
			return;
		}
		state.defaults = await frappe.xcall("karyo.hr.roster.shift_roster_setup_defaults", {
			employee_group: state.employee_group || null,
			work_pattern: state.work_pattern || null,
			shift_type: state.shift_type || null,
		});
		state.work_pattern = state.defaults.work_pattern || state.work_pattern || "";
		state.shift_type = state.defaults.shift_type || state.shift_type || "";
		state.holiday_list = state.defaults.holiday_list || state.holiday_list || "";
		if (state.defaults.requires_schedule) state.assignment_mode = "schedule";
		else if (!state.assignment_mode) state.assignment_mode = "direct";
		if (state.assignment_mode === "schedule" && !state.shift_schedule && state.defaults.shift_schedule) {
			state.shift_schedule = state.defaults.shift_schedule;
		}
	}

	async function loadSetup(initialize) {
		const data = await frappe.xcall("karyo.hr.roster.shift_roster_setup_status", {employees: state.selected});
		state.data = data;
		state.master_counts = data.master_counts || state.master_counts || {};
		if (initialize) {
			const rows = data.rows || [];
			state.employee_group = common(rows, row => row.karyo_employee_group);
			state.work_pattern = common(rows, row => row.karyo_work_pattern);
			// The recurring assignment is the employee-facing source. The Employee
			// default_shift value is retained only as an internal HRMS compatibility
			// snapshot and must not be presented as a separate "profile shift".
			state.shift_type = common(rows, row => row.assignment?.karyo_shift_type);
			state.holiday_list = common(rows, row => row.holiday_list);
			state.shift_location = common(rows, row => row.assignment?.shift_location);
			state.shift_schedule = common(rows, row => row.assignment?.shift_schedule);
			const assignmentName = common(rows, row => row.assignment?.name);
			state.assignment_mode = assignmentName && state.shift_schedule ? "schedule" : "direct";
		}
		await resolveDefaults();
		renderWizard();
	}

	function makeControl(fieldname, df, value, onChange) {
		const $parent = $content.find(`[data-control="${fieldname}"]`);
		if (!$parent.length) return null;
		let initializing = true;
		const control = frappe.ui.form.make_control({parent: $parent, render_input: true, df: {fieldname, ...df}});
		state.controls[fieldname] = control;
		control.df.onchange = async () => {
			if (initializing) return;
			await onChange(control.get_value() || "");
		};
		Promise.resolve(control.set_value(value || "")).finally(() => { initializing = false; });
		return control;
	}

	function renderWizard() {
		state.controls = {};
		const rows = state.data?.rows || [];
		const hasEmployees = rows.length > 0;
		const groupDone = !!state.employee_group;
		const patternDone = groupDone && !!state.work_pattern && !!state.holiday_list;
		const shiftDone = patternDone && !!state.shift_type;
		const rosterDone = shiftDone && (state.assignment_mode === "direct" || (state.assignment_mode === "schedule" && !!state.shift_schedule));
		const completed = [hasEmployees, groupDone, patternDone, shiftDone, rosterDone].filter(Boolean).length;
		const overview = `<div class="pm-stepper">${[
			[1, __("Employees"), hasEmployees], [2, __("Group"), groupDone], [3, __("Pattern & Calendar"), patternDone],
			[4, __("Shift"), shiftDone], [5, __("Roster Assignment"), rosterDone],
		].map(([number, label, done], index) => `<button type="button" class="pm-step${done ? " done" : index === completed ? " current" : ""}" data-no="${done ? "✓" : number}" data-jump-step="${number}"><strong>${esc(label)}</strong><span>${done ? __("Complete") : index === completed ? __("Current") : __("Blocked")}</span></button>`).join("")}</div>`;
		const groupBlockers = [];
		if (!state.master_counts?.employee_groups) groupBlockers.push(blocker(__("No Employee Group exists — create one"), "", "List/Employee Group"));
		const patternBlockers = !groupDone ? [blocker(__("Select Employee Group first"), "employee_group")] : [];
		if (groupDone && !state.master_counts?.work_patterns) patternBlockers.push(blocker(__("No Work Pattern exists — create one"), "", "List/Employee Work Pattern"));
		if (groupDone && !state.work_pattern) patternBlockers.push(blocker(__("Employee Group has no Work Pattern mapping"), "", `Form/Employee Group/${state.employee_group}`));
		if (state.work_pattern && !state.holiday_list) patternBlockers.push(blocker(__("Work Pattern has no Holiday Calendar mapping"), "", `Form/Employee Work Pattern/${state.work_pattern}`));
		const shiftBlockers = !patternDone ? [blocker(__("Complete Work Pattern and Holiday Calendar first"), state.work_pattern ? "holiday_list" : "work_pattern")] : [];
		if (patternDone && !state.shift_type) shiftBlockers.push(blocker(__("Work Pattern has no Shift Type mapping"), "", `Form/Employee Work Pattern/${state.work_pattern}`));
		const rosterBlockers = !shiftDone ? [blocker(__("Complete Shift Type first"), "shift_type")] : [];
		if (shiftDone && state.defaults.requires_schedule && !state.shift_schedule) rosterBlockers.push(blocker(__("Roster group requires a submitted Shift Schedule"), "shift_schedule"));
		const employeeTable = `<div class="pm-table-wrap"><table class="pm-table srs-employee-table"><thead><tr><th>${__("Employee")}</th><th>${__("Current group")}</th><th>${__("Current pattern")}</th><th>${__("Roster Shift")}</th><th>${__("Roster")}</th><th>${__("Status")}</th></tr></thead><tbody>${rows.map(row => `<tr><td><a href="/app/employee/${encodeURIComponent(row.name)}">${esc(row.employee_name || row.name)}</a><small>${esc(row.name)}</small></td><td>${esc(row.karyo_employee_group || "—")}</td><td>${esc(row.karyo_work_pattern || "—")}</td><td>${esc(row.assignment?.karyo_shift_type || "—")}</td><td>${esc(row.assignment?.shift_schedule || row.assignment?.name || "—")}</td><td><span class="pm-chip ${row.complete ? "ok" : "danger"}">${row.complete ? __("Complete") : __("Required")}</span></td></tr>`).join("")}</tbody></table></div>`;
		const groupBody = groupDone || state.master_counts?.employee_groups ? `<div class="srs-fields"><div class="pm-field" data-control="employee_group"></div><button type="button" class="pm-btn small srs-master" data-route="List/Employee Group">${__("Manage Employee Groups")} →</button></div>` : "";
		const patternBody = groupDone ? `<div class="srs-fields cols-2"><div class="pm-field" data-control="work_pattern"></div><div class="pm-field" data-control="holiday_list"></div><button type="button" class="pm-btn small srs-master" data-route="List/Employee Work Pattern">${__("Manage Work Patterns")} →</button><button type="button" class="pm-btn small srs-master" data-route="List/Holiday List">${__("Manage Holiday Calendars")} →</button></div>` : "";
		const shiftBody = patternDone ? `<div class="srs-fields cols-2"><div class="pm-field" data-control="shift_type"></div><div class="pm-field" data-control="shift_location"></div><button type="button" class="pm-btn small srs-master" data-route="List/Shift Type">${__("Manage Shift Types")} →</button></div>` : "";
		const rosterBody = shiftDone ? `<div class="srs-fields cols-2"><div class="pm-field" data-control="assignment_mode"></div>${state.assignment_mode === "schedule" ? '<div class="pm-field" data-control="shift_schedule"></div>' : ""}<div class="pm-field" data-control="effective_from"></div><button type="button" class="pm-btn small srs-master" data-route="List/Shift Schedule">${__("Manage Roster Schedules")} →</button></div>` : "";
		$content.find(".srs-wizard").html(`<div class="pm-card"><h3>${__("Shift & Roster Setup · 5 steps")} <span class="pm-chip ${rosterDone ? "ok" : "info"}">${__("{0} of 5 complete", [completed])}</span></h3><p class="pm-muted">${__("Red dependency markers are clickable. Fix the marked dependency and the next step opens automatically.")}</p>${overview}</div>
			${step({number:1,label:__("Employee Selection"),complete:hasEmployees,current:!hasEmployees,description:__("The setup below applies only to this selected employee scope."),body:employeeTable})}
			${step({number:2,label:__("Employee Group"),complete:groupDone,current:hasEmployees&&!groupDone,locked:!hasEmployees,description:__("Employee Group owns the PRB work category and normally maps the Work Pattern and default Shift."),body:groupBody,blockers:groupBlockers})}
			${step({number:3,label:__("Work Pattern & Holiday Calendar"),complete:patternDone,current:groupDone&&!patternDone,locked:!groupDone,description:__("The Work Pattern supplies normal weekly hours, working days, default Shift and Calendar Code."),body:patternBody,blockers:patternBlockers})}
			${step({number:4,label:__("Shift Type & Location"),complete:shiftDone,current:patternDone&&!shiftDone,locked:!patternDone,description:__("The Shift Type binds clock times and Shift Code. Location is optional and follows the recurring assignment."),body:shiftBody,blockers:shiftBlockers})}
			${step({number:5,label:__("Recurring Shift / Roster Assignment"),complete:rosterDone,current:shiftDone&&!rosterDone,locked:!shiftDone,description:__("Choose a direct recurring shift or a roster schedule. Roster groups require a submitted schedule."),body:rosterBody,blockers:rosterBlockers})}
			<div class="pm-card srs-save-card"><div><strong>${rosterDone ? __("Ready to save") : __("Complete every dependency to save")}</strong><p class="pm-muted">${__("Saving writes the values to every selected Employee Attendance tab and creates or reuses the required recurring assignment.")}</p></div><button type="button" class="pm-btn primary srs-save" ${rosterDone ? "" : "disabled"}>${__("Save Employee Shift & Roster Setup")}</button><div class="srs-save-feedback" role="status" aria-live="polite"></div></div>`);

		if (hasEmployees) makeControl("employee_group", {fieldtype:"Link", label:__("Employee Group"), options:"Employee Group", reqd:1}, state.employee_group, async value => {
			state.employee_group = value; state.work_pattern = ""; state.shift_type = ""; state.holiday_list = ""; state.shift_schedule = "";
			await resolveDefaults(); renderWizard();
		});
		if (groupDone) {
			makeControl("work_pattern", {fieldtype:"Link", label:__("Work Pattern"), options:"Employee Work Pattern", reqd:1, read_only:!!state.defaults.group_work_pattern}, state.work_pattern, async value => {
				state.work_pattern = value; state.shift_type = ""; state.holiday_list = ""; state.shift_schedule = ""; await resolveDefaults(); renderWizard();
			});
			makeControl("holiday_list", {fieldtype:"Link", label:__("Holiday Calendar"), options:"Holiday List", reqd:1, read_only:!!state.defaults.holiday_list}, state.holiday_list, async value => { state.holiday_list = value; renderWizard(); });
		}
		if (patternDone) {
			makeControl("shift_type", {fieldtype:"Link", label:__("Shift Type"), options:"Shift Type", reqd:1, read_only:!!(state.defaults.group_shift_type || state.defaults.pattern_shift_type)}, state.shift_type, async value => { state.shift_type = value; state.shift_schedule = ""; await resolveDefaults(); renderWizard(); });
			makeControl("shift_location", {fieldtype:"Link", label:__("Shift Location (optional)"), options:"Shift Location"}, state.shift_location, async value => { state.shift_location = value; });
		}
		if (shiftDone) {
			const modes = state.defaults.requires_schedule
				? [{label:__("Roster schedule"), value:"schedule"}]
				: [{label:__("Direct recurring shift"),value:"direct"},{label:__("Roster schedule"),value:"schedule"}];
			makeControl("assignment_mode", {fieldtype:"Select", label:__("Assignment method"), options:modes, reqd:1}, state.assignment_mode, async value => { state.assignment_mode = value; if (value !== "schedule") state.shift_schedule = ""; renderWizard(); });
			if (state.assignment_mode === "schedule") makeControl("shift_schedule", {fieldtype:"Link", label:__("Submitted Shift Schedule"), options:"Shift Schedule", reqd:1, get_query:()=>({filters:{docstatus:1,shift_type:state.shift_type}})}, state.shift_schedule, async value => { state.shift_schedule = value; renderWizard(); });
			makeControl("effective_from", {fieldtype:"Date", label:__("Effective from"), reqd:1}, state.effective_from, async value => { state.effective_from = value; });
		}
		$content.find("[data-jump-step]").on("click", function () { $content.find(`[data-step="${this.dataset.jumpStep}"]`)[0]?.scrollIntoView({behavior:"smooth",block:"center"}); });
		$content.find(".srs-blocker[data-focus]").on("click", function () { focusControl(this.dataset.focus); });
		$content.find("[data-route]").on("click", function () { route(...this.dataset.route.split("/")); });
		$content.find(".srs-save").on("click", saveSetup);
	}

	async function saveSetup() {
		const $button = $content.find(".srs-save"), $feedback = $content.find(".srs-save-feedback");
		$button.prop("disabled", true).text(__("Saving…")); $feedback.text("");
		try {
			const result = await frappe.xcall("karyo.hr.roster.save_shift_roster_setup", {
				employees: state.selected, employee_group: state.employee_group,
				work_pattern: state.work_pattern, shift_type: state.shift_type,
				holiday_list: state.holiday_list, assignment_mode: state.assignment_mode,
				shift_schedule: state.shift_schedule || null, shift_location: state.shift_location || null,
				effective_from: state.effective_from,
			});
			$feedback.html(`<span class="pm-chip ok">${esc(result.message)}</span>${result.adjusted?.length ? `<p class="pm-muted">${esc(__("Some start dates were moved after existing dated duties to prevent overlap."))}</p>` : ""}`);
			frappe.show_alert({message: result.message, indicator:"green"}, 7);
			await loadSetup(true);
		} finally {
			$button.prop("disabled", false).text(__("Save Employee Shift & Roster Setup"));
		}
	}

	loadOptions();
};
