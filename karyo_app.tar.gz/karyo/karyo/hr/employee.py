"""Server-side employee master validations (ASM-HR-*)."""

import frappe
from frappe import _
from frappe.utils import getdate


def validate_employee_foundation(doc, method=None):
	"""Reject inconsistent effective dates and incomplete payroll-ready records."""
	joining = getdate(doc.date_of_joining) if doc.date_of_joining else None
	confirmation = getdate(doc.karyo_date_confirmed) if doc.get("karyo_date_confirmed") else None
	retirement = getdate(doc.karyo_retirement_date) if doc.get("karyo_retirement_date") else None
	leaving = getdate(doc.relieving_date) if doc.relieving_date else None

	if joining and confirmation and confirmation < joining:
		frappe.throw(_("Date of Confirmation cannot be before Date of Joining."))
	if joining and retirement and retirement < joining:
		frappe.throw(_("Retirement Date cannot be before Date of Joining."))
	if joining and leaving and leaving < joining:
		frappe.throw(_("Relieving Date cannot be before Date of Joining."))
	if doc.get("karyo_prb_opted_in") and not doc.get("karyo_prb_grade"):
		frappe.throw(_("PRB Grade is required for an employee opted into PRB."))
