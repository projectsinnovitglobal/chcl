import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.tests.test_employee_closing import TestEmployeeClosing
from karyo.payroll.employee_closing import close_employees
from karyo.payroll.employee_processing import mark
from karyo.loan.employee_payroll import available, cycles, eligible_period_options
from karyo.loan.appraisal import _payslip_component_amounts
from karyo.payroll.generated_closing import list_generated


class TestEmployeeClosureLoans(unittest.TestCase):
    def setUp(self):
        TestEmployeeClosing.setUp(self)
        self.period='closure-loan-'+uuid4().hex
        frappe.get_doc({'doctype':'Payroll Period','name':self.period,'company':self.cycle.company,'start_date':self.cycle.start_date,'end_date':self.cycle.end_date}).db_insert()
        frappe.db.set_value('Payroll Cycle',self.cycle.name,{'status':'Processing','docstatus':0,'payroll_period':self.period})
        self.cycle.reload()
        for employee,slip in zip(self.employees,self.slips):
            mark(self.cycle,employee,status='Processed',salary_slip=slip.name)
            frappe.db.set_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':employee},'employee_approved_on',frappe.utils.now_datetime())
            frappe.db.set_value('Salary Slip',slip.name,{'start_date':self.cycle.start_date,'end_date':self.cycle.end_date})
    tearDown=TestEmployeeClosing.tearDown

    def test_individual_close_unlocks_only_that_employee_and_period(self):
        a,b=self.employees
        self.assertFalse(available(self.cycle,a))
        result=close_employees(self.cycle.name,[a])
        self.assertEqual(result['closed'],[a]);self.assertEqual(result['cycle_status'],'Processing')
        self.assertTrue(available(self.cycle,a));self.assertFalse(available(self.cycle,b))
        self.assertEqual([r.name for r in cycles(a,self.period)],[self.cycle.name])
        self.assertEqual(cycles(b,self.period),[])
        self.assertIn(self.period,[r.value for r in eligible_period_options(a)])
        self.assertNotIn(self.period,[r.value for r in eligible_period_options(b)])
        loan=frappe.get_doc({'doctype':'Karyo Loan','employee':a,'company':self.cycle.company,'appraisal_payroll_period':self.period})
        loan._resolve_appraisal_payroll_period();self.assertEqual(loan.appraisal_payroll_cycle,self.cycle.name)
        loan.employee=b;loan.appraisal_payroll_cycle=None
        with self.assertRaises(frappe.ValidationError):loan._resolve_appraisal_payroll_period()
        frappe.db.set_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':a},'closed_on',None)
        self.assertFalse(available(self.cycle,a))

    def test_appraisal_uses_exact_employee_cycle_slip(self):
        a=self.employees[0];close_employees(self.cycle.name,[a])
        other=frappe.copy_doc(self.slips[0]);other.name='unrelated-'+uuid4().hex;other.docstatus=1;other.karyo_payroll_cycle=None;other.payroll_entry=None;other.start_date=self.cycle.start_date;other.end_date=self.cycle.end_date;other.db_insert()
        amounts,cycle,slips=_payslip_component_amounts(a,self.cycle.name)
        self.assertEqual(slips,[self.slips[0].name])
        self.assertNotIn(other.name,slips)
        amounts,cycle,slips=_payslip_component_amounts(self.employees[1],self.cycle.name)
        self.assertIsNone(amounts)

    def test_generated_table_and_closure_guards(self):
        a,b=self.employees
        frappe.db.set_value('Salary Slip',self.slips[1].name,'docstatus',0)
        data=list_generated(month=str(self.cycle.end_date)[:7],employee=b)
        row=next(r for r in data['rows'] if r['payroll_cycle']==self.cycle.name)
        self.assertEqual(row['payslip_status'],'Generated (Draft)');self.assertFalse(row['can_close'])
        self.assertEqual(close_employees(self.cycle.name,[b])['closed'],[])
        data=list_generated(month=str(self.cycle.end_date)[:7],employee=a)
        row=next(r for r in data['rows'] if r['payroll_cycle']==self.cycle.name)
        self.assertTrue(row['can_close'])
        close_employees(self.cycle.name,[a])
        row=next(r for r in list_generated(month=str(self.cycle.end_date)[:7],employee=a)['rows'] if r['payroll_cycle']==self.cycle.name)
        self.assertEqual(row['status'],'Closed');self.assertFalse(row['can_close'])
        pending_closed=list_generated(month=str(self.cycle.end_date)[:7],employee=a,pending_only=1,page_length=6)
        pending_open=list_generated(month=str(self.cycle.end_date)[:7],employee=b,pending_only=1,page_length=6)
        self.assertNotIn(self.cycle.name,[r['payroll_cycle'] for r in pending_closed['rows']])
        self.assertTrue(all(r['status']!='Closed' for r in pending_closed['rows']))
        self.assertIn(b,[r['employee'] for r in pending_open['rows']])
        self.assertLessEqual(len(pending_open['rows']),6)
