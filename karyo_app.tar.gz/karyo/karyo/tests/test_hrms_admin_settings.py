from unittest.mock import MagicMock, patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.integrations.email_auth import verify_email_authentication


class TestHRMSAdminSettings(FrappeTestCase):
	def test_document_naming_only_returns_hrms_documents(self):
		settings = frappe.get_doc("Document Naming Settings")
		result = settings.get_transactions_and_prefixes()

		self.assertIn("Employee", result["transactions"])
		self.assertIn("Attendance", result["transactions"])
		self.assertIn("Karyo Loan", result["transactions"])
		for unrelated in ("Asset", "Lead", "Stock Entry", "Sales Invoice", "Purchase Order"):
			self.assertNotIn(unrelated, result["transactions"])

	@patch("karyo.integrations.email_auth.frappe.get_doc")
	def test_email_oauth_verification_reports_missing_authorisation(self, get_doc):
		account = MagicMock()
		account.auth_method = "OAuth"
		account.enable_outgoing = 1
		account.enable_incoming = 0
		account.connected_app = "Microsoft 365"
		account.backend_app_flow = 0
		account.connected_user = "hr@example.com"
		account.get_oauth_token.return_value = None
		get_doc.return_value = account

		result = verify_email_authentication("HR Email")

		self.assertFalse(result["ok"])
		self.assertEqual(result["mode"], "OAuth / SSO")
		self.assertIn("not authorised", result["message"])

	@patch("karyo.integrations.email_auth.frappe.get_doc")
	def test_email_oauth_verification_checks_live_smtp(self, get_doc):
		account = MagicMock()
		account.auth_method = "OAuth"
		account.enable_outgoing = 1
		account.enable_incoming = 0
		account.connected_app = "Microsoft 365"
		account.backend_app_flow = 0
		account.connected_user = "hr@example.com"
		token = MagicMock()
		token.get_password.return_value = "token"
		account.get_oauth_token.return_value = token
		get_doc.return_value = account

		result = verify_email_authentication("HR Email")

		self.assertTrue(result["ok"])
		account.validate_smtp_conn.assert_called_once_with()
