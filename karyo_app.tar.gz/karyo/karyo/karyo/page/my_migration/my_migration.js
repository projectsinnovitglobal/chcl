frappe.pages['my-migration'].on_page_load = function(wrapper) {
 const esc = value => frappe.utils.escape_html(String(value ?? ''));
 const api = 'karyo.migration.employee_upload.';
 const $body = karyo.pages.scaffold(wrapper, {
  title: __('My Migration Uploads'),
  subtitle: __('Upload your previous Employee data, Leave balances and Passage Benefit balances for approval'),
  actions: [{label: __('Upload Historical CSV'), onclick: () => openUpload()}]
 });
 let data;
 const download = async (domain, sample) => {
  const result = await frappe.xcall(api + 'template', {migration_domain: domain, sample});
  const url = URL.createObjectURL(new Blob([result.content], {type:'text/csv;charset=utf-8'}));
  const a = document.createElement('a');a.href=url;a.download=result.filename;a.click();URL.revokeObjectURL(url);
 };
 const load = async () => {
  try {
   data = await frappe.xcall(api + 'context');
   $body.empty();
   $('<div class="alert alert-info"></div>').text(__('Employee: {0} · {1}. Uploads remain pending until your approver or an administrator approves them. Existing data is preserved.',[data.employee_name,data.employee])).appendTo($body);
   const $templates = $('<section class="karyo-card mb-4" style="padding:20px"></section>').appendTo($body);
   $('<h4></h4>').text(__('Download CSV Templates and Sample Data')).appendTo($templates);
   $('<p class="text-muted"></p>').text(__('Download a blank template or a sample, replace the example values with your historical data, and keep your Employee ID. Sample values are illustrative.')).appendTo($templates);
   $('<p class="small text-muted"></p>').text(__('Employee CSV field_name values: {0}.',[data.employee_fields.join(', ')])).appendTo($templates);
   $('<p class="small text-muted"></p>').text(__('Leave CSV leave_type values: {0}.',[data.leave_types.join(', ')])).appendTo($templates);
   const $grid=$('<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px"></div>').appendTo($templates);
   ['Employee','Leave','Passage Benefit'].forEach(domain=>{
    const $card=$('<div style="border:1px solid var(--border-color);border-radius:10px;padding:16px"></div>').appendTo($grid);
    $('<strong></strong>').text(__(domain)).appendTo($card);
    $('<p class="small text-muted mt-2"></p>').text(domain==='Employee' ? __('Only empty contact and document fields can be filled; profile values are never overwritten.') : domain==='Leave' ? __('Approved openings appear in your Leave balances, allocation or leave bank.') : __('Approved openings appear in My PB Bank and Passage Benefit records.')).appendTo($card);
    $('<button class="btn btn-default btn-sm mr-2" type="button"></button>').text(__('Blank Template')).on('click',()=>download(domain,0)).appendTo($card);
    $('<button class="btn btn-default btn-sm" type="button"></button>').text(__('Sample CSV')).on('click',()=>download(domain,1)).appendTo($card);
   });
   if(data.approval_requests?.length) {
    const $approval=$('<section class="karyo-card mb-4" style="padding:20px"></section>').appendTo($body);
    $('<h4></h4>').text(__('Requests Awaiting My Approval')).appendTo($approval);
    data.approval_requests.forEach(row=>{
     const $row=$('<div class="d-flex justify-content-between align-items-center mb-2"></div>').appendTo($approval);
     $('<span></span>').text(`${row.employee_name} · ${row.migration_domain} · ${row.name}`).appendTo($row);
     $('<button class="btn btn-sm btn-primary" type="button"></button>').text(__('Review and Decide')).on('click',()=>frappe.set_route('Form','Employee Migration Request',row.name)).appendTo($row);
    });
   }
   const $history=$('<section class="karyo-card" style="padding:20px"></section>').appendTo($body);
   $('<h4></h4>').text(__('My Uploads and Approval Results')).appendTo($history);
   if (!data.requests.length) return $('<p class="text-muted"></p>').text(__('No migration uploads yet. Download a sample above, then choose Upload Historical CSV.')).appendTo($history);
   const $table=$('<table class="table"><thead><tr><th>Request</th><th>Upload For</th><th>Source As At</th><th>Status</th><th>Approver</th><th></th></tr></thead><tbody></tbody></table>').appendTo($history);
   data.requests.forEach(row=>{
    const $row=$('<tr></tr>').appendTo($table.find('tbody'));
    [row.name,__(row.migration_domain),frappe.datetime.str_to_user(row.source_as_at),__(row.status),row.approver].forEach(value=>$('<td></td>').text(value||'—').appendTo($row));
    const $action=$('<td></td>').appendTo($row);
    $('<button type="button" class="btn btn-xs btn-default"></button>').text(__('View Results')).on('click',()=>showRequest(row.name)).appendTo($action);
   });
  } catch (error) {
   $body.empty();$('<div class="alert alert-warning"></div>').text(__('An active Employee must be linked to your login to use historical migration uploads. Contact HR if your employee account is not mapped.')).appendTo($body);
   console.error(error);
  }
 };
 async function showRequest(name) {
  const request=await frappe.xcall(api+'request_details',{name});
  const rows=request.rows.map(row=>`<tr><td>${esc(row.row_number)}</td><td>${esc(row.record_label)}</td><td>${esc(row.status)}</td><td>${esc(row.detail)}${row.target_doctype?`<div class="mt-2"><a href="/app/${({'Employee':'my-hr','Leave Opening Balance':'my-leave-bank','Passage Benefit Bank':'my-pb-bank'})[row.target_doctype]||frappe.router.slug(row.target_doctype)}">${esc(row.target_doctype)}: ${esc(row.target_name)}</a></div>`:''}</td></tr>`).join('');
  const dialog=new frappe.ui.Dialog({title:__('Migration Results — {0}',[name]),size:'extra-large',fields:[{fieldtype:'HTML',fieldname:'results',options:`<p><strong>${esc(request.status)}</strong> · ${__('Approver')}: ${esc(request.approver)}</p><p>${esc(request.decision_reason||'')}</p><table class="table"><thead><tr><th>CSV Row</th><th>Record</th><th>Result</th><th>Details / Mapped Record</th></tr></thead><tbody>${rows}</tbody></table>`}]});
  dialog.show();
 }
 function openUpload() {
  if(!data)return;
  let file;
  const dialog=new frappe.ui.Dialog({title:__('Upload Historical Data for Approval'),size:'large',fields:[
   {fieldname:'migration_domain',fieldtype:'Select',label:__('Upload For'),options:'Employee\nLeave\nPassage Benefit',default:'Leave',reqd:1},
   {fieldname:'employee',fieldtype:'Data',label:__('Employee ID'),default:data.employee,read_only:1},
   {fieldname:'source_reference',fieldtype:'Small Text',label:__('Historical Source / Reference'),reqd:1,description:__('For example, the previous employer statement or opening balance certificate reference.')},
   {fieldname:'upload',fieldtype:'HTML',options:`<div class="alert alert-info">${__('Approval is required. Duplicate or existing data will be reported as Data already exists; no values will be overwritten.')}</div><label>${__('Historical CSV file')}</label><input type="file" accept=".csv,text/csv" class="form-control" data-ess-migration-file><p class="small text-muted mt-2">${__('Dates must use YYYY-MM-DD. Use the templates and sample CSVs on My Migration Uploads.')}</p>`}
  ],primary_action_label:__('Upload and Submit for Approval'),async primary_action(values){
   if(!file)return frappe.msgprint(__('Choose a CSV file.'));
   dialog.disable_primary_action();
   try{
    const result=await frappe.xcall(api+'submit_csv',{migration_domain:values.migration_domain,source_reference:values.source_reference,source_filename:file.name,csv_content:await file.text()});
    dialog.hide();await load();
    frappe.show_alert({message:result.status==='Pending Approval'?__('Upload submitted for approval'):__(result.status),indicator:result.status==='Pending Approval'?'green':'orange'});
    await showRequest(result.name);
   }finally{dialog.enable_primary_action();}
  }});
  dialog.show();dialog.$wrapper.find('[data-ess-migration-file]').on('change',function(){file=this.files?.[0];});
 }
 wrapper.karyo_migration_reload=karyo.live.watch('my-migration-uploads',load,['Employee Migration Request']);
 wrapper.karyo_migration_reload(true);
};
frappe.pages['my-migration'].on_page_show = wrapper => wrapper.karyo_migration_reload?.();
