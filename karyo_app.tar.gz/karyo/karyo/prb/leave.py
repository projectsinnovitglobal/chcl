"""PRB leave engine: Vacation Leave accrual + Sick Leave Bank (pure, testable).

Implements PRB analysis §11 (LV-*, SLB-*): vacation-leave accrual bands/ceilings,
death refund, and the Sick Leave Bank year-end posting (21-day entitlement,
110-day bank, advance offset, 1/22 refund) and exit payout.
"""


def vacation_accrual_band(length_of_service_years):
	"""(annual accrual days, normal ceiling) by length of service (LV-08)."""
	y = length_of_service_years
	if y <= 5:
		return 25, 105
	if y <= 10:
		return 30, 140
	if y <= 15:
		return 35, 175
	return 35, 210


def vacation_death_refund(balance_days, last_monthly_salary, divisor=22, precision=2):
	"""Refund vacation-leave balance on death/separation using the governed divisor."""
	if divisor <= 0:
		raise ValueError("Leave refund divisor must be greater than zero")
	return round(balance_days * last_monthly_salary / divisor, precision)


def beyond_ceiling_cap(normal_ceiling):
	"""Beyond-Ceiling account cap = 50% of the normal maximum accumulation (LV-11)."""
	return normal_ceiling * 0.5


def sick_leave_bank_year_end(
	opening_bank,
	sick_taken,
	advance_balance,
	monthly_salary,
	annual_entitlement=21,
	ceiling=110,
	refund_cap=16,
	advance_recovery_days=14,
	precision=2,
):
	"""Year-end Sick Leave Bank posting for a substantive officer (SLB-02/03/04).

	Advance sick leave is offset FIRST — no banking or cash while an advance
	remains (SLB-04). Otherwise unused days bank up to the 110 ceiling; days above
	the ceiling refund up to 16 days at 1/22 of monthly salary/day (SLB-03).
	"""
	unused = max(0, annual_entitlement - sick_taken)
	if advance_balance > 0:
		advance_offset = min(unused, advance_balance, advance_recovery_days)
		new_advance = advance_balance - advance_offset
		bank_credit = 0
		refund_days = 0
		non_bankable = 0
	else:
		advance_offset = 0
		new_advance = 0
		capacity = max(0, ceiling - opening_bank)
		bank_credit = min(unused, capacity)
		non_bankable = max(0, unused - bank_credit)
		refund_days = min(refund_cap, non_bankable)
	closing_bank = min(ceiling, opening_bank + bank_credit)
	refund_amount = round(refund_days * monthly_salary / 22.0, precision)
	return {
		"unused_days": unused,
		"advance_offset_days": advance_offset,
		"new_advance_balance": new_advance,
		"bank_credit_days": bank_credit,
		"non_bankable_days": non_bankable,
		"refund_days": refund_days,
		"refund_amount": refund_amount,
		"closing_bank_days": closing_bank,
	}


def sick_leave_bank_exit_payout(bank_days, monthly_salary, divisor=22, precision=2):
	"""Full bank payout at retirement/resignation/death — 1/22 monthly salary/day
	(SLB-07/09)."""
	if divisor <= 0:
		raise ValueError("Leave refund divisor must be greater than zero")
	return round(bank_days * monthly_salary / divisor, precision)


CASUAL_LEAVE_DAYS = 11


def casual_leave_entitlement(months_served=12, annual_days=CASUAL_LEAVE_DAYS, precision=2):
	"""Casual Leave entitlement (LV-01): 11 working days/year, pro-rata by months
	served in the year of appointment."""
	return round(annual_days * min(months_served, 12) / 12.0, precision)


def vacation_accrual(length_of_service_years, opening_balance, taken_days, eligible_ratio=1.0, precision=2,
	annual_entitlement=None, accumulation_ceiling=None):
	"""Vacation Leave closing balance = min(opening + accrual - taken, ceiling),
	where accrual = annual band x eligible service ratio (LV-06/08)."""
	default_annual, default_ceiling = vacation_accrual_band(length_of_service_years)
	annual = default_annual if annual_entitlement is None else annual_entitlement
	ceiling = default_ceiling if accumulation_ceiling is None else accumulation_ceiling
	accrual = round(annual * eligible_ratio, precision)
	closing = min(opening_balance + accrual - taken_days, ceiling)
	return {"annual": annual, "ceiling": ceiling, "accrual": accrual, "closing": round(closing, precision)}
