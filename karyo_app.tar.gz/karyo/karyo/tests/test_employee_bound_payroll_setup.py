"""Contract tests for the employee-bound Payroll Setup wizard and CSV import."""

import csv
import io
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from karyo.payroll import salary_scales
from karyo.setup import employee_master


class TestEmployeeBoundPayrollSetup(unittest.TestCase):
	@patch("karyo.payroll.salary_scales._payroll_setup_snapshot")
	def test_employee_payroll_tab_lists_incomplete_dependencies(self, snapshot):
		snapshot.return_value = {
			"profile": {"payroll_group": "", "payroll_type": "Major", "pay_day": "",
				"work_pattern": "", "payment_mode": "Bank", "bank": "", "bank_branch": "",
				"bank_account": ""},
			"appointment": None,
		}
		state = salary_scales.employee_payroll_setup_state("EMP-0001")
		self.assertFalse(state["complete"])
		self.assertIn("payroll_group", {row["fieldname"] for row in state["missing"]})
		self.assertIn("salary_appointment", {row["fieldname"] for row in state["missing"]})
		self.assertIn("bank_account", {row["fieldname"] for row in state["missing"]})
		self.assertTrue(all(row["step"] in (2, 3) for row in state["missing"]))

	@patch("karyo.payroll.salary_scales._payroll_setup_snapshot")
	def test_pending_employee_requires_final_activation(self, snapshot):
		snapshot.return_value = {
			"pending_activation": 1,
			"profile": {"payroll_group": "MONTHLY", "payroll_type": "Major", "pay_day": "PAY-25",
				"work_pattern": "Full Time", "payment_mode": "Cash", "bank": "",
				"bank_branch": "", "bank_account": "", "cash_receipt_number": "CASH-1",
				"cash_reference": "REF-1", "cash_collection_point": "Head Office"},
			"appointment": {"name": "APT-1", "grade": "G1", "salary_point": 1,
				"salary_scale": "S1", "basic_salary": 1000, "salary_structure": "MONTHLY",
				"salary_structure_assignment": "SSA-1"},
		}
		state = salary_scales.employee_payroll_setup_state("EMP-0001")
		self.assertEqual([row["fieldname"] for row in state["missing"]], ["employee_activation"])
		self.assertEqual(state["missing"][0]["step"], 5)

	def test_only_bank_payment_mode_requires_dependent_details(self):
		base = {
			"karyo_payroll_group": "MONTHLY", "karyo_payroll_type": "Major",
			"karyo_pay_day": "PAY-25", "karyo_work_pattern": "Full Time",
		}
		with self.assertRaisesRegex(Exception, "Bank Account Number"):
			salary_scales._validate_employee_payroll_profile({
				**base, "salary_mode": "Bank", "karyo_payroll_bank": "BANK-1",
				"karyo_payroll_bank_branch": "BRANCH-1", "bank_ac_no": "",
			})
		for payment_mode in ("Cash", "Cheque"):
			salary_scales._validate_employee_payroll_profile({**base, "salary_mode": payment_mode})

	@patch("karyo.setup.employee_master.frappe.get_all")
	@patch("karyo.setup.employee_master.frappe.get_roles", return_value=["HR Manager"])
	def test_attendance_selectors_use_live_master_lists(self, _roles, get_all):
		get_all.return_value = [employee_master.frappe._dict(
			name="STANDARD-40", work_pattern_name="Full Time",
		)]
		rows = employee_master.attendance_master_query(
			"Employee Work Pattern", "", "name", 0, 20,
			{"employee_field": "karyo_work_pattern", "company": "MBC"},
		)
		self.assertEqual(rows, [["STANDARD-40", "Full Time"]])
		self.assertEqual(get_all.call_args.args[0], "Employee Work Pattern")
		self.assertEqual(get_all.call_args.kwargs["filters"]["disabled"], 0)
		self.assertEqual(get_all.call_args.kwargs["fields"], ["name", "work_pattern_name"])

	@patch("karyo.setup.employee_master.frappe.get_all")
	@patch("karyo.setup.employee_master.frappe.get_roles", return_value=["Payroll User"])
	def test_every_attendance_field_routes_to_its_master(self, _roles, get_all):
		masters = {
			"holiday_list": ("Holiday List", "holiday_list_name"),
			"karyo_work_pattern": ("Employee Work Pattern", "work_pattern_name"),
			"default_shift": ("Shift Type", "karyo_shift_code"),
			"karyo_leave_scheme": ("Leave Policy", "title"),
			"karyo_leave_block_list": ("Leave Block List", "leave_block_list_name"),
		}
		for fieldname, (doctype, label_field) in masters.items():
			with self.subTest(fieldname=fieldname):
				get_all.reset_mock()
				get_all.return_value = [employee_master.frappe._dict(
					name="MASTER-1", **{label_field: "Master description"},
				)]
				rows = employee_master.attendance_master_query(
					doctype, "master", "name", 0, 20,
					{"employee_field": fieldname, "company": "MBC"},
				)
				self.assertEqual(rows, [["MASTER-1", "Master description"]])
				self.assertEqual(get_all.call_args.args[0], doctype)
				self.assertEqual(get_all.call_args.kwargs["fields"], ["name", label_field])
				self.assertIn("name", get_all.call_args.kwargs["or_filters"])
				self.assertIn(label_field, get_all.call_args.kwargs["or_filters"])
				if fieldname == "karyo_leave_block_list":
					self.assertEqual(get_all.call_args.kwargs["filters"]["company"], "MBC")

	def test_profile_accepts_only_employee_payroll_fields(self):
		profile = salary_scales._payroll_setup_profile({
			"payroll_group": "MONTHLY",
			"payroll_type": "Major",
			"salary_currency": "MUR",
			"bank_account_holder_name": "Employee One",
			"bank_account_is_primary": 1,
			"bank_account_effective_from": "2026-09-01",
			"bank_account_effective_to": "2027-08-31",
			"unexpected_field": "must not be written",
		})
		self.assertEqual(profile["payroll_group"], "MONTHLY")
		self.assertEqual(profile["payroll_type"], "Major")
		self.assertEqual(profile["salary_currency"], "MUR")
		self.assertEqual(profile["bank_account_holder_name"], "Employee One")
		self.assertEqual(profile["bank_account_is_primary"], 1)
		self.assertEqual(profile["bank_account_effective_from"], "2026-09-01")
		self.assertEqual(profile["bank_account_effective_to"], "2027-08-31")
		self.assertNotIn("unexpected_field", profile)

	@patch("karyo.payroll.salary_scales._payroll_setup_snapshot", return_value={"employee": "EMP-0001"})
	@patch("karyo.payroll.salary_scales.bulk_salary_setup")
	@patch("karyo.payroll.salary_scales.frappe.db.set_value")
	@patch("karyo.payroll.salary_scales.frappe.db.savepoint")
	@patch("karyo.payroll.salary_scales.frappe.get_doc")
	@patch("karyo.payroll.salary_scales.require_admin")
	def test_existing_on_payroll_employee_is_saved_before_atomic_reactivation(
		self, _admin, get_doc, _savepoint, set_value, bulk_setup, _snapshot,
	):
		class EmployeeDoc(dict):
			def __getattr__(self, key):
				return self.get(key)

			def __setattr__(self, key, value):
				if key == "meta":
					object.__setattr__(self, key, value)
				else:
					self[key] = value

			def set(self, key, value):
				self[key] = value

			def check_permission(self, _permission):
				return None

			def save(self):
				self["saved_on_payroll"] = self["karyo_on_payroll"]

		doc = EmployeeDoc(
			name="EMP-0001", company="MBC", status="Active", karyo_on_payroll=1,
			karyo_payroll_setup_pending_activation=0,
		)
		doc.meta = SimpleNamespace(has_field=lambda _fieldname: True)
		doc.flags = SimpleNamespace()
		get_doc.return_value = doc
		bulk_setup.return_value = {"created": [{"employee": doc.name}], "failed": []}
		result = salary_scales.complete_payroll_setup(
			[doc.name], {
				"payroll_group": "MONTHLY", "payroll_type": "Major", "pay_day": "PAY-25",
				"work_pattern": "Full Time", "salary_currency": "MUR",
				"payment_mode": "Bank", "bank": "BANK-1",
				"bank_branch": "BRANCH-1", "bank_account": "1234567890",
				"bank_account_holder_name": "Employee One", "bank_account_is_primary": 1,
				"bank_account_effective_from": "2026-09-01",
			},
			"GRADE-1", 1, "2026-09-01", "APPROVAL-1", salary_structure="MONTHLY",
		)
		self.assertEqual(doc["saved_on_payroll"], 0)
		self.assertEqual(doc["salary_currency"], "MUR")
		self.assertEqual(doc["karyo_bank_account_holder_name"], "Employee One")
		self.assertEqual(doc["karyo_bank_account_is_primary"], 1)
		self.assertEqual(doc["karyo_bank_account_effective_from"], "2026-09-01")
		self.assertTrue(doc.flags.skip_prb_assignment_sync)
		self.assertEqual(result["failed"], [])
		self.assertEqual(set_value.call_args.args[2]["karyo_on_payroll"], 1)

	@patch("karyo.payroll.salary_scales._payroll_setup_snapshot", return_value={"employee": "EMP-0001"})
	@patch("karyo.payroll.salary_scales.bulk_salary_setup")
	@patch("karyo.payroll.salary_scales.frappe.db.set_value")
	@patch("karyo.payroll.salary_scales.frappe.db.savepoint")
	@patch("karyo.payroll.salary_scales.frappe.get_doc")
	@patch("karyo.payroll.salary_scales.require_admin")
	def test_prb_opt_in_keeps_grade_scale_appointment(
		self, _admin, get_doc, _savepoint, _set_value, bulk_setup, _snapshot,
	):
		class EmployeeDoc(dict):
			__getattr__ = dict.get

			def __setattr__(self, key, value):
				if key in ("meta", "flags"):
					object.__setattr__(self, key, value)
				else:
					self[key] = value

			def set(self, key, value):
				self[key] = value

			def check_permission(self, _permission):
				return None

			def save(self):
				return None

		doc = EmployeeDoc(
			name="EMP-0001", company="MBC", status="Active", karyo_on_payroll=1,
			karyo_payroll_setup_pending_activation=0,
		)
		doc.meta = SimpleNamespace(has_field=lambda _fieldname: True)
		doc.flags = SimpleNamespace()
		get_doc.return_value = doc
		bulk_setup.return_value = {"created": [{"employee": doc.name}], "failed": []}

		result = salary_scales.complete_payroll_setup(
			[doc.name], {
				"payroll_group": "MONTHLY", "payroll_type": "Major", "pay_day": "PAY-25",
				"work_pattern": "Full Time", "payment_mode": "Cash",
				"prb_opted_in": 1, "prb_grade": "PRB-GRADE-1", "prb_salary_point": "081",
			},
			"GRADE-1", 1, "2026-09-01", "APPROVAL-1", salary_structure="MONTHLY",
		)

		self.assertEqual(result["failed"], [])
		self.assertEqual(bulk_setup.call_args.kwargs["pay_basis"], "Grade Scale")
		self.assertEqual(bulk_setup.call_args.args[1:3], ("GRADE-1", 1))

	@patch("karyo.payroll.salary_scales._payroll_setup_snapshot")
	@patch("karyo.payroll.salary_scales._payroll_setup_employees", return_value=["EMP-0001"])
	@patch("karyo.payroll.salary_scales.frappe.get_doc")
	@patch("karyo.payroll.salary_scales.require_admin")
	def test_new_employee_grade_prefills_salary_allocation(self, _admin, _get_doc, _employees, snapshot):
		snapshot.return_value = {
			"employee": "EMP-0001", "employee_name": "New Employee", "company": "MBC",
			"status": "Inactive", "identity": {"grade": "G1"}, "profile": {},
			"appointment": None,
		}
		context = salary_scales.payroll_setup_context(["EMP-0001"])
		self.assertEqual(context["common_appointment"]["grade"], "G1")

	@patch("karyo.payroll.salary_scales.require_admin")
	def test_sample_csv_has_full_contract_and_two_rows(self, _require_admin):
		result = salary_scales.payroll_setup_csv_sample()
		rows = list(csv.DictReader(io.StringIO(result["content"])))
		self.assertEqual(result["columns"], salary_scales.PAYROLL_SETUP_CSV_COLUMNS)
		self.assertEqual(len(rows), 2)
		self.assertEqual(rows[0]["employee_id"], "EMP-0001")
		self.assertEqual(rows[0]["payment_mode"], "Bank")
		self.assertEqual(rows[0]["salary_currency"], "MUR")
		self.assertEqual(rows[0]["bank_account_is_primary"], "1")
		self.assertTrue(rows[0]["bank_account_holder_name"])
		self.assertTrue(rows[0]["authority_reference"])

	@patch("karyo.payroll.salary_scales.require_admin")
	@patch("karyo.payroll.salary_scales.complete_payroll_setup")
	def test_csv_processes_each_row_by_employee_id(self, complete, _require_admin):
		complete.side_effect = lambda employees, *args, **kwargs: {
			"created": [{"employee": employees[0], "appointment": "APT-" + employees[0]}],
			"failed": [],
		}
		header = ",".join(salary_scales.PAYROLL_SETUP_CSV_COLUMNS)
		base = {
			"payroll_group": "MONTHLY", "payroll_type": "Major", "pay_day": "PAY-25",
			"work_pattern": "STANDARD", "payment_mode": "Cash", "grade": "G1",
			"salary_point": "1", "effective_from": "2026-09-01",
			"salary_structure": "MONTHLY", "appointment_type": "Appointment",
			"authority_reference": "APP-1",
		}
		lines = [header]
		for employee in ("EMP-0001", "EMP-0002"):
			row = {column: "" for column in salary_scales.PAYROLL_SETUP_CSV_COLUMNS}
			row.update(base)
			row["employee_id"] = employee
			buffer = io.StringIO()
			writer = csv.DictWriter(buffer, fieldnames=salary_scales.PAYROLL_SETUP_CSV_COLUMNS,
				lineterminator="")
			writer.writerow(row)
			lines.append(buffer.getvalue())

		result = salary_scales.import_payroll_setup_csv("\n".join(lines))
		self.assertEqual(result["requested"], 2)
		self.assertEqual([row["employee"] for row in result["created"]], ["EMP-0001", "EMP-0002"])
		self.assertEqual(complete.call_count, 2)
