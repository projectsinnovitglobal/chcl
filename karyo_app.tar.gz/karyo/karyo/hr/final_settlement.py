"""Leaving-service settlement and controlled post-exit payroll window."""

import json

import frappe
from frappe import _
from frappe.utils import cint, flt, getdate, now_datetime, nowdate

ADMIN_ROLES = ("System Manager", "HR Manager", "Payroll Manager")
SETTLEMENT_SNAPSHOT_FIELDS = (
	"karyo_leaving_date", "karyo_settlement_status", "karyo_settlement_as_at",
	"karyo_basic_salary", "karyo_service_years",
	"karyo_sick_current_days", "karyo_sick_bank_days", "karyo_annual_current_days", "karyo_annual_bank_days",
	"karyo_sick_current_amount", "karyo_sick_bank_amount", "karyo_annual_current_amount", "karyo_annual_bank_amount",
	"karyo_sick_leave_days", "karyo_vacation_leave_days", "karyo_leave_settlement_amount",
	"karyo_pb_balance", "karyo_loan_outstanding", "karyo_gross_settlement",
	"karyo_net_settlement", "karyo_settlement_explanation",
	"karyo_settlement_finalized_on", "karyo_settlement_breakdown",
)
SETTLEMENT_MAPPING = {
	"karyo_settlement_as_at": "as_at", "karyo_basic_salary": "basic_salary", "karyo_service_years": "service_years",
	"karyo_sick_current_days": "sick_current_days", "karyo_sick_bank_days": "sick_bank_days",
	"karyo_annual_current_days": "annual_current_days", "karyo_annual_bank_days": "annual_bank_days",
	"karyo_sick_current_amount": "sick_current_amount", "karyo_sick_bank_amount": "sick_bank_amount",
	"karyo_annual_current_amount": "annual_current_amount", "karyo_annual_bank_amount": "annual_bank_amount",
	"karyo_sick_leave_days": "sick_leave_days", "karyo_vacation_leave_days": "vacation_leave_days",
	"karyo_leave_settlement_amount": "leave_settlement_amount", "karyo_pb_balance": "pb_balance",
	"karyo_loan_outstanding": "loan_outstanding", "karyo_gross_settlement": "gross_settlement",
	"karyo_net_settlement": "net_settlement", "karyo_settlement_explanation": "explanation",
}


def _sick_balance_as_at(employee, as_at):
	from karyo.hr.settlement_balances import bank_balance_as_at
	return bank_balance_as_at(employee, as_at, "Sick Leave Bank")[0], "Sick Leave Bank as at leaving date"


def _annual_leave_balance_as_at(employee, as_at):
	from karyo.hr.settlement_balances import leave_position_as_at
	position = leave_position_as_at(employee, as_at)
	return position["annual_current_days"] + position["annual_bank_days"], "Annual allocation and Vacation Bank as at leaving date"


def _passage_benefit_as_at(employee, as_at):
	from karyo.passage_benefit.inquiry import _posted_balance_as_at

	return flt(_posted_balance_as_at(employee, as_at))


def _loan_position_as_at(employee, as_at):
	"""Rebuild the employee's total loan position at the cut-off from the loan subledger."""
	loans = frappe.get_all(
		"Karyo Loan",
		filters={
			"employee": employee, "docstatus": 1,
			"disbursement_date": ("<=", as_at),
			"status": ("not in", ["Draft", "Rejected", "Cancelled"]),
		},
		fields=[
			"name", "loan_type", "status", "disbursement_date", "outstanding_capital",
			"outstanding_interest", "outstanding_insurance",
		],
		limit_page_length=0,
	)
	breakdown = []
	for loan in loans:
		current = flt(loan.outstanding_capital) + flt(loan.outstanding_interest) + flt(loan.outstanding_insurance)
		# Reverse movements posted after the cut-off. This also restores loans that
		# were settled after the employee's leaving date.
		future = frappe.db.sql(
			"""select coalesce(sum(credit-debit), 0)
			from `tabKaryo Loan Ledger Entry`
			where loan=%s and transaction_date>%s""",
			(loan.name, as_at),
		)[0][0]
		outstanding = max(0, flt(current + flt(future), 2))
		if outstanding:
			breakdown.append({
				"loan": loan.name, "loan_type": loan.loan_type, "status": loan.status,
				"outstanding": outstanding,
			})
	return flt(sum(row["outstanding"] for row in breakdown), 2), breakdown


def _loan_outstanding(employee, as_at=None):
	return _loan_position_as_at(employee, getdate(as_at or nowdate()))[0]


def calculate(employee, as_at=None):
	from karyo.payroll.salary_scales import approved_appointment
	from karyo.hr.settlement_balances import leave_position_as_at
	from karyo.prb.leave import sick_leave_bank_exit_payout

	emp = frappe.get_doc("Employee", employee)
	as_at = getdate(as_at or emp.relieving_date or nowdate())
	joined = emp.get("karyo_date_joined_service") or emp.get("date_of_joining")
	if joined and as_at < getdate(joined):
		frappe.throw(_("Leaving Service Date cannot be before the employee joined service."))
	appointment = approved_appointment(employee, as_at)
	basic = flt(appointment.basic_salary if appointment else emp.get("karyo_scale_basic_salary") or emp.ctc)
	settings = frappe.get_cached_doc("MBC Leave Settings")
	divisor = flt(settings.leave_refund_divisor) or 22
	if divisor <= 0:
		frappe.throw(_("The configured leave refund divisor must be greater than zero."))
	position = leave_position_as_at(employee, as_at)
	sick = position["sick_current_days"] + position["sick_bank_days"]
	vacation = position["annual_current_days"] + position["annual_bank_days"]
	refundable_current_sick = min(position["sick_current_days"], max(flt(settings.sick_refund_cap), 0))
	amounts = {
		"sick_current_amount": flt(refundable_current_sick * basic / divisor, 2),
		# The year-end refund cap does not cap the existing full-bank exit payout rule.
		"sick_bank_amount": sick_leave_bank_exit_payout(position["sick_bank_days"], basic, divisor),
		"annual_current_amount": flt(position["annual_current_days"] * basic / divisor, 2),
		"annual_bank_amount": flt(position["annual_bank_days"] * basic / divisor, 2),
	}
	leave_amount = sum(amounts.values())
	pb = _passage_benefit_as_at(employee, as_at)
	loan, loan_breakdown = _loan_position_as_at(employee, as_at)
	gross = leave_amount + pb
	return {
		**{key: value for key, value in position.items() if key != "references"}, **amounts,
		"component_details_available": True,
		"employee": employee,
		"currency": frappe.get_cached_value("Company", emp.company, "default_currency") if emp.company else None,
		"as_at": as_at,
		"basic_salary": flt(basic, 2),
		"service_years": flt(max(0, (as_at - getdate(joined)).days / 365.2425), 2) if joined else 0,
		"sick_leave_days": flt(sick, 2),
		"refundable_sick_days": flt(refundable_current_sick + position["sick_bank_days"], 2),
		"vacation_leave_days": flt(vacation, 2),
		"leave_settlement_amount": flt(leave_amount, 2),
		"pb_balance": flt(pb, 2),
		"loan_outstanding": flt(loan, 2),
		"gross_settlement": flt(gross, 2),
		"net_settlement": flt(gross - loan, 2),
		"loan_breakdown": loan_breakdown,
		"leave_references": position["references"],
		"sources": {
			"sick_leave": "Current-year allocation and Sick Leave Bank as at leaving date",
			"annual_leave": "Current-year allocation and Vacation Leave Bank as at leaving date",
			"passage_benefit": "Passage Benefit Ledger as at leaving date",
			"loan": "Karyo Loan subledger as at leaving date",
		},
		"explanation": _(
			"Leave: ({0} refundable current sick + {1} banked sick + {2} annual/vacation) × basic {3} ÷ {4}; "
			"total accrued benefits add PB {5}; net offsets loan outstanding {6}. Pending and future leave are excluded."
		).format(refundable_current_sick, position["sick_bank_days"], vacation, basic, divisor, pb, loan),
	}


def populate_separation(doc, method=None):
	if not doc.get("employee"):
		return
	if not doc.is_new() and doc.get_db_value("karyo_settlement_status") == "Finalized":
		stored = frappe.db.get_value("Employee Separation", doc.name,
			["employee", *[field for field in SETTLEMENT_SNAPSHOT_FIELDS if doc.meta.has_field(field)]], as_dict=True)
		if doc.employee != stored.employee or not doc.karyo_leaving_date or getdate(doc.karyo_leaving_date) != getdate(stored.karyo_leaving_date):
			frappe.throw(_("A finalized settlement's employee and leaving date cannot be changed."))
		for field in SETTLEMENT_SNAPSHOT_FIELDS:
			if field in stored:
				doc.set(field, stored[field])
		return
	employee = frappe.db.get_value("Employee", doc.employee, ["relieving_date", "company"], as_dict=True)
	if not employee:
		return
	if not doc.get("karyo_leaving_date") and employee.relieving_date:
		doc.karyo_leaving_date = employee.relieving_date
	as_at = doc.get("karyo_leaving_date")
	if not as_at:
		if doc.get("boarding_status") == "Completed":
			frappe.throw(_("Leaving Service Date is required before completing the separation."))
		return
	result = calculate(doc.employee, as_at)
	for fieldname, key in SETTLEMENT_MAPPING.items():
		if doc.meta.has_field(fieldname):
			doc.set(fieldname, result[key])
	finalized = doc.get("boarding_status") == "Completed" and cint(doc.get("docstatus")) == 1
	if doc.meta.has_field("karyo_settlement_status"):
		doc.karyo_settlement_status = "Finalized" if finalized else "Preview"
	if doc.meta.has_field("karyo_settlement_breakdown"):
		doc.karyo_settlement_breakdown = json.dumps({
			"loan_breakdown": result["loan_breakdown"], "sources": result["sources"],
			"leave_references": result["leave_references"], "calculation": result,
			"computed_at": str(now_datetime()),
		}, default=str, sort_keys=True)
	if doc.meta.has_field("karyo_settlement_finalized_on"):
		doc.karyo_settlement_finalized_on = now_datetime() if finalized else None


def refresh_separation_snapshot(separation):
	"""Persist a dated preview or final settlement without bypassing its calculation rules."""
	doc = frappe.get_doc("Employee Separation", separation) if isinstance(separation, str) else separation
	if not doc.get("karyo_leaving_date"):
		return doc
	populate_separation(doc)
	values = {
		fieldname: doc.get(fieldname)
		for fieldname in SETTLEMENT_SNAPSHOT_FIELDS if doc.meta.has_field(fieldname)
	}
	frappe.db.set_value("Employee Separation", doc.name, values, update_modified=False)
	return doc


def finalize_completed_separation(separation):
	"""Persist the final snapshot when HRMS completes separation through its Project tasks."""
	doc = frappe.get_doc("Employee Separation", separation) if isinstance(separation, str) else separation
	if doc.get("boarding_status") != "Completed" or doc.get("docstatus") != 1:
		return doc
	return refresh_separation_snapshot(doc)


def settlement_from_separation(doc):
	"""Return the frozen completed snapshot, or a dated preview for an open separation."""
	if doc.get("boarding_status") != "Completed" or cint(doc.get("docstatus")) != 1:
		return calculate(doc.employee, doc.get("karyo_leaving_date")) if doc.get("karyo_leaving_date") else None
	breakdown = {}
	try:
		breakdown = json.loads(doc.get("karyo_settlement_breakdown") or "{}")
	except (TypeError, ValueError):
		pass
	return {
		"component_details_available": bool(breakdown.get("calculation")),
		**{key: breakdown.get("calculation", {}).get(key, 0) for key in (
			"basic_salary", "service_years", "sick_current_days", "sick_bank_days", "annual_current_days", "annual_bank_days",
			"sick_current_amount", "sick_bank_amount", "annual_current_amount", "annual_bank_amount")},
		"employee": doc.employee,
		"currency": frappe.get_cached_value("Company", doc.company, "default_currency") if doc.company else None,
		"separation": doc.name,
		"status": doc.get("karyo_settlement_status") or "Finalized",
		"as_at": doc.get("karyo_settlement_as_at") or doc.get("karyo_leaving_date"),
		"sick_leave_days": flt(doc.get("karyo_sick_leave_days"), 2),
		"vacation_leave_days": flt(doc.get("karyo_vacation_leave_days"), 2),
		"leave_settlement_amount": flt(doc.get("karyo_leave_settlement_amount"), 2),
		"pb_balance": flt(doc.get("karyo_pb_balance"), 2),
		"loan_outstanding": flt(doc.get("karyo_loan_outstanding"), 2),
		"gross_settlement": flt(doc.get("karyo_gross_settlement"), 2),
		"net_settlement": flt(doc.get("karyo_net_settlement"), 2),
		"explanation": doc.get("karyo_settlement_explanation"),
		"loan_breakdown": breakdown.get("loan_breakdown") or [],
		"sources": breakdown.get("sources") or {},
		"leave_references": breakdown.get("leave_references") or {},
		"finalized_on": doc.get("karyo_settlement_finalized_on"),
	}


@frappe.whitelist()
def preview_separation(employee, as_at, separation=None):
	"""Permission-checked, read-only prefill for new and in-progress exit forms."""
	if frappe.session.user == "Guest":
		frappe.throw(_("Sign in to view final settlements."), frappe.PermissionError)
	if not as_at:
		frappe.throw(_("Leaving Service Date is required to fetch settlement balances."))
	if separation:
		doc = frappe.get_doc("Employee Separation", separation)
		doc.check_permission("read")
		if doc.employee != employee:
			frappe.throw(_("The employee does not match this separation."), frappe.PermissionError)
		if doc.karyo_settlement_status == "Finalized":
			if getdate(as_at) != getdate(doc.karyo_leaving_date):
				frappe.throw(_("The finalized leaving date cannot be changed."))
			result = settlement_from_separation(doc)
			return {"values": {field: doc.get(field) for field in SETTLEMENT_MAPPING if doc.meta.has_field(field)},
				"status": "Finalized", "settlement": result}
	else:
		frappe.has_permission("Employee Separation", "create", throw=True)
	frappe.get_doc("Employee", employee).check_permission("read")
	result = calculate(employee, as_at)
	return {"values": {field: result[key] for field, key in SETTLEMENT_MAPPING.items()},
		"status": "Preview", "settlement": result}


def employee_final_settlement(employee):
	separation = frappe.db.get_value(
		"Employee Separation", {"employee": employee, "docstatus": ("<", 2)}, "name",
		order_by="creation desc",
	)
	if separation:
		doc = frappe.get_doc("Employee Separation", separation)
		result = settlement_from_separation(doc)
		if result:
			result["separation"] = doc.name
			return result
	emp = frappe.db.get_value("Employee", employee, ["status", "relieving_date"], as_dict=True)
	if emp and emp.relieving_date and emp.status == "Inactive":
		result = calculate(employee, emp.relieving_date)
		result["status"] = "Calculated — separation record required"
		return result
	return None


POST_EXIT_FIELDS = (
	"karyo_post_exit_payroll_enabled", "karyo_post_exit_payroll_until", "karyo_post_exit_payment_reference",
)


def payment_window_active(employee):
	"""Check the persisted authority on every use, including when the scheduler is off."""
	if isinstance(employee, str):
		employee = frappe.db.get_value("Employee", employee,
			["name", "status", "relieving_date", *POST_EXIT_FIELDS], as_dict=True)
	return bool(employee and employee.get("status") == "Active"
		and employee.get("relieving_date")
		and cint(employee.get("karyo_post_exit_payroll_enabled"))
		and str(employee.get("karyo_post_exit_payment_reference") or "").strip()
		and employee.get("karyo_post_exit_payroll_until")
		and getdate(employee.karyo_post_exit_payroll_until) >= getdate(nowdate()))


def is_post_exit_run(employee, start_date):
	if isinstance(employee, str):
		employee = frappe.db.get_value("Employee", employee,
			["name", "status", "relieving_date", *POST_EXIT_FIELDS], as_dict=True)
	return bool(start_date and payment_window_active(employee)
		and getdate(employee.relieving_date) < getdate(start_date)
		and getdate(start_date) <= getdate(employee.karyo_post_exit_payroll_until))


def payment_window_context(employee):
	doc = frappe.get_doc("Employee", employee) if isinstance(employee, str) else employee
	doc.check_permission("read")
	completed = frappe.db.get_value("Employee Separation",
		{"employee": doc.name, "docstatus": 1, "boarding_status": "Completed"}, "name")
	return {"employee": doc.name, "status": doc.status, "completed_separation": completed,
		"enabled": bool(cint(doc.get("karyo_post_exit_payroll_enabled"))),
		"active": payment_window_active(doc), "until": doc.get("karyo_post_exit_payroll_until"),
		"approval_reference": doc.get("karyo_post_exit_payment_reference"),
		"can_manage": bool(set(ADMIN_ROLES).intersection(frappe.get_roles()) and doc.has_permission("write"))}


@frappe.whitelist()
def get_payment_window(employee):
	return payment_window_context(employee)


def keep_post_exit_user_disabled(doc, method=None):
	"""Payroll reactivation must not restore the separated employee's login."""
	if cint(doc.get("karyo_post_exit_payroll_enabled")):
		from karyo.hr.lifecycle import disable_employee_user
		disable_employee_user(doc.name)


def _require_manager():
	frappe.only_for(ADMIN_ROLES)


def _locked_employee(employee):
	frappe.db.get_value("Employee", employee, "name", for_update=True)
	doc = frappe.get_doc("Employee", employee)
	doc.check_permission("write")
	return doc


@frappe.whitelist(methods=["POST"])
def open_post_exit_payment(employee, until_date, approval_reference):
	_require_manager()
	doc = _locked_employee(employee)
	if not frappe.db.exists("Employee Separation", {"employee": employee, "docstatus": 1, "boarding_status": "Completed"}):
		frappe.throw(_("A completed Employee Separation is required for a post-exit payment window."))
	if not doc.relieving_date or getdate(doc.relieving_date) > getdate(nowdate()):
		frappe.throw(_("The employee must have left service before opening a post-exit payment window."))
	if doc.status not in ("Inactive", "Left") and not cint(doc.get("karyo_post_exit_payroll_enabled")):
		frappe.throw(_("The separated employee must be inactive before opening a payment window."))
	if not until_date or getdate(until_date) < getdate(nowdate()):
		frappe.throw(_("Payment Window Until is required and cannot be in the past."))
	if not str(approval_reference or "").strip():
		frappe.throw(_("Approval Reference is required."))
	doc.flags.allow_post_exit_reactivation = True
	doc.status = "Active"
	doc.karyo_post_exit_payroll_enabled = 1
	doc.karyo_post_exit_payroll_until = getdate(until_date)
	doc.karyo_post_exit_payment_reference = str(approval_reference).strip()
	doc.save(ignore_permissions=True)
	doc.add_comment("Info", _("Post-exit payment window opened until {0}. Approval reference: {1}.").format(
		doc.karyo_post_exit_payroll_until, frappe.utils.escape_html(doc.karyo_post_exit_payment_reference)))
	return payment_window_context(doc)


def _close_payment_window(doc, expired=False):
	if not cint(doc.get("karyo_post_exit_payroll_enabled")):
		return
	doc.flags.allow_post_exit_reactivation = True
	doc.status = "Inactive"
	doc.karyo_post_exit_payroll_enabled = 0
	doc.karyo_post_exit_payroll_until = None
	doc.save(ignore_permissions=True)
	doc.add_comment("Info", _("Post-exit payment window expired; employee returned to Inactive.") if expired
		else _("Post-exit payment window closed; employee returned to Inactive."))


@frappe.whitelist(methods=["POST"])
def close_post_exit_payment(employee):
	_require_manager()
	doc = _locked_employee(employee)
	_close_payment_window(doc)
	return payment_window_context(doc)


def close_expired_post_exit_windows():
	for employee in frappe.get_all("Employee",
		filters={"karyo_post_exit_payroll_enabled": 1, "karyo_post_exit_payroll_until": ("<", nowdate())},
		pluck="name"):
		frappe.db.get_value("Employee", employee, "name", for_update=True)
		doc = frappe.get_doc("Employee", employee)
		if doc.get("karyo_post_exit_payroll_until") and getdate(doc.karyo_post_exit_payroll_until) < getdate(nowdate()):
			_close_payment_window(doc, expired=True)


@frappe.whitelist()
def my_final_settlement():
	from karyo.hr.clocking import _own_employee

	emp = _own_employee(required=True)
	separation = frappe.db.get_value(
		"Employee Separation", {"employee": emp.name, "docstatus": ("<", 2)}, "name", order_by="creation desc"
	)
	if separation:
		frappe.get_doc("Employee Separation", separation).check_permission("read")
	return employee_final_settlement(emp.name)
