"""Review, approve and post variable earnings before payroll is prepared."""

import frappe
from frappe import _
from frappe.utils import flt, getdate

from karyo.payroll.governance import has_actor_role


PURPOSES = {
	"time": "Additional Hours",
	"higher_duty": "Acting / Responsibility",
}
PURPOSE_CODES = {
	"time": {"OVERTIME", "NIGHT_DUTY", "EXCESS_HOURS"},
	"higher_duty": {"ACTING", "RESPONSIBILITY"},
}


def _cycle(value):
	cycle = frappe.get_doc("Payroll Cycle", value) if isinstance(value, str) else value
	cycle.check_permission("read")
	if cycle.docstatus == 2 or cycle.status in ("Closed", "Cancelled"):
		frappe.throw(_("Select an open Payroll Cycle before processing pre-payroll earnings."))
	return cycle


def _employees(cycle, employees=None):
	from karyo.payroll.employee_processing import resolve_employees

	return resolve_employees(cycle, employees)[0]


def _linked_sources(source_doctype, names):
	if not names:
		return {}
	rows = frappe.db.sql(
		"""select input.source_name, run.name as payroll_run, run.docstatus,
			run.snapshot_status, run.posting_status
		from `tabPRB Payroll Input` input
		inner join `tabPRB Payroll Run` run on run.name=input.parent and run.docstatus<2
		where input.source_doctype=%(doctype)s and input.source_name in %(names)s
		order by run.docstatus desc, run.modified desc""",
		{"doctype": source_doctype, "names": tuple(names)}, as_dict=True,
	)
	return {row.source_name: row for row in rows}


def _time_sources(cycle, employees):
	fields = ["name", "employee", "employee_name", "claim_type", "approved_hours", "actual_start",
		"payroll_approval_status", "overtime_period"]
	rows = frappe.get_all("PRB Overtime Authorization", filters={
		"company": cycle.company, "employee": ("in", employees or [""]), "docstatus": 1,
		"authorization_status": "Recorded", "approved_hours": (">", 0),
		"actual_start": ("between", [f"{cycle.start_date} 00:00:00", f"{cycle.end_date} 23:59:59"]),
	}, fields=fields, order_by="employee asc, actual_start asc", limit_page_length=0)
	links = _linked_sources("PRB Overtime Authorization", [row.name for row in rows])
	codes = {"Overtime": "OVERTIME", "Night Duty": "NIGHT_DUTY", "Excess Hours": "EXCESS_HOURS"}
	for row in rows:
		row.input_code = codes[row.claim_type]
		row.quantity = flt(row.approved_hours)
		row.source_doctype = "PRB Overtime Authorization"
		row.description = _("{0}: {1}").format(row.claim_type, row.actual_start)
		row.link = links.get(row.name)
	return rows


def _higher_duty_sources(cycle, employees):
	rows = frappe.get_all("PRB Higher Duty Assignment", filters={
		"company": cycle.company, "employee": ("in", employees or [""]), "docstatus": 1,
		"from_date": ("<=", cycle.end_date), "to_date": (">=", cycle.start_date),
	}, fields=["name", "employee", "employee_name", "assignment_type", "from_date", "to_date", "assignment_days"],
		order_by="employee asc, from_date asc", limit_page_length=0)
	links = _linked_sources("PRB Higher Duty Assignment", [row.name for row in rows])
	for row in rows:
		row.input_code = str(row.assignment_type).upper()
		row.quantity = flt(row.assignment_days)
		row.source_doctype = "PRB Higher Duty Assignment"
		row.description = _("{0}: {1} to {2}").format(row.assignment_type, row.from_date, row.to_date)
		row.link = links.get(row.name)
	return rows


def sources(cycle, category, employees):
	if category == "time":
		return _time_sources(cycle, employees)
	if category == "higher_duty":
		return _higher_duty_sources(cycle, employees)
	frappe.throw(_("Unknown pre-payroll earnings category."))


def _new_run(cycle, employee, purpose):
	doc = frappe.new_doc("PRB Payroll Run")
	doc.employee = employee
	doc.company = cycle.company
	doc.payroll_cycle = cycle.name
	doc.payroll_period = cycle.get("payroll_period")
	doc.calculation_date = cycle.payment_date or cycle.end_date
	doc.review_year = getdate(cycle.end_date).year
	doc.run_purpose = purpose
	if doc.meta.has_field("custom_entry_source"):
		doc.custom_entry_source = "Automatic"
	if doc.meta.has_field("custom_manual_reference"):
		doc.custom_manual_reference = _("Processed in Pre-Payroll Earnings for {0}.").format(cycle.name)
	return doc


def _append_source(doc, row, category):
	doc.append("employee_inputs", {
		"category": "Overtime" if category == "time" else "Acting",
		"input_code": row.input_code,
		"description": row.description,
		"quantity": row.quantity,
		"source_doctype": row.source_doctype,
		"source_name": row.name,
	})


def process_drafts(payroll_cycle, category, employees=None):
	"""Calculate governed source records into reviewable Draft PRB runs."""
	cycle = _cycle(payroll_cycle)
	selected = _employees(cycle, employees)
	category = str(category or "")
	if category not in PURPOSES:
		frappe.throw(_("Select Additional Hours or Acting / Responsibility."))
	available = [row for row in sources(cycle, category, selected)
		if not row.link and (category != "time" or row.payroll_approval_status == "Approved")]
	result = frappe._dict(processed=0, created=0, eligible=0, skipped=0, runs=[])
	if category == "time":
		groups = {}
		for row in available:
			groups.setdefault(row.employee, []).append(row)
	else:
		# One governed higher-duty assignment per run keeps overlapping authorities auditable.
		groups = {f"{row.employee}|{row.name}": [row] for row in available}
	for group in groups.values():
		doc = _new_run(cycle, group[0].employee, PURPOSES[category])
		for row in group:
			_append_source(doc, row, category)
		doc.flags.ignore_permissions = True
		doc.insert(ignore_permissions=True)
		result.created += 1
		result.processed += len(group)
		result.eligible += int(flt(doc.gross_pay) > 0)
		result.runs.append(doc.name)
	result.skipped = len(sources(cycle, category, selected)) - result.processed
	return result


def approve_drafts(payroll_cycle, category, employees=None):
	cycle = _cycle(payroll_cycle)
	selected = _employees(cycle, employees)
	if category not in PURPOSES:
		frappe.throw(_("Select a pre-payroll earnings category."))
	rows = frappe.get_all("PRB Payroll Run", filters={
		"payroll_cycle": cycle.name, "employee": ("in", selected or [""]),
		"run_purpose": PURPOSES[category], "docstatus": 0,
	}, pluck="name", order_by="employee asc, creation asc", limit_page_length=0)
	result = frappe._dict(approved=0, skipped=0, runs=[])
	for name in rows:
		doc = frappe.get_doc("PRB Payroll Run", name)
		if doc.exception_code or not flt(doc.gross_pay):
			result.skipped += 1
			continue
		doc.flags.ignore_permissions = True
		doc.submit()
		result.approved += 1
		result.runs.append(name)
	return result


def post_runs(payroll_cycle, category, employees=None):
	cycle = _cycle(payroll_cycle)
	selected = _employees(cycle, employees)
	if category not in PURPOSES:
		frappe.throw(_("Select a pre-payroll earnings category."))
	from karyo.payroll.prb_posting import post_run
	rows = frappe.get_all("PRB Payroll Run", filters={
		"payroll_cycle": cycle.name, "employee": ("in", selected or [""]),
		"run_purpose": PURPOSES[category], "docstatus": 1, "snapshot_status": "Approved",
		"posting_status": ("!=", "Posted"),
	}, fields=["name", "employee"], order_by="employee asc, creation asc", limit_page_length=0)
	result = frappe._dict(posted=0, additional_salary=0, runs=[])
	for row in rows:
		posted = post_run(row.name)
		result.posted += 1
		result.additional_salary += len(posted.get("posted") or [])
		result.runs.append(row.name)
	return result


def _stage(link, source_status=None):
	if link and link.posting_status == "Posted":
		return "Posted"
	if link and link.docstatus == 1:
		return "Approved"
	if link:
		return "Calculated"
	if source_status == "Rejected":
		return "Rejected"
	if source_status and source_status != "Approved":
		return "Source Approval Required"
	return "Ready to Process"


def workflow_rows(cycle, category, employees):
	items = sources(cycle, category, employees)
	grouped = {}
	for item in items:
		row = grouped.setdefault(item.employee, frappe._dict(
			employee=item.employee, employee_name=item.employee_name, category=PURPOSES[category],
			records=0, quantity=0, amount=0, statuses=set(), runs=set(), name=item.name,
		))
		row.records += 1
		row.quantity += flt(item.quantity)
		row.statuses.add(_stage(item.link, item.get("payroll_approval_status")))
		if item.link:
			row.runs.add(item.link.payroll_run)
	rows = []
	order = ["Source Approval Required", "Ready to Process", "Calculated", "Approved", "Posted", "Rejected"]
	for row in grouped.values():
		row.amount = sum(flt(value) for value in frappe.get_all(
			"PRB Payroll Component", filters={"parent": ("in", list(row.runs) or [""])}, pluck="amount",
		))
		row.status = min(row.statuses, key=lambda value: order.index(value))
		row.payroll_runs = ", ".join(sorted(row.runs))
		row.pop("statuses", None)
		row.pop("runs", None)
		rows.append(row)
	return rows


def screen_context(requested_cycle=None, search=None):
	from karyo.desk.payroll_screens import cycle_options, _pick_cycle
	from karyo.payroll.employee_processing import resolve_employees

	options = cycle_options(include_closed=True)
	selected = _pick_cycle(options, requested_cycle)
	cycle_row = next((row for row in options if row["name"] == selected), None)
	if not selected:
		return {"cycles": options, "selected_cycle": None, "cycle": None, "workflows": {}, "source_rows": []}
	cycle = frappe.get_doc("Payroll Cycle", selected)
	employees, people = resolve_employees(cycle)
	workflows = {}
	for category in PURPOSES:
		rows = workflow_rows(cycle, category, employees)
		query = str(search or "").strip().lower()
		if query:
			rows = [row for row in rows if query in f"{row.employee} {row.employee_name or ''}".lower()]
		workflows[category] = {
			"key": category, "label": _(PURPOSES[category]), "rows": rows,
			"counts": {
				"employees": len(rows), "records": sum(row.records for row in rows),
				"quantity": sum(flt(row.quantity) for row in rows),
				"amount": sum(flt(row.amount) for row in rows),
				"calculated": sum(row.status == "Calculated" for row in rows),
				"approved": sum(row.status == "Approved" for row in rows),
				"posted": sum(row.status == "Posted" for row in rows),
			},
		}
	time_sources = _time_sources(cycle, employees)
	recurring = frappe.get_all("Employee Recurring PDB", filters={
		"company": cycle.company, "employee": ("in", employees or [""]), "status": "Active",
		"start_date": ("<=", cycle.end_date),
	}, fields=["name", "employee", "employee_name", "pdb_code", "salary_component", "amount", "calculation_method", "end_date"],
		order_by="employee asc, priority asc, name asc", limit_page_length=0)
	earning_components = set(frappe.get_all("Salary Component", filters={
		"name": ("in", [row.salary_component for row in recurring] or [""]), "type": "Earning", "disabled": 0,
	}, pluck="name", limit_page_length=0))
	recurring = [row for row in recurring if row.salary_component in earning_components
		and (not row.end_date or getdate(row.end_date) >= getdate(cycle.start_date))]
	postings = {
		row.recurring_pdb: row for row in frappe.get_all("Employee Recurring PDB Posting",
			filters={"payroll_cycle": cycle.name, "recurring_pdb": ("in", [row.name for row in recurring] or [""])},
			fields=["recurring_pdb", "status", "amount", "additional_salary"], limit_page_length=0)
	}
	for row in recurring:
		posting = postings.get(row.name)
		row.workflow_status = posting.status if posting else _("Assigned")
		row.calculated_amount = flt(posting.amount) if posting else flt(row.amount)
		row.additional_salary = posting.additional_salary if posting else None
	return {
		"cycles": options, "selected_cycle": selected, "cycle": cycle_row,
		"payroll_group": cycle_row.get("payroll_group") if cycle_row else None,
		"employee_options": [{"value": row.name, "label": f"{row.employee_name or row.name} ({row.name})",
			"description": row.department or ""} for row in people],
		"workflows": workflows,
		"source_rows": [{
			"name": row.name, "employee": row.employee, "employee_name": row.employee_name,
			"claim_type": row.claim_type, "approved_hours": row.approved_hours,
			"payroll_approval_status": row.payroll_approval_status,
			"payroll_run": row.link.payroll_run if row.link else None,
			"payroll_posting_status": row.link.posting_status if row.link else None,
		} for row in time_sources],
		"other_rows": recurring,
		"can_approve_sources": has_actor_role("approver"),
		"readiness": readiness(cycle, employees, include_attendance=False),
	}


def readiness(payroll_cycle, employees=None, include_attendance=True):
	"""Return the explicit before-payroll gate for an employee population."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle) if isinstance(payroll_cycle, str) else payroll_cycle
	selected = _employees(cycle, employees)
	checks = []
	for category in PURPOSES:
		items = sources(cycle, category, selected)
		pending = [row for row in items if _stage(row.link, row.get("payroll_approval_status")) not in ("Posted", "Rejected")]
		checks.append({"key": category, "label": _(PURPOSES[category]), "applicable": len(items),
			"pending": len(pending), "complete": not pending, "screen": "overtime"})
	if include_attendance:
		# Attendance bonuses are an automatic Prepare Payroll step. They are not a
		# manual prerequisite: preparation calculates, approves and posts each
		# qualifying employee idempotently before this gate is asserted.
		pending = 0
		checks.append({"key": "attendance", "label": _("PRB Attendance Bonus"), "applicable": len(selected),
			"pending": pending, "complete": True, "automatic": True, "screen": "presencebonus"})
		from karyo.payroll.era_hours import eligible_era_hours
		era_applicable = [employee for employee in selected if eligible_era_hours(employee, cycle).hours > 0]
		era_runs = frappe.get_all("PRB Payroll Run", filters={"payroll_cycle": cycle.name,
			"employee": ("in", era_applicable or [""]), "run_purpose": "ERA Hours Payment", "docstatus": ("<", 2)},
			fields=["employee", "custom_eligibility_status", "posting_status"], limit_page_length=0)
		era_by_employee = {run.employee: run for run in era_runs}
		era_pending = sum(not era_by_employee.get(employee) or (
			era_by_employee[employee].custom_eligibility_status == "Eligible" and era_by_employee[employee].posting_status != "Posted"
		) for employee in era_applicable)
		checks.append({"key": "era", "label": _("ERA Hours Payment"), "applicable": len(era_applicable),
			"pending": era_pending, "complete": not era_pending, "screen": "erahours"})
	return {"complete": all(row["complete"] for row in checks), "checks": checks,
		"pending": sum(row["pending"] for row in checks)}


def assert_complete(payroll_cycle, employees=None):
	result = readiness(payroll_cycle, employees)
	if result["complete"]:
		return result
	pending = [_(row["label"]) for row in result["checks"] if not row["complete"]]
	frappe.throw(_("Complete and submit these current-month pre-payroll calculations before Process Payroll: {0}.").format(", ".join(pending)))
