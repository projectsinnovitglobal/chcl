"""White-label finishing + permission matrix (WL-02, PB-13, LN-18).

bench --site dev.localhost execute karyo.setup.finishing.setup
"""

import json

import frappe


def _set_single(doctype, field, value):
	if frappe.get_meta(doctype).has_field(field):
		frappe.db.set_single_value(doctype, field, value)


def brand_desk():
	# WL-02: app name, copyright and footer branding.
	_set_single("Website Settings", "app_name", "MBC HRMS")
	_set_single("Website Settings", "copyright", "MBC HRMS")
	_set_single("Website Settings", "footer_powered", " ")
	_set_single("Website Settings", "disable_signup", 1)
	_set_single("Navbar Settings", "app_logo", "/assets/karyo/images/mbc-logo.jpg")
	print("  + desk branding (navbar/website) applied")


def whitelabel_navbar():
	"""WL-02: end-to-end white-label for the navbar Help dropdown."""
	hide = {
		"Documentation",
		"User Forum",
		"Training",
		"Report an Issue",
		"About",
		"Karyo Support",
	}
	navbar = frappe.get_doc("Navbar Settings")
	changed = False
	for item in navbar.help_dropdown:
		if item.item_label in hide and not item.hidden:
			item.hidden = 1
			changed = True
	if changed:
		navbar.save(ignore_permissions=True)
	print("  + navbar help de-branded")


def disable_stock_home_onboarding():
	"""Replace the stock operations onboarding at /app/home with a Karyo fallback."""
	if frappe.db.exists("Workspace", "Home"):
		workspace = frappe.get_doc("Workspace", "Home")
		workspace.is_hidden = 0
		workspace.content = json.dumps(
			[
				{
					"id": "karyo-home-onboarding",
					"type": "onboarding",
					"data": {"onboarding_name": "Home", "col": 12},
				}
			]
		)
		for link in workspace.links:
			link.hidden = 1
		workspace.save(ignore_permissions=True)

	if frappe.db.exists("Module Onboarding", "Home"):
		step_name = "Review Karyo Home"
		if not frappe.db.exists("Onboarding Step", step_name):
			frappe.get_doc(
				{
					"doctype": "Onboarding Step",
					"name": step_name,
					"title": step_name,
					"description": "# Review MBC Home\n\nOpen the MBC home page to begin.",
					"action": "Go to Page",
					"action_label": "Open Karyo Home",
					"path": "sil-home",
					"validate_action": 0,
					"is_complete": 1,
				}
			).insert(ignore_permissions=True)

		onboarding = frappe.get_doc("Module Onboarding", "Home")
		onboarding.title = "Welcome to MBC"
		onboarding.subtitle = "People, payroll, leave and approvals"
		onboarding.success_message = "MBC is ready"
		onboarding.documentation_url = "/app/sil-home"
		onboarding.is_complete = 1
		onboarding.set("steps", [])
		onboarding.append("steps", {"step": step_name})
		onboarding.save(ignore_permissions=True)

	frappe.db.commit()
	print("  + stock home onboarding disabled")


def _add_perm(doctype, role, perms):
	dt = frappe.get_doc("DocType", doctype)
	if any(p.role == role for p in dt.permissions):
		return
	row = {"role": role, "read": 1, "print": 1, "email": 1, "share": 1, "report": 1, "export": 1}
	row.update(perms)
	dt.append("permissions", row)
	dt.save(ignore_permissions=True)
	print(f"  + perm {role} -> {doctype}")


def ensure_permissions():
	# PB-13 / ESS: employees manage their own claims and view their own bank.
	_add_perm("Passage Benefit Application", "Employee", {"create": 1, "write": 1, "if_owner": 1})
	_add_perm("Passage Benefit Bank", "Employee", {"if_owner": 1})
	# ESS loan applications are created through a scoped service; employees get
	# read-only form access and the row-level hook limits this to their own loans.
	_add_perm(
		"Karyo Loan",
		"Employee",
		{"if_owner": 0, "write": 0, "create": 0, "submit": 0, "cancel": 0, "delete": 0, "amend": 0, "email": 0, "share": 0, "report": 0, "export": 0},
	)
	# Committee members can read/act on loans they review.
	_add_perm("Karyo Loan", "Karyo Loan Committee", {"write": 1})
	# Finance owns the money-moving workflow states (Disburse / Activate / Settle).
	_add_perm("Karyo Loan", "Karyo Finance", {"write": 1, "submit": 1, "cancel": 1, "amend": 1})
	_add_perm("Karyo Loan Recast", "Karyo Finance", {"create": 1, "write": 1, "submit": 1, "cancel": 1})


def setup():
	print("Karyo finishing (branding + permissions):")
	brand_desk()
	whitelabel_navbar()
	ensure_permissions()
	frappe.db.commit()
	print("Done.")
