"""Typed Payroll Payment/Deduction/Benefit masters (PAY-011)."""

import frappe

from karyo.setup.foundation import f, make_doctype


DEMO_TYPES = [
	("PAY", "Payments", "Payment"),
	("DED", "Deductions", "Deduction"),
	("BEN", "Benefits", "Benefit"),
]

DEMO_CODES = [
	("BASIC", "PAY", "Basic Salary", "Basic", "Static", 1, 1, 0),
	("EOY", "PAY", "End-of-Year Bonus", "EOY Bonus", "Once Off", 1, 1, 0),
	("CMP", "PAY", "Compensation", "Compensation (Demo)", "Once Off", 1, 0, 0),
	("PAYE", "DED", "PAYE", "PAYE", "Static", 0, 1, 0),
	("NSF", "DED", "NSF", "NSF", "Static", 0, 1, 0),
	("CSG", "DED", "CSG", "CSG", "Static", 0, 1, 0),
	("LOANC", "DED", "Loan Capital", "Karyo Loan Capital", "Static", 0, 0, 1),
	("LOANI", "DED", "Loan Interest", "Karyo Loan Interest", "Static", 0, 0, 0),
	("LOANINS", "DED", "Loan Insurance", "Karyo Loan Insurance", "Static", 0, 0, 0),
	("PBE", "BEN", "Passage Benefit Encashment", "Passage Benefit Encashment", "Once Off", 0, 0, 0),
]


def create_doctypes():
	make_doctype(
		"Payroll PDB Type",
		autoname="field:pdb_type",
		naming_rule="By fieldname",
		title_field="description",
		fields=[
			f("pdb_type", "Data", "PDB Type", reqd=1, unique=1, in_list_view=1),
			f("description", "Data", "Description", reqd=1, in_list_view=1),
			f(
				"classification",
				"Select",
				"Classification",
				options="Payment\nDeduction\nBenefit",
				reqd=1,
				in_list_view=1,
			),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("effective_from", "Date", "Effective From", default="2026-01-01"),
			f("effective_to", "Date", "Effective To"),
			f(
				"configuration_version",
				"Link",
				"Configuration Version",
				options="Payroll Configuration Version",
			),
		],
	)
	make_doctype(
		"Payroll PDB Code",
		autoname="field:pdb_code",
		naming_rule="By fieldname",
		title_field="description",
		fields=[
			f("identity_sb", "Section Break", "PDB Identity"),
			f("pdb_code", "Data", "PDB Code", reqd=1, unique=1, in_list_view=1),
			f("pdb_type", "Link", "PDB Type", options="Payroll PDB Type", reqd=1, in_list_view=1),
			f("description", "Data", "Description", reqd=1, in_list_view=1),
			f("short_description", "Data", "Short Description"),
			f("identity_cb", "Column Break"),
			f(
				"salary_component",
				"Link",
				"Salary Component",
				options="Salary Component",
				reqd=1,
				unique=1,
				in_list_view=1,
			),
			f(
				"transaction_mode",
				"Select",
				"Transaction Mode",
				options="Static\nOnce Off\nBoth",
				default="Both",
				reqd=1,
			),
			f("display_sequence", "Int", "Display Sequence", default="0"),
			f("flags_sb", "Section Break", "Calculation and Tax Flags"),
			f("taxable", "Check", "Taxable", default="0"),
			f("exempt", "Check", "Exempt", default="0"),
			f("prorata", "Check", "Prorata by Payment Days", default="0"),
			f("flags_cb", "Column Break"),
			f("reducing_balance", "Check", "Reducing Balance", default="0"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("effective_sb", "Section Break", "Validity and Governance"),
			f(
				"effective_from",
				"Date",
				"Effective From",
				reqd=1,
				default="2026-01-01",
				in_list_view=1,
			),
			f("effective_to", "Date", "Effective To"),
			f(
				"configuration_version",
				"Link",
				"Configuration Version",
				options="Payroll Configuration Version",
				reqd=1,
			),
			f("accounting_cb", "Column Break"),
			f("company", "Link", "Company", options="Company"),
			f("default_account", "Link", "Default Account", options="Account", hidden=1, read_only=1),
			f("default_cost_center", "Link", "Default Cost Center", options="Cost Center"),
			f("source_reference", "Data", "Source Reference"),
		],
	)


def _demo_configuration():
	return frappe.db.get_value(
		"Payroll Configuration Version",
		{"config_key": "DEMO-PDB-2026", "version": "DEMO-1"},
		"name",
	)


def seed_demo_data():
	configuration = _demo_configuration()
	if not configuration:
		return
	for code, description, classification in DEMO_TYPES:
		if frappe.db.exists("Payroll PDB Type", code):
			continue
		frappe.get_doc(
			{
				"doctype": "Payroll PDB Type",
				"pdb_type": code,
				"description": f"{description} (Demo)",
				"classification": classification,
				"is_active": 1,
				"effective_from": "2026-01-01",
				"configuration_version": configuration,
			}
		).insert(ignore_permissions=True)
	for code, pdb_type, description, component, mode, taxable, prorata, reducing in DEMO_CODES:
		if frappe.db.exists("Payroll PDB Code", code) or not frappe.db.exists(
			"Salary Component", component
		):
			continue
		frappe.get_doc(
			{
				"doctype": "Payroll PDB Code",
				"pdb_code": code,
				"pdb_type": pdb_type,
				"description": f"{description} (Demo)",
				"short_description": description,
				"salary_component": component,
				"transaction_mode": mode,
				"taxable": taxable,
				"prorata": prorata,
				"reducing_balance": reducing,
				"is_active": 1,
				"effective_from": "2026-01-01",
				"configuration_version": configuration,
				"source_reference": "DEMO mapping — client catalogue pending",
			}
		).insert(ignore_permissions=True)


def setup():
	print("Karyo Payroll PDB setup:")
	create_doctypes()
	from karyo.install import samples_enabled

	if samples_enabled():
		seed_demo_data()
	frappe.db.commit()
	print("Done (typed PDB masters and safe demo mappings created).")
