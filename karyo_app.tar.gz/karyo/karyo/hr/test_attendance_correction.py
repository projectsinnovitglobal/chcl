import unittest
from unittest.mock import MagicMock, patch

import frappe

from karyo.hr import attendance_correction as correction


class TestAttendanceCorrection(unittest.TestCase):
	def test_requested_status_maps_to_native_attendance_request_fields(self):
		doc = frappe._dict(from_date="2026-09-21", karyo_requested_status="Half Day")
		correction._apply_requested_status(doc)
		self.assertEqual(doc.reason, "On Duty")
		self.assertEqual(doc.half_day, 1)
		self.assertEqual(doc.half_day_date, "2026-09-21")

	def test_batch_request_is_scoped_to_signed_in_employee(self):
		person = frappe._dict(name="EMP-OWN", employee_name="Own Employee")
		rows = [
			frappe._dict(name="ATT-1", attendance_date="2026-09-20", shift="Day", company="MBC"),
			frappe._dict(name="ATT-2", attendance_date="2026-09-21", shift="Day", company="MBC"),
		]
		created = []

		def get_doc(values):
			doc = frappe._dict(values)
			doc.name = f"REQ-{len(created) + 1}"
			doc.insert = MagicMock(side_effect=lambda **_kwargs: created.append(doc))
			return doc

		with (
			patch.object(correction, "_own_employee", return_value=person),
			patch.object(frappe, "get_all", side_effect=[rows, []]) as get_all,
			patch.object(frappe, "get_doc", side_effect=get_doc),
		):
			result = correction.request_corrections(
				["ATT-1", "ATT-2"], "Present", "Badge reader failed"
			)

		self.assertEqual(result["count"], 2)
		self.assertEqual([doc.employee for doc in created], ["EMP-OWN", "EMP-OWN"])
		self.assertTrue(all(doc.karyo_request_status == "Pending Approval" for doc in created))
		self.assertEqual(get_all.call_args_list[0].kwargs["filters"]["employee"], "EMP-OWN")

	def test_approval_marks_target_attendance_as_corrected(self):
		doc = frappe._dict(
			name="REQ-1", employee="EMP-OWN", karyo_attendance="ATT-1"
		)
		with (
			patch.object(frappe, "get_all", return_value=[]),
			patch.object(frappe.db, "exists", return_value=True),
			patch.object(frappe.db, "set_value") as set_value,
			patch.object(correction, "_notify"),
		):
			correction.mark_attendance_corrected(doc)

		set_value.assert_called_once()
		self.assertEqual(set_value.call_args.args[:2], ("Attendance", "ATT-1"))
		self.assertEqual(set_value.call_args.args[2]["karyo_is_corrected"], 1)
		self.assertEqual(set_value.call_args.args[2]["karyo_correction_request"], "REQ-1")

	def test_hr_can_approve_pending_correction_from_queue(self):
		doc = MagicMock()
		doc.name = "REQ-1"
		doc.docstatus = 0
		doc.karyo_request_status = "Pending Approval"
		doc.get.side_effect = lambda key: getattr(doc, key, None)
		doc.submit.side_effect = lambda: setattr(doc, "karyo_request_status", "Approved")
		with (
			patch.object(frappe, "get_roles", return_value=["HR Manager"]),
			patch.object(frappe, "get_doc", return_value=doc),
		):
			result = correction.approve_correction("REQ-1")

		doc.check_permission.assert_called_once_with("submit")
		doc.submit.assert_called_once_with()
		self.assertEqual(result, {"name": "REQ-1", "status": "Approved"})

	def test_batch_rejects_unowned_or_missing_rows(self):
		person = frappe._dict(name="EMP-OWN", employee_name="Own Employee")
		with (
			patch.object(correction, "_own_employee", return_value=person),
			patch.object(frappe, "get_all", return_value=[]),
			self.assertRaises(frappe.PermissionError),
		):
			correction.request_corrections(["ATT-OTHER"], "Present", "Wrong absence")
