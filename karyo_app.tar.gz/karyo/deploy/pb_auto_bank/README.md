# Automatic Passage Benefit banks

`karyo.passage_benefit.auto_bank.create_due_banks` checks active PB-flagged employees against today's effective eligibility rules. Only missing banks are created, with a zero opening balance and an open bank period. An audit comment identifies automatic creation. Existing banks, balances and manual creation are preserved. Employee row locks serialize manual and automatic creation; per-employee savepoints isolate failures, which are recorded in Error Log.

The method is registered in the app's hourly scheduler hooks. The general Frappe scheduler on `fhrms.demodomains.in` is disabled, so this deployment uses the included dedicated systemd timer. This activates only PB bank creation. It does not enable other site jobs. `Persistent=true` catches a missed run after downtime. Duplicate calls remain idempotent if the site's general scheduler is enabled later.

Install the units under `/etc/systemd/system`, then run `systemctl daemon-reload` and `systemctl enable --now karyo-pb-auto-bank.timer`. Edit site and bench paths for other deployments. Check with `systemctl list-timers karyo-pb-auto-bank.timer` and `journalctl -u karyo-pb-auto-bank.service`. The first service execution completed successfully on 2026-09-14; no eligible banks were missing.

Manual creation remains available on Initialise PB Bank. Automatic opening happens on the first successful check on or after eligibility is satisfied; it does not award a balance or post backdated benefits. Earnings and redemptions retain their existing calculation and approval workflows.
