"""Employee Onboarding salary setup, source records and native calculation preview."""
import re
import frappe
from frappe import _
from frappe.utils import getdate, get_last_day, today


def install():
    from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
    create_custom_fields({'Employee': [
        {'fieldname': 'karyo_salary_workspace_section', 'fieldtype': 'Section Break',
         'label': '', 'insert_after': 'iban'},
        {'fieldname': 'karyo_salary_workspace', 'fieldtype': 'HTML',
         'label': 'Salary Setup and Calculation', 'insert_after': 'karyo_salary_workspace_section'},
        {'fieldname': 'karyo_time_payroll_section', 'fieldtype': 'Section Break',
         'label': 'Hourly Rate & Additional Hours', 'insert_after': 'karyo_salary_workspace'},
        {'fieldname': 'karyo_hourly_rate', 'fieldtype': 'Currency',
         'label': 'Normal Hourly Rate', 'options': 'Company:company:default_currency',
         'precision': '6', 'read_only': 1, 'no_copy': 1,
         'insert_after': 'karyo_time_payroll_section'},
        {'fieldname': 'karyo_hourly_rate_calculation', 'fieldtype': 'Small Text',
         'label': 'Hourly Rate Calculation', 'read_only': 1, 'no_copy': 1,
         'insert_after': 'karyo_hourly_rate'},
        {'fieldname': 'karyo_time_payroll_linkage', 'fieldtype': 'HTML',
         'label': 'Additional Hours Payroll Linkage',
         'insert_after': 'karyo_hourly_rate_calculation'},
    ]}, update=True)
    for fieldname, values in {
        'karyo_payroll_group': {'insert_after': 'karyo_hr_sb', 'label': 'Salary Group (Payroll Group)'},
        'karyo_payroll_type': {'insert_after': 'karyo_payroll_group'},
        'karyo_pay_day': {'insert_after': 'karyo_payroll_type'},
    }.items():
        name = frappe.db.get_value('Custom Field', {'dt': 'Employee', 'fieldname': fieldname}, 'name')
        if name:
            doc = frappe.get_doc('Custom Field', name)
            doc.update(values)
            doc.save()
    frappe.clear_cache(doctype='Employee')


TIME_COMPONENTS = (
    ('OVERTIME', 'Overtime'),
    ('NIGHT_DUTY', 'Night Duty'),
    ('EXCESS_HOURS', 'Excess Hours'),
)


@frappe.whitelist()
def overtime_payroll_context(employee, work_pattern=None):
    """Explain the employee rate and the governed hours-to-payroll chain."""
    emp = _employee(employee)
    from karyo.payroll.salary_scales import employee_hourly_rate_snapshot

    rate = employee_hourly_rate_snapshot(
        emp, work_pattern=work_pattern if work_pattern is not None else emp.get('karyo_work_pattern')
    )
    configured = {
        row.component_code: row
        for row in frappe.get_all(
            'PRB Payroll Component Mapping',
            filters={'component_code': ('in', [code for code, _label in TIME_COMPONENTS])},
            fields=['component_code', 'description', 'pdb_code', 'posting_mode', 'is_active'],
            limit_page_length=0,
        )
    }
    mappings = []
    for code, label in TIME_COMPONENTS:
        mapping = configured.get(code)
        pdb = None
        component_disabled = None
        if mapping and mapping.pdb_code:
            pdb = frappe.db.get_value(
                'Payroll PDB Code', mapping.pdb_code,
                ['salary_component', 'transaction_mode', 'is_active'], as_dict=True,
            )
            if pdb and pdb.salary_component:
                component_disabled = frappe.db.get_value(
                    'Salary Component', pdb.salary_component, 'disabled'
                )
        active = bool(
            mapping and mapping.is_active and pdb and pdb.is_active
            and pdb.salary_component and not component_disabled
        )
        mappings.append({
            'claim_type': label,
            'component_code': code,
            'pdb_code': mapping.pdb_code if mapping else None,
            'posting_mode': mapping.posting_mode if mapping else None,
            'salary_component': pdb.salary_component if pdb else None,
            'transaction_mode': pdb.transaction_mode if pdb else None,
            'active': active,
        })

    authorizations = frappe.get_all(
        'PRB Overtime Authorization',
        filters={'employee': employee, 'docstatus': ('<', 2)},
		fields=[
			'name', 'claim_type', 'authorization_status', 'planned_start', 'planned_end',
			'planned_hours', 'actual_start', 'approved_hours', 'eligibility_reason',
			'shift_type', 'roster_schedule', 'roster_assignment', 'docstatus',
        ],
        order_by='planned_start desc, modified desc',
        limit_page_length=8,
    )
    linked = {}
    names = [row.name for row in authorizations]
    if names:
        for row in frappe.db.sql(
            """select i.source_name, i.parent as payroll_run,
                r.posting_status, r.snapshot_status, r.docstatus
            from `tabPRB Payroll Input` i
            inner join `tabPRB Payroll Run` r on r.name=i.parent and r.docstatus<2
            where i.source_doctype='PRB Overtime Authorization'
              and i.source_name in %(names)s
            order by r.modified desc""",
            {'names': tuple(names)}, as_dict=True,
        ):
            linked.setdefault(row.source_name, row)
    for row in authorizations:
        payroll = linked.get(row.name)
        row['payroll_run'] = payroll.payroll_run if payroll else None
        row['posting_status'] = payroll.posting_status if payroll else None
        row['snapshot_status'] = payroll.snapshot_status if payroll else None

    return {
        'employee': emp.name,
        'rate': rate,
        'mappings': mappings,
        'authorizations': authorizations,
        'linkage_steps': [
            _('1. Authorise the work before it starts.'),
            _('2. Record actual start/end; the system determines approved payable hours.'),
            _('3. Payroll calculation automatically attaches eligible records for the employee and cycle.'),
            _('4. The approved PRB Payroll Run posts through PDB Code to Additional Salary.'),
            _('5. Salary Slip reads the mapped Salary Component and prevents the same source being paid twice.'),
        ],
    }


def _employee(employee):
    from karyo.desk.payroll_management import _admin
    _admin()
    doc = frappe.get_doc('Employee', employee)
    doc.check_permission('read')
    return doc


def _month(month):
    month = month or today()[:7]
    if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', str(month)):
        frappe.throw(_('Select a valid salary month.'))
    start = getdate(month + '-01')
    return start, get_last_day(start)


def _rows(doctype, filters, fields, order_by='modified desc'):
    if not frappe.has_permission(doctype, 'read'):
        return []
    return frappe.get_list(doctype, filters=filters, fields=fields,
                           order_by=order_by, limit_page_length=0)


def _attach_pdb_codes(rows):
    components = {row.get('salary_component') for row in rows if row.get('salary_component')}
    if not components:
        return rows
    mappings = frappe.get_all(
        'Payroll PDB Code', filters={'salary_component': ('in', list(components)), 'is_active': 1},
        fields=['salary_component', 'pdb_code'], order_by='modified desc', limit_page_length=0,
    )
    by_component = {}
    for mapping in mappings:
        by_component.setdefault(mapping.salary_component, mapping.pdb_code)
    for row in rows:
        row['pdb_code'] = by_component.get(row.get('salary_component')) or row.get('salary_component')
    return rows


@frappe.whitelist()
def context(employee, month=None):
    emp = _employee(employee)
    start, end = _month(month)
    assignments = _rows('Salary Structure Assignment', {'employee': employee},
        ['name', 'salary_structure', 'from_date', 'base', 'variable', 'income_tax_slab', 'docstatus'], 'from_date desc')
    structures = _rows('Salary Structure', {'company': emp.company, 'docstatus': ('<', 2)},
        ['name', 'docstatus', 'is_active', 'payroll_frequency', 'currency'], 'name asc')
    available = {r.name: r for r in structures}
    current = next((a for a in assignments if a.docstatus == 1 and getdate(a.from_date) <= end
                    and a.salary_structure in available and available[a.salary_structure].docstatus == 1
                    and available[a.salary_structure].is_active == 'Yes'
                    and available[a.salary_structure].payroll_frequency == 'Monthly'), None)
    components = []
    if current:
        structure = frappe.get_doc('Salary Structure', current.salary_structure)
        structure.check_permission('read')
        for kind in ('earnings', 'deductions'):
            for row in structure.get(kind):
                components.append({k: row.get(k) for k in ('salary_component', 'abbr', 'amount',
                    'amount_based_on_formula', 'formula', 'condition', 'depends_on_payment_days',
                    'do_not_include_in_total', 'statistical_component', 'variable_based_on_taxable_salary')} | {'type': kind})
    _attach_pdb_codes(components)
    periods = _rows('Payroll Period', {'company': emp.company, 'start_date': ('<=', start),
                                     'end_date': ('>=', end)}, ['name', 'start_date', 'end_date', 'is_active'])
    # Historical/fiscal calendars can overlap at a transition month. A valid
    # match must not be reported as missing merely because another match also
    # exists; the period with the latest effective start owns that month.
    selected_period = max(periods, key=lambda row: (getdate(row.start_date), row.name)) if periods else None
    from karyo.payroll.salary_scales import employee_payroll_setup_state
    appointment = frappe.db.get_value(
        'Employee Salary Appointment', {'employee': employee, 'docstatus': 1},
        ['income_tax_slab', 'appointment_type', 'authority_reference', 'effective_to'],
        as_dict=True, order_by='effective_from desc',
    ) or {}
    branch = frappe.db.get_value(
        'Payroll Bank Branch', emp.get('karyo_payroll_bank_branch'),
        ['branch_code', 'branch_name', 'transfer_code', 'other_code'], as_dict=True,
    ) if emp.get('karyo_payroll_bank_branch') else {}
    branch = branch or {}
    return {'employee': employee, 'employee_name': emp.employee_name, 'company': emp.company,
        'month': str(start)[:7], 'group': emp.get('karyo_payroll_group'),
        'payroll_type': emp.get('karyo_payroll_type'), 'pay_day': emp.get('karyo_pay_day'), 'grade': emp.grade,
        'grade_description': emp.get('karyo_grade_description'),
        'scale': emp.get('karyo_salary_scale'), 'salary_point': emp.get('karyo_scale_salary_point'),
        'basic_salary': emp.get('karyo_scale_basic_salary'), 'ctc': emp.get('ctc'),
        'currency': emp.get('salary_currency') or frappe.db.get_value('Company', emp.company, 'default_currency'),
        'salary_appointment': emp.get('karyo_salary_appointment'),
        'salary_effective_from': emp.get('karyo_salary_effective_from'),
        'payment_mode': emp.get('salary_mode'), 'payroll_bank': emp.get('karyo_payroll_bank'),
        'payroll_bank_branch': emp.get('karyo_payroll_bank_branch'),
        'branch_code': branch.get('branch_code'), 'branch_name': branch.get('branch_name'),
        'branch_transfer_code': branch.get('transfer_code'), 'branch_other_code': branch.get('other_code'),
        'work_pattern': emp.get('karyo_work_pattern'), 'payroll_cost_center': emp.get('payroll_cost_center'),
        'contribution_group': emp.get('karyo_contribution_group'),
        'loan_eligibility_group': emp.get('karyo_loan_eligibility_group'),
        'loan_payroll_period': emp.get('karyo_loan_payroll_period'),
        'prb_opted_in': emp.get('karyo_prb_opted_in'),
        'prb_grade': emp.get('karyo_prb_grade') if emp.get('karyo_prb_opted_in') else _('Not applicable'),
        'prb_salary_point': emp.get('karyo_prb_salary_point') if emp.get('karyo_prb_opted_in') else _('Not applicable'),
        'prb_row3_salary': emp.get('karyo_prb_row3_salary') if emp.get('karyo_prb_opted_in') else None,
        'pb_bank': emp.get('karyo_pb_bank'), 'income_tax_slab': appointment.get('income_tax_slab'),
        'appointment_type': appointment.get('appointment_type'),
        'authority_reference': appointment.get('authority_reference'),
        'salary_effective_to': appointment.get('effective_to'),
        'setup': employee_payroll_setup_state(employee),
        'assignments': assignments, 'structures': structures, 'current': current, 'components': components,
        'period': selected_period.name if selected_period else None,
        'component_catalogue': _rows('Salary Component', {}, ['name', 'type', 'salary_component_abbr', 'disabled'], 'name asc'),
        'adjustments': _rows('Additional Salary', {'employee': employee, 'docstatus': ('<', 2)},
            ['name', 'salary_component', 'type', 'amount', 'payroll_date', 'is_recurring', 'from_date', 'to_date', 'docstatus']),
        'slips': _rows('Salary Slip', {'employee': employee},
            ['name', 'start_date', 'end_date', 'salary_structure', 'gross_pay', 'total_deduction', 'net_pay', 'currency', 'docstatus'], 'start_date desc'),
        'prb': _rows('PRB Payroll Run', {'employee': employee},
            ['name', 'payroll_cycle', 'basic_salary', 'exception_code', 'exception_detail', 'docstatus']),
        'statutory': _rows('Payroll Statutory Result', {'employee': employee},
            ['name', 'payroll_cycle', 'result_type', 'status', 'current_amount', 'cumulative_amount']),
    }


@frappe.whitelist()
def preview(employee, month):
    """Calculate with HRMS's salary engine without saving or submitting a slip."""
    emp = _employee(employee)
    if not frappe.has_permission('Salary Slip', 'read') or not frappe.has_permission('Salary Structure', 'read'):
        frappe.throw(_('Salary calculation access is required.'), frappe.PermissionError)
    start, end = _month(month)
    data = context(employee, month)
    if not data['current']:
        frappe.throw(_('An active submitted monthly Salary Structure and submitted Salary Structure Assignment are required for this month.'))
    if not data['period']:
        frappe.throw(_('Configure a Payroll Period covering this salary month.'))
    doc = frappe.get_doc({'doctype': 'Salary Slip', 'employee': employee, 'employee_name': emp.employee_name,
        'company': emp.company, 'department': emp.department, 'designation': emp.designation,
        'joining_date': emp.date_of_joining, 'relieving_date': emp.relieving_date,
        'posting_date': end, 'start_date': start, 'end_date': end, 'payroll_frequency': 'Monthly'})
    doc.get_emp_and_working_day_details()
    doc.set_salary_structure_assignment()
    doc.calculate_net_pay()
    fields = ('salary_structure', 'start_date', 'end_date', 'currency', 'gross_pay', 'total_deduction',
              'net_pay', 'rounded_total', 'total_working_days', 'payment_days', 'leave_without_pay', 'absent_days')
    result = {f: doc.get(f) for f in fields}
    for kind in ('earnings', 'deductions'):
        result[kind] = [{f: row.get(f) for f in ('salary_component', 'amount', 'default_amount', 'additional_salary',
            'amount_based_on_formula', 'formula', 'condition', 'depends_on_payment_days',
            'do_not_include_in_total', 'statistical_component', 'variable_based_on_taxable_salary')} for row in doc.get(kind)]
    result['preview_only'] = True
    return result


@frappe.whitelist()
def component_table(employee, month=None):
    """A single employee component table; incomplete setup is an inline empty state."""
    data = context(employee, month)
    result = {key: data[key] for key in (
        'employee', 'month', 'current', 'components', 'period', 'structures',
        'group', 'payroll_type', 'pay_day', 'grade', 'grade_description', 'scale', 'salary_point',
        'basic_salary', 'ctc', 'currency', 'salary_appointment', 'salary_effective_from',
        'payment_mode', 'payroll_bank', 'payroll_bank_branch',
        'branch_code', 'branch_name', 'branch_transfer_code', 'branch_other_code',
        'work_pattern', 'payroll_cost_center', 'contribution_group',
        'loan_eligibility_group', 'loan_payroll_period', 'prb_opted_in', 'prb_grade',
        'prb_salary_point', 'prb_row3_salary', 'pb_bank', 'income_tax_slab',
        'appointment_type', 'authority_reference', 'salary_effective_to', 'setup',
    )}
    # Show the same persisted binding created by Payroll Setup in the Employee
    # Payroll tab, rather than keeping it visible only in Process Payroll.
    bindings = frappe.db.sql(
        """select ce.payroll_cycle, c.status
        from `tabPayroll Cycle Employee` ce
        inner join `tabPayroll Cycle` c on c.name=ce.payroll_cycle
        where ce.employee=%s and c.docstatus<2
        order by c.end_date desc, ce.modified desc limit 5""",
        (employee,), as_dict=True,
    )
    result['payroll_cycle'] = ', '.join(row.payroll_cycle for row in bindings) or None
    result['payroll_cycle_status'] = ', '.join(row.status for row in bindings) or None
    result.update(calculation=None, calculation_error=None)
    if not data['current']:
        result['calculation_error'] = _('Select a Salary Structure to show the calculations.')
        return result
    # Automatic display should not open a validation dialog every time Salary is viewed.
    messages_before = list(frappe.local.message_log or [])
    try:
        result['calculation'] = structure_calculation(employee, data)
    except frappe.ValidationError as error:
        result['calculation_error'] = frappe.utils.strip_html(str(error))
    finally:
        frappe.local.message_log = messages_before
    return result


def structure_calculation(employee, data):
    """Evaluate only the selected template, before month-specific payroll inputs."""
    emp = _employee(employee)
    structure = frappe.get_doc('Salary Structure', data['current'].salary_structure)
    structure.check_permission('read')
    assignment = frappe.get_doc('Salary Structure Assignment', data['current'].name)
    assignment.check_permission('read')
    slip = frappe.new_doc('Salary Slip')
    slip.update({'employee': employee, 'salary_structure': structure.name,
                 'company': emp.company, 'currency': structure.currency,
                 'base': assignment.base, 'variable': assignment.variable})
    slip._salary_structure_assignment = assignment.as_dict()
    values, _defaults = slip.get_data_for_eval()
    result = {'salary_structure': structure.name, 'currency': structure.currency,
              'earnings': [], 'deductions': [], 'gross_pay': 0, 'total_deduction': 0,
              'pending_components': [], 'structure_only': True}
    # Use HRMS's safe formula evaluator and abbreviation map, in template order.
    # Payment-day reductions, loans and Additional Salary belong to Payroll.
    slip.set_salary_structure_doc()
    for kind in ('earnings', 'deductions'):
        for row in slip._salary_structure_doc.get(kind):
            item = row.as_dict()
            if row.variable_based_on_taxable_salary and not row.amount_based_on_formula and not row.amount:
                item['amount'] = None
                result['pending_components'].append(row.salary_component)
            else:
                item['amount'] = frappe.utils.flt(slip.eval_condition_and_formula(row, values))
                values[row.abbr] = item['amount']
            result[kind].append(item)
            if not row.statistical_component and not row.do_not_include_in_total:
                key = 'gross_pay' if kind == 'earnings' else 'total_deduction'
                result[key] += item['amount'] or 0
    result['net_pay'] = frappe.utils.flt(result['gross_pay'] - result['total_deduction'],
                                      slip.precision('net_pay'))
    _attach_pdb_codes(result['earnings'])
    _attach_pdb_codes(result['deductions'])
    return result


def _row3_base(employee):
    from karyo.setup.payroll_profiles import prb_salary_value

    point = frappe.db.get_value('Employee', employee, 'karyo_prb_salary_point')
    return frappe.utils.flt(prb_salary_value(point, effective_date=today())) if point and frappe.db.get_value('Employee', employee, 'karyo_prb_opted_in') else 0


def sync_base_from_prb_point(employee, point=None, effective_date=None):
    """Create the effective native assignment carrying the selected Row-3 base."""
    emp = _employee(employee)
    emp.check_permission('write')
    from karyo.setup.payroll_profiles import prb_salary_value

    if not emp.get('karyo_prb_opted_in'):
        return None
    effective = getdate(effective_date or today())
    amount = frappe.utils.flt(prb_salary_value(point or emp.get('karyo_prb_salary_point'), effective_date=effective))
    if not amount:
        return None
    current_name = frappe.db.get_value(
        'Salary Structure Assignment',
        {'employee': employee, 'docstatus': 1, 'from_date': ('<=', effective)},
        'name', order_by='from_date desc, creation desc',
    )
    if not current_name:
        return None
    current = frappe.get_doc('Salary Structure Assignment', current_name)
    current.check_permission('read')
    if abs(frappe.utils.flt(current.base) - amount) < 0.005:
        return current.name
    if frappe.db.exists('Salary Slip', {
        'employee': employee, 'docstatus': 1, 'end_date': ('>=', effective),
    }):
        frappe.throw(_('Resolve submitted payslips for this period or later before changing the PRB Salary Point.'))
    if frappe.db.exists('Salary Structure Assignment', {
        'employee': employee, 'docstatus': 1, 'from_date': ('>', effective),
    }):
        frappe.throw(_('Resolve the future Salary Structure Assignment before changing the PRB Salary Point.'))

    assignment = frappe.copy_doc(current)
    assignment.update({'from_date': effective, 'base': amount, 'docstatus': 0, 'amended_from': None})
    frappe.db.savepoint('sync_employee_prb_base')
    try:
        if getdate(current.from_date) == effective:
            current.cancel()
            assignment.amended_from = current.name
        assignment.insert()
        assignment.submit()
    except Exception:
        frappe.db.rollback(save_point='sync_employee_prb_base')
        raise
    from karyo.payroll.salary_scales import _refresh_draft_salary_slips

    _refresh_draft_salary_slips(employee, effective, '9999-12-31')
    return assignment.name


@frappe.whitelist(methods=["POST"])
def select_structure(employee, salary_structure):
    """Save the selection through the native assignment used by Payroll."""
    emp = _employee(employee)
    emp.check_permission('write')
    frappe.db.sql('select name from `tabEmployee` where name=%s for update', employee)
    structure = frappe.get_doc('Salary Structure', salary_structure)
    structure.check_permission('read')
    if (structure.company != emp.company or structure.docstatus != 1
            or structure.is_active != 'Yes' or structure.payroll_frequency != 'Monthly'):
        frappe.throw(_('Select an active, submitted monthly Salary Structure for this company.'))
    start, end = _month(None)
    effective = max(start, getdate(emp.date_of_joining)) if emp.date_of_joining else start
    if effective > end:
        frappe.throw(_('Salary can be assigned after the employee joins.'))
    current = context(employee)['current']
    if current and current.salary_structure == salary_structure:
        return component_table(employee)
    if frappe.db.exists('Salary Slip', {'employee': employee, 'docstatus': 1,
                                       'end_date': ('>=', effective)}):
        frappe.throw(_('Resolve submitted payslips for this month or later in Payroll before changing the Salary Structure.'))
    if frappe.db.exists('Salary Structure Assignment', {'employee': employee, 'docstatus': 1,
                                                       'from_date': ('>', effective)}):
        frappe.throw(_('Resolve the future Salary Structure Assignment in Payroll Setup before changing this selection.'))
    previous_name = frappe.db.get_value('Salary Structure Assignment',
        {'employee': employee, 'docstatus': 1, 'from_date': ('<=', effective)},
        'name', order_by='from_date desc')
    previous = frappe.get_doc('Salary Structure Assignment', previous_name) if previous_name else None
    if previous:
        previous.check_permission('read')
        assignment = frappe.copy_doc(previous)
    else:
        assignment = frappe.new_doc('Salary Structure Assignment')
        assignment.base = _row3_base(employee) or emp.get('karyo_scale_basic_salary') or 0
        if not assignment.base and emp.grade:
            grade = frappe.get_doc('Employee Grade', emp.grade)
            grade.check_permission('read')
            if grade.default_salary_structure == salary_structure:
                assignment.base = grade.default_base_pay or 0
    # A PRB Row-3 point is the authoritative base regardless of whether the
    # selected structure was copied from an earlier assignment.
    row3_base = _row3_base(employee)
    if row3_base:
        assignment.base = row3_base
    assignment.update({'employee': employee, 'company': emp.company,
                       'salary_structure': salary_structure, 'from_date': effective, 'docstatus': 0})
    assignment.amended_from = None
    # Preserve same-month history with native cancel/amend and link checks.
    frappe.db.savepoint('select_employee_salary_structure')
    try:
        if previous and getdate(previous.from_date) == effective:
            previous.cancel()
            assignment.amended_from = previous.name
        assignment.insert()
        assignment.submit()
    except Exception:
        frappe.db.rollback(save_point='select_employee_salary_structure')
        raise
    from karyo.payroll.salary_scales import _refresh_draft_salary_slips

    _refresh_draft_salary_slips(employee, effective, '9999-12-31')
    return component_table(employee)
