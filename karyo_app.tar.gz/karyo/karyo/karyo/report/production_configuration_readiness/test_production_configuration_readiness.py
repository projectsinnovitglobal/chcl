import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.production_configuration_readiness.production_configuration_readiness import (
	REQUIRED_TYPES,
	_assess,
	execute,
)


class TestProductionConfigurationReadiness(FrappeTestCase):
	def test_demo_configuration_is_blocked(self):
		row = frappe._dict(
			configuration_status="Demo",
			is_production_eligible=0,
			effective_from="2026-01-01",
			effective_to=None,
			source_reference="Demo",
			approval_reference=None,
		)
		result = _assess(row, frappe.utils.getdate("2026-09-02"))
		self.assertEqual(result.readiness, "Blocked")
		self.assertIn("Missing approval reference", result.blocking_reason)

	def test_report_exposes_all_required_configuration_gaps(self):
		_columns, data = execute({"on_date": "2026-09-02", "company": "__NO_SUCH_COMPANY__"})
		self.assertTrue(data)
		missing_types = {row.configuration_type for row in data if row.readiness == "Missing"}
		self.assertTrue(set(REQUIRED_TYPES).issubset(missing_types | {row.configuration_type for row in data}))
		self.assertTrue(any(row.readiness == "Blocked" for row in data if row.config_key))
