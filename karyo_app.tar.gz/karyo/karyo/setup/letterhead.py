"""Compatibility entry point for the retired Letter Head setup."""


def setup():
	from karyo.patches.remove_letter_head_dependency import execute

	execute()
	print("Letter Head dependency removed.")
