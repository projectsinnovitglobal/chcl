from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.payroll_master_completeness.payroll_master_completeness import _assess


class TestPayrollMasterCompleteness(FrappeTestCase):
	@patch("frappe.db.get_value", return_value=("Active", 1))
	def test_complete_active_master_is_ready(self, _get_value):
		record = frappe._dict(name="PDB-1", pdb_code="001", salary_component="Basic", configuration_version="CFG-1", is_active=1)
		row = _assess("Payroll PDB Code", record, "pdb_code", ("salary_component", "configuration_version"), frappe.utils.getdate("2026-09-03"))
		self.assertEqual(row["status"], "Ready")

	@patch("frappe.db.get_value", return_value=("Draft", 0))
	def test_missing_mapping_and_draft_configuration_are_blocked(self, _get_value):
		record = frappe._dict(name="PDB-2", pdb_code="002", salary_component=None, configuration_version="CFG-2", is_active=1)
		row = _assess("Payroll PDB Code", record, "pdb_code", ("salary_component", "configuration_version"), frappe.utils.getdate("2026-09-03"))
		self.assertEqual(row["status"], "Blocked")
		self.assertIn("Missing salary component", row["finding"])
		self.assertIn("not production eligible", row["finding"])
