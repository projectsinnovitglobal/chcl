"""Demo personas — logins, role wiring, company scoping and the staged in-flight
documents the client-demo storyline needs (see docs/demo/02_demo_storyline.md and
docs/demo/03_personas_and_logins.md at the bench root).

    bench --site dev.localhost execute karyo.setup.demo_logins.seed

Idempotent: safe to re-run before every demo/rehearsal — it recreates whatever
was consumed (the loan awaiting committee review, the PB application at
Pending Approval, this week's approved leave) and re-asserts users, roles,
passwords and company scoping. Demo site only.
"""

import frappe
from frappe.model.workflow import apply_workflow
from frappe.utils import add_days, nowdate
from frappe.utils.password import update_password

COMPANY = "SIL"
PASSWORD = "SIL@Demo2026"

# (email, employee_name, roles) — employees exist in the MAI demo dataset.
PERSONAS = [
	("marie.laurent@sil.mu", "Marie-Ange Laurent", ["HR Manager", "HR User", "Employee", "Leave Approver"]),
	("sanjay.b@sil.mu", "Sanjay Bhugowandeen", ["Karyo Loan Committee", "Employee", "Leave Approver"]),
	("kevin.liying@sil.mu", "Kevin Li Ying", ["Karyo Finance", "Accounts User", "Employee"]),
	("yashna.s@sil.mu", "Yashna Seebaluck", ["HR User", "Employee"]),
	("leela.chuttoo@sil.mu", "Leela Chuttoo", ["Employee"]),
]

# Staged in-flight documents (consumed live during the demo, restored by re-running)
COMMITTEE_LOAN_EMPLOYEE = "Ravish Gopee"  # Act 3: Sanjay recommends this application
COMMITTEE_LOAN_GUARANTORS = ["Jean-Noël Baptiste", "Roshan Jugurnauth"]
PENDING_PB_EMPLOYEE = "Kritika Ramdhony"  # Act 2: sits in Marie's queue (don't approve until Act 5)
ON_LEAVE_THIS_WEEK = ["Nathalie Rousseau", "Ashok Ramkissoon"]  # AI: "who is on leave this week?"


def _emp(full_name):
	return frappe.db.get_value(
		"Employee", {"employee_name": full_name, "company": COMPANY}, ["name", "employee_name"], as_dict=True
	)


def _block(label, fn):
	try:
		fn()
		frappe.db.commit()
		print(f"  + {label}")
	except Exception as e:
		frappe.db.rollback()
		print(f"  ! {label} skipped: {e}")


def _make_user(email, employee_name, roles):
	emp = _emp(employee_name)
	if not emp:
		raise frappe.DoesNotExistError(f"Employee {employee_name} not found in {COMPANY}")
	first, _, last = employee_name.partition(" ")
	if frappe.db.exists("User", email):
		user = frappe.get_doc("User", email)
	else:
		user = frappe.get_doc(
			{
				"doctype": "User",
				"email": email,
				"first_name": first,
				"last_name": last,
				"send_welcome_email": 0,
				"user_type": "System User",
			}
		)
		user.insert(ignore_permissions=True)
	user.add_roles(*roles)
	update_password(email, PASSWORD, logout_all_sessions=True)

	# Link the Employee record (drives My HR / ESS and own-record permissions)
	frappe.db.set_value("Employee", emp.name, "user_id", email)

	# Scope everything with a company link to the demo company — keeps _Test* data
	# (kept for the automated test suite) out of every list, report and AI answer.
	if not frappe.db.exists("User Permission", {"user": email, "allow": "Company", "for_value": COMPANY}):
		frappe.get_doc(
			{
				"doctype": "User Permission",
				"user": email,
				"allow": "Company",
				"for_value": COMPANY,
			}
		).insert(ignore_permissions=True)

	# A pure employee persona must only see documents linked to their own
	# Employee record. Company scoping alone would expose every SIL employee's
	# leave, attendance, expenses and payslips in standard list views.
	if set(roles) == {"Employee"} and not frappe.db.exists(
		"User Permission", {"user": email, "allow": "Employee", "for_value": emp.name}
	):
		frappe.get_doc(
			{
				"doctype": "User Permission",
				"user": email,
				"allow": "Employee",
				"for_value": emp.name,
				"apply_to_all_doctypes": 1,
			}
		).insert(ignore_permissions=True)


def verify_employee_scope(email="leela.chuttoo@sil.mu"):
	"""Return employee values visible through the standard permission engine."""
	employee = frappe.db.get_value("Employee", {"user_id": email}, "name")
	if not employee:
		raise frappe.DoesNotExistError(f"No Employee is linked to {email}")

	result = {"expected_employee": employee}
	previous_user = frappe.session.user
	try:
		frappe.set_user(email)
		for doctype in ("Leave Application", "Attendance", "Expense Claim", "Salary Slip"):
			result[doctype] = {
				"count": len(frappe.get_list(doctype, fields=["name"], limit_page_length=1000)),
				"employees": frappe.get_list(doctype, pluck="employee", distinct=True, limit_page_length=1000),
			}
	finally:
		frappe.set_user(previous_user)
	return result


def verify_employee_loans(email="leela.chuttoo@sil.mu"):
	"""Exercise the My Loans endpoint as the demo employee, not Administrator."""
	previous_user = frappe.session.user
	try:
		frappe.set_user(email)
		from karyo.desk.overview import my_loans

		data = my_loans()
		return {
			"user": email,
			"employee": (data.get("employee") or {}).get("name"),
			"loan_types": len(data.get("loan_types") or []),
			"loans": [
				{
					"label": loan.get("label"),
					"status": loan.get("workflow_state") or loan.get("status"),
					"schedule_count": loan.get("schedule_count"),
					"next_due": loan.get("next_due"),
				}
				for loan in data.get("loans") or []
			],
		}
	finally:
		frappe.set_user(previous_user)


def _users():
	for email, employee_name, roles in PERSONAS:
		_make_user(email, employee_name, roles)


def _relabel_demo_records():
	"""Point records of demo-company employees at the demo company (cosmetic but
	client-visible: PB banks historically carried the placeholder company)."""
	mai_employees = frappe.get_all("Employee", filters={"company": COMPANY}, pluck="name")
	for doctype in ("Passage Benefit Bank", "Karyo Loan", "Passage Benefit Application"):
		for name in frappe.get_all(
			doctype,
			filters={"employee": ["in", mai_employees], "company": ["!=", COMPANY]},
			pluck="name",
		):
			frappe.db.set_value(doctype, name, "company", COMPANY, update_modified=False)


def _committee_loan():
	emp = _emp(COMMITTEE_LOAN_EMPLOYEE)
	if frappe.db.exists("Karyo Loan", {"employee": emp.name, "workflow_state": "Loan Committee Scheduled"}):
		return
	loan = frappe.get_doc(
		{
			"doctype": "Karyo Loan",
			"employee": emp.name,
			"loan_type": "PERSONAL",
			"company": COMPANY,
			"approved_amount": 250000,
			"period_months": 48,
			"eligible_salary": 55000,
			"disbursement_date": add_days(nowdate(), 14),
			"repayment_start_date": add_days(nowdate(), 14),
			"guarantors": [{"guarantor": _emp(g).name} for g in COMMITTEE_LOAN_GUARANTORS],
		}
	)
	loan.insert(ignore_permissions=True)
	# Park the demo loan awaiting committee review.
	loan = apply_workflow(loan, "Print Application")
	apply_workflow(loan, "Schedule Committee")


def _pending_pb_application():
	emp = _emp(PENDING_PB_EMPLOYEE)
	if frappe.db.exists(
		"Passage Benefit Application", {"employee": emp.name, "workflow_state": "Pending Approval"}
	):
		return
	app = frappe.get_doc(
		{
			"doctype": "Passage Benefit Application",
			"employee": emp.name,
			"company": COMPANY,
			"usage_item": "AIRTICKET",
			"request_amount": 4000,
			"posting_date": nowdate(),
			"pay_period": frappe.utils.getdate().strftime("%b-%Y"),
		}
	)
	app.insert(ignore_permissions=True)
	apply_workflow(app, "Submit for Approval")


def _leave_this_week():
	"""Approved leave overlapping the demo week so 'who is on leave?' has an answer."""
	for i, full_name in enumerate(ON_LEAVE_THIS_WEEK):
		emp = _emp(full_name)
		# 3 calendar days max — Casual Leave (the shortest-capped type) allows no more.
		from_date, to_date = add_days(nowdate(), i), add_days(nowdate(), i + 2)
		if frappe.db.exists(
			"Leave Application",
			{"employee": emp.name, "status": "Approved", "to_date": [">=", nowdate()]},
		):
			continue
		leave_type = frappe.db.get_value(
			"Leave Allocation",
			{"employee": emp.name, "docstatus": 1, "to_date": [">=", to_date], "leave_type": "Annual Leave"},
			"leave_type",
		) or frappe.db.get_value(
			"Leave Allocation",
			{"employee": emp.name, "docstatus": 1, "to_date": [">=", to_date]},
			"leave_type",
		)
		if not leave_type:
			continue
		leave = frappe.get_doc(
			{
				"doctype": "Leave Application",
				"employee": emp.name,
				"leave_type": leave_type,
				"from_date": from_date,
				"to_date": to_date,
				"status": "Approved",
				"leave_approver": PERSONAS[0][0],
				"description": "Demo: approved leave for the demo week.",
			}
		)
		leave.insert(ignore_permissions=True)
		leave.submit()


def seed():
	print(f"Seeding demo logins + staged documents for {COMPANY}...")
	_block("demo users, roles, passwords, company scoping", _users)
	_block("relabel demo records to demo company", _relabel_demo_records)
	_block(f"loan awaiting committee ({COMMITTEE_LOAN_EMPLOYEE})", _committee_loan)
	_block(f"PB application at Pending Approval ({PENDING_PB_EMPLOYEE})", _pending_pb_application)
	_block("approved leave this week", _leave_this_week)
	frappe.clear_cache()
	print("Done. Logins (password SIL@Demo2026):")
	for email, employee_name, roles in PERSONAS:
		print(f"  {email:26s} {employee_name:22s} [{', '.join(roles)}]")
