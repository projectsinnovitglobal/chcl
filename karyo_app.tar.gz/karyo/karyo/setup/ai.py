"""Karyo AI setup — assistant configuration Single (GEN-001: config, not code)."""

import frappe

from karyo.setup.foundation import f, make_doctype


def setup():
	make_doctype(
		"Karyo AI Settings",
		issingle=1,
		fields=[
			f("general_sb", "Section Break", "Assistant"),
			f("enabled", "Check", "Enable MBC AI", default="1"),
			f(
				"demo_mode",
				"Check",
				"Demo Mode",
				description=(
					"Answer from live data with the built-in scripted assistant — "
					"no AI engine or API key needed. For demos and evaluation."
				),
			),
			f("assistant_name", "Data", "Assistant Name", default="MBC AI"),
			f("cb0", "Column Break"),
			f("model", "Data", "Model", default="claude-opus-4-8"),
			f("max_output_tokens", "Int", "Max Output Tokens", default="4096"),
			f("max_tool_turns", "Int", "Max Tool Turns per Question", default="8"),
			f("auth_sb", "Section Break", "Authentication"),
			f(
				"api_key",
				"Password",
				"Anthropic API Key",
				description="Falls back to `anthropic_api_key` in site_config.json when blank.",
			),
			f("prompt_sb", "Section Break", "Prompting"),
			f(
				"extra_instructions",
				"Small Text",
				"Extra System Instructions",
				description="Appended to the assistant's system prompt (tone, org-specific guidance).",
			),
		],
	)
	frappe.db.commit()
