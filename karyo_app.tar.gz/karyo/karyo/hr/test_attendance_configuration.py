import json
from pathlib import Path
import unittest

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.roster import attendance_configuration_rows


SOURCE = Path(__file__).resolve().parents[1] / "payroll" / "data" / "attendance_configuration_template.json"


class TestAttendanceConfigurationSheet(unittest.TestCase):
	def test_live_sheet_structure_is_captured_without_sample_data(self):
		payload = json.loads(SOURCE.read_text())
		self.assertEqual(payload["workbook_title"], "Attendance")
		self.assertEqual(payload["sheet"], "Sheet2")
		self.assertEqual(payload["range"], "A1:Q4")
		self.assertEqual(payload["header_row"], 3)
		self.assertEqual(payload["excluded_rows"], [4])
		self.assertEqual(payload["rows"], [])
		self.assertEqual(payload["columns"], [
			"Record Type*", "Code*", "Description*", "Department", "Section", "Location",
			"Employee Category", "Working Days", "Normal Start", "Normal End", "Daily Hours",
			"Saturday Working?", "Sunday Working?", "PH Treatment", "Effective From*",
			"Effective To", "Remarks",
		])


class TestAttendanceConfigurationRegister(FrappeTestCase):
	def test_register_uses_exact_sheet_fields_and_master_dependencies(self):
		rows = attendance_configuration_rows()
		self.assertTrue(rows)
		required = {
			"record_type", "code", "description", "department", "section", "location",
			"employee_category", "working_days", "normal_start", "normal_end", "daily_hours",
			"saturday_working", "sunday_working", "ph_treatment", "effective_from",
			"effective_to", "remarks", "doctype", "name",
		}
		self.assertTrue(required.issubset(rows[0]))
		self.assertTrue({"Shift", "Work Pattern", "Calendar"}.issubset({row["record_type"] for row in rows}))
		shift = next(row for row in rows if row["record_type"] == "Shift")
		self.assertEqual(shift["doctype"], "Shift Type")
		self.assertGreater(float(shift["daily_hours"]), 0)
