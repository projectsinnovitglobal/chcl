import unittest

import frappe

from karyo.payroll.process import prepare_entry_population


class _Entry(frappe._dict):
	def __init__(self, *, docstatus):
		super().__init__(
			name="PAYROLL-ENTRY-1",
			company="Test Company",
			karyo_payroll_cycle="CYCLE-1",
			docstatus=docstatus,
			status="Submitted" if docstatus == 1 else "Draft",
			employees=[frappe._dict(employee="EMP-1")],
		)
		self.saved = False

	def append(self, fieldname, values):
		self[fieldname].append(frappe._dict(values))

	def save(self):
		self.saved = True


class TestPayrollPopulationAmendment(unittest.TestCase):
	def setUp(self):
		self.cycle = frappe._dict(name="CYCLE-1", company="Test Company")

	def test_submitted_entry_stays_immutable_and_returns_supplement(self):
		entry = _Entry(docstatus=1)

		result = prepare_entry_population(self.cycle, entry, ["EMP-1", "EMP-2"])

		self.assertEqual(result, {"added": [], "supplemental": ["EMP-2"]})
		self.assertEqual([row.employee for row in entry.employees], ["EMP-1"])
		self.assertFalse(entry.saved)

	def test_draft_entry_adds_missing_employee_normally(self):
		entry = _Entry(docstatus=0)

		result = prepare_entry_population(self.cycle, entry, ["EMP-1", "EMP-2"])

		self.assertEqual(result, {"added": ["EMP-2"], "supplemental": []})
		self.assertEqual([row.employee for row in entry.employees], ["EMP-1", "EMP-2"])
		self.assertTrue(entry.saved)
