"""Seed fields introduced by the Attendance-calculation control sheet."""

import frappe

from karyo.setup.prb_settings import DEFAULTS


FIELDS = (
	"ot_middle_band_factor",
	"ot_middle_band_requires_urgent",
	"night_duty_annual_months",
	"night_duty_hours_denominator",
	"night_duty_rate_multiplier",
	"attendance_bonus_base",
	"incentive_attendance_bonus_base",
	"incentive_presence_base",
	"era_minimum_hours",
	"era_full_payment_hours",
	"era_lower_salary_max",
	"era_lower_rate",
	"era_lower_cap",
	"era_upper_salary_min",
	"era_upper_salary_max",
	"era_upper_rate",
	"era_upper_cap",
	"era_working_days_divisor",
	"era_casual_leave_exemption",
)


def execute():
	for fieldname in FIELDS:
		frappe.db.set_single_value("PRB Payroll Settings", fieldname, DEFAULTS[fieldname])
	frappe.clear_document_cache("PRB Payroll Settings", "PRB Payroll Settings")

	# ERA is now a first-class payroll component. Demo mappings remain editable
	# and the seeder does not modify production mappings.
	from karyo.setup.prb_posting import seed_demo_mappings

	seed_demo_mappings()
