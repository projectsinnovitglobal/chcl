"""Effective-dated employee/employer contribution schemes (PAY-015)."""

import json

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Payroll Contribution Band",
		istable=1,
		fields=[
			f("lower_salary", "Currency", "Lower Salary", reqd=1, in_list_view=1),
			f("upper_salary", "Currency", "Upper Salary", in_list_view=1),
			f("is_open_ended", "Check", "No Upper Limit", default="0", in_list_view=1),
			f("employee_value", "Float", "Employee Rate / Amount", reqd=1, in_list_view=1),
			f("employer_value", "Float", "Employer Rate / Amount", reqd=1, in_list_view=1),
		],
	)
	make_doctype(
		"Payroll Contribution Scheme",
		autoname="format:{scheme_code}-{version}",
		title_field="description",
		fields=[
			f("identity_sb", "Section Break", "Scheme Identity"),
			f("scheme_code", "Data", "Scheme Code", reqd=1, in_list_view=1),
			f("version", "Data", "Version", reqd=1, default="DEMO-1", in_list_view=1),
			f("description", "Data", "Description", reqd=1, in_list_view=1),
			f("company", "Link", "Company", options="Company", in_standard_filter=1),
			f("identity_cb", "Column Break"),
			f(
				"calculation_mode",
				"Select",
				"Calculation Mode",
				options="Percentage\nFlat Amount",
				default="Percentage",
				reqd=1,
				in_list_view=1,
			),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("allow_band_gaps", "Check", "Allow Intentional Band Gaps", default="0"),
			f("mapping_sb", "Section Break", "Payroll and Basis Mapping"),
			f(
				"basis_operation_code",
				"Link",
				"Salary Basis Operation Code",
				options="Payroll Operation Code",
				reqd=1,
			),
			f(
				"employee_pdb_code",
				"Link",
				"Employee Deduction PDB",
				options="Payroll PDB Code",
				reqd=1,
			),
			f("mapping_cb", "Column Break"),
			f(
				"employer_salary_component",
				"Link",
				"Employer Contribution Component",
				options="Salary Component",
				reqd=1,
			),
			f("employee_ceiling", "Currency", "Employee Salary Ceiling"),
			f("employer_ceiling", "Currency", "Employer Salary Ceiling"),
			f("rounding_sb", "Section Break", "Rounding and Accounting"),
			f("rounding_precision", "Int", "Rounding Precision", default="2", reqd=1),
			f(
				"rounding_method",
				"Select",
				"Rounding Method",
				options="Round Half Up\nRound Half to Even",
				default="Round Half Up",
				reqd=1,
			),
			f("rounding_cb", "Column Break"),
			f("employee_account", "Link", "Employee Deduction Account", options="Account", hidden=1, read_only=1),
			f("employer_account", "Link", "Employer Contribution Account", options="Account", hidden=1, read_only=1),
			f("bands_sb", "Section Break", "Salary Bands — Bounds are Inclusive"),
			f("bands", "Table", "Contribution Bands", options="Payroll Contribution Band", reqd=1),
			f("validity_sb", "Section Break", "Validity and Governance"),
			f("effective_from", "Date", "Effective From", reqd=1, in_list_view=1),
			f("effective_to", "Date", "Effective To"),
			f(
				"configuration_version",
				"Link",
				"Configuration Version",
				options="Payroll Configuration Version",
				reqd=1,
			),
			f("source_reference", "Data", "Source Reference"),
			f("notes", "Small Text", "Notes"),
		],
	)
	_ensure_upgrade_fields()


def _ensure_upgrade_fields():
	band_meta = frappe.get_doc("DocType", "Payroll Contribution Band")
	if not any(row.fieldname == "is_open_ended" for row in band_meta.fields):
		band_meta.append("fields", f("is_open_ended", "Check", "No Upper Limit", default="0"))
		band_meta.save(ignore_permissions=True)
	scheme_meta = frappe.get_doc("DocType", "Payroll Contribution Scheme")
	changed = False
	if not any(row.fieldname == "version" for row in scheme_meta.fields):
		scheme_meta.append("fields", f("version", "Data", "Version", reqd=1, default="DEMO-1"))
		changed = True
	if scheme_meta.autoname != "format:{scheme_code}-{version}":
		scheme_meta.autoname = "format:{scheme_code}-{version}"
		scheme_meta.naming_rule = "Expression (old style)"
		changed = True
	if changed:
		scheme_meta.save(ignore_permissions=True)
	frappe.db.sql(
		"""update `tabPayroll Contribution Scheme`
		set version = 'DEMO-1' where ifnull(version, '') = ''"""
	)


def _ensure_employer_component():
	name = "Employer CSG (Demo)"
	if frappe.db.exists("Salary Component", name):
		return name
	return frappe.get_doc(
		{
			"doctype": "Salary Component",
			"salary_component": name,
			"salary_component_abbr": "ECSGD",
			"type": "Deduction",
			"depends_on_payment_days": 1,
			"is_tax_applicable": 0,
			"disabled": 0,
		}
	).insert(ignore_permissions=True).name


def seed_demo_data():
	existing = frappe.db.get_value(
		"Payroll Contribution Scheme", {"scheme_code": "CSG-DEMO", "version": "DEMO-1"}, "name"
	)
	if existing:
		last_band = frappe.db.get_value(
			"Payroll Contribution Band",
			{"parent": existing},
			"name",
			order_by="idx desc",
		)
		if last_band:
			frappe.db.set_value("Payroll Contribution Band", last_band, "is_open_ended", 1)
		return
	configuration = frappe.db.get_value(
		"Payroll Configuration Version",
		{"config_key": "DEMO-CONTRIBUTIONS-2026", "version": "DEMO-1"},
		"name",
	)
	if not configuration or not frappe.db.exists("Payroll PDB Code", "CSG"):
		return
	frappe.get_doc(
		{
			"doctype": "Payroll Contribution Scheme",
			"scheme_code": "CSG-DEMO",
			"version": "DEMO-1",
			"description": "CSG Contribution (Demo — illustrative only)",
			"calculation_mode": "Percentage",
			"basis_operation_code": "GSAL",
			"employee_pdb_code": "CSG",
			"employer_salary_component": _ensure_employer_component(),
			"rounding_precision": 2,
			"rounding_method": "Round Half Up",
			"is_active": 1,
			"effective_from": "2026-01-01",
			"configuration_version": configuration,
			"source_reference": "DEMO ONLY — rates are not statutory values",
			"bands": [
				{
					"lower_salary": 0,
					"upper_salary": 50000,
					"employee_value": 1,
					"employer_value": 2,
				},
				{
					"lower_salary": 50000.01,
					"is_open_ended": 1,
					"employee_value": 1.5,
					"employer_value": 3,
				},
			],
			"notes": "Illustrative bands for development; replace before production.",
		}
	).insert(ignore_permissions=True)


def ensure_received_configuration():
	"""Register the received workbook as Draft pending mapping/activation."""
	existing = frappe.db.get_value(
		"Payroll Configuration Version",
		{"config_key": "MBC-CONTRIBUTIONS-2025-26", "version": "RECEIVED-1"},
		"name",
	)
	if existing:
		return existing
	doc = frappe.get_doc(
		{
			"doctype": "Payroll Configuration Version",
			"config_key": "MBC-CONTRIBUTIONS-2025-26",
			"configuration_type": "Contribution",
			"version": "RECEIVED-1",
			"configuration_status": "Draft",
			"is_production_eligible": 0,
			"effective_from": "2025-07-01",
			"source_reference": "Employer_Employee_Contribution_Registration.xlsx",
			"configuration_json": json.dumps(
				{
					"normalized_csv": "docs/Payroll/Payroll_Contribution_Client_Received_2025_26.csv",
					"schemes": ["CSG", "PCDC", "FPS", "CSFPS", "PENSION", "LEVY", "NSFP", "NSFC", "SIC2", "NPF"],
					"status": "Validated source rows; PDB and employer component mappings pending",
				},
				indent=2,
			),
			"notes": "Draft received configuration. Do not activate until mappings and effective dates are approved.",
		}
	).insert(ignore_permissions=True)
	frappe.db.set_value("Payroll Configuration Version", doc.name, "company", None)
	return doc.name


def setup():
	print("Karyo Payroll contribution setup:")
	create_doctypes()
	from karyo.install import samples_enabled

	if samples_enabled():
		# Re-run PDB seed so the demo CSG mapping is available on demo/test sites.
		from karyo.setup.payroll_pdb import seed_demo_data as seed_pdb_demo

		seed_pdb_demo()
		seed_demo_data()
	ensure_received_configuration()
	frappe.db.commit()
	print("Done (contribution schemes, bands, calculator mappings, and demo data created).")
