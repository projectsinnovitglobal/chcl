"""Controlled bulk increment, compensation, and EOY processing (PAY-042)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Bulk Payroll Run Line",
		istable=1,
		fields=[
			f("include", "Check", "Include", default="1", in_list_view=1),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", read_only=1, in_list_view=1),
			f("salary_appointment", "Link", "Salary Appointment", options="Employee Salary Appointment", read_only=1),
			f("salary_scale", "Link", "Increment Table", options="Salary Scale", read_only=1),
			f("increment_source", "Data", "Increment Source", read_only=1),
			f("increment_steps", "Int", "Increment Points", default="1", description="Number of salary points awarded on the effective date. For example, when one point is worth 100, 2 points add 200."),
			f("applied_increment_points", "Int", "Applied Points", read_only=1, description="Points actually applied after enforcing the top of the approved salary scale."),
			f("original_salary_point", "Data", "Original Point", read_only=1),
			f("proposed_salary_point", "Data", "Proposed Point", read_only=1),
			f("increment_base", "Currency", "Basic Salary", read_only=1),
			f("proposed_salary", "Currency", "Proposed Salary", read_only=1),
			f("salary_basis", "Currency", "Salary Basis", read_only=1),
			f("increment_amount", "Currency", "Increment", read_only=1),
			f("compensation_amount", "Currency", "Compensation", read_only=1),
			f("eoy_amount", "Currency", "EOY Bonus", read_only=1),
			f("lwp_days", "Float", "LWP/LWNP Days"),
			f("service_days", "Int", "Eligible Service Days", read_only=1),
			f("day_count_denominator", "Int", "Day-count Denominator", read_only=1),
			f("calculated_total", "Currency", "Calculated Total", read_only=1),
			f("override_enabled", "Check", "Override", default="0"),
			f("override_amount", "Currency", "Controlled Override"),
			f("override_reason", "Small Text", "Override Reason"),
			f("final_total", "Currency", "Final Total", read_only=1, in_list_view=1),
			f("exception_code", "Data", "Exception", read_only=1, in_list_view=1),
			f("exception_detail", "Small Text", "Exception Detail", read_only=1),
			f("prb_payroll_run", "Link", "PRB Payroll Run", options="PRB Payroll Run", read_only=1),
			f("compensation_additional_salary", "Link", "Compensation Posting", options="Additional Salary", read_only=1),
			f("eoy_bonus", "Link", "EOY Bonus", options="EOY Bonus", read_only=1),
		],
	)
	make_doctype(
		"Bulk Payroll Run",
		autoname="naming_series:",
		title_field="run_title",
		fields=[
			f("naming_series", "Select", "Series", options="BPR-.YYYY.-.#####", default="BPR-.YYYY.-.#####"),
			f("run_title", "Data", "Run Title", reqd=1, in_list_view=1),
			f(
				"run_type",
				"Select",
				"Run Type",
				options="Increment\nCompensation\nIncrement + Compensation\nEOY Bonus",
				reqd=1,
				in_list_view=1,
			),
			f("company", "Link", "Company", options="Company", reqd=1),
			f("effective_date", "Date", "Effective Date", reqd=1),
			f("period_start", "Date", "Period Start", reqd=1),
			f("period_end", "Date", "Period End", reqd=1),
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle"),
			f("compensation_scheme", "Link", "Compensation Scheme", options="Payroll Compensation Scheme"),
			f("pdb_type", "Link", "PDB Type", options="Payroll PDB Type", reqd=1),
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1),
			f("filters_sb", "Section Break", "Employee Selection"),
			f("include_retired", "Check", "Include Retired Employees", default="0"),
			f("remarks", "Small Text", "Remarks"),
			f("control_sb", "Section Break", "Control"),
			f(
				"status",
				"Select",
				"Status",
				options="Draft\nCalculated\nApproved\nApplied",
				default="Draft",
				reqd=1,
				read_only=1,
				in_list_view=1,
			),
			f("calculated_on", "Datetime", "Calculated On", read_only=1),
			f("approved_by", "Link", "Approved By", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
			f("applied_by", "Link", "Applied By", options="User", read_only=1),
			f("applied_on", "Datetime", "Applied On", read_only=1),
			f("totals_sb", "Section Break", "Reconciliation"),
			f("employee_count", "Int", "Employees", read_only=1),
			f("exception_count", "Int", "Exceptions", read_only=1),
			f("calculated_total", "Currency", "Calculated Total", read_only=1),
			f("approved_total", "Currency", "Approved Total", read_only=1),
			f("applied_total", "Currency", "Applied Total", read_only=1),
			f("reconciliation_difference", "Currency", "Difference", read_only=1),
			f("lines_sb", "Section Break", "Preview, Exceptions and Controlled Edits"),
			f("lines", "Table", "Employees", options="Bulk Payroll Run Line"),
		],
	)


def extend_eoy_bonus():
	create_custom_fields(
		{
			"EOY Bonus": [
				{
					"fieldname": "payroll_cycle",
					"fieldtype": "Link",
					"label": "December Payroll Cycle",
					"options": "Payroll Cycle",
					"read_only": 1,
					"insert_after": "year",
				},
				{
					"fieldname": "payroll_date",
					"fieldtype": "Date",
					"label": "December Payroll Date",
					"read_only": 1,
					"insert_after": "payroll_cycle",
				},
				{
					"fieldname": "service_days",
					"fieldtype": "Int",
					"label": "Eligible Service Days",
					"insert_after": "service_months",
				},
				{
					"fieldname": "day_count_denominator",
					"fieldtype": "Int",
					"label": "Day-count Denominator",
					"default": "365",
					"insert_after": "service_days",
				},
				{
					"fieldname": "bulk_payroll_run",
					"fieldtype": "Link",
					"label": "Bulk Payroll Run",
					"options": "Bulk Payroll Run",
					"read_only": 1,
					"insert_after": "additional_salary",
				},
				{
					"fieldname": "bulk_override_amount",
					"fieldtype": "Currency",
					"label": "Approved Bulk Override",
					"read_only": 1,
					"insert_after": "bulk_payroll_run",
				},
				{
					"fieldname": "bulk_override_enabled",
					"fieldtype": "Check",
					"label": "Approved Bulk Override Enabled",
					"read_only": 1,
					"insert_after": "bulk_override_amount",
				},
			]
		},
		ignore_validate=True,
	)


def setup():
	print("Karyo bulk payroll setup:")
	create_doctypes()
	extend_eoy_bonus()
	frappe.db.commit()
	print("Done (controlled increment, compensation, and EOY bulk workflow created).")
