"""The client's payroll reference data must be present and calculate correctly.

Sources: ``Employer_Employee_Contribution_Registration.xlsx`` (contribution
rates), the salary-scale guide (FAR17) and the MRA PAYE guide (Fair Share
Contribution).
"""

import unittest

import frappe

from karyo.payroll.contributions import calculate_contribution
from karyo.setup.mbc_payroll_reference import (
	FAIR_SHARE_RATE,
	FAIR_SHARE_THRESHOLD,
	REGISTER,
	VERSION,
	apply,
)

ON_DATE = "2025-08-31"


class TestMBCPayrollReference(unittest.TestCase):
	@classmethod
	def setUpClass(cls):
		frappe.set_user("Administrator")
		apply()

	def test_every_register_row_is_loaded_with_its_own_rates(self):
		for code, description, _ee, _er, bands, _gaps in REGISTER:
			name = f"{code}-{VERSION}"
			self.assertTrue(frappe.db.exists("Payroll Contribution Scheme", name), name)
			doc = frappe.get_doc("Payroll Contribution Scheme", name)
			self.assertEqual(doc.description, description)
			self.assertTrue(doc.is_active)
			loaded = [
				(row.lower_salary, row.upper_salary, row.employee_value, row.employer_value)
				for row in doc.bands
			]
			self.assertEqual(loaded, [tuple(float(v) for v in band) for band in bands])

	def test_csg_switches_band_at_fifty_thousand(self):
		low = calculate_contribution(f"CSG-{VERSION}", 40000, ON_DATE)
		high = calculate_contribution(f"CSG-{VERSION}", 80000, ON_DATE)
		self.assertEqual((low["employee_amount"], low["employer_amount"]), (0, 1800))
		self.assertEqual((high["employee_amount"], high["employer_amount"]), (0, 7200))

	def test_pension_uses_the_register_rates(self):
		result = calculate_contribution(f"PENSION-{VERSION}", 26050, ON_DATE)
		self.assertEqual(result["employee_amount"], 1563)
		self.assertEqual(result["employer_amount"], 4949.5)

	def test_contractual_nsf_starts_at_one_hundred_rupees(self):
		below = calculate_contribution(f"NSFC-{VERSION}", 50, ON_DATE)
		self.assertTrue(below["below_minimum"])
		self.assertEqual((below["employee_amount"], below["employer_amount"]), (0, 0))
		above = calculate_contribution(f"NSFC-{VERSION}", 30000, ON_DATE)
		self.assertEqual((above["employee_amount"], above["employer_amount"]), (300, 750))

	def test_far17_generates_the_documented_points(self):
		scale = frappe.get_doc("Salary Scale", {"scale_code": "FAR17"})
		self.assertEqual(scale.point_count, 38)
		self.assertEqual(scale.points[0].salary, 16785)
		self.assertEqual(scale.points[1].salary, 17045)
		self.assertEqual(scale.points[-1].salary, 34825)

	def test_fair_share_contribution_is_configured_on_the_active_paye_year(self):
		for name in frappe.get_all("Payroll PAYE Year", filters={"is_active": 1}, pluck="name"):
			year = frappe.get_doc("Payroll PAYE Year", name)
			self.assertEqual(year.fair_share_threshold, FAIR_SHARE_THRESHOLD)
			self.assertEqual(year.fair_share_rate, FAIR_SHARE_RATE)

	def test_every_prb_component_mapping_resolves_to_a_pdb_code(self):
		unresolved = [
			row.name
			for row in frappe.get_all(
				"PRB Payroll Component Mapping", fields=["name", "pdb_code"], filters={"is_active": 1}
			)
			if not frappe.db.exists("Payroll PDB Code", row.pdb_code)
		]
		self.assertEqual(unresolved, [])

	def test_client_facing_payroll_records_carry_no_demo_label(self):
		labelled = {}
		for doctype, fieldname in (
			("Payroll PDB Code", "description"),
			("Payroll Contribution Scheme", "description"),
			("PRB Payroll Component Mapping", "description"),
			("Salary Component", "name"),
			("Bank", "name"),
		):
			rows = frappe.get_all(doctype, filters={fieldname: ("like", "%(Demo%")}, pluck="name")
			if rows:
				labelled[doctype] = rows
		self.assertEqual(labelled, {})


if __name__ == "__main__":
	unittest.main()
