"""Validate and persist source-to-payroll calculation traces."""

import hashlib
import json

import frappe
from frappe import _
from frappe.utils import now_datetime


CATEGORY_BY_SOURCE = {
	"Karyo Loan": "Loan Deduction",
	"Karyo Loan Interest Change": "Loan Deduction",
	"Karyo Loan Recast": "Loan Deduction",
	"EOY Bonus": "EOY Bonus",
	"Passage Benefit Application": "Passage Benefit",
	"Passage Benefit Computation": "Passage Benefit",
	"Leave Encashment": "Leave Encashment",
	"PRB Payroll Run": "PRB Payroll",
	"Employee Recurring PDB Posting": "Recurring PDB",
	"Once-Off PDB Batch": "Once-off PDB",
	"Exceptional Payroll Batch": "Exceptional Payroll",
}


def assign_payroll_cycle(doc):
	"""Tag native and custom Additional Salary rows to their owning open cycle."""
	if doc.get("karyo_payroll_cycle") or not doc.employee:
		return
	payroll_date = doc.payroll_date or doc.from_date
	if not payroll_date:
		return
	company = doc.company or frappe.db.get_value("Employee", doc.employee, "company")
	from karyo.hr.leave_controls import _payroll_cycle_for_employee

	doc.karyo_payroll_cycle = _payroll_cycle_for_employee(
		doc.employee, company, payroll_date, payroll_date,
	)


TRACE_FIELDS = {
	"Karyo Loan": [
		"employee",
		"loan_reference_no",
		"approved_amount",
		"monthly_capital",
		"monthly_interest",
		"monthly_insurance",
		"repayment_start_date",
	],
	"EOY Bonus": ["employee", "year", "case", "monthly_salary", "acting_allowance", "bonus_amount"],
	"Passage Benefit Application": [
		"employee",
		"posting_date",
		"processing_route",
		"claimable_amount",
		"amount_taken",
	],
	"Passage Benefit Computation": [
		"employee",
		"from_date",
		"to_date",
		"pay_period",
		"eligible_days_total",
		"earned_amount",
		"payroll_pdb_type",
		"payroll_pdb_code",
	],
	"Leave Encashment": [
		"employee",
		"leave_type",
		"leave_allocation",
		"encashment_date",
		"encashment_days",
		"karyo_encashment_rate_per_day",
		"encashment_amount",
	],
	"PRB Payroll Run": [
		"employee",
		"period",
		"salary_point",
		"gross_pay",
		"exception_code",
		"snapshot_hash",
		"audit_trace",
	],
}


def validate_additional_salary_source(doc, method=None):
	assign_payroll_cycle(doc)
	if not doc.ref_doctype or not doc.ref_docname:
		return
	configured_category = doc.get("karyo_transaction_category")
	if doc.ref_doctype not in CATEGORY_BY_SOURCE and not configured_category:
		return
	category = configured_category or _source_category(doc)
	if not frappe.db.exists(doc.ref_doctype, doc.ref_docname):
		frappe.throw(_("Payroll source {0} {1} does not exist.").format(doc.ref_doctype, doc.ref_docname))
	pdb_code = frappe.db.get_value(
		"Payroll PDB Code", {"salary_component": doc.salary_component, "is_active": 1}, "name"
	)
	if not pdb_code:
		frappe.throw(
			_("Salary Component {0} has no active Payroll PDB mapping.").format(doc.salary_component)
		)
	doc.karyo_transaction_category = category
	doc.karyo_pdb_code = pdb_code
	doc.karyo_source_key = build_source_key(doc)
	duplicate = frappe.db.exists(
		"Additional Salary",
		{
			"name": ("!=", doc.name or ""),
			"karyo_source_key": doc.karyo_source_key,
			"docstatus": ("<", 2),
		},
	)
	if duplicate:
		frappe.throw(_("Payroll source is already posted as Additional Salary {0}.").format(duplicate))


def build_source_key(doc):
	period = doc.payroll_date or f"{doc.from_date or ''}:{doc.to_date or ''}"
	raw = "::".join(
		str(value or "")
		for value in (doc.ref_doctype, doc.ref_docname, doc.employee, doc.salary_component, period)
	)
	return hashlib.sha256(raw.encode()).hexdigest()


def _source_category(doc):
	if doc.ref_doctype == "PRB Payroll Run" and "overtime" in (doc.salary_component or "").lower():
		return "Overtime"
	return CATEGORY_BY_SOURCE[doc.ref_doctype]


def additional_salary_submitted(doc, method=None):
	if not doc.karyo_source_key:
		return
	values = _trace_values(doc)
	existing = frappe.db.get_value("Payroll Source Trace", {"source_key": doc.karyo_source_key}, "name")
	if existing:
		trace = frappe.get_doc("Payroll Source Trace", existing)
		trace.update(values)
		trace.status = "Posted"
		trace.reversed_on = None
		trace.save(ignore_permissions=True)
	else:
		trace = frappe.get_doc({"doctype": "Payroll Source Trace", **values}).insert(
			ignore_permissions=True
		)
	doc.db_set("karyo_source_trace", trace.name, update_modified=False)


def additional_salary_cancelled(doc, method=None):
	if doc.karyo_source_trace and frappe.db.exists("Payroll Source Trace", doc.karyo_source_trace):
		frappe.db.set_value(
			"Payroll Source Trace",
			doc.karyo_source_trace,
			{"status": "Reversed", "reversed_on": now_datetime()},
			update_modified=False,
		)


def _trace_values(doc):
	return {
		"source_key": doc.karyo_source_key,
		"category": doc.karyo_transaction_category,
		"source_doctype": doc.ref_doctype,
		"source_name": doc.ref_docname,
		"additional_salary": doc.name,
		"payroll_cycle": doc.karyo_payroll_cycle,
		"employee": doc.employee,
		"pdb_code": doc.karyo_pdb_code,
		"salary_component": doc.salary_component,
		"amount": doc.amount,
		"payment_date": doc.payroll_date or doc.from_date,
		"status": "Posted",
		"calculation_trace": json.dumps(build_calculation_snapshot(doc), sort_keys=True, default=str, indent=2),
		"posted_on": now_datetime(),
	}


def build_calculation_snapshot(doc):
	meta = frappe.get_meta(doc.ref_doctype)
	fields = [fieldname for fieldname in TRACE_FIELDS.get(doc.ref_doctype, []) if meta.has_field(fieldname)]
	source = frappe.db.get_value(doc.ref_doctype, doc.ref_docname, fields, as_dict=True) if fields else None
	return {
		"source": dict(source or {}),
		"output": {
			"employee": doc.employee,
			"salary_component": doc.salary_component,
			"pdb_code": doc.karyo_pdb_code,
			"amount": doc.amount,
			"payroll_date": doc.payroll_date,
			"from_date": doc.from_date,
			"to_date": doc.to_date,
		},
	}


@frappe.whitelist()
def reconcile_existing_sources():
	created = 0
	skipped = 0
	for name in frappe.get_all(
		"Additional Salary",
		filters={"ref_doctype": ("is", "set"), "ref_docname": ("is", "set"), "docstatus": 1},
		pluck="name",
	):
		doc = frappe.get_doc("Additional Salary", name)
		validate_additional_salary_source(doc)
		if not doc.karyo_source_key:
			skipped += 1
			continue
		doc.db_set(
			{
				"karyo_transaction_category": doc.karyo_transaction_category,
				"karyo_pdb_code": doc.karyo_pdb_code,
				"karyo_source_key": doc.karyo_source_key,
			},
			update_modified=False,
		)
		additional_salary_submitted(doc)
		created += 1
	return {"reconciled": created, "skipped": skipped}
