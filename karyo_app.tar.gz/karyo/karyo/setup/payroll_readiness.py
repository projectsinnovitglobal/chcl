"""Payroll readiness exception queue and cycle controls (PAY-022)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctype():
	make_doctype(
		"Payroll Readiness Exception",
		autoname="hash",
		title_field="validation_code",
		fields=[
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1),
			f("employee", "Link", "Employee", options="Employee", in_list_view=1),
			f("validation_code", "Data", "Code", reqd=1, in_list_view=1, in_standard_filter=1),
			f("identity_cb", "Column Break"),
			f(
				"severity",
				"Select",
				"Severity",
				options="Blocking\nApproval Required\nWarning",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f(
				"status",
				"Select",
				"Status",
				options="Open\nResolved\nWaived",
				default="Open",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f("details_sb", "Section Break", "Exception Details"),
			f("message", "Small Text", "Message", reqd=1),
			f("fingerprint", "Data", "Fingerprint", reqd=1, unique=1, read_only=1),
			f("excluded_doctype", "Link", "Excluded Type", options="DocType"),
			f("excluded_name", "Dynamic Link", "Excluded Record", options="excluded_doctype"),
			f("remediation_cb", "Column Break"),
			f("remediation_doctype", "Link", "Fix In", options="DocType"),
			f("remediation_name", "Dynamic Link", "Record to Fix", options="remediation_doctype"),
			f("resolution_sb", "Section Break", "Resolution"),
			f("resolution_note", "Small Text", "Resolution Note"),
			f("resolved_by", "Link", "Resolved By", options="User", read_only=1),
			f("resolved_on", "Datetime", "Resolved On", read_only=1),
			f("last_checked_on", "Datetime", "Last Checked On", read_only=1),
		],
	)


def add_cycle_fields():
	create_custom_fields(
		{
			"Payroll Cycle": [
				{
					"fieldname": "readiness_sb",
					"fieldtype": "Section Break",
					"label": "Payroll Readiness",
					"insert_after": "minor_reconciled_total",
				},
				{
					"fieldname": "readiness_status",
					"fieldtype": "Select",
					"label": "Readiness Status",
					"options": "Not Run\nReady\nBlocked",
					"default": "Not Run",
					"read_only": 1,
					"insert_after": "readiness_sb",
				},
				{
					"fieldname": "readiness_checked_on",
					"fieldtype": "Datetime",
					"label": "Readiness Checked On",
					"read_only": 1,
					"insert_after": "readiness_status",
				},
			],
		},
		ignore_validate=True,
	)


def setup():
	print("Karyo payroll readiness setup:")
	create_doctype()
	add_cycle_fields()
	frappe.db.commit()
	print("Done (readiness validation and exception queue created).")
