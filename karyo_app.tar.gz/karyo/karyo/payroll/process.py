"""Safe, repeatable Payroll Cycle orchestration (PAY-060)."""

import frappe
from frappe import _
from frappe.utils import flt, getdate, now_datetime

from karyo.payroll.governance import configured_role, has_actor_role
from karyo.payroll.readiness import get_cycle_employees, run_readiness
from karyo.payroll.statutory import calculate_contribution_results, calculate_salary_slip_paye_result


def _assert_processor():
	if not has_actor_role("processor"):
		frappe.throw(
			_("Only users with role {0} may process payroll.").format(configured_role("processor")),
			frappe.PermissionError,
		)


def _upsert_population(cycle, employees):
	open_exceptions = frappe.get_all(
		"Payroll Readiness Exception",
		filters={"payroll_cycle": cycle.name, "status": "Open"},
		fields=["employee", "severity", "validation_code", "message", "excluded_doctype"],
	)
	by_employee = {}
	for row in open_exceptions:
		by_employee.setdefault(row.employee, []).append(row)
	included = []
	excluded = []
	for employee in employees:
		issues = by_employee.get(employee, [])
		exclusion_issues = [
			row
			for row in issues
			if row.severity in {"Blocking", "Approval Required"} or row.excluded_doctype
		]
		status = "Excluded" if exclusion_issues else "Included"
		reason = "\n".join(f"{row.validation_code}: {row.message}" for row in exclusion_issues)
		business_key = f"{cycle.name}|{employee}"
		name = frappe.db.get_value("Payroll Cycle Employee", {"business_key": business_key}, "name")
		doc = frappe.get_doc("Payroll Cycle Employee", name) if name else frappe.new_doc("Payroll Cycle Employee")
		doc.update(
			{
				"payroll_cycle": cycle.name,
				"employee": employee,
				"business_key": business_key,
				"status": status,
				"exclusion_reason": reason,
				"last_processed_on": now_datetime(),
			}
		)
		doc.save(ignore_permissions=True)
		(included if status == "Included" else excluded).append(employee)
	return included, excluded


def _ensure_payroll_entry(cycle, employees):
	name = cycle.payroll_entry or frappe.db.get_value(
		"Payroll Entry", {"karyo_payroll_cycle": cycle.name, "docstatus": ("<", 2)}, "name"
	)
	if name and frappe.db.exists("Payroll Entry", name):
		return frappe.get_doc("Payroll Entry", name), True
	company = frappe.db.get_value(
		"Company",
		cycle.company,
		["default_currency", "default_payroll_payable_account"],
		as_dict=True,
	)
	if not company.default_payroll_payable_account:
		frappe.throw(_("Company must have a default Payroll Payable Account before processing."))
	doc = frappe.get_doc(
		{
			"doctype": "Payroll Entry",
			"posting_date": cycle.payment_date,
			"payroll_frequency": "Monthly",
			"company": cycle.company,
			"start_date": cycle.start_date,
			"end_date": cycle.end_date,
			"currency": company.default_currency,
			"exchange_rate": 1,
			"payroll_payable_account": company.default_payroll_payable_account,
			"karyo_payroll_cycle": cycle.name,
			"employees": [{"employee": employee} for employee in employees],
		}
	).insert(ignore_permissions=True)
	return doc, False


def prepare_entry_population(cycle, entry, employees):
	"""Attach employees to a draft entry or register a safe supplemental scope.

	A submitted Payroll Entry is an accounting document and its child table must
	not be edited in place.  Employees added later are therefore persisted in
	Payroll Cycle Employee and their Salary Slips are linked to the same entry by
	the employee-scoped generator.  This keeps the original entry, submitted
	slips and journal entries intact while making the correction auditable.
	"""
	if entry.company != cycle.company or entry.get("karyo_payroll_cycle") != cycle.name:
		frappe.throw(_("Payroll Entry does not belong to this payroll cycle."))
	if entry.docstatus == 2:
		frappe.throw(_("The Payroll Entry is cancelled. Prepare a replacement through the payroll workflow."))
	if entry.status == "Queued":
		frappe.throw(_("Payroll Entry processing is queued. Wait for it to finish before amending the employee population."))

	present = {row.employee for row in entry.employees}
	missing = [employee for employee in employees if employee not in present]
	if missing and entry.docstatus == 0:
		for employee in missing:
			entry.append("employees", {"employee": employee})
		entry.save()
		return {"added": missing, "supplemental": []}

	# Submitted entries stay immutable.  The caller records these employees in
	# Payroll Cycle Employee and generation creates only their missing slips.
	return {"added": [], "supplemental": missing if entry.docstatus == 1 else []}


def _log(cycle, step, status, message, reference_doctype=None, reference_name=None):
	idx = frappe.db.count(
		"Payroll Cycle Step Log", {"parent": cycle.name, "parenttype": "Payroll Cycle"}
	) + 1
	frappe.get_doc(
		{
			"doctype": "Payroll Cycle Step Log",
			"parent": cycle.name,
			"parenttype": "Payroll Cycle",
			"parentfield": "step_logs",
			"idx": idx,
			"step": step,
			"status": status,
			"started_on": now_datetime(),
			"completed_on": now_datetime(),
			"message": message,
			"reference_doctype": reference_doctype,
			"reference_name": reference_name,
		},
	).db_insert()


@frappe.whitelist()
def prepare_payroll(payroll_cycle):
	"""Build population and create/reuse the standard draft Payroll Entry."""
	_assert_processor()
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if cycle.status != "Processing":
		frappe.throw(_("Payroll Cycle must be in Processing."))
	from karyo.payroll.input_posting import materialize_cycle_inputs

	input_result = materialize_cycle_inputs(cycle)
	employees = get_cycle_employees(cycle)
	readiness = run_readiness(cycle.name, employees)
	included, excluded = _upsert_population(cycle, employees)
	if readiness["blocking"]:
		_log(cycle, "Prepare Payroll", "Failed", _("Readiness has {0} blocking items.").format(readiness["blocking"]))
		frappe.throw(_("Payroll readiness is blocked. Resolve or waive exceptions before processing."))
	if not included:
		frappe.throw(_("No eligible employees remain in the Payroll Cycle population."))
	from karyo.payroll.attendance_bonus import process_automatic_attendance_bonuses

	bonus_result = process_automatic_attendance_bonuses(cycle, included)
	from karyo.payroll.pre_payroll_earnings import assert_complete

	assert_complete(cycle, included)
	entry, reused = _ensure_payroll_entry(cycle, included)
	amendment = prepare_entry_population(cycle, entry, included)
	# Individual payslips generated before preparation join the governed batch.
	for slip in frappe.get_all("Salary Slip", filters={"karyo_payroll_cycle": cycle.name,
		"employee": ("in", included), "docstatus": 0, "payroll_entry": ("is", "not set"),
		"company": cycle.company, "start_date": cycle.start_date, "end_date": cycle.end_date}, pluck="name"):
		frappe.db.set_value("Salary Slip", slip, "payroll_entry", entry.name)

	frappe.db.set_value(
		"Payroll Cycle Employee",
		{"payroll_cycle": cycle.name, "status": "Included"},
		{"status": "Payroll Entry Ready", "payroll_entry": entry.name, "last_processed_on": now_datetime()},
		update_modified=False,
	)
	frappe.db.set_value(
		"Payroll Cycle",
		cycle.name,
		{"payroll_entry": entry.name, "employee_count": len(included)},
		update_modified=False,
	)
	_log(
		cycle,
		"Prepare Payroll",
		"Completed",
		_(
			"{0} employees included; {1} excluded; Payroll Entry {2}{3}; "
			"{4} supplemental employee(s). PRB Attendance Bonus processed automatically for "
			"{5} eligible employee(s), with {6} new run(s). Posted {7} static and "
			"{8} approved once-off payroll input(s)."
		).format(
			len(included), len(excluded), entry.name, _(" reused") if reused else _(" created"),
			len(amendment["supplemental"]), bonus_result["eligible"], bonus_result["created"],
			len(input_result["recurring"]["created"]),
			sum(len(row["posted"]) for row in input_result["once_off"]),
		),
		"Payroll Entry",
		entry.name,
	)
	return {
		"payroll_cycle": cycle.name,
		"payroll_entry": entry.name,
		"reused": reused,
		"included": len(included),
		"excluded": len(excluded),
		"supplemental": len(amendment["supplemental"]),
		"attendance_bonus": bonus_result,
		"payroll_inputs": input_result,
	}


def _sync_salary_slips(cycle, entry):
	slips = frappe.get_all(
		"Salary Slip",
		filters={"payroll_entry": entry.name, "docstatus": ("<", 2)},
		fields=["name", "employee"],
	)
	for slip in slips:
		frappe.db.set_value(
			"Salary Slip", slip.name, "karyo_payroll_cycle", cycle.name, update_modified=False
		)
		frappe.db.set_value(
			"Payroll Cycle Employee",
			{"payroll_cycle": cycle.name, "employee": slip.employee},
			{
				"status": "Salary Slip Created",
				"salary_slip": slip.name,
				"last_processed_on": now_datetime(),
				"exclusion_reason": None,
			},
			update_modified=False,
		)
	return slips


@frappe.whitelist()
def generate_salary_slips(payroll_cycle):
	"""Submit/reuse the Payroll Entry and capture its draft Salary Slips."""
	_assert_processor()
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if cycle.status != "Processing":
		frappe.throw(_("Payroll Cycle must be in Processing."))
	if not cycle.payroll_entry or not frappe.db.exists("Payroll Entry", cycle.payroll_entry):
		frappe.throw(_("Prepare Payroll before generating Salary Slips."))
	from karyo.payroll.input_posting import materialize_cycle_inputs

	input_result = materialize_cycle_inputs(cycle)
	entry = frappe.get_doc("Payroll Entry", cycle.payroll_entry)
	if entry.docstatus == 2:
		frappe.throw(_("The linked Payroll Entry is cancelled. Prepare a replacement before continuing."))
	from karyo.payroll.employee_processing import generate, prepared_population

	expected_employees = prepared_population(cycle, entry)
	existing = _sync_salary_slips(cycle, entry)
	existing_employees = {slip.employee for slip in existing}
	if expected_employees and expected_employees.issubset(existing_employees):
		_log(
			cycle,
			"Generate Salary Slips",
			"Skipped",
			_("Reused {0} existing draft Salary Slips.").format(len(existing)),
			"Payroll Entry",
			entry.name,
		)
		return {
			"payroll_entry": entry.name,
			"created": 0,
			"reused": len(existing),
			"queued": False,
			"payroll_inputs": input_result,
		}
	if entry.docstatus == 0:
		entry.flags.ignore_permissions = True
		entry.submit()
	else:
		entry.create_salary_slips()
	entry.reload()
	if entry.status == "Failed":
		frappe.db.set_value(
			"Payroll Cycle Employee",
			{"payroll_cycle": cycle.name, "status": "Payroll Entry Ready"},
			{
				"status": "Failed",
				"exclusion_reason": entry.error_message,
				"last_processed_on": now_datetime(),
			},
			update_modified=False,
		)
		_log(cycle, "Generate Salary Slips", "Failed", entry.error_message or _("Salary Slip generation failed."))
		frappe.throw(entry.error_message or _("Salary Slip generation failed."))
	if entry.status == "Queued":
		_log(
			cycle,
			"Generate Salary Slips",
			"Running",
			_("Salary Slip generation was queued by the standard Payroll Entry."),
			"Payroll Entry",
			entry.name,
		)
		return {
			"payroll_entry": entry.name,
			"created": 0,
			"reused": 0,
			"queued": True,
			"payroll_inputs": input_result,
		}
	entry.reload()
	supplemental = sorted(expected_employees - {row.employee for row in entry.employees})
	if supplemental:
		generate(cycle, supplemental)
	slips = _sync_salary_slips(cycle, entry)
	if {slip.employee for slip in slips} != expected_employees:
		frappe.throw(
			_("Generated {0} of {1} expected Salary Slips; review Payroll Entry errors.").format(
				len(slips), len(expected_employees)
			)
		)
	_log(
		cycle,
		"Generate Salary Slips",
		"Completed",
		_("Generated and linked {0} draft Salary Slips.").format(len(slips)),
		"Payroll Entry",
		entry.name,
	)
	return {
		"payroll_entry": entry.name,
		"created": len(slips) - len(existing),
		"reused": len(existing),
		"queued": False,
		"payroll_inputs": input_result,
	}


def _taxable_earnings(slip):
	return sum(
		flt(row.amount)
		for row in slip.earnings
		if row.is_tax_applicable and not row.statistical_component
	)


def _historical_paye_inputs(employee, cycle, paye_year, paye_component):
	prior_slips = frappe.get_all(
		"Salary Slip",
		filters={
			"employee": employee,
			"company": cycle.company,
			"docstatus": 1,
			"start_date": (">=", paye_year.effective_from),
			"end_date": ("<", cycle.start_date),
		},
		pluck="name",
		order_by="end_date asc",
	)
	if not prior_slips:
		return 0, 0, 1
	rows = frappe.get_all(
		"Salary Detail",
		filters={
			"parent": ("in", prior_slips),
			"parenttype": "Salary Slip",
			"parentfield": "earnings",
			"is_tax_applicable": 1,
			"statistical_component": 0,
		},
		fields=["sum(amount) as amount"],
	)
	taxable = flt(rows[0].amount if rows else 0)
	previous_paye = 0
	if paye_component:
		previous_paye = flt(
			frappe.db.get_value(
				"Salary Detail",
				{
					"parent": ("in", prior_slips),
					"parenttype": "Salary Slip",
					"parentfield": "deductions",
					"salary_component": paye_component,
				},
				"sum(amount)",
			)
		)
	return taxable, previous_paye, len(prior_slips) + 1


def _operation_basis(slip, operation_code):
	items = frappe.get_all(
		"Payroll Operation Code Item",
		filters={"parent": operation_code, "parenttype": "Payroll Operation Code"},
		fields=[
			"pdb_code", "aggregation_sign", "inclusion_percentage",
			"effective_from", "effective_to",
		],
		order_by="sequence, idx",
	)
	if not items:
		frappe.throw(_("Operation Code {0} has no PDB basis mappings.").format(operation_code))
	amounts = {}
	for row in [*slip.earnings, *slip.deductions]:
		amounts[row.salary_component] = amounts.get(row.salary_component, 0) + flt(row.amount)
	total = 0
	on_date = getdate(slip.end_date or slip.posting_date)
	for item in items:
		if item.effective_from and getdate(item.effective_from) > on_date:
			continue
		if item.effective_to and getdate(item.effective_to) < on_date:
			continue
		component = frappe.db.get_value("Payroll PDB Code", item.pdb_code, "salary_component")
		if not component:
			frappe.throw(_("PDB Code {0} has no Salary Component mapping.").format(item.pdb_code))
		value = amounts.get(component, 0) * flt(item.inclusion_percentage or 100) / 100
		total += -value if item.aggregation_sign == "Subtract" else value
	return total


def _effective_contribution_schemes(cycle):
	rows = frappe.get_all(
		"Payroll Contribution Scheme",
		filters={"is_active": 1, "effective_from": ("<=", cycle.payment_date)},
		fields=["name", "company", "effective_to"],
	)
	date = getdate(cycle.payment_date)
	return [
		row.name
		for row in rows
		if (not row.company or row.company == cycle.company)
		and (not row.effective_to or getdate(row.effective_to) >= date)
	]


def _employee_contribution_schemes(cycle, slip, available=None):
	"""Resolve schemes assigned to one employee instead of applying every scheme."""
	available = available if available is not None else _effective_contribution_schemes(cycle)
	if not available:
		return []
	explicit = frappe.db.get_value("Employee", slip.get("employee"), "karyo_contribution_group")
	if explicit:
		return [explicit] if explicit in available else []
	deduction_components = set(frappe.get_all(
		"Salary Detail",
		filters={
			"parenttype": "Salary Structure",
			"parent": slip.get("salary_structure"),
			"parentfield": "deductions",
		},
		pluck="salary_component",
	))
	if not deduction_components:
		return []
	schemes = frappe.get_all(
		"Payroll Contribution Scheme",
		filters={"name": ("in", available)},
		fields=["name", "employee_pdb_code"],
	)
	return [
		row.name for row in schemes
		if frappe.db.get_value("Payroll PDB Code", row.employee_pdb_code, "salary_component")
		in deduction_components
	]


@frappe.whitelist()
def calculate_cycle_statutory(payroll_cycle, employees=None):
	"""Calculate PAYE and contributions from linked draft Salary Slips."""
	_assert_processor()
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	# Native Payroll Entry generation may finish in the background after the
	# request has returned. Reconcile those completed slips into the employee
	# run rows before enforcing the statutory-stage prerequisite.
	if cycle.payroll_entry and frappe.db.exists("Payroll Entry", cycle.payroll_entry):
		_sync_salary_slips(cycle, frappe.get_doc("Payroll Entry", cycle.payroll_entry))
	if employees is not None:
		from karyo.payroll.employee_completion import validate_stage
		employees = validate_stage(cycle, employees, "Calculate PAYE and Contributions")
	elif cycle.status != "Processing":
		frappe.throw(_("Payroll Cycle must be in Processing."))
	population = frappe.get_all(
		"Payroll Cycle Employee",
		filters={"payroll_cycle": cycle.name, "status": ("in", ["Salary Slip Created", "Failed"]), **({"employee": ("in", employees)} if employees is not None else {})},
		fields=["name", "employee", "salary_slip"],
	)
	if not population or any(not row.salary_slip for row in population):
		frappe.throw(_("Generate and link all draft Salary Slips before statutory calculation."))
	paye_component = frappe.db.get_value(
		"Payroll PDB Code", {"pdb_code": "PAYE", "is_active": 1}, "salary_component"
	)
	available_schemes = _effective_contribution_schemes(cycle)
	used_schemes = set()
	processed = 0
	failures = []
	for row in population:
		try:
			slip = frappe.get_doc("Salary Slip", row.salary_slip)
			if slip.docstatus != 0:
				frappe.throw(_("Salary Slip must remain Draft during statutory calculation."))
			calculate_salary_slip_paye_result(cycle.name, slip, paye_component)
			for scheme in _employee_contribution_schemes(cycle, slip, available_schemes):
				operation_code = frappe.db.get_value(
					"Payroll Contribution Scheme", scheme, "basis_operation_code"
				)
				basis = _operation_basis(slip, operation_code)
				if not flt(basis) and flt(slip.gross_pay):
					frappe.throw(_(
						"Contribution Scheme {0} calculated a zero {1} basis while Salary Slip {2} "
						"has Gross Pay {3}. Correct the effective Salary Structure Assignment or "
						"the Operation Code mapping before applying deductions."
					).format(scheme, operation_code, slip.name, slip.gross_pay))
				calculate_contribution_results(cycle.name, row.employee, basis, [scheme])
				used_schemes.add(scheme)
			from karyo.payroll.computation import persist_salary_slip_computation

			employer_contributions = flt(frappe.db.get_value(
				"Payroll Statutory Result",
				{
					"payroll_cycle": cycle.name,
					"employee": row.employee,
					"result_type": "Employer Contribution",
					"status": ("!=", "Reversed"),
				},
				"sum(current_amount)",
			))
			persist_salary_slip_computation(slip, employer_contributions)
			frappe.db.set_value(
				"Payroll Cycle Employee",
				row.name,
				{"status": "Processed", "exclusion_reason": None, "last_processed_on": now_datetime()},
				update_modified=False,
			)
			processed += 1
		except Exception as error:
			message = str(error)
			failures.append({"employee": row.employee, "message": message})
			frappe.db.set_value(
				"Payroll Cycle Employee",
				row.name,
				{"status": "Failed", "exclusion_reason": message, "last_processed_on": now_datetime()},
				update_modified=False,
			)
	_log(
		cycle,
		"Calculate Statutory",
		"Failed" if failures else "Completed",
		_("Calculated {0} employees; {1} failed; {2} contribution schemes.").format(
			processed, len(failures), len(used_schemes)
		),
	)
	return {"processed": processed, "failed": failures, "contribution_schemes": len(used_schemes)}
