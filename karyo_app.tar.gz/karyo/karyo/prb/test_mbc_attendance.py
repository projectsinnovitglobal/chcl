import unittest

from karyo.prb.allowances import attendance_bonus, era_hours_payment, incentive_presence_bonus
from karyo.prb.overtime import (
	mbc_night_duty_amount,
	overtime_amount_from_salary,
	overtime_eligibility,
	public_holiday_overtime_units,
)


class TestMBCAttendanceFormulas(unittest.TestCase):
	def test_attendance_bonus_scale(self):
		self.assertEqual([attendance_bonus(x) for x in (0, 0.5, 1, 1.5, 2)], [2140, 1605, 1070, 535, 0])

	def test_incentive_presence_scale(self):
		self.assertEqual(
			[incentive_presence_bonus(x) for x in (0, 0.5, 1, 1.5, 2)],
			[1500, 1125, 750, 375, 0],
		)

	def test_public_holiday_units_boundaries(self):
		self.assertEqual(
			[public_holiday_overtime_units(x) for x in (0, 1.99, 2, 3.99, 4, 7.99, 8)],
			[0, 0, 0.5, 0.5, 1, 1, 2],
		)

	def test_prb_2026_overtime_salary_boundaries(self):
		self.assertEqual(overtime_eligibility(60599), (True, 1.0))
		self.assertEqual(overtime_eligibility(60600), (True, 0.8))
		self.assertEqual(overtime_eligibility(77750), (True, 0.8))
		self.assertEqual(overtime_eligibility(77751), (False, 0.0))

	def test_overtime_sheet_formula_applies_the_eighty_percent_band(self):
		self.assertEqual(overtime_amount_from_salary(65000, 4), 2133.33)

	def test_mbc_night_duty_formula(self):
		self.assertEqual(mbc_night_duty_amount(52000, 8), 1200)
		self.assertEqual(
			mbc_night_duty_amount(52000, 8, hours_denominator=2080, rate_multiplier=2, night_duty_pct=25),
			1200,
		)

	def test_era_sheet_validation_scenario(self):
		base = era_hours_payment(32, 40000, 40000, casual_leave_taken=1, other_absence_days=0)
		self.assertEqual(base, 4435)
		self.assertEqual(
			era_hours_payment(32, 40000, 40000, casual_leave_taken=1, other_absence_days=1),
			4233.41,
		)

	def test_era_proration_and_salary_gap(self):
		self.assertEqual(era_hours_payment(14.99, 26000, 26000), 0)
		self.assertEqual(era_hours_payment(15, 26000, 26000), 1950)
		self.assertEqual(era_hours_payment(30, 26000, 32000), 0)


if __name__ == "__main__":
	unittest.main()
