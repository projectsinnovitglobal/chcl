"""Approve, post, reverse, and amend controlled once-off PDB batches."""

import frappe
from frappe import _

from karyo.payroll.sequencing import reserve_transaction


@frappe.whitelist()
def approve_batch(name):
	batch = frappe.get_doc("Once-Off PDB Batch", name)
	if batch.status != "Draft":
		frappe.throw(_("Only Draft once-off batches can be approved."))
	cycle_status = frappe.db.get_value("Payroll Cycle", batch.payroll_cycle, "status")
	if cycle_status not in ("Draft", "Input Open", "Processing"):
		frappe.throw(_("Payroll Cycle is not accepting once-off inputs."))
	batch.status = "Approved"
	batch.save()
	return batch.name


@frappe.whitelist()
def post_batch(name):
	batch = frappe.get_doc("Once-Off PDB Batch", name)
	cycle = frappe.get_doc("Payroll Cycle", batch.payroll_cycle)
	if batch.status == "Posted":
		return {"batch": batch.name, "posted": [], "already_posted": True}
	if batch.status != "Approved":
		frappe.throw(_("Only Approved once-off batches can be posted."))
	if cycle.status not in ("Processing", "Review"):
		frappe.throw(_("Payroll Cycle must be Processing or Review before posting."))
	posted = []
	for row in batch.lines:
		if row.additional_salary and frappe.db.get_value(
			"Additional Salary", row.additional_salary, "docstatus"
		) == 1:
			posted.append(row.additional_salary)
			continue
		allocation = reserve_transaction(
			cycle.name, "Once-Off PDB Line", row.name, "Once-off", row.amount, row.employee
		)
		additional_salary = frappe.get_doc(
			{
				"doctype": "Additional Salary",
				"employee": row.employee,
				"company": batch.company,
				"salary_component": row.salary_component,
				"amount": row.amount,
				"payroll_date": cycle.payment_date,
				"overwrite_salary_structure_amount": 0,
				"ref_doctype": batch.doctype,
				"ref_docname": batch.name,
				"karyo_transaction_category": "Once-off PDB",
				"karyo_pdb_code": row.pdb_code,
				"karyo_payroll_cycle": cycle.name,
			}
		)
		additional_salary.insert(ignore_permissions=True)
		additional_salary.submit()
		row.allocation = allocation.name
		row.additional_salary = additional_salary.name
		posted.append(additional_salary.name)
	batch.status = "Posted"
	batch.save()
	return {"batch": batch.name, "posted": posted, "already_posted": False}


@frappe.whitelist()
def reverse_and_amend(name, reason):
	batch = frappe.get_doc("Once-Off PDB Batch", name)
	if batch.status != "Posted":
		frappe.throw(_("Only Posted once-off batches can be reversed."))
	if not reason:
		frappe.throw(_("A correction reason is required."))
	for row in batch.lines:
		if (
			row.additional_salary
			and frappe.db.get_value("Additional Salary", row.additional_salary, "docstatus") == 1
		):
			additional_salary = frappe.get_doc("Additional Salary", row.additional_salary)
			additional_salary.flags.ignore_links = True
			additional_salary.cancel()
		if row.allocation:
			frappe.db.set_value(
				"Payroll Transaction Allocation", row.allocation, "status", "Released", update_modified=False
			)
	batch.status = "Cancelled"
	batch.decision_reason = reason
	batch.flags.reversal_complete = True
	batch.save()
	new_batch = frappe.copy_doc(batch)
	new_batch.name = None
	new_batch.status = "Draft"
	new_batch.amends = batch.name
	new_batch.batch_description = _("Correction of {0}").format(batch.name)
	new_batch.decision_reason = None
	new_batch.approved_by = None
	new_batch.approved_on = None
	new_batch.posted_by = None
	new_batch.posted_on = None
	for row in new_batch.lines:
		row.name = None
		row.additional_salary = None
		row.allocation = None
	return new_batch.insert().name
