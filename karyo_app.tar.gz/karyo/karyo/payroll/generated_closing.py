"""Generated employee payroll, with closure scoped to the linked cycle/month."""
import re
import frappe
from frappe import _
from frappe.utils import cint, getdate, get_first_day, get_last_day


@frappe.whitelist()
def list_generated(month=None, employee=None, start=0, pending_only=0, page_length=25):
    from karyo.desk.payroll_management import _admin
    from karyo.payroll.employee_closing import state
    _admin()
    if not frappe.has_permission('Salary Slip','read'):
        frappe.throw(_('You do not have access to generated payroll.'),frappe.PermissionError)
    dates=frappe.get_list('Salary Slip',filters={'docstatus':('<',2)},fields=['end_date'],group_by='end_date',order_by='end_date desc',limit_page_length=0)
    months=sorted({str(row.end_date)[:7] for row in dates if row.end_date},reverse=True)
    month=month or (months[0] if months else None)
    if month and not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',month):frappe.throw(_('Select a valid payroll month.'))
    if not month:return {'month':None,'months':[],'employees':[],'rows':[],'has_more':False,'total':0}
    first=get_first_day(getdate(month+'-01'));last=get_last_day(first)
    slips=frappe.get_list('Salary Slip',filters={'docstatus':('<',2),'end_date':('between',[first,last])},
        fields=['name','employee','employee_name','end_date','net_pay','currency','docstatus','karyo_payroll_cycle','payroll_entry'],order_by='employee_name asc, name asc',limit_page_length=0)
    options={s.employee:s.employee_name for s in slips}
    rows=[];seen=set();scopes={}
    for slip in slips:
        if employee and slip.employee!=employee:continue
        cycle_name=slip.karyo_payroll_cycle or (frappe.db.get_value('Payroll Entry',slip.payroll_entry,'karyo_payroll_cycle') if slip.payroll_entry else None)
        key=(cycle_name,slip.employee) if cycle_name else (None,slip.name)
        if key in seen:continue
        seen.add(key)
        cycle=frappe.get_doc('Payroll Cycle',cycle_name) if cycle_name else None
        if cycle and not cycle.has_permission('read'):continue
        if cycle and cycle.company != frappe.db.get_value('Employee',slip.employee,'company'):continue
        if cycle_name not in scopes and cycle:scopes[cycle_name]=state(cycle)
        closed_row=next((r for r in scopes.get(cycle_name,{}).get('rows',[]) if r['employee']==slip.employee),{})
        rows.append({**closed_row,'employee':slip.employee,'employee_name':slip.employee_name,'slip':slip.name,
            'month':str(slip.end_date)[:7],'net_pay':slip.net_pay,'currency':slip.currency,
            'payroll_cycle':cycle_name,'pay_day':cycle.pay_day if cycle else None,'payroll_type':cycle.payroll_type if cycle else None,
            'payslip_status':_('Submitted') if slip.docstatus==1 else _('Generated (Draft)'),
            'status':closed_row.get('status') or _('Needs payroll cycle'),
            'reason':closed_row.get('reason') or (None if cycle else _('Link this payslip to its payroll cycle before closing.')),
            'can_close':bool(closed_row.get('can_close'))})
    if cint(pending_only):rows=[row for row in rows if row['status'] != _('Closed')]
    start=max(0,cint(start));page_length=max(1,min(cint(page_length) or 25,25))
    return {'month':month,'months':months,'employees':[{'value':name,'label':label} for name,label in sorted(options.items(),key=lambda item:item[1] or item[0])],
        'rows':rows[start:start+page_length],'total':len(rows),'has_more':len(rows)>start+page_length}
