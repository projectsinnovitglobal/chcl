"""Coverage for the Employee and Company fields specified by the payroll manual."""

import frappe
from frappe.tests.utils import FrappeTestCase
from frappe.utils import random_string

from karyo.desk.payroll_drawer import record_form, record_save
from karyo.desk.org_units import save as save_org_unit
from karyo.setup.employee_master import (
	EMPLOYEE_CATEGORY_TYPES,
	LOCATION_CODES,
	MARITAL_STATUSES,
	apply,
	prepare_company_master,
	prepare_employee_master,
)


class TestEmployeeCompanyManualFields(FrappeTestCase):
	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		apply()

	def test_employee_manual_fields_are_backed_by_real_fields_and_masters(self):
		meta = frappe.get_meta("Employee")
		expected = {
			"employee": ("Employee Code", "Data", None),
			"karyo_national_id": ("NIC / Passport", "Data", None),
			"salutation": ("Title", "Link", "Salutation"),
			"gender": ("Gender", "Link", "Gender"),
			"last_name": ("Surname", "Data", None),
			"first_name": ("First Name", "Data", None),
			"date_of_birth": ("Date of Birth", "Date", None),
			"karyo_address_line_1": ("Address 1", "Data", None),
			"karyo_address_line_2": ("Address 2", "Data", None),
			"cell_number": ("Phone", "Data", None),
			"personal_email": ("Personal Email", "Data", None),
			"date_of_joining": ("Date Joined Organisation", "Date", None),
			"karyo_date_joined_service": ("Date Joined Service", "Date", None),
			"final_confirmation_date": ("Confirmation Date", "Date", None),
			"karyo_employment_start_date": ("Employment Start Date", "Date", None),
			"contract_end_date": ("Employment End Date", "Date", None),
			"date_of_retirement": ("Retirement Date", "Date", None),
			"status": ("Employee Status", "Select", None),
			"employment_type": ("Employment Type", "Link", "Employment Type"),
			"karyo_employment_category": ("Category Code", "Link", "Employee Category"),
			"karyo_employment_category_description": ("Category Description", "Data", None),
			"karyo_payroll_eligible": ("Payroll Eligible?", "Check", None),
			"karyo_pb_eligibility_rule": ("PB Eligibility Rule", "Select", None),
			"karyo_permanent_pensionable": ("Pensionable?", "Check", None),
			"pb_eligible": ("PB Eligible?", "Check", None),
			"karyo_on_payroll": ("On Payroll?", "Check", None),
			"salary_mode": ("Payment Mode", "Select", None),
			"department": ("Department Code", "Link", "Department"),
			"karyo_section": ("Section Code", "Link", "Employee Section"),
			"karyo_location": ("Location / Site Code", "Link", "Employee Location"),
			"payroll_cost_center": ("Cost Centre", "Link", "Cost Center"),
			"karyo_job_family": ("Job Family Code", "Link", "Salary Job Family"),
			"designation": ("Post / Job Code", "Link", "Designation"),
			"grade": ("Grade Code", "Link", "Employee Grade"),
			"karyo_salary_scale": ("Salary Scale Code", "Link", "Salary Scale"),
			"karyo_scale_salary_point": ("Salary Step / Point", "Int", None),
			"karyo_scale_basic_salary": ("Basic Salary", "Currency", None),
			"karyo_payroll_group": ("Payroll Group", "Link", "Employee Payroll Group"),
			"karyo_work_pattern": ("Work Pattern", "Link", "Employee Work Pattern"),
			"holiday_list": ("Calendar Code", "Link", "Holiday List"),
			"default_shift": ("Shift Type", "Link", "Shift Type"),
			"karyo_contribution_group": ("Contribution Group", "Link", "Payroll Contribution Scheme"),
			"karyo_leave_scheme": ("Primary Leave Scheme", "Link", "Leave Policy"),
			"karyo_leave_block_list": ("Leave Block", "Link", "Leave Block List"),
			"karyo_loan_eligibility_group": ("Loan Eligibility Group", "Link", "Employee Loan Eligibility Group"),
			"marital_status": ("Marital Status", "Link", "Marital Status"),
		}
		for fieldname, (label, fieldtype, options) in expected.items():
			field = meta.get_field(fieldname)
			self.assertIsNotNone(field, fieldname)
			self.assertEqual(field.label, label, fieldname)
			self.assertEqual(field.fieldtype, fieldtype, fieldname)
			if options:
				self.assertEqual(field.options, options, fieldname)

		self.assertTrue(meta.get_field("employee").read_only)
		self.assertEqual(str(meta.get_field("karyo_on_payroll").default), "0")
		self.assertTrue(meta.get_field("karyo_payroll_eligible").read_only)
		self.assertTrue(meta.get_field("karyo_pb_eligibility_rule").read_only)
		self.assertIn(meta.get_field("karyo_work_pattern").insert_after, {"holiday_list", "karyo_employee_group"})
		self.assertEqual(meta.get_field("default_shift").insert_after, "karyo_work_pattern")
		self.assertTrue(meta.get_field("default_shift").hidden)
		self.assertTrue(meta.get_field("karyo_shift_code").hidden)
		self.assertEqual(meta.get_field("karyo_leave_scheme").insert_after, "karyo_shift_code")
		expected_leave_block_predecessor = "karyo_leave_schemes" if meta.has_field("karyo_leave_schemes") else "karyo_leave_scheme"
		self.assertEqual(meta.get_field("karyo_leave_block_list").insert_after, expected_leave_block_predecessor)
		self.assertTrue(meta.get_field("attendance_device_id").hidden)
		self.assertEqual(meta.get_field("karyo_loan_eligibility_section").insert_after, "karyo_prb_pb_status")
		self.assertEqual(meta.get_field("karyo_loan_eligibility_group").insert_after, "karyo_loan_eligibility_section")
		self.assertEqual(meta.get_field("karyo_loan_payroll_period").insert_after, "karyo_loan_eligibility_group")
		self.assertEqual(meta.get_field("karyo_payment_details_sb").insert_after, "karyo_loan_payroll_period")
		self.assertEqual(meta.get_field("karyo_hr_sb").insert_after, "salary_information")
		self.assertEqual(meta.get_field("karyo_date_joined_service").insert_after, "final_confirmation_date")
		self.assertEqual(meta.get_field("karyo_employment_start_date").insert_after, "karyo_date_joined_service")
		self.assertEqual(meta.get_field("ctc").label, "Cost to Company (CTC)")
		self.assertTrue(meta.get_field("ctc").read_only)
		self.assertTrue(meta.get_field("karyo_scale_basic_salary").hidden)
		for fieldname in ("passport_details_section", "passport_number", "date_of_issue", "valid_upto", "place_of_issue", "held_on", "new_workplace", "documents", "adhaar"):
			self.assertTrue(meta.get_field(fieldname).hidden, fieldname)
		for fieldname in ("passport", "driving_licence", "offer_letter", "joining_letter", "karyo_other_letters"):
			self.assertFalse(meta.get_field(fieldname).hidden, fieldname)
		self.assertTrue(meta.get_field("karyo_cheque_number").hidden)
		self.assertTrue(meta.get_field("karyo_cash_receipt_number").hidden)
		self.assertEqual(meta.get_field("karyo_payroll_bank_branch").depends_on, "eval:doc.salary_mode == 'Bank'")
		self.assertEqual(meta.get_field("salary_mode").options, "\nBank\nCheque\nCash")
		self.assertFalse(meta.get_field("karyo_cheque_number").mandatory_depends_on)
		self.assertFalse(meta.get_field("karyo_cash_receipt_number").mandatory_depends_on)
		self.assertEqual(
			meta.get_field("karyo_payroll_bank_branch").mandatory_depends_on,
			"eval:doc.karyo_on_payroll && doc.salary_mode == 'Bank'",
		)
		self.assertTrue(frappe.get_meta("Department").get_field("is_group").hidden)
		for fieldname in (
			"karyo_national_id", "last_name", "department", "karyo_location", "designation",
			"grade", "karyo_salary_scale", "karyo_scale_salary_point", "karyo_scale_basic_salary",
			"karyo_payroll_group", "karyo_employment_start_date", "salary_mode",
		):
			self.assertEqual(meta.get_field(fieldname).mandatory_depends_on, "eval:doc.karyo_on_payroll")
		for doctype in (
			"Employee Section", "Employee Category", "Marital Status", "Employee Payroll Group",
			"Employee Work Pattern", "Employee Loan Eligibility Group",
		):
			self.assertTrue(frappe.db.exists("DocType", doctype), doctype)
		self.assertGreater(frappe.db.count("Employee Loan Eligibility Group", {"disabled": 0}), 0)
		self.assertEqual(
			{
				(row.category_code, row.category_name, row.employment_type)
				for row in frappe.get_all(
					"Employee Category",
					fields=["category_code", "category_name", "employment_type"],
					limit_page_length=0,
				)
			},
			set(EMPLOYEE_CATEGORY_TYPES),
		)
		category_meta = frappe.get_meta("Employee Category")
		for fieldname, fieldtype, options in (
			("map_dependencies", "Check", None),
			("pensionable", "Check", None),
			("payroll_eligible", "Check", None),
			("pb_eligibility_rule", "Select", None),
			("leave_scheme", "Link", "Leave Policy"),
			("loan_eligibility_group", "Link", "Employee Loan Eligibility Group"),
			("contribution_group", "Link", "Payroll Contribution Scheme"),
			("remarks", "Small Text", None),
		):
			field = category_meta.get_field(fieldname)
			self.assertIsNotNone(field, fieldname)
			self.assertEqual(field.fieldtype, fieldtype, fieldname)
			if options:
				self.assertEqual(field.options, options, fieldname)
		self.assertTrue(frappe.db.exists("Employee Category", "RELF"))
		self.assertEqual(
			set(frappe.get_all("Employment Type", pluck="name", limit_page_length=0)),
			{employment_type for _, _, employment_type in EMPLOYEE_CATEGORY_TYPES},
		)
		self.assertEqual(
			{
				(row.marital_status_code, row.marital_status_description, row.is_active)
				for row in frappe.get_all(
					"Marital Status",
					fields=["marital_status_code", "marital_status_description", "is_active"],
					limit_page_length=0,
				)
			},
			{(code, description, 1) for code, description in MARITAL_STATUSES},
		)

	def test_location_master_uses_sheet_codes_and_names(self):
		from frappe.desk.search import search_widget

		self.assertTrue(frappe.get_meta("Employee Location").show_title_field_in_link)
		self.assertEqual(
			{
				(row.location_code, row.location_name)
				for row in frappe.get_all(
					"Employee Location",
					filters={"location_code": ("in", [code for code, _name in LOCATION_CODES])},
					fields=["location_code", "location_name"],
					limit_page_length=0,
				)
			},
			set(LOCATION_CODES),
		)
		self.assertIn(
			("ADM", "Administration"),
			[row[:2] for row in search_widget("Employee Location", "Administration")],
		)

	def test_education_level_and_previous_work_history_are_governed(self):
		level = frappe.get_meta("Employee Education").get_field("level")
		self.assertEqual(level.fieldtype, "Link")
		self.assertEqual(level.options, "Education Level")
		self.assertFalse(frappe.get_meta("Education Level").get_field("disabled").in_list_view)
		self.assertEqual(frappe.get_all("Education Level", pluck="name", order_by="name"), ["Graduate", "Post Graduate"])

		history = frappe.get_meta("Employee External Work History")
		self.assertTrue(history.get_field("salary").hidden)
		self.assertEqual(history.get_field("address").label, "Company Address")
		self.assertEqual(history.get_field("address").insert_after, "company_name")
		self.assertEqual(history.get_field("karyo_from_date").fieldtype, "Date")
		self.assertEqual(history.get_field("karyo_to_date").fieldtype, "Date")
		self.assertTrue(history.get_field("total_experience").read_only)

		doc = frappe._dict({
			"doctype": "Employee", "karyo_on_payroll": 0,
			"external_work_history": [frappe._dict({
				"idx": 1, "karyo_from_date": "2020-01-15", "karyo_to_date": "2023-04-14",
			})],
		})
		prepare_employee_master(doc)
		self.assertEqual(doc.external_work_history[0].total_experience, "3 year(s) 2 month(s)")

	def test_employee_bank_details_tab_maps_the_payment_masters(self):
		meta = frappe.get_meta("Employee")
		order = {field.fieldname: index for index, field in enumerate(meta.fields)}
		bank_tab = order["karyo_employee_bank_details_tab"]
		self.assertEqual(meta.get_field("karyo_employee_bank_details_tab").label, "Employee Bank Details")
		for fieldname in (
			"salary_mode", "karyo_payroll_bank", "karyo_payroll_bank_branch", "bank_ac_no", "iban",
			"karyo_bank_employee_code", "karyo_bank_account_holder_name",
			"karyo_bank_account_is_primary", "karyo_bank_account_effective_from",
			"karyo_bank_account_effective_to",
			"karyo_bank_code", "karyo_bank_swift_code", "karyo_bank_transfer_code",
			"karyo_bank_other_code", "karyo_branch_code", "karyo_branch_name",
			"karyo_branch_transfer_code", "karyo_branch_other_code", "karyo_branch_active",
		):
			self.assertGreater(order[fieldname], bank_tab, fieldname)

		self.assertEqual(meta.get_field("karyo_payroll_bank").options, "Bank")
		self.assertEqual(meta.get_field("karyo_payroll_bank").label, "Bank")
		self.assertEqual(meta.get_field("karyo_payroll_bank_branch").options, "Payroll Bank Branch")
		self.assertEqual(meta.get_field("karyo_payroll_bank_branch").label, "Branch")
		self.assertEqual(meta.get_field("bank_ac_no").label, "Account Number")
		self.assertTrue(meta.get_field("karyo_bank_employee_code").read_only)
		self.assertTrue(meta.get_field("iban").hidden)
		self.assertEqual(meta.get_field("karyo_cheque_number").insert_after, "karyo_cheque_details_sb")
		self.assertEqual(meta.get_field("karyo_cash_receipt_number").insert_after, "karyo_cash_details_sb")
		self.assertEqual(meta.get_field("karyo_branch_code").fetch_from, "karyo_payroll_bank_branch.branch_code")
		self.assertTrue(meta.get_field("karyo_branch_code").read_only)
		self.assertEqual(meta.get_field("karyo_bank_swift_code").fetch_from, "karyo_payroll_bank.swift_number")
		self.assertTrue(meta.get_field("karyo_bank_swift_code").read_only)

	def test_shift_type_is_the_shift_code_master(self):
		field = frappe.get_meta("Shift Type").get_field("karyo_shift_code")
		self.assertIsNotNone(field)
		self.assertEqual(field.label, "Shift Code")
		self.assertTrue(field.reqd)
		self.assertTrue(field.unique)
		shifts = frappe.get_all("Shift Type", fields=["name", "karyo_shift_code"])
		self.assertTrue(shifts)
		self.assertTrue(all(row.karyo_shift_code for row in shifts))
		self.assertEqual(len({row.karyo_shift_code for row in shifts}), len(shifts))

	def test_section_master_creation_uses_department_and_company(self):
		departments = frappe.get_all(
			"Department", filters={"company": ("is", "set")},
			fields=["name", "company"], limit_page_length=0,
		)
		department = next((row for row in departments if row.company != "MBC"), departments[0])
		code = "TEST-" + random_string(8).upper()
		try:
			result = save_org_unit("Employee Section", {
				"section_code": code,
				"section_name": "Test Section",
				"department": department.name,
				"company": department.company,
			})
			section = frappe.get_doc("Employee Section", result["name"])
			self.assertEqual(section.department, department.name)
			self.assertEqual(section.company, department.company)
		finally:
			if frappe.db.exists("Employee Section", code):
				frappe.delete_doc("Employee Section", code, force=True)

	def test_education_level_can_be_renamed_without_deleting_linked_records(self):
		frappe.db.savepoint("education_level_rename")
		try:
			result = save_org_unit(
				"Education Level", {"level_name": "Graduation", "description": "Graduation"},
				name="Graduate",
			)
			self.assertEqual(result["name"], "Graduation")
			self.assertTrue(frappe.db.exists("Education Level", "Graduation"))
			self.assertFalse(frappe.db.exists("Education Level", "Graduate"))
		finally:
			frappe.db.rollback(save_point="education_level_rename")

	def test_education_level_edit_disable_and_enable_lifecycle(self):
		from frappe.desk.search import search_widget

		code = "Education " + random_string(8)
		corrected_code = code + " Corrected"
		try:
			created = save_org_unit("Education Level", {
				"level_name": code,
				"description": "Initial description",
			})
			updated = save_org_unit("Education Level", {
				"level_name": corrected_code,
				"description": "Corrected description",
			}, name=created["name"])
			self.assertEqual(updated["name"], corrected_code)
			doc = frappe.get_doc("Education Level", corrected_code)
			self.assertEqual(doc.level_name, corrected_code)
			self.assertEqual(doc.description, "Corrected description")

			frappe.db.set_value("Education Level", corrected_code, "disabled", 1)
			self.assertTrue(frappe.db.exists("Education Level", corrected_code))
			self.assertNotIn(corrected_code, [row[0] for row in search_widget("Education Level", corrected_code)])

			frappe.db.set_value("Education Level", corrected_code, "disabled", 0)
			self.assertIn(corrected_code, [row[0] for row in search_widget("Education Level", corrected_code)])
		finally:
			for name in (corrected_code, code):
				if frappe.db.exists("Education Level", name):
					frappe.delete_doc("Education Level", name, force=True)

	def test_employee_group_opens_full_form_with_active_employee_picker(self):
		from frappe.desk.search import search_widget
		from karyo.hr.employee_group import prepare_employee_group

		self.assertFalse(frappe.get_meta("Employee Group").quick_entry)
		member_meta = frappe.get_meta("Employee Group Table")
		self.assertEqual(member_meta.get_field("employee").label, "Employee Code")
		self.assertEqual(member_meta.get_field("karyo_employee_name_selector").fieldtype, "Autocomplete")
		self.assertTrue(member_meta.get_field("karyo_employee_name_selector").in_list_view)
		self.assertTrue(member_meta.get_field("employee_name").hidden)
		self.assertEqual(member_meta.get_field("employee_name").fetch_from, "employee.employee_name")
		self.assertTrue(member_meta.get_field("user_id").read_only)
		active = frappe.db.get_value("Employee", {"status": "Active"}, "name")
		self.assertTrue(active)
		self.assertTrue(search_widget("Employee", active, filters={"status": "Active"}))
		details = frappe.db.get_value("Employee", active, ["employee_name", "user_id"], as_dict=True)

		by_code = frappe.get_doc({
			"doctype": "Employee Group",
			"employee_group_name": "Code Selection Test",
			"employee_list": [{"employee": active}],
		})
		prepare_employee_group(by_code)
		self.assertEqual(by_code.employee_list[0].karyo_employee_name_selector, active)
		self.assertEqual(by_code.employee_list[0].employee_name, details.employee_name)
		self.assertEqual(by_code.employee_list[0].user_id, details.user_id)

		by_name = frappe.get_doc({
			"doctype": "Employee Group",
			"employee_group_name": "Name Selection Test",
			"employee_list": [{"karyo_employee_name_selector": active}],
		})
		prepare_employee_group(by_name)
		self.assertEqual(by_name.employee_list[0].employee, active)
		self.assertEqual(by_name.employee_list[0].employee_name, details.employee_name)
		self.assertEqual(by_name.employee_list[0].user_id, details.user_id)

	def test_exit_interview_fields_are_not_part_of_simple_separation(self):
		self.assertTrue(frappe.get_meta("Employee Separation").get_field("exit_interview").hidden)
		self.assertTrue(frappe.get_meta("Employee").get_field("held_on").hidden)
		status = frappe.get_meta("Employee Separation").get_field("boarding_status")
		self.assertFalse(status.read_only)
		self.assertEqual(status.options, "Pending\nIn Process\nCompleted")

	def test_company_manual_fields_are_present(self):
		meta = frappe.get_meta("Company")
		expected = {
			"karyo_company_code": ("Code", "Data"),
			"company_name": ("Name", "Data"),
			"abbr": ("Abbreviation Name", "Data"),
			"karyo_address_line_1": ("Address", "Data"),
			"karyo_address_line_2": ("Address 2", "Data"),
			"karyo_address_line_3": ("Address 3", "Data"),
			"karyo_postal_code": ("Postal Code", "Data"),
			"country": ("Country", "Link"),
			"phone_no": ("Phone", "Data"),
			"fax": ("Fax", "Data"),
			"email": ("Email", "Data"),
			"website": ("Website", "Data"),
			"karyo_contact_person": ("Contact Person", "Data"),
			"karyo_paye_number": ("PAYE No", "Data"),
			"karyo_financial_year": ("Financial Year", "Link"),
			"karyo_fin_start_date": ("Fin Start Date", "Date"),
			"karyo_fin_end_date": ("Fin End Date", "Date"),
			"karyo_calendar_year": ("Calendar Year", "Int"),
		}
		for fieldname, (label, fieldtype) in expected.items():
			field = meta.get_field(fieldname)
			self.assertIsNotNone(field, fieldname)
			self.assertEqual(field.label, label, fieldname)
			self.assertEqual(field.fieldtype, fieldtype, fieldname)
		self.assertTrue(meta.get_field("karyo_company_code").read_only)
		self.assertTrue(meta.get_field("karyo_company_code").reqd)
		self.assertEqual(meta.get_field("karyo_payroll_bank").options, "Bank")
		self.assertEqual(meta.get_field("karyo_payroll_bank_branch").options, "Payroll Bank Branch")
		self.assertEqual(meta.get_field("default_bank_account").label, "Payroll Bank Account")
		self.assertEqual(meta.get_field("default_bank_account").insert_after, "karyo_company_payroll_accounts_cb")
		self.assertEqual(meta.get_field("default_payroll_payable_account").insert_after, "default_bank_account")

	def test_company_menu_and_payroll_profile_share_the_same_company_record(self):
		company = frappe.get_all("Company", pluck="name", limit_page_length=1)[0]
		doc = frappe.get_doc("Company", company)
		profile = record_form("company", "Company", company, is_admin=True)
		fields = {
			field["fieldname"]: field
			for section in profile["sections"] for field in section["fields"]
		}
		for fieldname in (
			"karyo_company_code", "company_name", "abbr", "karyo_address_line_1",
			"karyo_address_line_2", "karyo_address_line_3", "karyo_postal_code", "country",
			"phone_no", "fax", "email", "website", "karyo_contact_person", "karyo_paye_number",
			"karyo_financial_year", "karyo_fin_start_date", "karyo_fin_end_date", "karyo_calendar_year",
			"karyo_payroll_bank", "karyo_payroll_bank_branch",
		):
			self.assertIn(fieldname, fields)
			self.assertEqual(fields[fieldname]["value"], doc.get(fieldname), fieldname)
		for fieldname in (
			"default_bank_account", "default_payroll_payable_account",
			"default_expense_claim_payable_account", "default_employee_advance_account",
		):
			self.assertNotIn(fieldname, fields)
		self.assertTrue(fields["karyo_company_code"]["read_only"])
		self.assertTrue(fields["company_name"]["read_only"])

		original = doc.karyo_contact_person
		try:
			doc.karyo_contact_person = "Company menu sync test"
			doc.save(ignore_permissions=True)
			payroll_fields = {
				field["fieldname"]: field["value"]
				for section in record_form("company", "Company", company, is_admin=True)["sections"]
				for field in section["fields"]
			}
			self.assertEqual(payroll_fields["karyo_contact_person"], "Company menu sync test")

			record_save(
				"company", "Company", {"karyo_contact_person": "Payroll sync test"},
				name=company, is_admin=True,
			)
			self.assertEqual(
				frappe.db.get_value("Company", company, "karyo_contact_person"), "Payroll sync test"
			)
		finally:
			frappe.db.set_value("Company", company, "karyo_contact_person", original)

	def test_company_payroll_branch_must_belong_to_selected_bank(self):
		branches = frappe.get_all(
			"Payroll Bank Branch", filters={"is_active": 1}, fields=["name", "bank"], limit_page_length=2
		)
		if not branches:
			self.skipTest("No active payroll bank branch")
		other_bank = frappe.db.get_value("Bank", {"name": ("!=", branches[0].bank)}, "name")
		if not other_bank:
			self.skipTest("Only one bank is configured")
		company = frappe._dict(
			name="TEST-COMPANY", abbr="TST", karyo_company_code="TST",
			karyo_payroll_bank=other_bank, karyo_payroll_bank_branch=branches[0].name,
		)
		with self.assertRaisesRegex(frappe.ValidationError, "does not belong"):
			prepare_company_master(company)

	def test_on_payroll_requires_the_payroll_identity_and_salary_profile(self):
		employee = frappe._dict(
			karyo_on_payroll=1,
			date_of_joining="2026-01-01",
			company=frappe.defaults.get_global_default("company"),
		)
		with self.assertRaisesRegex(frappe.ValidationError, "NIC / Passport"):
			prepare_employee_master(employee)
		self.assertEqual(employee.karyo_employment_start_date, employee.date_of_joining)

	def test_only_bank_payment_mode_requires_dependent_details(self):
		base = dict(
			karyo_on_payroll=1, date_of_joining="2026-01-01", karyo_national_id="NIC-1",
			last_name="Employee", department="Department", karyo_location="Location",
			designation="Job", grade="Grade", karyo_salary_scale="Scale",
			karyo_scale_salary_point=1, karyo_scale_basic_salary=100,
			karyo_payroll_group="Group", karyo_employment_start_date="2026-01-01",
			external_work_history=[],
		)
		prepare_employee_master(frappe._dict(base, salary_mode="Cheque"))
		with self.assertRaisesRegex(frappe.ValidationError, "Payroll Bank"):
			prepare_employee_master(frappe._dict(base, salary_mode="Bank"))
		prepare_employee_master(frappe._dict(base, salary_mode="Cash"))
		with self.assertRaisesRegex(frappe.ValidationError, "Bank, Cheque or Cash"):
			prepare_employee_master(frappe._dict(base, salary_mode="Bank Transfer"))

	def test_employee_bank_account_defaults_and_effective_dates(self):
		doc = frappe._dict(
			doctype="Employee", name="MBC/HR/00999", employee="MBC/HR/00999",
			employee_name="Test Employee", salary_mode="Bank", date_of_joining="2026-01-15",
			karyo_on_payroll=0, external_work_history=[],
		)
		prepare_employee_master(doc)
		self.assertEqual(doc.karyo_bank_employee_code, "MBC/HR/00999")
		self.assertEqual(doc.karyo_bank_account_holder_name, "Test Employee")
		self.assertEqual(doc.karyo_bank_account_is_primary, 1)
		self.assertEqual(doc.karyo_bank_account_effective_from, "2026-01-15")
		doc.karyo_bank_account_effective_to = "2026-01-14"
		with self.assertRaisesRegex(frappe.ValidationError, "cannot be before"):
			prepare_employee_master(doc)
