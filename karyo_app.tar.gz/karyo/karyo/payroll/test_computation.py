import unittest
from unittest.mock import patch

import frappe

from karyo.payroll.computation import (
	RULE_IDS,
	_december_bonus_iet,
	_december_bonus_period_index,
	_emolument_bucket,
	acting_allowance,
	calculate_payroll_chain,
	eoy_bonus,
	hourly_rate,
	lwp_deduction,
	overtime_payment,
	sick_leave_refund,
)


class TestPayrollComputationSheet(unittest.TestCase):
	"""Acceptance cases for Sheet2!A4:J20 (PAY-CALC-001..017)."""

	def test_complete_payroll_chain(self):
		result = calculate_payroll_chain(
			payment_amounts=[50000, 3000, 2000],
			taxable_core_amounts=[50000],
			taxable_travelling=3000,
			taxable_benefits=2000,
			previous_emoluments=45000,
			edf_amount=130000,
			period_index=2,
			periods_per_year=13,
			tax_bands=[{"upper": 50000, "rate": 0}, {"upper": None, "rate": 10}],
			tax_band_factor=1,
			previous_paye=1000,
			other_deductions=[500, 1500],
			employer_contributions=5000,
		)
		self.assertEqual(result["gross_pay"], 55000)  # PAY-CALC-001
		self.assertEqual(result["monthly_taxable_emolument"], 50000)  # 002
		self.assertEqual(result["current_gross_emoluments"], 55000)  # 003
		self.assertEqual(result["total_emoluments"], 100000)  # 004
		self.assertEqual(result["monthly_iet"], 20000)  # 005
		self.assertEqual(result["chargeable_income"], 80000)  # 006
		self.assertEqual(result["net_paye_payable"], 3000)  # 007
		self.assertEqual(result["paye"], 2000)  # 008
		self.assertEqual(result["total_employee_deductions"], 4000)  # 009
		self.assertEqual(result["net_pay"], 51000)  # 010
		self.assertEqual(result["employer_cost"], 60000)  # 011
		self.assertEqual(result["rule_references"], list(RULE_IDS[:11]))

	def test_no_edf_uses_flat_fifteen_percent(self):
		result = calculate_payroll_chain(
			payment_amounts=[100000],
			taxable_core_amounts=[100000],
			no_edf_rate=15,
		)
		self.assertEqual(result["monthly_iet"], 0)
		self.assertEqual(result["paye"], 15000)
		self.assertEqual(result["net_pay"], 85000)

	def test_hourly_rate_and_overtime(self):
		rate = hourly_rate(520000, 2080)
		self.assertEqual(rate, 250)  # PAY-CALC-012
		self.assertEqual(overtime_payment(rate, 8, 2), 4000)  # PAY-CALC-013

	def test_acting_allowance_uses_higher_basis_and_prorates(self):
		self.assertEqual(
			acting_allowance(5000, 3000, applicable_percentage=50, proration_ratio=0.5),
			1250,
		)  # PAY-CALC-014

	def test_lwp_sick_refund_and_eoy(self):
		self.assertEqual(lwp_deduction(44000, 2, 22), 4000)  # PAY-CALC-015
		self.assertEqual(sick_leave_refund(5, 44000, 22), 10000)  # PAY-CALC-016
		self.assertEqual(eoy_bonus(60000, 183, 365), 30082.19)  # PAY-CALC-017

	def test_bonus_iet_is_identified_only_for_december_bonus_payroll(self):
		declaration = frappe._dict(declaration_status="Submitted")
		year = frappe._dict(periods_per_year=13)
		with patch(
			"karyo.payroll.computation.cumulative_declaration_deduction",
			side_effect=lambda _declaration, _year, position: position * 1000,
		):
			self.assertEqual(_december_bonus_iet(declaration, year, "2026-12-31", 50000), 1000)
			self.assertEqual(_december_bonus_iet(declaration, year, "2026-11-30", 50000), 0)
			self.assertEqual(_december_bonus_iet(declaration, year, "2026-12-31", 0), 0)

	def test_separate_and_combined_december_bonus_use_distinct_paye_positions(self):
		self.assertEqual(
			_december_bonus_period_index(6, "Prescribed Bonus - Separate", "2026-12-15"), 6
		)
		self.assertEqual(
			_december_bonus_period_index(6, "Prescribed Bonus - Combined with Salary", "2026-12-31"), 7
		)
		self.assertEqual(_december_bonus_period_index(7, "Regular Salary", "2026-12-31"), 7)

	def test_invalid_divisors_are_rejected(self):
		for calculation in (
			lambda: hourly_rate(520000, 0),
			lambda: lwp_deduction(44000, 2, 0),
			lambda: sick_leave_refund(5, 44000, 0),
			lambda: eoy_bonus(60000, 183, 0),
		):
			with self.assertRaises(ValueError):
				calculation()

	def test_taxable_emolument_buckets_follow_pdb_type_and_description(self):
		self.assertEqual(
			_emolument_bucket({"pdb_type": "TRV", "description": "Allowance"}, "Allowance"),
			"taxable_travelling",
		)
		self.assertEqual(
			_emolument_bucket({"pdb_type": "PAY", "description": "Transport Allowance"}),
			"taxable_travelling",
		)
		self.assertEqual(
			_emolument_bucket({"classification": "Benefit", "description": "Company Car"}),
			"taxable_benefits",
		)
		self.assertEqual(
			_emolument_bucket({"pdb_type": "PAY", "description": "Medical Allowance"}),
			"taxable_benefits",
		)
		self.assertEqual(
			_emolument_bucket({"pdb_type": "ALL", "description": "Basic Salary"}),
			"monthly_taxable_emolument",
		)


if __name__ == "__main__":
	unittest.main()
