from datetime import timedelta
from unittest.mock import Mock, patch

import frappe
from frappe.tests.utils import FrappeTestCase
from frappe.utils import getdate

from karyo.hr.roster import (
	KaryoShiftScheduleAssignment,
	_display_time,
	_expand_month_roster,
	_replace_shift_assignments_from,
	_time_hours,
	current_duty,
	employee_work_pattern_assignments,
	prepare_schedule_assignment,
	schedule_assignment_values,
	shift_roster_setup_status,
	shift_schedule_details,
	work_pattern_context,
)


class TestRoster(FrappeTestCase):
	def test_roster_change_replaces_future_duties_and_preserves_history(self):
		rows = [
			frappe._dict(name="SHIFT-SPAN", start_date="2026-09-01", end_date="2026-09-30"),
			frappe._dict(name="SHIFT-FUTURE", start_date="2026-09-15", end_date="2026-09-15"),
		]
		future = frappe._dict(flags=frappe._dict(), cancel=Mock())
		with patch.object(frappe, "get_all", return_value=rows), patch.object(
			frappe.db, "set_value"
		) as set_value, patch.object(frappe, "get_doc", return_value=future):
			result = _replace_shift_assignments_from("EMP-1", "2026-09-15")
		set_value.assert_called_once_with(
			"Shift Assignment", "SHIFT-SPAN", "end_date", getdate("2026-09-14"),
			update_modified=False,
		)
		future.cancel.assert_called_once()
		self.assertEqual(result["shortened"], ["SHIFT-SPAN"])
		self.assertEqual(result["cancelled"], ["SHIFT-FUTURE"])

	def test_month_roster_contains_every_day_and_the_assigned_shift(self):
		assignments = [frappe._dict(
			name="SHIFT-1", start_date="2026-09-02", end_date="2026-09-03",
			shift_type="Night Shift", shift_code="NIGHT", start_time="22:00:00",
			end_time="06:00:00", duty_hours=8, shift_schedule="Night Rotation",
			shift_location="HQ",
		)]
		rows = _expand_month_roster(assignments, "2026-09-01", "2026-09-03")
		self.assertEqual(len(rows), 3)
		self.assertTrue(rows[0]["is_rest_day"])
		self.assertEqual(rows[1]["shift_type"], "Night Shift")
		self.assertEqual(rows[1]["shift_code"], "NIGHT")
		self.assertEqual(rows[1]["start_time"], "22:00")
		self.assertEqual(rows[1]["end_time"], "06:00")

	def test_historical_duty_does_not_filter_on_current_active_status(self):
		row = frappe._dict(
			name="SHIFT-OLD", shift_type="Day Shift", start_date="2026-09-01",
			end_date="2026-09-10", shift_schedule_assignment=None, shift_location=None,
		)
		context = frappe._dict(
			shift_code="DAY", start_time="09:00:00", end_time="18:00:00", duty_hours=9,
		)
		with patch.object(frappe, "get_all", return_value=[row]) as listing, patch(
			"karyo.hr.roster.shift_context", return_value=context
		):
			duty = current_duty("EMP-1", "2026-09-05")
		self.assertNotIn("status", listing.call_args.kwargs["filters"])
		self.assertEqual(duty.assignment, "SHIFT-OLD")

	def _employee_without_assignment(self):
		assigned = set(frappe.get_all(
			"Shift Assignment", filters={"docstatus": 1, "status": "Active"}, pluck="employee",
		))
		return frappe.db.get_value(
			"Employee", {"status": "Active", "name": ["not in", list(assigned) or [""]]},
			["name", "company"], as_dict=True,
		)

	def test_cross_midnight_shift_hours(self):
		self.assertEqual(_time_hours(timedelta(hours=22), timedelta(hours=6)), 8)
		self.assertEqual(_display_time("6:00:00"), "06:00")

	def test_shift_type_resolves_its_only_submitted_schedule(self):
		details = shift_schedule_details(shift_type="Night Shift")
		self.assertEqual(details["shift_schedule"], "Field Work")
		self.assertEqual(details["karyo_shift_type"], "Night Shift")
		self.assertEqual(details["karyo_is_rotational_schedule"], 0)

	def test_rotational_schedule_populates_cycle_fields(self):
		details = schedule_assignment_values("PRB 3-Shift Rotation")
		self.assertEqual(details["karyo_shift_type"], "PRB 8-Hour Day")
		self.assertEqual(details["karyo_is_rotational_schedule"], 1)
		self.assertEqual(details["karyo_rotation_cycle_days_snapshot"], 21)
		self.assertIn("Day 1:", details["karyo_rotation_pattern"])
		self.assertIn("Rest Day", details["karyo_rotation_pattern"])

	def test_schedule_assignment_rejects_mismatched_shift_type(self):
		doc = frappe.new_doc("Shift Schedule Assignment")
		doc.shift_schedule = "Field Work"
		doc.karyo_shift_type = "Day Shift"
		with self.assertRaisesRegex(frappe.ValidationError, "belongs to Shift Type Night Shift"):
			prepare_schedule_assignment(doc)

	def test_schedule_can_supply_mandatory_shift_type(self):
		doc = frappe.new_doc("Shift Schedule Assignment")
		doc.shift_schedule = "Field Work"
		prepare_schedule_assignment(doc)
		self.assertEqual(doc.karyo_shift_type, "Night Shift")

	def test_shift_type_only_assignment_is_valid(self):
		doc = frappe.new_doc("Shift Schedule Assignment")
		doc.karyo_shift_type = "Day Shift"
		prepare_schedule_assignment(doc)
		self.assertFalse(doc.shift_schedule)
		self.assertEqual(doc.karyo_is_rotational_schedule, 0)

	def test_work_pattern_resolves_shift_mapping(self):
		if not frappe.db.exists("Employee Work Pattern", "Standard 33.75 Hours"):
			self.skipTest("work-pattern catalogue is not installed")
		context = work_pattern_context("Standard 33.75 Hours")
		self.assertEqual(context.shift_type, "PRB Standard Day")
		self.assertTrue(context.shift_code)

	def test_direct_shift_type_assignment_generates_dated_duty(self):
		employee = self._employee_without_assignment()
		if not employee or not frappe.db.exists("Shift Type", "PRB Standard Day"):
			self.skipTest("roster catalogue is not installed")
		doc = frappe.get_doc({
			"doctype": "Shift Schedule Assignment",
			"employee": employee.name,
			"company": employee.company,
			"karyo_shift_type": "PRB Standard Day",
			"shift_status": "Active",
			"enabled": 1,
			"create_shifts_after": "2099-01-01",
		}).insert(ignore_permissions=True)
		doc.create_shifts("2099-01-02", "2099-01-08")
		assignment = frappe.db.get_value(
			"Shift Assignment",
			{"shift_schedule_assignment": doc.name, "docstatus": 1},
			["shift_type", "start_date", "end_date"],
			as_dict=True,
		)
		self.assertEqual(assignment.shift_type, "PRB Standard Day")
		self.assertEqual(str(assignment.start_date), "2099-01-02")
		self.assertEqual(str(assignment.end_date), "2099-01-08")

	def test_rotational_schedule_generates_each_work_duty_and_skips_rest_days(self):
		employee = self._employee_without_assignment()
		if not employee or not frappe.db.exists("Shift Schedule", "PRB 3-Shift Rotation"):
			self.skipTest("roster catalogue is not installed")
		doc = frappe.get_doc({
			"doctype": "Shift Schedule Assignment",
			"employee": employee.name,
			"company": employee.company,
			"shift_schedule": "PRB 3-Shift Rotation",
			"shift_status": "Active",
			"enabled": 1,
			"create_shifts_after": "2031-01-01",
			"karyo_rotation_anchor_date": "2031-01-01",
		}).insert(ignore_permissions=True)
		self.assertIsInstance(doc, KaryoShiftScheduleAssignment)
		doc.create_shifts("2031-01-01", "2031-01-21")
		rows = frappe.get_all(
			"Shift Assignment",
			filters={"shift_schedule_assignment": doc.name, "docstatus": 1},
			fields=["start_date", "shift_type"],
			order_by="start_date asc",
		)
		self.assertEqual(len(rows), 15)
		self.assertEqual({row.shift_type for row in rows[:5]}, {"PRB 8-Hour Day"})
		self.assertEqual({row.shift_type for row in rows[5:10]}, {"PRB 8-Hour Evening"})
		self.assertEqual({row.shift_type for row in rows[10:]}, {"PRB 8-Hour Night"})
		self.assertNotIn("2031-01-06", {str(row.start_date) for row in rows})
		self.assertNotIn("2031-01-21", {str(row.start_date) for row in rows})

	def test_setup_status_lists_active_rostered_employees(self):
		assignment = frappe.db.get_value(
			"Shift Schedule Assignment", {"enabled": 1, "docstatus": ["<", 2]}, "employee"
		)
		if not assignment:
			self.skipTest("No active roster setup fixture")
		status = shift_roster_setup_status()
		self.assertIn(assignment, {row["name"] for row in status["rostered_rows"]})

	def test_work_pattern_assignment_register_matches_employee_field(self):
		assigned = frappe.db.get_value(
			"Employee", {"status": ["!=", "Left"], "karyo_work_pattern": ["is", "set"]},
			["name", "karyo_work_pattern"], as_dict=True,
		)
		if not assigned:
			self.skipTest("No employee Work Pattern assignment fixture")
		result = employee_work_pattern_assignments()
		row = next(item for item in result["rows"] if item["employee"] == assigned.name)
		self.assertEqual(row["work_pattern"], assigned.karyo_work_pattern)
		self.assertEqual(result["source_field"], "Employee.karyo_work_pattern")
