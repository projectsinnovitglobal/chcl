"""Official PRB grade-scale staging, validation, and activation (PAY-043)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"PRB Grade Scale Import Row",
		istable=1,
		fields=[
			f("grade_id", "Data", "Grade", reqd=1, in_list_view=1),
			f("organisation", "Data", "Organisation", in_list_view=1),
			f("sector", "Select", "Sector", options="\nCivil Service\nParastatal\nLocal Authority\nRodrigues"),
			f("volume_part", "Data", "Volume 2 Part"),
			f("initial_point", "Data", "Initial Point", in_list_view=1),
			f("top_point", "Data", "Top Point", in_list_view=1),
			f("qualification_bar_point", "Data", "Qualification Bar"),
			f("is_flat_salary", "Check", "Flat Salary"),
			f("flat_salary", "Currency", "Flat Salary Amount"),
			f("source_reference", "Data", "Source Reference"),
		],
	)
	make_doctype(
		"PRB Grade Scale Migration Exception",
		istable=1,
		fields=[
			f("severity", "Select", "Severity", options="Error\nWarning", reqd=1, in_list_view=1),
			f("exception_code", "Data", "Code", reqd=1, in_list_view=1),
			f("grade_id", "Data", "Grade", in_list_view=1),
			f("employee", "Link", "Employee", options="Employee", in_list_view=1),
			f("detail", "Small Text", "Detail", reqd=1),
		],
	)
	make_doctype(
		"PRB Grade Scale Dataset",
		autoname="naming_series:",
		title_field="dataset_title",
		fields=[
			f("naming_series", "Select", "Series", options="PRBG-.YYYY.-.#####", default="PRBG-.YYYY.-.#####"),
			f("dataset_title", "Data", "Dataset Title", reqd=1, in_list_view=1),
			f("configuration_version", "Link", "Configuration Version", options="Payroll Configuration Version", reqd=1),
			f("source_reference", "Data", "Official Source Reference", reqd=1),
			f("source_file", "Attach", "Source CSV"),
			f("source_hash", "Data", "Source SHA-256", read_only=1),
			f("is_official_client_data", "Check", "Confirmed Official Client Data"),
			f("effective_from", "Date", "Effective From", reqd=1),
			f("status", "Select", "Status", options="Draft\nValidated\nActivated\nRejected", default="Draft", read_only=1, in_list_view=1),
			f("validation_sb", "Section Break", "Validation and Activation"),
			f("row_count", "Int", "Rows", read_only=1),
			f("error_count", "Int", "Errors", read_only=1),
			f("warning_count", "Int", "Warnings", read_only=1),
			f("validated_by", "Link", "Validated By", options="User", read_only=1),
			f("validated_on", "Datetime", "Validated On", read_only=1),
			f("activated_by", "Link", "Activated By", options="User", read_only=1),
			f("activated_on", "Datetime", "Activated On", read_only=1),
			f("rows_sb", "Section Break", "Imported Grade Scales"),
			f("rows", "Table", "Grade Scales", options="PRB Grade Scale Import Row"),
			f("exceptions_sb", "Section Break", "Migration and Employee Exceptions"),
			f("exceptions", "Table", "Exceptions", options="PRB Grade Scale Migration Exception", read_only=1),
		],
	)


def extend_grade_scale():
	create_custom_fields(
		{
			"PRB Grade Scale": [
				{"fieldname": "migration_sb", "fieldtype": "Section Break", "label": "Dataset Governance", "insert_after": "is_flat_salary"},
				{"fieldname": "dataset", "fieldtype": "Link", "label": "Source Dataset", "options": "PRB Grade Scale Dataset", "read_only": 1, "insert_after": "migration_sb"},
				{"fieldname": "data_origin", "fieldtype": "Select", "label": "Data Origin", "options": "Demo\nOfficial", "default": "Demo", "read_only": 1, "insert_after": "dataset"},
				{"fieldname": "is_active", "fieldtype": "Check", "label": "Active", "default": "0", "read_only": 1, "insert_after": "data_origin"},
				{"fieldname": "effective_from", "fieldtype": "Date", "label": "Effective From", "read_only": 1, "insert_after": "is_active"},
				{"fieldname": "source_reference", "fieldtype": "Data", "label": "Source Reference", "read_only": 1, "insert_after": "effective_from"},
			]
		},
		ignore_validate=True,
	)
	frappe.db.sql(
		"""
		update `tabPRB Grade Scale`
		set data_origin='Demo', is_active=0,
		    source_reference='SAMPLE / DUMMY — not approved for production'
		where coalesce(data_origin, '')=''
		"""
	)


def setup():
	print("Karyo PRB grade-scale migration setup:")
	create_doctypes()
	extend_grade_scale()
	frappe.db.commit()
	print("Done (official scale staging, validation, impact reporting, and activation created).")
