"""Simple separation approval without an Exit Interview dependency."""

import unittest

import frappe
from frappe.utils import today

from karyo.product_scope import HIDDEN_HR_SETTINGS_FIELDS, hidden_doctypes
from karyo.setup.employee_master import (
	capture_separation_employee_status,
	deactivate_separated_employee,
	prevent_completed_separation_cancellation,
	restore_separated_employee,
)


class TestEmployeeSeparationSimple(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("simple_separation")
		self.employee = frappe.db.get_value(
			"Employee",
			{"status": "Active", "name": ("not in", frappe.get_all(
				"Employee Separation", filters={"docstatus": 1}, pluck="employee"
			) or [""])},
			"name",
		)
		if not self.employee:
			self.skipTest("No active employee without an approved separation")

	def tearDown(self):
		frappe.db.rollback(save_point="simple_separation")
		frappe.set_user(self.user)

	def test_pending_approval_stays_active_and_completion_is_irreversible(self):
		separation = frappe._dict(
			name="TEST-SEPARATION-NOT-SAVED", employee=self.employee,
			boarding_status="Pending", docstatus=1, karyo_previous_employee_status=None,
			karyo_previous_user_enabled=0,
		)
		capture_separation_employee_status(separation)
		self.assertEqual(separation.karyo_previous_employee_status, "Active")

		deactivate_separated_employee(separation)
		self.assertEqual(frappe.db.get_value("Employee", self.employee, "status"), "Active")

		separation.boarding_status = "Completed"
		deactivate_separated_employee(separation)
		self.assertEqual(frappe.db.get_value("Employee", self.employee, "status"), "Inactive")

		restore_separated_employee(separation)
		self.assertEqual(frappe.db.get_value("Employee", self.employee, "status"), "Inactive")
		with self.assertRaises(frappe.ValidationError):
			prevent_completed_separation_cancellation(separation)

	def test_submitted_pending_separation_does_not_deactivate_employee(self):
		employee = frappe.get_doc("Employee", self.employee)
		separation = frappe.get_doc({
			"doctype": "Employee Separation",
			"employee": employee.name,
			"company": employee.company,
			"boarding_begins_on": today(),
			"karyo_leaving_date": today(),
			"boarding_status": "Pending",
		}).insert()
		separation.submit()

		self.assertEqual(separation.boarding_status, "Pending")
		self.assertEqual(frappe.db.get_value("Employee", employee.name, "status"), "Active")

		project = frappe.get_doc("Project", separation.project)
		project.percent_complete_method = "Manual"
		project.status = "Completed"
		project.save()
		separation.reload()
		self.assertEqual(separation.boarding_status, "Completed")
		self.assertEqual(frappe.db.get_value("Employee", employee.name, "status"), "Inactive")
		with self.assertRaises(frappe.ValidationError):
			separation.cancel()
		employee.reload()
		employee.status = "Active"
		with self.assertRaises(frappe.ValidationError):
			employee.save()

	def test_approval_disables_employee_login_and_cancellation_restores_it(self):
		employee = next((
			row for row in frappe.get_all(
				"Employee", filters={"status": "Active", "user_id": ("is", "set")},
				fields=["name", "user_id"], limit_page_length=0,
			)
			if row.user_id not in ("Administrator", "Guest")
			and frappe.db.get_value("User", row.user_id, "enabled")
		), None)
		if not employee:
			self.skipTest("No active employee with an enabled ESS login")

		separation = frappe._dict(
			name="TEST-SEPARATION-LOGIN", employee=employee.name,
			boarding_status="Completed", docstatus=1,
			karyo_previous_employee_status=None, karyo_previous_user_enabled=0,
		)
		capture_separation_employee_status(separation)
		self.assertEqual(separation.karyo_previous_user_enabled, 1)
		deactivate_separated_employee(separation)
		self.assertEqual(frappe.db.get_value("User", employee.user_id, "enabled"), 0)
		restore_separated_employee(separation)
		self.assertEqual(frappe.db.get_value("User", employee.user_id, "enabled"), 0)

	def test_exit_interview_is_hidden_from_product_navigation(self):
		self.assertIn("Exit Interview", hidden_doctypes())
		self.assertTrue(frappe.get_meta("Employee Separation").get_field("exit_interview").hidden)
		self.assertTrue(frappe.get_meta("Employee").get_field("new_workplace").hidden)
		status = frappe.get_meta("Employee Separation").get_field("boarding_status")
		self.assertFalse(status.read_only)
		self.assertEqual(status.options.splitlines(), ["Pending", "In Process", "Completed"])

	def test_out_of_scope_hr_settings_are_hidden(self):
		meta = frappe.get_meta("HR Settings")
		for fieldname in HIDDEN_HR_SETTINGS_FIELDS:
			self.assertTrue(meta.get_field(fieldname).hidden, fieldname)
