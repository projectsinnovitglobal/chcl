"""Bulk increment, compensation, and EOY calculation/application workflow."""

from calendar import isleap

import frappe
from frappe import _
from frappe.utils import add_days, cint, date_diff, flt, getdate, now_datetime

from karyo.payroll.compensation import calculate_compensation
from karyo.payroll.salary_scales import approved_appointment, is_flat_scale
from karyo.prb.engine import build_lookups, convert_salary_point
from karyo.prb.eoy import eoy_bonus
from karyo.prb.movements import advance_point


def validate_december_bonus_cycle(payroll_cycle, company, payroll_date):
	"""Validate either supported December statutory-bonus processing mode.

	The bonus may be included in the regular December salary calculation or run
	in a dedicated December bonus cycle. The latter owns PAYE position 6; the
	regular/combined December cycle owns position 7.
	"""
	if not payroll_cycle:
		return {"payment_type": None, "period_index": None}
	cycle = frappe.db.get_value(
		"Payroll Cycle", payroll_cycle,
		[
			"company", "start_date", "end_date", "pay_day",
			"paye_payment_type", "paye_period_index",
		],
		as_dict=True,
	)
	payroll_date = getdate(payroll_date)
	if not cycle or cycle.company != company:
		frappe.throw(_("Select the employee company's December Payroll Cycle."))
	if payroll_date.month != 12 or not (
		getdate(cycle.start_date) <= payroll_date <= getdate(cycle.end_date)
	):
		frappe.throw(_("The EOY Bonus effective date must fall in the selected December Payroll Cycle."))
	payment_type = cycle.paye_payment_type
	period_index = cycle.paye_period_index
	if cycle.pay_day and (not payment_type or not period_index):
		pay_day = frappe.db.get_value(
			"Payroll Pay Day", cycle.pay_day,
			["paye_payment_type", "paye_period_index"], as_dict=True,
		)
		payment_type = payment_type or (pay_day or {}).get("paye_payment_type")
		period_index = period_index or (pay_day or {}).get("paye_period_index")
	allowed = {
		"Regular Salary",
		"Prescribed Bonus - Combined with Salary",
		"Prescribed Bonus - Separate",
	}
	if payment_type and payment_type not in allowed:
		frappe.throw(_(
			"EOY Bonus requires the regular/combined December payroll or a Prescribed Bonus - Separate cycle."
		))
	expected = 6 if payment_type == "Prescribed Bonus - Separate" else 7
	if period_index and int(period_index) != expected:
		frappe.throw(_(
			"The selected {0} cycle must use PAYE period position {1}."
		).format(payment_type or _("December payroll"), expected))
	return {"payment_type": payment_type, "period_index": int(period_index or expected)}


def _mapped_pdb(salary_components, company=None):
	rows = frappe.get_all(
		"Payroll PDB Code",
		filters={"salary_component": ("in", salary_components), "is_active": 1},
		fields=["name", "salary_component", "company"],
		order_by="modified desc",
	)
	rows = [row for row in rows if not row.company or not company or row.company == company]
	rows.sort(key=lambda row: (
		salary_components.index(row.salary_component),
		0 if company and row.company == company else 1,
	))
	return rows[0].name if rows else None


def default_pdb(run_type, compensation_scheme=None, company=None):
	"""Return the active PDB mapping suggested by the selected process."""
	pdb_code = None
	if "Compensation" in (run_type or "") and compensation_scheme:
		pdb_code = frappe.db.get_value(
			"Payroll Compensation Scheme", compensation_scheme, "compensation_pdb_code"
		)
	elif run_type == "EOY Bonus":
		pdb_code = _mapped_pdb(["EOY Bonus"], company) or (
			"EOY" if frappe.db.exists("Payroll PDB Code", {"name": "EOY", "is_active": 1}) else None
		)
	elif "Increment" in (run_type or ""):
		pdb_code = _mapped_pdb(["Basic", "BASIC SALARY"], company) or (
			"BASIC" if frappe.db.exists("Payroll PDB Code", {"name": "BASIC", "is_active": 1}) else None
		)
	return {
		"pdb_type": frappe.db.get_value("Payroll PDB Code", pdb_code, "pdb_type") if pdb_code else None,
		"pdb_code": pdb_code,
	}


@frappe.whitelist()
def get_default_pdb(run_type, compensation_scheme=None, company=None):
	return default_pdb(run_type, compensation_scheme, company)


def _scale_context(employee, effective_date, increment_due=False, increment_points=1):
	"""Resolve an effective salary and move by the requested salary points.

	Each generated salary-scale step is one point.  Its monetary value comes
	from the effective Increment Band, so a point value of 100 produces an
	increment of 100 for one point and 200 for two points (unless the movement
	reaches a new band or the top of the scale).
	"""
	appointment = approved_appointment(employee.name, effective_date)
	if appointment and appointment.pay_basis == "PRB":
		# Use the appointment effective on the award date, including a future
		# appointment, rather than today's cached Employee salary point.
		prb_employee = frappe._dict(employee.as_dict() if callable(getattr(employee, "as_dict", None)) else dict(employee))
		prb_employee.update(karyo_prb_salary_point=appointment.prb_salary_point,
			karyo_prb_grade=appointment.prb_grade)
		context = _legacy_context(prb_employee, increment_due, increment_points, effective_date,
			review_year=appointment.prb_year)
		if context:
			context.update(salary_appointment=appointment.name,
				increment_source=_("PRB Salary Point Table {0}").format(appointment.prb_year))
		return context
	if not appointment or not appointment.salary_scale:
		return None
	scale = frappe.get_doc("Salary Scale", appointment.salary_scale)
	if scale.docstatus != 1:
		frappe.throw(_("Increment table {0} is not approved.").format(appointment.salary_scale))
	if is_flat_scale(scale):
		amount = flt(scale.get("basic_salary") or appointment.basic_salary)
		return {
			"salary_appointment": appointment.name,
			"salary_scale": appointment.salary_scale,
			"increment_source": _("Flat Salary Scale {0}").format(appointment.salary_scale),
			"increment_steps": max(1, cint(increment_points or 1)),
			"applied_increment_points": 0,
			"original_salary_point": "",
			"proposed_salary_point": "",
			"increment_base": amount,
			"proposed_salary": amount,
			"increment_eligible": False,
			"increment_amount": 0,
		}
	points = list(scale.get("points") or [])
	current_index = next(
		(index for index, point in enumerate(points) if cint(point.salary_point) == cint(appointment.salary_point)),
		None,
	)
	if current_index is None:
		frappe.throw(
			_("Salary point {0} is not present in increment table {1}.").format(
				appointment.salary_point, appointment.salary_scale
			)
		)
	current = points[current_index]
	requested_points = max(1, cint(increment_points or 1))
	proposed_index = min(current_index + requested_points, len(points) - 1) if increment_due else current_index
	proposed = points[proposed_index]
	applied_points = proposed_index - current_index if increment_due else 0
	increment_eligible = bool(applied_points)
	band = next(
		(
			row for row in reversed(list(scale.get("bands") or []))
			if flt(current.salary) >= flt(row.salary)
		),
		None,
	)
	source = (
		_("Increment Band {0}").format(band.increment_band)
		if band and band.increment_band
		else _("Increment Table {0}").format(appointment.salary_scale)
	)
	return {
		"salary_appointment": appointment.name,
		"salary_scale": appointment.salary_scale,
		"increment_source": source,
		"increment_steps": requested_points,
		"applied_increment_points": applied_points,
		"original_salary_point": str(current.salary_point),
		"proposed_salary_point": str(proposed.salary_point),
		"increment_base": flt(current.salary),
		"proposed_salary": flt(proposed.salary),
		"increment_eligible": increment_eligible,
		"increment_amount": flt(proposed.salary) - flt(current.salary) if increment_eligible else 0,
	}


def _legacy_context(employee, increment_due=False, increment_points=1, effective_date=None, review_year=None):
	point = employee.karyo_prb_salary_point
	if not point:
		return None
	current = convert_salary_point(point)
	if not current["revised_salary_2026"]:
		return None
	grade = employee.get("karyo_prb_grade")
	grade_values = frappe.db.get_value(
		"PRB Grade Scale", grade, ["top_point", "is_flat_salary"], as_dict=True
	) if grade else None
	grade_top = grade_values.top_point if grade_values else None
	eligible = bool(increment_due and not (grade_values and grade_values.is_flat_salary))
	requested_points = max(1, cint(increment_points or 1))
	revised, ordered = build_lookups()
	proposed_point = advance_point(point, requested_points, ordered, top=grade_top) if eligible else point
	from karyo.setup.payroll_profiles import prb_salary_value
	current_salary = prb_salary_value(point, review_year=review_year, effective_date=effective_date or getdate())
	proposed_salary = prb_salary_value(proposed_point, review_year=review_year, effective_date=effective_date or getdate())
	applied_points = (
		max(0, ordered.index(proposed_point) - ordered.index(point))
		if point in ordered and proposed_point in ordered
		else 0
	)
	return {
		"salary_appointment": None,
		"salary_scale": None,
		"increment_source": _("Legacy PRB Salary Point Table"),
		"original_salary_point": point,
		"increment_steps": requested_points,
		"applied_increment_points": applied_points,
		"proposed_salary_point": proposed_point,
		"increment_base": flt(current_salary),
		"proposed_salary": flt(proposed_salary),
		"increment_eligible": bool(applied_points),
		"increment_amount": flt(proposed_salary) - flt(current_salary),
	}


def _employee_preview_values(employee, effective_date=None, run_type="Increment", increment_points=1):
	"""Values displayed as soon as an employee is selected in the bulk drawer."""
	context = None
	increment_due = "Increment" in (run_type or "")
	preview_date = effective_date or getdate()
	if preview_date:
		context = _scale_context(employee, preview_date, increment_due=increment_due, increment_points=increment_points) or _legacy_context(
			employee, increment_due=increment_due, increment_points=increment_points, effective_date=preview_date
		)
	values = {
		"employee": employee.name,
		"employee_name": employee.employee_name,
		"include": 1,
	}
	if not context:
		if preview_date:
			values.update(
				{
					"include": 0,
					"exception_code": "MISSING_GRADE_SCALE",
					"exception_detail": _("Employee has no approved salary scale or PRB salary point."),
				}
			)
		return values
	values.update(context)
	values.update(
		{
			"salary_basis": context["proposed_salary"] if increment_due else context["increment_base"],
			"increment_amount": context["increment_amount"] if increment_due else 0,
		}
	)
	values["calculated_total"] = values["increment_amount"]
	values["final_total"] = None
	if increment_due and not context.get("increment_eligible") and run_type == "Increment":
		values.update({
			"include": 0,
			"exception_code": "NOT_INCREMENT_ELIGIBLE",
			"exception_detail": _("Employee is at the top of the approved scale or has a flat salary."),
		})
	return values


@frappe.whitelist()
def employee_preview(employee, effective_date=None, run_type="Increment", increment_points=1):
	"""Prefill a newly selected employee row before the run is saved."""
	if not employee:
		return {}
	doc = frappe.get_doc("Employee", employee)
	doc.check_permission("read")
	return _employee_preview_values(doc, effective_date, run_type, increment_points)


def _employees(batch):
	"""Return only the employees explicitly selected on the run."""
	selected = list(dict.fromkeys(row.employee for row in batch.lines if row.employee))
	if not selected:
		return []
	include_retired = bool(getattr(batch, "include_retired", 0) and batch.run_type == "EOY Bonus")
	filters = {
		"company": batch.company,
		"status": ("in", ["Active", "Left"]) if include_retired else "Active",
		"name": ("in", selected),
	}
	rows = frappe.get_all(
		"Employee",
		filters=filters,
		fields=[
			"name", "employee_name", "status", "date_of_joining", "relieving_date",
			"karyo_prb_salary_point", "karyo_prb_grade",
		],
		order_by="name",
	)
	if include_retired:
		# Active employees normally have no relieving date and must remain in the
		# run.  The period boundary applies only to people who have left.
		period_start = getdate(batch.period_start)
		rows = [
			row for row in rows
			if row.status == "Active" or (row.relieving_date and getdate(row.relieving_date) >= period_start)
		]
	by_name = {row.name: row for row in rows}
	return [by_name[name] for name in selected if name in by_name]


@frappe.whitelist()
def preview_employees(
	company,
	employees=None,
	run_type=None,
	include_retired=0,
	period_start=None,
	effective_date=None,
):
	"""Preview an explicit single- or multi-employee selection."""
	if not frappe.has_permission("Employee", "read"):
		frappe.throw(_("Not permitted to view employees."), frappe.PermissionError)
	if isinstance(employees, str):
		employees = frappe.parse_json(employees)
	selected = list(dict.fromkeys(employee for employee in (employees or []) if employee))
	if not company or not selected:
		return []
	batch = frappe._dict(
		company=company,
		run_type=run_type,
		include_retired=cint(include_retired),
		period_start=period_start,
		lines=[frappe._dict(employee=employee) for employee in selected],
	)
	return [
		_employee_preview_values(row, effective_date, run_type)
		for row in _employees(batch)
	]


@frappe.whitelist()
def employee_selection_options(company, txt="", run_type=None, include_retired=0, period_start=None):
	"""Searchable options for the explicit employee selector."""
	if not frappe.has_permission("Employee", "read"):
		frappe.throw(_("Not permitted to view employees."), frappe.PermissionError)
	if not company:
		return []
	include_leavers = bool(cint(include_retired) and run_type == "EOY Bonus")
	filters = {
		"company": company,
		"status": ("in", ["Active", "Left"]) if include_leavers else "Active",
	}
	search = "%{0}%".format((txt or "").strip())
	rows = frappe.get_all(
		"Employee",
		filters=filters,
		or_filters={"name": ("like", search), "employee_name": ("like", search)},
		fields=["name", "employee_name", "status", "relieving_date"],
		order_by="employee_name, name",
		limit_page_length=50,
	)
	if include_leavers and period_start:
		start = getdate(period_start)
		rows = [
			row for row in rows
			if row.status == "Active" or (row.relieving_date and getdate(row.relieving_date) >= start)
		]
	return [
		{
			"value": row.name,
			"label": "{0} ({1})".format(row.employee_name or row.name, row.name),
			"description": _("Left employee") if row.status == "Left" else row.name,
		}
		for row in rows
	]


def _lwp_days(employee, start_date, end_date):
	return flt(
		frappe.db.sql(
			"""
			select coalesce(sum(leave_without_pay), 0)
			from `tabSalary Slip`
			where employee=%s and docstatus=1 and end_date >= %s and start_date <= %s
			""",
			(employee, start_date, end_date),
		)[0][0]
	)


def _day_basis(batch):
	year = getdate(batch.period_end).year
	configured = frappe.db.get_single_value("Karyo Settings", "day_count_basis")
	return 366 if configured == "Actual (366 in leap years)" and isleap(year) else 365


def _calculate_employee(batch, employee, increment_points=1):
	context = _scale_context(employee, batch.effective_date, "Increment" in batch.run_type, increment_points)
	if (
		(frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo") == "Production"
		and not context
	):
		from karyo.payroll.prb_grade_migration import assert_employee_official_scale

		assert_employee_official_scale(employee.name)
	row = {
		"employee": employee.name,
		"employee_name": employee.employee_name,
		"include": 1,
	}
	context = context or _legacy_context(employee, "Increment" in batch.run_type, increment_points, batch.effective_date or batch.period_start)
	if not context:
		return {**row, "include": 0, "exception_code": "MISSING_GRADE_SCALE", "exception_detail": "Employee has no PRB salary point."}
	row.update(context)
	if batch.run_type == "Increment" and not context.get("increment_eligible"):
		return {
			**row,
			"include": 0,
			"increment_amount": 0,
			"calculated_total": 0,
			"final_total": None,
			"exception_code": "NOT_INCREMENT_ELIGIBLE",
			"exception_detail": _("Employee is at the top of the approved scale or has a flat salary."),
		}
	salary_basis = context["increment_base"]
	increment = 0
	if "Increment" in batch.run_type:
		new_salary = context["proposed_salary"]
		increment = context["increment_amount"]
		salary_basis = new_salary
	row["salary_basis"] = salary_basis
	row["increment_amount"] = increment
	compensation = 0
	if "Compensation" in batch.run_type:
		result = calculate_compensation(
			batch.compensation_scheme,
			salary_basis,
			batch.effective_date,
			employee=employee.name,
			company=batch.company,
		)
		compensation = result["compensation_amount"]
	row["compensation_amount"] = compensation
	eoy_amount = 0
	if batch.run_type == "EOY Bonus":
		denominator = _day_basis(batch)
		joined = max(getdate(employee.date_of_joining), getdate(batch.period_start))
		service_end = min(
			getdate(batch.period_end),
			getdate(employee.relieving_date) if employee.relieving_date else getdate(batch.period_end),
		)
		service_days = max(0, date_diff(service_end, joined) + 1)
		lwp = _lwp_days(employee.name, batch.period_start, batch.period_end)
		eligible_days = max(0, service_days - lwp)
		row.update(
			{
				"lwp_days": lwp,
				"service_days": eligible_days,
				"day_count_denominator": denominator,
			}
		)
		eoy_amount = eoy_bonus(salary_basis, service_days=eligible_days) * 365 / denominator
		eoy_amount = round(eoy_amount, 2)
	row["eoy_amount"] = eoy_amount
	row["calculated_total"] = increment + compensation + eoy_amount
	row["final_total"] = None
	return row


def _override_active(row):
	return bool(row.get("override_enabled") or flt(row.get("override_amount")))


def _final_amount(row, run_type):
	if not _override_active(row):
		return flt(row.calculated_total)
	if "Increment" in run_type:
		return flt(row.override_amount) + flt(row.compensation_amount) + flt(row.eoy_amount)
	return flt(row.override_amount)


def _set_totals(batch):
	included = [row for row in batch.lines if row.include and not row.exception_code]
	for row in included:
		# Final is an override result, not a duplicate of Calculated. Keep it
		# blank until payroll explicitly enters an override.
		row.final_total = _final_amount(row, batch.run_type) if _override_active(row) else None
	batch.employee_count = len(included)
	batch.exception_count = sum(1 for row in batch.lines if row.exception_code)
	batch.calculated_total = sum(flt(row.calculated_total) for row in included)
	batch.approved_total = sum(_final_amount(row, batch.run_type) for row in included)


@frappe.whitelist()
def calculate_run(name):
	batch = frappe.get_doc("Bulk Payroll Run", name)
	batch.check_permission("write")
	if batch.status not in ("Draft", "Calculated"):
		frappe.throw(_("Only Draft or Calculated runs can be recalculated."))
	selected = [row.employee for row in batch.lines if row.employee]
	increment_points = {row.employee: max(1, cint(row.get("increment_steps") or 1)) for row in batch.lines if row.employee}
	if not selected:
		frappe.throw(_("Select at least one employee for this payroll run."))
	employees = _employees(batch)
	if not employees:
		frappe.throw(_("None of the selected employees is eligible for this payroll run."))
	batch.set("lines", [])
	for employee in employees:
		try:
			batch.append("lines", _calculate_employee(batch, employee, increment_points.get(employee.name, 1)))
		except Exception as exc:
			batch.append(
				"lines",
				{
					"employee": employee.name,
					"employee_name": employee.employee_name,
					"include": 0,
					"exception_code": "CALCULATION_ERROR",
					"exception_detail": str(exc),
				},
			)
	_set_totals(batch)
	batch.status = "Calculated"
	batch.calculated_on = now_datetime()
	batch.save()
	return {"run": batch.name, "employees": batch.employee_count, "exceptions": batch.exception_count, "total": batch.calculated_total}


@frappe.whitelist()
def approve_run(name):
	batch = frappe.get_doc("Bulk Payroll Run", name)
	batch.check_permission("write")
	from karyo.payroll.governance import has_actor_role
	if frappe.session.user != "Administrator" and "System Manager" not in frappe.get_roles() and not has_actor_role("approver"):
		frappe.throw(_("Not permitted to approve bulk payroll runs."), frappe.PermissionError)
	if batch.status != "Calculated":
		frappe.throw(_("Only a Calculated run can be approved."))
	_set_totals(batch)
	if not batch.employee_count:
		frappe.throw(_("Select at least one calculated employee before approving the run."))
	if any(row.include and row.exception_code for row in batch.lines):
		frappe.throw(_("Included employees have unresolved exceptions."))
	batch.status = "Approved"
	batch.approved_by = frappe.session.user
	batch.approved_on = now_datetime()
	batch.save()
	return batch.name


def _post_compensation(batch, row):
	pdb_code = batch.pdb_code
	component = frappe.db.get_value("Payroll PDB Code", pdb_code, "salary_component")
	amount = flt(row.compensation_amount)
	if _override_active(row) and "Increment" not in batch.run_type:
		amount += flt(row.override_amount) - flt(row.calculated_total)
	if not amount:
		return None
	doc = frappe.get_doc(
		{
			"doctype": "Additional Salary",
			"employee": row.employee,
			"company": batch.company,
			"salary_component": component,
			"amount": amount,
			"payroll_date": batch.effective_date,
			"overwrite_salary_structure_amount": 0,
			"ref_doctype": batch.doctype,
			"ref_docname": batch.name,
			"karyo_transaction_category": "Bulk Payroll",
			"karyo_payroll_cycle": batch.payroll_cycle,
		}
	).insert(ignore_permissions=True)
	doc.submit()
	return doc.name


def _post_eoy(batch, row):
	component = frappe.db.get_value("Payroll PDB Code", batch.pdb_code, "salary_component")
	doc = frappe.get_doc(
		{
			"doctype": "EOY Bonus",
			"employee": row.employee,
			"year": getdate(batch.period_end).year,
			"case": "Pro-rata Service",
			"monthly_salary": row.salary_basis,
			"service_days": row.service_days,
			"day_count_denominator": row.day_count_denominator,
			"pdb_component": component,
			"bulk_payroll_run": batch.name,
			"bulk_override_amount": row.override_amount,
			"bulk_override_enabled": int(_override_active(row)),
			"payroll_cycle": batch.payroll_cycle,
			"payroll_date": batch.effective_date,
		}
	).insert(ignore_permissions=True)
	doc.submit()
	return doc.name


def _apply_increment(batch, row):
	"""Apply the calculated next point without letting a money override change it."""
	if not row.proposed_salary_point or row.proposed_salary_point == row.original_salary_point:
		return None
	if not row.salary_appointment:
		if getdate(batch.effective_date) > getdate():
			frappe.throw(_("Create an approved salary appointment before scheduling a future increment for employee {0}.").format(row.employee))
		from karyo.setup.payroll_profiles import prb_salary_value

		frappe.db.set_value("Employee", row.employee, {
			"karyo_prb_salary_point": row.proposed_salary_point,
			"karyo_prb_row3_salary": prb_salary_value(row.proposed_salary_point, effective_date=getdate()) or 0,
		})
		from karyo.payroll.employee_salary_workspace import sync_base_from_prb_point

		sync_base_from_prb_point(row.employee, row.proposed_salary_point, batch.effective_date)
		return None
	current = frappe.get_doc("Employee Salary Appointment", row.salary_appointment)
	if getdate(batch.effective_date) <= getdate(current.effective_from):
		frappe.throw(
			_("Increment effective date must be after the current salary appointment start for employee {0}.").format(
				row.employee
			)
		)
	previous_end = current.effective_to
	current.effective_to = add_days(batch.effective_date, -1)
	current.flags.ignore_permissions = True
	current.flags.prb_revision_closing = True
	current.save()
	appointment = frappe.get_doc({
		"doctype": "Employee Salary Appointment",
		"employee": row.employee,
		"appointment_type": "Salary Change",
		"pay_basis": current.pay_basis,
		"grade": current.grade,
		"prb_grade": current.prb_grade,
		"prb_salary_point": row.proposed_salary_point if current.pay_basis == "PRB" else None,
		"prb_year": current.prb_year,
		"salary_structure": current.salary_structure,
		"income_tax_slab": current.income_tax_slab,
		"effective_from": batch.effective_date,
		"effective_to": previous_end,
		"salary_point": row.proposed_salary_point,
		"authority_reference": batch.name,
		"notes": _("Applied from approved bulk increment {0}.").format(batch.name),
	}).insert(ignore_permissions=True)
	appointment.flags.ignore_permissions = True
	appointment.submit()
	return appointment.name


@frappe.whitelist()
def apply_run(name):
	frappe.db.sql("select name from `tabBulk Payroll Run` where name=%s for update", (name,))
	batch = frappe.get_doc("Bulk Payroll Run", name)
	batch.check_permission("write")
	if batch.status == "Applied":
		return {"run": batch.name, "already_applied": True, "total": batch.applied_total}
	if batch.status != "Approved":
		frappe.throw(_("Only an Approved run can be applied."))
	if "Increment" in batch.run_type:
		# Serialize awards and reject a calculation made against salary history
		# which another approved run has since changed.
		for employee in sorted({row.employee for row in batch.lines if row.include and not row.exception_code}):
			frappe.db.sql("select name from `tabEmployee` where name=%s for update", (employee,))
		for row in batch.lines:
			if not row.include or row.exception_code:
				continue
			context = _calculate_employee(batch, frappe.get_doc("Employee", row.employee), row.increment_steps)
			if any(str(context.get(field) or "") != str(row.get(field) or "") for field in (
				"salary_appointment", "original_salary_point", "proposed_salary_point",
			)) or abs(flt(context.get("increment_amount")) - flt(row.increment_amount)) > .005:
				frappe.throw(_("Salary history has changed for employee {0}. Create and calculate a new increment run.").format(row.employee))
	applied_total = 0
	for row in batch.lines:
		if not row.include or row.exception_code:
			continue
		if "Increment" in batch.run_type and row.proposed_salary_point:
			row.db_set("salary_appointment", _apply_increment(batch, row), update_modified=False)
		if "Compensation" in batch.run_type:
			row.db_set("compensation_additional_salary", _post_compensation(batch, row), update_modified=False)
		if batch.run_type == "EOY Bonus":
			row.db_set("eoy_bonus", _post_eoy(batch, row), update_modified=False)
		applied_total += _final_amount(row, batch.run_type)
	batch.db_set(
		{
			"status": "Applied",
			"applied_by": frappe.session.user,
			"applied_on": now_datetime(),
			"applied_total": applied_total,
			"reconciliation_difference": applied_total - flt(batch.approved_total),
		},
		update_modified=False,
	)
	return {"run": batch.name, "already_applied": False, "total": applied_total}
