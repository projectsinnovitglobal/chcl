frappe.query_reports["PB Bank Balance Listing"] = {
	filters: [
		{fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company", default: frappe.defaults.get_user_default("Company")},
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
	],
};
