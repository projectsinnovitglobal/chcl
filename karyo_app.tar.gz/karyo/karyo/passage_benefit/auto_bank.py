"""Catch up missing PB banks once the shared eligibility rules are satisfied."""

import frappe
from frappe.utils import getdate, today

from karyo.passage_benefit.eligibility import evaluate


def _candidates():
	return frappe.get_all("Employee", filters={"status": "Active", "pb_eligible": 1},
		pluck="name", order_by="name asc", limit_page_length=0)


def create_due_banks():
	"""Hourly scheduler job; never exposed as an employee-callable API.

	Use today's effective eligibility rules and a zero opening balance. Existing
	banks (including manually opened or closed ones) are never replaced. Lock the
	employee while creating so concurrent scheduled executions cannot duplicate it.
	"""
	frappe.only_for("System Manager")
	as_on = getdate(today())
	result = {"created": [], "skipped": [], "failed": []}
	for employee in _candidates():
		savepoint = "pb_auto_bank"
		frappe.db.savepoint(savepoint)
		try:
			frappe.db.sql("SELECT name FROM `tabEmployee` WHERE name=%s FOR UPDATE", employee)
			if frappe.db.exists("Passage Benefit Bank", employee):
				result["skipped"].append(employee)
				continue
			eligibility = evaluate(employee, as_on)
			if not eligibility.eligible or not eligibility.eligible_from_date or getdate(eligibility.eligible_from_date) > as_on:
				result["skipped"].append(employee)
				continue
			# Starting on the day all current conditions pass also avoids applying a
			# superseded historical parameter version to a newly opened bank.
			bank = frappe.get_doc({"doctype": "Passage Benefit Bank", "employee": employee,
				"opening_date": as_on, "opening_balance": 0})
			bank.insert(ignore_permissions=True)
			bank.add_comment("Info", "Automatically opened after Passage Benefit eligibility checks passed. Opening balance: 0.")
			result["created"].append(bank.name)
		except Exception:
			frappe.db.rollback(save_point=savepoint)
			result["failed"].append(employee)
			frappe.log_error(title="Automatic PB Bank creation failed", message=frappe.get_traceback())
	return result
