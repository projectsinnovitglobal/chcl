"""Karyo Loan — eligibility conditions reference (Phase 0).

    bench --site dev.localhost execute karyo.setup.loan_conditions.setup

Creates the Loan Condition DocType (BR-FAR-LMS-REF-014..016), adds the
`enforce_loan_conditions` toggle to Karyo Settings so the check can be run as a
blocking or non-blocking validation (REF-016 / VAL-FAR-007), and provides an
importer that expands a client SICOM-style age x term-column insurance matrix
into the effective-dated Loan Insurance Rate band rows the engine reads.

`seed_sample_reference()` seeds clearly-labelled sample loan types, insurance
rates, recomputation parameters and conditions matching the client prototype.
Real values are client deliverables (OI-FAR-001/006). Idempotent.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype

# Insurance term columns -> month ranges (BR-FAR-LMS-REF-009). The client
# confirms final ranges; these mirror the "2-4 years / 5-8 years" style bands.
TERM_BANDS = [(0, 48), (49, 96), (97, 144), (145, 192), (193, 600)]


def create_condition_doctype():
	# Loan eligibility conditions (BR-FAR-LMS-REF-014).
	make_doctype(
		"Loan Condition",
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="LC-.#####", default="LC-.#####"),
			f("loan_type", "Link", "Loan Type", options="Loan Type", reqd=1, in_list_view=1),
			f("salary_from", "Currency", "Salary From", in_list_view=1),
			f("salary_to", "Currency", "Salary To (blank = no upper bound)", in_list_view=1),
			f("cb1", "Column Break"),
			f("max_salary", "Currency", "Maximum Salary (cap for loan sizing)"),
			f("max_duration_months", "Int", "Maximum Duration (Months)", in_list_view=1),
			f("first_loan_only", "Check", "First Loan Only"),
			f("valid_sb", "Section Break", "Validity"),
			f("start_date", "Date", "Start Date"),
			f("end_date", "Date", "End Date"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("cb2", "Column Break"),
			f("remarks", "Small Text", "Remarks"),
		],
	)


def add_settings_toggle():
	governed_doctypes = (
		"Loan Type",
		"Loan Condition",
		"Loan Insurance Rate",
		"Loan Operation Code",
		"Loan Recomputation Parameter",
	)
	governance_fields = {}
	for doctype in governed_doctypes:
		meta = frappe.get_meta(doctype)
		insert_after = "end_date" if meta.has_field("end_date") else meta.fields[-1].fieldname
		governance_fields[doctype] = [
			{"fieldname": "governance_sb", "fieldtype": "Section Break", "label": "Configuration Governance", "insert_after": insert_after},
			{"fieldname": "configuration_status", "fieldtype": "Select", "label": "Configuration Status", "options": "Demo\nDraft\nValidated\nApproved\nActive\nSuperseded\nRetired", "default": "Demo", "in_list_view": 1, "insert_after": "governance_sb"},
			{"fieldname": "configuration_version", "fieldtype": "Data", "label": "Version", "default": "1.0", "insert_after": "configuration_status"},
			{"fieldname": "is_production_eligible", "fieldtype": "Check", "label": "Approved for Production", "default": "0", "insert_after": "configuration_version"},
			{"fieldname": "source_reference", "fieldtype": "Data", "label": "Source Reference", "insert_after": "is_production_eligible"},
			{"fieldname": "approval_reference", "fieldtype": "Data", "label": "Approval Reference", "insert_after": "source_reference"},
			{"fieldname": "governance_cb", "fieldtype": "Column Break", "insert_after": "approval_reference"},
			{"fieldname": "approved_by", "fieldtype": "Link", "label": "Approved By", "options": "User", "read_only": 1, "insert_after": "governance_cb"},
			{"fieldname": "approved_on", "fieldtype": "Datetime", "label": "Approved On", "read_only": 1, "insert_after": "approved_by"},
		]
	create_custom_fields(
		governance_fields | {
			"Loan Insurance Rate": governance_fields["Loan Insurance Rate"] + [
				{"fieldname": "provider", "fieldtype": "Data", "label": "Insurance Provider", "insert_after": "threshold"},
				{"fieldname": "policy_reference", "fieldtype": "Data", "label": "Provider Policy / Rate Reference", "insert_after": "provider"},
			],
			"Karyo Settings": [
				{
					"fieldname": "enforce_loan_conditions",
					"fieldtype": "Check",
					"label": "Enforce Loan Conditions (block on no match)",
					"insert_after": "max_deduction_pct",
					"description": (
						"When on, a loan without a matching active Loan Condition is blocked "
						"(VAL-FAR-007). When off, eligibility validation is skipped (REF-016)."
					),
				}
			]
		},
		ignore_validate=True,
	)
	print("  + loan governance fields and enforce_loan_conditions toggle ensured")


def import_insurance_matrix(rows, effective_date, threshold=0, term_bands=None):
	"""Expand a client age x term-column insurance matrix into Loan Insurance Rate
	band rows the engine reads (get_insurance_rate). Each `row` is
	(loan_code, age, [term1_rate, term2_rate, ...]); a blank/zero column is
	skipped. Idempotent on (loan_code, age, term band, effective_date)."""
	bands = term_bands or TERM_BANDS
	created = 0
	for loan_code, age, term_rates in rows:
		for (lo, hi), rate in zip(bands, term_rates, strict=False):
			if not rate:
				continue
			exists = frappe.db.exists(
				"Loan Insurance Rate",
				{
					"loan_code": loan_code,
					"min_age": age,
					"max_age": age,
					"min_term_months": lo,
					"max_term_months": hi,
					"effective_date": effective_date,
				},
			)
			if exists:
				continue
			frappe.get_doc(
				{
					"doctype": "Loan Insurance Rate",
					"loan_code": loan_code,
					"min_age": age,
					"max_age": age,
					"min_term_months": lo,
					"max_term_months": hi,
					"rate": rate,
					"effective_date": effective_date,
					"threshold": threshold,
				}
			).insert(ignore_permissions=True)
			created += 1
	print(f"  + imported {created} insurance rate band row(s)")
	return created


# --- Sample reference data (clearly labelled; client-confirmed values pending) --

SAMPLE_NOTE = "Sample — replace with client-confirmed values (OI-FAR-001)."

SAMPLE_LOAN_TYPES = [
	# code, name, category, rate, max_amount, max_period, insurance_required, threshold, lien
	("PERS", "Personal Loan", "Personal", 6.0, 250000, 84, 1, 10000, 0),
	("MED2", "Medical Loan - 3.5%", "Medical", 3.5, 75000, 60, 0, 0, 0),
	("NMPL", "Multipurpose Loan - 6%", "Multipurpose", 6.0, 300000, 96, 1, 10000, 0),
	("MOTO1", "Motorcycle Loan", "Motorcycle", 6.0, 200000, 84, 1, 10000, 1),
	("CAR", "Car Loan", "Motor Vehicle", 6.0, 800000, 120, 1, 25000, 1),
]

SAMPLE_INSURANCE_MATRIX = [
	("ALL", 18, [28.96, 29.65, 31.10]),
	("ALL", 19, [30.50, 30.50, 32.15]),
	("ALL", 38, [28.96, 28.96, 30.00]),
	("PERS", 38, [28.96, 28.96, 30.00]),
]

SAMPLE_CONDITIONS = [
	# loan_type, salary_from, salary_to, max_salary, max_duration, first_loan_only
	("PERS", 0, 75000, 75000, 84, 0),
	("MED2", 0, 50000, 50000, 60, 0),
	("NMPL", 0, 100000, 100000, 96, 0),
]


def seed_sample_reference():
	"""Seed labelled sample loan types, insurance rates, recomputation params and
	conditions matching the client prototype. Idempotent."""
	for code, name, cat, rate, maxa, maxp, ins, thr, lien in SAMPLE_LOAN_TYPES:
		if frappe.db.exists("Loan Type", code):
			continue
		doc = frappe.get_doc(
			{
				"doctype": "Loan Type",
				"loan_code": code,
				"loan_name": name,
				"loan_category": cat,
				"interest_rate": rate,
				"max_amount": maxa,
				"max_period_months": maxp,
				"is_active": 1,
				"insurance_required": ins,
				"insurance_threshold": thr,
				"start_date": "2025-01-01",
			}
		)
		# custom field added by loan_lien.setup; guard in case order changes.
		if doc.meta.has_field("lien_required"):
			doc.lien_required = lien
		doc.insert(ignore_permissions=True)

	import_insurance_matrix(SAMPLE_INSURANCE_MATRIX, "2026-01-01", threshold=10000)

	# Default recast cap of 5% for all loan types (matches the worked example).
	if not frappe.db.exists("Loan Recomputation Parameter", {"function": "RECAST", "loan_type": ""}):
		frappe.get_doc(
			{
				"doctype": "Loan Recomputation Parameter",
				"function": "RECAST",
				"value": 5,
				"start_date": "2025-01-01",
				"is_active": 1,
				"remarks": SAMPLE_NOTE,
			}
		).insert(ignore_permissions=True)

	for lt, sf, st, ms, md, first in SAMPLE_CONDITIONS:
		if frappe.db.exists("Loan Condition", {"loan_type": lt, "salary_from": sf}):
			continue
		frappe.get_doc(
			{
				"doctype": "Loan Condition",
				"loan_type": lt,
				"salary_from": sf,
				"salary_to": st,
				"max_salary": ms,
				"max_duration_months": md,
				"first_loan_only": first,
				"start_date": "2025-01-01",
				"is_active": 1,
				"remarks": SAMPLE_NOTE,
			}
		).insert(ignore_permissions=True)
	print("  + sample loan reference data seeded")


def setup():
	print("Karyo Loan conditions setup:")
	create_condition_doctype()
	add_settings_toggle()
	frappe.db.commit()
	print("Done.")
