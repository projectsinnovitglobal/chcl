"""Remaining PRB DocTypes: Vacation Leave (Bank + Posting), PRB Rule Version
registry (PRB-01), and PRB Grade Scale (Volume 2 structure, PRB-17).

    bench --site dev.localhost execute karyo.setup.prb_extra.setup
"""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_vacation_leave():
	make_doctype(
		"Vacation Leave Bank",
		autoname="field:employee",
		naming_rule="By fieldname",
		title_field="employee_name",
		fields=[
			f("employee", "Link", "Employee Code", options="Employee", reqd=1, unique=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("status", "Select", "Status", options="Active\nInactive", default="Active"),
			f("allotted_days", "Float", "Allotted", read_only=1, in_list_view=1),
			f("taken_days", "Float", "Taken", read_only=1, in_list_view=1),
			f("available_days", "Float", "Available", read_only=1, in_list_view=1),
			f("cb", "Column Break"),
			f("opening_balance_days", "Float", "Opening Balance (days)"),
			f("balance_days", "Float", "Balance (days)", read_only=1),
			f("ceiling_days", "Int", "Ceiling (days)", read_only=1),
		],
	)
	make_doctype(
		"Vacation Leave Posting",
		is_submittable=1,
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="VLP-.YYYY.-.#####", default="VLP-.YYYY.-.#####"),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("vacation_leave_bank", "Link", "Vacation Leave Bank", options="Vacation Leave Bank"),
			f("year", "Int", "Year", reqd=1, in_list_view=1),
			f("hcb", "Column Break"),
			f("length_of_service_years", "Float", "Length of Service (years)", reqd=1),
			f("eligible_ratio", "Float", "Eligible Service Ratio", default="1"),
			f("taken_days", "Float", "Days Taken"),
			f("res_sb", "Section Break", "Result"),
			f("opening_balance_days", "Float", "Opening Balance (days)", read_only=1),
			f("annual_accrual_days", "Int", "Annual Band (days)", read_only=1),
			f("accrual_days", "Float", "Accrued (days)", read_only=1),
			f("rcb", "Column Break"),
			f("ceiling_days", "Int", "Ceiling (days)", read_only=1),
			f("closing_balance_days", "Float", "Closing Balance (days)", read_only=1, in_list_view=1),
		],
	)


def create_rule_version():
	make_doctype(
		"PRB Rule Version",
		fields=[
			f("rule_group", "Data", "Rule Group", reqd=1, in_list_view=1),
			f("source_reference", "Data", "Source Reference", in_list_view=1),
			f("addendum_version", "Data", "Addendum Version"),
			f("cb", "Column Break"),
			f("effective_from", "Date", "Effective From", reqd=1, in_list_view=1),
			f("effective_to", "Date", "Effective To"),
			f("priority", "Int", "Priority", default="0"),
			f("status", "Select", "Status", options="Active\nSuperseded", default="Active", in_list_view=1),
		],
	)


def create_grade_scale():
	make_doctype(
		"PRB Grade Scale",
		autoname="field:grade_id",
		naming_rule="By fieldname",
		fields=[
			f("grade_id", "Data", "Grade", reqd=1, unique=1, in_list_view=1),
			f("organisation", "Data", "Organisation", in_list_view=1),
			f(
				"sector",
				"Select",
				"Sector",
				options="\nCivil Service\nParastatal\nLocal Authority\nRodrigues",
			),
			f("volume_part", "Data", "Volume 2 Part"),
			f("cb", "Column Break"),
			f("initial_point", "Data", "Initial Salary Point"),
			f("top_point", "Data", "Top Salary Point"),
			f("qualification_bar_point", "Data", "Qualification Bar Point"),
			f("flat_salary", "Currency", "Flat Salary"),
			f("is_flat_salary", "Check", "Is Flat Salary"),
		],
	)


SAMPLE_GRADE_SCALES = [
	# grade, organisation, sector, initial_pt, top_pt, qual_bar, part
	("CS-GENERAL-WORKER", "Ministry of Civil Service", "Civil Service", "003", "030", "", "Part I"),
	("CS-OFFICE-ATTENDANT", "Ministry of Civil Service", "Civil Service", "015", "045", "", "Part I"),
	("CS-CLERICAL-OFFICER", "Ministry of Civil Service", "Civil Service", "020", "060", "", "Part I"),
	("CS-EXECUTIVE-OFFICER", "Ministry of Civil Service", "Civil Service", "060", "089", "075", "Part I"),
	("CS-HIGHER-EXECUTIVE", "Ministry of Civil Service", "Civil Service", "075", "096", "", "Part I"),
	("CS-PRINCIPAL-OFFICER", "Ministry of Civil Service", "Civil Service", "089", "105", "", "Part I"),
	("CS-ASST-SECRETARY", "Ministry of Civil Service", "Civil Service", "096", "112", "", "Part I"),
	("CS-PERMANENT-SECRETARY", "Ministry of Civil Service", "Civil Service", "112", "116", "", "Part I"),
	("HEALTH-NURSING-OFFICER", "Ministry of Health", "Civil Service", "055", "085", "070", "Part I"),
	("HEALTH-MEDICAL-OFFICER", "Ministry of Health", "Civil Service", "085", "108", "", "Part I"),
	("EDU-PRIMARY-EDUCATOR", "Ministry of Education", "Civil Service", "050", "082", "", "Part I"),
	("EDU-SECONDARY-EDUCATOR", "Ministry of Education", "Civil Service", "062", "092", "078", "Part I"),
	("POLICE-CONSTABLE", "Police Force", "Civil Service", "035", "070", "", "Part I"),
	("POLICE-INSPECTOR", "Police Force", "Civil Service", "072", "098", "", "Part I"),
	("PARA-TECHNICIAN", "Sample Parastatal Body", "Parastatal", "040", "080", "", "Part II"),
	("PARA-ENGINEER", "Sample Parastatal Body", "Parastatal", "085", "110", "", "Part II"),
	("LA-SUPERVISOR", "Sample Local Authority", "Local Authority", "035", "072", "", "Part III"),
	("LA-CHIEF-INSPECTOR", "Sample Local Authority", "Local Authority", "072", "095", "", "Part III"),
	("ROD-FIELD-OFFICER", "Rodrigues Regional Assembly", "Rodrigues", "030", "065", "", "Part IV"),
]


def seed_sample_grade_scales():
	"""SAMPLE / dummy Volume 2 grade scales so PRB Grade Scale is demoable.
	Replace with official PRB Volume 2 data before production (PRB-17)."""
	created = 0
	for grade, org, sector, init, top, bar, part in SAMPLE_GRADE_SCALES:
		if frappe.db.exists("PRB Grade Scale", grade):
			continue
		frappe.get_doc(
			{
				"doctype": "PRB Grade Scale",
				"grade_id": grade,
				"organisation": org,
				"sector": sector,
				"volume_part": part,
				"initial_point": init,
				"top_point": top,
				"qualification_bar_point": bar or None,
				"data_origin": "Demo",
				"is_active": 0,
				"source_reference": "SAMPLE / DUMMY — not approved for production",
			}
		).insert(ignore_permissions=True)
		created += 1
	print(f"  + seeded {created} SAMPLE grade scales (dummy — replace with official Volume 2)")


def setup():
	print("Karyo PRB extra setup:")
	create_vacation_leave()
	create_rule_version()
	create_grade_scale()
	frappe.db.commit()
	print("Done.")
