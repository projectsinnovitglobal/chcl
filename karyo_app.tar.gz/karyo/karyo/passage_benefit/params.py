"""Effective-dated Passage Benefit parameter resolution (PB-GEN-003, PB-PAR-003).

Policy values (accrual %, salary basis, thresholds, operation codes, rounding,
leap-year treatment) may change over time. Rather than editing core logic, HR
maintains dated versions in `Passage Benefit Settings.parameter_versions`; the
computation resolves the version in force on its period-end date so historical
computations keep the values that were effective when they ran (GEN-005).

`resolve(as_on)` returns a frappe._dict that behaves like the Settings doc — the
live Single fields are the base, overlaid by the effective version's non-blank
values. With no versions configured it is just the Single, so behaviour is
unchanged until HR opts into versioning.
"""

import frappe
from frappe import _
from frappe.utils import getdate

from karyo.payroll.configuration import assert_production_eligible

# Fields a version may override. Non-blank version values win over the Single.
VERSIONED_FIELDS = (
	"pb_percentage",
	"salary_basis",
	"min_years_service",
	"min_salary_threshold",
	"eligibility_mode",
	"require_confirmation",
	"require_permanent_employee",
	"leap_year_treatment",
	"rounding_stage",
	"entitlement_operation_code",
	"adjustment_operation_code",
	"payroll_pdb_type",
	"payroll_pdb_code",
	"pdb_salary_component",
)


def resolve(as_on=None):
	"""Return effective PB parameters as at `as_on` (a frappe._dict)."""
	settings = frappe.get_cached_doc("Passage Benefit Settings")
	mode = frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo"
	if mode == "Production":
		if not settings.get("configuration_version"):
			frappe.throw(_("An approved Passage Benefit configuration is required in Production."))
		configuration = assert_production_eligible(settings.configuration_version)
		if configuration.configuration_type != "Passage Benefit Rules":
			frappe.throw(_("Passage Benefit Settings must reference a Passage Benefit Rules configuration."))
	params = frappe._dict(settings.as_dict())
	params["parameter_version"] = None

	versions = settings.get("parameter_versions") or []
	if not versions or not as_on:
		return params

	as_on = getdate(as_on)
	effective = [
		v for v in versions
		if v.effective_from
		and getdate(v.effective_from) <= as_on
		and (not v.effective_to or as_on <= getdate(v.effective_to))
	]
	if not effective:
		return params
	chosen = max(effective, key=lambda v: getdate(v.effective_from))
	for field in VERSIONED_FIELDS:
		value = chosen.get(field)
		if value not in (None, ""):
			params[field] = value
	params["parameter_version"] = chosen.item_sequence or chosen.effective_from
	return params


def validate_required(
	params, *, for_payroll=False, require_entitlement=True, as_on=None, company=None
):
	"""Block a PB computation/processing path when its mandatory setup is incomplete."""
	required = {}
	if require_entitlement:
		required.update({
			"pb_percentage": _("Passage Benefit percentage"),
			"salary_basis": _("Salary Basis"),
			"entitlement_operation_code": _("Operation Code for Entitlement / Salary Basis"),
		})
	if for_payroll:
		required.update({
			"payroll_pdb_type": _("Payroll PDB Type"),
			"payroll_pdb_code": _("Payroll PDB Code"),
		})
	missing = [label for fieldname, label in required.items() if params.get(fieldname) in (None, "", 0)]
	if missing:
		frappe.throw(_("Passage Benefit setup is incomplete. Configure: {0}.").format(", ".join(missing)))

	# A previously approved redemption already carries its authoritative claimable
	# amount. Processing it needs the payroll mapping, not the earning/accrual rule
	# that originally funded the bank.
	if not require_entitlement:
		return params

	operation = frappe.db.get_value(
		"Payroll Operation Code", params.entitlement_operation_code,
		["is_active", "effective_from", "effective_to"], as_dict=True,
	)
	if not operation or not operation.is_active:
		frappe.throw(_("The configured Passage Benefit entitlement operation code is missing or inactive."))
	if as_on:
		as_on = getdate(as_on)
		if getdate(operation.effective_from) > as_on or (
			operation.effective_to and getdate(operation.effective_to) < as_on
		):
			frappe.throw(_("The configured Passage Benefit entitlement operation code is not effective on {0}.").format(as_on))
	# Passage Benefit Settings is global, so its salary-basis operation is also a
	# global policy reference. A company on the operation limits payroll-cycle use,
	# but must not make the global PB policy unusable for every other company.
	return params
