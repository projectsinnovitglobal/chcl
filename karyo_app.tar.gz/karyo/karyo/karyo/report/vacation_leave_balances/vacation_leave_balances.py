from calendar import isleap

import frappe
from frappe import _
from frappe.utils import cint, date_diff, flt, getdate


def execute(filters=None):
	filters = frappe._dict(filters or {})
	year = cint(filters.get("year")) or frappe.utils.now_datetime().year
	conditions, values = ["1=1"], {"year": year}
	for field, expression in (
		("company", "e.company"), ("department", "e.department"),
		("employee", "b.employee"), ("status", "b.status"),
	):
		if filters.get(field):
			conditions.append(f"{expression} = %({field})s")
			values[field] = filters.get(field)
	rows = frappe.db.sql(
		f"""
		select b.employee, b.employee_name, e.company, e.department, e.date_of_joining,
			b.status, b.opening_balance_days as bank_opening, b.allotted_days,
			b.taken_days as bank_taken, b.balance_days as bank_balance, b.ceiling_days as bank_ceiling,
			p.name as posting, p.length_of_service_years, p.eligible_ratio,
			p.opening_balance_days, p.annual_accrual_days, p.accrual_days,
			p.taken_days, p.ceiling_days, p.closing_balance_days
		from `tabVacation Leave Bank` b
		inner join `tabEmployee` e on e.name = b.employee
		left join `tabVacation Leave Posting` p on p.name = (
			select p2.name from `tabVacation Leave Posting` p2
			where p2.employee = b.employee and p2.year = %(year)s and p2.docstatus = 1
			order by p2.creation desc limit 1
		)
		where {' and '.join(conditions)}
		order by b.employee_name, b.employee
		""",
		values,
		as_dict=True,
	)
	bands = sorted(
		frappe.get_all("MBC Vacation Leave Band", filters={"parent": "MBC Leave Settings"},
			fields=["service_from_years", "service_to_years", "annual_entitlement_days", "accumulation_ceiling_days"]),
		key=lambda row: flt(row.service_from_years),
	)
	for row in rows:
		service = flt(row.length_of_service_years)
		if not row.posting and row.date_of_joining:
			service = max(0, date_diff(f"{year}-12-31", getdate(row.date_of_joining)) / 365.25)
		band = _band_for(service, bands)
		row.update({
			"year": year,
			"length_of_service_years": round(service, 2),
			"service_band": _band_label(band),
			"opening_balance_days": flt(row.opening_balance_days if row.posting else row.bank_opening),
			"annual_accrual_days": flt(row.annual_accrual_days if row.posting else (band.annual_entitlement_days if band else row.allotted_days)),
			"eligible_ratio": flt(row.eligible_ratio) if row.posting else 1,
			"accrual_days": flt(row.accrual_days if row.posting else row.allotted_days),
			"taken_days": flt(row.taken_days if row.posting else row.bank_taken),
			"ceiling_days": flt(row.ceiling_days if row.posting else (band.accumulation_ceiling_days if band else row.bank_ceiling)),
			"closing_balance_days": flt(row.closing_balance_days if row.posting else row.bank_balance),
		})
		row.daily_accrual_days = round(row.annual_accrual_days / (366 if isleap(year) else 365), 6)
	return _columns(), rows


def _band_for(service, bands):
	return next((row for row in bands if service >= flt(row.service_from_years)
		and (not flt(row.service_to_years) or service < flt(row.service_to_years))), None)


def _band_label(band):
	if not band:
		return _("Not configured")
	start, end = flt(band.service_from_years), flt(band.service_to_years)
	return _("{0}+ years").format(start) if not end else _("{0} to under {1} years").format(start, end)


def _columns():
	return [
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 135},
		{"fieldname": "employee_name", "label": _("Employee Name"), "width": 180},
		{"fieldname": "company", "label": _("Company"), "fieldtype": "Link", "options": "Company", "width": 110},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 140},
		{"fieldname": "year", "label": _("Year"), "fieldtype": "Int", "width": 70},
		{"fieldname": "length_of_service_years", "label": _("Service (Years)"), "fieldtype": "Float", "width": 110},
		{"fieldname": "service_band", "label": _("Service Band"), "width": 155},
		{"fieldname": "opening_balance_days", "label": _("Opening Balance"), "fieldtype": "Float", "width": 115},
		{"fieldname": "annual_accrual_days", "label": _("Earned Basis (Band)"), "fieldtype": "Float", "width": 135},
		{"fieldname": "daily_accrual_days", "label": _("Earned per Day"), "fieldtype": "Float", "precision": 6, "width": 115},
		{"fieldname": "eligible_ratio", "label": _("Eligible Service Ratio"), "fieldtype": "Float", "width": 130},
		{"fieldname": "accrual_days", "label": _("Earned"), "fieldtype": "Float", "width": 90},
		{"fieldname": "taken_days", "label": _("Taken"), "fieldtype": "Float", "width": 85},
		{"fieldname": "ceiling_days", "label": _("Ceiling Based on Service"), "fieldtype": "Float", "width": 160},
		{"fieldname": "closing_balance_days", "label": _("Closing Balance"), "fieldtype": "Float", "width": 115},
		{"fieldname": "status", "label": _("Status"), "width": 85},
		{"fieldname": "posting", "label": _("Year-end Posting"), "fieldtype": "Link", "options": "Vacation Leave Posting", "width": 150},
	]
