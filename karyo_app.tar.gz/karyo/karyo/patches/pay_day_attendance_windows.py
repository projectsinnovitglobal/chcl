"""Correct untouched future Major Pay Days to recurring cut-off windows."""

from datetime import timedelta

import frappe
from frappe.utils import get_first_day, get_last_day, getdate

from karyo.setup.payroll_calendar import pay_window_for_month


def _work_days(company, start_date, end_date):
	holiday_list = frappe.db.get_value("Company", company, "default_holiday_list")
	holidays = set()
	if holiday_list:
		holidays = {
			getdate(value)
			for value in frappe.get_all(
				"Holiday",
				filters={"parent": holiday_list, "holiday_date": ("between", [start_date, end_date])},
				pluck="holiday_date",
			)
		}
	return sum(
		1
		for offset in range((end_date - start_date).days + 1)
		if (day := start_date + timedelta(days=offset)) not in holidays
		and (holiday_list or day.weekday() < 5)
	)


def execute():
	"""Migrate generated, unprocessed rows that retain the old calendar-month shape."""
	rows = frappe.get_all(
		"Payroll Pay Day",
		filters={
			"payroll_type": "Major",
			"status": ("in", ["Planned", "Active"]),
			"source_reference": "Generated calendar — review before activation",
		},
		fields=["name", "company", "pay_day_master", "start_date", "end_date", "payment_date"],
	)
	for row in rows:
		payment_date = getdate(row.payment_date)
		day_of_month = frappe.db.get_value("Pay Day", row.pay_day_master, "day_of_month")
		if (
			not day_of_month
			or getdate(row.start_date) != get_first_day(payment_date)
			or getdate(row.end_date) != get_last_day(payment_date)
			or frappe.db.exists("Payroll Cycle", {"pay_day": row.name, "docstatus": ("<", 2)})
		):
			continue
		start_date, end_date, payment_date = pay_window_for_month(payment_date, day_of_month)
		frappe.db.set_value(
			"Payroll Pay Day",
			row.name,
			{
				"start_date": start_date,
				"end_date": end_date,
				"payment_date": payment_date,
				"work_days": _work_days(row.company, start_date, end_date),
			},
			update_modified=False,
		)
