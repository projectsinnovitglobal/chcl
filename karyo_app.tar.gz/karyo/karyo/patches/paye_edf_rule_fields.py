"""Backfill explicit PAYE sequencing and EDF employment-basis fields."""

import frappe
from frappe.utils import getdate

from karyo.payroll.paye import statutory_period_index


def execute():
	for row in frappe.get_all(
		"Payroll Pay Day",
		fields=["name", "payment_date", "paye_payment_type", "paye_period_index"],
	):
		payment = getdate(row.payment_date)
		payment_type = row.paye_payment_type or "Regular Salary"
		year_start = getdate(f"{payment.year if payment.month >= 7 else payment.year - 1}-07-01")
		index = int(row.paye_period_index or 0) or statutory_period_index(payment, year_start, 13)
		if payment_type == "Prescribed Bonus - Separate":
			index = 6
		frappe.db.set_value(
			"Payroll Pay Day",
			row.name,
			{"paye_payment_type": payment_type, "paye_period_index": index},
			update_modified=False,
		)

	for cycle in frappe.get_all("Payroll Cycle", fields=["name", "pay_day"]):
		values = frappe.db.get_value(
			"Payroll Pay Day", cycle.pay_day, ["paye_payment_type", "paye_period_index"], as_dict=True
		)
		if values:
			frappe.db.set_value("Payroll Cycle", cycle.name, values, update_modified=False)

	for declaration in frappe.get_all(
		"Employee Tax Declaration",
		fields=["name", "employee", "source_opening_record", "employment_basis", "appointment_date"],
	):
		appointment = declaration.appointment_date or frappe.db.get_value(
			"Employee", declaration.employee, "date_of_joining"
		)
		basis = declaration.employment_basis
		if not basis and declaration.source_opening_record:
			first = frappe.db.get_value(
				"EDF PAYE Opening", declaration.source_opening_record, "first_employment"
			)
			basis = "First Employment" if first else "Not First Employment"
		# Legacy declarations previously used a full-year denominator.  Preserve
		# that established result rather than guessing that they were first jobs.
		basis = basis or "Not First Employment"
		frappe.db.set_value(
			"Employee Tax Declaration",
			declaration.name,
			{"appointment_date": appointment, "employment_basis": basis},
			update_modified=False,
		)
