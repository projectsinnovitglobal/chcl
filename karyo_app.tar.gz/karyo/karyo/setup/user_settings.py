"""Keep the User settings layout focused on HR account details."""

import json

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


def apply():
	meta = frappe.get_meta("User", cached=False)
	order = [field.fieldname for field in meta.fields]
	# Move the entire native password section, retaining validation and permissions.
	start = order.index("change_password")
	end = next(
		(index for index in range(start + 1, len(order))
		 if meta.get_field(order[index]).fieldtype in {"Section Break", "Tab Break"}),
		len(order),
	)
	password_fields = order[start:end]
	remaining = [field for field in order if field not in password_fields]
	target = remaining.index("roles_permissions_tab")
	new_order = remaining[:target] + password_fields + remaining[target:]
	if new_order != order:
		make_property_setter("User", None, "field_order", json.dumps(new_order), "Data", for_doctype=True)
	for fieldname in ("settings_tab", "connections_tab"):
		if not meta.get_field(fieldname).hidden:
			make_property_setter("User", fieldname, "hidden", 1, "Check")
	if meta.get_field("change_password").collapsible:
		make_property_setter("User", "change_password", "collapsible", 0, "Check")
	frappe.clear_cache(doctype="User")
