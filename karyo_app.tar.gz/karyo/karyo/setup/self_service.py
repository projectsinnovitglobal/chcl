"""Read-only, employee-scoped leave allocation access."""
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.permissions import add_permission, update_permission_property


def apply():
	create_custom_fields(
		{"Shift Request": [
			{"fieldname": "karyo_current_shift", "fieldtype": "Link", "label": "Current Shift",
				"options": "Shift Type", "read_only": 1, "insert_after": "shift_type"},
			{"fieldname": "karyo_reason", "fieldtype": "Small Text", "label": "Reason",
				"insert_after": "karyo_current_shift"},
			{"fieldname": "karyo_duration_days", "fieldtype": "Int", "label": "Duration (Days)",
				"read_only": 1, "insert_after": "to_date"},
			{"fieldname": "karyo_request_status", "fieldtype": "Select", "label": "Request Status",
				"options": "Pending Approval\nApproved\nRejected\nCancelled", "read_only": 1,
				"default": "Pending Approval", "insert_after": "status"},
		]},
		ignore_validate=True,
	)
	if not frappe.db.exists("Custom DocPerm", {"parent":"Leave Allocation","role":"Employee","permlevel":0,"if_owner":0}):
		add_permission("Leave Allocation", "Employee")
	for field in ("read", "select"):
		update_permission_property("Leave Allocation", "Employee", 0, field, 1)
	for field in ("create", "write", "delete", "submit", "cancel", "amend", "share", "export", "import"):
		update_permission_property("Leave Allocation", "Employee", 0, field, 0)
	frappe.clear_cache(doctype="Leave Allocation")

	# Currency is shared reference data needed by employee advance forms.
	if not frappe.db.exists("Custom DocPerm", {"parent":"Currency","role":"Employee","permlevel":0}):
		add_permission("Currency", "Employee", permlevel=0, ptype="select")
	frappe.clear_cache(doctype="Currency")
	frappe.clear_cache(doctype="Shift Request")
	_backfill_shift_requests()


def _backfill_shift_requests():
	"""Populate the display snapshot for requests created before these fields existed."""
	from karyo.hr.shift_change import _current_shift

	for row in frappe.get_all(
		"Shift Request",
		fields=["name", "employee", "from_date", "to_date", "status", "docstatus"],
	):
		status = (
			"Cancelled" if row.docstatus == 2 else
			row.status if row.status in ("Approved", "Rejected") else
			"Pending Approval"
		)
		values = {
			"karyo_current_shift": _current_shift(row.employee, row.from_date),
			"karyo_duration_days": max(
				1, frappe.utils.date_diff(row.to_date or row.from_date, row.from_date) + 1
			),
			"karyo_request_status": status,
		}
		frappe.db.set_value("Shift Request", row.name, values, update_modified=False)
