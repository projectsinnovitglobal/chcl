frappe.pages["tax-benefits-overview"].on_page_load = function (wrapper) {
	karyo.overview.render(wrapper, "tax-benefits-overview", {
		title: __("Tax & Benefits"),
		subtitle: __("Gratuity, settlements, tax and benefits"),
		actions: [
			{ label: __("New Gratuity"), primary: true, onclick: () => frappe.new_doc("Gratuity") },
			{ label: __("New FnF Statement"), onclick: () => frappe.new_doc("Full and Final Statement") },
		],
	});
};
