"""Versioned CSV staging for recurring and once-off PDB transactions (PAY-032)."""

import json

import frappe

from karyo.setup.foundation import f, make_doctype


TEMPLATES = {
	"Static": [
		"employee",
		"pdb_code",
		"amount",
		"calculation_method",
		"formula",
		"start_date",
		"end_date",
		"initial_balance",
		"remarks",
	],
	"Once-off": ["employee", "pdb_code", "amount", "transaction_reference", "remarks"],
}


def create_doctypes():
	make_doctype(
		"Payroll Transaction Import Template",
		autoname="format:PAY-IMPORT-{upload_type}-{version}",
		fields=[
			f("upload_type", "Select", "Upload Type", options="Static\nOnce-off", reqd=1, in_list_view=1),
			f("version", "Data", "Version", reqd=1, in_list_view=1),
			f("headers_json", "Code", "CSV Headers", options="JSON", reqd=1),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("effective_from", "Date", "Effective From", reqd=1),
			f("notes", "Small Text", "Notes"),
		],
	)
	make_doctype(
		"Payroll Transaction Import Row",
		istable=1,
		fields=[
			f("row_number", "Int", "Row", reqd=1, in_list_view=1),
			f("raw_values", "Code", "Raw Values", options="JSON", read_only=1),
			f("employee", "Data", "Employee", in_list_view=1),
			f("pdb_code", "Data", "PDB Code", in_list_view=1),
			f("amount", "Currency", "Amount", in_list_view=1),
			f("calculation_method", "Data", "Calculation Method"),
			f("formula", "Code", "Formula"),
			f("start_date", "Date", "Start Date"),
			f("end_date", "Date", "End Date"),
			f("initial_balance", "Currency", "Initial Balance"),
			f("transaction_reference", "Data", "Transaction Reference"),
			f("remarks", "Small Text", "Remarks"),
			f("business_key", "Data", "Business Key", read_only=1),
			f("status", "Select", "Status", options="Valid\nInvalid\nRejected\nPosted", in_list_view=1),
			f("validation_message", "Small Text", "Validation Message", in_list_view=1),
			f("target_doctype", "Link", "Created Type", options="DocType", read_only=1),
			f("target_name", "Dynamic Link", "Created Record", options="target_doctype", read_only=1),
		],
	)
	make_doctype(
		"Payroll Transaction Import",
		autoname="PAYIMP-.YYYY.-.#####",
		fields=[
			f("company", "Link", "Company", options="Company", reqd=1, in_list_view=1),
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1),
			f("upload_type", "Select", "Upload Type", options="Static\nOnce-off", reqd=1, in_list_view=1),
			f(
				"template_version",
				"Link",
				"Template Version",
				options="Payroll Transaction Import Template",
				reqd=1,
			),
			f("identity_cb", "Column Break"),
			f("csv_file", "Attach", "CSV File"),
			f("file_hash", "Data", "File SHA-256", read_only=1),
			f(
				"status",
				"Select",
				"Status",
				options="Uploaded\nValidated\nApproved\nPosted\nRejected",
				default="Uploaded",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f("rows_sb", "Section Break", "Staged Rows"),
			f("rows", "Table", "Rows", options="Payroll Transaction Import Row"),
			f("controls_sb", "Section Break", "Import Controls"),
			f("total_rows", "Int", "Total Rows", read_only=1),
			f("valid_rows", "Int", "Valid Rows", read_only=1),
			f("invalid_rows", "Int", "Invalid Rows", read_only=1),
			f("control_total", "Currency", "Source Control Total", read_only=1),
			f("accepted_total", "Currency", "Accepted Total", read_only=1),
			f("controls_cb", "Column Break"),
			f("approved_by", "Link", "Approved By", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
			f("posted_by", "Link", "Posted By", options="User", read_only=1),
			f("posted_on", "Datetime", "Posted On", read_only=1),
			f("generated_batch", "Link", "Generated Once-Off Batch", options="Once-Off PDB Batch", read_only=1),
			f("decision_reason", "Small Text", "Decision Reason"),
		],
	)


def seed_templates():
	for upload_type, headers in TEMPLATES.items():
		name = f"PAY-IMPORT-{upload_type}-1.0"
		if frappe.db.exists("Payroll Transaction Import Template", name):
			continue
		frappe.get_doc(
			{
				"doctype": "Payroll Transaction Import Template",
				"upload_type": upload_type,
				"version": "1.0",
				"headers_json": json.dumps(headers),
				"is_active": 1,
				"effective_from": "2026-01-01",
				"notes": "Versioned Karyo payroll transaction CSV schema.",
			}
		).insert(ignore_permissions=True)


def add_permissions():
	meta = frappe.get_doc("DocType", "Payroll Transaction Import")
	matrix = {
		"Payroll Input": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Processor": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Reviewer": {"read": 1, "write": 1, "report": 1},
		"Payroll Approver": {"read": 1, "write": 1, "report": 1},
		"Payroll Auditor": {"read": 1, "report": 1, "export": 1},
	}
	for role, values in matrix.items():
		row = next((permission for permission in meta.permissions if permission.role == role), None)
		if not row:
			row = meta.append("permissions", {"role": role})
		for fieldname, value in values.items():
			row.set(fieldname, value)
	meta.save(ignore_permissions=True)


def ensure_staging_field_types():
	meta = frappe.get_doc("DocType", "Payroll Transaction Import Row")
	changed = False
	for fieldname in ("employee", "pdb_code"):
		field = next(row for row in meta.fields if row.fieldname == fieldname)
		if field.fieldtype != "Data":
			field.fieldtype = "Data"
			field.options = None
			changed = True
	if changed:
		meta.save(ignore_permissions=True)


def setup():
	print("Karyo payroll transaction import setup:")
	create_doctypes()
	ensure_staging_field_types()
	seed_templates()
	add_permissions()
	frappe.db.commit()
	print("Done (versioned CSV templates, staging rows, and import controls created).")
