"""Align existing recurring PDB rows with the static capture terminology."""

import frappe


def execute():
	if not frappe.db.table_exists("Employee Recurring PDB"):
		return
	frappe.db.sql(
		"""update `tabEmployee Recurring PDB`
		set calculation_method = 'Fixed Monthly'
		where calculation_method = 'Fixed Amount'"""
	)
	for row in frappe.get_all(
		"Employee Recurring PDB",
		fields=["name", "pdb_type", "priority"],
		limit_page_length=0,
	):
		classification = frappe.db.get_value("Payroll PDB Type", row.pdb_type, "classification")
		transaction_type = "Deduction" if classification == "Deduction" else "Payment"
		frappe.db.set_value(
			"Employee Recurring PDB",
			row.name,
			{
				"transaction_type": transaction_type,
				"priority": max(1, int(row.priority or 1)) if transaction_type == "Deduction" else 0,
			},
			update_modified=False,
		)
