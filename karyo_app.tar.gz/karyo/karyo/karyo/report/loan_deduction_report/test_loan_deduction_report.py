from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.loan_deduction_report.loan_deduction_report import execute


class TestLoanDeductionReport(FrappeTestCase):
	@patch("karyo.karyo.report.loan_report_utils.permitted_loan_names", return_value=("LOAN-1",))
	@patch("frappe.db.sql")
	def test_submitted_allocations_have_historically_correct_reducing_balance(self, sql, _permitted):
		sql.return_value = [
			frappe._dict(loan="LOAN-1", component="Capital", posting_date="2026-01-31", amount=100,
				approved_amount=1000, total_interest=100, total_insurance=20),
			frappe._dict(loan="LOAN-1", component="Capital", posting_date="2026-02-28", amount=150,
				approved_amount=1000, total_interest=100, total_insurance=20),
		]
		_columns, rows = execute({"from_date": "2026-02-01", "to_date": "2026-02-28"})
		self.assertEqual(len(rows), 1)
		self.assertEqual(rows[0].balance_before, 900)
		self.assertEqual(rows[0].reducing_balance, 750)
		query = sql.call_args.args[0]
		self.assertIn("ss.docstatus=1", query)
		self.assertIn("a.is_reversal=0", query)

	def test_rejects_inverted_date_range(self):
		with self.assertRaises(frappe.ValidationError):
			execute({"from_date": "2026-03-01", "to_date": "2026-02-28"})

	@patch("karyo.karyo.report.loan_report_utils.permitted_loan_names", return_value=("LOAN-1",))
	@patch("frappe.db.sql")
	def test_combines_capital_interest_and_insurance_per_employee_slip(self, sql, _permitted):
		common = {
			"loan": "LOAN-1",
			"loan_type": "PERSONAL",
			"posting_date": "2026-02-28",
			"payroll_period": "February 2026",
			"payroll_cycle": "PAYC-1",
			"employee": "EMP-1",
			"employee_name": "Employee One",
			"department": "Finance",
			"location": "Head Office",
			"salary_slip": "SAL-1",
			"schedule_month": 1,
			"approved_amount": 1000,
			"total_interest": 100,
			"total_insurance": 20,
		}
		sql.return_value = [
			frappe._dict(**common, component="Capital", pdb_code="LOANC", amount=100),
			frappe._dict(**common, component="Interest", pdb_code="LOANI", amount=10),
			frappe._dict(**common, component="Insurance", pdb_code="LOANINS", amount=2),
		]
		columns, rows = execute({"payroll_cycle": "PAYC-1"})
		self.assertEqual(len(rows), 1)
		self.assertEqual(rows[0].employee, "EMP-1")
		self.assertEqual(rows[0].capital_amount, 100)
		self.assertEqual(rows[0].interest_amount, 10)
		self.assertEqual(rows[0].insurance_amount, 2)
		self.assertEqual(rows[0].total_monthly_emi, 112)
		self.assertEqual(rows[0].pdb_codes, "LOANC, LOANI, LOANINS")
		self.assertIn("total_monthly_emi", {column["fieldname"] for column in columns})
