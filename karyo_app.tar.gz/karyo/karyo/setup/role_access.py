"""MBC-only module profiles, role profiles, and enforceable capability roles."""

from __future__ import annotations

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.permissions import setup_custom_perms


ACTIVE_MODULE_DEFS = ("Karyo", "HR", "Payroll")

MODULE_DOCTYPES = {
	"People": (
		"Employee", "Employee Group", "Employee Grade", "Employment Type",
		"Employee Category", "Employee Location", "Employee Section",
		"Employee Payroll Group", "Employee Work Pattern", "Education Level",
		"Identification Document Type", "Marital Status", "Department",
		"Designation", "Branch", "Employee Transfer", "Employee Promotion",
		"Employee Separation", "Employee Grievance", "Grievance Type",
	),
	"Attendance": (
		"Attendance", "Attendance Request", "Employee Checkin", "Shift Type",
		"Shift Location", "Shift Assignment", "Shift Request", "Shift Schedule",
		"Shift Schedule Assignment", "Holiday List", "Daily Work Summary",
		"Daily Work Summary Group",
	),
	"Leave": (
		"Leave Application", "Leave Allocation", "Leave Type", "Leave Category",
		"Leave Period", "Leave Policy", "Leave Policy Assignment", "Leave Block List",
		"Leave Encashment", "Leave Ledger Entry", "Compensatory Leave Request",
		"MBC Leave Settings", "Leave Opening Balance", "Leave Balance", "Leave Transaction", "Sick Leave Bank",
		"Sick Leave Bank Posting", "Vacation Leave Bank", "Vacation Leave Posting",
	),
	"Passage Benefits": (
		"Passage Benefit Application", "Passage Benefit Adjustment",
		"Passage Benefit Bank", "Passage Benefit Computation",
		"Passage Benefit Computation Run", "Passage Benefit Ledger Entry",
		"Passage Benefit Not Earned Period", "Passage Benefit Settings",
		"Passage Benefit Usage Item",
	),
	"Payroll": (
		"Salary Component", "Salary Structure", "Salary Structure Assignment",
		"Salary Slip", "Additional Salary", "Payroll Entry", "Payroll Period",
		"Payroll Settings", "Karyo Payroll Settings", "Payroll Cycle",
		"Payroll Readiness Exception", "Payroll Transaction Allocation",
		"Payroll Transaction Import", "Payroll Transaction Import Template",
		"Payroll Source Trace", "Payroll Statutory Result", "Payroll Type",
		"Payroll Operation Code", "Payroll PDB Code", "Payroll PDB Type",
		"Payroll PAYE Year", "Payroll Contribution Scheme", "Payroll Compensation Scheme",
		"Payroll Bank Branch", "Pay Day", "Payroll Pay Day", "Income Tax Slab",
		"Employee Tax Declaration", "Employee Tax Exemption Category",
		"Employee Tax Exemption Sub Category", "Employee Tax Exemption Declaration",
		"Employee Tax Exemption Proof Submission", "Employee Recurring PDB",
		"Once-Off PDB Batch", "Exceptional Payroll Batch", "EDF PAYE Opening",
		"EOY Bonus", "PRB Payroll Run", "PRB Payroll Settings", "PRB Salary Point",
		"PRB Grade Scale", "PRB Grade Scale Dataset", "PRB Rule Version",
		"PRB Payroll Component Mapping", "Salary Scale", "Salary Scale Step",
		"Salary Increment Band", "Salary Job Family", "Employee Salary Appointment",
	),
	"Loan Reports": (
		"Karyo Loan", "Karyo Loan Recast", "Karyo Loan Settlement",
		"Karyo Loan Correction", "Karyo Loan Insurance Change",
		"Karyo Loan Interest Change", "Karyo Loan Ledger Entry",
		"Karyo Loan History", "Karyo Loan Payroll Allocation",
		"Karyo Loan Disbursement Event", "Loan Service Request", "Loan Type",
		"Loan Condition", "Loan Policy Rule", "Employee Loan Eligibility Group",
		"Loan Approval Authority", "Loan Document Requirement", "Loan Insurance Rate",
		"Loan Operation Code", "Loan Recomputation Parameter", "Loan Accounting Mapping",
	),
	"Administration": (
		"User", "Role", "Role Profile", "Module Profile", "System Settings",
		"Global Defaults", "Document Naming Settings", "Email Account", "Email Template",
		"Email Queue", "Print Format", "Workflow", "Workflow State",
		"Workflow Action Master", "Notification", "Karyo Role Delegation",
		"Karyo AI Settings", "MBC Integration Profile", "MBC Integration Event",
		"MBC Migration Batch",
	),
}

ACTION_RIGHTS = {
	"View": {"read": 1, "select": 1, "report": 1, "export": 1, "print": 1},
	"Edit": {
		"read": 1, "select": 1, "write": 1, "create": 1, "submit": 1,
		"import": 1, "email": 1, "share": 1,
	},
	"Delete": {"read": 1, "select": 1, "delete": 1, "cancel": 1, "amend": 1},
}

PROFILE_NAMES = tuple(MODULE_DOCTYPES)


def capability_role(module: str, action: str) -> str:
	return f"MBC {module} {action}"


def all_capability_roles() -> tuple[str, ...]:
	return tuple(
		capability_role(module, action)
		for module in MODULE_DOCTYPES
		for action in ACTION_RIGHTS
	)


def _ensure_role(name: str):
	if frappe.db.exists("Role", name):
		frappe.db.set_value("Role", name, {"disabled": 0, "desk_access": 1}, update_modified=False)
		return
	frappe.get_doc(
		{
			"doctype": "Role",
			"role_name": name,
			"desk_access": 1,
			"is_custom": 1,
		}
	).insert(ignore_permissions=True)


def _ensure_permission(doctype: str, role: str, rights: dict[str, int]):
	# A Custom DocPerm set replaces the standard table for its parent. Frappe's
	# supported setup helper copies the complete standard table before we add an
	# MBC row, preserving all existing permissions.
	setup_custom_perms(doctype)
	filters = {
		"parent": doctype,
		"role": role,
		"permlevel": 0,
		"if_owner": 0,
	}
	names = frappe.get_all("Custom DocPerm", filters=filters, pluck="name", order_by="creation asc")
	name = names[0] if names else None
	for duplicate in names[1:]:
		frappe.delete_doc("Custom DocPerm", duplicate, ignore_permissions=True, force=True)
	values = {
		"read": 0, "write": 0, "create": 0, "delete": 0, "submit": 0,
		"cancel": 0, "amend": 0, "report": 0, "export": 0, "import": 0,
		"share": 0, "print": 0, "email": 0, "select": 0,
		**rights,
	}
	if name:
		frappe.db.set_value("Custom DocPerm", name, values, update_modified=False)
	else:
		frappe.get_doc({"doctype": "Custom DocPerm", **filters, **values}).insert(
			ignore_permissions=True
		)


def configure_capability_permissions():
	for module, doctypes in MODULE_DOCTYPES.items():
		for action, rights in ACTION_RIGHTS.items():
			role = capability_role(module, action)
			_ensure_role(role)
			for doctype in doctypes:
				if not frappe.db.exists("DocType", doctype):
					continue
				meta = frappe.get_meta(doctype)
				if meta.istable:
					continue
				_ensure_permission(doctype, role, rights)
				frappe.clear_cache(doctype=doctype)


def seed_role_profiles():
	"""Create the seven requested starting profiles without overwriting user edits."""
	for module in PROFILE_NAMES:
		if frappe.db.exists("Role Profile", module):
			continue
		frappe.get_doc(
			{
				"doctype": "Role Profile",
				"role_profile": module,
				"roles": [{"role": capability_role(module, "View")}],
			}
		).insert(ignore_permissions=True)


def validate_role_profile(doc, method=None):
	"""Reject hidden/default roles from profiles even when saved through the API."""
	allowed = set(all_capability_roles()) | {
		"HR User", "HR Manager", "Employee", "Employee Self Service", "Registry Officer",
		"Leave Approver", "Passage Benefit Officer", "Karyo Finance", "Payroll Finance",
		"Payroll Input", "Payroll Processor", "Payroll Reviewer", "Payroll Approver",
		"Payroll Auditor", "Loan Applicant", "Loan Officer", "Loan Approver",
		"Karyo Loan Committee", "Loan Configuration Administrator", "Loan Auditor",
		"Prepared Report User", "Report Manager", "System Manager", "Karyo IT Support",
		"Integration Manager", "Data Migration Manager", "Dashboard Manager", "Script Manager",
	}
	seen = set()
	filtered = []
	for row in doc.get("roles", []):
		if row.role in allowed and row.role not in seen:
			seen.add(row.role)
			filtered.append(row)
	doc.set("roles", filtered)


def prepare_module_profile(doc, method=None):
	"""Keep implementation modules blocked even though they are absent from the editor."""
	all_modules = set(frappe.get_all("Module Def", pluck="name"))
	blocked = {row.module for row in doc.get("block_modules", [])}
	for module in sorted(all_modules - set(ACTIVE_MODULE_DEFS) - blocked):
		doc.append("block_modules", {"module": module})


def apply_metadata():
	make_property_setter("User", "short_bio", "hidden", 1, "Check")
	make_property_setter("Role", None, "sort_field", "disabled", "Data", for_doctype=True)
	make_property_setter("Role", None, "sort_order", "ASC", "Data", for_doctype=True)
	frappe.clear_cache(doctype="User")
	frappe.clear_cache(doctype="Role")


def setup():
	configure_capability_permissions()
	seed_role_profiles()
	apply_metadata()
	frappe.clear_cache(doctype="Role Profile")
	frappe.clear_cache(doctype="Module Profile")
	frappe.db.commit()
