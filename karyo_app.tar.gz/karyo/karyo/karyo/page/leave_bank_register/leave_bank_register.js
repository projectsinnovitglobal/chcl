frappe.pages["leave-bank-register"].on_page_load = function (wrapper) {
	const $body = karyo.pages.scaffold(wrapper, {
		title: __("Leave Bank"),
		subtitle: __("Employee allocations, usage and remaining leave"),
	});
	wrapper.leave_bank_body = $body;
};

frappe.pages["leave-bank-register"].on_page_show = async function (wrapper) {
	const key = frappe.get_route()[1] || "casual";
	const expectedRoute = frappe.get_route().join("/");
	const load = async () => {
		const $body = wrapper.leave_bank_body;
		try {
			const data = await frappe.xcall("karyo.hr.self_service.leave_bank_register", { bank_key: key });
			if (frappe.get_route().join("/") !== expectedRoute) return;
			$body.empty();
			wrapper.page.set_title(__(data.title));
			wrapper.page.main.find(".karyo-page-title, .karyo-crumb-current").text(__(data.title));
			wrapper.page.main.find(".karyo-page-subtitle").text(
				__("Employee allocations and balances as at {0}", [frappe.datetime.str_to_user(data.as_of)])
			);
			const number = karyo.pages.leave_days;
			karyo.pages.stats($body, [
				{ label: __("Employees"), value: data.summary.employees, sub: __("with this leave bank"), icon: "users", icon_color: "blue" },
				{ label: __("Allocated"), value: number(data.summary.allocated), sub: __("days"), icon: "calendar-plus", icon_color: "blue" },
				{ label: __("Taken"), value: number(data.summary.taken), sub: __("days"), icon: "calendar-minus", icon_color: "orange" },
				{ label: __("Remaining"), value: number(data.summary.remaining), sub: __("days"), icon: "calendar-check", icon_color: "green" },
			]);
			const rows = data.rows.map(row => ({
				leave_code: row.leave_code || "—",
				leave_type: row.leave_type,
				employee: row.employee,
				employee_name: row.employee_name,
				period: `${frappe.datetime.str_to_user(row.from_date)} – ${frappe.datetime.str_to_user(row.to_date)}`,
				allocated: number(row.allocated),
				taken: number(row.taken),
				pending: number(row.pending),
				expired: number(row.expired),
				remaining: number(row.remaining),
				depends_on: row.depends_on || "—",
			}));
			karyo.pages.table(
				karyo.pages.grid($body, 1),
				{ title: __(data.title), subtitle: __("Leave codes: {0}", [data.codes.join(", ")]) },
				[
					{ label: __("Leave Code"), field: "leave_code" },
					{ label: __("Leave Type / Category"), field: "leave_type" },
					{ label: __("Employee Code"), field: "employee" },
					{ label: __("Employee Name"), field: "employee_name" },
					{ label: __("Allocation Period"), field: "period" },
					{ label: __("Leave Allocated"), field: "allocated" },
					{ label: __("Taken"), field: "taken" },
					{ label: __("Pending"), field: "pending" },
					{ label: __("Expired"), field: "expired" },
					{ label: __("Remaining"), field: "remaining" },
					{ label: __("Depends on / deducts from"), field: "depends_on" },
				],
				rows,
				{ empty: __("No employees currently have this leave bank assigned.") }
			);
			if (data.assumption) {
				$("<small class=\"karyo-bank-assumption\">").text(__(data.assumption)).appendTo($body);
			}
		} catch (error) {
			if (frappe.get_route().join("/") !== expectedRoute) return;
			$body.empty();
			karyo.pages.empty_state($body, { title: __("Could not load this leave bank") });
			throw error;
		}
	};
	return karyo.live.watch(`leave-bank-register:${key}`, load, [
		"Leave Balance", "Leave Transaction", "Leave Allocation", "Leave Application",
		"Leave Ledger Entry", "Sick Leave Bank", "Sick Leave Bank Posting",
		"Vacation Leave Bank", "Vacation Leave Posting",
	])(true);
};
