"""PAY-CALC-001..017 payroll computation chain from the MBC control sheet.

The pure functions in this module are the calculation contract.  The Salary
Slip adapter classifies approved rows through their governed PDB masters and
stores a reproducible parallel-run trace without replacing HRMS source rows.
"""

import json
from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal

import frappe
from frappe.utils import flt, getdate

from karyo.payroll.paye import (
	calculate_cumulative_paye,
	cumulative_declaration_deduction,
	get_effective_paye_year,
	get_employee_tax_declaration,
	progressive_tax,
	statutory_period_index,
)


RULE_IDS = tuple(f"PAY-CALC-{number:03d}" for number in range(1, 18))


def _decimal(value):
	return Decimal(str(value or 0))


def _money(value, precision=2):
	return float(_decimal(value).quantize(Decimal("1").scaleb(-precision), rounding=ROUND_HALF_UP))


def _non_negative(value, label):
	value = _decimal(value)
	if value < 0:
		raise ValueError(f"{label} cannot be negative")
	return value


def gross_pay(payment_amounts, precision=2):
	"""PAY-CALC-001: sum all approved payment components."""
	return _money(sum((_decimal(value) for value in payment_amounts), Decimal("0")), precision)


def monthly_taxable_emolument(component_amounts, precision=2):
	"""PAY-CALC-002: sum approved taxable core/PAYE-basis components."""
	return _money(sum((_decimal(value) for value in component_amounts), Decimal("0")), precision)


def current_gross_emoluments(monthly_taxable, taxable_travelling=0, taxable_benefits=0, precision=2):
	"""PAY-CALC-003: taxable emolument + taxable travelling + benefits."""
	return _money(_decimal(monthly_taxable) + _decimal(taxable_travelling) + _decimal(taxable_benefits), precision)


def total_emoluments(current_gross, previous_emoluments=0, precision=2):
	"""PAY-CALC-004: current gross emoluments + previous emoluments."""
	return _money(_decimal(current_gross) + _decimal(previous_emoluments), precision)


def monthly_iet(edf_amount, period_index, periods_per_year=13, precision=2):
	"""PAY-CALC-005: EDF amount / 13 × months (PAYE periods) reached."""
	periods = int(periods_per_year)
	index = int(period_index)
	if periods < 1 or index < 1 or index > periods:
		raise ValueError("PAYE period index is outside the configured income year")
	return _money(_non_negative(edf_amount, "EDF amount") / periods * index, precision)


def chargeable_income(emoluments, iet, precision=2):
	"""PAY-CALC-006: total emoluments less the allowed cumulative IET."""
	return _money(max(Decimal("0"), _decimal(emoluments) - _decimal(iet)), precision)


def net_paye_payable(
	chargeable,
	*,
	bands=None,
	band_factor=1,
	flat_rate=None,
	precision=2,
	band_boundary_rounding="Exact Fraction",
):
	"""PAY-CALC-007: tax rate(s) × chargeable income."""
	chargeable = _non_negative(chargeable, "chargeable income")
	if flat_rate is not None:
		return _money(chargeable * _non_negative(flat_rate, "tax rate") / 100, precision)
	if not bands:
		raise ValueError("tax bands are required when no flat rate is supplied")
	return _money(
		progressive_tax(
			chargeable, bands, precision, band_factor, band_boundary_rounding
		)["tax"],
		precision,
	)


def paye_for_period(cumulative_paye, previous_paye=0, precision=2):
	"""PAY-CALC-008: cumulative net PAYE payable less PAYE already paid."""
	return _money(max(Decimal("0"), _decimal(cumulative_paye) - _decimal(previous_paye)), precision)


def total_employee_deductions(other_deductions, paye=0, precision=2):
	"""PAY-CALC-009: PAYE plus contributions, loans and other deductions."""
	return _money(
		sum((_decimal(value) for value in other_deductions), Decimal("0")) + _decimal(paye),
		precision,
	)


def net_pay(gross, deductions, precision=2):
	"""PAY-CALC-010: gross pay less total employee deductions."""
	return _money(_decimal(gross) - _decimal(deductions), precision)


def employer_cost(gross, employer_contributions=0, precision=2):
	"""PAY-CALC-011: gross pay plus employer contributions."""
	return _money(_decimal(gross) + _decimal(employer_contributions), precision)


def hourly_rate(salary_basis, divisor, precision=6):
	"""PAY-CALC-012: validated GSAL basis divided by its governed divisor."""
	divisor = _decimal(divisor)
	if divisor <= 0:
		raise ValueError("hourly-rate divisor must be greater than zero")
	return _money(_non_negative(salary_basis, "salary basis") / divisor, precision)


def overtime_payment(rate, approved_hours, multiplier, precision=2):
	"""PAY-CALC-013: hourly rate × approved hours × overtime multiplier."""
	return _money(
		_non_negative(rate, "hourly rate")
		* _non_negative(approved_hours, "approved overtime hours")
		* _non_negative(multiplier, "overtime multiplier"),
		precision,
	)


def acting_allowance(
	salary_difference,
	increment_based_amount,
	applicable_percentage=100,
	proration_ratio=1,
	precision=2,
):
	"""PAY-CALC-014: higher basis × percentage × applicable-period ratio."""
	basis = max(
		_non_negative(salary_difference, "salary difference"),
		_non_negative(increment_based_amount, "increment-based amount"),
	)
	percentage = _non_negative(applicable_percentage, "applicable percentage")
	ratio = _non_negative(proration_ratio, "proration ratio")
	if percentage > 100 or ratio > 1:
		raise ValueError("acting allowance percentage/ratio cannot exceed 100% of the selected basis")
	return _money(basis * percentage / 100 * ratio, precision)


def lwp_deduction(salary_basis, lwp_days, divisor, precision=2):
	"""PAY-CALC-015: salary basis × LWP days / configured divisor."""
	divisor = _decimal(divisor)
	if divisor <= 0:
		raise ValueError("LWP divisor must be greater than zero")
	return _money(
		_non_negative(salary_basis, "salary basis") * _non_negative(lwp_days, "LWP days") / divisor,
		precision,
	)


def sick_leave_refund(payable_days, salary_basis, day_divisor, precision=2):
	"""PAY-CALC-016: payable sick-bank days × salary basis/day divisor."""
	return lwp_deduction(salary_basis, payable_days, day_divisor, precision)


def eoy_bonus(salary_basis, eligible_service_days, service_day_divisor=365, precision=2):
	"""PAY-CALC-017: configured salary basis × eligible service-day ratio."""
	divisor = _decimal(service_day_divisor)
	if divisor <= 0:
		raise ValueError("EOY service-day divisor must be greater than zero")
	return _money(
		_non_negative(salary_basis, "EOY salary basis")
		* _non_negative(eligible_service_days, "eligible service days")
		/ divisor,
		precision,
	)


def calculate_payroll_chain(
	*,
	payment_amounts,
	taxable_core_amounts,
	taxable_travelling=0,
	taxable_benefits=0,
	previous_emoluments=0,
	edf_amount=0,
	period_index=1,
	periods_per_year=13,
	tax_bands=None,
	tax_band_factor=1,
	no_edf_rate=None,
	previous_paye=0,
	other_deductions=(),
	employer_contributions=0,
	precision=2,
	tax_precision=None,
	cumulative_iet=None,
	band_boundary_rounding="Exact Fraction",
	no_paye_threshold=0,
	threshold_applies=True,
):
	"""Calculate PAY-CALC-001..011 as one deterministic, auditable chain."""
	gross = gross_pay(payment_amounts, precision)
	monthly_taxable = monthly_taxable_emolument(taxable_core_amounts, precision)
	current_gross = current_gross_emoluments(
		monthly_taxable, taxable_travelling, taxable_benefits, precision
	)
	cumulative_emoluments = total_emoluments(current_gross, previous_emoluments, precision)
	iet = (
		_money(cumulative_iet, precision)
		if cumulative_iet is not None
		else monthly_iet(edf_amount, period_index, periods_per_year, precision)
	)
	chargeable = chargeable_income(cumulative_emoluments, iet, precision)
	tax_basis = current_gross if no_edf_rate is not None else chargeable
	cumulative_tax = net_paye_payable(
		tax_basis,
		bands=tax_bands,
		band_factor=tax_band_factor,
		flat_rate=no_edf_rate,
		precision=precision if tax_precision is None else tax_precision,
		band_boundary_rounding=band_boundary_rounding,
	)
	current_paye = (
		cumulative_tax
		if no_edf_rate is not None
		else paye_for_period(cumulative_tax, previous_paye, precision)
	)
	if (
		threshold_applies
		and _decimal(no_paye_threshold) > 0
		and _decimal(current_gross) <= _decimal(no_paye_threshold)
	):
		current_paye = 0.0
	deductions = total_employee_deductions(other_deductions, current_paye, precision)
	return {
		"gross_pay": gross,
		"monthly_taxable_emolument": monthly_taxable,
		"taxable_travelling": _money(taxable_travelling, precision),
		"taxable_benefits": _money(taxable_benefits, precision),
		"current_gross_emoluments": current_gross,
		"previous_emoluments": _money(previous_emoluments, precision),
		"total_emoluments": cumulative_emoluments,
		"monthly_iet": iet,
		"chargeable_income": chargeable,
		"net_paye_payable": cumulative_tax,
		"previous_paye": _money(previous_paye, precision),
		"paye": current_paye,
		"total_employee_deductions": deductions,
		"net_pay": net_pay(gross, deductions, precision),
		"employer_contributions": _money(employer_contributions, precision),
		"employer_cost": employer_cost(gross, employer_contributions, precision),
		"rule_references": list(RULE_IDS[:11]),
	}


def _component_classification(slip):
	components = list(
		dict.fromkeys(row.salary_component for row in [*slip.earnings, *slip.deductions] if row.salary_component)
	)
	if not components:
		return {}
	rows = frappe.get_all(
		"Payroll PDB Code",
		filters={"salary_component": ("in", components), "is_active": 1},
		fields=["pdb_code", "pdb_type", "salary_component", "description", "taxable"],
	)
	type_classifications = {
		row.pdb_type: row.classification
		for row in frappe.get_all(
			"Payroll PDB Type", filters={"pdb_type": ("in", list({row.pdb_type for row in rows}))},
			fields=["pdb_type", "classification"],
		)
	}
	return {
		row.salary_component: {
			"pdb_code": row.pdb_code,
			"pdb_type": row.pdb_type,
			"classification": type_classifications.get(row.pdb_type),
			"description": row.description,
			"taxable": bool(row.taxable),
		}
		for row in rows
	}


def _emolument_bucket(metadata, salary_component=None):
	"""Return the PAY-CALC-002/003 bucket for one taxable PDB."""
	description = " ".join(
		str(value or "")
		for value in (metadata.get("description"), salary_component)
	).lower()
	travel_terms = ("trav", "mileage", "transport", "petrol allowance", "car allowance", "taxi")
	benefit_terms = ("benefit", "medical allowance", "housing", "accommodation")
	if metadata.get("pdb_type") == "TRV" or any(term in description for term in travel_terms):
		return "taxable_travelling"
	if metadata.get("classification") == "Benefit" or any(term in description for term in benefit_terms):
		return "taxable_benefits"
	return "monthly_taxable_emolument"


def _salary_slip_payment_date(slip):
	cycle = slip.get("karyo_payroll_cycle")
	payment_date = frappe.db.get_value("Payroll Cycle", cycle, "payment_date") if cycle else None
	return getdate(payment_date or slip.end_date or slip.posting_date)


def _paye_operation_pdb_codes(slip):
	"""Return effective PAYE-operation members, or None when no governed mapping applies."""
	if not frappe.db.exists("Payroll Operation Code", "PAYE"):
		return None
	doc = frappe.get_doc("Payroll Operation Code", "PAYE")
	on_date = _salary_slip_payment_date(slip)
	if (
		not doc.is_active
		or getdate(doc.effective_from) > on_date
		or (doc.effective_to and getdate(doc.effective_to) < on_date)
		or (doc.company and doc.company != slip.company)
	):
		return None
	return {
		row.pdb_code
		for row in doc.items
		if getdate(row.effective_from or doc.effective_from) <= on_date
		and not (
			(row.effective_to or doc.effective_to)
			and getdate(row.effective_to or doc.effective_to) < on_date
		)
	}


def _current_component_amounts(slip):
	metadata = _component_classification(slip)
	paye_operation_pdb_codes = _paye_operation_pdb_codes(slip)
	payments = []
	core = []
	travel = benefits = 0.0
	other_deductions = []
	paye_component = frappe.db.get_value(
		"Payroll PDB Code", {"pdb_code": "PAYE", "is_active": 1}, "salary_component"
	)
	component_trace = []
	for row in slip.earnings:
		if row.statistical_component:
			continue
		amount = flt(row.amount)
		payments.append(amount)
		meta = metadata.get(row.salary_component, {})
		taxable = bool(meta.get("taxable") or row.is_tax_applicable)
		bucket = "non_taxable"
		if taxable:
			bucket = _emolument_bucket(meta, row.salary_component)
			if bucket == "taxable_travelling":
				travel += amount
			elif bucket == "taxable_benefits":
				benefits += amount
			elif paye_operation_pdb_codes is not None and meta.get("pdb_code") not in paye_operation_pdb_codes:
				bucket = "taxable_outside_paye_operation"
			else:
				core.append(amount)
		component_trace.append({
			"salary_component": row.salary_component,
			"pdb_code": meta.get("pdb_code"),
			"amount": amount,
			"bucket": bucket,
		})
	for row in slip.deductions:
		if not row.statistical_component and row.salary_component != paye_component:
			other_deductions.append(flt(row.amount))
	return {
		"payments": payments,
		"taxable_core": core,
		"taxable_travelling": travel,
		"taxable_benefits": benefits,
		"other_deductions": other_deductions,
		"paye_component": paye_component,
		"component_trace": component_trace,
		"tax_basis_mode": (
			"PAYE Operation Code" if paye_operation_pdb_codes is not None else "Taxable PDB Fallback"
		),
	}


def _prior_payroll_values(slip, year, paye_component, include_current_month=False):
	prior_rows = frappe.get_all(
		"Salary Slip",
		filters={
			"name": ("!=", slip.name or ""),
			"employee": slip.employee,
			"company": slip.company,
			"docstatus": 1,
			"start_date": (">=", year.effective_from),
			"end_date": ("<=", slip.end_date or slip.posting_date),
		},
		fields=["name", "end_date", "posting_date", "karyo_payroll_cycle", "creation", "karyo_computation_trace"],
	)
	# Minor and Major runs can share the same month-end. Their payment sequence,
	# not only end_date, decides what is already withheld. This ensures a Major
	# run includes an earlier Minor run while a recalculated Minor run cannot
	# accidentally include a later Major payroll.
	current_end = getdate(slip.end_date or slip.posting_date)
	current_cycle = slip.get("karyo_payroll_cycle")
	current_payment = frappe.db.get_value("Payroll Cycle", current_cycle, "payment_date") if current_cycle else None
	cycle_names = [row.karyo_payroll_cycle for row in prior_rows if row.karyo_payroll_cycle]
	cycle_dates = dict(frappe.get_all(
		"Payroll Cycle", filters={"name": ("in", cycle_names or [""])},
		fields=["name", "payment_date"], as_list=True,
	)) if cycle_names else {}
	prior_slips = []
	month_slips = []
	for row in prior_rows:
		row_end = getdate(row.end_date or row.posting_date)
		if row_end < current_end:
			prior_slips.append(row.name)
			if (row_end.year, row_end.month) == (current_end.year, current_end.month):
				month_slips.append(row.name)
			continue
		prior_payment = cycle_dates.get(row.karyo_payroll_cycle) or row.posting_date
		if current_payment and prior_payment and getdate(prior_payment) < getdate(current_payment):
			prior_slips.append(row.name)
			month_slips.append(row.name)
	if not prior_slips:
		return (0.0,) * 6 if include_current_month else (0.0, 0.0)
	previous_emoluments = flt(frappe.db.get_value(
		"Salary Detail",
		{
			"parent": ("in", prior_slips), "parenttype": "Salary Slip", "parentfield": "earnings",
			"is_tax_applicable": 1, "statistical_component": 0,
		},
		"sum(amount)",
	))
	previous_paye = flt(frappe.db.get_value(
		"Salary Detail",
		{
			"parent": ("in", prior_slips), "parenttype": "Salary Slip", "parentfield": "deductions",
			"salary_component": paye_component,
		},
		"sum(amount)",
	)) if paye_component else 0.0
	if not include_current_month:
		return previous_emoluments, previous_paye
	month_emoluments = month_paye = 0.0
	if month_slips:
		month_emoluments = flt(frappe.db.get_value("Salary Detail", {
			"parent": ("in", month_slips), "parenttype": "Salary Slip", "parentfield": "earnings",
			"is_tax_applicable": 1, "statistical_component": 0,
		}, "sum(amount)"))
		month_paye = flt(frappe.db.get_value("Salary Detail", {
			"parent": ("in", month_slips), "parenttype": "Salary Slip", "parentfield": "deductions",
			"salary_component": paye_component,
		}, "sum(amount)")) if paye_component else 0.0
	prior_fsc = month_fsc = 0.0
	for row in prior_rows:
		if row.name not in prior_slips or not row.karyo_computation_trace:
			continue
		trace = json.loads(row.karyo_computation_trace)
		paid = flt(trace.get("fair_share_withheld"))
		prior_fsc += paid
		if row.name in month_slips:
			month_fsc += paid
	return previous_emoluments, previous_paye, month_emoluments, month_paye, prior_fsc, month_fsc


def _salary_slip_paye_period(slip, year):
	"""Resolve the explicit cycle position, falling back to the guide calendar."""
	cycle = slip.get("karyo_payroll_cycle")
	if cycle:
		configured = frappe.db.get_value("Payroll Cycle", cycle, "paye_period_index")
		if configured:
			return int(configured)
	return statutory_period_index(
		_salary_slip_payment_date(slip), year.effective_from, year.periods_per_year
	)


def _december_bonus_period_index(period_index, payment_type, on_date, periods_per_year=13):
	"""Resolve PAYE position 6 (separate bonus) or 7 (combined December)."""
	if getdate(on_date).month != 12 or int(periods_per_year or 0) != 13:
		return int(period_index)
	if payment_type == "Prescribed Bonus - Separate":
		return 6
	return max(int(period_index), 7)


def _december_bonus_iet(declaration, year, on_date, eoy_bonus_amount):
	"""Return the prescribed-bonus IET instalment used only in December.

	For a 13-position PAYE year, position 6 is the bonus position between
	November (5) and regular December (7).  A combined December payroll reaches
	both positions, but the extra instalment is identified separately for audit.
	"""
	if (
		getdate(on_date).month != 12
		or not flt(eoy_bonus_amount)
		or int(year.periods_per_year or 0) != 13
		or not declaration
		or declaration.declaration_status != "Submitted"
	):
		return 0.0
	before_bonus = cumulative_declaration_deduction(declaration, year, 5)
	through_bonus = cumulative_declaration_deduction(declaration, year, 6)
	return max(0.0, flt(through_bonus) - flt(before_bonus))


def salary_slip_computation(slip, employer_contributions=0):
	"""Build the full control-sheet calculation from one calculated Salary Slip."""
	on_date = _salary_slip_payment_date(slip)
	year = get_effective_paye_year(on_date, slip.company)
	declaration = get_employee_tax_declaration(slip.employee, year.name, on_date)
	current = _current_component_amounts(slip)
	eoy_bonus_amount = sum(
		flt(row["amount"])
		for row in current["component_trace"]
		if row.get("pdb_code") == "EOY" or row.get("salary_component") == "EOY Bonus"
	)
	previous_emoluments, previous_paye, month_emoluments, month_paye, prior_fsc, month_fsc = _prior_payroll_values(
		slip, year, current["paye_component"], include_current_month=True
	)
	period_index = _salary_slip_paye_period(slip, year)
	if eoy_bonus_amount and on_date.month == 12 and int(year.periods_per_year or 0) == 13:
		payment_type = None
		if slip.get("karyo_payroll_cycle"):
			payment_type = frappe.db.get_value(
				"Payroll Cycle", slip.karyo_payroll_cycle, "paye_payment_type"
			)
		period_index = _december_bonus_period_index(
			period_index, payment_type, on_date, year.periods_per_year
		)
	prior_employment_emoluments = flt(declaration.prior_employment_emoluments) if declaration else 0
	prior_employment_paye = flt(declaration.prior_employment_paye) if declaration else 0
	edf_submitted = bool(declaration and declaration.declaration_status == "Submitted")
	edf_amount = flt(declaration.annual_iet) + flt(declaration.annual_reliefs) if edf_submitted else 0
	cumulative_iet = cumulative_declaration_deduction(declaration, year, period_index)
	bonus_iet = _december_bonus_iet(declaration, year, on_date, eoy_bonus_amount)
	director_or_board_fee = bool(
		declaration and declaration.get("emolument_type") == "Director or Board Member Fees"
	)
	flat_rate = (
		flt(declaration.get("no_edf_rate_option") or year.get("director_flat_rate") or 15)
		if director_or_board_fee else None
	)
	bands = [
		{"upper": None if row.is_open_ended else row.upper_chargeable_income, "rate": row.tax_rate}
		for row in year.bands
	]
	result = calculate_payroll_chain(
		payment_amounts=current["payments"],
		taxable_core_amounts=current["taxable_core"],
		taxable_travelling=current["taxable_travelling"],
		taxable_benefits=current["taxable_benefits"],
		previous_emoluments=previous_emoluments + prior_employment_emoluments,
		edf_amount=edf_amount,
		period_index=min(period_index, int(year.periods_per_year)),
		periods_per_year=year.periods_per_year,
		cumulative_iet=cumulative_iet,
		tax_bands=bands,
		tax_band_factor=Decimal(min(period_index, int(year.periods_per_year))) / Decimal(int(year.periods_per_year)),
		no_edf_rate=flat_rate if director_or_board_fee else (
			None if edf_submitted else flt(
				declaration.no_edf_rate_option if declaration else year.no_edf_rate or 15
			)
		),
		previous_paye=previous_paye + prior_employment_paye,
		other_deductions=current["other_deductions"],
		employer_contributions=employer_contributions,
		precision=2,
		tax_precision=int(year.currency_precision),
		band_boundary_rounding=year.get("band_boundary_rounding") or "Exact Fraction",
		no_paye_threshold=year.get("monthly_no_paye_threshold") or 0,
		threshold_applies=not director_or_board_fee,
	)
	# Use the same effective PAYE engine as statutory processing. The control
	# sheet alone does not apply configured withholding rounding or Fair Share.
	# Minor and Major share a monthly exemption threshold and one EDF position.
	monthly_emoluments = flt(result["current_gross_emoluments"]) + month_emoluments
	tax = calculate_cumulative_paye(
		cumulative_emoluments=result["total_emoluments"],
		period_index=min(period_index, int(year.periods_per_year)),
		bands=bands,
		cumulative_iet=cumulative_iet if edf_submitted and not director_or_board_fee else 0,
		previous_paye=result["previous_paye"],
		edf_submitted=edf_submitted,
		no_edf_rate=flt((declaration.get("no_edf_rate_option") if declaration else None) or year.no_edf_rate or 15),
		flat_rate=flat_rate,
		periods_per_year=year.periods_per_year,
		precision=int(year.currency_precision),
		current_emoluments=result["current_gross_emoluments"] if director_or_board_fee else monthly_emoluments,
		no_paye_threshold=year.get("monthly_no_paye_threshold") or 0,
		fair_share_threshold=year.get("fair_share_threshold") or 0,
		fair_share_rate=year.get("fair_share_rate") or 0,
		band_boundary_rounding=year.get("band_boundary_rounding") or "Exact Fraction",
		current_rounding=year.get("current_paye_rounding") or "Round Half Up",
	)
	withholding = tax["current_paye"]
	if not edf_submitted and not director_or_board_fee:
		# Flat no-EDF tax is on all this month's income; deduct amounts already
		# withheld by an earlier run in the month exactly once.
		withholding = max(0.0, withholding - month_paye - prior_fsc + month_fsc)
		withholding = float(_decimal(withholding).quantize(
			Decimal("1").scaleb(-int(year.currency_precision)),
			rounding=ROUND_DOWN if year.get("current_paye_rounding") == "Round Down" else ROUND_HALF_UP,
		))
		tax["cumulative_tax"] = result["previous_paye"] + withholding
	tax["current_paye"] = withholding
	result.update({
		"paye": withholding,
		"net_paye_payable": tax["cumulative_tax"],
		"chargeable_income": tax["chargeable_income"],
		"fair_share_contribution": tax["fair_share_contribution"],
		"fair_share_withheld": min(withholding, max(0.0, tax["fair_share_contribution"] - prior_fsc)),
		"monthly_emoluments_for_threshold": monthly_emoluments,
		"prior_month_paye": month_paye,
		"paye_engine": tax,
	})
	result["total_employee_deductions"] = total_employee_deductions(current["other_deductions"], withholding)
	result["net_pay"] = net_pay(result["gross_pay"], result["total_employee_deductions"])
	result.update({
		"paye_year": year.name,
		"configuration_version": year.configuration_version,
		"source_declaration": declaration.name if declaration else None,
		"paye_period_index": period_index,
		"tax_basis_mode": current["tax_basis_mode"],
		"component_trace": current["component_trace"],
		"eoy_bonus_amount": flt(eoy_bonus_amount, 2),
		"bonus_iet_applied": flt(bonus_iet, 2),
		"bonus_iet_application_period": "December" if bonus_iet else None,
		"actual_salary_slip": {
			"gross_pay": flt(slip.gross_pay),
			"total_deduction": flt(slip.total_deduction),
			"net_pay": flt(slip.net_pay),
		},
		"reconciliation": {
			"gross_delta": _money(flt(slip.gross_pay) - result["gross_pay"]),
			"deduction_delta": _money(flt(slip.total_deduction) - result["total_employee_deductions"]),
			"net_delta": _money(flt(slip.net_pay) - result["net_pay"]),
		},
	})
	return result


def apply_salary_slip_computation(slip, employer_contributions=0):
	"""Apply the governed PAYE result and populate its audit fields."""
	result = salary_slip_computation(slip, employer_contributions)
	paye_component = frappe.db.get_value(
		"Payroll PDB Code", {"pdb_code": "PAYE", "is_active": 1}, "salary_component"
	)
	if paye_component:
		rows = [row for row in slip.deductions if row.salary_component == paye_component]
		if rows:
			rows[0].amount = result["paye"]
			rows[0].default_amount = result["paye"]
			for duplicate in rows[1:]:
				slip.remove(duplicate)
		elif result["paye"]:
			row = slip.append("deductions", {"salary_component": paye_component, "amount": result["paye"]})
			row.default_amount = result["paye"]
		if hasattr(slip, "set_net_pay"):
			slip.set_net_pay()
	mapping = {
		"karyo_monthly_taxable_emolument": "monthly_taxable_emolument",
		"karyo_taxable_travelling": "taxable_travelling",
		"karyo_taxable_benefits": "taxable_benefits",
		"karyo_current_gross_emoluments": "current_gross_emoluments",
		"karyo_previous_emoluments": "previous_emoluments",
		"karyo_total_emoluments": "total_emoluments",
		"karyo_monthly_iet": "monthly_iet",
		"karyo_chargeable_income": "chargeable_income",
		"karyo_net_paye_payable": "net_paye_payable",
		"karyo_previous_paye": "previous_paye",
		"karyo_calculated_paye": "paye",
		"karyo_employer_contributions": "employer_contributions",
		"karyo_employer_cost": "employer_cost",
	}
	for fieldname, key in mapping.items():
		if slip.meta.has_field(fieldname):
			slip.set(fieldname, result[key])
	if slip.meta.has_field("karyo_computation_trace"):
		slip.karyo_computation_trace = json.dumps(result, sort_keys=True, default=str, indent=2)
	return result


def persist_salary_slip_computation(slip, employer_contributions=0):
	"""Persist the parallel-run result after statutory contributions are known."""
	result = apply_salary_slip_computation(slip, employer_contributions)
	fieldnames = (
		"karyo_monthly_taxable_emolument", "karyo_taxable_travelling", "karyo_taxable_benefits",
		"karyo_current_gross_emoluments", "karyo_previous_emoluments", "karyo_total_emoluments",
		"karyo_monthly_iet", "karyo_chargeable_income", "karyo_net_paye_payable",
		"karyo_previous_paye", "karyo_calculated_paye", "karyo_employer_contributions",
		"karyo_employer_cost", "karyo_computation_trace",
	)
	values = {fieldname: slip.get(fieldname) for fieldname in fieldnames if slip.meta.has_field(fieldname)}
	if values and not slip.is_new():
		frappe.db.set_value("Salary Slip", slip.name, values, update_modified=False)
	return result


def populate_salary_slip_computation(doc, method=None):
	"""Salary Slip validate hook; skip only when no effective PAYE year exists."""
	if not doc.get("employee") or not (doc.get("end_date") or doc.get("posting_date")):
		return
	on_date = _salary_slip_payment_date(doc)
	available = frappe.get_all(
		"Payroll PAYE Year",
		filters={"is_active": 1, "effective_from": ("<=", on_date)},
		fields=["company", "effective_to"],
	)
	if not any(
		(not row.company or row.company == doc.company)
		and (not row.effective_to or getdate(row.effective_to) >= on_date)
		for row in available
	):
		return
	# Keep the employer-side amount already attached by the statutory stage when
	# HRMS rebuilds or re-saves a draft Salary Slip later in the cycle.
	apply_salary_slip_computation(doc, flt(doc.get("karyo_employer_contributions")))


@frappe.whitelist()
def calculation_preview(salary_slip):
	"""Return the complete PAY-CALC trace for an existing Salary Slip."""
	doc = frappe.get_doc("Salary Slip", salary_slip)
	doc.check_permission("read")
	employer_contributions = 0.0
	if doc.get("karyo_payroll_cycle"):
		employer_contributions = flt(frappe.db.get_value(
			"Payroll Statutory Result",
			{
				"payroll_cycle": doc.karyo_payroll_cycle,
				"employee": doc.employee,
				"result_type": "Employer Contribution",
				"status": ("!=", "Reversed"),
			},
			"sum(current_amount)",
		))
	return salary_slip_computation(doc, employer_contributions)
