frappe.query_reports["Loan Schedule"] = {
	filters: [
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "from_date", label: __("Due From"), fieldtype: "Date" },
		{ fieldname: "to_date", label: __("Due To"), fieldtype: "Date" },
		{ fieldname: "version", label: __("Schedule Version"), fieldtype: "Int" },
		{ fieldname: "include_superseded", label: __("Include Superseded"), fieldtype: "Check", default: 0 },
	],
};
