"""End-of-Year bonus engine (pure, testable) — PRB analysis §8, EOY-01..13.

Base = monthly salary (+ acting allowance for acting/higher-duty cases, EOY-11/12).
Ratio depends on the case: full month, pro-rata service, half-pay salary ratio,
or intermittent/bank-scheme proportion. Excluded cases pay nothing (EOY-07).
"""

EXCLUDED_REASONS = {"resigned_private", "own_convenience", "dismissed", "interdiction"}


def is_excluded(reason, reinstated=False):
	"""EOY-07: no bonus for resignation/dismissal/interdiction — unless a reinstated
	officer is approved to be paid for the interdiction period."""
	if reason == "interdiction" and reinstated:
		return False
	return reason in EXCLUDED_REASONS


def eoy_bonus(
	monthly_salary,
	*,
	excluded=False,
	acting_allowance=0,
	half_pay=False,
	actual_salary_drawn=0,
	total_annual_salary=0,
	service_months=None,
	service_days=None,
	precision=2,
):
	"""End-of-year bonus for salaried officers.

	- half_pay (EOY-05): ratio = actual salary drawn / total annual salary.
	- service_months / service_days (EOY-02): pro-rata of a full month.
	- otherwise a full month (EOY-01). acting_allowance adds to the base (EOY-11/12).
	"""
	if excluded:
		return 0.0
	base = float(monthly_salary) + float(acting_allowance or 0)
	if half_pay:
		ratio = (actual_salary_drawn / total_annual_salary) if total_annual_salary else 0.0
	elif service_months is not None:
		ratio = service_months / 12.0
	elif service_days is not None:
		ratio = service_days / 365.0
	else:
		ratio = 1.0
	return round(base * ratio, precision)


def eoy_bonus_intermittent(actual_annual_earnings, fulltime_annual_salary, precision=2):
	"""EOY-10: substitute/daily/sessional/bank-scheme — a full-time month's bonus
	scaled by actual earnings vs the corresponding full-time annual salary."""
	if not fulltime_annual_salary:
		return 0.0
	fulltime_month = fulltime_annual_salary / 12.0
	proportion = actual_annual_earnings / fulltime_annual_salary
	return round(fulltime_month * proportion, precision)
