frappe.pages["hr-record"].on_page_load = function (wrapper) {
	frappe.ui.make_app_page({ parent: wrapper, title: __("HR Record"), single_column: true });
	$(wrapper).addClass("karyo-module-page hr-record-page");
};

frappe.pages["hr-record"].on_page_show = function (wrapper) {
	const route = frappe.get_route();
	if (route[0] !== "hr-record") return;
	const record_type = route[1];
	const name = route.slice(2).join("/");
	if (record_type === "expense-claim" && name && karyo.shell.is_ess_user()) {
		frappe.set_route("my-claims", name);
		return;
	}
	const $root = $(wrapper).find(".layout-main-section").empty();
	if (!record_type || !name) {
		frappe.set_route("people-overview");
		return;
	}
	$root.append($("<div class='employee-360-loading'></div>").text(__("Loading record…")));
	karyo.live.request(wrapper, {
		method: "karyo.desk.record_workspace.get_workspace",
		args: { record_type, name },
		callback: (r) => render_hr_record($root, r.message || {}),
	});
};

function render_hr_record($root, d) {
	$root.empty();
	const $page = $('<div class="karyo-page hr-record-workspace"></div>').appendTo($root);
	$page.toggleClass(
		"is-financial",
		["salary-slip", "expense-claim", "karyo-loan"].includes(d.record_type)
	);
	const $crumbs = $('<div class="karyo-crumbs"></div>').appendTo($page);
	$crumbs.append(
		$('<a href="/app/people-overview"></a>').text(__("People")),
		'<span class="karyo-crumb-sep">›</span>',
		$("<span></span>").text(d.title)
	);
	const $header = $(
		'<div class="record-workspace-header"><div><div class="record-eyebrow"></div><h1></h1><div class="record-header-meta"></div></div><div class="record-workspace-actions"></div></div>'
	).appendTo($page);
	$header.find(".record-eyebrow").text(d.title);
	$header.find("h1").text(d.display_name || d.name);
	$header
		.find(".record-header-meta")
		.append(karyo.pages.pill(d.record_type === "leave-application" && d.status === "Open" ? __("Pending") : d.status), $("<span></span>").text(d.date || d.name));
	if (d.actions?.edit) {
		$header.find(".record-workspace-actions").append(
			$('<button class="btn btn-sm btn-primary"></button>')
				.text(__(d.meta?.docstatus === 0 ? "Edit" : "Manage"))
				.on("click", () => {
					karyo.record_workspace.edit(d.doctype, d.name);
				})
		);
	}
	if (d.actions?.delete) {
        $('<button type="button" class="btn btn-default text-danger"></button>').text(__('Delete'))
            .on('click', () => frappe.model.delete_doc(d.doctype, d.name, () => frappe.set_route('List', d.doctype)))
            .appendTo($header.find('.record-workspace-actions'));
    }
	if (d.employee) render_record_employee($page, d.employee);
	if (d.record_type === "employee-separation" && d.settlement)
		render_final_settlement($page, d.settlement, d.currency);
	if (d.flow) {
		const $journey = $('<section class="employee-section record-flow"><div class="record-flow-main"></div><div class="record-flow-side"></div></section>').appendTo($page);
		karyo.pages.section_head($journey.find(".record-flow-main"), { title: __("Journey") });
		karyo.pages.stepper($journey.find(".record-flow-main"), d.flow);
		if ((d.flow.checklist || []).length) {
			karyo.pages.section_head($journey.find(".record-flow-main"), { title: __("Pre-action checklist"), count: d.flow.checklist.length });
			karyo.pages.checklist($journey.find(".record-flow-main"), d.flow.checklist);
		}
		karyo.pages.flow_panel($journey.find(".record-flow-side"), {
			why: d.flow.why, gate: d.flow.gate,
			cta: d.actions?.edit && !d.flow.gate ? { label: __("Continue this step"), onclick: () => karyo.record_workspace.edit(d.doctype, d.name) } : null,
		});
	}
	const $grid = $('<div class="record-workspace-grid"></div>').appendTo($page);
	render_record_summary($grid, d.fields || [], d.currency);
	render_record_audit($grid, d.meta || {});
	(d.tables || []).forEach((table) => render_record_table($page, table, d.currency));
}

function render_final_settlement($page, settlement, currency) {
	const money = (value) => format_currency(value || 0, currency);
	const days = (value) => __("{0} days", [format_number(flt(value || 0), null, 2)]);
	const $section = $('<section class="employee-section record-final-settlement"><div class="employee-section-head"><h3></h3><span></span></div><p class="employee-muted"></p><div class="pay-summary"></div><div class="employee-data-grid"></div></section>').appendTo($page);
	$section.find("h3").text(__("Leaving Service Final Settlement"));
	$section.find(".employee-section-head span").append(karyo.pages.pill(__(settlement.status || "Preview"), settlement.status === "Finalized" ? "green" : "orange"));
	$section.find("p").text(__("Balances as at {0}. The outstanding loan balance is deducted from leave and Passage Benefit amounts.", [settlement.as_at || "—"]));
	[
		[__("Remaining Sick Leave"), days(settlement.sick_leave_days)],
		[__("Annual Leave Balance"), days(settlement.vacation_leave_days)],
		[__("Leave Settlement"), money(settlement.leave_settlement_amount)],
		[__("Passage Benefit Balance"), money(settlement.pb_balance)],
		[__("Outstanding Loan Balance"), money(settlement.loan_outstanding)],
		[__("Total Accrued Benefits"), money(settlement.gross_settlement)],
		[__("Net Settlement"), money(settlement.net_settlement)],
	].forEach(([label, value]) => $section.find(".pay-summary").append(
		$("<div><span></span><strong></strong></div>").find("span").text(label).end().find("strong").text(value).end()
	));
	if (settlement.component_details_available) {
		const $table = $('<table class="table table-bordered"><thead><tr></tr></thead><tbody></tbody></table>').appendTo(
			$('<div class="table-responsive mt-3"></div>').appendTo($section)
		);
		[__("Benefit"), __("No. of Days"), __("Amount")].forEach(label => $('<th></th>').text(label).appendTo($table.find('thead tr')));
		[
			[__("Sick Leave — Current Year"), settlement.sick_current_days, settlement.sick_current_amount],
			[__("Sick Leave — Bank Balance"), settlement.sick_bank_days, settlement.sick_bank_amount],
			[__("Annual Leave — Current Year"), settlement.annual_current_days, settlement.annual_current_amount],
			[__("Annual Leave — Bank Balance"), settlement.annual_bank_days, settlement.annual_bank_amount],
			[__("Passage Benefits"), null, settlement.pb_balance],
		].forEach(([label, count, amount]) => {
			const $row = $('<tr></tr>').appendTo($table.find('tbody'));
			[label, count == null ? '—' : days(count), money(amount)].forEach(value => $('<td></td>').text(value).appendTo($row));
		});
	}
	if (settlement.explanation)
		$("<div class='alert alert-light border'>").text(settlement.explanation).appendTo($section.find(".employee-data-grid"));
	if ((settlement.loan_breakdown || []).length) {
		const $loans = $('<div class="record-detail-table"><div class="record-detail-row is-head"><span></span><span></span><span></span></div></div>').appendTo($section.find(".employee-data-grid"));
		[__("Outstanding loan"), __("Status"), __("Balance at leaving date")].forEach((label, index) => $loans.find(".is-head span").eq(index).text(label));
		settlement.loan_breakdown.forEach((loan) => {
			const $row = $("<div class='record-detail-row'><span></span><span></span><span></span></div>").appendTo($loans);
			$row.find("span").eq(0).text([loan.loan_type, loan.loan].filter(Boolean).join(" · "));
			$row.find("span").eq(1).text(loan.status || "—");
			$row.find("span").eq(2).text(money(loan.outstanding));
		});
	}
}

function render_record_employee($page, employee) {
	const initials = (employee.employee_name || employee.name || "?")
		.split(/\s+/)
		.slice(0, 2)
		.map((part) => part[0])
		.join("")
		.toUpperCase();
	const $card = $(
		'<button type="button" class="record-employee-card"><div class="person-avatar"><span></span></div><div><small>Employee</small><strong></strong><span></span></div><b>View profile →</b></button>'
	).appendTo($page);
	if (employee.image)
		$card.find(".person-avatar").empty().append($("<img alt=''>").attr("src", employee.image));
	else $card.find(".person-avatar span").text(initials);
	$card.find("strong").text(employee.employee_name || employee.name);
	$card
		.find("div > span")
		.last()
		.text([employee.designation, employee.department].filter(Boolean).join(" · "));
	$card.on("click", () => frappe.set_route(employee.route.replace(/^\/app\//, "")));
}

function render_record_summary($grid, fields, currency) {
	const $section = $(
		'<section class="employee-section"><h3>Summary</h3><div class="record-summary"></div></section>'
	)
		.appendTo($grid)
		.find(".record-summary");
	(fields || []).forEach((field) => {
		const $row = $("<div><span></span><strong></strong></div>");
		$row.find("span").text(field.label);
		let value = field.value;
		if (field.fieldtype === "Check") value = field.value ? __("Yes") : __("No");
		if (field.fieldtype === "Currency" && field.value != null)
			value = format_currency(field.value, currency);
		$row.find("strong").text(value ?? "—");
		$row.toggleClass("is-amount", field.fieldtype === "Currency");
		$section.append($row);
	});
}

function render_record_audit($grid, meta) {
	const $section = $(
		'<section class="employee-section"><h3>Record information</h3><div class="record-audit"></div></section>'
	).appendTo($grid);
	[
		[__("Created"), meta.created],
		[__("Created by"), meta.owner],
		[__("Last updated"), meta.modified],
		[__("Updated by"), meta.modified_by],
	].forEach(([label, value]) =>
		$section.find(".record-audit").append(
			$("<div><span></span><strong></strong></div>")
				.find("span")
				.text(label)
				.end()
				.find("strong")
				.text(value || "—")
				.end()
		)
	);
}

function render_record_table($page, table, currency) {
	const $section = $(
		'<section class="employee-section record-detail-section"><div class="employee-section-head"><h3></h3><span></span></div><div class="record-detail-table"></div></section>'
	).appendTo($page);
	$section.find("h3").text(table.title || __("Details"));
	$section
		.find(".employee-section-head span")
		.text(__("{0} items", [(table.rows || []).length]));
	const $table = $section.find(".record-detail-table");
	if (!(table.rows || []).length) {
		$table.append($("<div class='employee-muted'></div>").text(__("No details added")));
		return;
	}
	const $head = $('<div class="record-detail-row is-head"></div>').appendTo($table);
	(table.columns || []).forEach((column) => $head.append($("<span></span>").text(column.label)));
	if ((table.rows || []).some((row) => row.task_status))
		$head.append($("<span></span>").text(__("Status")));
	(table.rows || []).forEach((row) => {
		const $record = $('<div class="record-detail-row"></div>');
		(table.columns || []).forEach((column) => {
			let value = row[column.fieldname];
			if (column.fieldtype === "Currency" && value != null)
				value = format_currency(value, currency);
			$record.append($("<span></span>").text(value ?? "—"));
		});
		if ((table.rows || []).some((item) => item.task_status))
			$record.append($("<span></span>").text(row.task_status || "—"));
		$table.append($record);
	});
}
