"""Install the additional-hours payroll decision gate on existing sites."""

import frappe


def execute():
	from karyo.setup.prb_posting import add_posting_fields, backfill_overtime_approval_status

	add_posting_fields()
	backfill_overtime_approval_status()
	frappe.clear_cache(doctype="PRB Overtime Authorization")

