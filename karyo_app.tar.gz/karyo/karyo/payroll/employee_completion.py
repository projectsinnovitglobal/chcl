"""Reviewed, approved and closed payroll for the explicitly selected employees."""
import frappe
from frappe import _
from frappe.utils import now_datetime, flt
from karyo.payroll.governance import has_actor_role, assert_segregation_of_duties
from karyo.payroll.employee_processing import counts, mark

ACTIONS = ('Calculate PAYE and Contributions','Send for Review','Review Statutory Results','Approve Payroll','Apply Employee Deductions','Submit Salary Slips','Close Payroll')
ACTORS = ('processor','reviewer','reviewer','approver','approver','processor','finance')
PAYE_ACTIONS = ACTIONS[:5]


def guard_salary_slip_submission(doc, method=None):
    """Keep governed Salary Slips draft until their explicit submit step.

	Salary Slip submission is irreversible without cancellation and also triggers
	loan/accounting side effects.  PAYE calculation, review and deduction apply
	all operate on the draft, so a manual/native early submit must be rejected.
	"""
    cycle_name = doc.get('karyo_payroll_cycle')
    if not cycle_name and doc.get('payroll_entry'):
        cycle_name = frappe.db.get_value('Payroll Entry', doc.payroll_entry, 'karyo_payroll_cycle')
    if not cycle_name:
        return
    cycle = frappe.db.get_value('Payroll Cycle', cycle_name, ['status', 'docstatus'], as_dict=True)
    if not cycle:
        return
    # The selected employee workflow sets this flag only around the governed
    # Submit Salary Slips action, after statutory deductions are reconciled.
    if frappe.flags.payroll_employee_completion:
        return
    # Preserve the older whole-cycle submit action, which is available only
    # after the submitted cycle is Approved and all statutory rows are Applied.
    if cycle.status == 'Approved' and cycle.docstatus == 1:
        unapplied = frappe.db.exists('Payroll Statutory Result', {
            'payroll_cycle': cycle_name,
            'employee': doc.employee,
            'result_type': ('in', ['PAYE', 'Employee Contribution']),
            'status': ('!=', 'Applied'),
        })
        has_paye = frappe.db.exists('Payroll Statutory Result', {
            'payroll_cycle': cycle_name, 'employee': doc.employee,
            'result_type': 'PAYE', 'status': 'Applied',
        })
        if has_paye and not unapplied:
            return
    frappe.throw(_(
        'Salary Slip must remain Draft while PAYE and statutory contributions are being processed. '
        'Use Close Payroll > Submit Salary Slips after statutory deductions are applied.'
    ))


def state(cycle, employees=None):
    from karyo.payroll.employee_closing import state as closing_state, slips
    scope = closing_state(cycle,employees)
    chosen=scope['employees']
    records={r.employee:r for r in frappe.get_all('Payroll Cycle Employee',filters={'payroll_cycle':cycle.name,'employee':('in',chosen or [''])},fields=['employee','status','review_sent_on','employee_approved_on','employee_approved_by','closed_on'])}
    salary=[s for s in slips(cycle) if s.employee in chosen]
    results=frappe.get_all('Payroll Statutory Result',filters={'payroll_cycle':cycle.name,'employee':('in',chosen or [''])},fields=['employee','status','result_type'])
    generated=bool(chosen) and all(sum(s.employee==e for s in salary)==1 for e in chosen)
    calculated=generated and all(any(r.employee==e and r.result_type=='PAYE' for r in results) and records.get(e,{}).get('status') not in ('Failed','Salary Slip Created') for e in chosen)
    reviewed=calculated and all(r.status in ('Reviewed','Applied') for r in results)
    approved=reviewed and all(records.get(e,{}).get('employee_approved_on') or (cycle.docstatus==1 and cycle.status in ('Approved','Closed','Reopened')) for e in chosen)
    applied=approved and all(r.status=='Applied' for r in results if r.result_type in ('PAYE','Employee Contribution'))
    done=dict(zip(ACTIONS,[calculated,calculated and all(records.get(e,{}).get('review_sent_on') or cycle.status in ('Review','Approved','Closed') for e in chosen),reviewed,approved,applied,applied and all(s.docstatus==1 for s in salary),bool(chosen) and all(r['status']=='Closed' for r in scope['rows'])]))
    active=next((a for a in ACTIONS if not done[a]),None)
    issues=counts(cycle,chosen)['blocking'] if chosen else 0
    steps=[]
    for action,actor in zip(ACTIONS,ACTORS):
        reason=None
        if done[action]:reason=_('Completed for this selection.')
        elif not chosen:reason=_('Select eligible employees for this pay day.')
        elif cycle.docstatus==2 or cycle.status in ('Cancelled','Closed'):reason=_('This payroll cycle is closed or cancelled.')
        elif not generated:reason=_('Generate Draft Salary Slips for this selection first.')
        elif issues:reason=_('Resolve readiness exceptions for the selected employees first.')
        elif action!=active:reason=_('Complete {0} first.').format(active)
        elif not has_actor_role(actor) and not (action=='Submit Salary Slips' and has_actor_role('approver')):reason=_('A payroll {0} must run this step.').format(actor)
        elif action=='Close Payroll' and scope['blocked']:reason=_('Resolve the employee requirements in the table before closing this selection.')
        steps.append({'action':action,'screen':'applypaye' if action in PAYE_ACTIONS else 'close','hint':_('Applies only to the employee selection above.'),'done':done[action],'next':action==active,'available':not reason,'blocked_reason':reason})
    from karyo.payroll.employee_closing import population
    everyone = population(cycle)
    closed = set(frappe.get_all('Payroll Cycle Employee', filters={'payroll_cycle':cycle.name, 'closed_on':('is','set')}, pluck='employee'))
    if everyone and everyone.issubset(closed) and cycle.status != 'Closed':
        from frappe.model.workflow import get_transitions
        for transition in get_transitions(cycle):
            if transition.action in ('Send for Review', 'Approve Payroll', 'Close Payroll'):
                steps.append({'action':'Finalize overall cycle: '+transition.action, 'screen':'close',
                    'hint':_('All employees are closed. This explicitly completes the overall cycle workflow.'),
                    'done':False, 'next':True, 'available':True, 'blocked_reason':None})
    can_reject = bool(cycle.docstatus == 0 and next(s for s in steps if s['action']=='Approve Payroll')['available']
        and all(s.docstatus == 0 for s in salary) and not any(r.status == 'Applied' for r in results)
        and not any(r.employee_approved_on or r.closed_on for r in records.values()))
    return {**scope,'steps':steps,'records':records,'can_reject':can_reject}


@frappe.whitelist(methods=['POST'])
def reject_payroll(payroll_cycle, employees=None, reason=None):
    """Return only the selected, unapproved draft payroll to calculation."""
    if not isinstance(reason, str) or not reason.strip():
        frappe.throw(_('Enter a reason for returning payroll for processing.'))
    cycle = frappe.get_doc('Payroll Cycle', payroll_cycle)
    cycle.check_permission('write')
    frappe.db.sql('select name from `tabPayroll Cycle` where name=%s for update', cycle.name)
    cycle.reload()
    scope = state(cycle, employees)
    if not scope['can_reject']:
        frappe.throw(_('Only a payroll approver can return reviewed, unapproved draft payroll for processing.'), frappe.PermissionError)
    selected = scope['employees']
    frappe.db.savepoint('reject_employee_payroll')
    try:
        frappe.db.set_value('Payroll Statutory Result', {'payroll_cycle':cycle.name, 'employee':('in',selected)}, 'status', 'Calculated')
        for employee in selected:
            mark(cycle, employee, status='Salary Slip Created', review_sent_on=None,
                exclusion_reason=_('Returned for processing: {0}').format(reason.strip()))
        cycle.add_comment('Info', _('Payroll rejected and returned for processing for employees {0}. Reason: {1}').format(', '.join(selected), reason.strip()))
        cycle.notify_update()
    except Exception:
        frappe.db.rollback(save_point='reject_employee_payroll')
        raise
    return {'employees':selected, 'message':_('Payroll returned for processing. Correct the selected draft payslips, then rerun Calculate PAYE and Contributions.')}


def validate_stage(cycle, employees, action):
    cycle.check_permission('write')
    scope=state(cycle,employees)
    step=next(s for s in scope['steps'] if s['action']==action)
    if not step['available']:
        frappe.throw(step['blocked_reason'] or _('This step is unavailable.'))
    return [employee for employee in scope['employees'] if not next(s for s in state(cycle,[employee])['steps'] if s['action']==action)['done']]


@frappe.whitelist(methods=['POST'])
def run_step(payroll_cycle, action, employees=None):
    if action not in ACTIONS and action not in ['Finalize overall cycle: '+a for a in ('Send for Review','Approve Payroll','Close Payroll')]:frappe.throw(_('Select a valid employee payroll step.'))
    cycle=frappe.get_doc('Payroll Cycle',payroll_cycle)
    cycle.check_permission('write')
    frappe.db.sql('select name from `tabPayroll Cycle` where name=%s for update',cycle.name)
    cycle.reload()
    if action.startswith('Finalize overall cycle: '):
        available = [s['action'] for s in state(cycle,employees)['steps'] if s['available']]
        if action not in available:frappe.throw(_('Complete every employee before finalizing the overall cycle.'))
        from karyo.payroll.completion import run_step as run_cycle_step
        return run_cycle_step(cycle.name, action.split(': ',1)[1])
    chosen=validate_stage(cycle,employees,action)
    # A failed native operation rolls back the selected batch, including approvals.
    frappe.db.savepoint('employee_completion_step')
    previous_flag=frappe.flags.payroll_employee_completion
    frappe.flags.payroll_employee_completion=True
    try:
        if action=='Calculate PAYE and Contributions':
            from karyo.payroll.process import calculate_cycle_statutory
            from karyo.payroll.employee_processing import employee_error_message
            result=calculate_cycle_statutory(cycle.name,employees=chosen)
            if result.get('failed'):
                detail = '; '.join(employee_error_message(row['employee'], row['message']) for row in result['failed'])
                frappe.throw(_('Statutory calculation failed: {0}').format(detail))
        elif action=='Send for Review':
            for employee in chosen:mark(cycle,employee,review_sent_on=now_datetime())
        elif action=='Review Statutory Results':
            from karyo.payroll.statutory import review_cycle_results
            review_cycle_results(cycle.name,employees=chosen)
        elif action=='Approve Payroll':
            approval=frappe._dict(cycle.as_dict());approval.status='Approved'
            assert_segregation_of_duties(approval)
            for employee in chosen:mark(cycle,employee,employee_approved_on=now_datetime(),employee_approved_by=frappe.session.user)
        elif action=='Apply Employee Deductions':
            from karyo.payroll.statutory import apply_cycle_results
            apply_cycle_results(cycle.name,employees=chosen)
        elif action=='Submit Salary Slips':
            submit_selected_slips(cycle, chosen)
        else:
            from karyo.payroll.employee_closing import close_employees
            return close_employees(cycle.name,chosen)
        cycle.add_comment('Info',_('{0} completed for employees: {1}.').format(action,', '.join(chosen)))
        cycle.notify_update()
        return {'employees':chosen,'message':_('{0} completed for {1} selected employee(s).').format(action,len(chosen))}
    except Exception:
        frappe.db.rollback(save_point='employee_completion_step')
        raise

    finally:
        frappe.flags.payroll_employee_completion=previous_flag


def submit_selected_slips(cycle, employees):
    """Keep native submission and accrual atomic, restricted to this batch."""
    from karyo.payroll.employee_closing import slips
    selected = [frappe.get_doc('Salary Slip', row.name) for row in slips(cycle)
                if row.employee in employees and row.docstatus == 0]
    entry = frappe.get_doc('Payroll Entry', cycle.payroll_entry) if cycle.payroll_entry else None
    if not entry or entry.company != cycle.company or entry.get('karyo_payroll_cycle') != cycle.name:
        frappe.throw(_('Payroll Entry does not belong to this payroll cycle.'))
    entry.check_permission('write')
    # ERPNext needs ledger mappings for the accrual journal. Karyo derives them
    # internally so staff never have to browse or select legacy Account masters.
    from karyo.payroll.component_accounts import ensure_salary_slip_component_accounts
    ensure_salary_slip_component_accounts(selected, entry.company)
    names = {slip.name for slip in selected}
    native_list = entry.get_sal_slip_list
    native_components = entry.get_salary_components
    native_accounting_entry = entry.get_accounting_entries_and_payable_amount
    # Native accrual queries through this instance method. Restrict it without
    # changing the shared Payroll Entry population or any other request.
    def selected_list(ss_status, as_dict=False):
        rows = native_list(ss_status, as_dict=as_dict)
        return [r for r in rows if (r.name if as_dict else r[0]) in names]
    def selected_components(component_type):
        # A zero-value component must not create a zero-total account dictionary:
        # HRMS otherwise attempts an empty journal, whose stock-account validation
        # misleadingly checks every inventory account in the company.
        precision = frappe.get_precision('Salary Detail', 'amount')
        return [row for row in (native_components(component_type) or []) if flt(row.amount, precision)]
    def nonzero_accounting_entry(*args, **kwargs):
        # A zero-net slip can leave a binary-float remainder after separately
        # totaling earnings and deductions. HRMS tests the raw remainder before
        # rounding and otherwise appends a Journal Entry row whose displayed
        # debit and credit are both zero.
        amount = kwargs.get('amount', args[2] if len(args) > 2 else 0)
        precision = kwargs.get('precision', args[7] if len(args) > 7 else None)
        payable_amount = kwargs.get('payable_amount', args[5] if len(args) > 5 else 0)
        if not flt(amount, precision):
            return payable_amount
        return native_accounting_entry(*args, **kwargs)
    previous = frappe.flags.via_payroll_entry
    try:
        frappe.flags.via_payroll_entry = True
        for slip in selected:
            messages_before = list(getattr(frappe.local, 'message_log', []) or [])
            try:
                if slip.payroll_entry != entry.name:frappe.throw(_('Salary Slip belongs to another Payroll Entry.'))
                slip.check_permission('submit')
                slip.submit()
            except frappe.ValidationError as error:
                from karyo.payroll.employee_processing import employee_error_message
                frappe.local.message_log = messages_before
                frappe.throw(employee_error_message(slip.employee, error))
        entry.get_sal_slip_list = selected_list
        entry.get_salary_components = selected_components
        entry.get_accounting_entries_and_payable_amount = nonzero_accounting_entry
        entry.make_accrual_jv_entry(selected)
        from karyo.payroll.employee_closing import population
        submitted = set(frappe.get_all('Salary Slip',filters={'payroll_entry':entry.name,'docstatus':1},pluck='employee'))
        if population(cycle).issubset(submitted) and not frappe.db.exists('Salary Slip', {'payroll_entry':entry.name, 'docstatus':0}):
            entry.db_set({'salary_slips_submitted':1, 'status':'Submitted', 'error_message':''})
    finally:
        entry.__dict__.pop('get_sal_slip_list', None)
        entry.__dict__.pop('get_salary_components', None)
        entry.__dict__.pop('get_accounting_entries_and_payable_amount', None)
        frappe.flags.via_payroll_entry = previous
