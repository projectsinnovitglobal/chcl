"""Guided Passage Benefit calculation, approval, and PB Bank posting.

The monthly scheduler remains the automatic accrual path in ``karyo.tasks``.
This module owns the interactive workspace path: calculate persistent draft
results, approve a reviewed scope, then submit those approved amounts to the
employee's PB Bank ledger. Payroll is used later only when an employee redeems
an approved benefit through the Payroll processing route.
"""

import frappe
from frappe import _
from frappe.utils import flt, get_first_day, get_last_day, getdate, now_datetime, nowdate

from karyo.passage_benefit.init_bank import list_eligible_employees
from karyo.passage_benefit.params import resolve as resolve_params
from karyo.passage_benefit.params import validate_required


CALCULATE_ROLES = {"System Manager", "HR Manager", "HR User", "Passage Benefit Officer"}
APPROVE_ROLES = {"System Manager", "HR Manager", "Passage Benefit Officer", "Payroll Approver"}
PAYROLL_ROLES = {"System Manager", "Payroll Processor", "Payroll Finance", "Karyo Finance"}
VIEW_ROLES = CALCULATE_ROLES | APPROVE_ROLES | PAYROLL_ROLES | {"Payroll Reviewer", "Payroll Auditor"}
OPEN_PAYROLL_STATUSES = ("Draft", "Input Open", "Processing", "Review", "Approved", "Reopened")


def _require(roles, message):
	if not set(frappe.get_roles()) & roles:
		frappe.throw(message, frappe.PermissionError)


def _as_list(values, label):
	if isinstance(values, str):
		values = frappe.parse_json(values) if values.strip().startswith("[") else [values]
	if not isinstance(values, (list, tuple)) or not values:
		frappe.throw(_("Select at least one {0}.").format(label))
	return list(dict.fromkeys(value for value in values if value))


def _period(from_date, to_date):
	start, end = getdate(from_date), getdate(to_date)
	if end < start:
		frappe.throw(_("To Date cannot be before From Date."))
	return start, end, f"{end.year:04d}-{end.month:02d}"


def _cycles():
	return frappe.get_list(
		"Payroll Cycle",
		filters={"status": ["in", OPEN_PAYROLL_STATUSES]},
		fields=["name", "company", "start_date", "end_date", "payment_date", "pay_period_label", "status"],
		order_by="start_date desc, payment_date desc",
		limit_page_length=50,
	)


def _default_cycle(cycles):
	today = getdate(nowdate())
	return next((row for row in cycles if getdate(row.start_date) <= today <= getdate(row.end_date)), None) or (cycles[0] if cycles else None)


def _mapping(as_on, company=None):
	params = validate_required(
		resolve_params(as_on),
		for_payroll=True,
		require_entitlement=False,
		as_on=as_on,
		company=company,
	)
	pdb_type = frappe.db.get_value(
		"Payroll PDB Type",
		params.payroll_pdb_type,
		["name", "description", "classification", "is_active", "effective_from", "effective_to"],
		as_dict=True,
	)
	pdb = frappe.db.get_value(
		"Payroll PDB Code",
		params.payroll_pdb_code,
		["name", "pdb_type", "description", "salary_component", "transaction_mode", "is_active", "effective_from", "effective_to"],
		as_dict=True,
	)
	on = getdate(as_on)
	if not pdb_type or not pdb_type.is_active:
		frappe.throw(_("The configured Passage Benefit PDB Type is missing or inactive."))
	if not pdb or not pdb.is_active:
		frappe.throw(_("The configured Passage Benefit PDB Code is missing or inactive."))
	if pdb.pdb_type != pdb_type.name:
		frappe.throw(_("The Passage Benefit PDB Code does not belong to the configured PDB Type."))
	if pdb.transaction_mode not in ("Once Off", "Both"):
		frappe.throw(_("The Passage Benefit PDB Code must allow once-off payroll transactions."))
	for row, label in ((pdb_type, _("PDB Type")), (pdb, _("PDB Code"))):
		if row.effective_from and on < getdate(row.effective_from):
			frappe.throw(_("The Passage Benefit {0} is not effective on {1}.").format(label, on))
		if row.effective_to and on > getdate(row.effective_to):
			frappe.throw(_("The Passage Benefit {0} expired on {1}.").format(label, row.effective_to))
	component = frappe.db.get_value(
		"Salary Component", pdb.salary_component, ["name", "type", "disabled"], as_dict=True
	)
	if not component or component.disabled:
		frappe.throw(_("The Passage Benefit Salary Component is missing or disabled."))
	expected = "Deduction" if pdb_type.classification == "Deduction" else "Earning"
	if component.type != expected:
		frappe.throw(
			_("The Passage Benefit PDB Type is {0}, but Salary Component {1} is configured as {2}.").format(
				pdb_type.classification, component.name, component.type
			)
		)
	return frappe._dict(
		pdb_type=pdb_type.name,
		pdb_type_description=pdb_type.description,
		classification=pdb_type.classification,
		pdb_code=pdb.name,
		pdb_description=pdb.description,
		salary_component=component.name,
		component_type=component.type,
	)


def _existing_rows(pay_period, employees=None):
	filters = {"pay_period": pay_period, "docstatus": ["<", 2]}
	if employees:
		filters["employee"] = ["in", employees]
	rows = frappe.get_list(
		"Passage Benefit Computation",
		filters=filters,
		fields=[
			"name", "employee", "employee_name", "from_date", "to_date", "pay_period",
			"eligible_days_total", "earned_amount", "workflow_status", "docstatus",
			"payroll_cycle", "payroll_pdb_type", "payroll_pdb_code", "pdb_component",
			"additional_salary", "approved_by", "approved_on", "payroll_submitted_by",
			"payroll_submitted_on",
		],
		order_by="employee asc, creation desc",
		limit_page_length=0,
	)
	seen = set()
	result = []
	for row in rows:
		if row.employee in seen:
			continue
		seen.add(row.employee)
		if row.additional_salary:
			row.workflow_status = "Submitted to Payroll"
		elif row.docstatus == 1 and row.workflow_status != "Submitted to Payroll":
			row.workflow_status = "PB Bank Posted"
		else:
			row.workflow_status = row.workflow_status or "Calculated"
		row.bank_ledger_entry = frappe.db.get_value(
			"Passage Benefit Ledger Entry",
			{
				"reference_doctype": "Passage Benefit Computation",
				"reference_name": row.name,
				"entry_type": "Earning",
				"docstatus": 1,
			},
			"name",
		)
		row.salary_basis = frappe.db.get_value(
			"Passage Benefit Computation Segment",
			{"parent": row.name},
			"monthly_salary",
			order_by="salary_to desc, idx desc",
		) or 0
		result.append(row)
	return result


def workspace(from_date=None, to_date=None, company=None, payroll_cycle=None):
	_require(VIEW_ROLES, _("You are not permitted to process Passage Benefits."))
	cycles = _cycles()
	selected = next((row for row in cycles if row.name == payroll_cycle), None) or _default_cycle(cycles)
	start = getdate(from_date) if from_date else getdate(selected.start_date) if selected else get_first_day(nowdate())
	end = getdate(to_date) if to_date else getdate(selected.end_date) if selected else get_last_day(nowdate())
	start, end, pay_period = _period(start, end)
	if selected and not company:
		company = selected.company
	employees = list_eligible_employees(company=company, as_on=end)
	existing = {row.employee: row for row in _existing_rows(pay_period)}
	for row in employees:
		calculation = existing.get(row["employee"])
		row["calculation"] = calculation
		row["calculation_status"] = calculation.workflow_status if calculation else "Ready to Calculate" if row["eligible"] else "Not Eligible"
	mapping = None
	mapping_error = None
	try:
		mapping = _mapping(end, company)
	except Exception as exc:
		mapping_error = str(exc)
	return {
		"from_date": start,
		"to_date": end,
		"pay_period": pay_period,
		"company": company,
		"payroll_cycle": selected.name if selected else None,
		"cycles": cycles,
		"employees": employees,
		"results": list(existing.values()),
		"mapping": mapping,
		"mapping_error": mapping_error,
		"can_calculate": bool(set(frappe.get_roles()) & CALCULATE_ROLES),
		"can_approve": bool(set(frappe.get_roles()) & APPROVE_ROLES),
		"can_submit_pb_bank": bool(set(frappe.get_roles()) & PAYROLL_ROLES),
		# Compatibility for clients deployed before the action was named correctly.
		"can_submit_payroll": bool(set(frappe.get_roles()) & PAYROLL_ROLES),
	}


def calculate(from_date, to_date, employees, company=None, payroll_cycle=None):
	_require(CALCULATE_ROLES, _("You are not permitted to calculate Passage Benefits."))
	employees = _as_list(employees, _("eligible employee"))
	start, end, pay_period = _period(from_date, to_date)
	created, skipped, failed = [], [], []
	for index, employee in enumerate(employees, 1):
		savepoint = f"pb_guided_calculate_{index}"
		frappe.db.savepoint(savepoint)
		try:
			existing = frappe.db.exists(
				"Passage Benefit Computation",
				{"employee": employee, "pay_period": pay_period, "docstatus": ["<", 2]},
			)
			if existing:
				skipped.append({"employee": employee, "name": existing, "reason": _("Already calculated for this period.")})
				continue
			row = frappe.get_doc(
				{
					"doctype": "Passage Benefit Computation",
					"employee": employee,
					"from_date": start,
					"to_date": end,
					"pay_period": pay_period,
					"payroll_cycle": payroll_cycle,
					"workflow_status": "Calculated",
				}
			)
			row.insert(ignore_permissions=True)
			created.append({"employee": employee, "name": row.name, "earned": row.earned_amount})
		except Exception as exc:
			frappe.db.rollback(save_point=savepoint)
			failed.append({"employee": employee, "error": str(exc)})
	return {
		"created": created,
		"skipped": skipped,
		"failed": failed,
		"message": _("{0} calculated, {1} already available, {2} failed.").format(len(created), len(skipped), len(failed)),
	}


def approve(computations):
	_require(APPROVE_ROLES, _("You are not permitted to approve Passage Benefit calculations."))
	computations = _as_list(computations, _("calculated result"))
	approved, skipped, failed = [], [], []
	for index, name in enumerate(computations, 1):
		savepoint = f"pb_guided_approve_{index}"
		frappe.db.savepoint(savepoint)
		try:
			frappe.db.sql("SELECT name FROM `tabPassage Benefit Computation` WHERE name=%s FOR UPDATE", name)
			doc = frappe.get_doc("Passage Benefit Computation", name)
			if doc.docstatus != 0:
				skipped.append({"name": name, "reason": _("The calculation is already submitted.")})
				continue
			if doc.workflow_status == "Approved":
				skipped.append({"name": name, "reason": _("Already approved.")})
				continue
			if (doc.workflow_status or "Calculated") != "Calculated":
				frappe.throw(_("Only calculated Passage Benefit rows can be approved."))
			doc.workflow_status = "Approved"
			doc.approved_by = frappe.session.user
			doc.approved_on = now_datetime()
			doc.save(ignore_permissions=True)
			doc.add_comment("Workflow", _("Passage Benefit calculation approved for PB Bank posting."))
			approved.append(name)
		except Exception as exc:
			frappe.db.rollback(save_point=savepoint)
			failed.append({"name": name, "error": str(exc)})
	return {
		"approved": approved,
		"skipped": skipped,
		"failed": failed,
		"message": _("{0} approved, {1} skipped, {2} failed.").format(len(approved), len(skipped), len(failed)),
	}


def _payroll_date(doc, payroll_cycle=None):
	cycle_name = payroll_cycle or doc.payroll_cycle
	cycle = None
	if cycle_name:
		cycle = frappe.db.get_value(
			"Payroll Cycle", cycle_name,
			["name", "company", "start_date", "end_date", "payment_date", "status"], as_dict=True,
		)
		if not cycle or cycle.status not in OPEN_PAYROLL_STATUSES:
			frappe.throw(_("Select an open Payroll Cycle before submitting Passage Benefit to payroll."))
		if cycle.company != frappe.db.get_value("Employee", doc.employee, "company"):
			frappe.throw(_("The Payroll Cycle company does not match employee {0}.").format(doc.employee))
		return cycle, getdate(cycle.payment_date or cycle.end_date)
	cycles = frappe.get_list(
		"Payroll Cycle",
		filters={
			"company": frappe.db.get_value("Employee", doc.employee, "company"),
			"status": ["in", OPEN_PAYROLL_STATUSES],
			"start_date": ["<=", doc.to_date],
			"end_date": [">=", doc.to_date],
		},
		fields=["name", "company", "start_date", "end_date", "payment_date", "status"],
		order_by="payment_date desc",
		limit_page_length=1,
	)
	if not cycles:
		frappe.throw(_("No open Payroll Cycle covers the Passage Benefit period."))
	return cycles[0], getdate(cycles[0].payment_date or cycles[0].end_date)


def submit_to_payroll(computations, payroll_cycle=None):
	_require(PAYROLL_ROLES, _("You are not permitted to submit Passage Benefits to payroll."))
	computations = _as_list(computations, _("approved result"))
	posted, skipped, failed = [], [], []
	for index, name in enumerate(computations, 1):
		savepoint = f"pb_guided_payroll_{index}"
		frappe.db.savepoint(savepoint)
		try:
			frappe.db.sql("SELECT name FROM `tabPassage Benefit Computation` WHERE name=%s FOR UPDATE", name)
			doc = frappe.get_doc("Passage Benefit Computation", name)
			if doc.additional_salary:
				skipped.append({"name": name, "reason": _("Already submitted to payroll."), "additional_salary": doc.additional_salary})
				continue
			if doc.docstatus != 0 or doc.workflow_status != "Approved":
				frappe.throw(_("Only approved, unsubmitted Passage Benefit calculations can be sent to payroll."))
			company = frappe.db.get_value("Employee", doc.employee, "company")
			mapping = _mapping(doc.to_date, company)
			cycle, payroll_date = _payroll_date(doc, payroll_cycle)
			if flt(doc.earned_amount) <= 0:
				frappe.throw(_("The calculated Passage Benefit amount must be greater than zero before payroll submission."))
			# Persist the resolved mapping first so the immutable Payroll Source Trace
			# captured by Additional Salary contains the exact PDB inputs used.
			doc.payroll_cycle = cycle.name
			doc.payroll_pdb_type = mapping.pdb_type
			doc.payroll_pdb_code = mapping.pdb_code
			doc.pdb_component = mapping.salary_component
			doc.save(ignore_permissions=True)
			additional = frappe.get_doc(
				{
					"doctype": "Additional Salary",
					"employee": doc.employee,
					"company": company,
					"salary_component": mapping.salary_component,
					"amount": flt(doc.earned_amount),
					"payroll_date": payroll_date,
					"overwrite_salary_structure_amount": 0,
					"ref_doctype": doc.doctype,
					"ref_docname": doc.name,
					"karyo_transaction_category": "Passage Benefit",
					"karyo_payroll_cycle": cycle.name,
				}
			)
			additional.insert(ignore_permissions=True)
			additional.submit()
			doc.additional_salary = additional.name
			doc.payroll_submitted_by = frappe.session.user
			doc.payroll_submitted_on = now_datetime()
			doc.workflow_status = "Submitted to Payroll"
			doc.save(ignore_permissions=True)
			doc.submit()
			posted.append({"name": name, "employee": doc.employee, "additional_salary": additional.name, "amount": doc.earned_amount})
		except Exception as exc:
			frappe.db.rollback(save_point=savepoint)
			failed.append({"name": name, "error": str(exc)})
	return {
		"posted": posted,
		"skipped": skipped,
		"failed": failed,
		"message": _("{0} submitted to payroll, {1} skipped, {2} failed.").format(len(posted), len(skipped), len(failed)),
	}


def submit_to_pb_bank(computations, payroll_cycle=None):
	"""Post approved accruals directly to PB Bank without creating payroll pay."""
	_require(PAYROLL_ROLES, _("You are not permitted to submit Passage Benefits to PB Bank."))
	computations = _as_list(computations, _("approved result"))
	posted, skipped, failed = [], [], []
	for index, name in enumerate(computations, 1):
		savepoint = f"pb_guided_bank_{index}"
		frappe.db.savepoint(savepoint)
		try:
			frappe.db.sql("SELECT name FROM `tabPassage Benefit Computation` WHERE name=%s FOR UPDATE", name)
			doc = frappe.get_doc("Passage Benefit Computation", name)
			ledger_entry = frappe.db.get_value(
				"Passage Benefit Ledger Entry",
				{
					"reference_doctype": doc.doctype,
					"reference_name": doc.name,
					"entry_type": "Earning",
					"docstatus": 1,
				},
				"name",
			)
			if doc.docstatus == 1 and ledger_entry:
				skipped.append({"name": name, "reason": _("Already posted to PB Bank."), "ledger_entry": ledger_entry})
				continue
			if doc.docstatus != 0 or doc.workflow_status != "Approved":
				frappe.throw(_("Only approved, unsubmitted Passage Benefit calculations can be posted to PB Bank."))
			if flt(doc.earned_amount) <= 0:
				frappe.throw(_("The calculated Passage Benefit amount must be greater than zero before PB Bank posting."))
			if payroll_cycle:
				doc.payroll_cycle = payroll_cycle
			doc.payroll_submitted_by = frappe.session.user
			doc.payroll_submitted_on = now_datetime()
			doc.workflow_status = "PB Bank Posted"
			doc.save(ignore_permissions=True)
			doc.submit()
			ledger_entry = frappe.db.get_value(
				"Passage Benefit Ledger Entry",
				{"reference_doctype": doc.doctype, "reference_name": doc.name, "entry_type": "Earning", "docstatus": 1},
				"name",
			)
			posted.append({
				"name": name,
				"employee": doc.employee,
				"ledger_entry": ledger_entry,
				"amount": doc.earned_amount,
			})
		except Exception as exc:
			frappe.db.rollback(save_point=savepoint)
			failed.append({"name": name, "error": str(exc)})
	return {
		"posted": posted,
		"skipped": skipped,
		"failed": failed,
		"message": _("{0} posted to PB Bank, {1} skipped, {2} failed.").format(len(posted), len(skipped), len(failed)),
	}
