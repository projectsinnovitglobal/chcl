"""Current leave entitlements and calendar for the signed-in employee."""
from calendar import isleap
from datetime import date, timedelta
import re

import frappe
from frappe import _
from frappe.utils import flt, nowdate, getdate, cint, get_first_day, get_last_day
from karyo.hr.clocking import _own_employee


LEAVE_BANK_REGISTERS = {
	"casual": {"title": "Casual Leave Bank", "codes": ("CASL01", "CASL02")},
	"vacation": {"title": "Vacation Leave Bank", "codes": ("ANN", "ANN01", "VAC01", "VAC02", "VAC03", "VAC04", "VAC05", "MISION", "TRN", "PL")},
	"sick": {"title": "Sick Leave Bank", "codes": ("SICK01", "SICK02", "SICK03", "SICK05", "SICK06", "SICK07", "COVID")},
	"advance-sick": {"title": "Advance Sick Leave Bank", "codes": ("SICK03", "SICK04")},
	"leave-without-pay": {"title": "Leave Without Pay Bank", "codes": ("LWP", "LWP01", "LWP02", "LWP03", "LWP04", "KLT", "ABS", "UNAU", "INT")},
	"injury": {"title": "Injury Leave Bank", "codes": ("INJ", "INJ1")},
	"maternity": {"title": "Maternity Leave Bank", "codes": ("MAT", "MAT2")},
	"paternity": {"title": "Paternity Leave Bank", "codes": ("PAT",)},
	"adoption": {"title": "Adoption Leave Bank", "codes": ("ADOPT",)},
	"study": {"title": "Study Leave Bank", "codes": ("STD", "LWP01", "EXAMS")},
}


def _current_fiscal_year(on_date=None):
	"""Return the fiscal period containing ``on_date`` with a safe calendar fallback."""
	on_date = getdate(on_date or nowdate())
	rows = frappe.get_all(
		"Fiscal Year",
		filters={
			"disabled": 0,
			"year_start_date": ("<=", on_date),
			"year_end_date": (">=", on_date),
		},
		fields=["name", "year_start_date", "year_end_date"],
		order_by="year_start_date desc",
		limit_page_length=1,
	)
	if rows:
		return rows[0]
	return frappe._dict(
		name=str(on_date.year),
		year_start_date=date(on_date.year, 1, 1),
		year_end_date=date(on_date.year, 12, 31),
	)


def vacation_accrual_snapshot(employee, on_date=None):
	"""Calculate the employee's current service-band Vacation accrual rate."""
	as_of = getdate(on_date or nowdate())
	profile = frappe.db.get_value(
		"Employee", employee, ["date_of_joining", "karyo_date_joined_service"], as_dict=True
	) or frappe._dict()
	joined = profile.karyo_date_joined_service or profile.date_of_joining
	service_years = max(0, (as_of - getdate(joined)).days / 365.2425) if joined else 0

	from karyo.prb.leave import vacation_accrual_band

	annual, ceiling = vacation_accrual_band(service_years)
	if frappe.db.exists("DocType", "MBC Leave Settings"):
		for band in frappe.get_cached_doc("MBC Leave Settings").vacation_leave_bands:
			upper = flt(band.service_to_years)
			if service_years >= flt(band.service_from_years) and (not upper or service_years <= upper):
				annual = flt(band.annual_entitlement_days)
				ceiling = flt(band.accumulation_ceiling_days)
				break
	days_in_year = 366 if isleap(as_of.year) else 365
	return frappe._dict({
		"as_of": as_of,
		"service_years": round(service_years, 2),
		"annual_accrual_days": annual,
		"days_in_year": days_in_year,
		"daily_accrual_days": round(annual / days_in_year, 6),
		"earned_to_date_days": round(annual * (as_of.timetuple().tm_yday / days_in_year), 4),
		"ceiling_days": ceiling,
	})


def _upcoming_leave_allocations(employee, as_of, fiscal_year, type_meta):
	"""Expose future submitted quotas without making them spendable early."""
	upcoming = frappe.get_all(
		"Leave Allocation",
		filters=[
			["Leave Allocation", "employee", "=", employee],
			["Leave Allocation", "docstatus", "=", 1],
			["Leave Allocation", "from_date", ">", as_of],
		],
		fields=[
			"name", "leave_type", "from_date", "to_date", "new_leaves_allocated",
			"total_leaves_allocated", "total_leaves_encashed", "carry_forward",
			"unused_leaves", "_user_tags",
		],
		order_by="from_date asc, creation asc",
		limit_page_length=50,
	)
	rows = []
	for allocation in upcoming:
		if allocation.leave_type not in type_meta:
			continue
		meta = type_meta[allocation.leave_type]
		total = flt(allocation.total_leaves_allocated or allocation.new_leaves_allocated)
		carry_days = flt(allocation.unused_leaves) if cint(allocation.carry_forward) else 0
		rows.append({
			"leave_type": allocation.leave_type,
			"leave_code": meta.get("karyo_mbc_leave_code"),
			"bank_type": meta.get("karyo_bank_type"),
			"total": total,
			"taken": flt(allocation.total_leaves_encashed),
			"pending": 0.0,
			"remaining": 0.0,
			"confirmed_remaining": 0.0,
			"expired": 0.0,
			"from_date": allocation.from_date,
			"to_date": allocation.to_date,
			"allocation": allocation.name,
			"available_from": allocation.from_date,
			"availability_status": _("Available from {0}").format(allocation.from_date),
			"source": "Upcoming Leave Allocation",
			"is_carry_forward": cint(bool(carry_days or allocation.carry_forward)),
			"carry_forward_days": carry_days,
			"tag": _("Carry Forward") if carry_days or allocation.carry_forward else None,
		})
	return rows


def leave_balances(employee, date=None, include_all_types=False):
	"""Ledger-backed entitlement, with pending requests reserved separately."""
	from hrms.hr.doctype.leave_application.leave_application import get_leave_details, get_leave_allocation_records, get_number_of_leave_days, get_manually_expired_leaves
	date = date or nowdate()
	as_of = getdate(date)
	fiscal_year = _current_fiscal_year(as_of)
	details = get_leave_details(employee, date).get("leave_allocation", {})
	periods = get_leave_allocation_records(employee, date)
	type_meta = {row.name: row for row in frappe.get_all(
		"Leave Type", filters={"karyo_is_retired": 0},
		fields=[
			"name", "karyo_mbc_leave_code", "karyo_bank_type",
			"karyo_eligible_gender", "karyo_max_days_per_application",
		], limit_page_length=0
	)}
	out = []
	for leave_type, detail in details.items():
		if leave_type not in type_meta:
			continue
		period = periods[leave_type]
		pending = 0.0
		requests = frappe.get_all("Leave Application", filters={"employee":employee,"leave_type":leave_type,"docstatus":0,"status":["in",["Open","Approved"]],"from_date":["<=",period.to_date],"to_date":[">=",period.from_date]},fields=["from_date","to_date","half_day","half_day_date","total_leave_days"])
		for request in requests:
			start, end = max(getdate(request.from_date),getdate(period.from_date)), min(getdate(request.to_date),getdate(period.to_date))
			if start == getdate(request.from_date) and end == getdate(request.to_date):
				pending += flt(request.total_leave_days)
			else:
				half = request.half_day and request.half_day_date and start <= getdate(request.half_day_date) <= end
				pending += max(0,flt(get_number_of_leave_days(employee,leave_type,start,end,cint(bool(half)),request.half_day_date)))
		# Native HRMS reads only the first manual-expiry entry and excludes the
		# allocation end date. Sum all posted expiry entries for these allocations.
		allocation_rows = frappe.get_all(
			"Leave Allocation",
			filters={"employee":employee,"leave_type":leave_type,"docstatus":1,"from_date":["<=",date],"to_date":[">=",date]},
			fields=["name", "carry_forward", "unused_leaves", "_user_tags"],
		)
		names = [row.name for row in allocation_rows]
		expiries = frappe.get_all("Leave Ledger Entry",filters={"transaction_type":"Leave Allocation","transaction_name":["in",names],"docstatus":1,"is_expired":1,"is_carry_forward":0},fields=["leaves"]) if names else []
		carry_entries = frappe.get_all("Leave Ledger Entry",filters={"transaction_type":"Leave Allocation","transaction_name":["in",names],"docstatus":1,"is_expired":0,"is_carry_forward":1},fields=["leaves"]) if names else []
		carry_days = sum(flt(row.leaves) for row in carry_entries)
		manual_expired = sum(flt(row.leaves) for row in expiries)
		native_expired = flt(get_manually_expired_leaves(employee,leave_type,period.from_date,period.to_date))
		from karyo.hr.lateness import posted_lateness_days
		lateness_taken = posted_lateness_days(employee, leave_type, period.from_date, date)
		from karyo.hr.leave_controls import casual_permission_balance_correction
		permission_correction = casual_permission_balance_correction(
			employee, leave_type, period.from_date, period.to_date
		)
		confirmed = flt(detail.get("remaining_leaves")) + permission_correction - native_expired + manual_expired - lateness_taken
		taken = max(0, flt(detail.get("leaves_taken")) - permission_correction) + lateness_taken
		expired = max(0,flt(detail.get("total_leaves"))-taken-confirmed)
		meta = type_meta.get(leave_type, frappe._dict())
		is_carry_forward = bool(carry_days)
		out.append({"leave_type":leave_type,"leave_code":meta.get("karyo_mbc_leave_code"),"bank_type":meta.get("karyo_bank_type"),"total":flt(detail.get("total_leaves")),"taken":taken,"pending":flt(pending),"remaining":max(0,flt(confirmed-pending)),"confirmed_remaining":confirmed,"expired":expired,"from_date":period.from_date,"to_date":period.to_date,"allocation":period.get("name"),"availability_status":_("Available now"),"is_carry_forward":cint(is_carry_forward),"carry_forward_days":carry_days,"tag":_("Carry Forward") if is_carry_forward else None})
	# Submitted quotas beginning later in the current financial year must be
	# visible to the employee before they become spendable. They are deliberately
	# excluded from the available counter until their effective date.
	out.extend(_upcoming_leave_allocations(employee, as_of, fiscal_year, type_meta))
	# Legacy closing balances remain visible until a native allocation for the
	# same governed code takes over. Later imported transactions reduce the
	# snapshot so the employee dashboard does not show a stale closing figure.
	if frappe.db.exists("DocType", "Leave Balance"):
		seen_codes = {row.get("leave_code") for row in out if row.get("leave_code")}
		snapshots = frappe.get_all(
			"Leave Balance", filters={
				"employee": employee, "as_at_date": ("<=", date), "is_system_synced": 0,
			},
			fields=["leave_code", "leave_type", "closing_balance", "as_at_date", "leave_year"],
			order_by="as_at_date desc, modified desc", limit_page_length=0,
		)
		latest = {}
		for snapshot in snapshots:
			latest.setdefault(snapshot.leave_code, snapshot)
		for code, snapshot in latest.items():
			if code in seen_codes:
				continue
			taken = 0.0
			if frappe.db.exists("DocType", "Leave Transaction"):
				taken = sum(flt(row.duration_units) for row in frappe.get_all(
					"Leave Transaction",
					filters={
						"employee": employee, "leave_code": code, "cancelled": 0,
						"legacy_status": ("in", ["Approved", "Taken", "Posted", "Completed", "Closed"]),
						"start_date": (">", snapshot.as_at_date), "end_date": ("<=", date),
					},
					fields=["duration_units"], limit_page_length=0,
				))
			closing = flt(snapshot.closing_balance)
			out.append({
				"leave_type": snapshot.leave_type, "leave_code": code, "bank_type": "Legacy Balance",
				"total": closing, "taken": taken, "pending": 0.0,
				"remaining": max(0, closing - taken), "confirmed_remaining": closing - taken,
				"expired": 0.0, "from_date": snapshot.as_at_date,
				"to_date": f"{cint(snapshot.leave_year)}-12-31", "source": "Leave Balance",
			})
	# Sick and Vacation banks are governed outside native Leave Allocation, but
	# employees need one consistent counter model everywhere. Add them as balance
	# rows while retaining their dedicated bank cards and avoiding code duplicates.
	seen_codes = {row.get("leave_code") for row in out if row.get("leave_code")}
	bank_rows = [
		("Sick Leave Bank", "SICK02", "Sick From Bank", "allotted_days", "taken_days", "available_days"),
		("Sick Leave Bank", "SICK03", "Advance Sick Leave Full Pay", "advance_allotted_days", "advance_balance_days", None),
		("Vacation Leave Bank", "VAC01", "Vacation Leave", "allotted_days", "taken_days", "available_days"),
	]
	for doctype, code, leave_type, allotted_field, taken_field, remaining_field in bank_rows:
		if code in seen_codes or not frappe.db.exists(doctype, {"employee": employee, "status": "Active"}):
			continue
		fields = [allotted_field, taken_field] + ([remaining_field] if remaining_field else [])
		bank = frappe.db.get_value(doctype, {"employee": employee}, fields, as_dict=True)
		allocated = flt(bank.get(allotted_field))
		taken = flt(bank.get(taken_field))
		remaining = flt(bank.get(remaining_field)) if remaining_field else max(0, allocated - taken)
		out.append({
			"leave_type": leave_type, "leave_code": code, "bank_type": doctype,
			"total": allocated, "taken": taken, "pending": 0.0,
			"remaining": remaining, "confirmed_remaining": remaining, "expired": 0.0,
			"from_date": f"{as_of.year}-01-01", "to_date": f"{as_of.year}-12-31",
			"source": doctype,
		})
		seen_codes.add(code)
	# Paternity is a conditional annual entitlement, not a Vacation Bank drawdown.
	# It is exposed only when the Employee satisfies the governed type-level rule.
	pat_meta = next((meta for meta in type_meta.values() if meta.karyo_mbc_leave_code == "PAT"), None)
	if pat_meta and "PAT" not in seen_codes:
		from karyo.hr.leave_controls import eligible_leave_types
		eligible = {row.name for row in eligible_leave_types(employee, as_of)}
		if pat_meta.name in eligible:
			period_start, period_end = f"{as_of.year}-01-01", f"{as_of.year}-12-31"
			approved = flt(frappe.db.get_value(
				"Leave Application",
				{
					"employee": employee, "leave_type": pat_meta.name, "docstatus": 1,
					"status": "Approved", "from_date": ("between", [period_start, period_end]),
				},
				"sum(total_leave_days)",
			))
			pending = flt(frappe.db.get_value(
				"Leave Application",
				{
					"employee": employee, "leave_type": pat_meta.name, "docstatus": 0,
					"status": ("in", ["Open", "Approved"]),
					"from_date": ("between", [period_start, period_end]),
				},
				"sum(total_leave_days)",
			))
			limit = flt(pat_meta.karyo_max_days_per_application)
			out.append({
				"leave_type": pat_meta.name, "leave_code": "PAT", "bank_type": "None",
				"total": limit, "taken": approved, "pending": pending,
				"remaining": max(0, limit - approved - pending),
				"confirmed_remaining": max(0, limit - approved), "expired": 0.0,
				"from_date": period_start, "to_date": period_end,
				"source": "Conditional entitlement",
				"depends_on": "Male · substantive (PERM) appointment · active employee",
			})
			seen_codes.add("PAT")
	if include_all_types:
		seen_types = {row.get("leave_type") for row in out}
		as_of = getdate(date)
		for leave_type, meta in sorted(type_meta.items(), key=lambda item: (item[1].get("karyo_mbc_leave_code") or "", item[0])):
			if leave_type in seen_types:
				continue
			out.append({
				"leave_type": leave_type,
				"leave_code": meta.get("karyo_mbc_leave_code"),
				"bank_type": meta.get("karyo_bank_type"),
				"total": 0.0, "taken": 0.0, "pending": 0.0,
				"remaining": 0.0, "confirmed_remaining": 0.0, "expired": 0.0,
				"from_date": f"{as_of.year}-01-01", "to_date": f"{as_of.year}-12-31",
				"source": "Leave Type",
			})
	# Carry the admin opening-balance audit reference with the same live rows shown
	# on ESS. The amount itself is already posted to the allocation/bank above;
	# these fields make that mapping visible without maintaining a second counter.
	if frappe.db.exists("DocType", "Leave Opening Balance"):
		openings = frappe.get_all(
			"Leave Opening Balance",
			filters={
				"employee": employee, "docstatus": 1,
				"balance_as_at_date": ("<", date), "allocation_to_date": (">=", date),
			},
			fields=[
				"name", "leave_type", "karyo_leave_code", "balance_days",
				"balance_as_at_date", "source_type", "source_organisation", "source_reference",
			],
			order_by="balance_as_at_date desc, modified desc", limit_page_length=0,
		)
		by_type = {row.leave_type: row for row in openings}
		by_code = {row.karyo_leave_code: row for row in openings if row.karyo_leave_code}
		for balance in out:
			opening = by_type.get(balance.get("leave_type")) or by_code.get(balance.get("leave_code"))
			if not opening:
				continue
			balance.update({
				"opening_balance": flt(opening.balance_days),
				"opening_balance_as_at": opening.balance_as_at_date,
				"opening_balance_source": opening.source_type,
				"opening_balance_organisation": opening.source_organisation,
				"opening_balance_reference": opening.source_reference,
				"opening_balance_record": opening.name,
			})
	accrual = vacation_accrual_snapshot(employee, as_of)
	for balance in out:
		if balance.get("leave_code") == "VAC01":
			balance.update(accrual)
	return out


@frappe.whitelist()
def my_leaves():
	person = _own_employee(required=True)
	return {"employee": person.name, "as_of": nowdate(), "balances": leave_balances(person.name)}


def _month_bounds(month=None):
	"""Return a validated calendar month and its inclusive bounds."""
	month = month or getdate(nowdate()).strftime("%Y-%m")
	if not re.fullmatch(r"\d{4}-\d{2}", str(month)):
		frappe.throw(_("Choose a valid month."))
	try:
		anchor = getdate(f"{month}-01")
	except (TypeError, ValueError):
		frappe.throw(_("Choose a valid month."))
	if anchor.strftime("%Y-%m") != month:
		frappe.throw(_("Choose a valid month."))
	return month, getdate(get_first_day(anchor)), getdate(get_last_day(anchor))


def _calendar_time(value):
	if value in (None, ""):
		return None
	parts = str(value).split(".", 1)[0].split(":")
	if len(parts) < 2:
		return str(value)
	return f"{int(parts[0]):02d}:{int(parts[1]):02d}"


def _calendar_attendance(person, start, end):
	"""Own saved/live attendance represented as explicit day events."""
	from karyo.hr.attendance_rules import display_status
	from karyo.hr.clocking import attendance_clock_view

	rows = frappe.get_all(
		"Attendance",
		filters={
			"employee": person.name,
			"attendance_date": ("between", [start, end]),
			"docstatus": 1,
		},
		fields=[
			"name", "attendance_date", "status", "shift", "late_entry",
			"attendance_request", "karyo_is_corrected", "custom_entry_source",
		],
		order_by="attendance_date asc, name asc",
		limit_page_length=100,
	)
	clock = attendance_clock_view(
		[row.name for row in rows], from_date=start, to_date=end
	)
	by_name = {row.name: row for row in rows}
	for row in clock["live_rows"]:
		if row.employee == person.name:
			by_name.setdefault(row.name, row)

	events = []
	present_days = 0
	absent_days = 0
	for row in sorted(by_name.values(), key=lambda value: (getdate(value.attendance_date), value.name)):
		metrics = clock["records"].get(row.name, {})
		status = metrics.get("status") or display_status(
			row.status,
			metrics.get("clock_in_status"),
			row.get("late_entry"),
			confirmed_present=bool(
				row.get("attendance_request")
				or row.get("karyo_is_corrected")
				or row.get("custom_entry_source") in {"Manual Input", "Attendance Import"}
			),
		)
		detail_status = status
		# The calendar is a day-level answer, not a clock-quality report. Preserve
		# the detailed timing state for the linked Attendance page, while showing
		# employees the clear Present/Absent result they expect on each date.
		if status == "Awaiting Clock In" and getdate(row.attendance_date) < getdate(nowdate()):
			status = "Absent"
		present = status in {"Present", "On-time", "Late", "Work From Home", "Half Day"}
		present_days += 0.5 if status == "Half Day" else int(present)
		absent_days += int(status == "Absent")
		day_status = "Present" if present else status
		events.append({
			"date": getdate(row.attendance_date),
			"title": _(day_status),
			"type": "attendance",
			"attendance_status": day_status,
			"detail": _("Attendance · {0}").format(_(detail_status)),
			"route": f"/app/my-attendance/{row.name}" if not row.get("__clock_live") else "/app/my-attendance",
		})
	return events, {"present": present_days, "absent": absent_days}


def _calendar_roster(person, employee, start, end, holiday_dates):
	"""Resolve every day of the month to duty/rest/unassigned plus authorities."""
	from karyo.hr.roster import employee_duty

	authorities = frappe.get_all(
		"PRB Overtime Authorization",
		filters={
			"employee": person.name,
			"docstatus": 1,
			"planned_start": ("<=", f"{end} 23:59:59"),
			"planned_end": (">=", f"{start} 00:00:00"),
		},
		fields=[
			"name", "claim_type", "authorization_status", "planned_start", "planned_end",
			"planned_hours", "approved_hours", "shift_type", "authority_reference",
		],
		order_by="planned_start asc, name asc",
		limit_page_length=100,
	)
	by_day = {}
	for authority in authorities:
		by_day.setdefault(getdate(authority.planned_start), []).append(authority)

	days = []
	for offset in range((end - start).days + 1):
		day = start + timedelta(days=offset)
		day_authorities = by_day.get(day, [])
		try:
			duty = employee_duty(person.name, day)
			roster_error = None
		except frappe.ValidationError as error:
			duty = None
			roster_error = str(error)

		additional = []
		for authority in day_authorities:
			hours = flt(authority.approved_hours or authority.planned_hours)
			additional.append({
				"name": authority.name,
				"type": authority.claim_type,
				"status": authority.authorization_status,
				"hours": hours,
				"assigned_hours": flt(authority.planned_hours),
				"start": str(authority.planned_start),
				"end": str(authority.planned_end),
				"shift": authority.shift_type,
				"reference": authority.authority_reference,
			})
		if day in holiday_dates and not day_authorities:
			duty = None

		if roster_error:
			label = _("Roster conflict")
		elif day in holiday_dates and not day_authorities:
			label = _("Rest / holiday")
		elif duty and duty.get("is_rest_day"):
			label = _("Rest / roster day")
		elif duty:
			label = duty.shift_type
		else:
			label = _("No shift assigned")
		days.append({
			"date": day,
			"label": label,
			"shift_type": duty.shift_type if duty else None,
			"shift_code": duty.shift_code if duty else None,
			"start_time": _calendar_time(duty.start_time) if duty else None,
			"end_time": _calendar_time(duty.end_time) if duty else None,
			"duty_hours": flt(duty.duty_hours) if duty else 0,
			"assignment": duty.assignment if duty else None,
			"schedule": duty.schedule if duty else None,
			"location": duty.shift_location if duty else None,
			"source": _(duty.source) if duty and duty.get("source") else None,
			"is_rest_day": bool(day in holiday_dates and not day_authorities) or bool(duty and duty.get("is_rest_day")),
			"error": roster_error,
			"additional_duties": additional,
		})
	return days


@frappe.whitelist()
def my_calendar(month=None):
	"""Current employee calendar without exposing colleague birth years."""
	person = _own_employee(required=True)
	month, start, end = _month_bounds(month)
	employee = frappe.db.get_value(
		"Employee", person.name,
		["employee_name", "company", "default_shift", "karyo_work_pattern", "karyo_employee_group"],
		as_dict=True,
	)
	events = []
	holiday_dates = set()

	from erpnext.setup.doctype.employee.employee import get_holiday_list_for_employee

	holiday_list = get_holiday_list_for_employee(person.name, raise_exception=False)
	if holiday_list:
		for holiday in frappe.get_all(
			"Holiday",
			filters={
				"parent": holiday_list,
				"parenttype": "Holiday List",
				"holiday_date": ["between", [start, end]],
			},
			fields=["holiday_date", "description", "weekly_off"],
			order_by="holiday_date asc",
		):
			holiday_dates.add(getdate(holiday.holiday_date))
			events.append(
				{
					"date": holiday.holiday_date,
					"title": holiday.description or _("Holiday"),
					"type": "weekly_off" if holiday.weekly_off else "holiday",
					"detail": _("Weekly off") if holiday.weekly_off else _("Holiday"),
				}
			)

	# A birthday calendar is a shared company event. Return only the display name
	# and the occurrence in this month; never expose the stored date/year of birth.
	if employee.company:
		birthdays = frappe.db.sql(
			"""select name, employee_name, day(date_of_birth) as birth_day
			from `tabEmployee`
			where status='Active' and company=%s and date_of_birth is not null
				and month(date_of_birth)=%s
			order by birth_day, employee_name""",
			(employee.company, start.month),
			as_dict=True,
		)

		for birthday in birthdays:
			try:
				occurrence = date(start.year, start.month, int(birthday.birth_day))
			except ValueError:
				continue
			events.append(
				{
					"date": occurrence,
					"title": birthday.employee_name,
					"type": "birthday",
					"detail": _("Birthday"),
					"is_own": birthday.name == person.name,
				}
			)

	attendance_events, attendance_summary = _calendar_attendance(person, start, end)
	events.extend(attendance_events)
	roster_days = _calendar_roster(person, employee, start, end, holiday_dates)

	for leave in frappe.get_all(
		"Leave Application",
		filters={
			"employee": person.name,
			"docstatus": 1,
			"status": "Approved",
			"from_date": ["<=", end],
			"to_date": [">=", start],
		},
		fields=["name", "leave_type", "from_date", "to_date"],
		order_by="from_date asc",
	):
		events.append(
			{
				"date": max(getdate(leave.from_date), start),
				"end_date": min(getdate(leave.to_date), end),
				"title": leave.leave_type,
				"type": "leave",
				"detail": _("My approved leave"),
				"route": f"/app/leave-application/{leave.name}",
			}
		)

	events.sort(key=lambda row: (getdate(row["date"]), row["type"], row["title"] or ""))
	return {
		"employee": person.name,
		"employee_name": employee.employee_name,
		"work_pattern": employee.karyo_work_pattern,
		"month": month,
		"month_label": start.strftime("%B %Y"),
		"start_date": start,
		"end_date": end,
		"holiday_list": holiday_list,
		"events": events,
		"attendance_summary": attendance_summary,
		"roster_days": roster_days,
		"roster_summary": {
			"scheduled": sum(bool(row["shift_type"]) and not row["is_rest_day"] for row in roster_days),
			"additional": sum(len(row["additional_duties"]) for row in roster_days),
		},
	}


@frappe.whitelist()
def my_roster(month=None):
	"""Employee-scoped monthly duty roster from the same source used by clocking.

	Every calendar date is returned, including rest/unassigned days. Approved
	leave and submitted additional-hours authorities are overlaid without copying
	shift data into a second ESS-specific register.
	"""
	person = _own_employee(required=True)
	month, start, end = _month_bounds(month)
	employee = frappe.db.get_value(
		"Employee", person.name,
		["employee_name", "company", "default_shift", "karyo_work_pattern", "karyo_employee_group"],
		as_dict=True,
	) or frappe._dict()

	holiday_dates = set()
	holiday_labels = {}
	from erpnext.setup.doctype.employee.employee import get_holiday_list_for_employee
	holiday_list = get_holiday_list_for_employee(person.name, raise_exception=False)
	if holiday_list:
		for holiday in frappe.get_all(
			"Holiday",
			filters={
				"parent": holiday_list, "parenttype": "Holiday List",
				"holiday_date": ("between", [start, end]),
			},
			fields=["holiday_date", "description", "weekly_off"],
			order_by="holiday_date asc",
		):
			day = getdate(holiday.holiday_date)
			holiday_dates.add(day)
			holiday_labels[day] = holiday.description or (_("Weekly off") if holiday.weekly_off else _("Holiday"))

	days = _calendar_roster(person, employee, start, end, holiday_dates)
	leaves = frappe.get_all(
		"Leave Application",
		filters={
			"employee": person.name, "docstatus": 1, "status": "Approved",
			"from_date": ("<=", end), "to_date": (">=", start),
		},
		fields=["name", "leave_type", "from_date", "to_date", "half_day", "half_day_date"],
		order_by="from_date asc, name asc",
	)
	leave_by_date = {}
	for leave in leaves:
		day = max(getdate(leave.from_date), start)
		leave_end = min(getdate(leave.to_date), end)
		while day <= leave_end:
			leave_by_date.setdefault(day, []).append({
				"name": leave.name, "leave_type": leave.leave_type,
				"half_day": bool(leave.half_day and getdate(leave.half_day_date or leave.from_date) == day),
			})
			day += timedelta(days=1)

	additional_hours = {"Overtime": 0.0, "Night Duty": 0.0, "Excess Hours": 0.0}
	for row in days:
		day = getdate(row["date"])
		row["holiday"] = holiday_labels.get(day)
		row["leave"] = leave_by_date.get(day, [])
		for duty in row["additional_duties"]:
			additional_hours.setdefault(duty["type"], 0.0)
			additional_hours[duty["type"]] += flt(duty.get("assigned_hours") or duty.get("hours"))

	from karyo.hr.clocking import _clock_access
	clock_access = _clock_access(person.name) if start <= getdate(nowdate()) <= end else None
	return {
		"employee": person.name,
		"employee_name": employee.employee_name,
		"work_pattern": employee.karyo_work_pattern,
		"default_shift": employee.default_shift,
		"holiday_list": holiday_list,
		"month": month,
		"month_label": start.strftime("%B %Y"),
		"start_date": start,
		"end_date": end,
		"days": days,
		"clock_access": clock_access,
		"summary": {
			"scheduled": sum(bool(row["shift_type"]) and not row["is_rest_day"] for row in days),
			"rest": sum(bool(row["is_rest_day"]) for row in days),
			"hours": sum(flt(row["duty_hours"]) for row in days if not row["is_rest_day"]),
			"additional": sum(len(row["additional_duties"]) for row in days),
			"additional_hours": additional_hours,
			"approved_leave_days": sum(bool(row["leave"]) for row in days),
		},
	}


@frappe.whitelist()
def my_leave_bank():
	"""Allocated leave and bank counters for the signed-in employee only."""
	person = _own_employee(required=True)
	from karyo.hr.leave_controls import RULE_FIELDS, _employee, _employee_leave_schemes, _leave_eligibility
	from karyo.karyo.doctype.sick_leave_bank.sick_leave_bank import balance_snapshot
	fiscal_year = _current_fiscal_year()
	balances = leave_balances(person.name)
	type_rows = frappe.get_all(
		"Leave Type", filters={"karyo_is_retired": 0},
		fields=["name", "karyo_code_description", "karyo_is_retired", "is_lwp", *RULE_FIELDS],
		order_by="karyo_mbc_leave_group asc, karyo_mbc_leave_code asc, name asc",
		limit_page_length=0,
	)
	employee_row = _employee(person.name)
	types = []
	for row in type_rows:
		eligibility = _leave_eligibility(
			person.name, row.name, balances=balances, person=employee_row,
			rules=row, type_row=row, calculate_days=False,
		)
		types.append({
			"leave_type": row.name, "leave_code": row.karyo_mbc_leave_code,
			"description": row.karyo_code_description, "bank_type": row.karyo_bank_type,
			"deducts_from": row.karyo_deducts_from_leave_type,
			"annual_entitlement": row.karyo_annual_entitlement_days,
			"max_days": row.karyo_max_days_per_application,
			"attachment_after": row.karyo_medical_certificate_after_days,
			"eligible": cint(eligibility.eligible),
			"eligibility_reason": eligibility.reason,
			"available": eligibility.available,
		})
	transactions = []
	if frappe.db.exists("DocType", "Leave Transaction"):
		transactions = frappe.get_all(
			"Leave Transaction", filters={"employee": person.name},
			fields=[
				"leave_request_id", "leave_code", "start_date", "end_date", "duration_units",
				"duration_unit", "two_hour_permission", "requested_hours",
				"standard_day_hours", "equivalent_leave_days", "legacy_status", "cancelled",
			],
			order_by="start_date desc, modified desc", limit_page_length=20,
		)
	from karyo.hr.leave_encashment import encashment_summary
	vacation_bank = frappe.db.get_value(
		"Vacation Leave Bank", {"employee": person.name},
		["allotted_days", "taken_days", "available_days", "balance_days", "ceiling_days"], as_dict=True,
	)
	accrual = vacation_accrual_snapshot(person.name)
	if vacation_bank:
		vacation_bank.update({**accrual, "ceiling_days": vacation_bank.ceiling_days or accrual.ceiling_days})
	return {
		"employee": person.name,
		"employee_name": person.employee_name,
		"as_of": nowdate(),
		"fiscal_year": fiscal_year,
		"scheme": frappe.db.get_value("Employee", person.name, "karyo_leave_scheme"),
		"schemes": _employee_leave_schemes(person.name),
		"allocations": balances,
		"sick_leave_bank": balance_snapshot(person.name, balances=balances),
		"vacation_leave_bank": vacation_bank,
		"vacation_accrual": accrual,
		"transactions": transactions,
		"encashment": encashment_summary(person.name),
		"leave_types": types,
	}


@frappe.whitelist()
def employee_advance_currency():
	"""Expose only the signed-in employee's applicable advance currency."""
	person = _own_employee(required=True)
	assignment = frappe.get_all("Salary Structure Assignment", filters={"employee":person.name,"docstatus":1,"from_date":["<=",nowdate()]}, fields=["currency"], order_by="from_date desc", limit_page_length=1)
	currency = assignment[0].currency if assignment else None
	if not currency:
		company = frappe.db.get_value("Employee",person.name,"company")
		currency = frappe.db.get_value("Company",company,"default_currency")
	return {"employee":person.name,"currency":currency}


@frappe.whitelist()
def leave_applications(status="Pending"):
	"""Permission-filtered application box, including closed decisions."""
	states = {"Pending":"Open", "Approved":"Approved", "Rejected":"Rejected", "Cancelled":"Cancelled", "All":None}
	if status not in states:
		frappe.throw("Invalid leave status")
	filters = {"status":states[status]} if states[status] else {}
	or_filters = None
	if status == "Cancelled":
		filters = {}
		or_filters = [["Leave Application", "docstatus", "=", 2], ["Leave Application", "status", "=", "Cancelled"]]
	elif status != "All":
		filters["docstatus"] = ["<",2]
	return frappe.get_list("Leave Application", filters=filters, or_filters=or_filters,
		fields=["name","employee_name","leave_type","from_date","to_date","total_leave_days","status","docstatus"],
		order_by="modified desc", limit_page_length=100)


def notify_employee_request(doc, method=None):
	"""Deliver committed changes to the owner even without broad list subscriptions."""
	employee = doc.get("employee") or (doc.get("raised_by") if doc.doctype == "Employee Grievance" else None)
	user = frappe.db.get_value("Employee", employee, "user_id") if employee else None
	if user:
		frappe.publish_realtime("karyo_employee_request_updated",{"doctype":doc.doctype,"name":doc.name},user=user,after_commit=True)


@frappe.whitelist()
def allocation_balances(employee=None, start=0, page_length=20):
	"""Current allocation table for permitted employees, paged by employee."""
	filters = {"docstatus":1,"from_date":["<=",nowdate()],"to_date":[">=",nowdate()]}
	if employee: filters["employee"] = employee
	start, page_length = max(0,cint(start)), min(50,max(1,cint(page_length)))
	if employee:
		people = frappe.get_list(
			"Employee", filters={"name": employee}, fields=["name as employee", "employee_name"],
			start=0, page_length=1,
		)
	else:
		people = frappe.get_list("Leave Allocation",filters=filters,fields=["employee","employee_name"],group_by="employee, employee_name",order_by="employee asc",start=start,page_length=page_length+1)
	rows = []
	for person in people[:page_length]:
		allocated = set(frappe.get_list(
			"Leave Allocation", filters={**filters, "employee": person.employee},
			pluck="leave_type", limit_page_length=0,
		))
		rows.extend(
			{**balance, "employee": person.employee, "employee_name": person.employee_name}
			for balance in leave_balances(person.employee)
			if balance.get("leave_type") in allocated
		)
	return {"balances":rows,"has_more":len(people)>page_length,"start":start,"as_of":nowdate()}


@frappe.whitelist()
def leave_bank_register(bank_key):
	"""Employee-level allocation, usage and remaining balance for one leave bank."""
	frappe.has_permission("Leave Allocation", "read", throw=True)
	config = LEAVE_BANK_REGISTERS.get(bank_key)
	if not config:
		frappe.throw(_("Unknown Leave Bank."))
	types = frappe.get_all(
		"Leave Type", filters={"karyo_mbc_leave_code": ("in", config["codes"])},
		fields=["name", "karyo_mbc_leave_code", "karyo_code_description"],
		order_by="karyo_mbc_leave_code asc", limit_page_length=0,
	)
	type_by_name = {row.name: row for row in types}
	current = nowdate()
	allocation_rows = frappe.get_list(
		"Leave Allocation",
		filters={
			"docstatus": 1, "leave_type": ("in", list(type_by_name)),
			"from_date": ("<=", current), "to_date": (">=", current),
		},
		fields=["employee", "employee_name", "leave_type"],
		order_by="employee asc, leave_type asc", limit_page_length=0,
	)
	people = {}
	for allocation in allocation_rows:
		people[allocation.employee] = allocation.employee_name
	rows = []
	for employee, employee_name in people.items():
		balances = {row["leave_type"]: row for row in leave_balances(employee)}
		for leave_type in sorted({row.leave_type for row in allocation_rows if row.employee == employee}):
			balance = balances.get(leave_type)
			meta = type_by_name.get(leave_type)
			if not balance or not meta:
				continue
			rows.append({
				"leave_code": meta.karyo_mbc_leave_code,
				"leave_type": leave_type,
				"leave_description": meta.karyo_code_description,
				"employee": employee,
				"employee_name": employee_name,
				"from_date": balance.get("from_date"), "to_date": balance.get("to_date"),
				"allocated": flt(balance.get("total")), "taken": flt(balance.get("taken")),
				"pending": flt(balance.get("pending")), "expired": flt(balance.get("expired")),
				"remaining": flt(balance.get("remaining")),
			})

	# Vacation and sick banks are maintained outside native allocations. Include
	# their employee records in the same register so the bank menu remains complete.
	bank_sources = []
	if bank_key == "vacation":
		bank_sources = [("Vacation Leave Bank", "VAC01", "Vacation Leave", "allotted_days", "taken_days", "available_days")]
	elif bank_key == "sick":
		bank_sources = [
			("Sick Leave Bank", "SICK02", "Sick From Bank", "allotted_days", "taken_days", "available_days"),
			("Sick Leave Bank", "SICK03", "Advance Sick Leave Full Pay", "advance_allotted_days", "advance_balance_days", None),
		]
	elif bank_key == "advance-sick":
		bank_sources = [("Sick Leave Bank", "SICK03", "Advance Sick Leave Full Pay", "advance_allotted_days", "advance_balance_days", None)]
	elif bank_key == "paternity":
		for person in frappe.get_list(
			"Employee", filters={"status": "Active", "gender": "Male", "karyo_employment_category": "PERM"},
			fields=["name as employee", "employee_name"], order_by="name asc", limit_page_length=0,
		):
			balance = next((row for row in leave_balances(person.employee) if row.get("leave_code") == "PAT"), None)
			if not balance:
				continue
			rows.append({
				"leave_code": "PAT", "leave_type": balance["leave_type"],
				"leave_description": frappe.db.get_value("Leave Type", balance["leave_type"], "karyo_code_description") or balance["leave_type"],
				"employee": person.employee, "employee_name": person.employee_name,
				"from_date": balance["from_date"], "to_date": balance["to_date"],
				"allocated": flt(balance["total"]), "taken": flt(balance["taken"]),
				"pending": flt(balance["pending"]), "expired": 0.0,
				"remaining": flt(balance["remaining"]),
				"depends_on": balance.get("depends_on"),
			})
	for bank_source in bank_sources:
		doctype, code, leave_type, allocated_field, taken_field, remaining_field = bank_source
		existing = {(row["employee"], row["leave_code"]) for row in rows}
		fields = ["employee", "employee_name", "status", taken_field]
		for field in (allocated_field, remaining_field):
			if field:
				fields.append(field)
		for bank in frappe.get_list(doctype, filters={"status": "Active"}, fields=list(dict.fromkeys(fields)), order_by="employee asc", limit_page_length=0):
			if (bank.employee, code) in existing:
				continue
			taken = flt(bank.get(taken_field))
			allocated = flt(bank.get(allocated_field)) if allocated_field else 180.0
			remaining = flt(bank.get(remaining_field)) if remaining_field else max(0, allocated - taken)
			rows.append({
				"leave_code": code, "leave_type": leave_type,
				"leave_description": frappe.db.get_value("Leave Type", leave_type, "karyo_code_description") or leave_type,
				"employee": bank.employee, "employee_name": bank.employee_name,
				"from_date": f"{getdate(current).year}-01-01", "to_date": f"{getdate(current).year}-12-31",
				"allocated": allocated, "taken": taken, "pending": 0.0,
				"expired": 0.0, "remaining": remaining,
			})
	rows.sort(key=lambda row: (row["leave_code"] or "", row["employee"] or ""))
	return {
		"key": bank_key, "title": _(config["title"]), "codes": list(config["codes"]),
		"as_of": current, "rows": rows,
		"assumption": _(
			"Assumption: the 180 days shown is the maximum full-pay Advance Sick facility per recoverable cycle, not an annual credit. It is available only after normal Sick Leave and the Sick Leave Bank are exhausted; another full-pay advance is allowed only after the outstanding advance is fully recovered. Recovery is up to 14 unused Sick Leave days per year."
			" Half-pay Advance Sick is a separate maximum of 180 days and starts only after the full-pay facility is exhausted."
		) if bank_key in ("sick", "advance-sick") else _(
			"Paternity Leave is available only to an active male officer holding a substantive (PERM) appointment. It provides up to 10 working days on full pay in a calendar year and does not deduct from a leave bank."
		) if bank_key == "paternity" else None,
		"summary": {
			"employees": len({row["employee"] for row in rows}),
			"allocated": sum(flt(row["allocated"]) for row in rows),
			"taken": sum(flt(row["taken"]) for row in rows),
			"pending": sum(flt(row["pending"]) for row in rows),
			"remaining": sum(flt(row["remaining"]) for row in rows),
		},
	}


def publish_balance_update(doc, method=None):
	"""Refresh all counter views after commit, without broadcasting employee data."""
	if doc.doctype.startswith("Leave") or doc.doctype in (
		"Sick Leave Bank", "Sick Leave Bank Posting", "Vacation Leave Bank", "Vacation Leave Posting",
	):
		types = [
			"Leave Balance", "Leave Transaction", "Leave Allocation", "Leave Application",
			"Leave Ledger Entry", "Sick Leave Bank", "Sick Leave Bank Posting",
			"Vacation Leave Bank", "Vacation Leave Posting",
		]
	else:
		types = ["Passage Benefit Bank","Passage Benefit Application","Passage Benefit Ledger Entry","Passage Benefit Computation","Passage Benefit Adjustment","Passage Benefit Computation Run"]
	payload = {"doctypes":types}
	from frappe.realtime import get_doctype_room
	frappe.publish_realtime("karyo_balance_updated",payload,room=get_doctype_room(types[0]),after_commit=True)
	employee = doc.get("employee")
	user = frappe.db.get_value("Employee", employee, "user_id") if employee else None
	if user:
		frappe.publish_realtime("karyo_balance_updated",payload,user=user,after_commit=True)
