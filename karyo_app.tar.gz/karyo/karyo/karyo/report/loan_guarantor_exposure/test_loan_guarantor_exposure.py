from unittest.mock import patch
import frappe
from frappe.model.naming import set_new_name
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.doctype.karyo_loan_settlement import test_karyo_loan_settlement as loan_helpers
from karyo.karyo.report.loan_guarantor_exposure.loan_guarantor_exposure import execute


class TestLoanGuarantorExposure(FrappeTestCase):
	_assign_salary_structure = loan_helpers.TestKaryoLoanSettlement._assign_salary_structure
	_activate_loan = loan_helpers.TestKaryoLoanSettlement._activate_loan

	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		cls.company = frappe.db.get_value("Company", {}, "name")
		if cls.company and not frappe.db.exists("Loan Type", "PERSONAL"):
			frappe.get_doc(
				{
					"doctype": "Loan Type",
					"loan_code": "PERSONAL",
					"loan_name": "Personal Loan",
					"loan_category": "Personal",
					"interest_rate": 6,
					"is_active": 1,
				}
			).insert(ignore_permissions=True)

	def setUp(self):
		frappe.db.set_single_value("Karyo Settings", "require_appraisal_payroll_cycle", 0)
		approval_clock=patch("karyo.karyo.doctype.karyo_loan.karyo_loan.now_datetime", return_value=frappe.utils.get_datetime("2026-06-01 09:00:00"))
		approval_clock.start();self.addCleanup(approval_clock.stop)
		if not self.company:
			self.skipTest("no Company on site")
		frappe.db.set_single_value("Karyo Settings", "max_deduction_pct", 40)
		frappe.db.set_value("Loan Type", "PERSONAL", {"pdb_capital": "Karyo Loan Capital", "pdb_interest": "Karyo Loan Interest", "pdb_insurance": "Karyo Loan Insurance"}, update_modified=False)
		self.emp = self._employee("Exposure", "Borrower")
		self.guarantor = self._employee("Exposure", "Guarantor")
		self._assign_salary_structure(self.emp.name)
		self._assign_salary_structure(self.guarantor.name)
		self.loan = self._activate_loan()
		self.loan.db_set("outstanding_capital", 70000)
		self.loan.db_set("outstanding_interest", 1200)
		self.loan.db_set("outstanding_insurance", 300)
		self._attach_guarantor(self.loan.name, self.guarantor.name)

	def _employee(self, first_name, last_name):
		return frappe.get_doc(
			{
				"doctype": "Employee",
				"first_name": first_name,
				"last_name": last_name,
				"gender": frappe.db.get_value("Gender", {}, "name") or "Male",
				"date_of_birth": "1985-01-01",
				"date_of_joining": "2016-01-01",
				"company": self.company,
				"status": "Active",
			}
		).insert(ignore_permissions=True, ignore_mandatory=True)

	def _attach_guarantor(self, loan, guarantor):
		row = frappe.get_doc(
			{
				"doctype": "Karyo Loan Guarantor",
				"parent": loan,
				"parenttype": "Karyo Loan",
				"parentfield": "guarantors",
				"guarantor": guarantor,
				"guarantor_name": frappe.db.get_value("Employee", guarantor, "employee_name"),
				"guarantor_status": frappe.db.get_value("Employee", guarantor, "status"),
			}
		)
		set_new_name(row)
		row.db_insert()

	def test_active_exposure_contains_borrower_loan_and_component_totals(self):
		columns, rows = execute({"guarantor": self.guarantor.name, "active_only": 1})
		self.assertTrue({"guarantor", "borrower", "loan", "active_exposure"}.issubset({c["fieldname"] for c in columns}))
		self.assertEqual(len(rows), 1)
		row = rows[0]
		self.assertEqual(row.loan, self.loan.name)
		self.assertEqual(row.borrower, self.emp.name)
		self.assertEqual(row.active_guarantee_count, 1)
		self.assertEqual(row.guaranteed_amount, 71500)
		self.assertEqual(row.active_exposure, 71500)
		self.assertEqual(row.exposure_status, "Active")

	def test_active_only_and_borrower_filters(self):
		self.loan.db_set("status", "Settled")
		_columns, active_rows = execute({"guarantor": self.guarantor.name, "active_only": 1})
		self.assertEqual(active_rows, [])

		_columns, settled_rows = execute(
			{"guarantor": self.guarantor.name, "borrower": self.emp.name, "active_only": 0, "loan_status": "Settled"}
		)
		self.assertEqual(len(settled_rows), 1)
		self.assertEqual(settled_rows[0].loan_status, "Settled")
		self.assertEqual(settled_rows[0].active_guarantee_count, 0)
		self.assertEqual(settled_rows[0].active_exposure, 0)
		self.assertEqual(settled_rows[0].exposure_status, "Inactive")
