import json
import unittest

from karyo.setup.pb_setup_rules import (
	DATA_FILE,
	ENTITLEMENT_OPERATION,
	_load_gspb_source,
	_load_source,
	_unique_gspb_rows,
)


class TestPBSetupRules(unittest.TestCase):
	def test_sheet_snapshot_excludes_sample_and_captures_every_real_rule(self):
		payload = _load_source()
		self.assertEqual(payload["workbook_title"], "PB-Setup")
		self.assertEqual(payload["sheet"], "Sheet2")
		self.assertEqual(payload["range"], "A1:G17")
		self.assertEqual(payload["excluded_rows"], [4])
		self.assertEqual(len(payload["rules"]), 13)
		self.assertEqual({row["sheet_row"] for row in payload["rules"]}, set(range(5, 18)))

	def test_required_values_match_the_source_rules(self):
		payload = _load_source()
		rules = {row["parameter"]: row for row in payload["rules"]}
		self.assertIn("37,290", rules["Salary threshold"]["rule"])
		self.assertIn("5 years", rules["Service threshold"]["rule"])
		self.assertIn("confirmation date", rules["Eligible from date"]["rule"])
		self.assertEqual(rules["Annual salary basis"]["related_operation_pdb"], f"{ENTITLEMENT_OPERATION} where salary basis applies")
		self.assertEqual(json.loads(DATA_FILE.read_text())["header_row"], 3)

	def test_current_gspb_sheet_snapshot_excludes_sample_and_deduplicates_c26(self):
		payload = _load_gspb_source()
		self.assertEqual(payload["workbook_title"], "Passage-Benefit")
		self.assertEqual(payload["sheet"], "Sheet1")
		self.assertIn("1BIic6ZGzoKm7u1q4pqwWDr9BHVarVofGdi1OjabBAuw", payload["source_url"])
		self.assertEqual(payload["range"], "A1:H29")
		self.assertEqual(payload["excluded_rows"], [4])
		self.assertEqual(len(payload["rows"]), 25)
		rows, duplicates = _unique_gspb_rows(payload)
		self.assertEqual(len(rows), 24)
		self.assertEqual(duplicates, [{"pdb_code": "C26", "sheet_row": 28}])
		self.assertEqual(rows[0]["pdb_code"], "ARRS")
		self.assertEqual(rows[-1]["pdb_code"], "BS")

	def test_current_gspb_rows_are_paid_period_components_at_full_weight(self):
		rows, _duplicates = _unique_gspb_rows(_load_gspb_source())
		self.assertEqual(
			{row["salary_basis_treatment"] for row in rows},
			{"Included only when actually processed/paid in relevant payroll period"},
		)
		self.assertEqual({row["inclusion_percentage"] for row in rows}, {100})
		self.assertTrue(all(row["description"] for row in rows))
