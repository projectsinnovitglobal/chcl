"""Client pay-day calendar linked to standard Payroll Period (PAY-014)."""

import calendar

import frappe
from frappe import _
from frappe.utils import add_days, add_months, get_first_day, getdate

from karyo.setup.foundation import f, make_doctype


def create_doctype():
	make_doctype(
		"Payroll Pay Day",
		autoname="field:pay_day_code",
		naming_rule="By fieldname",
		title_field="pay_period_label",
		fields=[
			f("identity_sb", "Section Break", "Pay Day Identity"),
			f("pay_day_code", "Data", "Pay Day Code", reqd=1, unique=1, in_list_view=1),
			f("company", "Link", "Company", options="Company", reqd=1, in_list_view=1),
			f("payroll_period", "Link", "Payroll Period", options="Payroll Period", reqd=1),
			f("pay_day_master", "Link", "Pay Day Master", options="Pay Day", reqd=1),
			f("identity_cb", "Column Break"),
			f(
				"payroll_type",
				"Link",
				"Payroll Type",
				options="Payroll Type",
				reqd=1,
				in_list_view=1,
			),
			f("pay_period_label", "Data", "Pay Period", reqd=1, in_list_view=1),
			f(
				"status",
				"Select",
				"Status",
				options="Planned\nActive\nProcessing\nClosed\nCancelled",
				default="Planned",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f("dates_sb", "Section Break", "Dates"),
			f("start_date", "Date", "Start Date", reqd=1, in_list_view=1,
				description="First attendance date included in this payroll run."),
			f("end_date", "Date", "End Date", reqd=1, in_list_view=1,
				description="Last attendance date included in this payroll run."),
			f(
				"work_days",
				"Int",
				"Work Days",
				read_only=1,
				description="Automatically recalculated from the company's default Holiday List, including its weekly-off entries.",
			),
			f("dates_cb", "Column Break"),
			f("payment_date", "Date", "Payment Date", reqd=1, in_list_view=1),
			f("input_cutoff_date", "Date", "Input Cut-off Date"),
			f("governance_sb", "Section Break", "Governance"),
			f(
				"configuration_version",
				"Link",
				"Configuration Version",
				options="Payroll Configuration Version",
				reqd=1,
			),
			f("source_reference", "Data", "Source Reference"),
			f("notes", "Small Text", "Notes"),
		],
	)


def _clamped_date(year, month, day):
	return getdate(f"{year:04d}-{month:02d}-{min(day, calendar.monthrange(year, month)[1]):02d}")


def pay_window(payment_date, day_of_month):
	"""Return the day after the prior monthly cut-off through this cut-off."""
	payment_date = getdate(payment_date)
	previous_month = add_months(get_first_day(payment_date), -1)
	previous_cutoff = _clamped_date(previous_month.year, previous_month.month, int(day_of_month))
	return add_days(previous_cutoff, 1), payment_date


def pay_window_for_month(month_start, day_of_month):
	"""Return start, end and payment date for a recurring monthly Pay Day."""
	month_start = get_first_day(month_start)
	payment_date = _clamped_date(month_start.year, month_start.month, int(day_of_month))
	start_date, end_date = pay_window(payment_date, day_of_month)
	return start_date, end_date, payment_date


def build_pay_day_rows(
	company,
	payroll_period,
	major_day=25,
	minor_day=15,
	include_minor=True,
	configuration_version=None,
):
	period = frappe.db.get_value(
		"Payroll Period", payroll_period, ["company", "start_date", "end_date"], as_dict=True
	)
	if not period or period.company != company:
		frappe.throw(_("Payroll Period does not belong to the selected company."))
	configuration_version = configuration_version or frappe.db.get_single_value(
		"Karyo Payroll Settings", "default_calendar_configuration"
	)
	if not configuration_version:
		frappe.throw(_("A Payroll Calendar configuration is required."))
	abbr = frappe.db.get_value("Company", company, "abbr") or "PAY"
	rows = []
	month_start = get_first_day(period.start_date)
	period_end = getdate(period.end_date)
	while month_start <= period_end:
		label = month_start.strftime("%B %Y")
		definitions = [("Major", major_day)]
		if include_minor:
			definitions.insert(0, ("Minor", minor_day))
		for payroll_type, pay_day in definitions:
			start_date, end_date, payment_date = pay_window_for_month(month_start, pay_day)
			from karyo.setup.payroll_profiles import ensure_pay_day
			pay_day_master = ensure_pay_day(company, payroll_type, int(pay_day))
			rows.append(
				{
					"pay_day_code": f"{abbr}-{month_start:%Y-%m}-{payroll_type.upper()}",
					"company": company,
					"payroll_period": payroll_period,
					"payroll_type": payroll_type,
					"pay_day_master": pay_day_master,
					"pay_period_label": label,
					"status": "Planned",
					"start_date": start_date,
					"end_date": end_date,
					"payment_date": payment_date,
					"input_cutoff_date": _clamped_date(
						month_start.year, month_start.month, max(1, int(pay_day) - 3)
					),
					"configuration_version": configuration_version,
					"source_reference": "Generated calendar — review before activation",
				}
			)
		month_start = get_first_day(add_months(month_start, 1))
	return rows


@frappe.whitelist()
def generate_pay_days(
	company,
	payroll_period,
	major_day=25,
	minor_day=15,
	include_minor=True,
	configuration_version=None,
	dry_run=False,
):
	rows = build_pay_day_rows(
		company,
		payroll_period,
		major_day=int(major_day),
		minor_day=int(minor_day),
		include_minor=frappe.utils.cint(include_minor),
		configuration_version=configuration_version,
	)
	if frappe.utils.cint(dry_run):
		return rows
	created = []
	skipped = []
	for row in rows:
		existing = frappe.db.exists("Payroll Pay Day", row["pay_day_code"]) or frappe.db.exists(
			"Payroll Pay Day",
			{
				"company": row["company"],
				"payroll_type": row["payroll_type"],
				"payment_date": row["payment_date"],
			},
		)
		if existing:
			skipped.append(row["pay_day_code"])
			continue
		created.append(frappe.get_doc({"doctype": "Payroll Pay Day", **row}).insert().name)
	return {"created": created, "skipped": skipped}


def seed_demo_calendar():
	company = frappe.db.get_single_value("Karyo Payroll Settings", "default_company")
	if not company:
		company = frappe.db.get_value("Company", {"default_currency": "MUR"}, "name")
	if not company:
		return
	configuration = frappe.db.get_single_value(
		"Karyo Payroll Settings", "default_calendar_configuration"
	)
	config_company = frappe.db.get_value(
		"Payroll Configuration Version", configuration, "company"
	) if configuration else None
	if (
		not configuration
		or not frappe.db.exists("Payroll Configuration Version", configuration)
		or (config_company and config_company != company)
	):
		abbr = frappe.db.get_value("Company", company, "abbr") or "COMPANY"
		config_key = f"DEMO-PAY-CALENDAR-{abbr}-2026"
		configuration = frappe.db.get_value(
			"Payroll Configuration Version",
			{"config_key": config_key, "version": "DEMO-1"},
			"name",
		)
		if not configuration:
			configuration = frappe.get_doc(
				{
					"doctype": "Payroll Configuration Version",
					"config_key": config_key,
					"configuration_type": "Payroll Calendar",
					"company": company,
					"version": "DEMO-1",
					"configuration_status": "Demo",
					"effective_from": "2026-01-01",
					"configuration_json": "{}",
					"source_reference": "Generated demo calendar configuration",
				}
			).insert(ignore_permissions=True).name
	period = frappe.db.get_value(
		"Payroll Period",
		{"company": company, "start_date": ("<=", "2026-07-01"), "end_date": (">=", "2026-07-01")},
		"name",
	)
	if period:
		generate_pay_days(company, period, configuration_version=configuration)


def setup():
	print("Karyo Payroll pay-day calendar setup:")
	create_doctype()
	from karyo.install import samples_enabled

	if samples_enabled():
		seed_demo_calendar()
	frappe.db.commit()
	print("Done (pay-day calendar created and demo annual calendar generated where possible).")
