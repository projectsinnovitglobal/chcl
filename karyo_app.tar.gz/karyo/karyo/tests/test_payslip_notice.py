"""Staff are told to verify their payslip on ESS once the period closes.

Training manual, "Bulk email to view payslip on ess".
"""

import unittest
from unittest.mock import patch
from uuid import uuid4

import frappe

from karyo.payroll.payslip_notice import (
	period_recipients,
	recipients,
	send_payslip_notice,
	send_period_payslip_notice,
)


class TestPayslipNotice(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("payslip_notice_test")
		template = frappe.db.get_value(
			"Payroll Pay Day", {"payroll_type": "Major"}, "name", order_by="start_date asc"
		)
		if not template:
			from karyo.setup.payroll_calendar import seed_demo_calendar

			seed_demo_calendar()
			template = frappe.db.get_value(
				"Payroll Pay Day", {"payroll_type": "Major"}, "name", order_by="start_date asc"
			)
		if not template:
			raise AssertionError("Payslip notice test requires a Major Payroll Pay Day")
		day = frappe.copy_doc(frappe.get_doc("Payroll Pay Day", template))
		day.name = "notice-" + uuid4().hex
		day.pay_day_code = day.name
		day.status = "Active"
		day.payroll_type = "Minor"
		day.pay_period_label = "Payslip notice " + uuid4().hex[:8]
		day.docstatus = 0
		day.db_insert()
		self.cycle = frappe.get_doc(
			{"doctype": "Payroll Cycle", "company": day.company, "pay_day": day.name, "status": "Draft"}
		).insert()

	def tearDown(self):
		frappe.db.rollback(save_point="payslip_notice_test")
		frappe.set_user(self.user)

	def test_recipients_come_from_submitted_slips_in_the_period(self):
		cycle, people = recipients(self.cycle.name)
		self.assertEqual(cycle["name"], self.cycle.name)
		for row in people:
			self.assertTrue(row["email"])

	def test_notice_is_skipped_when_the_setting_is_off(self):
		with patch.object(
			frappe.db, "get_single_value", side_effect=frappe.db.get_single_value
		):
			frappe.db.set_single_value("Karyo Payroll Settings", "notify_payslip_on_close", 0)
			frappe.clear_document_cache("Karyo Payroll Settings", "Karyo Payroll Settings")
			result = send_payslip_notice(self.cycle.name)
		self.assertEqual(result["sent"], 0)
		self.assertTrue(result["skipped"])

	def test_notice_mails_each_employee_once_and_logs_it(self):
		frappe.db.set_single_value("Karyo Payroll Settings", "notify_payslip_on_close", 1)
		frappe.db.set_single_value("Karyo Payroll Settings", "payslip_group_email", "viewpayslip@example.mu")
		frappe.clear_document_cache("Karyo Payroll Settings", "Karyo Payroll Settings")
		_cycle, people = recipients(self.cycle.name)
		if not people:
			self.skipTest("No submitted salary slips in this period on this site")
		with patch("frappe.sendmail") as sendmail:
			result = send_payslip_notice(self.cycle.name)
		self.assertEqual(result["sent"], len(people))
		self.assertEqual(sendmail.call_count, 1)
		sent_to = sendmail.call_args.kwargs["recipients"]
		self.assertEqual(len(sent_to), len(set(sent_to)))
		self.assertEqual(sendmail.call_args.kwargs["reply_to"], "viewpayslip@example.mu")
		self.assertTrue(
			frappe.db.exists(
				"Comment", {"reference_doctype": "Payroll Cycle", "reference_name": self.cycle.name}
			)
		)

	def test_a_mail_failure_does_not_block_closing_the_period(self):
		from karyo.payroll.payslip_notice import notify_on_close

		with patch("karyo.payroll.payslip_notice.send_payslip_notice", side_effect=Exception("smtp down")):
			result = notify_on_close(self.cycle.name)
		self.assertEqual(result["sent"], 0)
		self.assertTrue(result["error"])

	def test_period_notice_uses_only_submitted_real_slips_and_is_audited(self):
		period = self.cycle.payroll_period
		_period, people = period_recipients(period)
		if not people:
			self.skipTest("No submitted salary slip with an email exists in this Payroll Period")
		with patch("frappe.sendmail") as sendmail:
			result = send_period_payslip_notice(period)
		self.assertEqual(result["sent"], len(people))
		self.assertEqual(sendmail.call_args.kwargs["reference_doctype"], "Payroll Period")
		self.assertEqual(sendmail.call_args.kwargs["reference_name"], period)
		self.assertTrue(frappe.db.exists("Comment", {
			"reference_doctype": "Payroll Period", "reference_name": period,
		}))


if __name__ == "__main__":
	unittest.main()
