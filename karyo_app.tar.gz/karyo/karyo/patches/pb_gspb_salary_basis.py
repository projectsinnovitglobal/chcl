"""Apply the current client GSPB salary-basis component spreadsheet."""

from karyo.setup.pb_setup_rules import apply_pb_setup_rules


def execute():
	apply_pb_setup_rules(commit=False)
