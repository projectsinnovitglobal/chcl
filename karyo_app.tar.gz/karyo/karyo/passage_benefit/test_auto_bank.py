import unittest
from unittest.mock import patch
import frappe
from frappe.utils import add_days, getdate, today
from karyo.passage_benefit import auto_bank
from karyo.passage_benefit.init_bank import create_banks
from karyo.karyo.doctype.passage_benefit_bank.test_passage_benefit_bank import TestPassageBenefitBank


class TestAutomaticPBBank(unittest.TestCase):
	def setUp(self):
		frappe.set_user("Administrator")
		frappe.db.savepoint("auto_bank_test")
		TestPassageBenefitBank.setUp(self)
		self.candidates = patch.object(auto_bank, "_candidates", return_value=[self.employee.name])
		self.candidates.start()

	def tearDown(self):
		self.candidates.stop()
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="auto_bank_test")
		frappe.clear_cache(doctype="Passage Benefit Settings")

	def test_creates_once_at_zero_with_open_period_and_audit(self):
		self.assertEqual(auto_bank.create_due_banks()["created"], [self.employee.name])
		bank=frappe.get_doc("Passage Benefit Bank", self.employee.name)
		self.assertEqual(bank.current_balance, 0)
		self.assertEqual(len(bank.periods), 1)
		self.assertEqual(bank.periods[0].status, "Open")
		self.assertEqual(auto_bank.create_due_banks()["created"], [])
		self.assertTrue(frappe.db.exists("Comment", {"reference_name": bank.name, "comment_type": "Info"}))

	def test_waits_until_eligibility_date(self):
		tomorrow=add_days(today(),1)
		self.employee.db_set("karyo_date_confirmed", tomorrow)
		self.assertEqual(auto_bank.create_due_banks()["created"], [])
		with patch.object(auto_bank,"today",return_value=tomorrow):
			self.assertEqual(auto_bank.create_due_banks()["created"], [self.employee.name])
		self.assertEqual(getdate(frappe.db.get_value("Passage Benefit Bank",self.employee.name,"opening_date")),getdate(tomorrow))

	def test_manual_bank_is_preserved(self):
		self.assertEqual(create_banks([self.employee.name],opening_balance=1250)["created"],[self.employee.name])
		self.assertEqual(auto_bank.create_due_banks()["created"],[])
		self.assertEqual(frappe.db.get_value("Passage Benefit Bank",self.employee.name,"current_balance"),1250)

	def test_ineligible_employee_is_not_created(self):
		self.employee.db_set("pb_eligible",0)
		self.assertEqual(auto_bank.create_due_banks()["created"],[])
		self.assertFalse(frappe.db.exists("Passage Benefit Bank",self.employee.name))

	def test_failure_is_isolated_and_recorded(self):
		with patch.object(auto_bank,"evaluate",side_effect=ValueError("Incomplete setup")), patch.object(frappe,"log_error") as log:
			self.assertEqual(auto_bank.create_due_banks()["failed"],[self.employee.name])
			log.assert_called_once()
		self.assertFalse(frappe.db.exists("Passage Benefit Bank",self.employee.name))
