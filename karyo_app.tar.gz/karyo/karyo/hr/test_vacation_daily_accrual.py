from unittest.mock import patch
from uuid import uuid4

import frappe
from frappe.tests.utils import FrappeTestCase
from frappe.utils import nowdate

from karyo.desk.overview import my_hr
from karyo.hr.self_service import leave_balances, my_leave_bank, vacation_accrual_snapshot


class TestVacationDailyAccrual(FrappeTestCase):
	def setUp(self):
		frappe.set_user("Administrator")
		frappe.db.savepoint("vacation_daily_test")
		token = uuid4().hex[:10]
		self.user = f"vacation-daily-{token}@example.invalid"
		# Isolate the calculation from onboarding, which initializes live banks.
		frappe.get_doc({
			"doctype": "User", "name": self.user, "email": self.user,
			"first_name": "Vacation Daily QA", "enabled": 1, "user_type": "System User",
		}).db_insert()
		frappe.get_doc({
			"doctype": "Has Role", "parent": self.user, "parenttype": "User",
			"parentfield": "roles", "role": "Employee",
		}).db_insert()
		frappe.clear_cache(user=self.user)
		self.employee = f"VAC-DAILY-QA-{token}"
		frappe.get_doc({
			"doctype": "Employee", "name": self.employee, "employee_number": self.employee,
			"first_name": "Vacation Daily QA", "employee_name": "Vacation Daily QA",
			"status": "Active", "user_id": self.user, "karyo_employment_category": "PERM",
			"company": frappe.db.get_value("Employee", {"status": "Active"}, "company"),
			"date_of_joining": "2024-01-01", "karyo_date_joined_service": "2019-01-01",
		}).db_insert()

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="vacation_daily_test")
		frappe.clear_cache(user=self.user)

	def test_configured_service_bands_and_leap_year(self):
		settings = frappe.get_doc("MBC Leave Settings")
		for year in (2024, 2026):
			for years in (2, 7, 12, 20):
				joined = f"{year - years}-01-01"
				frappe.db.set_value("Employee", self.employee, "karyo_date_joined_service", joined)
				expected_band = next(b for b in settings.vacation_leave_bands if
					b.service_from_years <= years and (not b.service_to_years or years < b.service_to_years))
				snapshot = vacation_accrual_snapshot(self.employee, f"{year}-07-01")
				divisor = 366 if year == 2024 else 365
				self.assertEqual(snapshot.days_in_year, divisor)
				self.assertEqual(snapshot.annual_accrual_days, expected_band.annual_entitlement_days)
				self.assertEqual(snapshot.daily_accrual_days, round(expected_band.annual_entitlement_days / divisor, 6))
				self.assertEqual(snapshot.ceiling_days, expected_band.accumulation_ceiling_days)

	def test_daily_rate_visible_without_initialized_bank(self):
		self.assertFalse(frappe.db.exists("Vacation Leave Bank", {"employee": self.employee}))
		frappe.set_user(self.user)
		bank_screen = my_leave_bank()
		dashboard = my_hr()
		expected = vacation_accrual_snapshot(self.employee)
		self.assertIsNone(bank_screen["vacation_leave_bank"])
		self.assertIsNone(dashboard["vacation_leave_bank"])
		self.assertEqual(bank_screen["vacation_accrual"], expected)
		self.assertEqual(dashboard["vacation_accrual"], expected)

	def test_service_parameter_change_updates_both_screens(self):
		frappe.set_user(self.user)
		before = my_leave_bank()["vacation_accrual"]
		frappe.set_user("Administrator")
		frappe.db.set_value("Employee", self.employee, "karyo_date_joined_service", f"{int(nowdate()[:4]) - 20}-01-01")
		frappe.set_user(self.user)
		after = my_leave_bank()["vacation_accrual"]
		self.assertNotEqual(before.annual_accrual_days, after.annual_accrual_days)
		self.assertEqual(my_hr()["vacation_accrual"], after)

	def test_rate_matches_live_bank_and_vacation_balance_row(self):
		bank = frappe.get_doc({
			"doctype": "Vacation Leave Bank", "employee": self.employee,
			"status": "Active", "opening_balance_days": 12, "balance_days": 12,
		}).insert(ignore_permissions=True)
		frappe.set_user(self.user)
		screen = my_leave_bank()
		dashboard = my_hr()
		row = next(r for r in leave_balances(self.employee) if r.get("leave_code") == "VAC01")
		expected = vacation_accrual_snapshot(self.employee)
		for result in (screen["vacation_accrual"], screen["vacation_leave_bank"],
			dashboard["vacation_accrual"], dashboard["vacation_leave_bank"], row):
			self.assertEqual(result["daily_accrual_days"], expected.daily_accrual_days)
			self.assertEqual(result["annual_accrual_days"], expected.annual_accrual_days)
		self.assertEqual(bank.daily_accrual_days, expected.daily_accrual_days)
		self.assertEqual(row["remaining"], 12)

	def test_edited_entitlement_is_used_instead_of_default_band(self):
		settings = frappe.get_doc("MBC Leave Settings")
		settings.vacation_leave_bands[1].annual_entitlement_days = 31
		original = frappe.get_cached_doc
		def configured_doc(doctype, *args, **kwargs):
			return settings if doctype == "MBC Leave Settings" else original(doctype, *args, **kwargs)
		with patch("frappe.get_cached_doc", side_effect=configured_doc):
			snapshot = vacation_accrual_snapshot(self.employee)
			self.assertEqual(snapshot.annual_accrual_days, 31)
			self.assertEqual(snapshot.daily_accrual_days, round(31 / snapshot.days_in_year, 6))
