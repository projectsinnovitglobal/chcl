"""Regression coverage for link-safe organisation master corrections."""

from uuid import uuid4

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.desk.org_units import save as save_org_unit


class TestLinkedMasterSync(FrappeTestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("linked_master_sync")
		self.employee = frappe.db.get_value("Employee", {}, "name")
		self.company = frappe.db.get_value("Company", {}, "name")
		self.assertTrue(self.employee and self.company)

	def tearDown(self):
		frappe.db.rollback(save_point="linked_master_sync")
		frappe.clear_cache()
		frappe.set_user(self.user)

	def test_company_correction_updates_employee_link(self):
		token = uuid4().hex[:8]
		old_name = self.company
		corrected_name = f"{old_name} Corrected {token}"[:140]
		frappe.db.set_value("Employee", self.employee, "company", old_name)

		result = save_org_unit("Company", {"company_name": corrected_name}, old_name)

		self.assertEqual(result["name"], corrected_name)
		self.assertTrue(frappe.db.exists("Company", corrected_name))
		self.assertFalse(frappe.db.exists("Company", old_name))
		self.assertEqual(frappe.db.get_value("Employee", self.employee, "company"), corrected_name)

	def test_designation_correction_updates_employee_link(self):
		token = uuid4().hex[:8]
		designation = frappe.get_doc({
			"doctype": "Designation",
			"designation_name": f"Misspelt Post {token}",
			"company": self.company,
		}).insert()
		frappe.db.set_value("Employee", self.employee, "designation", designation.name)

		designation.designation_name = f"Corrected Post {token}"
		designation.save()

		self.assertEqual(designation.name, f"Corrected Post {token}")
		self.assertEqual(
			frappe.db.get_value("Employee", self.employee, "designation"), designation.name
		)
		self.assertFalse(frappe.db.exists("Designation", f"Misspelt Post {token}"))

	def test_department_and_section_corrections_keep_employee_mapping(self):
		token = uuid4().hex[:8]
		department = frappe.get_doc({
			"doctype": "Department",
			"department_name": f"Misspelt Department {token}",
			"company": self.company,
		}).insert()
		section = frappe.get_doc({
			"doctype": "Employee Section",
			"section_code": f"SEC-{token}",
			"section_name": "Misspelt Section",
			"department": department.name,
		}).insert()
		frappe.db.set_value("Employee", self.employee, {
			"department": department.name,
			"karyo_section": section.name,
		})

		old_department = department.name
		department.department_name = f"Corrected Department {token}"
		department.save()
		self.assertNotEqual(department.name, old_department)
		self.assertEqual(frappe.db.get_value("Employee", self.employee, "department"), department.name)
		self.assertEqual(frappe.db.get_value("Employee Section", section.name, "department"), department.name)

		old_section = section.name
		section.reload()
		section.section_code = f"FIX-{token}"
		section.section_name = "Corrected Section"
		section.save()
		self.assertNotEqual(section.name, old_section)
		self.assertEqual(frappe.db.get_value("Employee", self.employee, "karyo_section"), section.name)
		self.assertEqual(frappe.db.get_value("Employee Section", section.name, "section_name"), "Corrected Section")
