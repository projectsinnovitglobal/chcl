"""Payslip output privacy, monthly selection and generation-context regression."""
import unittest
from uuid import uuid4
from unittest.mock import patch
from pathlib import Path

import frappe
from karyo.desk.payroll_management import (
    payslip_generation_context, employee_payslips, payslip_print_html, download_payslip_pdf,
    employee_run_eligibility,
)


class TestPayslipGeneration(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('payslip_generation_test')
        self.token = uuid4().hex
        self.company = frappe.db.get_value('Company', {}, 'name')
        self.employee = 'payslip-test-' + self.token
        self.account = self.token + '@example.com'
        frappe.get_doc({'doctype': 'User', 'name': self.account, 'email': self.account,
                        'first_name': 'Payslip test', 'enabled': 1}).db_insert()
        frappe.get_doc({'doctype': 'Employee', 'name': self.employee,
                        'employee_name': 'Test <script>alert(1)</script>',
                        'company': self.company, 'user_id': self.account, 'status': 'Active'}).db_insert()
        self.names = []
        for month, status, employee in [('07', 1, self.employee), ('08', 1, self.employee),
                                         ('09', 0, self.employee), ('07', 1, 'other-' + self.token)]:
            name = 'payslip-' + uuid4().hex
            frappe.get_doc({'doctype': 'Salary Slip', 'name': name, 'employee': employee,
                'employee_name': 'Test <script>alert(1)</script>', 'company': self.company,
                'start_date': f'2091-{month}-01', 'end_date': f'2091-{month}-28',
                'currency': 'MUR', 'gross_pay': 1200, 'total_deduction': 200, 'net_pay': 1000,
                'docstatus': status, 'karyo_payment_status': 'PAID'}).db_insert()
            self.names.append(name)

    def tearDown(self):
        frappe.set_user('Administrator')
        frappe.db.rollback(save_point='payslip_generation_test')
        frappe.set_user(self.user)

    def test_month_table_includes_own_generated_and_submitted_slips(self):
        frappe.set_user(self.account)
        self.assertEqual({r.name for r in employee_payslips()['rows']}, set(self.names[:3]))
        self.assertEqual([r.name for r in employee_payslips(month='2091-07')['rows']], self.names[:1])
        self.assertEqual([r.name for r in employee_payslips(month='2091-09')['rows']], [self.names[2]])
        with self.assertRaises(frappe.ValidationError):
            employee_payslips(month='2091-13')

    def test_dashboards_exclude_slips_without_complete_payroll_dates(self):
        from karyo.payroll.payslip_status import admin_payslips
        incomplete = []
        for start, end in [(None, None), ('2091-07-01', None), (None, '2091-07-28')]:
            slip = frappe.copy_doc(frappe.get_doc('Salary Slip', self.names[0]))
            slip.name = 'closing-slip-' + uuid4().hex
            slip.docstatus = 1
            slip.start_date, slip.end_date = start, end
            slip.db_insert()
            incomplete.append(slip.name)
        frappe.set_user(self.account)
        self.assertEqual({r.name for r in employee_payslips()['rows']}, set(self.names[:3]))
        self.assertEqual([r.name for r in employee_payslips(month='2091-07')['rows']], self.names[:1])
        frappe.set_user('Administrator')
        names = set()
        start = 0
        while True:
            page = admin_payslips(start=start)
            names.update(r.name for r in page['rows'])
            if not page['has_more']:
                break
            start += len(page['rows'])
        self.assertTrue(set(self.names).issubset(names))
        self.assertFalse(set(incomplete).intersection(names))

    def test_home_payment_preview_is_pending_only_and_limited(self):
        from karyo.payroll.payslip_status import admin_payslips
        frappe.db.set_value('Salary Slip', self.names[0], 'karyo_payment_status', 'Draft')
        frappe.db.set_value('Salary Slip', self.names[1], 'karyo_payment_status', 'Processing')
        page = admin_payslips(pending_only=1, page_length=1)
        self.assertEqual(len(page['rows']), 1)
        self.assertNotEqual(page['rows'][0].payment_status, 'PAID')
        self.assertTrue(page['has_more'])

    def test_employee_print_and_pdf_allow_own_draft_deny_other_employee(self):
        frappe.set_user(self.account)
        for name in self.names[3:]:
            with self.assertRaises(frappe.PermissionError):
                payslip_print_html(name)
            with self.assertRaises(frappe.PermissionError):
                download_payslip_pdf(name)
        self.assertNotIn('DRAFT', payslip_print_html(self.names[2]))
        html = payslip_print_html(self.names[0])
        self.assertIn('&lt;script&gt;', html)
        self.assertNotIn('<script>', html)
        self.assertIn('1,000.00', html)
        for label in ('Pay Slip for', 'Employee ID', 'Total Working Days', 'Earnings',
                      'Deductions', 'Total Earnings', 'Total Deductions', 'Net Salary'):
            self.assertIn(label, html)
        for removed in ('Provident Fund', 'Payroll Period'):
            self.assertNotIn(removed, html)
        self.assertIn('/assets/karyo/images/mbc-logo.jpg', html)
        download_payslip_pdf(self.names[0])
        self.assertTrue(frappe.local.response.filecontent.startswith(b'%PDF'))

    def test_admin_draft_print_omits_workflow_badge_and_guest_is_denied(self):
        self.assertNotIn('DRAFT', payslip_print_html(self.names[2]))
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            payslip_print_html(self.names[0])
        with self.assertRaises(frappe.PermissionError):
            payslip_generation_context('irrelevant')

    def test_context_keeps_payroll_period_scope_and_workflow(self):
        period = frappe.get_doc('Payroll Period', frappe.db.get_value('Payroll Period', {}, 'name'))
        result = payslip_generation_context(period.name)
        for run in result['runs']:
            self.assertEqual(run.company, period.company)
            self.assertGreaterEqual(run.start_date, period.start_date)
            self.assertLessEqual(run.end_date, period.end_date)
        self.assertIn('summary', result)
        self.assertIn('ready', result)
        self.assertIn('readiness_reason', result)
        self.assertIn('run_availability', result)
        self.assertEqual(result['run_availability']['available'], bool(result['runs']))
        self.assertEqual(result['summary']['pending'],
                         max(result['summary']['eligible'] - result['summary']['already_generated'], 0))
        self.assertEqual(payslip_generation_context('period::' + period.name)['selected'], result['selected'])
        with self.assertRaises(frappe.ValidationError):
            payslip_generation_context(period.name, 'not-in-period')
        with self.assertRaises(frappe.ValidationError):
            payslip_generation_context(period.name + ' · Active')
        frappe.set_user(self.account)
        with self.assertRaises(frappe.PermissionError):
            payslip_generation_context(period.name)

    def test_bulk_generation_does_not_require_a_selected_employee(self):
        cycle = frappe.get_all('Payroll Cycle', filters={'docstatus': ('<', 2)},
            fields=['company', 'start_date', 'end_date'], limit_page_length=1)[0]
        # Company.get_value({}) and an unfiltered Payroll Cycle query have no
        # guaranteed shared ordering once other test fixtures exist. Keep this
        # employee inside the period company so the assertion tests bulk scope,
        # not the separate cross-company validation rule.
        frappe.db.set_value('Employee', self.employee, 'company', cycle.company)
        period = 'payslip-period-' + self.token
        frappe.get_doc({'doctype': 'Payroll Period', 'name': period,
            'company': cycle.company, 'start_date': cycle.start_date,
            'end_date': cycle.end_date}).db_insert()
        with patch('karyo.desk.payroll_management._step_availability', return_value=[
                {'action': 'Generate Draft Salary Slips', 'available': True}]):
            result = payslip_generation_context(period)
            self.assertTrue(result['ready'])
            self.assertTrue(result['can_generate'])
            frappe.db.set_value('Employee', self.employee, 'status', 'Inactive')
            result = payslip_generation_context(period, employee=self.employee)
            self.assertFalse(result['can_generate'])
        with patch('karyo.desk.payroll_management._step_availability', return_value=[
                {'action': 'Generate Draft Salary Slips', 'available': False}]):
            self.assertFalse(payslip_generation_context(period)['can_generate'])

    def test_generate_button_inherits_page_context(self):
        source = (Path(__file__).parents[1] / 'karyo/page/payroll_management/payroll_management.js').read_text()
        self.assertIn('.pm-generate-payslips", () => pm_generate_payslips(', source)
        self.assertIn('dialog.set_secondary_action_label(__("Cancel"))', source)
        compact = source[source.index('async function pm_generate_payslips'):]
        self.assertIn('const selection = state.data?.selection', compact)
        self.assertIn('const employee = state.data?.employee?.employee || state.sel.employee', compact)
        self.assertIn('state.process_employees = employee ? [employee] : []', compact)
        self.assertIn('frappe.set_route("payroll-management", "process")', compact)
        self.assertNotIn('fieldname: "scope"', compact)
        self.assertNotIn('fieldname: "employee"', compact)
        toolbar = source[source.index('PM_LAYOUTS.payslips ='):source.index('// Reports:', source.index('PM_LAYOUTS.payslips ='))]
        self.assertNotIn('pm-payslip-setup', toolbar)

    def test_process_blockers_are_actionable_in_the_right_panel(self):
        source = (Path(__file__).parents[1] / 'karyo/page/payroll_management/payroll_management.js').read_text()
        wizard = source[source.index('PM_LAYOUTS.wizard ='):source.index('// Query payroll', source.index('PM_LAYOUTS.wizard ='))]
        self.assertIn('Blocking issues', wizard)
        self.assertIn('pm-blocked-step', wizard)
        self.assertIn('pm_step_remediation(step, data)', wizard)
        self.assertIn('pm-exception-details', wizard)

    def test_service_dates_control_run_eligibility(self):
        employee = frappe._dict(status='Active', date_of_joining='2026-07-15', relieving_date=None)
        self.assertTrue(employee_run_eligibility(employee, '2026-07-01', '2026-07-31')['eligible'])
        employee.date_of_joining = '2026-08-01'
        self.assertFalse(employee_run_eligibility(employee, '2026-07-01', '2026-07-31')['eligible'])
        employee.date_of_joining = '2026-01-01'
        employee.relieving_date = '2026-06-30'
        self.assertFalse(employee_run_eligibility(employee, '2026-07-01', '2026-07-31')['eligible'])
        employee.relieving_date = None
        employee.status = 'Inactive'
        self.assertFalse(employee_run_eligibility(employee, '2026-07-01', '2026-07-31')['eligible'])

    def test_cancelled_slip_is_hidden_from_employee_and_download(self):
        frappe.db.set_value('Salary Slip', self.names[2], 'docstatus', 2)
        frappe.set_user(self.account)
        self.assertNotIn(self.names[2], [r.name for r in employee_payslips()['rows']])
        with self.assertRaises(frappe.PermissionError): download_payslip_pdf(self.names[2])

    def test_email_has_exact_recipient_pdf_and_preserves_draft_label(self):
        from karyo.payroll.payslip_delivery import details, send
        with patch('karyo.desk.employee_account._email_ready', return_value=True), \
             patch('frappe.sendmail') as mail, patch('frappe.utils.pdf.get_pdf', return_value=b'%PDF-test') as pdf:
            info = details(self.names[2])
            self.assertEqual(info['recipient'], self.account)
            self.assertEqual(info['status'], 'Draft')
            with self.assertRaises(frappe.ValidationError): send(self.names[2], 'someone-else@example.com')
            mail.assert_not_called()
            result = send(self.names[2], self.account)
            self.assertTrue(result['queued'])
            args = mail.call_args.kwargs
            self.assertEqual(args['recipients'], [self.account])
            self.assertTrue(args['subject'].startswith('DRAFT'))
            self.assertEqual(args['reference_name'], self.names[2])
            self.assertEqual(args['attachments'][0]['fcontent'], b'%PDF-test')
            self.assertNotIn('DRAFT', pdf.call_args.args[0])
            frappe.set_user(self.account)
            with self.assertRaises(frappe.PermissionError): send(self.names[2], self.account)

    def test_email_rejects_cancelled_and_unconfigured_delivery(self):
        from karyo.payroll.payslip_delivery import details
        with patch('karyo.desk.employee_account._email_ready', return_value=False):
            with self.assertRaises(frappe.ValidationError): details(self.names[0])
        frappe.db.set_value('Salary Slip', self.names[0], 'docstatus', 2)
        with self.assertRaises(frappe.ValidationError): details(self.names[0])

    def test_employee_refresh_is_targeted_and_waits_for_commit(self):
        from karyo.hr.self_service import notify_employee_request
        import karyo.hooks
        self.assertIn('karyo.loan.payroll.salary_slip_submitted', karyo.hooks.doc_events['Salary Slip']['on_submit'])
        for event in ('on_update', 'on_submit', 'on_cancel', 'on_update_after_submit', 'on_trash'):
            self.assertIn('karyo.hr.self_service.notify_employee_request', karyo.hooks.doc_events['Salary Slip'][event])
        with patch('frappe.publish_realtime') as notify:
            notify_employee_request(frappe.get_doc('Salary Slip', self.names[2]))
            self.assertEqual(notify.call_args.kwargs, {'user': self.account, 'after_commit': True})

    def test_email_respects_configured_pdf_encryption(self):
        from karyo.payroll.payslip_delivery import send
        settings = frappe._dict(encrypt_salary_slips_in_emails=1, password_policy='{name}', sender_email=None)
        with patch('karyo.desk.employee_account._email_ready', return_value=True), \
             patch('frappe.sendmail'), patch('frappe.get_single', return_value=settings), \
             patch('frappe.utils.pdf.get_pdf', return_value=b'%PDF-test') as pdf:
            send(self.names[0], self.account)
            self.assertEqual(pdf.call_args.kwargs['options']['password'], self.employee)

    def test_payment_status_defaults_and_controls_download_without_changing_amounts(self):
        from karyo.payroll.payslip_status import set_status, status_info
        name = self.names[1]
        frappe.db.set_value('Salary Slip', name, 'karyo_payment_status', None)
        self.assertEqual(status_info(frappe.get_doc('Salary Slip', name))['payment_status'], 'Draft')
        before = frappe.db.get_value('Salary Slip', name, ['docstatus','gross_pay','net_pay'])
        with patch('frappe.publish_realtime'):
            for value in ('Processing', 'PAID', 'Draft'):
                result = set_status(name, value)
                self.assertEqual(result['can_download'], value == 'PAID')
                frappe.set_user(self.account)
                own = next(r for r in employee_payslips()['rows'] if r.name == name)
                self.assertEqual(own['payment_status'], value)
                self.assertFalse(own['can_set_payment_status'])
                if value == 'PAID': self.assertIn('Payslip', payslip_print_html(name))
                else:
                    with self.assertRaises(frappe.ValidationError): download_payslip_pdf(name)
                with self.assertRaises(frappe.PermissionError): set_status(name, 'PAID')
                frappe.set_user('Administrator')
        self.assertEqual(frappe.db.get_value('Salary Slip', name, ['docstatus','gross_pay','net_pay']), before)
        with self.assertRaises(frappe.ValidationError): set_status(name, 'Approved')
        frappe.db.set_value('Salary Slip', name, 'docstatus', 2)
        with self.assertRaises(frappe.ValidationError): set_status(name, 'PAID')

    def test_draft_slip_cannot_be_marked_paid_before_loan_posting_is_available(self):
        from karyo.payroll.payslip_status import set_status
        name = self.names[2]
        frappe.db.set_value('Salary Slip', name, 'karyo_payment_status', 'Processing')
        with self.assertRaisesRegex(
            frappe.ValidationError,
            'Submit the Salary Slip before marking it PAID',
        ):
            set_status(name, 'PAID')
        self.assertEqual(
            frappe.db.get_value('Salary Slip', name, 'karyo_payment_status'),
            'Processing',
        )

    def test_submitted_slip_can_update_payment_status_with_audit(self):
        from karyo.payroll.payslip_status import set_status
        name = self.names[0]
        with patch('frappe.publish_realtime'):
            set_status(name, 'Processing')
            set_status(name, 'PAID')
        self.assertEqual(frappe.db.get_value('Salary Slip', name, 'docstatus'), 1)
        comments = frappe.get_all('Comment', filters={'reference_doctype':'Salary Slip','reference_name':name}, pluck='content')
        self.assertTrue(any('Processing to PAID' in text for text in comments))
