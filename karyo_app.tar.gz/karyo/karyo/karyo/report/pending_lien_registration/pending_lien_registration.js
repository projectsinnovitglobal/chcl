frappe.query_reports["Pending Lien Registration"] = {
	filters: [
		{ fieldname: "as_at_date", label: __("As At Date"), fieldtype: "Date", reqd: 1, default: frappe.datetime.get_today() },
		{ fieldname: "follow_up_days", label: __("Follow-up Days"), fieldtype: "Int", default: 7 },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "owner", label: __("Owner"), fieldtype: "Link", options: "User" },
		{ fieldname: "lien_status", label: __("Lien Status"), fieldtype: "Select", options: "\nPending\nReturned\nRejected\nRelease Pending" },
		{ fieldname: "follow_up_status", label: __("Follow-up Status"), fieldtype: "Select", options: "\nPending\nDue Soon\nDue Today\nOverdue\nReturned" },
	],
};
