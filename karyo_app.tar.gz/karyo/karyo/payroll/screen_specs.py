"""Declarative layout of the Payroll Management desk.

Every screen the client's Payroll Management user manual describes is listed
here with the layout it renders in and, for each doctype it touches, the fields
the manual names (with the manual's own labels), the fields that only a payroll
administrator sees, the automated facts the drawer derives, and the actions the
record offers at each status.

Nothing here is executed on its own: ``karyo.desk.payroll_management`` reads
these specs to build the screen payloads and the record drawer, and every write
still goes through the document's own validation.

Field entries in ``sections`` are one of::

    "fieldname"                      # label from the doctype
    ("fieldname", "Manual label")    # label the user manual uses
    {"fieldname": ..., "label": ..., "read_only": 1, "wide": 1, "hint": ...}
"""

# --- Manual field labels per doctype -----------------------------------------

ENTITIES = {
	"Company": {
		"title": "company_name",
		"subtitle": "abbr",
		"sections": [
			{"label": "Identity", "fields": [
				{"fieldname": "karyo_company_code", "label": "Code", "read_only": 1},
				{"fieldname": "company_name", "label": "Name", "read_only": 1},
				("abbr", "Abbreviation Name"),
			]},
			{"label": "Address", "fields": [
				("karyo_address_line_1", "Address"), ("karyo_address_line_2", "Address 2"),
				("karyo_address_line_3", "Address 3"),
				("karyo_postal_code", "Postal Code"), ("country", "Country"),
			]},
			{"label": "Contact", "fields": [
				("phone_no", "Phone"), ("fax", "Fax"), ("email", "Email"),
				("website", "Website"), ("karyo_contact_person", "Contact Person"),
			]},
			{"label": "Payroll Registration & Financial Year", "fields": [
				("karyo_paye_number", "PAYE No"), ("karyo_financial_year", "Financial Year"),
				{"fieldname": "karyo_fin_start_date", "label": "Fin Start Date", "read_only": 1},
				{"fieldname": "karyo_fin_end_date", "label": "Fin End Date", "read_only": 1},
				{"fieldname": "karyo_calendar_year", "label": "Calendar Year", "read_only": 1},
			]},
			{"label": "Payroll Bank & Branch", "fields": [
				("karyo_payroll_bank", "Payroll Bank Name"),
				("karyo_payroll_bank_branch", "Branch Name"),
			]},
		],
		"admin": ["default_currency", "default_holiday_list"],
		"automated": "company",
		"actions": [],
	},
	"Payroll PDB Type": {
		"title": "pdb_type",
		"subtitle": "description",
		"sections": [
			{"label": "PDB Type", "fields": [
				("pdb_type", "PDB Type"), ("description", "PDB Description"),
				("classification", "Type"), ("is_active", "Active"),
			]},
		],
		"admin": ["effective_from", "effective_to", "configuration_version"],
		"config_type": "PDB Catalogue",
		"automated": "pdb_type",
		"list": ["pdb_type", "description", "classification", "is_active"],
		"actions": [],
	},
	"Payroll PDB Code": {
		"title": "pdb_code",
		"subtitle": "description",
		"sections": [
			{"label": "Code", "fields": [
				("pdb_code", "PDB Code"), ("pdb_type", "PDB Type"),
				("description", "Description"), ("short_description", "Short Description"),
				("transaction_mode", "Static / Once Off"), ("is_active", "Active"),
			]},
			{"label": "Behaviour", "fields": [
				("taxable", "Taxable"), ("exempt", "Exempt"),
				("prorata", "Prorata"), ("reducing_balance", "Reducing Balance"),
			]},
		],
		"admin": ["display_sequence", "effective_from", "effective_to",
			"configuration_version", "company", "default_cost_center", "source_reference"],
		"config_type": "PDB Catalogue",
		"automated": "pdb_code",
		"auto_component": True,
		"list": ["pdb_code", "description", "transaction_mode", "taxable", "is_active"],
		"actions": [],
	},
	"Bank": {
		"title": "bank_name",
		"subtitle": "karyo_bank_code",
		"sections": [
			{"label": "Bank", "fields": [
				("bank_name", "Bank Name"), ("karyo_bank_code", "Bank Code"),
				("karyo_bank_transfer_code", "Transfer Code"), ("karyo_bank_other_code", "Other Code"),
				("karyo_payroll_active", "Active for Payroll"),
			]},
			{"label": "Address", "fields": [
				("karyo_address_line_1", "Address 1"), ("karyo_address_line_2", "Address 2"),
				("karyo_address_line_3", "Address 3"), ("karyo_phone", "Phone"), ("karyo_email", "Email"),
			]},
		],
		"admin": ["karyo_bank_effective_from", "karyo_bank_effective_to", "karyo_bank_configuration"],
		"automated": "bank",
		"list": ["bank_name", "karyo_bank_code", "karyo_payroll_active"],
		"actions": [],
	},
	"Payroll Bank Branch": {
		"title": "branch_name",
		"subtitle": "branch_code",
		"sections": [
			{"label": "Branch", "fields": [
				("bank", "Bank"), ("branch_name", "Branch Name"), ("branch_code", "Branch Code"),
				("transfer_code", "Transfer Code"), ("other_code", "Other Code"), ("is_active", "Active"),
			]},
			{"label": "Address", "fields": [
				("address_line_1", "Address 1"), ("address_line_2", "Address 2"), ("address_line_3", "Address 3"),
				("postal_code", "Postal Code"), ("telephone", "Telephone No"), ("fax", "Fax"),
			]},
		],
		"admin": ["effective_from", "effective_to", "configuration_version", "source_reference"],
		"config_type": "Bank Export",
		"automated": "bank_branch",
		"list": ["branch_code", "branch_name", "transfer_code", "is_active"],
		"actions": [],
	},
	"Payroll Operation Code": {
		"title": "operation_code",
		"subtitle": "description",
		"sections": [
			{"label": "Operation Code", "fields": [
				{"fieldname": "operation_code", "label": "Operation Code"},
				{"fieldname": "description", "label": "Description"},
				{"fieldname": "operation_category", "label": "Category"},
				("is_active", "Active"),
			]},
		],
		"tables": [
			{"fieldname": "items", "label": "PDB codes in this operation", "fields": [
				("pdb_code", "PDB Code"), ("sequence", "Sequence Number"), ("aggregation_sign", "Sign"),
				("inclusion_percentage", "Inclusion % / Weight"),
				("salary_basis_treatment", "Salary-Basis Treatment"),
				("effective_from", "Effective From"), ("effective_to", "Effective To"),
				("remarks", "Remarks"),
			]},
		],
		"admin": ["effective_from", "effective_to", "configuration_version", "company", "source_reference", "notes"],
		"config_type": "Operation Codes",
		"automated": "operation_code",
		"list": ["operation_code", "description", "operation_category", "is_active"],
		"actions": [],
	},
	"Payroll Contribution Scheme": {
		"title": "description",
		"subtitle": "scheme_code",
		"sections": [
			{"label": "Contribution", "fields": [
				("scheme_code", "Contribution Code"), ("description", "Contribution Description"),
				("employee_pdb_code", "PDB Code"), ("calculation_mode", "Contribution Flag"),
				("basis_operation_code", "Salary Basis"), ("is_active", "Active"),
			]},
			{"label": "Ceilings & rounding", "fields": [
				("employer_ceiling", "Employer Ceiling"), ("employee_ceiling", "Employee Ceiling"),
				("rounding_precision", "Round (dp)"), ("rounding_method", "Rounding"),
			]},
		],
		"tables": [
			{"fieldname": "bands", "label": "Salary bands", "fields": [
				("lower_salary", "Lower Salary"), ("upper_salary", "Upper Salary"),
				("employee_value", "Employee Amount / %"), ("employer_value", "Employer Amount / %"),
				("is_open_ended", "No Upper Limit"),
			]},
		],
		"admin": ["version", "effective_from", "effective_to", "configuration_version", "company",
			"employer_salary_component", "allow_band_gaps",
			"source_reference", "notes"],
		"config_type": "Contribution",
		"versioned": "scheme_code",
		"automated": "contribution",
		"list": ["scheme_code", "description", "calculation_mode", "effective_from", "is_active"],
		"actions": [],
	},
	"Payroll Compensation Scheme": {
		"title": "description",
		"subtitle": "scheme_code",
		"sections": [
			{"label": "Compensation", "fields": [
				("scheme_code", "Compensation Code"), ("description", "Description"),
				("compensation_pdb_code", "PDB Code"), ("calculation_method", "Method"),
				("basis_operation_code", "Salary Basis"), ("is_active", "Active"),
			]},
			{"label": "Applies to", "fields": [
				("employment_type", "Employment Type"), ("department", "Department"),
				("designation", "Designation"), ("prb_grade", "PRB Grade"),
			]},
		],
		"tables": [
			{"fieldname": "bands", "label": "Salary bands", "fields": [
				("lower_salary", "Lower Salary"), ("upper_salary", "Upper Salary"),
				("percentage", "Percentage"), ("flat_amount", "Flat Amount"), ("is_open_ended", "No Upper Limit"),
			]},
		],
		"admin": ["version", "rounding_precision", "rounding_method", "effective_from", "effective_to",
			"configuration_version", "company", "allow_band_gaps", "source_reference", "notes"],
		"config_type": "Compensation",
		"versioned": "scheme_code",
		"automated": "compensation",
		"list": ["scheme_code", "description", "calculation_method", "effective_from", "is_active"],
		"actions": [],
	},
	"Payroll PAYE Year": {
		"title": "tax_year",
		"subtitle": "version",
		"sections": [
			{"label": "PAYE Year", "fields": [
				("tax_year", "PAYE Year"), ("effective_from", "Effective Date"),
				("effective_to", "Effective To"), ("is_active", "Active"),
			]},
			{"label": "Parameters", "fields": [
				("periods_per_year", "PAYE Periods"), ("current_paye_rounding", "Current PAYE Rounding"),
				("no_edf_rate", "No-EDF Rate %"),
				("no_edf_optional_rate", "No-EDF Optional Rate %"),
				("band_boundary_rounding", "Band Boundary Rounding"),
				("monthly_no_paye_threshold", "Monthly No-PAYE Threshold"),
				("director_flat_rate", "Director / Board Flat Rate %"),
				("fair_share_threshold", "Fair Share Threshold"), ("fair_share_rate", "Fair Share Rate %"),
			]},
			{"label": "IET — Income Exemption Threshold", "fields": [
				("dependent_1_relief", "One Dependent"), ("dependent_2_relief", "Two Dependents"),
				("dependent_3_relief", "Three Dependents"), ("dependent_4_plus_relief", "Four or More"),
			]},
		],
		"tables": [
			{"fieldname": "bands", "label": "Tax bands", "fields": [
				("upper_chargeable_income", "Tax Band To"), ("tax_rate", "Tax Rate %"), ("is_open_ended", "No Upper Limit"),
			]},
		],
		"admin": ["version", "currency_precision", "configuration_version", "company", "source_reference"],
		"config_type": "PAYE",
		"versioned": "tax_year",
		"automated": "paye_year",
		"list": ["tax_year", "version", "effective_from", "is_active"],
		"actions": [],
	},
	"Employee Tax Declaration": {
		"title": "employee",
		"subtitle": "tax_year",
		"sections": [
			{"label": "EDF", "fields": [
				("employee", "Employee Code"),
				{"fieldname": "tax_year", "label": "PAYE Year", "read_only": 1, "hint": "Selected from the effective date."},
				{"fieldname": "company", "label": "Company", "read_only": 1},
				{"fieldname": "currency", "label": "Calculation Currency", "read_only": 1},
				("declaration_status", "EDF Status"), ("emolument_type", "Emolument Type"),
				("employment_basis", "First or Later Employment"), ("appointment_date", "Appointment Date"),
				("tax_residency", "Tax Residency"), ("spouse_claims_dependents", "Spouse Claims Dependents"),
				("effective_from", "Effective Date"), ("effective_to", "Effective To"),
			]},
			{"label": "Reliefs", "fields": [
				{"fieldname": "number_of_dependents", "label": "Eligible Dependents", "read_only": 1},
				{"fieldname": "no_edf_rate_option", "label": "Calculated No-EDF Rate", "read_only": 1},
				{"fieldname": "annual_reliefs", "label": "Approved Other Reliefs / Deductions"},
				{"fieldname": "annual_iet", "label": "Calculated Dependent Deduction", "read_only": 1},
				{"fieldname": "total_annual_edf_amount", "label": "Total Annual EDF / IET", "read_only": 1},
				{"fieldname": "imported_edf_amount", "label": "Imported Legacy EDF Amount", "read_only": 1},
				{"fieldname": "prior_employment_emoluments", "label": "Imported Prior Emoluments", "read_only": 1},
				{"fieldname": "prior_employment_paye", "label": "Imported Prior PAYE", "read_only": 1},
				{"fieldname": "calculation_explanation", "label": "How PAYE Is Calculated", "read_only": 1, "wide": 1},
			]},
		],
		"tables": [
			{"fieldname": "dependents", "label": "Dependent eligibility", "fields": [
				("dependent_name", "Dependent Name"), ("relationship", "MRA Category"),
				("meets_definition", "Evidence Confirmed"),
				("annual_net_and_exempt_income", "Annual Net + Exempt Income"),
				("eligible", "Eligible"), ("ineligibility_reason", "Reason"),
			]},
		],
		"admin": ["previous_declaration", "source_reference", "source_file", "source_opening_record"],
		"automated": "tax_declaration",
		"list": ["employee", "tax_year", "declaration_status", "number_of_dependents", "annual_iet", "effective_from"],
		"actions": [],
	},
	"EDF PAYE Opening": {
		"title": "employee",
		"subtitle": "payroll_period",
		"native_lifecycle": True,
		"sections": [
			{"label": "Legacy EDF / PAYE opening data", "fields": [
				{"fieldname": "financial_year", "read_only": 1, "hint": "Filled from the effective PAYE year."},
				{"fieldname": "payroll_period", "read_only": 1, "hint": "Filled from the employee's active payroll cycle."},
				"employee", {"fieldname": "edf_reference", "label": "EDF Reference", "read_only": 1,
					"hint": "Loaded from the submitted employee EDF; the EDF document ID is used when no external reference was entered."},
				"edf_amount", "edf_effective_date", "first_employment", "appointment_date",
				"previous_emoluments", "previous_paye_paid", "taxable_travelling",
				"taxable_benefits", "legacy_paye", "no_edf",
				{"fieldname": "source_evidence", "wide": 1},
				{"fieldname": "remarks", "wide": 1},
			]},
			{"label": "Resolved target records", "fields": [
				"company", "currency", "paye_year", "employee_tax_declaration",
				"period_start", "period_end", "payroll_cycle", "salary_slip",
			]},
			{"label": "Parallel-run result", "fields": [
				"calculation_status", "target_paye", "paye_variance",
			]},
		],
		"admin": ["source_file"],
		"list": ["employee", "financial_year", "payroll_period", "legacy_paye", "target_paye", "paye_variance", "calculation_status"],
		"actions": [],
	},
	"Payroll Type": {
		"title": "payroll_type_name",
		"subtitle": "payroll_type_code",
		"sections": [
			{"label": "Payroll Type", "fields": [
				("payroll_type_code", "Payroll Type Code"),
				("payroll_type_name", "Payroll Type Name"),
				("processing_scope", "Processing Scope"),
				("sequence", "Processing Sequence"),
				("is_active", "Active"),
				{"fieldname": "description", "label": "Description", "wide": 1},
			]},
		],
		"list": ["payroll_type_code", "payroll_type_name", "processing_scope", "sequence", "is_active"],
		"actions": [],
	},
	"Employee Payroll Group": {
		"title": "payroll_group_name",
		"subtitle": "payroll_group_code",
		"sections": [
			{"label": "Payroll Group", "fields": [
				("payroll_group_code", "Payroll Group Code"),
				("payroll_group_name", "Payroll Group Name"),
				{"fieldname": "description", "label": "Description", "wide": 1},
				("disabled", "Disabled"),
			]},
		],
		"list": ["payroll_group_code", "payroll_group_name", "description", "disabled"],
		"actions": [],
	},
	"Pay Day": {
		"title": "pay_day_name",
		"subtitle": "pay_day_code",
		"sections": [
			{"label": "Pay Day Master", "fields": [
				("pay_day_code", "Pay Day Code"), ("pay_day_name", "Pay Day Name"),
				("company", "Company"), ("payroll_type", "Payroll Type"),
				("payroll_group", "Payroll Group"), ("is_active", "Active"),
			]},
			{"label": "Recurring Schedule", "fields": [
				("day_of_month", "Day of Month"), ("cutoff_lead_days", "Cut-off Lead Days"),
				{"fieldname": "description", "label": "Description", "wide": 1},
			]},
		],
		"list": ["pay_day_code", "pay_day_name", "payroll_type", "payroll_group", "day_of_month", "is_active"],
		"actions": [],
	},
	"Payroll Pay Day": {
		"title": "pay_period_label",
		"subtitle": "pay_day_code",
		"sections": [
			{"label": "Pay Day", "fields": [
				("pay_day_master", "Pay Day Master"), ("payroll_type", "Payroll Type"),
				("pay_day_code", "Pay Day"),
				("pay_period_label", "Pay Period"), ("payroll_group", "Payroll Group"),
				("status", "Status"),
			]},
			{"label": "Period", "fields": [
				("start_date", "Start Date"), ("end_date", "End Date"),
				("payment_date", "Payment Date"), ("input_cutoff_date", "Input Cut-off"),
				{"fieldname": "work_days", "label": "Work Days", "read_only": 1,
					"hint": "Automatically calculated from the company Holiday List, including weekly offs"},
				("paye_payment_type", "PAYE Payment Type"),
				{"fieldname": "paye_period_index", "label": "PAYE Period Position", "read_only": 1},
			]},
		],
		"admin": ["company", "payroll_period", "configuration_version", "source_reference", "notes"],
		"config_type": "Payroll Calendar",
		"automated": "pay_day",
		"list": ["pay_period_label", "payroll_type", "start_date", "end_date", "payment_date", "work_days", "status"],
		"actions": [
			{"key": "activate", "label": "Set active", "handler": "pay_day_status", "args": {"status": "Active"},
				"when": {"status": ["Planned"]}, "primary": True,
				"confirm": "Make this the active pay period? Only one period per payroll type can be open."},
			{"key": "cancel", "label": "Cancel pay day", "handler": "pay_day_status", "args": {"status": "Cancelled"},
				"when": {"status": ["Planned"]}, "danger": True, "confirm": "Cancel this pay day?"},
			{"key": "close_pay_day", "label": "Close Pay Day", "handler": "pay_day_status", "args": {"status": "Closed"},
				"when": {"status": ["Active", "Processing"]}, "role": "finance", "primary": True,
				"confirm": "Close this pay day? The linked payroll cycle must already be closed."},
		],
	},
	"Employee Recurring PDB": {
		"label": "Static Payment and Deduction",
		"title": "pdb_code",
		"subtitle": "employee_name",
		"sections": [
			{"label": "Static Payment and Deduction", "fields": [
				("employee", "Employee Code"), ("pdb_code", "PDB Code"),
				{"fieldname": "transaction_type", "label": "Payment / Deduction", "read_only": 1},
				("calculation_method", "Calculation Basis"), ("amount", "Amount / Rate"),
				("start_date", "Effective From"), ("end_date", "Effective To"),
				{"fieldname": "formula", "label": "Formula", "wide": 1},
				{"fieldname": "remarks", "label": "Remarks", "wide": 1},
			]},
			{"label": "Salary scale (basic salary)", "fields": [
				("salary_scale", "Salary Scale"), ("salary_step", "Salary Step"),
			]},
			{"label": "Deduction details", "fields": [
				("initial_balance", "Outstanding / Reducing Balance"), ("priority", "Priority"),
				{"fieldname": "remaining_balance", "label": "Remaining Balance", "read_only": 1},
			]},
		],
		"admin": ["company", "pdb_type", "salary_component", "is_reducing_balance", "status", "change_reason"],
		"automated": "recurring",
		"list": ["pdb_code", "transaction_type", "amount", "calculation_method", "start_date", "end_date", "priority", "status"],
		"actions": [
			{"key": "activate", "label": "Activate", "method": "karyo.payroll.recurring.change_recurring_status",
				"args": {"status": "Active"}, "reason": True, "when": {"status": ["Draft", "Suspended"]}, "primary": True},
			{"key": "suspend", "label": "Suspend", "method": "karyo.payroll.recurring.change_recurring_status",
				"args": {"status": "Suspended"}, "reason": True, "when": {"status": ["Active"]}},
			{"key": "complete", "label": "Complete", "method": "karyo.payroll.recurring.change_recurring_status",
				"args": {"status": "Completed"}, "reason": True, "when": {"status": ["Active"]}},
			{"key": "cancel", "label": "Cancel", "method": "karyo.payroll.recurring.change_recurring_status",
				"args": {"status": "Cancelled"}, "reason": True, "when": {"status": ["Draft", "Active", "Suspended"]}, "danger": True},
		],
	},
	"Once-Off PDB Batch": {
		"title": "batch_description",
		"subtitle": "pay_period_label",
		"sections": [
			{"label": "Once-off batch", "fields": [
				("payroll_cycle", "Pay Period"), ("batch_description", "Description"),
				{"fieldname": "status", "label": "Status", "read_only": 1},
			]},
		],
		"tables": [
			{"fieldname": "lines", "label": "Payments / deductions", "fields": [
				("employee", "Employee Code"), ("pdb_code", "PDB Code"), ("amount", "Amount"),
				("cost_center", "Cost Centre"), ("remarks", "Remarks"),
			]},
		],
		"admin": ["company", "decision_reason"],
		"automated": "once_off",
		"list": ["batch_description", "pay_period_label", "line_count", "control_total", "status"],
		"actions": [
			{"key": "approve", "label": "Approve", "method": "karyo.payroll.once_off.approve_batch",
				"when": {"status": ["Draft"]}, "primary": True, "role": "approver"},
			{"key": "post", "label": "Post to payroll", "method": "karyo.payroll.once_off.post_batch",
				"when": {"status": ["Approved"]}, "primary": True, "danger": True,
				"confirm": "Post every line as an Additional Salary on this pay period?"},
			{"key": "reverse", "label": "Reverse & amend", "method": "karyo.payroll.once_off.reverse_and_amend",
				"reason": True, "when": {"status": ["Posted"]}, "danger": True},
		],
	},
	"Exceptional Payroll Batch": {
		"title": "description",
		"subtitle": "pay_period_label",
		"sections": [
			{"label": "Separate payment / deduction", "fields": [
				("payroll_cycle", "Pay Period"), ("description", "Description"),
				{"fieldname": "exception_reason", "label": "Reason", "wide": 1},
				{"fieldname": "status", "label": "Status", "read_only": 1},
			]},
		],
		"tables": [
			{"fieldname": "lines", "label": "Employee lines", "fields": [
				("employee", "Employee Code"), ("pdb_code", "PDB Code"), ("amount", "Amount"),
				("calculate_tax", "Calculate Tax"), ("reason", "Remarks"),
			]},
		],
		"admin": ["company", "supporting_attachment", "decision_reason"],
		"automated": "exceptional",
		"list": ["description", "pay_period_label", "line_count", "control_total", "status"],
		"actions": [
			{"key": "review", "label": "Mark reviewed", "method": "karyo.payroll.exceptional.review_batch",
				"when": {"status": ["Draft"]}, "primary": True, "role": "approver"},
			{"key": "approve", "label": "Approve", "method": "karyo.payroll.exceptional.approve_batch",
				"when": {"status": ["Reviewed"]}, "primary": True, "role": "finance"},
			{"key": "post", "label": "Post to register", "method": "karyo.payroll.exceptional.post_batch",
				"when": {"status": ["Approved"]}, "primary": True, "danger": True,
				"confirm": "Post these separate payments to the payroll register?"},
			{"key": "reverse", "label": "Reverse", "method": "karyo.payroll.exceptional.reverse_batch",
				"reason": True, "when": {"status": ["Posted"]}, "danger": True},
		],
	},
	"Bulk Payroll Run": {
		"title": "run_title",
		"subtitle": "run_type",
		"sections": [
			{"label": "Bulk run", "fields": [
				("run_title", "Title"), ("run_type", "Processing Type"),
				("effective_date", "Effective Date"), ("payroll_cycle", "Pay Period"),
				("compensation_scheme", "Compensation Table"),
				("pdb_type", "Posting PDB Type"), ("pdb_code", "Posting PDB Code"),
				{"fieldname": "status", "label": "Status", "read_only": 1},
			]},
			{"label": "Employee Selection", "fields": [
				("include_retired", "Include retired (EOY bonus)"),
			]},
			{"label": "Remarks", "fields": [
				{"fieldname": "remarks", "label": "Remarks", "wide": 1},
			]},
		],
		"tables": [
			{"fieldname": "lines", "label": "Selected Employees and Calculation", "fixed_rows": 1, "expanded": 1, "fields": [
				{"fieldname": "employee", "label": "Employee", "read_only": 1}, ("employee_name", "Name"),
				("salary_scale", "Increment Table"), ("increment_source", "Source"),
				("increment_steps", "Increment Points"), ("applied_increment_points", "Applied Points"),
				("original_salary_point", "Current Point"), ("proposed_salary_point", "Proposed Point"),
				("increment_base", "Basic Salary"), ("proposed_salary", "Proposed Salary"),
				("increment_amount", "Calculated Increment"),
				("compensation_amount", "Calculated Compensation"), ("eoy_amount", "Calculated EOY Bonus"),
				("calculated_total", "Calculated Total"), ("include", "Include"),
				("override_enabled", "Override"), ("override_amount", "Override Amount"),
				("override_reason", "Override Reason"), ("final_total", "Final"),
				("exception_code", "Exception"), ("exception_detail", "Exception Detail"),
			]},
		],
		"admin": ["company", "period_start", "period_end"],
		"automated": "bulk_run",
		"list": ["run_title", "run_type", "effective_date", "employee_count", "calculated_total", "status"],
		"actions": [
			{"key": "calculate", "label": "Process", "method": "karyo.payroll.bulk.calculate_run",
				"when": {"status": ["Draft", "Calculated"]}, "primary": True},
			{"key": "approve", "label": "Approve", "method": "karyo.payroll.bulk.approve_run",
				"when": {"status": ["Calculated"]}, "primary": True, "role": "approver"},
			{"key": "apply", "label": "Apply", "method": "karyo.payroll.bulk.apply_run",
				"when": {"status": ["Approved"]}, "primary": True, "danger": True,
				"confirm": "Apply the approved amounts to the employees' payroll?"},
		],
		"note": "Enter each employee's Increment Points. The value of one point comes from the effective approved increment band (for example, point value 100 means 1 point = 100 and 2 points = 200). Movements are capped at the salary-scale maximum.",
	},
	"Payroll Transaction Import": {
		"title": "name",
		"subtitle": "upload_type",
		"sections": [
			{"label": "Upload", "fields": [
				("upload_type", "Upload Type"), ("payroll_cycle", "Pay Period"),
				("template_version", "Template"), {"fieldname": "status", "label": "Status", "read_only": 1},
			]},
		],
		"tables": [
			{"fieldname": "rows", "label": "Uploaded rows", "read_only": 1, "fields": [
				("row_number", "Row"), ("employee", "Employee"), ("pdb_code", "PDB Code"),
				("amount", "Amount"), ("status", "Status"), ("validation_message", "Message"),
			]},
		],
		"admin": ["company", "csv_file", "decision_reason"],
		"automated": "transaction_import",
		"list": ["upload_type", "payroll_cycle", "total_rows", "valid_rows", "invalid_rows", "status"],
		"actions": [
			{"key": "approve", "label": "Approve", "method": "karyo.payroll.transaction_import.approve_import",
				"when": {"status": ["Validated"]}, "primary": True, "role": "approver"},
			{"key": "reject", "label": "Reject", "method": "karyo.payroll.transaction_import.reject_import",
				"reason": True, "when": {"status": ["Uploaded", "Validated"]}, "danger": True},
			{"key": "post", "label": "Post to payroll", "method": "karyo.payroll.transaction_import.post_import",
				"when": {"status": ["Approved"]}, "primary": True, "danger": True,
				"confirm": "Create the payroll transactions from this upload?"},
		],
	},
	"Payroll Statutory Result": {
		"title": "employee",
		"subtitle": "result_type",
		"sections": [
			{"label": "Result", "fields": [
				{"fieldname": "employee", "label": "Employee", "read_only": 1},
				{"fieldname": "result_type", "label": "Type", "read_only": 1},
				{"fieldname": "rule_reference", "label": "Rule / Scheme", "read_only": 1},
				{"fieldname": "salary_basis", "label": "Basis", "read_only": 1},
				{"fieldname": "chargeable_income", "label": "Chargeable Income", "read_only": 1},
				{"fieldname": "current_amount", "label": "This Period", "read_only": 1},
				{"fieldname": "cumulative_amount", "label": "Cumulative", "read_only": 1},
				{"fieldname": "status", "label": "Status", "read_only": 1},
			]},
		],
		"admin": ["configuration_version", "source_declaration", "salary_slip", "calculation_hash"],
		"read_only": True,
		"automated": "statutory_result",
		"list": ["employee", "result_type", "rule_reference", "current_amount", "status"],
		"actions": [],
	},
	"Salary Slip": {
		"title": "employee_name",
		"subtitle": "employee",
		"sections": [
			{"label": "Payslip", "fields": [
				{"fieldname": "employee", "label": "Employee Code", "read_only": 1},
				{"fieldname": "employee_name", "label": "Name", "read_only": 1},
				{"fieldname": "start_date", "label": "From", "read_only": 1},
				{"fieldname": "end_date", "label": "To", "read_only": 1},
				{"fieldname": "payment_days", "label": "Payment Days", "read_only": 1},
				{"fieldname": "gross_pay", "label": "Gross Pay", "read_only": 1},
				{"fieldname": "total_deduction", "label": "Total Deductions", "read_only": 1},
				{"fieldname": "net_pay", "label": "Net Pay", "read_only": 1},
			]},
			{"label": "Salary Bank Transfer", "fields": [
				{"fieldname": "karyo_primary_remittance_bank", "label": "Primary Bank", "read_only": 1},
				{"fieldname": "karyo_primary_remittance_branch", "label": "Primary Branch", "read_only": 1},
				{"fieldname": "karyo_primary_remittance_account", "label": "Primary Account", "read_only": 1},
				{"fieldname": "karyo_primary_remittance_amount", "label": "Primary Amount (Net Balance)", "read_only": 1},
				{"fieldname": "karyo_secondary_remittance_bank", "label": "Secondary Bank", "read_only": 1},
				{"fieldname": "karyo_secondary_remittance_branch", "label": "Secondary Branch", "read_only": 1},
				{"fieldname": "karyo_secondary_remittance_account", "label": "Secondary Account", "read_only": 1},
				{"fieldname": "karyo_secondary_remittance_amount", "label": "Secondary Fixed Amount", "read_only": 1},
			]},
		],
		"admin": ["payroll_entry", "salary_structure", "mode_of_payment"],
		"read_only": True,
		"automated": "salary_slip",
		"list": ["employee", "employee_name", "gross_pay", "total_deduction", "net_pay", "status"],
		"actions": [],
	},
	"Payroll Cycle": {
		"title": "pay_period_label",
		"subtitle": "payroll_type",
		"sections": [
			{"label": "Payroll cycle", "fields": [
				{"fieldname": "pay_day", "label": "Pay Day", "read_only": 1},
				{"fieldname": "payroll_type", "label": "Minor / Major", "read_only": 1},
				{"fieldname": "start_date", "label": "Start Date", "read_only": 1},
				{"fieldname": "end_date", "label": "End Date", "read_only": 1},
				{"fieldname": "payment_date", "label": "Payment Date", "read_only": 1},
				{"fieldname": "status", "label": "Status", "read_only": 1},
			]},
		],
		"admin": ["payroll_entry", "readiness_status", "minor_sequence_waived", "minor_waiver_reason"],
		"read_only": True,
		"automated": "payroll_cycle",
		"list": ["pay_period_label", "payroll_type", "start_date", "end_date", "employee_count", "status"],
		"actions": [],
	},
}


# --- Screens ------------------------------------------------------------------
#
# ``layout`` picks the renderer:
#   master_detail  two lists; the detail list is filtered by the selected master
#   list           one list with optional versions grouping
#   tabs           several lists/forms behind tabs
#   employee       employee search strip, then the employee's records
#   batches        pay-period selector, then batches for that period
#   upload         CSV upload card plus the import list
#   wizard         one payroll cycle with the month-end steps for the screen
#   query          filterable table over processed data
#   payslips       payslip list with an inline preview
#   salary_sheet   generated salary sheet for one pay day
#   reports / checklist / dashboard / profile   bespoke

SCREENS = {
	"dashboard": {"layout": "dashboard", "group": "Overview", "title": "Payroll Management Dashboard"},
	"payrollsetup": {
		"layout": "setup_wizard", "group": "Set Up Payroll Parameters", "title": "Employee Payroll Setup",
	},
	"company": {
		"layout": "profile", "group": "Set Up Payroll Parameters", "title": "Maintain Company Profile",
		"doctype": "Company",
	},
	"payrolltypes": {
		"layout": "list", "group": "Set Up Payroll Parameters", "title": "Maintain Payroll Types",
		"doctype": "Payroll Type", "new_label": "New Payroll Type", "order_by": "sequence asc, name asc",
	},
	"payrollgroups": {
		"layout": "list", "group": "Set Up Payroll Parameters", "title": "Maintain Payroll Groups",
		"doctype": "Employee Payroll Group", "new_label": "New Payroll Group",
		"order_by": "payroll_group_code asc, name asc",
	},
	"paydaymasters": {
		"layout": "list", "group": "Set Up Payroll Parameters", "title": "Maintain Pay Day Masters",
		"doctype": "Pay Day", "new_label": "New Pay Day Master", "order_by": "company asc, day_of_month asc",
	},
	"pdb": {
		"layout": "master_detail", "group": "Set Up Payroll Parameters", "title": "Maintain PDB Type and Code",
		"master": {"doctype": "Payroll PDB Type", "label": "PDB Types", "new_label": "Add PDB Type"},
		"detail": {"doctype": "Payroll PDB Code", "label": "PDB Codes", "link_field": "pdb_type",
			"new_label": "Add PDB Code"},
	},
	"bank": {
		"layout": "master_detail", "group": "Set Up Payroll Parameters", "title": "Manage Bank and Branch",
		"master": {"doctype": "Bank", "label": "Banks", "new_label": "Add Bank"},
		"detail": {"doctype": "Payroll Bank Branch", "label": "Branches", "link_field": "bank",
			"new_label": "Add Branch"},
	},
	"opcodes": {
		"layout": "master_detail", "group": "Set Up Payroll Parameters", "title": "Manage Operations Code",
		"master": {"doctype": "Payroll Operation Code", "label": "Operation Codes", "new_label": "Add Operation Code"},
		"detail": {"child": "items", "label": "PDB codes in this operation",
			"columns": [
				("pdb_code", "PDB Code"), ("description", "Description"),
				("sequence", "Sequence"), ("aggregation_sign", "Sign"),
				("inclusion_percentage", "Inclusion % / Weight"),
				("salary_basis_treatment", "Salary-Basis Treatment"),
				("effective_from", "Effective From"), ("effective_to", "Effective To"),
				("remarks", "Remarks"),
			]},
		"note": "Create operation codes here, then add or remove the PDB codes grouped under each operation.",
	},
	"contribution": {
		"layout": "list", "group": "Set Up Payroll Parameters", "title": "Maintain Contribution Table",
		"doctype": "Payroll Contribution Scheme", "new_label": "New Contribution", "versioned": True,
	},
	"compensation": {
		"layout": "list", "group": "Set Up Payroll Parameters", "title": "Maintain Compensation Table",
		"doctype": "Payroll Compensation Scheme", "new_label": "New Compensation", "versioned": True,
	},
	"paye": {
		"layout": "tabs", "group": "Set Up Payroll Parameters", "title": "PAYE Setup",
		"tabs": [
			{"key": "table", "label": "PAYE Table", "doctype": "Payroll PAYE Year", "new_label": "New PAYE Year", "versioned": True},
			{"key": "edf", "label": "EDF / IET", "doctype": "Employee Tax Declaration", "new_label": "Record New / Fresh EDF",
				"employee_filter": True},
			{"key": "openings", "label": "EDF/PAYE Openings", "doctype": "EDF PAYE Opening", "new_label": "New Opening Record",
				"employee_filter": True},
		],
	},
	"paydays": {
		"layout": "list", "group": "Payroll Processing End of Month", "title": "Maintain Pay Days",
		"doctype": "Payroll Pay Day", "new_label": "New Pay Day", "order_by": "start_date desc",
		"status_filter": ["Planned", "Active", "Processing", "Closed", "Cancelled"],
	},
	"static": {
		"layout": "employee", "group": "Payroll Transactions", "title": "Static Payment and Deduction",
		"doctype": "Employee Recurring PDB", "new_label": "Add Static Payment / Deduction",
	},
	"onceoff": {
		"layout": "batches", "group": "Payroll Transactions", "title": "Maintain Once-Off Payments/Deductions",
		"doctype": "Once-Off PDB Batch", "new_label": "New Once-Off Batch",
	},
	"load": {
		"layout": "upload", "group": "Payroll Transactions", "title": "Load Payment / Deduction",
		"doctype": "Payroll Transaction Import",
	},
	"separate": {
		"layout": "batches", "group": "Payroll Processing End of Month", "title": "Record Separate Payments/Deductions",
		"doctype": "Exceptional Payroll Batch", "new_label": "New Separate Payment",
		"note": "Use only for genuine cases; normal transactions go through payroll processing.",
	},
	"bulk": {
		"layout": "list", "group": "Payroll EOY", "title": "Compensation / Increment / EOY Bonus",
		"doctype": "Bulk Payroll Run", "new_label": "New Bulk Run",
		"note": "Process increments before compensation. EOY bonus is pro-rated on days worked excluding LWP/LWNP.",
	},
	"query": {
		"layout": "query", "group": "Query / Generate Payroll Processed Data", "title": "Query Payroll and Payslip",
		"doctype": "Salary Slip",
	},
	"payequery": {
		"layout": "paye_query", "group": "Query / Generate Payroll Processed Data",
		"title": "Query PAYE Computation",
	},
	"contribgen": {
		"layout": "query", "group": "Query / Generate Payroll Processed Data", "title": "Contributions Generated",
		"doctype": "Payroll Statutory Result",
	},
	"payslipgen": {
		"layout": "payslips", "group": "Query / Generate Payroll Processed Data", "title": "Generate Payslip",
		"doctype": "Salary Slip",
	},
	"salarysheet": {
		"layout": "salary_sheet", "group": "Generate Outputs", "title": "Salary Sheet",
		"doctype": "Salary Slip",
	},
	"overtime": {"layout": "prepayroll", "group": "Payroll Processing End of Month", "title": "Before Process Payroll · Additional Earnings"},
	"attendancebonus": {
		"layout": "list", "group": "Payroll Processing End of Month",
		"title": "Attendance Bonus", "doctype": "PRB Payroll Run",
		"new_label": "Calculate Attendance Bonus",
		"run_purpose": "Attendance Bonus",
		"visible_run_purposes": ["Attendance Bonus", "PRB Attendance Bonuses"],
		"bonus_inputs": [
			{"category": "Allowance", "input_code": "ATTENDANCE_BONUS", "description": "Attendance Bonus"},
		],
		"note": "Prepare Payroll automatically calculates and posts this bonus for every qualifying employee. This screen shows the generated result; use Calculate Attendance Bonus only for a governed correction or exceptional recalculation.",
	},
	"incentiveattendancebonus": {
		"layout": "list", "group": "Payroll Processing End of Month",
		"title": "Incentive Attendance Bonus", "doctype": "PRB Payroll Run",
		"new_label": "Calculate Incentive Attendance Bonus",
		"run_purpose": "Incentive Attendance Bonus",
		"visible_run_purposes": ["Incentive Attendance Bonus", "PRB Attendance Bonuses"],
		"bonus_inputs": [
			{"category": "Allowance", "input_code": "INCENTIVE_ATTENDANCE", "description": "Incentive Attendance Bonus"},
		],
		"note": "Prepare Payroll automatically calculates and posts this bonus for every qualifying employee. This screen shows the generated result; use Calculate Incentive Attendance Bonus only for a governed correction or exceptional recalculation.",
	},
	"presencebonus": {
		"layout": "attendance_bonus", "group": "Payroll Processing End of Month",
		"title": "PRB Attendance Bonus (Attendance + Incentive)", "doctype": "PRB Payroll Run",
		"new_label": "Calculate PRB Attendance Bonuses",
		"run_purpose": "PRB Attendance Bonuses",
		"bonus_inputs": [
			{"category": "Allowance", "input_code": "ATTENDANCE_BONUS", "description": "Attendance Bonus"},
			{"category": "Allowance", "input_code": "INCENTIVE_ATTENDANCE", "description": "Incentive Attendance Bonus"},
		],
		"note": "Process the selected month for one employee or the full payroll population. Review the two bonus amounts, approve the calculation, then submit the mapped components to payroll.",
	},
	"erahours": {
		"layout": "attendance_bonus", "group": "Payroll Processing End of Month",
		"title": "ERA Hours Payment", "doctype": "PRB Payroll Run",
		"new_label": "Calculate ERA Hours Payment",
		"run_purpose": "ERA Hours Payment",
		"governed_inputs": [
			{"category": "Allowance", "input_code": "ERA_HOURS", "description": "ERA Hours Payment", "quantity": 0, "rate": 0, "amount": 0},
		],
		"note": "Process one employee, several selected employees, or the full payroll population from approved Excess Hours records. Review the ERA result, approve it, then submit it to payroll. Below 15 hours pays zero; 15 to 30 hours is prorated; above 30 hours receives the full eligible salary-band amount. One casual-leave day is exempt and other absence is deducted over 22 working days.",
	},
	"process": {"layout": "wizard", "group": "Payroll Processing End of Month", "title": "Process Payroll"},
	"applypaye": {"layout": "wizard", "group": "Payroll Processing End of Month", "title": "Process / Apply PAYE"},
	"close": {"layout": "wizard", "group": "Payroll Processing End of Month", "title": "Close Payroll"},
	"board": {
		"layout": "batches", "group": "Board Sitting", "title": "Board Sitting Computation",
		"doctype": "Once-Off PDB Batch", "new_label": "New Sitting Batch", "board": True,
	},
	"reports": {"layout": "reports", "group": "Reports", "title": "Payroll Reports and Bank Files"},
	"checklist": {"layout": "checklist", "group": "Annexures", "title": "Payroll Processing Checklist"},
}

# Doctypes each screen may read or write through the desk endpoints.
SCREEN_DOCTYPES = {
	"dashboard": ["Payroll Cycle", "Payroll Pay Day"],
	"payrollsetup": ["Company", "Payroll Type", "Employee Payroll Group", "Pay Day", "Salary Increment Band", "Salary Scale",
		"Employee Grade", "Payroll PDB Type", "Payroll PDB Code", "Payroll Operation Code",
		"Payroll Contribution Scheme", "Payroll PAYE Year", "Payroll Bank Branch",
		"Employee", "Salary Structure", "Salary Structure Assignment", "Employee Salary Appointment",
		"Payroll Cycle", "Payroll Cycle Employee"],
	"company": ["Company"],
	"payrolltypes": ["Payroll Type"],
	"payrollgroups": ["Employee Payroll Group"],
	"paydaymasters": ["Pay Day"],
	"pdb": ["Payroll PDB Type", "Payroll PDB Code"],
	"bank": ["Bank", "Payroll Bank Branch"],
	"opcodes": ["Payroll Operation Code"],
	"contribution": ["Payroll Contribution Scheme"],
	"compensation": ["Payroll Compensation Scheme"],
	"paye": ["Payroll PAYE Year", "Employee Tax Declaration", "EDF PAYE Opening"],
	"paydays": ["Payroll Pay Day"],
	"static": ["Employee Recurring PDB"],
	"onceoff": ["Once-Off PDB Batch"],
	"load": ["Payroll Transaction Import", "Payroll Transaction Import Template"],
	"separate": ["Exceptional Payroll Batch"],
	"bulk": ["Bulk Payroll Run"],
	"process": ["Payroll Cycle", "Payroll Pay Day"],
	"overtime": ["PRB Overtime Authorization", "PRB Higher Duty Assignment", "PRB Payroll Run", "Payroll Cycle", "Employee"],
	"applypaye": ["Payroll Cycle", "Payroll Statutory Result"],
	"query": ["Salary Slip", "Payroll Cycle"],
	"payequery": ["Payroll Statutory Result", "Payroll Cycle", "Salary Slip", "Employee", "Payroll PAYE Year", "Employee Tax Declaration"],
	"contribgen": ["Payroll Statutory Result"],
	"payslipgen": ["Salary Slip"],
	"salarysheet": ["Salary Slip", "Payroll Cycle", "Payroll Pay Day"],
	"close": ["Payroll Cycle"],
	"attendancebonus": ["PRB Payroll Run", "Payroll Cycle", "Employee", "Attendance"],
	"incentiveattendancebonus": ["PRB Payroll Run", "Payroll Cycle", "Employee", "Attendance"],
	"presencebonus": ["PRB Payroll Run", "Payroll Cycle", "Employee", "Attendance"],
	"erahours": ["PRB Payroll Run", "Payroll Cycle", "Employee", "Attendance"],
	"board": ["Once-Off PDB Batch"],
	"reports": ["Payroll Cycle"],
	"checklist": ["Payroll Cycle", "Payroll Readiness Exception"],
}

# Employee header strip on the employee-centric screens — the manual's
# "Employee Details" block, in its order.
EMPLOYEE_STRIP = [
	("name", "Code"), ("salutation", "Title"), ("karyo_national_id", "NID"),
	("last_name", "Surname"), ("first_name", "First Name"),
	("karyo_prb_grade", "Substantive Grade"), ("karyo_temporary_grade", "Temp Grade"),
	("department", "Department"), ("karyo_payroll_group", "Payroll Group"),
	("karyo_payroll_type", "Payroll Type"), ("karyo_pay_day", "Pay Day"),
	("karyo_payroll_bank", "Bank"), ("status", "Status"),
]


def field_spec(entry):
	"""Normalise one ``sections`` entry to a dict."""
	if isinstance(entry, str):
		return {"fieldname": entry}
	if isinstance(entry, tuple):
		return {"fieldname": entry[0], "label": entry[1]}
	return dict(entry)


# Payroll dependencies share the same editor as setup and processing records.
NATIVE_PAYROLL_ENTITIES = {
    "Salary Structure": ["name", "company", "is_active", "docstatus"],
    "Salary Structure Assignment": ["employee", "salary_structure", "from_date", "docstatus"],
    "Salary Component": ["salary_component", "type", "disabled"],
    "Income Tax Slab": ["name", "company", "effective_from", "docstatus"],
    "PRB Grade Scale": ["name"],
    "PRB Salary Point": ["name"],
    "Payroll Configuration Version": ["name", "configuration_type", "configuration_status"],
}
for _doctype, _columns in NATIVE_PAYROLL_ENTITIES.items():
	ENTITIES.setdefault(_doctype, {"title": "name", "list": _columns, "native_fields": True})
ENTITIES["PRB Payroll Run"] = {
	"title": "employee_name", "subtitle": "payroll_cycle", "native_fields": True,
	"list": ["employee", "employee_name", "run_purpose", "custom_entry_source", "payroll_cycle", "gross_pay", "custom_eligibility_status", "posting_status", "docstatus"],
	"sections": [
		{"label": "Employee and payroll cycle", "fields": [
			("employee", "Employee"), ("payroll_cycle", "Payroll Cycle"),
			{"fieldname": "company", "read_only": 1}, {"fieldname": "payroll_period", "read_only": 1},
			{"fieldname": "calculation_date", "label": "Calculation Date"},
			{"fieldname": "run_purpose", "label": "Run Purpose", "read_only": 1},
		]},
		{"label": "Calculated result", "fields": [
			{"fieldname": "basic_salary", "read_only": 1}, {"fieldname": "gross_pay", "read_only": 1},
			{"fieldname": "custom_eligibility_status", "label": "Eligibility", "read_only": 1},
			{"fieldname": "custom_eligibility_reason", "label": "Eligibility Reason", "read_only": 1, "wide": 1},
			{"fieldname": "posting_status", "read_only": 1},
			{"fieldname": "exception_detail", "read_only": 1, "wide": 1},
		]},
	],
	"tables": [{"fieldname": "employee_inputs", "label": "Attendance bonus calculation", "fixed_rows": 1, "fields": [
		{"fieldname": "category", "read_only": 1}, {"fieldname": "input_code", "fieldtype": "Data", "read_only": 1},
		{"fieldname": "description", "read_only": 1}, {"fieldname": "amount", "label": "Base Amount"},
		{"fieldname": "parameters_json", "label": "Calculated Attendance Input", "read_only": 1},
	]}],
	"actions": [{"key": "post", "label": "Post to Payroll", "method": "karyo.payroll.prb_posting.post_run",
		"when": {"docstatus": [1], "posting_status": ["Not Posted"]}, "primary": True,
		"confirm": "Post these approved bonus amounts to payroll?"}],
}
ENTITIES["Employee"] = {
    "title": "employee_name", "list": ["employee_name", "company", "status"], "existing_only": True,
    "sections": [
        {"label": "Employee", "fields": [{"fieldname": "name", "label": "Employee"},
            {"fieldname": "employee_name", "read_only": 1}, {"fieldname": "company", "read_only": 1}]},
		{"label": "Salary and tax", "fields": [("pan_number", "Tax Identifier"), "payroll_cost_center",
			{"fieldname": "karyo_prb_grade", "fieldtype": "Link", "options": "PRB Grade Scale"},
			{"fieldname": "karyo_prb_salary_point", "fieldtype": "Data"}]},
		{"label": "Payment details", "fields": [
			"salary_mode",
			{"fieldname": "karyo_payroll_bank", "label": "Payroll Bank", "read_only": 0},
			{"fieldname": "karyo_payroll_bank_branch", "label": "Payroll Bank Branch", "read_only": 0},
		]},
		{"label": "Prefilled bank and branch details", "fields": [
			{"fieldname": "karyo_bank_code", "read_only": 1},
			{"fieldname": "karyo_bank_transfer_code", "read_only": 1},
			{"fieldname": "karyo_bank_other_code", "read_only": 1},
			{"fieldname": "karyo_branch_code", "read_only": 1},
			{"fieldname": "karyo_branch_name", "read_only": 1},
			{"fieldname": "karyo_branch_transfer_code", "read_only": 1},
			{"fieldname": "karyo_branch_other_code", "read_only": 1},
		]},
    ],
}
ENTITIES["Payroll Readiness Exception"] = {
    "title": "validation_code", "read_only": True,
    "sections": [{"label": "Readiness exception", "fields": ["employee", "validation_code", "severity",
        "message", "status", "remediation_doctype", "remediation_name"]}],
}
SCREENS["salarysetup"] = {
    "layout": "tabs", "group": "Set Up Payroll Parameters", "title": "PDB Payroll Templates & Employee Mappings",
    "note": "PDB Type and PDB Code are the payroll elements. A payroll template groups those codes for calculation; employee mappings are generated only by Employee Payroll Setup.",
    "tabs": [
        {"key": "structures", "label": "PDB Payroll Templates", "doctype": "Salary Structure",
            "new_label": "New PDB Payroll Template"},
        {"key": "assignments", "label": "Generated Employee Mappings", "doctype": "Salary Structure Assignment",
            "no_create": True, "filters": {"karyo_salary_appointment": ("is", "set")}},
    ],
}
SCREEN_DOCTYPES["salarysetup"] = ["Salary Structure", "Salary Structure Assignment"]
SCREENS["paye"]["tabs"].append({"key": "slabs", "label": "Income Tax Slabs", "doctype": "Income Tax Slab"})
SCREENS["paye"]["tabs"].extend([
    {"key": "relief-categories", "label": "EDF Relief Categories", "doctype": "Employee Tax Exemption Category", "new_label": "Add Relief Category"},
    {"key": "relief-subcategories", "label": "EDF Relief Sub-Categories", "doctype": "Employee Tax Exemption Sub Category", "new_label": "Add Relief Sub-Category"},
])
SCREEN_DOCTYPES["paye"].extend(["Income Tax Slab", "Employee Tax Exemption Category", "Employee Tax Exemption Sub Category"])
PAYROLL_DEPENDENCIES = set(ENTITIES)

# The availability of a saved reference is visible to every payroll editor.
for _doctype in ("Payroll PDB Code", "Payroll PDB Type", "Payroll Contribution Scheme", "Payroll Compensation Scheme", "Payroll PAYE Year"):
    _entity = ENTITIES[_doctype]
    _availability = [f for f in ("company", "effective_from", "effective_to", "configuration_version") if f in _entity.get("admin", [])]
    _entity["admin"] = [f for f in _entity.get("admin", []) if f not in _availability]
    if _availability:
        _entity["sections"].append({"label": "Availability", "fields": _availability})
# PDB Code is the user-facing pay element. Its technical Salary Component is
# created automatically and deliberately omitted from the drawer.


# Settings-only routes share the payroll drawer without duplicating the main menu.
PAYROLL_SETTINGS_MASTERS = ['Payroll Settings', 'Karyo Payroll Settings', 'PRB Payroll Settings', 'Payroll Configuration Version', 'PRB Salary Point', 'PRB Grade Scale', 'PRB Grade Scale Dataset', 'PRB Rule Version', 'PRB Payroll Component Mapping', 'Payroll Transaction Import Template', 'Employee Tax Exemption Category', 'Employee Tax Exemption Sub Category', 'Gratuity Rule', 'Salary Increment Band', 'Salary Scale', 'Salary Scale Step', 'Employee Grade', 'Salary Job Family', 'Payroll Period', 'Employee Salary Appointment']
PAYROLL_SETTINGS_MASTERS += ['Expense Claim Type', 'Purpose of Travel', 'Cost Center', 'PRB Payroll Run', 'Payroll Entry', 'Additional Salary', 'Salary Withholding', 'EOY Bonus']
for _doctype in PAYROLL_SETTINGS_MASTERS:
    ENTITIES.setdefault(_doctype, {"title": "name", "list": ["name"], "native_fields": True})
    _screen = "master-" + _doctype.lower().replace(" ", "-")
    SCREENS[_screen] = {"layout": "list", "doctype": _doctype, "title": _doctype, "group": "Payroll Masters", "hidden_nav": True}
    SCREEN_DOCTYPES[_screen] = [_doctype]
SCREENS["master-salary-scale"].update({
    "layout": "salary_scale_setup",
    "title": "Salary Scale Setup",
    "group": "Set Up Payroll Parameters",
    "hidden_nav": False,
    "note": "Configure Scale Details, Increment Bands and Generated Salary Points in one guided workflow.",
})
SCREEN_DOCTYPES["master-salary-scale"] = ["Salary Scale", "Salary Increment Band", "Salary Scale Step"]
ENTITIES["Employee Tax Exemption Category"].update({
    "title": "name", "list": ["name", "max_amount", "is_active"],
})
ENTITIES["Employee Tax Exemption Sub Category"].update({
    "title": "name", "list": ["name", "exemption_category", "max_amount", "is_active"],
})
PAYROLL_DEPENDENCIES.update(PAYROLL_SETTINGS_MASTERS)

# Salary Appointment creation is intentionally owned by the single/bulk setup
# action. The record drawer remains a useful read-only audit view for submitted
# rows, while the list displays the native structure mapping beside it.
SCREENS["master-employee-salary-appointment"].update({
    "no_create": True,
    "canonical_salary_setup": True,
    "title": "Salary Appointments",
    "note": "One setup action keeps Salary Appointment, Salary Structure Assignment and employee salary values synchronized.",
})
ENTITIES["Employee Salary Appointment"].update({
    "title": "employee_name",
    "label": "Salary Appointment",
    "native_fields": True,
    "sections": [
        {"label": "Employee appointment", "fields": [
            "employee", "employee_name", "company", "appointment_type", "grade",
            "grade_description", "job_family", "employee_category",
            "effective_from", "effective_to",
        ]},
        {"label": "Salary allocation", "fields": [
            "salary_scale", "salary_point", "basic_salary", "currency", "salary_structure",
            "income_tax_slab", "salary_structure_assignment",
        ]},
        {"label": "Approval", "fields": [
            "authority_reference", "notes", "approved_by", "approved_on",
        ]},
    ],
    "list": [
        "employee", "employee_name", "grade", "salary_scale", "salary_point", "basic_salary",
        "salary_structure", "salary_structure_assignment",
    ],
})
ENTITIES["Salary Structure Assignment"].update({
    "label": "Generated Employee Payroll Mapping",
    "canonical_only": True,
    "list": [
        "employee", "salary_structure", "from_date", "base", "income_tax_slab",
        "karyo_salary_appointment", "karyo_salary_scale", "karyo_salary_point",
    ],
})
ENTITIES["Salary Structure"].update({
    "label": "PDB Payroll Template",
    "list": ["name", "company", "is_active", "docstatus"],
})

for _doctype in ("Payroll Entry",):
	ENTITIES[_doctype]["read_only"] = True

ENTITIES["Cost Center"].update({"title": "cost_center_name", "list": ["name", "cost_center_name", "company", "parent_cost_center", "is_group"]})
ENTITIES["Salary Scale"].update({
    "title": "description",
    "list": ["scale_code", "description", "lowest_salary", "upper_salary", "scale_type", "valid_from", "valid_to"],
})
ENTITIES["Salary Increment Band"].update({
    "title": "description",
    "list": ["band_code", "description", "salary_breakpoint", "increment_amount", "currency", "effective_from", "effective_to", "disabled"],
})
ENTITIES["Salary Scale Step"].update({
    "title": "salary_scale",
    "list": ["salary_scale", "step_sequence", "salary_point", "increment_amount", "effective_from", "effective_to"],
})
ENTITIES["Salary Job Family"].update({"title": "description", "list": ["family_code", "description"]})
ENTITIES["Employee Grade"].update({
    "title": "name",
    "label": "Employee Grade Code",
    "name_label": "Grade Code",
    "native_fields": False,
    "sections": [
        {"label": "Employee Grade Code", "fields": [
            {"fieldname": "name", "label": "Grade Code", "read_only": 1},
            {"fieldname": "karyo_grade_description", "label": "Grade Description"},
            {"fieldname": "karyo_job_family", "label": "Job Family"},
            {"fieldname": "karyo_employee_category", "label": "Employee Category / Grade Group"},
            {"fieldname": "karyo_is_active", "label": "Active?"},
            {"fieldname": "karyo_remarks", "label": "Remarks"},
        ]},
    ],
    "tables": [
        {"fieldname": "karyo_salary_scales", "label": "Salary Scale", "fields": [
            {"fieldname": "salary_scale", "label": "Salary Scale Code"},
            {"fieldname": "scale_description", "label": "Salary Scale Description", "read_only": 1},
            "effective_from", "effective_to",
        ]},
    ],
    "list": ["name", "karyo_grade_description", "karyo_job_family", "karyo_employee_category", "karyo_is_active"],
})
ENTITIES["PRB Grade Scale"]["list"] = ["grade_id", "organisation", "initial_point", "top_point"]
ENTITIES["PRB Salary Point"]["list"] = [
    "review_year", "salary_point", "basic_2021", "gross_2025", "revised_2026",
]

ENTITIES["Expense Claim Type"]["list"] = ["name", "description"]
ENTITIES["Purpose of Travel"]["list"] = ["name"]
