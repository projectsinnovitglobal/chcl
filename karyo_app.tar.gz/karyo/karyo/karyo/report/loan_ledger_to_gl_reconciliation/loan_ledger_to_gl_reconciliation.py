import frappe
from frappe import _
from frappe.utils import flt


def execute(filters=None):
	filters = frappe._dict(filters or {})
	query_filters = {"company": filters.company} if filters.get("company") else {}
	loans = frappe.get_all(
		"Karyo Loan",
		filters=query_filters,
		fields=["name", "employee", "company", "workflow_state", "disbursed_amount", "registration_fee", "disbursement_basis", "disbursement_status", "disbursement_journal_entry"],
		order_by="disbursement_date desc",
		limit_page_length=0,
	)
	loan_names = [loan.name for loan in loans]
	journal_names = {loan.disbursement_journal_entry for loan in loans if loan.disbursement_journal_entry}
	date_conditions = []
	params = {"loans": loan_names or [""]}
	allocation_filters = {"loan": ("in", loan_names or [""])}
	if filters.get("from_date"):
		date_conditions.append("transaction_date >= %(from_date)s")
		params["from_date"] = filters.from_date
		allocation_filters["posting_date"] = (">=", filters.from_date)
	if filters.get("to_date"):
		date_conditions.append("transaction_date <= %(to_date)s")
		params["to_date"] = filters.to_date
		allocation_filters["posting_date"] = ("between", [filters.from_date, filters.to_date]) if filters.get("from_date") else ("<=", filters.to_date)
	ledger_recoveries = {row.loan: flt(row.amount) for row in frappe.db.sql(f"""select loan,
		coalesce(sum(credit-debit), 0) amount from `tabKaryo Loan Ledger Entry`
		where loan in %(loans)s and ref_type in ('Loan Capital','Loan Interest','Loan Insurance',
		'Loan Capital Reversal','Loan Interest Reversal','Loan Insurance Reversal')
		{'and ' + ' and '.join(date_conditions) if date_conditions else ''} group by loan""", params, as_dict=True)}
	allocations = frappe.get_all("Karyo Loan Payroll Allocation", filters=allocation_filters,
		fields=["loan", "amount", "is_reversal", "journal_entry"], limit_page_length=0)
	payroll_recoveries = {}
	loan_journals = {}
	for allocation in allocations:
		payroll_recoveries[allocation.loan] = payroll_recoveries.get(allocation.loan, 0) + (-1 if allocation.is_reversal else 1) * flt(allocation.amount)
		if allocation.journal_entry:
			journal_names.add(allocation.journal_entry)
			loan_journals.setdefault(allocation.loan, set()).add(allocation.journal_entry)
	journals = {row.name: row for row in frappe.get_all("Journal Entry", filters={"name": ("in", list(journal_names) or [""])},
		fields=["name", "docstatus"], limit_page_length=0)}
	journal_totals = {}
	for account in frappe.get_all("Journal Entry Account", filters={"parent": ("in", list(journal_names) or [""])},
		fields=["parent", "debit_in_account_currency", "credit_in_account_currency"], limit_page_length=0):
		total = journal_totals.setdefault(account.parent, [0, 0])
		total[0] += flt(account.debit_in_account_currency)
		total[1] += flt(account.credit_in_account_currency)
	data = []
	for loan in loans:
		expected = flt(loan.disbursed_amount) + (flt(loan.registration_fee) if loan.disbursement_basis == "Net After Registration Fee" else 0)
		debit = credit = 0
		journal_status = None
		if loan.disbursement_journal_entry:
			journal = journals.get(loan.disbursement_journal_entry)
			journal_status = {0: "Draft", 1: "Submitted", 2: "Cancelled"}.get(journal.docstatus) if journal else None
			debit, credit = journal_totals.get(loan.disbursement_journal_entry, (0, 0))
		difference = expected - debit
		if not loan.disbursement_journal_entry:
			status = "Missing GL"
		elif journal_status == "Cancelled" and loan.disbursement_status != "Reversed":
			status = "Exception"
		elif abs(debit - credit) > 0.005 or abs(difference) > 0.005:
			status = "Mismatch"
		else:
			status = "Reconciled"
		ledger_recovery = ledger_recoveries.get(loan.name, 0)
		payroll_recovery = payroll_recoveries.get(loan.name, 0)
		recovery_gl = sum(journal_totals.get(name, (0, 0))[1] for name in loan_journals.get(loan.name, set())
			if journals.get(name) and journals[name].docstatus == 1)
		recovery_difference = max(abs(ledger_recovery - payroll_recovery), abs(payroll_recovery - recovery_gl))
		if recovery_difference > 0.005:
			status = "Mismatch" if status == "Reconciled" else status
		data.append({**loan, "expected_receivable": expected, "journal_status": journal_status, "gl_debit": debit, "gl_credit": credit, "difference": difference, "ledger_recovery": ledger_recovery, "payroll_recovery": payroll_recovery, "recovery_gl": recovery_gl, "recovery_difference": recovery_difference, "reconciliation_status": status})
	return _columns(), data


def _columns():
	return [
		{"fieldname": "reconciliation_status", "label": _("Status"), "fieldtype": "Data", "width": 100},
		{"fieldname": "name", "label": _("Loan"), "fieldtype": "Link", "options": "Karyo Loan", "width": 150},
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 130},
		{"fieldname": "disbursement_status", "label": _("Disbursement"), "fieldtype": "Data", "width": 100},
		{"fieldname": "disbursement_journal_entry", "label": _("Journal Entry"), "fieldtype": "Link", "options": "Journal Entry", "width": 150},
		{"fieldname": "journal_status", "label": _("JE Status"), "fieldtype": "Data", "width": 90},
		{"fieldname": "expected_receivable", "label": _("Expected"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "gl_debit", "label": _("GL Debit"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "gl_credit", "label": _("GL Credit"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "difference", "label": _("Difference"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "ledger_recovery", "label": _("Ledger Recovery"), "fieldtype": "Currency", "width": 130},
		{"fieldname": "payroll_recovery", "label": _("Payroll Recovery"), "fieldtype": "Currency", "width": 130},
		{"fieldname": "recovery_gl", "label": _("Recovery GL"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "recovery_difference", "label": _("Recovery Difference"), "fieldtype": "Currency", "width": 140},
	]
