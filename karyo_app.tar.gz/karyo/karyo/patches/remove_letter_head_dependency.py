"""Retire Letter Head as a product dependency and clear all stored references."""

import frappe


def execute():
	link_fields = frappe.get_all(
		"DocField",
		filters={"fieldtype": "Link", "options": "Letter Head"},
		fields=["parent", "fieldname"],
		limit_page_length=0,
	)
	link_fields += frappe.get_all(
		"Custom Field",
		filters={"fieldtype": "Link", "options": "Letter Head"},
		fields=["dt as parent", "fieldname"],
		limit_page_length=0,
	)
	seen = set()
	for field in link_fields:
		key = (field.parent, field.fieldname)
		if key in seen:
			continue
		seen.add(key)
		meta = frappe.get_meta(field.parent)
		if meta.issingle:
			if frappe.db.get_single_value(field.parent, field.fieldname):
				frappe.db.set_single_value(field.parent, field.fieldname, None)
			continue
		for name in frappe.get_all(
			field.parent,
			filters={field.fieldname: ("is", "set")},
			pluck="name",
			limit_page_length=0,
		):
			frappe.db.set_value(
				field.parent, name, field.fieldname, None, update_modified=False
			)

	frappe.db.delete(
		"DefaultValue",
		{"defkey": ("in", ["letter_head", "default_letter_head"])},
	)
	for name in frappe.get_all("Letter Head", pluck="name", limit_page_length=0):
		frappe.delete_doc("Letter Head", name, ignore_permissions=True, force=True)
	frappe.clear_cache()
