import unittest

from karyo.setup.legacy_contribution_catalogue import (
	_bands,
	_calculation_mode,
	_group_schemes,
	_has_band_gaps,
	_load_catalogue,
)


class TestLegacyContributionCatalogue(unittest.TestCase):
	def setUp(self):
		self.payload, self.rows = _load_catalogue()
		self.grouped = _group_schemes(self.rows)

	def test_sample_is_excluded_and_source_is_complete(self):
		self.assertEqual(len(self.rows), 20)
		self.assertEqual(len(self.grouped), 18)
		self.assertNotIn("SAMPLE-CONT", self.grouped)

	def test_duplicate_fps_band_is_deduplicated(self):
		self.assertEqual(len(self.grouped["FPS"]), 2)
		self.assertEqual(len(_bands(self.grouped["FPS"])), 1)

	def test_csg_preserves_two_bands_and_declares_gap(self):
		bands = _bands(self.grouped["CSG"])
		self.assertEqual(len(bands), 2)
		self.assertEqual(bands[1]["lower_salary"], 50001.0)
		self.assertTrue(_has_band_gaps(bands))
		self.assertEqual(_calculation_mode(self.grouped["CSG"]), "Percentage")

	def test_flat_and_percentage_modes_follow_non_zero_values(self):
		self.assertEqual(_calculation_mode(self.grouped["BAIM"]), "Flat Amount")
		self.assertEqual(_calculation_mode(self.grouped["NPS"]), "Percentage")
