from unittest.mock import MagicMock, patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.final_settlement import calculate


class TestFinalSettlement(FrappeTestCase):
	@patch("karyo.hr.final_settlement._loan_position_as_at", return_value=(12000, [{"loan": "LOAN-1", "outstanding": 12000}]))
	@patch("karyo.hr.final_settlement._passage_benefit_as_at", return_value=5000)
	@patch("karyo.hr.settlement_balances.leave_position_as_at", return_value={
		"sick_current_days": 20, "sick_bank_days": 30, "annual_current_days": 10, "annual_bank_days": 5, "references": {},
	})
	@patch("karyo.hr.final_settlement.frappe.get_cached_doc")
	@patch("karyo.hr.final_settlement.frappe.get_doc")
	@patch("karyo.payroll.salary_scales.approved_appointment")
	def test_leave_pb_and_loan_are_reconciled(self, appointment, get_doc, settings, _leave, _pb, _loan):
		appointment.return_value = frappe._dict(basic_salary=44000)
		get_doc.return_value = frappe._dict(relieving_date="2026-09-30", ctc=44000)
		settings.return_value = frappe._dict(leave_refund_divisor=22, sick_refund_cap=16)
		result = calculate("EMP-1", "2026-09-30")
		self.assertEqual(result["sick_current_amount"], 32000)
		self.assertEqual(result["sick_bank_amount"], 60000)
		self.assertEqual(result["leave_settlement_amount"], 122000)
		self.assertEqual(result["gross_settlement"], 127000)
		self.assertEqual(result["net_settlement"], 115000)
		self.assertEqual(result["loan_breakdown"][0]["loan"], "LOAN-1")
