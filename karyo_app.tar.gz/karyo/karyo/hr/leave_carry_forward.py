"""Financial-year leave entitlement and carry-forward processing.

The native Leave Allocation and Leave Ledger Entry records remain the source of
truth.  This module adds a review-and-process surface around that native flow so
HR can see exactly what will move before the new financial-year bank is opened.
"""

from __future__ import annotations

from collections import OrderedDict

import frappe
from frappe import _
from frappe.utils import add_days, add_years, cint, date_diff, flt, getdate, nowdate

from hrms.hr.doctype.leave_allocation.leave_allocation import get_unused_leaves
from hrms.hr.doctype.leave_application.leave_application import get_approved_leaves_for_period


HR_ROLES = {"HR User", "HR Manager", "System Manager"}


def _check_hr_permission():
	if not set(frappe.get_roles()).intersection(HR_ROLES):
		frappe.throw(_("Only HR may process previous-year leave balances."), frappe.PermissionError)


def _fiscal_years():
	return frappe.get_all(
		"Fiscal Year",
		filters={"disabled": 0},
		fields=["name", "year_start_date", "year_end_date"],
		order_by="year_start_date desc",
		limit_page_length=0,
	)


def _period_label(start, end):
	return _("{0} to {1}").format(getdate(start), getdate(end))


def _target_period(target_fiscal_year=None):
	periods = _fiscal_years()
	if not periods:
		frappe.throw(_("Create an active Fiscal Year before processing leave carry forward."))
	today = getdate(nowdate())
	if target_fiscal_year:
		target = next((row for row in periods if row.name == target_fiscal_year), None)
		if not target:
			frappe.throw(_("Choose a valid active Fiscal Year."))
	else:
		target = next(
			(row for row in periods if getdate(row.year_start_date) <= today <= getdate(row.year_end_date)),
			periods[0],
		)

	target_start = getdate(target.year_start_date)
	target_end = getdate(target.year_end_date)
	previous = next(
		(
			row for row in periods
			if getdate(row.year_end_date) == add_days(target_start, -1)
		),
		None,
	)
	if previous:
		previous_start = getdate(previous.year_start_date)
		previous_end = getdate(previous.year_end_date)
		previous_name = previous.name
	else:
		# A configured current FY is enough to process an immediately preceding
		# period. This keeps the tool usable while the historic FY masters are
		# being loaded, without reverting to calendar-year assumptions.
		previous_start = add_years(target_start, -1)
		previous_end = add_days(target_start, -1)
		previous_name = _period_label(previous_start, previous_end)

	return frappe._dict(
		name=target.name,
		start=target_start,
		end=target_end,
		previous_name=previous_name,
		previous_start=previous_start,
		previous_end=previous_end,
		periods=periods,
	)


def _target_entitlement(employee, leave_type, target, previous_allocation, target_allocation=None):
	"""Resolve the new-year entitlement without carrying stale encashment values."""
	if target_allocation:
		return flt(target_allocation.new_leaves_allocated)

	from karyo.hr.leave_controls import _employee, _employee_leave_schemes

	employee_doc = _employee(employee)
	policies = _employee_leave_schemes(
		employee,
		employee_doc.karyo_leave_scheme if employee_doc else None,
	)
	annual = 0.0
	if policies:
		annual = flt(frappe.db.get_value(
			"Leave Policy Detail",
			{
				"parent": ("in", policies),
				"parenttype": "Leave Policy",
				"leave_type": leave_type,
			},
			"max(annual_allocation)",
		))
	if not annual:
		annual = flt(frappe.db.get_value("Leave Type", leave_type, "karyo_annual_entitlement_days"))
	if not annual:
		annual = flt(previous_allocation.new_leaves_allocated)
	if not employee_doc or annual <= 0:
		return annual

	service_start = getdate(
		employee_doc.get("karyo_date_joined_service")
		or employee_doc.get("date_of_joining")
		or target.start
	)
	service_end = getdate(employee_doc.get("contract_end_date") or target.end)
	eligible_start = max(service_start, target.start)
	eligible_end = min(service_end, target.end)
	if eligible_end < eligible_start:
		return 0.0
	period_days = date_diff(target.end, target.start) + 1
	eligible_days = date_diff(eligible_end, eligible_start) + 1
	return round((annual * eligible_days / period_days) * 2) / 2


def _target_allocation(employee, leave_type, target):
	rows = frappe.get_all(
		"Leave Allocation",
		filters={
			"employee": employee,
			"leave_type": leave_type,
			"docstatus": 1,
			"to_date": (">=", target.start),
			"from_date": ("<=", target.end),
		},
		fields=[
			"name", "from_date", "to_date", "new_leaves_allocated",
			"total_leaves_allocated", "unused_leaves", "carry_forward",
		],
		order_by="from_date asc",
		limit_page_length=0,
	)
	if not rows:
		return None, False
	exact = next(
		(row for row in rows if getdate(row.from_date) == target.start and getdate(row.to_date) == target.end),
		None,
	)
	return exact, bool(rows and not exact)


def _eligible_rows(company, target, employee=None):
	leave_types = {
		row.name: row for row in frappe.get_all(
			"Leave Type",
			filters={"is_carry_forward": 1},
			fields=[
				"name", "karyo_mbc_leave_code", "maximum_carry_forwarded_leaves",
				"max_leaves_allowed", "expire_carry_forwarded_leaves_after_days",
			],
			limit_page_length=0,
		)
	}
	if not leave_types:
		return []

	# The latest submitted allocation ending inside the previous FY is the same
	# allocation the native carry-forward calculation will pick for target.start.
	allocation_filters = {
		"docstatus": 1,
		"leave_type": ("in", list(leave_types)),
		"to_date": ("between", [target.previous_start, target.previous_end]),
		"from_date": ("<=", target.previous_end),
	}
	if employee:
		allocation_filters["employee"] = employee
	allocations = frappe.get_all(
		"Leave Allocation",
		filters=allocation_filters,
		fields=[
			"name", "employee", "employee_name", "leave_type", "from_date", "to_date",
			"new_leaves_allocated", "total_leaves_allocated", "total_leaves_encashed",
			"leave_policy", "carry_forwarded_leaves_count", "expired",
		],
		order_by="employee asc, leave_type asc, to_date desc, creation desc",
		limit_page_length=0,
	)
	employee_filters = {"company": company, "status": "Active"}
	if employee:
		employee_filters["name"] = employee
	employees = {
		row.name: row for row in frappe.get_all(
			"Employee",
			filters=employee_filters,
			fields=["name", "employee_name", "department"],
			limit_page_length=0,
		)
	}
	latest = OrderedDict()
	for allocation in allocations:
		key = (allocation.employee, allocation.leave_type)
		if allocation.employee in employees and key not in latest:
			latest[key] = allocation

	rows = []
	prestart = getdate(nowdate()) < target.start
	for (employee, leave_type), previous in latest.items():
		leave_type_doc = leave_types[leave_type]
		target_allocation, has_overlap = _target_allocation(employee, leave_type, target)
		if has_overlap:
			continue
		if target_allocation and cint(target_allocation.carry_forward) and not prestart:
			continue
		if target_allocation and not prestart and frappe.db.exists(
			"Leave Ledger Entry",
			{
				"transaction_type": "Leave Allocation",
				"transaction_name": target_allocation.name,
				"is_carry_forward": 1,
				"docstatus": 1,
			},
		):
			continue

		raw_unused = flt(get_unused_leaves(
			employee, leave_type, previous.from_date, previous.to_date,
		))
		if raw_unused <= 0:
			continue
		taken = flt(get_approved_leaves_for_period(
			employee, leave_type, previous.from_date, previous.to_date,
		))
		encashed = flt(previous.total_leaves_encashed)
		entitlement = _target_entitlement(
			employee, leave_type, target, previous, target_allocation,
		)
		eligible = raw_unused
		maximum_cf = flt(leave_type_doc.maximum_carry_forwarded_leaves)
		if maximum_cf:
			eligible = min(eligible, maximum_cf)
		max_total = flt(leave_type_doc.max_leaves_allowed)
		# A pre-created future allocation may already include an earlier staged
		# carry-forward amount. Capacity is always calculated from the target
		# year's own entitlement, never from that staged amount a second time.
		target_base = flt(
			target_allocation.new_leaves_allocated if target_allocation else entitlement
		)
		if max_total:
			eligible = min(eligible, max(0, max_total - target_base))
		eligible = max(0, eligible)
		if eligible <= 0:
			continue

		allocated = flt(previous.total_leaves_allocated)
		other_adjustments = raw_unused - (allocated - taken - encashed)
		person = employees[employee]
		staged = flt(target_allocation.unused_leaves) if target_allocation else 0
		rows.append({
			"employee": employee,
			"employee_name": person.employee_name,
			"department": person.department,
			"leave_type": leave_type,
			"leave_code": leave_type_doc.karyo_mbc_leave_code,
			"previous_allocation": previous.name,
			"previous_from_date": previous.from_date,
			"previous_to_date": previous.to_date,
			"previous_allocated": allocated,
			"taken": taken,
			"encashed": encashed,
			"other_adjustments": other_adjustments,
			"unused_balance": raw_unused,
			"maximum_carry_forward": maximum_cf,
			"carry_forward": eligible,
			"current_entitlement": entitlement,
			"current_bank_total": target_base + eligible,
			"staged_carry_forward": staged,
			"allocation_tag": _("Carry Forwarded Leaves"),
			"target_allocation": target_allocation.name if target_allocation else None,
			"target_allocation_exists": bool(target_allocation),
			"leave_policy": previous.leave_policy,
			"carry_forward_expiry_days": cint(leave_type_doc.expire_carry_forwarded_leaves_after_days),
		})
	return rows


def _preview_payload(company=None, target_fiscal_year=None, employee=None):
	_check_hr_permission()
	company = company or frappe.defaults.get_user_default("Company") or frappe.db.get_single_value(
		"Global Defaults", "default_company"
	)
	if not company or not frappe.db.exists("Company", company):
		frappe.throw(_("Choose a valid Company."))
	if employee and not frappe.db.exists(
		"Employee", {"name": employee, "company": company, "status": "Active"}
	):
		frappe.throw(_("Choose an active employee belonging to the selected Company."))
	target = _target_period(target_fiscal_year)
	rows = _eligible_rows(company, target, employee=employee)
	employees = len({row["employee"] for row in rows})
	today = getdate(nowdate())
	future_preprocessing = bool(
		employee and target.previous_start <= today < target.start
	)
	closed_period_processing = target.start <= today and target.previous_end < today
	return {
		"company": company,
		"employee": employee,
		"target_fiscal_year": target.name,
		"target_from_date": target.start,
		"target_to_date": target.end,
		"previous_fiscal_year": target.previous_name,
		"previous_from_date": target.previous_start,
		"previous_to_date": target.previous_end,
		"fiscal_years": [
			{"value": row.name, "label": f"{row.name} ({row.year_start_date} – {row.year_end_date})"}
			for row in target.periods
		],
		"can_process": bool(closed_period_processing or future_preprocessing),
		"future_preprocessing": future_preprocessing,
		"rows": rows,
		"summary": {
			"employees": employees,
			"leave_banks": len(rows),
			"encashed_excluded": sum(flt(row["encashed"]) for row in rows),
			"carry_forward": sum(flt(row["carry_forward"]) for row in rows),
			"current_entitlement": sum(flt(row["current_entitlement"]) for row in rows),
			"current_bank_total": sum(flt(row["current_bank_total"]) for row in rows),
		},
	}


@frappe.whitelist()
def previous_year_leave_preview(company=None, target_fiscal_year=None, employee=None):
	"""Return only employee/type rows with a positive carry-forward amount."""
	return _preview_payload(company, target_fiscal_year, employee=employee)


def _augment_existing_allocation(row, target, expire_source=True):
	"""Add a native carry-forward ledger component to an existing FY bank."""
	from hrms.hr.doctype.leave_ledger_entry.leave_ledger_entry import (
		create_leave_ledger_entry,
		expire_allocation,
	)

	allocation = frappe.get_doc("Leave Allocation", row["target_allocation"])
	previous = frappe.get_doc("Leave Allocation", row["previous_allocation"])
	carry = flt(row["carry_forward"])
	expiry_days = cint(row["carry_forward_expiry_days"])
	carry_end = min(
		add_days(target.start, expiry_days - 1) if expiry_days else target.end,
		target.end,
	)
	existing_carry = flt(frappe.db.get_value(
		"Leave Ledger Entry",
		{
			"transaction_type": "Leave Allocation",
			"transaction_name": allocation.name,
			"is_carry_forward": 1,
			"docstatus": 1,
		},
		"sum(leaves)",
	) or 0)
	delta = carry - existing_carry
	if abs(delta) >= 0.005:
		create_leave_ledger_entry(
			allocation,
			{
				"leaves": delta,
				"from_date": target.start,
				"to_date": carry_end,
				"is_carry_forward": 1,
			},
		)
	frappe.db.set_value(
		"Leave Allocation",
		allocation.name,
		{
			"carry_forward": 1,
			"unused_leaves": carry,
			"total_leaves_allocated": flt(allocation.new_leaves_allocated) + carry,
			"description": _("Carry Forwarded Leaves from {0} for {1}.").format(
				previous.name, target.name,
			),
		},
	)
	frappe.db.set_value(
		"Leave Allocation", previous.name, "carry_forwarded_leaves_count", carry,
	)
	allocation.add_tag(_("Carry Forwarded Leaves"))
	if expire_source:
		expire_allocation(previous)
	return allocation.name, "updated"


def _create_target_allocation(row, target, prestart=False):
	carry = flt(row["carry_forward"])
	base_entitlement = flt(row["current_entitlement"])
	# Native Leave Allocation rejects a zero-total draft. A fixed-term employee
	# can still own a legitimate balance to carry into a future year, so seed
	# that allocation and relabel its ledger entry immediately after submission.
	carry_only_prestart = bool(prestart and not base_entitlement and carry)
	allocation = frappe.get_doc({
		"doctype": "Leave Allocation",
		"employee": row["employee"],
		"leave_type": row["leave_type"],
		"from_date": target.start,
		"to_date": target.end,
		"new_leaves_allocated": carry if carry_only_prestart else base_entitlement,
		# Native submission expires the source allocation immediately when this
		# flag is set. A future-year bank must not expire the still-active source,
		# so stage the carry-forward ledger after submitting its entitlement.
		"carry_forward": 0 if prestart else 1,
		"leave_policy": row.get("leave_policy"),
		"description": _("Financial-year entitlement and carry forward from {0}.").format(
			row["previous_allocation"]
		),
	})
	allocation.flags.ignore_permissions = True
	allocation.insert()
	allocation.submit()
	if prestart:
		if carry_only_prestart:
			carry_end = min(
				add_days(target.start, cint(row["carry_forward_expiry_days"]) - 1)
				if cint(row["carry_forward_expiry_days"]) else target.end,
				target.end,
			)
			ledger_names = frappe.get_all(
				"Leave Ledger Entry",
				filters={
					"transaction_type": "Leave Allocation",
					"transaction_name": allocation.name,
					"is_carry_forward": 0,
					"docstatus": 1,
				},
				pluck="name",
			)
			for ledger_name in ledger_names:
				frappe.db.set_value(
					"Leave Ledger Entry", ledger_name,
					{"is_carry_forward": 1, "to_date": carry_end},
					update_modified=False,
				)
			frappe.db.set_value(
				"Leave Allocation", allocation.name,
				{
					"new_leaves_allocated": 0,
					"unused_leaves": carry,
					"total_leaves_allocated": carry,
					"carry_forward": 1,
					"description": _("Carry Forwarded Leaves from {0} for {1}.").format(
						row["previous_allocation"], target.name,
					),
				},
			)
			frappe.db.set_value(
				"Leave Allocation", row["previous_allocation"],
				"carry_forwarded_leaves_count", carry,
			)
		else:
			row["target_allocation"] = allocation.name
			_augment_existing_allocation(row, target, expire_source=False)
	allocation.reload()
	allocation.add_tag(_("Carry Forwarded Leaves"))
	return allocation.name, "created"


@frappe.whitelist(methods=["POST"])
def process_previous_year_leaves(company, target_fiscal_year, employee=None):
	"""Open/synchronize current FY banks for every currently eligible row.

	The candidate set is always recalculated on the server. No amount supplied by
	the browser is trusted, and already processed rows disappear on the next run.
	"""
	payload = _preview_payload(company, target_fiscal_year, employee=employee)
	if not payload["can_process"]:
		frappe.throw(_(
			"The previous financial year must be closed before bulk carry forward. "
			"To prepare a future year early, select one employee."
		))
	target = _target_period(target_fiscal_year)
	prestart = getdate(nowdate()) < target.start
	result = {"created": 0, "updated": 0, "skipped": 0, "employees": set(), "allocations": []}
	for row in payload["rows"]:
		# Serialize competing requests for the same source allocation. A second
		# request then observes the target carry-forward record and safely skips it.
		frappe.db.sql(
			"select name from `tabLeave Allocation` where name=%s for update",
			(row["previous_allocation"],),
		)
		current, overlap = _target_allocation(row["employee"], row["leave_type"], target)
		if overlap or (current and cint(current.carry_forward) and not prestart):
			result["skipped"] += 1
			continue
		if current and not prestart and frappe.db.exists(
			"Leave Ledger Entry",
			{
				"transaction_name": current.name, "transaction_type": "Leave Allocation",
				"is_carry_forward": 1, "docstatus": 1,
			},
		):
			result["skipped"] += 1
			continue
		fresh_unused = flt(get_unused_leaves(
			row["employee"], row["leave_type"], row["previous_from_date"], row["previous_to_date"],
		))
		if fresh_unused <= 0:
			result["skipped"] += 1
			continue
		# A leave approval or encashment may have completed while this request was
		# waiting for the source-allocation lock. Never carry more than the freshly
		# observed ledger balance or the remaining current-bank capacity.
		carry = min(flt(row["carry_forward"]), fresh_unused)
		limits = frappe.db.get_value(
			"Leave Type", row["leave_type"],
			["maximum_carry_forwarded_leaves", "max_leaves_allowed"], as_dict=True,
		)
		maximum_cf = flt(limits.maximum_carry_forwarded_leaves)
		if maximum_cf:
			carry = min(carry, maximum_cf)
		max_total = flt(limits.max_leaves_allowed)
		if max_total:
			target_base = flt(current.new_leaves_allocated) if current else flt(row["current_entitlement"])
			carry = min(carry, max(0, max_total - target_base))
		if carry <= 0:
			result["skipped"] += 1
			continue
		row["carry_forward"] = carry
		row["target_allocation"] = current.name if current else None
		name, action = (
			_augment_existing_allocation(row, target, expire_source=not prestart)
			if current else _create_target_allocation(row, target, prestart=prestart)
		)
		result[action] += 1
		result["employees"].add(row["employee"])
		result["allocations"].append(name)

	# Hooks on allocation/ledger submission update both the admin register and
	# employee balance surface. Refresh once more after all source expiries so
	# materialized Leave Balance rows cannot retain an intermediate value.
	from karyo.setup.leave import sync_employee_leave_balances

	for employee in result["employees"]:
		sync_employee_leave_balances(employee, max(target.start, getdate(nowdate())))
	return {
		"created": result["created"],
		"updated": result["updated"],
		"skipped": result["skipped"],
		"employees": len(result["employees"]),
		"allocations": result["allocations"],
	}
