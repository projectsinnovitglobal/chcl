"""PRB rule-version selection (PRB-01, PRB analysis §3.2).

Pure selection over effective-dated rule candidates; the DB-backed version reads
`PRB Rule Version` rows. Rules are immutable: supersede by adding a new version.
"""

from frappe.utils import getdate


def select_rule(candidates, on_date):
	"""Pick the applicable rule for `on_date` from candidate dicts with
	`effective_from`, optional `effective_to`, `priority`, `status`.

	Filters to active rows whose effective window covers the date, then sorts by
	priority desc, then latest effective_from. Returns the winner or None.
	"""
	on_date = getdate(on_date)
	eligible = []
	for c in candidates:
		if c.get("status") and c["status"] != "Active":
			continue
		ef = getdate(c["effective_from"]) if c.get("effective_from") else None
		et = getdate(c["effective_to"]) if c.get("effective_to") else None
		if ef and ef > on_date:
			continue
		if et and et < on_date:
			continue
		eligible.append(c)
	if not eligible:
		return None
	eligible.sort(
		key=lambda c: (c.get("priority", 0), getdate(c.get("effective_from") or "1900-01-01")),
		reverse=True,
	)
	return eligible[0]


def select_rule_from_db(rule_group, on_date):
	"""DB-backed selection over PRB Rule Version rows for a rule group."""
	import frappe

	rows = frappe.get_all(
		"PRB Rule Version",
		filters={"rule_group": rule_group},
		fields=["name", "effective_from", "effective_to", "priority", "status", "source_reference"],
	)
	return select_rule(rows, on_date)
