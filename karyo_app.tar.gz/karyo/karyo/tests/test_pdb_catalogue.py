"""Catalogue visibility, paging and permission-checked deletion; all writes roll back."""
import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.desk.payroll_screens import _master_detail
from karyo.desk.payroll_drawer import record_save, record_action
from karyo.payroll.screen_specs import SCREENS


class TestPDBCatalogue(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('pdb_catalogue')
        self.notify = patch('frappe.publish_realtime'); self.notify.start()
        self.suffix = 'CAT'+uuid4().hex[:10].upper()

    def tearDown(self):
        self.notify.stop()
        frappe.db.rollback(save_point='pdb_catalogue')
        frappe.set_user(self.user)

    def catalogue(self, **params):
        return _master_detail('pdb', SCREENS['pdb'], params)

    def test_all_types_search_and_second_page(self):
        # Copy a validated existing code into isolated test records.
        source = frappe.get_doc('Payroll PDB Code', frappe.db.get_value('Payroll PDB Code', {}, 'name')).as_dict()
        component = frappe.get_doc('Salary Component', source['salary_component']).as_dict()
        names = []
        for i in range(42):
            salary_component = record_save('salarysetup', 'Salary Component', dict(component,
                salary_component=f'{self.suffix}-{i}', salary_component_abbr=f'{self.suffix}{i}'))['name']
            values = dict(source, pdb_code=f'{self.suffix}-{i}', description=f'{self.suffix} entry {i}',
                          salary_component=salary_component)
            names.append(record_save('pdb', 'Payroll PDB Code', values, is_admin=True)['name'])
        first = self.catalogue(search=self.suffix)
        second = self.catalogue(search=self.suffix, start=40)
        self.assertIsNone(first['master']['selected'])
        self.assertEqual(first['detail']['count'], 42)
        self.assertTrue(first['detail']['has_more'])
        self.assertFalse(second['detail']['has_more'])
        found = [r.name for page in (first, second) for r in page['detail']['rows']]
        self.assertCountEqual(found, names)
        record_save('pdb', 'Payroll PDB Code', {'description': self.suffix+' edited'}, names[0])
        edited = self.catalogue(search=self.suffix+' edited')['detail']['rows']
        self.assertEqual([r.name for r in edited], [names[0]])
        record_action('pdb', 'Payroll PDB Code', names[0], 'delete')
        self.assertFalse(frappe.db.exists('Payroll PDB Code', names[0]))
        self.assertEqual(self.catalogue(search=self.suffix)['detail']['count'], 41)
        other_type = frappe.db.get_value('Payroll PDB Type', {'name':['!=',source['pdb_type']]}, 'name')
        if other_type:
            self.assertEqual(self.catalogue(master=other_type, search=self.suffix)['detail']['rows'], [])

    def test_delete_unused_and_reject_linked_type(self):
        source = frappe.get_doc('Payroll PDB Type', frappe.db.get_value('Payroll PDB Type', {}, 'name')).as_dict()
        name = record_save('pdb', 'Payroll PDB Type', dict(source, pdb_type=self.suffix), is_admin=True)['name']
        record_action('pdb', 'Payroll PDB Type', name, 'delete')
        self.assertFalse(frappe.db.exists('Payroll PDB Type', name))
        linked_type = frappe.db.get_value('Payroll PDB Code', {}, 'pdb_type')
        with self.assertRaises(frappe.LinkExistsError):
            record_action('pdb', 'Payroll PDB Type', linked_type, 'delete')
        self.assertTrue(frappe.db.exists('Payroll PDB Type', linked_type))

    def test_user_permissions_and_denied_delete(self):
        frappe.set_user('mbc.admin@mbc.mu')
        data = self.catalogue()
        self.assertTrue(data['detail']['rows'][0]['_can_edit'])
        self.assertTrue(data['detail']['rows'][0]['_can_delete'])
        name = data['detail']['rows'][0].name
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            record_action('pdb', 'Payroll PDB Code', name, 'delete')
