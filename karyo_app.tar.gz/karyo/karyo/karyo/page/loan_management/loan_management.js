function lm_open_drawer_state($root, $drawer, trigger) {
	if (!$drawer?.length) return;
	$drawer.data("trigger", trigger || document.activeElement)
		.prop("inert", false).attr("aria-hidden", "false").addClass("open");
	$root.find(".lm-overlay").addClass("open");
	karyo.ui?.lock_scroll($drawer[0]);
	requestAnimationFrame(() => {
		const target = $drawer.find(".lm-close:visible, button:visible, input:visible, select:visible, textarea:visible").first()[0];
		(target || $drawer[0])?.focus();
	});
}

function lm_close_drawers($root) {
	$root.find(".lm-drawer.open").each(function () {
		const trigger = $(this).data("trigger");
		$(this).removeClass("open").prop("inert", true).attr("aria-hidden", "true");
		karyo.ui?.unlock_scroll(this);
		if (trigger?.isConnected) trigger.focus();
	});
	$root.find(".lm-overlay").removeClass("open");
}

frappe.pages["loan-management"].on_page_load = function (wrapper) {
	frappe.ui.make_app_page({
		parent: wrapper,
		title: __("Loan Management"),
		single_column: true,
	});
	const user = frappe.session.user_fullname || frappe.session.user || "";
	const initials = user
		.split(/\s+/)
		.filter(Boolean)
		.slice(0, 2)
		.map((part) => part[0])
		.join("")
		.toUpperCase();
	const pages = [
		["dashboard", "▦", __("Dashboard")],
		["#reference", "", __("Reference")],
		["loan-types", "▤", __("Loan Types")],
		["insurance-rates", "%", __("Insurance Rates")],
		["recompute-params", "↻", __("Recomputation Parameters")],
		["loan-conditions", "✓", __("Loan Conditions")],
        ["#setup", "", __("Additional Loan Setup")],
        ["operation-codes", "▤", __("Loan Operation Codes")],
		["document-requirements", "▤", __("Document Requirements")],
		["approval-authorities", "▤", __("Approval Authorities")],
		["loan-committees", "♙", __("Loan Committee Master")],
		["#transactions", "", __("Transactions")],
		["applications", "✎", __("Loan Applications")],
		["approvals", "☑", __("Approval of Loans")],
		["committee", "♙", __("Loan Committee")],
		["employee-requests", "▤", __("Employee Loan Requests")],
		["refund", "↩", __("Refund / Settlement")],
		["advance", "⇄", __("Advance Payment / Change Period")],
		["global-interest", "%", __("Global Change of Interest")],
		["individual-interest", "%", __("Individual Change of Interest")],
		["#queries", "", __("Queries")],
		["schedule-query", "▥", __("Loan Schedule")],
		["outstanding", "◫", __("Outstanding Balance")],
		["history", "⌛", __("Loan History")],
		["ledger", "▧", __("Loan Ledger (New)")],
		["payroll-query", "¤", __("Loan Deductions - Payroll")],
		["guarantors", "♙", __("Loan Guarantors")],
		["static-query", "▣", __("Static Payments & Deductions")],
		["#reports", "", __("Reports")],
		["reports", "▥", __("Report Catalogue")],
	];
	const titles = Object.fromEntries(
		pages.filter((p) => !p[0].startsWith("#")).map((p) => [p[0], p[2]])
	);
	const nav = pages
		.map(([id, icon, label]) =>
			id.startsWith("#")
				? `<div class="lm-nav-section">${frappe.utils.escape_html(label)}</div>`
				: `<button type="button" data-page="${id}" class="${
						id === "dashboard" ? "active" : ""
				  }"><span class="lm-ico">${icon}</span>${frappe.utils.escape_html(
						label
				  )}</button>`
		)
		.join("");
	const $root = $(`<div class="karyo-loan-management">
		<div class="lm-app">
			<aside class="lm-sidebar">
				<div class="lm-brand"><div class="lm-brand-row"><img src="/assets/karyo/images/mbc-logo.jpg" alt="MBC"><div><div class="lm-brand-mark">MBC HRMS</div><small>${__(
					"Loan Management System"
				)}</small></div></div></div>
				<nav class="lm-nav">${nav}</nav>
			</aside>
			<main class="lm-main">
				<header class="lm-topbar"><div class="lm-top-left"><button class="lm-menu" aria-label="${__(
					"Open navigation"
				)}">☰</button><div><div class="lm-top-title">${__(
		"Loan Management Dashboard"
	)}</div><div class="lm-top-sub">${__(
		"MBC HRMS • Loan Management"
	)}</div></div></div><div class="lm-user"><div><strong>${frappe.utils.escape_html(
		user
	)}</strong><small>${__(
		"Authorised User"
	)}</small></div><div class="lm-avatar">${frappe.utils.escape_html(
		initials
	)}</div></div></header>
				<div class="lm-content"></div>
			</main>
		</div>
		<div class="lm-overlay" aria-hidden="true"></div>
		<div class="lm-toast"></div>
		${application_drawer()}
		${reference_drawer()}
		${dashboard_records_drawer()}
	</div>`).appendTo($(wrapper).find(".layout-main-section"));

	// Transaction and report screens are contributed as self-contained modules, each
	// owning its page markup, loader and delegated handlers.
	const modules = [
		{pages:{"employee-requests":{title:"Employee Loan Requests"}},build:employee_requests_page,load:load_employee_requests},
		{ pages: LM_APPROVAL_PAGES, build: approval_page, load: load_approval, wire: wire_approval },
		{ pages: LM_SERVICING_PAGES, build: servicing_page, load: load_servicing, wire: wire_servicing },
		{ pages: LM_INTEREST_PAGES, build: interest_page, load: load_interest, wire: wire_interest },
		{ pages: LM_REPORT_PAGES, build: report_page, load: load_report, wire: wire_report },
	];

	function module_for(id) {
		return modules.find((m) => Object.prototype.hasOwnProperty.call(m.pages, id));
	}

	const $content = $root.find(".lm-content");
	$content.append(dashboard_page());
	$content.append(applications_page());
	pages
		.filter((p) => !p[0].startsWith("#") && !["dashboard", "applications"].includes(p[0]))
		.forEach(([id, , title]) => {
			const module = module_for(id);
			$content.append(
				is_query_page(id)
					? query_page(id)
					: is_reference_page(id)
					? reference_page(id)
					: module
					? module.build(id)
					: generic_page(id, title)
			);
		});
	modules.forEach((module) => module.wire && module.wire($root));
	$root.on("click", ".lm-view-agreement", function(){karyo.loan_ui.agreement(this.dataset.loan);});
	karyo.loan_tables.attach($root[0], "loan-management");

	// Query and reference screens fetch on first visit, then only on Search/Reset.
	const loaded_pages = new Set();

	function show_page(id) {
        if (!titles[id]) id = "dashboard";
		lm_close_drawers($root);
		$root.find(".lm-page").removeClass("active");
		$root.find(`#lm-${id}`).addClass("active");
		$root
			.find(".lm-nav button")
			.toggleClass("active", false)
			.filter(`[data-page="${id}"]`)
			.addClass("active");
		const module = module_for(id);
		const heading = is_query_page(id)
			? __(LM_QUERY_PAGES[id].title)
			: is_reference_page(id)
			? __(LM_REFERENCE_PAGES[id].title)
			: module
			? __(module.pages[id].heading || module.pages[id].title)
			: titles[id];
		$root.find(".lm-top-title").text(heading || __("Loan Management"));
		$root.find(".lm-sidebar").removeClass("open");
		if (!loaded_pages.has(id) || is_query_page(id) || is_reference_page(id)) {
			if (is_query_page(id)) {
				loaded_pages.add(id);
				load_query($root, id);
			} else if (is_reference_page(id)) {
				loaded_pages.add(id);
				load_reference($root, id);
			} else if (module) {
				loaded_pages.add(id);
				module.load($root, id);
			}
		}
	}
	function toggle_drawer(open) {
		if (!open) lm_close_drawers($root);
	}
	$root.on("click", "[data-page]", function () {
		frappe.set_route("loan-management", this.dataset.page);
	});
	$root.on("click", ".lm-new-loan", () => open_application_drawer($root));
    $root.on("click", ".lm-kpi", function () { open_dashboard_records($root, this.dataset.kpi); });
	$root.on("keydown", ".lm-drawer", function (event) {
        if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); toggle_drawer(false); return; }
        if (event.key !== "Tab") return;
        const $targets = $(this).find("button:visible, [tabindex='0']:visible");
        const first = $targets[0], last = $targets[$targets.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    });

	$root.on("click", ".lm-kpi-open-loan", function () {
		lm_close_drawers($root);
		open_application_drawer($root, this.dataset.loan, true);
    });

	$root.on("click", ".lm-open-loan", function () {
		open_application_drawer($root, this.dataset.loan, this.dataset.mode !== "edit");
	});
	$root.on("click", ".lm-run-lifecycle", function () {
		const $drawer = $(this).closest(".lm-app-drawer");
		const base = ($drawer.find(".lm-loan-lifecycle").data("steps") || []).find((row) => row.key === this.dataset.step);
		const alternative = base?.alternatives?.find((row) => row.action === this.dataset.action);
		const step = alternative ? { ...base, ...alternative } : base;
		if (step) run_lifecycle_step($drawer, step);
	});
	$root.on("click", ".lm-open-repayment", async function () {
		const $button = $(this);
		const loan = $button.closest(".lm-repayment-workspace").data("loan") || $button.closest(".lm-app-drawer").data("loan");
		if (!loan || $button.prop("disabled")) return;
		$button.prop("disabled", true);
		try {
			const target = await frappe.xcall("karyo.desk.loan_management.repayment_payroll_target", { loan });
			frappe.route_options = { ...(frappe.route_options || {}), loan_repayment_target: target };
			lm_close_drawers($root);
			frappe.set_route("payroll-management", "process");
			frappe.show_alert({ message: __("Loan {0}, employee {1}, and pay period {2} were selected for payroll.", [target.loan, target.employee, target.period_label]), indicator: "blue" }, 8);
		} catch (error) {
			frappe.msgprint({ title: __("Repayment cannot start"), message: karyo.ui?.error_message(error) || error.message, indicator: "red" });
		} finally {
			$button.prop("disabled", false);
		}
	});
	$root.on("click", ".lm-open-advance", function () {
		lm_close_drawers($root);
		frappe.set_route("loan-management", "advance");
	});
	$root.on("click", ".lm-open-settlement", function () {
		const $workspace = $(this).closest(".lm-tab-panel").find(".lm-inline-settlement");
		$workspace.removeClass("lm-hidden");
		$workspace[0]?.scrollIntoView({ behavior: "smooth", block: "nearest" });
	});
	$root.on("change", '[data-settlement="payment_type"]', function () {
		$(this).closest(".lm-inline-settlement").find(".lm-settlement-cheque").toggleClass("lm-hidden", this.value !== "Cheque");
	});
	$root.on("change input", ".lm-inline-settlement input, .lm-inline-settlement select, .lm-inline-settlement textarea", function () {
		const $workspace = $(this).closest(".lm-repayment-workspace");
		$workspace.data("settlement-ready", false).find(".lm-settlement-submit").prop("disabled", true);
	});
	$root.on("click", ".lm-settlement-preview", async function () {
		const $workspace = $(this).closest(".lm-repayment-workspace");
		const result = await frappe.xcall("karyo.desk.loan_servicing.settlement_preview", {
			loan: $workspace.data("loan"),
			refund_date: $workspace.find('[data-settlement="refund_date"]').val() || null,
			ewf_waive_interest: $workspace.find('[data-settlement="ewf_waive_interest"]').is(":checked") ? 1 : 0,
		});
		if (result.permitted === false) {
			$workspace.find(".lm-settlement-result").attr("class", "lm-settlement-result lm-notice warn").text(result.message || __("You do not have permission to settle this loan."));
			$workspace.data("settlement-ready", false).find(".lm-settlement-submit").prop("disabled", true);
			return;
		}
		const figures = result.figures || {};
		$workspace.find(".lm-settlement-result").attr("class", `lm-settlement-result lm-notice ${result.blocked ? "warn" : "good"}`).html(
			result.blocked ? frappe.utils.escape_html(result.message || __("Settlement dependencies are not complete.")) :
			`<strong>${__("Settlement balance")}: ${format_currency(figures.total_balance_due || 0)}</strong><br>${__("Capital")}: ${format_currency(figures.capital_due || 0)} · ${__("Interest")}: ${format_currency(figures.interest_due || 0)} · ${__("Insurance")}: ${format_currency(figures.insurance_due || 0)} · ${__("Remaining instalments")}: ${cint(figures.remaining_instalments)}`
		);
		$workspace.data("settlement-ready", !result.blocked).find(".lm-settlement-submit").prop("disabled", Boolean(result.blocked));
	});
	$root.on("click", ".lm-settlement-submit", function () {
		const button = this;
		const $workspace = $(this).closest(".lm-repayment-workspace");
		if (!$workspace.data("settlement-ready")) return;
		const loan = $workspace.data("loan");
		const paymentType = $workspace.find('[data-settlement="payment_type"]').val();
		const chequeNo = ($workspace.find('[data-settlement="cheque_no"]').val() || "").trim();
		if (paymentType === "Cheque" && !chequeNo) {
			frappe.msgprint(__("Cheque Number is mandatory when the payment type is Cheque."));
			return;
		}
		frappe.confirm(__("Process the full settlement for loan {0}? This closes the loan and stops its payroll deductions.", [loan]), async () => {
			button.disabled = true;
			try {
				const result = await frappe.xcall("karyo.desk.loan_servicing.settle", {
					loan,
					refund_date: $workspace.find('[data-settlement="refund_date"]').val() || null,
					payment_type: paymentType,
					cheque_no: chequeNo,
					remarks: $workspace.find('[data-settlement="remarks"]').val() || null,
					ewf_waive_interest: $workspace.find('[data-settlement="ewf_waive_interest"]').is(":checked") ? 1 : 0,
				});
				if (result.permitted === false) { frappe.msgprint(result.message); return; }
				frappe.show_alert({ message: result.message || __("Settlement completed"), indicator: "green" }, 8);
				await refresh_application_drawer($workspace.closest(".lm-app-drawer"));
			} catch (error) {
				$workspace.find(".lm-settlement-result").attr("class", "lm-settlement-result lm-notice warn").text(error?.message || __("Settlement could not be completed because a dependency is missing."));
			} finally { button.disabled = false; }
		});
	});
	$root.on("click", ".lm-close, .lm-overlay", () => toggle_drawer(false));
	$root.on("click", ".lm-menu", () => $root.find(".lm-sidebar").toggleClass("open"));
	$root.on("click", ".lm-tab", function () {
		$(this).addClass("active").siblings().removeClass("active");
		$root
			.find(".lm-tab-panel")
			.removeClass("active")
			.filter(`[data-panel="${this.dataset.tab}"]`)
			.addClass("active");
	});
	$root.on("click", ".lm-app-search", () => load_applications($root));
	$root.on("click", ".lm-employee-request-refresh", () => load_employee_requests($root));
	$root.on("click", ".lm-service-request-action", function () {
		karyo.loan_ui.review_requests(this.dataset.loan, null, this.dataset.request);
	});
	$root.on("click", ".lm-app-reset", () => {
		$root.find(".lm-app-filter").val("");
		load_applications($root);
	});
	$root.on("click", ".lm-open-native", () => {
		const name = $root.find(".lm-app-drawer").data("loan");
		if (name) frappe.set_route("Form", "Karyo Loan", name);
		else frappe.new_doc("Karyo Loan");
	});

	$root.on("click", ".lm-q-search", function () {
		load_query($root, $(this).closest(".lm-page").data("query"));
	});
	$root.on("change", ".lm-q-filter", function () {
		const $page = $(this).closest(".lm-page");
		const id = $page.data("query");
		if (!id) return;

		// A loan selection drives both the result rows and the Loan Summary card.
		// Refresh immediately so the card never describes the previous selection.
		// Employee selection also narrows the loan list before the query is run.
		if (this.dataset.filter === "employee") {
			with_query_options($root, (options) => {
				populate_query_loan_filter($page, LM_QUERY_PAGES[id], options);
				load_query($root, id);
			});
			return;
		}
		load_query($root, id);
	});
	$root.on("click", ".lm-q-reset", function () {
		const $page = $(this).closest(".lm-page");
		const id = $page.data("query");
		with_query_options($root, (options) => {
			$page.find('[data-filter="employee"], [data-filter="status"]').val("");
			// Rebuild from the complete loan list. Schedule and Outstanding Balance
			// return to the first available loan because they require one.
			populate_query_loan_filter($page, LM_QUERY_PAGES[id], options, true);
			load_query($root, id);
		});
	});
	$root.on("click", ".lm-q-download", function () {
		const $page = $(this).closest(".lm-page");
		const report = $page.data("report");
		if (!report) {
			lm_toast($root, __("No linked report is available for this query."));
			return;
		}
		const loan = $page.find('[data-filter="loan"]').val();
		frappe.set_route("query-report", report, loan ? { loan: loan } : {});
	});

	$root.on("click", ".lm-ref-search", function () {
		load_reference($root, $(this).closest(".lm-page").data("reference"));
	});
	$root.on("click", ".lm-ref-reset", function () {
		const $page = $(this).closest(".lm-page");
		$page.find('.lm-ref-filter[data-filter="search"]').val("");
		$page.find('.lm-ref-filter[data-filter="status"]').prop("selectedIndex", 0);
		load_reference($root, $page.data("reference"));
	});
	$root.on("click", ".lm-ref-create", function () {
		open_reference_drawer($root, $(this).closest(".lm-page").data("reference"));
	});
	$root.on("click", ".lm-ref-edit, .lm-ref-view", function (event) {
		event.preventDefault();
		open_reference_drawer(
			$root,
			$(this).closest(".lm-page").data("reference"),
			this.dataset.name,
            this.classList.contains("lm-ref-view")
		);
	});
	$root.on("click keydown", "tbody tr", function (event) {
		if ($(event.target).closest("button, a, input, select, textarea, [role='separator']").length) return;
		if (event.type === "keydown" && (event.target !== this || !["Enter", " "].includes(event.key))) return;
		const $row = $(this), reference = $row.hasClass("lm-ref-record");
		const loan = $row.find('.lm-delete-record[data-doctype="Karyo Loan"]').attr("data-name");
		if (!reference && !loan) return;
		if (event.type === "click" && window.getSelection()?.toString()) return;
		event.preventDefault();
		if (reference) open_reference_drawer($root, $row.closest(".lm-page").data("reference"), this.dataset.name, true);
		else open_application_drawer($root, loan, true);
	});
	$root.on("click", ".lm-delete-record", function (event) {
		event.preventDefault(); event.stopPropagation();
		const button = this, {doctype, name} = this.dataset;
		if (button.disabled || !name) return;
		frappe.confirm(__("Delete {0}?", [frappe.utils.escape_html(name)]), async () => {
			button.disabled = true;
			try {
				await frappe.xcall("frappe.client.delete", {doctype, name});
				const id = frappe.get_route()[1] || "dashboard";
				if (is_reference_page(id)) load_reference($root, id);
				else if (is_query_page(id)) load_query($root, id);
				else if (id === "applications") load_applications($root);
				else if (id === "dashboard") load_dashboard($root);
				else { loaded_pages.delete(id); show_page(id); }
			} catch (error) {
				// Frappe displays the server's permission or linked-record error.
				button.disabled = false;
			}
		});
	});
	$root.on("click", ".lm-ref-save", () => save_reference($root));
	$root.on("click", ".lm-ref-transition", function () {
		transition_reference($root, this.dataset.target);
	});
    $root.on("click", ".lm-ref-add-row", function () {
        const $table = $(this).closest(".lm-ref-table");
        const field = $table.data("spec");
        const $row = $(reference_child_row(field, {}, true)).appendTo($table.find(".lm-ref-rows"));
        mount_reference_links($row);
    });
    $root.on("click", ".lm-ref-remove-row", function () { $(this).closest(".lm-ref-row").remove(); });
	$root.on("click", ".lm-ref-move-up", function () {
		const $row = $(this).closest(".lm-ref-row");
		const $previous = $row.prev(".lm-ref-row");
		if ($previous.length) $row.insertBefore($previous);
	});
	$root.on("click", ".lm-ref-move-down", function () {
		const $row = $(this).closest(".lm-ref-row");
		const $next = $row.next(".lm-ref-row");
		if ($next.length) $row.insertAfter($next);
	});


	$root.on("input change", ".lm-app-drawer [data-edit], .lm-app-drawer [data-edit-text], .lm-app-drawer [data-check-field]", () => $root.find(".lm-app-drawer").data("dirty", true));
	$root.on("click", ".lm-app-save", () => save_application($root));
	$root.on("click", ".lm-app-compute", () => save_application($root, "computation"));
	$root.on("click", ".lm-app-schedule", () => save_application($root, "schedule"));

    wrapper.loan_show_page = () => show_page(frappe.get_route()[1] || "dashboard");
    wrapper.loan_show_page();
    $root.on("keydown", ".lm-filters input", function (event) {
        if (event.key === "Enter") $(this).closest(".lm-filters").find("button.primary").first().trigger("click");
    });
	karyo.live.watch("loan-management-records", () => {
		if ($root.find('input[type="checkbox"]:checked').length) return;
		const id = frappe.get_route()[1] || "dashboard";
		if (id === "employee-requests") return load_employee_requests($root);
		if (id === "dashboard") return load_dashboard($root);
		if (id === "applications") return load_applications($root);
		if (["committee", "approvals"].includes(id)) return load_approval($root, id);
		if (is_query_page(id)) return load_query($root, id);
		if (is_reference_page(id)) return load_reference($root, id);
	}, ["Karyo Loan", "Karyo Loan Ledger Entry", "Loan Type", "Loan Service Request"], () => frappe.get_route()[0] === "loan-management");
	load_dashboard($root);
	load_applications($root);
	// Fetched up front so the sidebar hides query screens this user cannot read,
	// rather than gating them only after the first visit.
	with_query_options($root, () => {});
};

frappe.pages["loan-management"].on_page_show = function(wrapper) { wrapper.loan_show_page?.(); };

function load_dashboard($root) {
	frappe.call({
		method: "karyo.desk.loan_management.dashboard",
		freeze: false,
		callback: (response) => {
			const data = response.message || {};
			if (!data.permitted) {
				$root
					.find("#lm-dashboard")
					.html(
						`<div class="lm-notice">${__(
							"You do not have permission to view the Loan Management dashboard."
						)}</div>`
					);
				return;
			}
			render_dashboard($root, data);
		},
		error: () =>
			$root.find(".lm-live-state").text(__("Live dashboard data could not be loaded.")),
	});
}

function render_dashboard($root, data) {
	const k = data.kpis || {};
	const set = (key, value, note) => {
		const $card = $root.find(`[data-kpi="${key}"]`);
		$card.prop("disabled", false);
		$card.find(".value").text(value);
		$card.find(".note").text(note);
	};
	set("active", k.active || 0, __("{0} outstanding", [format_currency(k.outstanding || 0)]));
	set(
		"pending",
		k.pending || 0,
		k.pending ? __("Awaiting workflow action") : __("No applications awaiting action")
	);
	set(
		"applications",
		k.applications_month || 0,
		__("{0} processed", [k.applications_processed || 0])
	);
	set(
		"settled",
		k.settled_month || 0,
		__("{0} recovered", [format_currency(k.settled_amount || 0)])
	);
	set(
		"exceptions",
		k.payroll_exceptions || 0,
		k.payroll_exceptions
			? __("Missing or inactive deduction mapping")
			: __("No posting exceptions")
	);

	const rows = (data.recent || [])
		.map(
			(row) =>
				`<tr><td><a class="lm-link" href="${row.route}">${frappe.utils.escape_html(
					row.name
				)}</a></td><td>${frappe.utils.escape_html(
					[row.employee, row.employee_name].filter(Boolean).join(" - ")
				)}</td><td>${frappe.utils.escape_html(
					row.loan_type || "—"
				)}</td><td>${format_currency(
					row.approved_amount || 0
				)}</td><td><span class="lm-badge ${status_class(
					row.status
				)}">${frappe.utils.escape_html(row.status)}</span></td><td class="lm-row-actions">${loan_row_actions(row.name, row.agreement_available)}</td></tr>`
		)
		.join("");
	$root
		.find(".lm-recent-body")
		.html(
			rows ||
				`<tr><td colspan="6" class="lm-muted">${__(
					"No loan applications found"
				)}</td></tr>`
		);

	const types = (data.by_type || []).slice(0, 5);
	const maximum = Math.max(...types.map((row) => row.count || 0), 1);
	$root
		.find(".lm-type-bars")
		.html(
			types
				.map(
					(row) =>
						`<div class="lm-bar-row"><span>${frappe.utils.escape_html(
							row.label
						)}</span><div class="lm-bar"><span style="width:${Math.round(
							((row.count || 0) / maximum) * 100
						)}%"></span></div><strong>${row.count || 0}</strong></div>`
				)
				.join("") || `<div class="lm-muted">${__("No active loans")}</div>`
		);

	(data.pipeline?.steps || []).forEach((step, index) => {
		const $step = $root.find(".lm-step").eq(index);
		$step.find("strong").text(step.label);
		$step.find("small").text(step.sublabel);
		$step
			.toggleClass("done", index < data.pipeline.current)
			.toggleClass("current", index === data.pipeline.current);
	});
	apply_capabilities($root, data.capabilities || {});
	$root.find(".lm-live-state").text(__("Live data"));
}

function apply_capabilities($root, capabilities) {
	$root.find(".lm-new-loan").toggle(Boolean(capabilities.create));
	const requirements = {
		"loan-types": "configure",
		"insurance-rates": "configure",
		"recompute-params": "configure",
		"loan-conditions": "configure",
		approvals: "approve",
		committee: "approve",
		refund: "service",
		advance: "service",
		"global-interest": "service",
		"individual-interest": "service",
		reports: "reports",
	};
	Object.entries(requirements).forEach(([page, capability]) => {
		$root.find(`.lm-nav [data-page="${page}"]`).toggle(Boolean(capabilities[capability]));
	});
}

function status_class(status) {
	const value = String(status || "").toLowerCase();
	if (value.includes("cancel") || value.includes("reject")) return "bad";
	if (value.includes("active") || value.includes("approved") || value.includes("settled"))
		return "good";
	if (value.includes("pending") || value.includes("committee") || value.includes("review"))
		return "warn";
	return "gray";
}

// Company currency for the whole page, taken from whichever server payload arrives
// first. The prototype hardcoded MUR; we defer to the company so the UI can never
// disagree with the ledger it is reporting on.
let lm_currency = null;

function lm_set_currency(value) {
	if (value) lm_currency = value;
}

function lm_money(value, blank = "—") {
	if (value === null || value === undefined || value === "") return blank;
	return format_currency(flt(value), lm_currency || undefined);
}

function lm_toast($root, message) {
	const $toast = $root.find(".lm-toast").text(message).addClass("show");
	clearTimeout($toast.data("timer"));
	$toast.data(
		"timer",
		setTimeout(() => $toast.removeClass("show"), 2800)
	);
}

// `edit` names the input type to switch to when the application is still editable
// (see karyo.desk.loan_management.APPLICATION_EDITABLE_FIELDS). Fields without it
// stay read-only: they are computed by Karyo Loan.validate(), never entered.
function display_field(label, fieldname, type = "text", edit = null) {
	const editable = edit ? ` data-edit="${edit}"` : "";
	return `<div class="lm-field"><label>${frappe.utils.escape_html(
		label
	)}</label><input type="${type}" data-field="${fieldname}"${editable} readonly value="—"></div>`;
}

function application_drawer() {
	const tabs = [
		["process", "Process Loan"],
		["details", "Loan Details"],
		["computation", "Computation"],
		["insurance", "Insurance Details"],
		["lien", "Vehicle Lien"],
		["documents", "Upload Documents"],
		["guarantors", "Guarantors"],
		["committee-approval", "Committee & Approval"],
		["payroll-mapping", "Payroll Mapping"],
		["schedule", "Schedule"],
		["audit", "Audit"],
	];
	return `<aside class="lm-drawer lm-app-drawer" tabindex="-1" role="dialog" aria-modal="true" aria-label="${__("Maintain Loan Application")}" aria-hidden="true" inert><div class="lm-drawer-head"><div><strong class="lm-drawer-title">${__(
		"Maintain Loan Application"
	)}</strong><div class="lm-muted lm-drawer-subtitle">${__(
		"New loan application"
	)}</div></div><button type="button" class="lm-close" aria-label="${__("Close")}">✕</button></div><div class="lm-tabs">${tabs
		.map(
			([id, label], i) =>
				`<button class="lm-tab ${i ? "" : "active"}" data-tab="${id}">${__(
					label
				)}</button>`
		)
		.join("")}</div><div class="lm-drawer-loading lm-placeholder"><div><strong>${__(
		"Loading application"
	)}</strong>${__("Retrieving loan details…")}</div></div><div class="lm-drawer-content">
		<div class="lm-tab-panel active" data-panel="process"><div class="lm-section-label">${__(
			"Loan Lifecycle"
		)}</div><div class="lm-notice">${__(
			"Complete each governed step in order. A tick means the step is complete; blocked steps show the missing role or dependency."
		)}</div><div class="lm-loan-lifecycle"></div><div class="lm-toolbar lm-agreement-actions"></div><div class="lm-repayment-workspace"></div></div>
		<div class="lm-tab-panel" data-panel="details"><div class="lm-section-label">${__(
			"Employee & Loan Information"
		)}</div><div class="lm-form-grid cols-2">${display_field(
		__("Employee Code"),
		"employee"
	)}${display_field(__("Employee Name"), "employee_name")}${display_field(
		__("Company"),
		"company"
	)}${display_field(__("Loan Number"), "name")}${display_field(
		__("Loan Code"),
		"loan_type",
		"text",
		"text"
	)}${display_field(__("Application Date"), "date_applied", "text", "date")}${display_field(
		__("Amount Applied"),
		"amount_applied",
		"text",
		"number"
	)}${display_field(__("Amount Approved"), "approved_amount", "text", "number")}${display_field(
		__("Duration (Months)"),
		"period_months",
		"text",
		"number"
	)}${display_field(__("Repayment Start Date"), "repayment_start_date", "text", "date")}${display_field(
		__("Planned End Date"),
		"planned_repayment_end_date"
	)}${display_field(__("Interest Rate (%)"), "interest_rate", "text", "number")}${display_field(
		__("Eligible Salary"),
		"eligible_salary"
	)}${display_field(__("Existing Deductions"), "existing_deductions")}${display_field(
		__("Proposed Deduction (%)"),
		"deduction_pct"
	)}${display_field(
		__("Appraisal"),
		"appraisal_status"
	)}${display_field(
		__("Registration Fee"),
		"registration_fee",
		"text",
		"number"
	)}${display_field(__("Cheque No."), "cheque_no", "text", "text")}${display_field(
		__("Disbursed Date"),
		"disbursement_date",
		"text",
		"date"
	)}<div class="lm-check"><input type="checkbox" data-check-field="is_approval_required" disabled><label>${__(
		"Approval by Committee"
	)}</label></div></div><div class="lm-purpose"><label>${__(
		"Purpose"
	)}</label><div data-text="purpose">—</div><textarea class="lm-hidden" data-edit-text="purpose"></textarea></div>
		<div class="lm-notice warn lm-app-lock lm-hidden"></div>
		<div class="lm-separator"></div><div class="lm-toolbar lm-app-edit-actions lm-hidden"><button class="lm-btn secondary lm-app-save">${__(
			"Save Draft"
		)}</button><button class="lm-btn primary lm-app-compute">${__(
			"Compute Loan"
		)}</button></div></div>
		<div class="lm-tab-panel" data-panel="computation"><div class="lm-section-label">${__(
			"Loan Computation"
		)}</div><div class="lm-summary-box">${summary_row(
		"Principal",
		"approved_amount"
	)}${summary_row("Rate of Interest", "interest_rate", true)}${summary_row(
		"Period of Refund",
		"period_months",
		false,
		" months"
	)}${summary_row("Monthly Capital Refund", "monthly_capital")}${summary_row(
		"Total Interest",
		"total_interest"
	)}${summary_row("Monthly Interest Refund", "monthly_interest")}${summary_row(
		"Total Insurance",
		"total_insurance"
	)}${summary_row("Monthly Insurance", "monthly_insurance")}${summary_row(
		"Monthly Refund",
		"monthly_refund",
		false,
		"",
		true
	)}</div><div class="lm-summary-box">${summary_row(
		"Net Loan Amount",
		"net_loan_amount",
		false,
		"",
		true
	)}</div></div>
		<div class="lm-tab-panel" data-panel="insurance"><div class="lm-section-label">${__(
			"Insurance Computation"
	)}</div><div class="lm-form-grid cols-2">${display_field(
		__("Insurance Rate (per Rs 10,000)"),
		"insurance_rate"
	)}${display_field(__("Rate Rule"), "insurance_rate_rule")}${display_field(
		__("Insurance Provider"),
		"insurance_provider"
	)}${display_field(
		__("Policy / Rate Reference"),
		"insurance_policy_reference"
	)}${display_field(__("Sum Assured"), "sum_assured")}${display_field(
		__("Monthly Insurance"),
		"monthly_insurance"
	)}${display_field(
		__("Total Insurance"),
		"total_insurance"
	)}${display_field(
		__("Insurance Confirmed"),
		"insurance_confirmed"
	)}</div><div class="lm-notice" style="margin-top:14px">${__(
		"Insurance values are calculated by the governed server-side loan engine."
	)}</div></div>
		<div class="lm-tab-panel" data-panel="lien"><div class="lm-lien-workspace"></div></div>
		<div class="lm-tab-panel" data-panel="documents">${child_table("documents", [
			"Document Type",
			"File",
			"Uploaded By",
			"Uploaded On",
			"Remarks",
		])}</div>
		<div class="lm-tab-panel" data-panel="guarantors"><div class="lm-notice">${__(
			"Guarantor exposure is validated against active guarantees."
		)}</div>${child_table("guarantors", ["Employee", "Name", "Status", "Age", "Note"])}</div>
		<div class="lm-tab-panel" data-panel="schedule"><div class="lm-toolbar lm-app-edit-actions lm-hidden"><button class="lm-btn primary lm-app-schedule">${__("Process Schedule")}</button></div><div class="lm-notice lm-deduction-note"></div>${child_table("schedule", [
			"Period",
			"Due Date",
			"Opening",
			"Capital",
			"Interest",
			"Insurance",
			"Total Refund",
			"Closing",
			"Status",
		])}</div>
		<div class="lm-tab-panel" data-panel="committee-approval"><div class="lm-section-label">${__("Committee & Approval")}</div><div class="lm-form-grid cols-2">${[
			["Loan Committee Date", "committee_date"], ["MD Decision", "md_decision"],
			["Committee Decision", "committee_decision"], ["MD Approver", "md_approver"],
			["Committee Remarks", "committee_remarks"], ["Committee Reviewer", "committee_decided_by"],
		].map(([label, field]) => display_field(__(label), field)).join("")}</div><div class="lm-section-label" style="margin-top:18px">${__("Prefilled Approval Steps")}</div><div class="lm-app-approval-chain"></div><div class="lm-notice">${__("Members are copied from the selected Loan Committee Master and must approve in the displayed order. Only the current member can act; the final member completes the committee step.")}</div><button class="lm-btn primary lm-drawer-committee">${__("Open Loan Committee")}</button></div>
		<div class="lm-tab-panel" data-panel="payroll-mapping"><div class="lm-section-label">${__("Automatic Loan Payroll Mapping")}</div><div class="lm-notice lm-payroll-automation-note"></div>${child_table("payroll-mappings", [
			"Component", "PDB Type", "PDB Code", "Description", "Monthly Amount", "Payroll Record", "Status",
		])}<div class="lm-notice" style="margin-top:14px">${__("Overtime is not assigned on the loan. Submitted overtime or night-duty records with Recorded status, actual times and approved hours are loaded automatically into the matching employee payroll cycle and cannot be paid twice.")}</div></div>
		<div class="lm-tab-panel" data-panel="audit">${child_table("audit", [
			"Date / Time",
			"User",
			"Action",
			"Remarks",
		])}</div>
	</div><div class="lm-drawer-actions"><div><span class="lm-badge gray lm-workflow-badge">${__(
		"Draft"
	)}</span> <span class="lm-muted lm-approval-note"></span></div><button class="lm-btn secondary lm-open-native">${__(
		"Open Full Record"
	)}</button></div></aside>`;
}

function summary_row(label, fieldname, percent = false, suffix = "", total = false) {
	return `<div class="lm-summary-row ${total ? "total" : ""}"><span>${__(
		label
	)}</span><strong data-summary="${fieldname}" data-percent="${
		percent ? 1 : 0
	}" data-suffix="${suffix}">—</strong></div>`;
}

function child_table(kind, columns) {
	return `<div class="lm-table-wrap"><table class="lm-table"><thead><tr>${columns
		.map((x) => `<th>${__(x)}</th>`)
		.join("")}</tr></thead><tbody data-child="${kind}"><tr><td colspan="${
		columns.length
	}" class="lm-muted">${__("No records")}</td></tr></tbody></table></div>`;
}

	function load_applications($root) {
	const args = {
		search: $root.find('.lm-app-filter[data-filter="search"]').val() || "",
		loan_type: $root.find('.lm-app-filter[data-filter="loan_type"]').val() || "",
		status: $root.find('.lm-app-filter[data-filter="status"]').val() || "",
	};
	$root
		.find(".lm-application-body")
		.html(`<tr><td colspan="9" class="lm-muted">${__("Loading…")}</td></tr>`);
	$root.find('.lm-app-filter[data-filter="loan_type"]').prop("disabled", true);
	frappe.call({
		method: "karyo.desk.loan_management.applications",
		args,
		callback: (r) => {
			const data = r.message || { rows: [] };
			const $statuses=$root.find('.lm-app-filter[data-filter="status"]');
			const selected=$statuses.val();
			$statuses.empty().append($('<option>').val('').text(__('All')));
			(data.statuses || []).forEach(state=>$statuses.append($('<option>').val(state).text(__(state))));
			$statuses.val(selected || '');
			const $types = $root.find('.lm-app-filter[data-filter="loan_type"]');
			const selectedType = $types.val() || "";
			$types.empty().append($("<option>").val("").text(__("All")));
			(data.loan_types || []).forEach((type) => $types.append(
				$("<option>").val(type.name).text(type.loan_name ? `${type.name} - ${type.loan_name}` : type.name)
			));
			if ((data.loan_types || []).some(type => type.name === selectedType)) $types.val(selectedType);
			$types.prop("disabled", false);
			$root.find(".lm-application-count").text(__("{0} records", [data.rows.length]));
			$root
				.find(".lm-application-body")
				.html(
					data.rows.map(application_row).join("") ||
						`<tr><td colspan="9" class="lm-muted">${__(
							"No matching applications"
						)}</td></tr>`
				);
		},
		error: () => {
			$root.find('.lm-app-filter[data-filter="loan_type"]').prop("disabled", false);
			$root.find(".lm-application-count").text(__("Unable to load"));
			$root.find(".lm-application-body").html(`<tr><td colspan="9" class="lm-muted">${__("Unable to load loan applications. Please try Search again.")}</td></tr>`);
		},
	});
}

function load_employee_requests($root) {
	const $body = $root.find(".lm-employee-request-body");
	$body.html(`<tr><td colspan="8" class="lm-muted">${__("Loading…")}</td></tr>`);
	frappe.call({
		method: "karyo.loan.self_service.requests",
		callback: (response) => {
			const rows = response.message || [];
			$root.find(".lm-employee-request-count").text(__("{0} servicing requests", [rows.length]));
			$body.html(
				rows.map(employee_request_row).join("") ||
					`<tr><td colspan="8" class="lm-muted">${__("No employee loan servicing requests found.")}</td></tr>`
			);
		},
		error: () => {
			$root.find(".lm-employee-request-count").text(__("Unable to load"));
			$body.html(`<tr><td colspan="8" class="lm-muted">${__("Unable to load employee loan servicing requests. Select Refresh to try again.")}</td></tr>`);
		},
	});
}

function employee_request_row(row) {
	const escape = frappe.utils.escape_html;
	const details = row.request_type === "Advance Payment"
		? format_currency(row.amount || 0)
		: row.new_period ? __("{0} months", [row.new_period]) : "—";
	const action = row.status === "Pending Review" ? __("Review / Change Status") : __("View");
	return `<tr><td>${escape(row.name)}</td><td><button type="button" class="lm-text-link lm-open-loan" data-loan="${escape(row.loan)}">${escape(row.loan)}</button></td><td>${escape(row.employee || "—")}</td><td>${escape(__(row.request_type || "—"))}</td><td>${row.effective_date ? frappe.datetime.str_to_user(row.effective_date) : "—"}</td><td>${details}</td><td><span class="lm-badge ${status_class(row.status)}">${escape(__(row.status || "Pending Review"))}</span></td><td><button type="button" class="lm-btn small secondary lm-service-request-action" data-request="${escape(row.name)}" data-loan="${escape(row.loan)}">${action}</button></td></tr>`;
}

function application_row(row) {
	return `<tr><td>✎</td><td><button class="lm-text-link lm-open-loan" data-loan="${frappe.utils.escape_html(
		row.name
	)}">${frappe.utils.escape_html(row.name)}</button></td><td>${frappe.utils.escape_html(
		[row.employee, row.employee_name].filter(Boolean).join(" - ")
	)}</td><td>${frappe.utils.escape_html(
		row.loan_type || "—"
	)}</td><td>${frappe.datetime.str_to_user(row.date_applied || "")}</td><td>${format_currency(
		row.amount_applied || 0
	)}</td><td>${format_currency(
		row.approved_amount || 0
	)}</td><td><span class="lm-badge ${status_class(
		row.display_status
	)}">${frappe.utils.escape_html(
		row.display_status
	)}</span></td><td class="lm-row-actions">${loan_row_actions(row.name, row.agreement_available)}</td></tr>`;
}

function open_application_drawer($root, loan, view_only = false) {
	const $drawer = $root
		.find(".lm-app-drawer")
		.data("loan", loan || "").data("dirty", false);
	lm_open_drawer_state($root, $drawer, document.activeElement);
	$root.find(".lm-tab").first().trigger("click");
	if (!loan) {
		$root.find('.lm-tab[data-tab="details"]').trigger("click");
		$drawer.find(".lm-drawer-loading").hide();
		$drawer.find(".lm-drawer-content").show();
		$drawer.find(".lm-drawer-subtitle").text(__("New loan application"));
		$drawer.find("[data-field]").val("");
		$drawer.find('[data-field="name"]').val(__("Auto-generated"));
		$drawer.find("[data-summary], [data-text]").text("—");
		$drawer.find(".lm-open-native").text(__("Create in Full Form"));
		$drawer.find(".lm-app-edit-actions").addClass("lm-hidden");
		$drawer.find(".lm-app-lock").removeClass("lm-hidden").text(
			__("Create the application in the full form, then return here to maintain it.")
		);
		return;
	}
	const reload_detail = async () => {
		const data = await frappe.xcall("karyo.desk.loan_management.application_detail", {loan});
		if(!$drawer.hasClass('open') || $drawer.data('loan') !== loan)return;
		if($drawer.data('dirty')) {
			render_application_state($drawer,data.loan || {});
			render_loan_lifecycle($drawer,data);
			if(!data.editable)$drawer.find('.lm-app-edit-actions').addClass('lm-hidden');
			return;
		}
		render_application_detail($drawer,{...data,editable:data.editable && !view_only});
	};
	karyo.live.watch('loan-open-drawer',reload_detail,['Karyo Loan','Karyo Loan Ledger Entry'],()=>frappe.get_route()[0]==='loan-management' && $drawer.hasClass('open') && $drawer.data('loan')===loan,{allowModal:true});
	$drawer.find(".lm-drawer-content").hide();
	$drawer.find(".lm-drawer-loading").show();
	frappe.call({
		method: "karyo.desk.loan_management.application_detail",
		args: { loan },
		callback: (r) => {
			if($drawer.data('loan') !== loan)return;
			const data = r.message || {};
			render_application_detail($drawer, {...data, editable: data.editable && !view_only});
			$drawer.find(".lm-drawer-loading").hide();
			$drawer.find(".lm-drawer-content").show();
		},
	});
}

function render_application_detail($drawer, data) {
	const loan = data.loan || {};
	const $subtitle = $drawer.find(".lm-drawer-subtitle").empty();
	$subtitle.append(document.createTextNode(loan.name || ""));
	if (loan.employee) {
		$subtitle.append(document.createTextNode(" • "));
		const employeeLabel = [loan.employee_name, loan.employee].filter(Boolean).join(" · ");
		if (data.can_view_employee) {
			$("<a>")
				.attr("href", `/app/employee-360/${encodeURIComponent(loan.employee)}`)
				.text(employeeLabel)
				.appendTo($subtitle);
		} else {
			$subtitle.append(document.createTextNode(employeeLabel));
		}
	}
	$drawer.find(".lm-open-native").text(__("Open Full Record"));
	const editable = Boolean(data.editable);
	$drawer.find("[data-field]").each(function () {
		const key = this.dataset.field;
		if (editable && this.dataset.edit) {
			this.readOnly = false;
			this.type = this.dataset.edit;
			$(this).val(loan[key] == null ? "" : loan[key]);
		} else {
			this.readOnly = true;
			this.type = "text";
			$(this).val(format_loan_value(key, loan[key]));
		}
	});
	$drawer.find("[data-check-field]").each(function () {
		this.checked = Boolean(cint(loan[this.dataset.checkField]));
		this.disabled = !editable;
	});
	$drawer
		.find('[data-edit-text="purpose"]')
		.toggleClass("lm-hidden", !editable)
		.val(loan.purpose || "");
	$drawer.find('[data-text="purpose"]').toggleClass("lm-hidden", editable);
	$drawer.find(".lm-app-edit-actions").toggleClass("lm-hidden", !editable);
	$drawer
		.find(".lm-app-lock")
		.toggleClass("lm-hidden", !data.lock_reason)
		.text(data.lock_reason || "");
	// Static deductions are posted by Karyo Loan.before_submit(), not from here, so
	// this reports state instead of offering a button that would bypass the workflow.
	$drawer
		.find(".lm-deduction-note")
		.text(
			data.deductions_posted
				? __("Capital, interest and insurance deductions are posted to payroll.")
				: __(
						"Deductions post to payroll automatically when Activate repayment completes."
				  )
		);
	$drawer.find(".lm-payroll-automation-note").html(
		`<strong>${frappe.utils.escape_html(data.payroll_automation?.stage || __("Waiting"))}</strong><br>${frappe.utils.escape_html(data.payroll_automation?.message || "")}`
	);
	lm_set_currency(data.currency);
	$drawer.find("[data-text]").each(function () {
		$(this).text(loan[this.dataset.text] || "—");
	});
	$drawer.find("[data-summary]").each(function () {
		const key = this.dataset.summary;
		const raw = loan[key];
		let value =
			raw == null
				? "—"
				: this.dataset.percent === "1"
				? `${flt(raw).toFixed(2)}%`
				: ["period_months"].includes(key)
				? raw
				: format_currency(raw);
		$(this).text(value === "—" ? value : value + (this.dataset.suffix || ""));
	});
	render_application_state($drawer,loan);
	$drawer.data('dirty',false);
	render_children($drawer, data);
	render_application_approval_chain($drawer, data.approval_chain || {});
	render_loan_lifecycle($drawer,data);
	render_lien_workspace($drawer, data);
	const $agreements=$drawer.find('.lm-agreement-actions');
	$agreements.empty();
	if(data.application_document?.available)$('<button class="lm-btn primary">').text(__('Print Application PDF')).on('click',()=>karyo.loan_ui.application_pdf(loan.name)).appendTo($agreements);
	if(data.agreement?.available)$('<button class="lm-btn secondary">').text(__('View Agreement')).on('click',()=>karyo.loan_ui.agreement(loan.name)).appendTo($agreements);
	if(data.agreement?.signed_on)$('<span class="lm-badge good">').text(__('Signed by {0} on {1}', [data.agreement.signer_name || data.agreement.signed_by || '', frappe.datetime.str_to_user(data.agreement.signed_on)])).appendTo($agreements);
	else if(data.agreement?.requires_signature)$('<span class="lm-badge warn">').text(__('Awaiting employee signature')).appendTo($agreements);
	if(frappe.model.can_write('Karyo Loan')){
		$('<button class="lm-btn secondary">').text(__('Add Agreement')).prop('disabled',!!data.agreement?.issued_on||!!data.agreement?.signed_on).on('click',()=>karyo.loan_ui.agreement_admin(loan.name)).appendTo($agreements);
		if(data.agreement?.available&&!data.agreement?.issued_on)$('<button class="lm-btn secondary">').text(__('Issue Agreement')).on('click',async()=>{await frappe.xcall('karyo.loan.agreements.issue',{loan:loan.name});frappe.show_alert({message:__('Agreement issued'),indicator:'green'});}).appendTo($agreements);
	}
	$('<button class="lm-btn secondary">').text(__('Servicing Requests')).on('click',()=>karyo.loan_ui.review_requests(loan.name)).appendTo($agreements);
}

function render_application_approval_chain($drawer, chain) {
	const escape = frappe.utils.escape_html;
	const rows = chain.steps || [];
	$drawer.find(".lm-app-approval-chain").html(rows.map((row) => {
		const current = chain.current && chain.current.name === row.name;
		const status = current ? __("Current approver") : __(row.status || "Pending");
		return `<div class="lm-notice ${row.status === "Approved" ? "good" : current ? "warn" : ""}"><strong>${escape(row.approval_sequence)}. ${escape(row.member_name || row.approver_user)}</strong> · ${escape(__(row.approval_level || ""))}<br>${escape(row.approval_group || row.email || "")}<br><span class="lm-badge ${row.status === "Approved" ? "green" : current ? "yellow" : "gray"}">${escape(status)}</span>${row.is_final_approver ? ` <span class="lm-badge blue">${__("Final Approver")}</span>` : ""}</div>`;
	}).join("") || `<div class="lm-notice warn">${__("No approval members are configured. Open Loan Committee Master and assign it to this Loan Type.")}</div>`);
}

function render_lien_workspace($drawer, data) {
	const loan = data.loan || {};
	const lien = data.lien || {};
	const $box = $drawer.find('.lm-lien-workspace');
	const escape = frappe.utils.escape_html;
	if (!lien.required) {
		$box.html(`<div class="lm-section-label">${__('Vehicle Lien')}</div><div class="lm-notice">${__('This loan type does not require a vehicle lien.')}</div>`);
		return;
	}
	const status = loan.lien_status || lien.default_status || 'Pending';
	const rows = [
		[__('Status'), __(status)],
		[__('Registration Authority'), lien.authority || '—'],
		[__('Lien Registration No.'), loan.lien_registration_no || '—'],
		[__('Vehicle Registration No.'), loan.vehicle_registration_no || '—'],
		[__('Registered On'), loan.lien_registered_date ? frappe.datetime.str_to_user(loan.lien_registered_date) : '—'],
		[__('Evidence'), loan.lien_document || '—'],
		[__('Verified'), cint(loan.lien_verified) ? __('Yes') : __('No')],
		[__('Verified By / On'), [loan.lien_verified_by, loan.lien_verified_on ? frappe.datetime.str_to_user(loan.lien_verified_on) : ''].filter(Boolean).join(' · ') || '—'],
	];
	const history = (lien.history || []).map(row => `<tr><td>${escape(__(row.lien_status || ''))}</td><td>${escape(row.event_date ? frappe.datetime.str_to_user(row.event_date) : '—')}</td><td>${escape(row.event_user || '—')}</td><td>${escape(row.remarks || '—')}</td></tr>`).join('');
	$box.html(`<div class="lm-section-label">${__('Vehicle Lien')}</div>
		<div class="lm-notice ${status === 'Registered' && cint(loan.lien_verified) ? 'good' : 'warn'}">${escape(lien.instructions || __('Register and verify the vehicle lien before disbursement.'))}</div>
		<div class="lm-form-grid cols-2">${rows.map(([label, value]) => `<div class="lm-field"><label>${escape(label)}</label><div>${escape(value)}</div></div>`).join('')}</div>
		<div class="lm-toolbar lm-lien-actions"></div>
		<div class="lm-section-label" style="margin-top:18px">${__('Lien History')}</div><div class="lm-table-wrap"><table class="lm-table"><thead><tr><th>${__('Status')}</th><th>${__('Date / Time')}</th><th>${__('User')}</th><th>${__('Remarks')}</th></tr></thead><tbody>${history || `<tr><td colspan="4" class="lm-muted">${__('No lien events recorded')}</td></tr>`}</tbody></table></div>`);
	if (frappe.model.can_write('Karyo Loan')) {
		$('<button type="button" class="lm-btn primary">').text(__('Update Vehicle Lien')).on('click', () => open_lien_dialog($drawer, data)).appendTo($box.find('.lm-lien-actions'));
	}
}

function open_lien_dialog($drawer, data) {
	const loan = data.loan || {}, lien = data.lien || {};
	const dialog = new frappe.ui.Dialog({title: __('Vehicle Lien · {0}', [loan.name]), fields: [
		{fieldname:'lien_status', fieldtype:'Select', label:__('Lien Status'), options:'Pending\nReturned\nRejected\nRegistered\nRelease Pending\nReleased\nCancelled', default:loan.lien_status || lien.default_status || 'Pending', reqd:1},
		{fieldname:'lien_registration_no', fieldtype:'Data', label:__('Lien Registration No.'), default:loan.lien_registration_no || ''},
		{fieldname:'vehicle_registration_no', fieldtype:'Data', label:__('Vehicle Registration No.'), default:loan.vehicle_registration_no || ''},
		{fieldname:'lien_registered_date', fieldtype:'Date', label:__('Lien Registered On'), default:loan.lien_registered_date || ''},
		{fieldname:'lien_document', fieldtype:'Attach', label:__('Lien Document'), default:loan.lien_document || ''},
		{fieldname:'lien_verified', fieldtype:'Check', label:__('Lien Verified'), default:cint(loan.lien_verified)},
		{fieldname:'lien_released_date', fieldtype:'Date', label:__('Lien Released On'), default:loan.lien_released_date || ''},
		{fieldname:'lien_return_reason', fieldtype:'Small Text', label:__('Return Reason'), default:loan.lien_return_reason || ''},
		{fieldname:'lien_rejection_reason', fieldtype:'Small Text', label:__('Rejection / Cancellation Reason'), default:loan.lien_rejection_reason || ''},
	]});
	const requirements = () => {
		const registered = dialog.get_value('lien_status') === 'Registered';
		for (const fieldname of ['lien_registration_no','vehicle_registration_no','lien_registered_date']) dialog.set_df_property(fieldname, 'reqd', registered ? 1 : 0);
		dialog.set_df_property('lien_document', 'reqd', registered && lien.document_required ? 1 : 0);
		dialog.set_df_property('lien_verified', 'read_only', !registered);
	};
	dialog.fields_dict.lien_status.df.onchange = requirements;
	dialog.set_primary_action(__('Save Lien Details'), async () => {
		const values = dialog.get_values();
		if (!values) return;
		dialog.get_primary_btn().prop('disabled', true);
		try {
			const result = await frappe.xcall('karyo.desk.loan_management.update_vehicle_lien', {loan:loan.name, values});
			render_application_detail($drawer, result.detail || {});
			dialog.hide();
			frappe.show_alert({message:result.message || __('Vehicle lien details updated.'), indicator:'green'});
		} finally { dialog.get_primary_btn().prop('disabled', false); }
	});
	dialog.show();
	requirements();
}

function render_loan_lifecycle($drawer, data) {
	const lifecycle = data.lifecycle || { steps: [], repayment: {} };
	const escape = frappe.utils.escape_html;
	const rows = (lifecycle.steps || []).map((step, index) => {
		const classes = ["lm-loan-step", step.done ? "done" : "", step.current ? "current" : "", step.terminal ? "terminal" : "", step.ignored ? "ignored" : "", !step.available && !step.done && !step.ignored ? "blocked" : ""].filter(Boolean).join(" ");
		const buttonLabel = step.terminal ? __("Rejected") : step.ignored ? __("Ignored") : step.done ? __("Completed") : __("Pending");
		let button = `<button type="button" class="lm-btn small secondary" disabled>${escape(buttonLabel)}</button>`;
		if (step.action && step.available) button = `<button type="button" class="lm-btn small ${step.current ? "primary" : "secondary"} lm-run-lifecycle" data-step="${escape(step.key)}">${escape(__(step.action))}</button>`;
		else if (step.action_kind === "repayment" && step.available) button = `<button type="button" class="lm-btn small secondary lm-open-repayment">${__("Process repayment")}</button>`;
		else if (step.action_kind === "settlement" && step.available) button = `<button type="button" class="lm-btn small primary lm-open-settlement">${__("Settle loan")}</button>`;
		const reason = step.dependency_error || step.blocked_reason;
		const detail = step.terminal ? __("Process stopped at rejection") : step.ignored ? __("Not applicable after rejection") : step.done ? __("Complete") : step.current ? __("Current step") : __("Not started");
		const stepMarker = step.terminal ? "×" : step.ignored ? "—" : step.done ? "✓" : index + 1;
		const terminalReason = step.terminal_reason ? `<div class="lm-loan-step-terminal-reason"><strong>${__("Reason")}:</strong> ${escape(step.terminal_reason)}</div>` : "";
		const alternatives = (step.alternatives || []).map((item) => `<button type="button" class="lm-btn small ${item.danger ? "danger" : "secondary"} lm-run-lifecycle" data-step="${escape(step.key)}" data-action="${escape(item.action)}">${escape(item.label)}</button>`).join("");
		return `<div class="${classes}" data-step="${escape(step.key)}"><span class="lm-loan-stepno">${stepMarker}</span><div class="lm-loan-stepbody"><strong>${escape(step.label)}</strong><div class="lm-muted">${escape(detail)}</div>${terminalReason}${reason && !step.done && !step.ignored ? `<div class="lm-loan-step-error">${escape(reason)}</div>` : ""}${alternatives ? `<div class="lm-toolbar lm-loan-step-alternatives">${alternatives}</div>` : ""}</div>${button}</div>`;
	}).join("");
	$drawer.find(".lm-loan-lifecycle").html(rows || `<div class="lm-notice warn">${__("The loan workflow is not configured.")}</div>`).data("steps", lifecycle.steps || []);
	render_repayment_workspace($drawer, data);
}

function render_repayment_workspace($drawer, data) {
	const repayment = data.lifecycle?.repayment || {};
	const loan = data.loan || {};
	const $box = $drawer.find(".lm-repayment-workspace");
	if (!repayment.active && !repayment.settled) {
		$box.empty();
		return;
	}
	const progress = Math.max(0, Math.min(100, flt(repayment.progress)));
	$box.html(`<div class="lm-section-label">${__("Repayment / Settlement")}</div>
		<div class="lm-repayment-summary"><div><small>${__("Instalments paid")}</small><strong>${cint(repayment.paid_periods)} / ${cint(repayment.periods)}</strong></div><div><small>${__("Outstanding capital")}</small><strong>${format_currency(repayment.outstanding_capital || 0)}</strong></div><div><small>${__("Total paid")}</small><strong>${format_currency(repayment.total_paid || 0)}</strong></div></div>
		<div class="lm-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}"><span style="width:${progress}%"></span></div>
		<div class="lm-muted">${repayment.settled ? __("This loan is fully settled.") : __("Regular repayments are posted from submitted salary slips. Use the options below for payroll processing, advance payment, rescheduling, or full settlement.")}</div>
		${repayment.active ? `<div class="lm-toolbar lm-repayment-actions"><button type="button" class="lm-btn small secondary lm-open-repayment">${__("Process Payslip")}</button><button type="button" class="lm-btn small secondary lm-open-advance">${__("Advance / Change Period")}</button>${repayment.can_settle ? `<button type="button" class="lm-btn small primary lm-open-settlement">${__("Full Settlement")}</button>` : ""}</div>${repayment.can_settle ? `<div class="lm-inline-settlement lm-hidden"><div class="lm-form-grid cols-2"><div class="lm-field"><label>${__("Settlement Date")}</label><input type="date" data-settlement="refund_date" value="${frappe.datetime.get_today()}"></div><div class="lm-field"><label>${__("Payment Type")}</label><select data-settlement="payment_type"><option>Cash</option><option>Cheque</option><option>Bank</option></select></div><div class="lm-field lm-settlement-cheque lm-hidden"><label>${__("Cheque Number")}</label><input data-settlement="cheque_no"></div><div class="lm-field"><label>${__("Remarks")}</label><textarea data-settlement="remarks"></textarea></div></div><label class="lm-check"><input type="checkbox" data-settlement="ewf_waive_interest"> ${__("EWF — waive outstanding interest")}</label><div class="lm-settlement-result lm-notice">${__("Select Preview to calculate the authoritative settlement balance.")}</div><div class="lm-toolbar"><button type="button" class="lm-btn small secondary lm-settlement-preview">${__("Preview Settlement")}</button><button type="button" class="lm-btn small good lm-settlement-submit" disabled>${__("Process Full Settlement")}</button></div></div>` : ""}` : ""}`);
	$box.data("loan", loan.name).data("settlement-ready", false);
}

async function refresh_application_drawer($drawer) {
	const loan = $drawer.data("loan");
	if (!loan) return;
	const data = await frappe.xcall("karyo.desk.loan_management.application_detail", { loan });
	if ($drawer.hasClass("open") && $drawer.data("loan") === loan) render_application_detail($drawer, data || {});
}

function run_lifecycle_step($drawer, step) {
	const execute = async (values = {}) => {
		try {
			const result = await frappe.xcall("karyo.desk.loan_management.run_lifecycle_action", { loan: $drawer.data("loan"), action: step.action, values });
			render_application_detail($drawer, result.detail || {});
			frappe.show_alert({ message: result.message || __("Step completed"), indicator: "green" });
			return true;
		} catch (error) {
			const message = error?.message || __("This step could not be completed because a dependency is missing.");
			const $row = $drawer.find(`.lm-loan-step[data-step="${step.key}"]`);
			let $reason = $row.find(".lm-loan-step-error");
			if (!$reason.length) $reason = $('<div class="lm-loan-step-error">').appendTo($row.find(".lm-loan-stepbody"));
			$reason.text(message);
			return false;
		}
	};
	if (step.inputs?.length) {
		const dialog = new frappe.ui.Dialog({ title: __(step.action), fields: step.inputs });
		dialog.set_primary_action(__("Complete Step"), async () => {
			const values = dialog.get_values();
			if (!values) return;
			dialog.get_primary_btn().prop("disabled", true);
			try { if (await execute(values)) dialog.hide(); }
			finally { dialog.get_primary_btn().prop("disabled", false); }
		});
		dialog.show();
		return;
	}
	frappe.confirm(__("Complete {0} for loan {1}?", [step.label, $drawer.data("loan")]), () => execute());
}

function render_application_state($drawer,loan) {
	const state=cint(loan.docstatus)===2?'Cancelled':loan.workflow_state || loan.status || __('Draft');
	$drawer.find('.lm-workflow-badge').attr('class',`lm-badge lm-workflow-badge ${status_class(state)}`).text(state);
	const approved=['Approved','Agreement Printed','Ready for Disbursement','Disbursed','Active Loan','Settled'].includes(state);
	const rejected = state === 'Rejected' && loan.rejection_reason ? __('Application rejected — {0}', [loan.rejection_reason]) : __('Application rejected');
	$drawer.find('.lm-approval-note').text(approved?__('Approval completed'):state==='Rejected'?rejected:state==='Returned'?__('Returned for rework'):loan.is_approval_required?__('Approval required'):__('Direct processing'));
}

function format_loan_value(key, value) {
	if (value == null || value === "") return "—";
	if (
		[
			"amount_applied",
			"approved_amount",
			"eligible_salary",
			"existing_deductions",
			"sum_assured",
			"monthly_insurance",
			"total_insurance",
		].includes(key)
	)
		return format_currency(value);
	if (
		[
			"date_applied",
			"committee_date",
			"repayment_start_date",
			"planned_repayment_end_date",
			"disbursement_date",
		].includes(key)
	)
		return frappe.datetime.str_to_user(value);
	if (["interest_rate", "deduction_pct"].includes(key))
		return `${flt(value).toFixed(2)}%`;
	if (key === "insurance_rate") return flt(value).toFixed(4).replace(/\.?0+$/, "");
	return value;
}

function render_children($drawer, data) {
	const money = (v) => format_currency(v || 0);
	const specs = {
		documents: (r) => [
			r.document_type,
			r.attachment
				? `<a class="lm-link" href="${r.attachment}" target="_blank">${__(
						"View file"
				  )}</a>`
				: "—",
			r.uploaded_by,
			r.uploaded_on,
			r.remarks,
		],
		guarantors: (r) => [r.guarantor, r.guarantor_name, r.guarantor_status, r.age, r.note],
		schedule: (r) => [
			r.month,
			r.due_date ? frappe.datetime.str_to_user(r.due_date) : "—",
			money(r.opening_balance),
			money(r.capital),
			money(r.interest),
			money(r.insurance),
			money(r.total),
			money(r.closing_balance),
			`<span class="lm-badge ${status_class(r.status)}">${frappe.utils.escape_html(
				r.status || "Pending"
			)}</span>`,
		],
		"payroll-mappings": (r) => [
			r.component_type,
			r.pdb_type || "—",
			r.pdb_code || "—",
			r.description || r.salary_component || "—",
			money(r.monthly_amount),
			r.additional_salary || __("Created at activation"),
			`<span class="lm-badge ${/Missing/.test(r.status || "") ? "red" : /Posted/.test(r.status || "") ? "green" : "gray"}">${frappe.utils.escape_html(r.status || "")}</span>`,
		],
		audit: (r) => [r.creation, r.owner, r.event_type, r.remarks],
	};
	Object.entries(specs).forEach(([kind, mapper]) => {
		const rows = kind === "audit" ? (data.history || []) : kind === "payroll-mappings" ? (data.payroll_automation?.rows || []) : (data[kind] || []);
		const $body = $drawer.find(`[data-child="${kind}"]`);
		const columns = $body.closest("table").find("th").length;
		$body.html(
			rows
				.map(
					(row) =>
						`<tr>${mapper(row)
							.map((cell) => `<td>${cell == null || cell === "" ? "—" : cell}</td>`)
							.join("")}</tr>`
				)
				.join("") ||
				`<tr><td colspan="${columns}" class="lm-muted">${__("No records")}</td></tr>`
		);
	});
}

function dashboard_page() {
	// Tiles render empty and are filled by render_dashboard() from live data, so no
	// placeholder figure can ever be mistaken for a real one.
	const kpis = [
		["active", "Active Loans"],
		["pending", "Pending Approval"],
		["applications", "Applications This Month"],
		["settled", "Settled This Month"],
		["exceptions", "Payroll Posting Exceptions"],
	];
	const steps = [
		["Application", "Capture employee & loan", "done"],
		["Compute", "Capital, interest, insurance", "done"],
		["Approval", "Optional workflow", "current"],
		["Schedule", "Generate repayment periods", ""],
		["Post", "Static P&D records", ""],
		["Monitor", "Ledger, balance, reports", ""],
	];
	return `<section class="lm-page active" id="lm-dashboard"><div class="lm-page-head"><div><h1>${__(
		"Loan Management Dashboard"
	)}</h1><div class="lm-crumb">LMS / ${__("Dashboard")} · <span class="lm-live-state">${__(
		"Loading live data…"
	)}</span></div></div><div class="lm-toolbar"><button class="lm-btn secondary" data-page="reports">${__(
		"View Reports"
	)}</button><button class="lm-btn primary lm-new-loan">+ ${__(
		"New Loan Application"
	)}</button></div></div><div class="lm-kpis">${kpis
		.map(
			([key, label]) =>
				`<button type="button" class="lm-kpi" data-kpi="${key}" disabled aria-haspopup="dialog" title="${__("View matching records")}"><span class="label">${__(
					label
				)}</span><span class="value">—</span><span class="note">${__("Loading…")}</span></button>`
		)
		.join(
			""
		)}</div><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
		"End-to-End Loan Process"
	)}</div><span class="lm-badge info">${__(
		"Status-driven"
	)}</span></div><div class="lm-card-body"><div class="lm-process">${steps
		.map(
			(s, i) =>
				`<div class="lm-step"><div class="n">${i + 1}</div><strong>${__(
					s[0]
				)}</strong><small>${__("Loading…")}</small></div>`
		)
		.join(
			""
		)}</div></div></div><div class="lm-grid-2"><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
		"Recent Loan Applications"
	)}</div><button class="lm-btn small secondary" data-page="applications">${__(
		"View All"
	)}</button></div><div class="lm-table-wrap"><table class="lm-table"><thead><tr><th>${__(
		"Loan No."
	)}</th><th>${__("Employee")}</th><th>${__("Loan Type")}</th><th>${__(
		"Approved Amount"
	)}</th><th>${__(
		"Status"
	)}</th><th>${__("Action")}</th></tr></thead><tbody class="lm-recent-body"><tr><td colspan="6" class="lm-muted">${__(
		"Loading…"
	)}</td></tr></tbody></table></div></div><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
		"Loans by Type"
	)}</div><span class="lm-muted">${__(
		"Active"
	)}</span></div><div class="lm-card-body lm-type-bars"><div class="lm-muted">${__(
		"Loading…"
	)}</div></div></div></div></section>`;
}

function dashboard_records_drawer() {
	return `<aside class="lm-drawer lm-kpi-drawer" tabindex="-1" inert role="dialog" aria-modal="true" aria-labelledby="lm-kpi-title" aria-hidden="true">
        <div class="lm-drawer-head"><div><strong class="lm-drawer-title" id="lm-kpi-title"></strong><div class="lm-muted lm-kpi-count"></div></div><button class="lm-close" aria-label="${__("Close")}">✕</button></div>
        <div class="lm-drawer-body"><div class="lm-kpi-message lm-muted"></div><div class="lm-table-wrap"><table class="lm-table"><thead></thead><tbody></tbody></table></div></div>
        <div class="lm-drawer-actions"><button class="lm-btn secondary lm-close">${__("Close")}</button></div>
    </aside>`;
}

function open_dashboard_records($root, metric) {
    const $card = $root.find(`[data-kpi="${metric}"]`);
    const $drawer = $root.find(".lm-kpi-drawer");
    const request = {};
	$drawer.data({request});
	lm_open_drawer_state($root, $drawer, $card[0]);
    $drawer.find(".lm-drawer-title").text($card.find(".label").text());
    $drawer.find(".lm-kpi-count").text(__("Loading…"));
    $drawer.find("thead, tbody").empty();
    $drawer.find(".lm-kpi-message").empty();
    frappe.call({method: "karyo.desk.loan_management.dashboard_records", args: {metric},
        callback: response => {
            if ($drawer.data("request") !== request) return;
            const data = response.message || {}, columns = data.columns || [], rows = data.rows || [];
            $drawer.find(".lm-kpi-count").text(__("{0} records", [rows.length]));
            $drawer.find(".lm-kpi-message").text(data.message || "");
            $drawer.find("thead").html(`<tr>${columns.map(col => `<th>${frappe.utils.escape_html(col.label)}</th>`).join("")}<th>${__("Action")}</th></tr>`);
            $drawer.find("tbody").html(rows.map(row => `<tr>${columns.map(col => `<td>${reference_cell(row[col.key], col.type)}</td>`).join("")}<td class="lm-row-actions">${row.view_loan ? `<button class="lm-btn secondary small lm-kpi-open-loan" data-loan="${frappe.utils.escape_html(row.view_loan)}">${__("View")}</button>` : "—"}</td></tr>`).join("") || `<tr><td colspan="${columns.length + 1}" class="lm-muted">${__("No matching records")}</td></tr>`);
        },
        error: () => {
            if ($drawer.data("request") !== request) return;
            $drawer.find(".lm-kpi-count").text(__("Records could not be loaded."));
        },
    });
}

function employee_requests_page() {
	return `<section class="lm-page" id="lm-employee-requests"><div class="lm-page-head"><div><h1>${__(
		"Employee Loan Requests"
	)}</h1><div class="lm-crumb">LMS / ${__("Transactions")} / ${__(
		"Employee Loan Requests"
	)}</div></div><div class="lm-toolbar"><button type="button" class="lm-btn secondary lm-employee-request-refresh">${__(
		"Refresh"
	)}</button></div></div><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
		"Advance Payment and Servicing Requests"
	)}</div><div class="lm-muted lm-employee-request-count">${__(
		"Loading…"
	)}</div></div><div class="lm-table-wrap"><table class="lm-table lm-employee-request-table"><thead><tr><th>${__(
		"Request"
	)}</th><th>${__("Loan")}</th><th>${__("Employee")}</th><th>${__("Request Type")}</th><th>${__(
		"Effective Date"
	)}</th><th>${__("Amount / Period")}</th><th>${__("Status")}</th><th>${__(
		"Action"
	)}</th></tr></thead><tbody class="lm-employee-request-body"><tr><td colspan="8" class="lm-muted">${__(
		"Loading…"
	)}</td></tr></tbody></table></div></div></section>`;
}

function applications_page() {
	return `<section class="lm-page" id="lm-applications"><div class="lm-page-head"><div><h1>${__(
		"Loan Applications"
	)}</h1><div class="lm-crumb">LMS / ${__("Transactions")} / ${__(
		"Loan Applications"
	)}</div></div><div class="lm-toolbar"><button type="button" class="lm-btn secondary lm-app-search">${__(
		"Refresh"
	)}</button><button type="button" class="lm-btn primary lm-new-loan">+ ${__(
		"Create Loan Application"
	)}</button></div></div><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
		"Search & Filter"
	)}</div></div><div class="lm-card-body"><div class="lm-filters"><div class="lm-field"><label>${__(
		"Employee Code / Name"
	)}</label><input class="lm-app-filter" data-filter="search" placeholder="${__(
		"Search employee"
	)}"></div><div class="lm-field"><label>${__(
		"Loan Type"
	)}</label><select class="lm-app-filter" data-filter="loan_type"><option value="">${__(
		"All"
	)}</option></select></div><div class="lm-field"><label>${__(
		"Status"
	)}</label><select class="lm-app-filter" data-filter="status"><option value="">${__(
		"All"
	)}</option></select></div><button class="lm-btn primary lm-app-search">${__(
		"Search"
	)}</button><button class="lm-btn secondary lm-app-reset">${__(
		"Reset"
	)}</button></div></div></div><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
		"Loan Application Register"
	)}</div><div class="lm-muted">${__(
		"Interactive Report"
	)} • <span class="lm-application-count">${__(
		"Loading…"
	)}</span></div></div><div class="lm-table-wrap"><table class="lm-table lm-application-table"><thead><tr><th></th><th>${__(
		"Loan Number"
	)}</th><th>${__("Employee")}</th><th>${__("Loan Code")}</th><th>${__(
		"Date Applied"
	)}</th><th>${__("Amount Applied")}</th><th>${__("Amount Approved")}</th><th>${__(
		"Status"
	)}</th><th>${__(
		"Action"
	)}</th></tr></thead><tbody class="lm-application-body"><tr><td colspan="9" class="lm-muted">${__(
		"Loading…"
	)}</td></tr></tbody></table></div></div></section>`;
}

function generic_page(id, title) {
	const group = [
		"loan-types",
		"insurance-rates",
		"recompute-params",
		"loan-conditions",
	].includes(id)
		? __("Reference")
		: id === "reports"
		? __("Reports")
		: ["approvals", "refund", "advance", "global-interest", "individual-interest"].includes(id)
		? __("Transactions")
		: __("Queries");
	return `<section class="lm-page" id="lm-${id}"><div class="lm-page-head"><div><h1>${frappe.utils.escape_html(
		title
	)}</h1><div class="lm-crumb">LMS / ${group} / ${frappe.utils.escape_html(
		title
	)}</div></div><div class="lm-toolbar"><button class="lm-btn secondary">${__(
		"Actions"
	)} ▾</button>${
		group === __("Reference")
			? `<button class="lm-btn primary">+ ${__("Create")}</button>`
			: ""
	}</div></div><div class="lm-notice">${__(
		"This screen is included in the Phase 1 visual shell. Live records and actions will be connected in the relevant implementation phase."
	)}</div><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${frappe.utils.escape_html(
		title
	)}</div><span class="lm-badge info">${__(
		"Phase 1"
	)}</span></div><div class="lm-placeholder"><div><strong>${__(
		"Reference layout ready"
	)}</strong>${__(
		"The detailed client layout will be populated with live MBC HRMS controls and data."
	)}</div></div></div></section>`;
}

// --- Query screens ----------------------------------------------------------
// The client prototype builds its seven read-only screens from one factory
// (makeQueryPage). We keep that shape: this config carries the per-screen
// heading, breadcrumb and whether a Loan Summary card applies, while the column
// set and values come from karyo.desk.loan_queries so the data stays authoritative.
const LM_QUERY_PAGES = {
	"schedule-query": {
		title: "Query Loan Schedule",
		crumb: "Loan Schedule",
		summary: true,
		requires_loan: true,
	},
	outstanding: {
		title: "Loan Outstanding Balance",
		crumb: "Outstanding Balance",
		summary: true,
		requires_loan: true,
	},
	history: { title: "Query Loan History", crumb: "Loan History", summary: true },
	ledger: { title: "Loan Ledger (New)", crumb: "Loan Ledger (New)", summary: true },
	"payroll-query": { title: "Loan Deductions - Payroll", crumb: "Loan Ded. Payroll" },
	guarantors: { title: "Loan Guarantors", crumb: "Loan Guarantors" },
	"static-query": {
		title: "Static Payments & Deductions - Loan Only",
		crumb: "Static Payments and Deductions",
	},
};

function is_query_page(id) {
	return Object.prototype.hasOwnProperty.call(LM_QUERY_PAGES, id);
}

function query_page(id) {
	const config = LM_QUERY_PAGES[id];
	const summary_card = config.summary
		? `<div class="lm-card lm-q-summary-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Loan Summary"
		  )}</div></div><div class="lm-card-body"><div class="lm-form-grid lm-q-summary"></div></div></div>`
		: "";
	return `<section class="lm-page" id="lm-${id}" data-query="${id}">
		<div class="lm-page-head"><div><h1>${__(config.title)}</h1><div class="lm-crumb">LMS / ${__(
		"Query"
	)} / ${__(config.crumb)}</div></div><div class="lm-toolbar"><button class="lm-btn secondary lm-q-download">${__(
		"Download"
	)} ▾</button></div></div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Search / Filter"
		)}</div></div><div class="lm-card-body"><div class="lm-filters">
			<div class="lm-field"><label>${__(
				"Employee Code"
			)}</label><select class="lm-q-filter" data-filter="employee"><option value="">${__("Loading…")}</option></select></div>
			<div class="lm-field"><label>${__(
				"Loan Number"
			)}</label><select class="lm-q-filter" data-filter="loan"><option value="">${__("Loading…")}</option></select></div>
			<div class="lm-field compact"><label>${__(
				"Status / Ref Type"
			)}</label><select class="lm-q-filter" data-filter="status"><option value="">${__(
		"All"
	)}</option></select></div>
			<button class="lm-btn primary lm-q-search">${__("Search")}</button>
			<button class="lm-btn secondary lm-q-reset">${__("Reset")}</button>
		</div></div></div>
		${summary_card}
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Results"
		)}</div><span class="lm-muted lm-q-count">${__(
		"Read-only Interactive Report"
	)}</span></div><div class="lm-table-wrap"><table class="lm-table"><thead class="lm-q-head"></thead><tbody class="lm-q-body"><tr><td class="lm-muted">${__(
		"Loading…"
	)}</td></tr></tbody></table></div></div>
	</section>`;
}

// Filter selects are shared across all seven screens, so the option lists are
// fetched once and reused.
let lm_query_options = null;

function with_query_options($root, callback) {
	if (lm_query_options) {
		callback(lm_query_options);
		return;
	}
	frappe.call({
		method: "karyo.desk.loan_queries.options",
		freeze: false,
		callback: (response) => {
			lm_query_options = response.message || { employees: [], loans: [] };
			lm_set_currency(lm_query_options.currency);
			// Drop query screens this user cannot read from the sidebar, matching how
			// apply_capabilities() gates the reference and transaction groups.
			Object.entries(lm_query_options.can_read || {}).forEach(([id, allowed]) => {
				$root.find(`.lm-nav [data-page="${id}"]`).toggle(Boolean(allowed));
			});
			callback(lm_query_options);
		},
		error: () => callback({ employees: [], loans: [], _error: true }),
	});
}

function populate_query_filters($root, id, options) {
	const config = LM_QUERY_PAGES[id];
	const $page = $root.find(`#lm-${id}`);
	const escape = frappe.utils.escape_html;
	const $employee = $page.find('[data-filter="employee"]');
	if (!$employee.data("ready")) {
		const employeeRows = options.employees || [];
		$employee
			.data("ready", !options._error)
			.html(
				`<option value="">${options._error ? __("Unable to load options") : employeeRows.length ? __("All Employees") : __("No employees available")}</option>` +
					employeeRows
						.map((row) => `<option value="${escape(row.value)}">${escape(row.label)}</option>`)
						.join("")
			);
	}
	populate_query_loan_filter($page, config, options);
	const $status = $page.find('[data-filter="status"]');
	const choices = (options.status_options || {})[id];
	if (!$status.data("ready")) {
		$status.data("ready", !options._error);
		if (choices && choices.length) {
			$status.append(
				choices.map((value) => `<option value="${escape(value)}">${escape(value)}</option>`).join("")
			);
		} else if (!options._error) {
			$status.closest(".lm-field").addClass("lm-hidden");
		}
	}
}

function populate_query_loan_filter($page, config, options, reset = false) {
	const escape = frappe.utils.escape_html;
	const $loan = $page.find('[data-filter="loan"]');
	const employee = $page.find('[data-filter="employee"]').val() || "";
	const current = reset ? "" : ($loan.val() || "");
	const loans = (options.loans || []).filter((row) => !employee || row.employee === employee);
	const current_is_available = loans.some((row) => row.value === current);
	const selected = current_is_available
		? current
		: config.requires_loan && loans.length
			? loans[0].value
			: "";
	const blank_label = options._error
		? __("Unable to load options")
		: loans.length
			? __("All Loans")
			: employee
				? __("No loans for selected employee")
				: __("No loans available");
	const blank_option = config.requires_loan && loans.length
		? ""
		: `<option value="">${blank_label}</option>`;

	$loan
		.data("ready", !options._error)
		.prop("disabled", Boolean(options._error) || !loans.length)
		.html(
			blank_option +
				loans.map((row) => `<option value="${escape(row.value)}">${escape(row.label)}</option>`).join("")
		)
		.val(selected);
}

function load_query($root, id) {
	const $page = $root.find(`#lm-${id}`);
	const request_id = cint($page.data("query-request") || 0) + 1;
	$page.data("query-request", request_id);
	with_query_options($root, (options) => {
		if ($page.data("query-request") !== request_id) return;
		populate_query_filters($root, id, options);
		if (options._error) {
			$page.find(".lm-q-body").html(`<tr><td class="lm-muted">${__("Unable to load filter options. Please try Search again.")}</td></tr>`);
			return;
		}
		const args = { kind: id };
		$page.find(".lm-q-filter").each(function () {
			if (this.value) args[this.dataset.filter] = this.value;
		});
		$page.find(".lm-q-body").html(`<tr><td class="lm-muted">${__("Loading…")}</td></tr>`);
		const $summary = $page.find(".lm-q-summary");
		if ($summary.length) {
			const has_loan = Boolean(args.loan);
			$page.find(".lm-q-summary-card").toggleClass("lm-hidden", !has_loan);
			$summary.html(has_loan ? `<div class="lm-muted">${__("Loading selected loan…")}</div>` : "");
		}
		frappe.call({
			method: "karyo.desk.loan_queries.run",
			args: args,
			freeze: false,
			callback: (response) => {
				if ($page.data("query-request") === request_id) {
					render_query($root, id, response.message || {});
				}
			},
			error: () => {
				if ($page.data("query-request") !== request_id) return;
				$page
					.find(".lm-q-body")
					.html(`<tr><td class="lm-muted">${__("This query could not be loaded.")}</td></tr>`);
			},
		});
	});
}

function render_query($root, id, data) {
	const $page = $root.find(`#lm-${id}`);
	const columns = data.columns || [];
	const rows = data.rows || [];
	lm_set_currency(data.currency);
	$page.data("report", data.report || "");

	if (data.permitted === false) {
		$page.find(".lm-q-head").empty();
		$page
			.find(".lm-q-body")
			.html(
				`<tr><td class="lm-muted">${frappe.utils.escape_html(
					data.message || __("You do not have permission to view this query.")
				)}</td></tr>`
			);
		$page.find(".lm-q-count").text("");
		$page.find(".lm-q-summary-card").addClass("lm-hidden");
		return;
	}

	$page
		.find(".lm-q-head")
		.html(
			`<tr>${columns
				.map((column) => `<th>${frappe.utils.escape_html(column.label)}</th>`)
				.join("")}<th>${__("Action")}</th></tr>`
		);

	const empty = data.needs_loan
		? __("Select a loan number to run this query.")
		: __("No records found");
	$page
		.find(".lm-q-body")
		.html(
			rows
				.map(
					(row) =>
						`<tr>${columns
							.map((column) => `<td>${query_cell(row[column.key], column.type)}</td>`)
							.join("")}<td class="lm-row-actions">${(row.loan || $page.find('[data-filter="loan"]').val()) ? loan_row_actions(row.loan || $page.find('[data-filter="loan"]').val()) : "—"}</td></tr>`
				)
				.join("") ||
				`<tr><td colspan="${Math.max(columns.length + 1, 1)}" class="lm-muted">${empty}</td></tr>`
		);
	$page
		.find(".lm-q-count")
		.text(
			rows.length
				? __("Read-only Interactive Report • {0} record(s)", [rows.length])
				: __("Read-only Interactive Report")
		);

	const $summary = $page.find(".lm-q-summary");
	if ($summary.length) {
		const summary = data.summary || [];
		$page.find(".lm-q-summary-card").toggleClass("lm-hidden", !summary.length);
		$summary.html(
			summary
				.map(
					(item) =>
						`<div class="lm-field"><label>${frappe.utils.escape_html(
							item.label
						)}</label><input readonly value="${frappe.utils.escape_html(
							summary_value(item)
						)}"></div>`
				)
				.join("")
		);
	}
}

function summary_value(item) {
	if (item.value === null || item.value === undefined || item.value === "") return "—";
	if (item.type === "currency") return lm_money(item.value);
	if (item.type === "months") return __("{0} months", [item.value]);
	return String(item.value);
}

function query_cell(value, type) {
	if (value === null || value === undefined || value === "") return "—";
	if (type === "check") return cint(value) ? __("Yes") : __("No");
	if (type === "currency") return frappe.utils.escape_html(lm_money(value));
	if (type === "date") return frappe.utils.escape_html(frappe.datetime.str_to_user(value));
	if (type === "badge")
		return `<span class="lm-badge ${status_class(value)}">${frappe.utils.escape_html(
			value
		)}</span>`;
	return frappe.utils.escape_html(String(value));
}

// --- Reference screens ------------------------------------------------------
// The client prototype builds its four Reference pages from one factory
// (makeReferencePage): filter bar, register grid, and a drawer for create/edit.
// Columns and the form spec come from karyo.desk.loan_reference so the register
// reflects the real schema and the editor respects the governance lifecycle.
const LM_REFERENCE_PAGES = {
    "operation-codes": { title: "Loan Operation Codes", crumb: "Loan Operation Codes", setup: true },
    "document-requirements": { title: "Document Requirements", crumb: "Document Requirements", setup: true },
    "approval-authorities": { title: "Approval Authorities", crumb: "Approval Authorities", setup: true },
	"loan-committees": { title: "Loan Committee Master", crumb: "Loan Committee Master", setup: true },
	"loan-types": { title: "Maintain Loan Types", crumb: "Loan Types" },
	"insurance-rates": { title: "Maintain Insurance Rates", crumb: "Insurance Rates" },
	"recompute-params": { title: "Recomputation Parameters", crumb: "Recomputation Parameters" },
	"loan-conditions": { title: "Maintain Loan Conditions", crumb: "Loan Conditions" },
};

function is_reference_page(id) {
	return Object.prototype.hasOwnProperty.call(LM_REFERENCE_PAGES, id);
}

function reference_page(id) {
	const config = LM_REFERENCE_PAGES[id];
	return `<section class="lm-page" id="lm-${id}" data-reference="${id}">
		<div class="lm-page-head"><div><h1>${__(config.title)}</h1><div class="lm-crumb">LMS / ${__(
		config.setup ? "Additional Loan Setup" : "Reference"
	)} / ${__(config.crumb)}</div></div><div class="lm-toolbar"><div class="dropdown lm-ref-action-menu"><button type="button" class="lm-btn secondary lm-ref-actions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="lm-ref-actions-${id}">${__(
		"Actions"
	)} ▾</button><div class="dropdown-menu dropdown-menu-right" aria-labelledby="lm-ref-actions-${id}"><button type="button" class="dropdown-item lm-ref-search">${__("Refresh")}</button><button type="button" class="dropdown-item lm-ref-reset">${__("Reset Filters")}</button></div></div><button class="lm-btn primary lm-ref-create">+ ${__("Create")}</button></div></div>
		<div class="lm-notice lm-ref-notice lm-hidden"></div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Search & Filter"
		)}</div></div><div class="lm-card-body"><div class="lm-filters">
			<div class="lm-field"><label>${__(
				"Search"
			)}</label><input class="lm-ref-filter" data-filter="search" placeholder="${__(
		"Enter code or description"
	)}"></div>
			<div class="lm-field compact"><label>${__(
				"Status"
			)}</label><select class="lm-ref-filter" data-filter="status"><option value="Active">${__(
		"Active"
	)}</option><option value="Inactive">${__("Inactive")}</option><option value="">${__(
		"All"
	)}</option></select></div>
			<button class="lm-btn primary lm-ref-search">${__("Search")}</button>
			<button class="lm-btn secondary lm-ref-reset">${__("Reset")}</button>
		</div></div></div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			config.title
		)} ${__("Register")}</div><span class="lm-muted lm-ref-count">${__(
		"Interactive Grid"
	)}</span></div><div class="lm-table-wrap"><table class="lm-table"><thead class="lm-ref-head"></thead><tbody class="lm-ref-body"><tr><td class="lm-muted">${__(
		"Loading…"
	)}</td></tr></tbody></table></div></div>
	</section>`;
}

function reference_drawer() {
	return `<aside class="lm-drawer lm-ref-drawer" tabindex="-1" role="dialog" aria-modal="true" aria-label="${__("Reference Record")}" aria-hidden="true" inert><div class="lm-drawer-head"><div><strong class="lm-drawer-title">${__(
		"Reference Record"
	)}</strong><div class="lm-muted lm-ref-subtitle">${__(
		"Create / Edit Reference Record"
	)}</div></div><button type="button" class="lm-close" aria-label="${__("Close")}">✕</button></div>
	<div class="lm-drawer-body">
		<div class="lm-notice lm-ref-form-notice lm-hidden"></div>
		<div class="lm-section-label">${__("Reference Details")}</div>
		<div class="lm-form-grid cols-2 lm-ref-fields"></div>
	</div>
	<div class="lm-drawer-actions"><div class="lm-mini-actions"><span class="lm-ref-transitions"></span><button class="lm-btn secondary lm-close">${__(
		"Cancel"
	)}</button><button class="lm-btn primary lm-ref-save">${__("Save")}</button></div></div></aside>`;
}

function load_reference($root, id) {
	const $page = $root.find(`#lm-${id}`);
	const args = { kind: id };
	$page.find(".lm-ref-filter").each(function () {
		if (this.value) args[this.dataset.filter] = this.value;
	});
	$page.find(".lm-ref-body").html(`<tr><td class="lm-muted">${__("Loading…")}</td></tr>`);
	frappe.call({
		method: "karyo.desk.loan_reference.register",
		args: args,
		freeze: false,
		callback: (response) => render_reference($root, id, response.message || {}),
		error: () =>
			$page
				.find(".lm-ref-body")
				.html(`<tr><td class="lm-muted">${__("This register could not be loaded.")}</td></tr>`),
	});
}

function render_reference($root, id, data) {
	const $page = $root.find(`#lm-${id}`);
	const columns = data.columns || [];
	const rows = data.rows || [];
	lm_set_currency(data.currency);
	$page.data("doctype", data.doctype || "");
	$page.find(".lm-ref-action-menu").toggle(data.permitted !== false);

	if (data.permitted === false) {
		$page.find(".lm-ref-head").empty();
		$page.find(".lm-ref-create").hide();
		$page
			.find(".lm-ref-body")
			.html(
				`<tr><td class="lm-muted">${frappe.utils.escape_html(
					data.message || __("You do not have permission to view this register.")
				)}</td></tr>`
			);
		$page.find(".lm-ref-count").text("");
		return;
	}

	$page.find(".lm-ref-create").toggle(Boolean(data.can_create));
	const $notice = $page.find(".lm-ref-notice");
	$notice.toggleClass("lm-hidden", !data.notice).text(data.notice || "");

	$page
		.find(".lm-ref-head")
		.html(
			`<tr>${columns
				.map((column) => `<th>${frappe.utils.escape_html(column.label)}</th>`)
				.join("")}<th>${__("Action")}</th></tr>`
		);
	$page
		.find(".lm-ref-body")
		.html(
			rows
				.map(
					(row) =>
						`<tr class="lm-ref-record" data-name="${frappe.utils.escape_html(row.name || "")}" tabindex="0">${columns
							.map((column, index) => `<td>${index === 0 ? `<a href="#" class="lm-ref-view" data-name="${frappe.utils.escape_html(row.name || "")}">${reference_cell(row[column.key], column.type)}</a>` : reference_cell(row[column.key], column.type)}</td>`)
                            .join("")}<td class="lm-row-actions"><button class="lm-btn small secondary lm-ref-edit" data-name="${frappe.utils.escape_html(row.name || "")}"${row.editable ? "" : " disabled"}>${__("Edit")}</button> <button type="button" class="lm-btn small secondary lm-delete-record" data-name="${frappe.utils.escape_html(row.name || "")}" data-doctype="${frappe.utils.escape_html(data.doctype)}"${frappe.model.can_delete(data.doctype) ? "" : " disabled"}>${__("Delete")}</button></td></tr>`
				)
				.join("") ||
				`<tr><td colspan="${columns.length + 1}" class="lm-muted">${__(
					"No records found"
				)}</td></tr>`
		);
	$page
		.find(".lm-ref-count")
		.text(rows.length ? __("Interactive Grid • {0} record(s)", [rows.length]) : __("Interactive Grid"));
}

function reference_cell(value, type) {
	if (value === null || value === undefined || value === "") return "—";
	if (type === "currency") return frappe.utils.escape_html(lm_money(value));
	if (type === "percent") return frappe.utils.escape_html(`${flt(value).toFixed(2)}%`);
	if (type === "rate") return frappe.utils.escape_html(flt(value).toFixed(2));
	if (type === "date") return frappe.utils.escape_html(frappe.datetime.str_to_user(value));
	return frappe.utils.escape_html(String(value));
}

function open_reference_drawer($root, id, name, view_only = false) {
	const $drawer = $root.find(".lm-ref-drawer").data({ kind: id, name: name || "" });
	lm_open_drawer_state($root, $drawer, document.activeElement);
	$drawer.find(".lm-ref-save").hide();
	$drawer.find(".lm-ref-transitions").empty();
	$drawer.find(".lm-ref-fields").html(`<div class="lm-muted">${__("Loading…")}</div>`);
	frappe.call({
		method: "karyo.desk.loan_reference.form",
		args: { kind: id, name: name || null },
		freeze: false,
		callback: (response) => render_reference_form($root, {...(response.message || {}), ...(view_only ? {editable: false} : {})}),
	});
}

function render_reference_form($root, data) {
	const $drawer = $root.find(".lm-ref-drawer");
	const fields = data.fields || [];
	const values = data.values || {};
	$drawer.find(".lm-drawer-title").text(data.title || __("Reference Record"));
	$drawer
		.find(".lm-ref-subtitle")
		.text(data.name ? `${data.name} · ${__(data.status || "Demo")}` : __("Create / Edit Reference Record"));

	// A record past approval is immutable, so the drawer says so and locks rather
	// than letting the save fail in validation.
	const message = data.reason || data.notice || "";
	$drawer
		.find(".lm-ref-form-notice")
		.toggleClass("lm-hidden", !message)
		.toggleClass("warn", Boolean(data.reason))
		.text(message);
	$drawer.find(".lm-ref-save").toggle(Boolean(data.editable));
	$drawer.find(".lm-ref-transitions").html(
		(data.transitions || [])
			.map((target) => `<button type="button" class="lm-btn secondary lm-ref-transition" data-target="${frappe.utils.escape_html(target)}">${__(target)}</button>`)
			.join("")
	);

	$drawer.find(".lm-ref-fields").html(
		fields
			.map((field) => reference_input(field, values[field.fieldname], data.editable, data.name))
			.join("")
	);
    fields.filter(field => field.fieldtype === "Table").forEach(field => {
        $drawer.find(`[data-table-field="${field.fieldname}"]`).data({spec: field, editable: data.editable});
    });
    mount_reference_links($drawer);
	sync_reference_dependencies($drawer, fields);
}

function sync_reference_dependencies($drawer, fields) {
	const refresh = () => fields.forEach((field) => {
		if (!field.depends_on_field) return;
		const source = $drawer.find(`[data-ref-field="${field.depends_on_field}"]`)[0];
		const visible = source?.dataset.type === "Check" ? source.checked : Boolean($(source).val());
		$drawer.find(`[data-ref-wrapper="${field.fieldname}"]`).toggle(Boolean(visible));
	});
	const sources = [...new Set(fields.map((field) => field.depends_on_field).filter(Boolean))];
	sources.forEach((fieldname) => $drawer.find(`[data-ref-field="${fieldname}"]`).on("change", refresh));
	refresh();
}

function reference_child_row(field, values, editable) {
	const orderButtons = editable && field.fieldname === "members"
		? `<button type="button" class="lm-btn secondary small lm-ref-move-up">${__("Move Up")}</button> <button type="button" class="lm-btn secondary small lm-ref-move-down">${__("Move Down")}</button> `
		: "";
    return `<div class="lm-ref-row"><div class="lm-form-grid cols-2">${field.fields.map(child =>
        reference_input(child, values[child.fieldname] ?? child.default, editable)
    ).join("")}</div>${editable ? `${orderButtons}<button type="button" class="lm-btn secondary small lm-ref-remove-row">${__("Remove")}</button>` : ""}</div>`;
}

function mount_reference_links($scope) {
    $scope.find(".lm-ref-link").each(function () {
        const $host = $(this);
        const control = frappe.ui.form.make_control({parent: this, only_input: true,
            df: {fieldtype: "Link", fieldname: this.dataset.linkField, options: this.dataset.options,
                reqd: cint(this.dataset.required), only_select: true}, render_input: true});
        control.set_input(this.dataset.value || "");
		if (this.dataset.accountCompanyField) {
			const companyField = this.dataset.accountCompanyField;
			control.get_query = () => {
				const $company = $scope.closest(".lm-ref-drawer").find(`[data-link-field="${companyField}"]`);
				const company = $company.data("control")?.get_value();
				return { filters: { ...(company ? { company } : {}), is_group: 0 } };
			};
		}
		const fixedFilters = this.dataset.linkFilters ? JSON.parse(this.dataset.linkFilters) : {};
		if (this.dataset.linkFilterField || Object.keys(fixedFilters).length) {
			const linkedField = this.dataset.linkFilterField;
			control.get_query = () => {
				const linkedValue = linkedField
					? $scope.closest(".lm-ref-drawer").find(`[data-link-field="${linkedField}"]`).data("control")?.get_value()
					: "";
				return {filters: {...fixedFilters, ...(linkedField && linkedValue ? {[linkedField]: linkedValue} : {})}};
			};
		}
        $host.data("control", control);
    });
}

function reference_values($scope) {
    const values = {};
    const own = function () { return $(this).closest(".lm-ref-row")[0] === ($scope.hasClass("lm-ref-row") ? $scope[0] : undefined); };
    $scope.find("[data-ref-field]").filter(own).each(function () {
        if ((this.disabled || this.readOnly) && !this.dataset.submitReadonly) return;
        values[this.dataset.refField] = this.dataset.type === "Check" ? (this.checked ? 1 : 0) : $(this).val();
    });
    $scope.find(".lm-ref-link").filter(own).each(function () {
        values[this.dataset.linkField] = $(this).data("control").get_value();
    });
    $scope.find(".lm-ref-table").each(function () {
        if (!$(this).data("editable")) return;
        values[this.dataset.tableField] = $(this).find(".lm-ref-row").map(function () { return reference_values($(this)); }).get();
    });
    return values;
}

function reference_input(field, value, editable, name) {
	const escape = frappe.utils.escape_html;
	const label = `<label class="${field.reqd ? "lm-req" : ""}">${escape(field.label)}</label>`;
	// loan_code names the document and the controller rejects changes to it, so it
	// locks once the record exists.
	const locked = !editable || field.read_only || (field.lock && name);
	const disabled = locked ? " disabled" : "";
	const readonly = locked ? " readonly" : "";
	const key = escape(field.fieldname);
	const wrapper = ` data-ref-wrapper="${key}"`;
	const submitReadonly = field.submit_readonly ? ' data-submit-readonly="1"' : "";
    if (field.fieldtype === "Table") {
        return `<div class="lm-ref-table" data-table-field="${key}"${wrapper}>${label}<div class="lm-ref-rows">${(value || []).map(row => reference_child_row(field, row, editable)).join("")}</div>${editable ? `<button type="button" class="lm-btn secondary small lm-ref-add-row">${escape(field.add_label || __("Add Row"))}</button>` : ""}</div>`;
    }
	if (field.fieldtype === "Link") {
		const accountCompany = field.account_company_field
			? ` data-account-company-field="${escape(field.account_company_field)}"`
			: "";
		const linkFilters = field.link_filters
			? ` data-link-filters="${escape(JSON.stringify(field.link_filters))}"`
			: "";
		const linkFilterField = field.link_filter_field
			? ` data-link-filter-field="${escape(field.link_filter_field)}"`
			: "";
		return `<div class="lm-field"${wrapper}>${label}${locked ? `<input type="text" readonly value="${escape(value || "")}">` : `<div class="lm-ref-link" data-link-field="${key}" data-options="${escape(field.options)}" data-required="${field.reqd || 0}" data-value="${escape(value || "")}"${accountCompany}${linkFilters}${linkFilterField}></div>`}</div>`;
    }


	if (field.fieldtype === "Check") {
		const checked = cint(value) ? " checked" : "";
		return `<div class="lm-check"${wrapper}><input type="checkbox" data-ref-field="${key}" data-type="Check"${checked}${disabled}${submitReadonly}><label>${escape(
			field.label
		)}</label></div>`;
	}
	if (field.fieldtype === "Select") {
		const options = (field.options || [])
			.map(
				(option) =>
					`<option value="${escape(option)}"${
						String(value || "") === String(option) ? " selected" : ""
					}>${escape(option || __("Not set"))}</option>`
			)
			.join("");
		return `<div class="lm-field"${wrapper}>${label}<select data-ref-field="${key}" data-type="Select"${disabled}${submitReadonly}>${options}</select></div>`;
	}
	if (field.fieldtype === "Small Text") {
		return `<div class="lm-field" style="grid-column:1/-1"${wrapper}>${label}<textarea data-ref-field="${key}" data-type="Small Text"${readonly}${submitReadonly}>${escape(
			value == null ? "" : String(value)
		)}</textarea></div>`;
	}
	const input_type =
		field.fieldtype === "Date"
			? "date"
			: ["Int", "Float", "Currency", "Percent"].includes(field.fieldtype)
			? "number"
			: "text";
	const step = input_type === "number" && field.fieldtype !== "Int" ? ' step="0.01"' : "";
	const hint = field.description
		? `<div class="lm-muted" style="margin-top:4px">${escape(field.description)}</div>`
		: "";
	return `<div class="lm-field"${wrapper}>${label}<input type="${input_type}"${step} data-ref-field="${key}" data-type="${escape(
		field.fieldtype
	)}" value="${escape(value == null ? "" : String(value))}"${readonly}${submitReadonly}>${hint}</div>`;
}

function save_reference($root) {
	const $drawer = $root.find(".lm-ref-drawer");
	const kind = $drawer.data("kind");
	const name = $drawer.data("name") || null;
	const values = reference_values($drawer);
	const $save = $drawer.find(".lm-ref-save").prop("disabled", true);
	frappe.call({
		method: "karyo.desk.loan_reference.save",
		args: { kind: kind, name: name, values: JSON.stringify(values) },
		freeze: true,
		freeze_message: __("Saving…"),
		callback: (response) => {
			const result = response.message || {};
			lm_toast($root, result.message || __("Record saved."));
			lm_close_drawers($root);
			load_reference($root, kind);
		},
		always: () => $save.prop("disabled", false),
	});
}

function transition_reference($root, target) {
	const $drawer = $root.find(".lm-ref-drawer");
	const kind = $drawer.data("kind");
	const name = $drawer.data("name");
	if (!kind || !name || !target) return;
	frappe.confirm(
		__("Move {0} to {1}?", [name, target]),
		() => {
			const $buttons = $drawer.find(".lm-ref-transition").prop("disabled", true);
			frappe.call({
				method: "karyo.desk.loan_reference.transition",
				args: { kind, name, target },
				freeze: true,
				freeze_message: __("Updating configuration status…"),
				callback: (response) => {
					const result = response.message || {};
					lm_toast($root, result.message || __("Configuration status updated."));
					load_reference($root, kind);
					lm_close_drawers($root);
					open_reference_drawer($root, kind, name);
				},
				always: () => $buttons.prop("disabled", false),
			});
		}
	);
}

// Saving IS the computation: Karyo Loan.validate() recalculates capital, interest,
// insurance and regenerates the schedule, so the drawer never computes anything
// itself. "Compute Loan" and "Process Schedule" save and then show the refreshed
// figures on the relevant tab.
function save_application($root, focus_tab) {
	const $drawer = $root.find(".lm-app-drawer");
	const loan = $drawer.data("loan");
	if (!loan) {
		lm_toast($root, __("Create the application in the full form first."));
		return;
	}
	const values = {};
	$drawer.find("[data-field][data-edit]").each(function () {
		if (this.readOnly) return;
		values[this.dataset.field] = this.value === "" ? null : this.value;
	});
	$drawer.find("[data-check-field]").each(function () {
		if (this.disabled) return;
		values[this.dataset.checkField] = this.checked ? 1 : 0;
	});
	const $purpose = $drawer.find('[data-edit-text="purpose"]');
	if (!$purpose.hasClass("lm-hidden")) values.purpose = $purpose.val();

	const $buttons = $drawer.find(".lm-app-save, .lm-app-compute, .lm-app-schedule");
	$buttons.prop("disabled", true);
	frappe.call({
		method: "karyo.desk.loan_management.save_application",
		args: { loan: loan, values: JSON.stringify(values) },
		freeze: true,
		freeze_message: __("Saving and recomputing…"),
		callback: (response) => {
			const result = response.message || {};
			lm_toast($root, result.message || __("Application saved."));
			// Re-read so the computation, insurance and schedule tabs show server values.
			frappe.call({
				method: "karyo.desk.loan_management.application_detail",
				args: { loan: loan },
				freeze: false,
				callback: (detail) => {
					render_application_detail($drawer, detail.message || {});
					if (focus_tab) {
						$drawer.find(`.lm-tab[data-tab="${focus_tab}"]`).trigger("click");
					}
				},
			});
			load_applications($root);
		},
		always: () => $buttons.prop("disabled", false),
	});
}

// --- Approval of Loans ------------------------------------------------------
// The client prototype hardcoded an Approve / Cancel pair. MBC drives approval
// from the real "Karyo Loan Approval" workflow, so the action buttons are built
// from whatever karyo.desk.loan_approval reports the current user may genuinely
// do to this document in its present state — never from a fixed list here.
//
// load_approval() is the single render entry point: it refreshes the filter
// lists and the retrieved application together, so a decision that moves a loan
// out of the workflow's actionable states is reflected immediately. The screen's
// own state (chosen employee, chosen loan, retrieved loan) lives in $page.data()
// so a re-render never loses the user's selection.
const LM_APPROVAL_PAGES = {
	approvals: { title: "Approval of Loans", crumb: "Approval of Loans" },
	committee: { title: "Loan Committee", crumb: "Loan Committee" },
};

function committee_page() {
 return `<section class="lm-page" id="lm-committee" data-txn="committee"><div class="lm-page-head"><div><h1>${__("Loan Committee")}</h1><div class="lm-crumb">LMS / ${__("Transactions")} / ${__("Loan Committee")}</div></div><div class="lm-toolbar"><button class="lm-btn secondary lm-committee-refresh">${__("Refresh")}</button></div></div><div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__("Applications Awaiting Committee Action")}</div><span class="lm-muted lm-committee-count"></span></div><div class="lm-card-body"><div class="lm-filters"><div class="lm-field"><label>${__("Search")}</label><input class="lm-committee-search" placeholder="${__("Loan number or employee")}"></div><div class="lm-field"><label>${__("Status")}</label><select class="lm-committee-status"><option value="">${__("All Committee Statuses")}</option>${["Loan Committee Scheduled","Under Loan Committee Review","Pending"].map(state=>`<option value="${state}">${__(state)}</option>`).join("")}</select></div></div><div class="lm-table-wrap"><table class="lm-table"><thead><tr>${["Loan Number","Employee Code","Employee Name","Status","Action"].map(label=>`<th>${__(label)}</th>`).join("")}</tr></thead><tbody class="lm-committee-list"></tbody></table></div></div></div></section>`;
}

async function load_committee($root) {
 const $page = $root.find("#lm-committee"), request = ($page.data("list-request") || 0) + 1;
 $page.data("list-request", request);
 try {
  const data = await frappe.xcall("karyo.desk.loan_approval.options", {committee_only:1});
  if ($page.data("list-request") !== request) return;
  if (data.permitted === false) {$page.find(".lm-committee-list").html(`<tr><td colspan="5">${frappe.utils.escape_html(data.message)}</td></tr>`);return;}
  const search = ($page.find(".lm-committee-search").val() || "").toLowerCase(), state = $page.find(".lm-committee-status").val();
  const rows = (data.loans || []).filter(row=>(!state || row.state===state) && `${row.value} ${row.employee} ${row.employee_name}`.toLowerCase().includes(search));
  const e=frappe.utils.escape_html;
  $page.find(".lm-committee-count").text(__("{0} applications",[rows.length]));
  $page.find(".lm-committee-list").html(rows.map(row=>`<tr><td><a href="#" class="lm-committee-view" data-loan="${e(row.value)}">${e(row.value)}</a></td><td>${e(row.employee||"")}</td><td>${e(row.employee_name||"")}</td><td><span class="lm-badge ${status_class(row.state)}">${e(row.state)}</span></td><td><button class="lm-btn small secondary lm-committee-view" data-loan="${e(row.value)}">${__("View")}</button></td></tr>`).join("") || `<tr><td colspan="5" class="lm-muted">${__("No applications awaiting committee action match these filters.")}</td></tr>`);
 } catch (_error) {$page.find(".lm-committee-list").html(`<tr><td colspan="5">${__("Unable to load committee applications. Refresh to retry.")}</td></tr>`);}
}

function approval_page(id) {
 if (id === "committee") return committee_page();
	const config = LM_APPROVAL_PAGES[id] || LM_APPROVAL_PAGES.approvals;
	return `<section class="lm-page" id="lm-${id}" data-txn="${id}">
		<div class="lm-page-head"><div><h1>${__(config.title)}</h1><div class="lm-crumb">LMS / ${__(
		"Transactions"
	)} / ${__(
		config.crumb
	)}</div></div><div class="lm-toolbar"><button class="lm-btn secondary lm-ap-history">${__(
		"Approval History"
	)}</button></div></div>
		<div class="lm-notice">${__("Approval is applied only when {0} is selected on the loan application.", [
			`<strong>${__("Approval by Committee")}</strong>`,
		])}</div>
		<div class="lm-notice warn lm-ap-alert lm-hidden"></div>
		${id === "committee" ? `<div class="lm-notice">${__("Select a loan to review its details, then open Loan Committee to start review, recommend, keep pending, reject or return it for rework. Completed decisions move to the next approval step.")}</div><div class="lm-card"><div class="lm-card-body lm-filters"><div class="lm-field"><label>${__("Committee Status")}</label><select class="lm-committee-status"><option value="">${__("All Pending Committee Loans")}</option>${["Loan Committee Scheduled", "Under Loan Committee Review", "Pending"].map(state => `<option value="${state}">${__(state)}</option>`).join("")}</select></div><button class="lm-btn secondary lm-committee-refresh">${__("Refresh Queue")}</button><button class="lm-btn secondary lm-committee-next">${__("Next Loan")}</button><span class="lm-muted lm-committee-count"></span></div></div>` : ""}
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Retrieve Loan Application"
		)}</div></div><div class="lm-card-body"><div class="lm-filters">
			<div class="lm-field"><label>${__(
				"Employee Code"
			)}</label><select class="lm-ap-filter" data-filter="employee"></select></div>
			<div class="lm-field"><label>${__(
				"Loan Number"
			)}</label><select class="lm-ap-filter" data-filter="loan"></select></div>
			<button class="lm-btn primary lm-ap-retrieve">${__("Retrieve")}</button>
		</div></div></div>
		<div class="lm-grid-2">
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Loan Header"
			)}</div><span class="lm-badge gray lm-ap-state">${__("Not retrieved")}</span></div>
			<div class="lm-card-body"><div class="lm-form-grid cols-2 lm-ap-header"><div class="lm-muted">${__(
				"Retrieve a loan application to view its header."
			)}</div></div></div></div>
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Repayment & Disbursement"
			)}</div></div><div class="lm-card-body"><div class="lm-summary-box lm-ap-repayment"></div></div></div>
		</div>
		<div class="lm-card lm-ap-policy-card lm-hidden"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Personal Loan Policy Rules"
		)}</div></div><div class="lm-card-body lm-ap-policy"></div></div>
		<div class="lm-card lm-ap-chain-card lm-hidden"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Approval Chain"
		)}</div></div><div class="lm-card-body lm-ap-chain"></div></div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Approval Decision"
		)}</div></div><div class="lm-card-body"><div class="lm-form-grid cols-2">
			<div class="lm-field"><label class="lm-req">${__(
				"Remarks"
			)}</label><textarea class="lm-ap-remarks" placeholder="${__(
		"Enter approval or cancellation remarks"
	)}"></textarea></div>
			<div><div class="lm-section-label">${__(
				"Action"
			)}</div><div class="lm-toolbar lm-ap-actions"><span class="lm-muted">${__(
		"Retrieve a loan application to see the actions available to you."
	)}</span></div><p class="lm-muted">${__(
		"The action records user, date/time and remarks in the audit trail."
	)}</p></div>
		</div></div></div>
	</section>`;
}

function load_approval($root, id) {
	if (id === "committee") return load_committee($root);
	const $page = $root.find(`#lm-${id || "approvals"}`);
	const escape = frappe.utils.escape_html;
	const request = ($page.data("approval-request") || 0) + 1;
	$page.data("approval-request", request);

	function alert_note(message) {
		$page
			.find(".lm-ap-alert")
			.toggleClass("lm-hidden", !message)
			.text(message || "");
	}

	function header_value(item) {
		if (item.value === null || item.value === undefined || item.value === "") return "—";
		if (item.type === "currency") return lm_money(item.value);
		if (item.type === "months") return __("{0} months", [item.value]);
		if (item.type === "years") return __("{0} years", [item.value]);
		if (item.type === "percent") return `${flt(item.value).toFixed(2)}%`;
		return String(item.value);
	}

	function set_state(label, css) {
		$page
			.find(".lm-ap-state")
			.attr("class", `lm-badge lm-ap-state ${css}`)
			.text(label);
	}

	function render_blank(message) {
		$page
			.find(".lm-ap-header")
			.html(
				`<div class="lm-muted">${escape(
					message || __("Retrieve a loan application to view its header.")
				)}</div>`
			);
		$page.find(".lm-ap-repayment").empty();
		set_state(__("Not retrieved"), "gray");
		$page
			.find(".lm-ap-actions")
			.html(
				`<span class="lm-muted">${__(
					"Retrieve a loan application to see the actions available to you."
				)}</span>`
			);
	}

	function render_detail(data) {
		$page.data("approval-detail", data);
		lm_set_currency(data.currency);
		if (data.permitted === false) {
			$page.data("retrieved", "");
			render_blank(data.message);
			set_state(__("Not available"), "gray");
			alert_note(data.message);
			return;
		}
		alert_note(data.notice);
		set_state(data.state || __("Not retrieved"), data.state ? status_class(data.state) : "gray");
		$page.find(".lm-ap-header").html(
			(data.header || [])
				.map(
					(item) =>
						`<div class="lm-field"><label>${escape(
							item.label
						)}</label><input readonly value="${escape(header_value(item))}"></div>`
				)
				.join("")
		);
		$page.find(".lm-ap-repayment").html(
			(data.repayment || [])
				.map(
					(row) =>
						`<div class="lm-summary-row ${row.total ? "total" : ""}"><span>${escape(
							row.label
						)}</span><strong>${escape(lm_money(row.value))}</strong></div>`
				)
				.join("")
		);
		const rules = data.policy_rules || [];
		$page.find(".lm-ap-policy-card").toggleClass("lm-hidden", !rules.length);
		$page.find(".lm-ap-policy").html(rules.map((row) =>
			`<div class="lm-notice ${row.applicable ? "good" : ""}"><strong>${escape(row.policy_reference)} · ${escape(row.loan_area)}</strong><br>${escape(row.rule_text)}${row.applicable ? `<br><strong>${__("Applicable to this employee")}</strong>` : ""}</div>`
		).join(""));
		const chain = data.approval_chain || {}, steps = chain.steps || [];
		$page.find(".lm-ap-chain-card").toggleClass("lm-hidden", !steps.length);
		$page.find(".lm-ap-chain").html(steps.map((row) => {
			const current = chain.current && chain.current.name === row.name;
			return `<div class="lm-notice ${row.status === "Approved" ? "good" : current ? "warn" : ""}"><strong>${escape(row.approval_sequence)}. ${escape(row.member_name || row.approver_user)}</strong> · ${escape(row.approval_level)}<br>${escape(row.designation || row.email || "")}<br><span class="lm-badge ${row.status === "Approved" ? "green" : current ? "yellow" : "gray"}">${escape(current ? __("Current approver") : __(row.status || "Pending"))}</span></div>`;
		}).join(""));
		$page.find(".lm-ap-actions").html(
			(data.actions || [])
				.map(
					(action) =>
						`<button class="lm-btn ${escape(
							action.style || "secondary"
						)} lm-ap-act" data-action="${escape(action.action)}" title="${escape(
							__("Moves to {0}", [action.next_state || ""])
						)}">${escape(action.action)}</button>`
				)
				.join("") ||
				`<span class="lm-muted">${__(
					"No approval action is available to you for this loan."
				)}</span>`
		);
		if (data.can_open_committee) {
			$page.find(".lm-ap-actions").html(`<button class="lm-btn primary lm-ap-committee">${__("Open Loan Committee")}</button>`);
		}
	}

	function populate(data) {
		const status = $page.find(".lm-committee-status").val();
		const loans = (data.loans || []).filter(row => !status || row.state === status);
		$page.find(".lm-committee-count").text(__("{0} loan(s) awaiting committee action", [loans.length]));
		const employee = $page.data("employee") || "";
		const $employee = $page.find('[data-filter="employee"]');
		$employee.html(
			`<option value="">${__("All Employees")}</option>` +
				(data.employees || [])
					.map((row) => `<option value="${escape(row.value)}">${escape(row.label)}</option>`)
					.join("")
		);
		$employee.val(employee);
		// The employee filter is applied here rather than by hiding options, because
		// a hidden-but-selected option still submits on some browsers.
		const scoped = employee ? loans.filter((row) => row.employee === employee) : loans;
		const $loan = $page.find('[data-filter="loan"]');
		$loan.html(
			scoped
				.map(
					(row) =>
						`<option value="${escape(row.value)}">${escape(row.label)} — ${escape(
							row.state || ""
						)}</option>`
				)
				.join("") || `<option value="">${__("No loan awaiting approval")}</option>`
		);
		const wanted = $page.data("loan") || "";
		const selected = scoped.some((row) => row.value === wanted)
			? wanted
			: scoped.length
			? scoped[0].value
			: "";
		$loan.val(selected);
		$page.data("loan", selected);
		// First visit opens on the selected application, as the prototype does; after
		// that the Retrieve button governs which loan is shown.
		if ($page.data("retrieved") === undefined) $page.data("retrieved", selected);
	}

	frappe.call({
		method: "karyo.desk.loan_approval.options",
		args: {committee_only: id === "committee" ? 1 : 0},
		freeze: false,
		callback: (response) => {
			if ($page.data("approval-request") !== request) return;
			const data = response.message || {};
			if (data.permitted === false) {
				$page.find(".lm-ap-filter, .lm-ap-retrieve").prop("disabled", true);
				render_blank(data.message);
				alert_note(data.message);
				return;
			}
			lm_set_currency(data.currency);
			$page.data("can-history", Boolean(data.can_read_history));
			populate(data);
			const loan = $page.data("retrieved") || "";
			if (!loan) {
				alert_note("");
				render_blank();
				return;
			}
			frappe.call({
				method: "karyo.desk.loan_approval.detail",
				args: { loan: loan },
				freeze: false,
				callback: (detail_response) => {
					if ($page.data("approval-request") === request) render_detail(detail_response.message || {});
				},
				error: () => {
					render_blank();
					alert_note(__("This loan application could not be loaded."));
				},
			});
		},
		error: () => {
			render_blank();
			alert_note(__("The approval screen could not be loaded."));
		},
	});
}

function wire_approval($root) {
	const page_of = (element) => $(element).closest(".lm-page");
	const id_of = ($page) => $page.data("txn") || "approvals";
	$root.on("click", ".lm-drawer-committee", function () {
		const loan = $root.find(".lm-app-drawer").data("loan");
		if (!loan) return;
		$root.find("#lm-committee").data({loan, retrieved: loan});
		lm_close_drawers($root);
		frappe.set_route("loan-management", "committee").then(() => load_approval($root, "committee"));
	});
	$root.on("input", ".lm-committee-search", function () {clearTimeout(this.searchTimer);this.searchTimer=setTimeout(()=>load_committee($root),250);});
	$root.on("click", ".lm-committee-view", function (event) {
		event.preventDefault(); const $page=page_of(this); $page.data("retrieved",this.dataset.loan);
		const $trigger=$('<button class="lm-ap-committee" hidden></button>').appendTo($page);$trigger.trigger("click");$trigger.remove();
	});
	$root.on("change", ".lm-committee-status", function () {
		const $page = page_of(this);
		$page.removeData("retrieved").data("loan", "");
		load_approval($root, "committee");
	});
	$root.on("click", ".lm-committee-refresh", () => load_approval($root, "committee"));
	$root.on("click", ".lm-committee-next", function () {
		const $page = page_of(this), select = $page.find('[data-filter="loan"]')[0];
		if (!select.options.length || !select.value) return;
		select.selectedIndex = (select.selectedIndex + 1) % select.options.length;
		$page.data({loan: select.value, retrieved: select.value});
		$page.find(".lm-ap-remarks").val("");
		load_approval($root, "committee");
	});
	$root.on("click", ".lm-ap-committee", async function () {
		const $page = page_of(this), loan = $page.data("retrieved");
		const latest = await frappe.xcall("karyo.desk.loan_approval.detail", {loan});
		if (latest.permitted === false) {frappe.msgprint(latest.message);return;}
		const dialog = new frappe.ui.Dialog({title: __("Loan Committee"), fields: [
			{fieldtype: "Data", fieldname: "loan", label: __("Loan Number"), read_only: 1, default: loan},
			{fieldtype: "Data", fieldname: "state", label: __("Current Step"), read_only: 1},
			{fieldtype: "Date", fieldname: "committee_date", label: __("Committee Date"), reqd: 1},
			{fieldtype: "Select", fieldname: "decision", label: __("Decision / Status Change"), options: [], reqd: 1},
			{fieldtype: "Small Text", fieldname: "remarks", label: __("Comments"), reqd: 1},
			{fieldtype: "HTML", fieldname: "actions"}
		]});
		dialog.$wrapper.addClass("loan-application-drawer loan-committee-drawer");
		const $body = dialog.$wrapper.find(".modal-body");
		const $panel = $('<div class="loan-application-panel"><h5></h5><div class="loan-application-grid"></div></div>');
		$panel.find("h5").text(__("Committee & Approval"));
		for (const field of ["loan", "state", "committee_date", "decision", "remarks"]) {
			$panel.find(".loan-application-grid").append(dialog.fields_dict[field].$wrapper.detach());
		}
		$panel.append(dialog.fields_dict.actions.$wrapper.detach());
		$body.append($panel);
		// Render the decision menu inside the drawer, independent of the browser's native popup.
		const decisionControl = dialog.fields_dict.decision;
		decisionControl.$input.hide().attr("aria-hidden", "true").attr("tabindex", "-1");
		decisionControl.$wrapper.find('.select-icon').hide();
		const picker = $('<div style="position:relative;width:100%"><button type="button" class="form-control" aria-haspopup="listbox" aria-expanded="false" style="text-align:left;display:flex;justify-content:space-between"><span></span><span aria-hidden="true">▾</span></button><div role="listbox" aria-label="Decision / Status Change" hidden style="position:absolute;top:100%;left:0;right:0;z-index:10;background:white;border:1px solid #b9cbd9;border-radius:5px;padding:4px;box-shadow:0 4px 12px #0002"></div></div>');
		decisionControl.$input.after(picker);
		const toggle = picker.children('button'), menu = picker.children('[role=listbox]');
		const closePicker = () => {menu.prop('hidden',true);toggle.attr('aria-expanded','false');};
		toggle.on('click',()=>{const open=menu.prop('hidden');menu.prop('hidden',!open);toggle.attr('aria-expanded',String(open));if(open)menu.find('button').first().trigger('focus');});
		picker.on('keydown', e => {
			const buttons=menu.find('button'), index=buttons.index(document.activeElement);
			if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closePicker();toggle.trigger('focus');}
			if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();menu.prop('hidden',false);toggle.attr('aria-expanded','true');buttons.eq((index+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length).trigger('focus');}
		});
		picker.on('focusout',()=>setTimeout(()=>{if(!picker[0].contains(document.activeElement))closePicker();},0));
		const syncPicker = () => {
			toggle.find('span').first().text(dialog.get_value('decision') || __('Select a decision'));
			menu.find('button').each((_,el)=>$(el).attr('aria-selected',String(el.dataset.value===dialog.get_value('decision'))));
			dialog.get_primary_btn().prop('disabled',!dialog.get_value('decision'));
		};
		const render = data => {
			dialog.set_value("state", data.state);
			dialog.set_value("committee_date", data.decision?.committee_date || frappe.datetime.get_today());
			const $actions = dialog.fields_dict.actions.$wrapper;
			$actions.html(`<p class="text-muted">${frappe.utils.escape_html(data.notice || __("Choose a decision and enter comments, then click Update."))}</p>`);
			$('<p class="text-muted small">').text(data.agreement?.signed_on?__('Employee agreement signature verified. Final approval will issue the retained agreement.'):__('The employee must review and sign the agreement in My Loans before final approval.')).appendTo($actions);
			if(!data.agreement?.issued_on&&!data.agreement?.signed_on&&frappe.model.can_write('Karyo Loan'))$('<button type="button" class="lm-btn small secondary">').text(__('Add Agreement')).on('click',()=>karyo.loan_ui.agreement_admin(loan)).appendTo($actions);
			if(data.agreement?.available)$('<button type="button" class="lm-btn small secondary">').text(__('View Agreement')).on('click',()=>karyo.loan_ui.agreement(loan)).appendTo($actions);
			const decisionActions = (data.actions || []).filter(row=>["Approve","Recommend","Keep Pending","Reject","Return for Rework","Send for MD Approval"].includes(row.action));
			dialog.set_df_property("decision", "options", decisionActions.map(row=>({value:row.action,label:__(row.action)})));
			dialog.set_value("decision", "");
			menu.empty();
			for (const row of decisionActions) {
				$('<button type="button" role="option" class="btn btn-default" style="display:block;width:100%;text-align:left;margin:2px 0"></button>').text(__(row.action)).attr('data-value',row.action).appendTo(menu).on('click',async()=>{await dialog.set_value('decision',row.action);syncPicker();closePicker();toggle.trigger('focus');});
			}
			toggle.prop('disabled',!menu.children().length);
			syncPicker();
			dialog.set_primary_action(__("Update"), async () => {
				const values = dialog.get_values(); if (!values) return;
				const $button = dialog.get_primary_btn().prop("disabled", true);
				try {
					const result = await frappe.xcall("karyo.desk.loan_approval.act", {loan, action:values.decision, remarks:values.remarks, committee_date:values.committee_date});
					if (result.permitted === false) {frappe.msgprint(result.message);return;}
					frappe.show_alert({message:result.message,indicator:"green"});
					load_approval($root,id_of($page));
					if (["Loan Committee Scheduled","Under Loan Committee Review","Pending"].includes(result.state)) render(result.detail); else dialog.hide();
				} catch (_error) { /* Retain comments so validation blockers can be corrected. */ }
				finally {$button.prop("disabled", !dialog.get_value("decision"));}
			});
			dialog.get_primary_btn().prop("disabled", !dialog.get_value("decision"));

		};
		render(latest);
		dialog.show();
	});

	$root.on("change", '.lm-ap-filter[data-filter="employee"]', function () {
		const $page = page_of(this);
		$page.data({ employee: this.value, loan: "" });
		if (id_of($page) === "committee") $page.removeData("retrieved");
		load_approval($root, id_of($page));
	});
	$root.on("change", '.lm-ap-filter[data-filter="loan"]', function () {
		const $page = page_of(this);
		$page.data("loan", this.value);
		if (id_of($page) === "committee") {
			$page.data("retrieved", this.value).find(".lm-ap-remarks").val("");
			load_approval($root, "committee");
		}
	});
	$root.on("click", ".lm-ap-retrieve", function () {
		const $page = page_of(this);
		const loan = $page.find('[data-filter="loan"]').val();
		if (!loan) {
			lm_toast($root, __("Select a loan number to retrieve."));
			return;
		}
		$page.data({ loan: loan, retrieved: loan });
		$page.find(".lm-ap-remarks").val("");
		load_approval($root, id_of($page));
		lm_toast($root, __("Loan application retrieved."));
	});
	$root.on("click", ".lm-ap-history", function () {
		const $page = page_of(this);
		if (!$page.data("can-history")) {
			lm_toast($root, __("You do not have permission to view the approval history."));
			return;
		}
		const loan = $page.data("retrieved");
		if (!loan) {
			lm_toast($root, __("Retrieve a loan application first."));
			return;
		}
		frappe.set_route("List", "Karyo Loan History", { loan: loan });
	});
	$root.on("click", ".lm-ap-act", function () {
		const $page = page_of(this);
		const loan = $page.data("retrieved");
		const action = this.dataset.action;
		const remarks = ($page.find(".lm-ap-remarks").val() || "").trim();
		if (!loan) {
			lm_toast($root, __("Retrieve a loan application first."));
			return;
		}
		// The prototype refuses an empty remark and the server enforces it too, so
		// this check only spares the round trip.
		if (!remarks) {
			lm_toast($root, __("Remarks are required."));
			return;
		}
		const $buttons = $page.find(".lm-ap-act").prop("disabled", true);
		frappe.confirm(
			__("Apply {0} to {1}?", [
				frappe.utils.escape_html(action),
				frappe.utils.escape_html(loan),
			]),
			() =>
				frappe.call({
					method: "karyo.desk.loan_approval.act",
					args: { loan: loan, action: action, remarks: remarks },
					freeze: true,
					freeze_message: __("Recording decision…"),
					callback: (response) => {
						const result = response.message || {};
						lm_toast($root, result.message || __("Decision recorded."));
						if (result.permitted !== false) $page.find(".lm-ap-remarks").val("");
						load_approval($root, id_of($page));
					},
					always: () => $buttons.prop("disabled", false),
				}),
			() => $buttons.prop("disabled", false)
		);
	});
}

// --- Servicing screens ------------------------------------------------------
// The client prototype's two transaction screens. Both are views over a
// submittable doctype — Karyo Loan Settlement and Karyo Loan Recast — so every
// figure shown here is computed by karyo.desk.loan_servicing running the real
// controller on an unsaved document. The prototype's inline formulas are
// deliberately not ported: nothing on these screens is calculated in the browser.
const LM_SERVICING_PAGES = {
	refund: { title: "Refund / Settlement", crumb: "Refund or Recast Loans" },
	advance: { title: "Advance Payment / Change in Period", crumb: "Advance Payment / Change in Period" },
};

function servicing_page(id) {
	const config = LM_SERVICING_PAGES[id];
	// The two screens share the prototype's field furniture, so the markup is built
	// from the same three helpers and only the layout differs.
	const field = (label, control, required, wide) =>
		`<div class="lm-field"${wide ? ' style="grid-column:1/-1"' : ""}><label class="${
			required ? "lm-req" : ""
		}">${__(label)}</label>${control}</div>`;
	const output = (label, key) =>
		field(label, `<input data-out="${key}" readonly value="—">`);
	const select = (key, extra) =>
		`<select data-field="${key}" class="${extra || ""}"></select>`;

	const head = (toolbar) =>
		`<div class="lm-page-head"><div><h1>${__(config.title)}</h1><div class="lm-crumb">LMS / ${__(
			"Transactions"
		)} / ${__(config.crumb)}</div></div>${toolbar || ""}</div>`;
	const message = `<div class="lm-notice warn lm-sv-message lm-hidden"></div>`;

	if (id === "refund") {
		return `<section class="lm-page" id="lm-refund" data-txn="refund">
			${head("")}
			<div class="lm-notice warn">${__(
				"MBC processing uses <strong>Refund / full settlement</strong>. Recast can remain configurable but is not applied unless approved."
			)}</div>
			<div class="lm-notice warn lm-sv-mode-note lm-hidden"></div>
			${message}
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Loan Selection"
			)}</div></div><div class="lm-card-body"><div class="lm-form-grid">
				${field("Employee Code", select("employee", "lm-sv-employee"), true)}
				${field("Loan Number", select("loan", "lm-sv-input"), true)}
				${field("Refund / Recast", select("mode", "lm-sv-mode"))}
				${field(
					"Date of Refund",
					`<input type="date" data-field="refund_date" class="lm-sv-input">`
				)}
			</div></div></div>
			<div class="lm-grid-2">
				<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
					"Outstanding Loan Details"
				)}</div></div><div class="lm-card-body"><div class="lm-form-grid cols-2">
					${output("Capital Due", "capital_due")}
					${output("Interest Due", "interest_due")}
					${output("Insurance Due", "insurance_due")}
					${output("Total Balance Due", "total_balance_due")}
					${output("Remaining Instalments", "remaining_instalments")}
					<div class="lm-check"><input type="checkbox" data-field="ewf_waive_interest" class="lm-sv-input"><label>${__(
						"EWF - waive interest"
					)}</label></div>
				</div></div></div>
				<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
					"Settlement Details"
				)}</div></div><div class="lm-card-body"><div class="lm-form-grid cols-2">
					${field("Type of Payment", select("payment_type", "lm-sv-payment-type"), true)}
					<div class="lm-field lm-sv-cheque"><label class="lm-req">${__(
						"Cheque Number"
					)}</label><input data-field="cheque_no"></div>
					${field("Remarks", `<textarea data-field="remarks"></textarea>`, false, true)}
				</div><div class="lm-separator"></div><button class="lm-btn danger lm-sv-settle">${__(
			"Process Full Settlement"
		)}</button></div></div>
			</div>
		</section>`;
	}

	return `<section class="lm-page" id="lm-advance" data-txn="advance">
		${head(
			`<div class="lm-toolbar"><button class="lm-btn secondary" data-page="history">${__(
				"View Loan History"
			)}</button></div>`
		)}
		${message}
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Loan Details"
		)}</div></div><div class="lm-card-body"><div class="lm-form-grid">
			${field("Employee Code", select("employee", "lm-sv-employee"), true)}
			${field("Loan Number", select("loan", "lm-sv-input"), true)}
			${output("Approved Amount", "approved_amount")}
			${output("Interest Rate", "interest_rate")}
			${field("Capital / Both", select("component", "lm-sv-input"))}
			${field(
				"Effective Date",
				`<input type="date" data-field="effective_date" class="lm-sv-input">`,
				true
			)}
			${field("Payment / Refund", select("direction", "lm-sv-input"))}
			${output("Remaining Duration", "remaining_duration")}
		</div></div></div>
		<div class="lm-grid-2">
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Outstanding as at Effective Date"
			)}</div></div><div class="lm-card-body"><div class="lm-summary-box">
				<div class="lm-summary-row"><span>${__(
					"Outstanding Capital"
				)}</span><strong data-out="outstanding_capital">—</strong></div>
				<div class="lm-summary-row"><span>${__(
					"Outstanding Interest"
				)}</span><strong data-out="outstanding_interest">—</strong></div>
				<div class="lm-summary-row total"><span>${__(
					"Total Outstanding"
				)}</span><strong data-out="outstanding_total">—</strong></div>
			</div></div></div>
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Re-computation Input"
			)}</div></div><div class="lm-card-body"><div class="lm-form-grid cols-2">
				${field(
					"Advance Payment",
					`<input type="number" step="0.01" data-field="advance_payment" value="0">`,
					true
				)}
				${field("New Duration", `<input type="number" data-field="new_period">`, true)}
				${field("Remarks", `<textarea data-field="remarks"></textarea>`, false, true)}
			</div><button class="lm-btn primary lm-sv-process">${__("PROCESS")}</button></div></div>
		</div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Re-computation Result"
		)}</div><span class="lm-badge info">${__(
		"Preview"
	)}</span></div><div class="lm-card-body"><div class="lm-form-grid">
			${output("New Outstanding Capital", "new_outstanding_capital")}
			${output("New Outstanding Balance", "new_outstanding_balance")}
			${output("New Monthly Capital Refund", "monthly_capital")}
			${output("New Monthly Interest Refund", "monthly_interest")}
		</div><div class="lm-separator"></div><button class="lm-btn good lm-sv-confirm">${__(
		"Confirm & Update Schedule"
	)}</button></div></div>
	</section>`;
}

function load_servicing($root, id) {
	const $page = $root.find(`#lm-${id}`);
	const escape = frappe.utils.escape_html;
	// Employee, loan and Select choices are the same for both screens, so they are
	// fetched once and cached on the page root rather than per screen.
	const options = $root.data("lm-servicing-options");
	if (!options) {
		frappe.call({
			method: "karyo.desk.loan_servicing.options",
			freeze: false,
			callback: (response) => {
				$root.data("lm-servicing-options", response.message || { employees: [], loans: [] });
				load_servicing($root, id);
			},
			error: () => notice(__("This screen could not be loaded.")),
		});
		return;
	}

	function notice(text) {
		$page.find(".lm-sv-message").toggleClass("lm-hidden", !text).text(text || "");
	}
	function set_out(key, value) {
		$page.find(`[data-out="${key}"]`).each(function () {
			if (this.tagName === "INPUT") $(this).val(value);
			else $(this).text(value);
		});
	}
	function fill(selector, values, selected) {
		const $select = $page.find(selector);
		const current = selected || $select.val();
		$select.html(
			(values || [])
				.map(
					(row) =>
						`<option value="${escape(row.value)}">${escape(row.label)}</option>`
				)
				.join("")
		);
		if (current) $select.val(current);
	}
	function loans_for(employee) {
		return (options.loans || [])
			.filter((row) => !employee || row.employee === employee)
			.map((row) => ({ value: row.value, label: row.label }));
	}

	lm_set_currency(options.currency);
	if (options.permitted === false) {
		notice(options.message || __("You do not have permission to service loans."));
		$page.find(".lm-sv-settle, .lm-sv-process, .lm-sv-confirm").addClass("lm-hidden");
		return;
	}

	if (!$page.data("ready")) {
		$page.data("ready", true);
		fill('[data-field="employee"]', options.employees || []);
		fill(
			'[data-field="payment_type"]',
			(options.payment_types || []).map((value) => ({ value: value, label: value }))
		);
		fill(
			'[data-field="direction"]',
			(options.directions || []).map((value) => ({ value: value, label: value }))
		);
		fill(
			'[data-field="component"]',
			(options.components || []).map((value) => ({ value: value, label: value }))
		);
		// The prototype's Refund / Recast switch: MBC processes a full settlement, so
		// choosing Recast points at the Advance Payment screen instead of settling.
		fill(
			'[data-field="mode"]',
			[
				{ value: "Refund", label: __("Refund") },
				{ value: "Recast", label: __("Recast") },
			]
		);
		$page.find('[data-field="refund_date"], [data-field="effective_date"]').val(options.today || "");
	}
	const employee = $page.find('[data-field="employee"]').val() || "";
	const available = loans_for(employee);
	if (!$page.find('[data-field="loan"] option').length || $page.data("loans-for") !== employee) {
		$page.data("loans-for", employee);
		fill('[data-field="loan"]', available, available.length ? available[0].value : "");
	}
	const loan = $page.find('[data-field="loan"]').val() || "";
	// With nothing to act on every action is inert; each render then re-states the
	// button it owns from what the server allowed.
	$page.find(".lm-sv-settle, .lm-sv-process, .lm-sv-confirm").prop("disabled", !loan);
	if (!loan) {
		notice(__("No active loan is available for servicing."));
		return;
	}

	if (id === "refund") {
		frappe.call({
			method: "karyo.desk.loan_servicing.settlement_preview",
			args: {
				loan: loan,
				refund_date: $page.find('[data-field="refund_date"]').val() || null,
				ewf_waive_interest: $page.find('[data-field="ewf_waive_interest"]').is(":checked") ? 1 : 0,
			},
			freeze: false,
			callback: (response) => render_refund(response.message || {}),
			error: () => notice(__("The outstanding position could not be loaded.")),
		});
		return;
	}

	const computed = Boolean($page.data("compute"));
	frappe.call({
		method: "karyo.desk.loan_servicing.recast_preview",
		args: {
			loan: loan,
			effective_date: $page.find('[data-field="effective_date"]').val() || null,
			component: $page.find('[data-field="component"]').val() || null,
			direction: $page.find('[data-field="direction"]').val() || null,
			advance_payment: computed ? $page.find('[data-field="advance_payment"]').val() || 0 : 0,
			new_period: computed ? $page.find('[data-field="new_period"]').val() || 0 : 0,
		},
		freeze: false,
		callback: (response) => render_advance(response.message || {}, computed),
		error: () => notice(__("The outstanding position could not be loaded.")),
	});

	function render_refund(data) {
		lm_set_currency(data.currency);
		if (data.permitted === false) {
			notice(data.message || __("You do not have permission to view settlements."));
			$page.find(".lm-sv-settle").prop("disabled", true);
			return;
		}
		const figures = data.figures || {};
		set_out("capital_due", lm_money(figures.capital_due));
		set_out("interest_due", lm_money(figures.interest_due));
		set_out("insurance_due", lm_money(figures.insurance_due));
		set_out("total_balance_due", lm_money(figures.total_balance_due));
		set_out("remaining_instalments", figures.remaining_instalments == null ? "—" : figures.remaining_instalments);
		// The server refuses an unauthorised EWF waiver and returns the unwaived
		// position instead, so the checkbox follows what was actually computed.
		$page
			.find('[data-field="ewf_waive_interest"]')
			.prop("checked", cint(data.ewf_waive_interest) === 1);
		notice(data.waiver_message || data.message || "");
		$page.data("blocked", Boolean(data.blocked));
		$page.find(".lm-sv-settle").toggleClass("lm-hidden", !data.can_settle);
		refresh_mode();
	}

	function render_advance(data, computed) {
		lm_set_currency(data.currency);
		if (data.permitted === false) {
			notice(data.message || __("You do not have permission to view recasts."));
			$page.find(".lm-sv-process, .lm-sv-confirm").prop("disabled", true);
			return;
		}
		const record = data.loan || {};
		const outstanding = data.outstanding || {};
		set_out("approved_amount", lm_money(record.approved_amount));
		set_out("interest_rate", `${flt(record.interest_rate).toFixed(2)}%`);
		set_out("remaining_duration", __("{0} months", [cint(record.remaining_instalments)]));
		set_out("outstanding_capital", lm_money(outstanding.capital));
		set_out("outstanding_interest", lm_money(outstanding.interest));
		set_out("outstanding_total", lm_money(outstanding.total));
		if (!computed && $page.data("prefilled-loan") !== record.name) {
			// A fresh loan selection starts from its own remaining duration, the way the
			// prototype pre-fills the revised period.
			$page.data("prefilled-loan", record.name);
			$page.find('[data-field="new_period"]').val(cint(record.remaining_instalments) || "");
		}
		const figures = data.figures || {};
		set_out("new_outstanding_capital", computed ? lm_money(figures.new_outstanding_capital) : "—");
		set_out("new_outstanding_balance", computed ? lm_money(figures.new_outstanding_balance) : "—");
		set_out("monthly_capital", computed ? lm_money(figures.monthly_capital) : "—");
		set_out("monthly_interest", computed ? lm_money(figures.monthly_interest) : "—");
		notice(data.message || "");
		$page.find(".lm-sv-confirm").toggleClass("lm-hidden", !data.can_recast);
		$page.find(".lm-sv-confirm").prop("disabled", !(data.computed && !data.blocked && data.can_recast));
	}

	function refresh_mode() {
		const recast = $page.find('[data-field="mode"]').val() === "Recast";
		$page
			.find(".lm-sv-mode-note")
			.toggleClass("lm-hidden", !recast)
			.text(
				recast
					? __(
							"Recast is not applied unless approved. Use Advance Payment / Change in Period to recompute a loan."
					  )
					: ""
			);
		$page.find(".lm-sv-settle").prop("disabled", recast || Boolean($page.data("blocked")));
	}
}

function wire_servicing($root) {
	// Changing the employee rebuilds the loan list for that employee, then reloads.
	$root.on("change", ".lm-sv-employee", function () {
		const $page = $(this).closest(".lm-page");
		$page.data("loans-for", null).data("compute", false);
		load_servicing($root, $page.data("txn"));
	});
	// Any input the server needs in order to compute invalidates the current preview.
	$root.on("change", ".lm-sv-input", function () {
		const $page = $(this).closest(".lm-page");
		$page.data("compute", false);
		load_servicing($root, $page.data("txn"));
	});
	// Cash settlements carry no cheque number, so the field is hidden rather than
	// left to fail the controller's VAL-FAR-018 check.
	$root.on("change", ".lm-sv-payment-type", function () {
		const $page = $(this).closest(".lm-page");
		$page.find(".lm-sv-cheque").toggleClass("lm-hidden", this.value !== "Cheque");
	});
	// Refund or Recast changes nothing the server computes, so the screen only
	// re-applies the mode notice and the button state.
	$root.on("change", ".lm-sv-mode", function () {
		load_servicing($root, $(this).closest(".lm-page").data("txn"));
	});

	$root.on("click", ".lm-sv-process", function () {
		const $page = $(this).closest(".lm-page");
		$page.data("compute", true);
		load_servicing($root, $page.data("txn"));
	});

	$root.on("click", ".lm-sv-settle", function () {
		const $page = $(this).closest(".lm-page");
		const loan = $page.find('[data-field="loan"]').val();
		const payment_type = $page.find('[data-field="payment_type"]').val();
		const cheque_no = ($page.find('[data-field="cheque_no"]').val() || "").trim();
		if (!loan) return;
		if (payment_type === "Cheque" && !cheque_no) {
			lm_toast($root, __("Cheque Number is mandatory when the Type of Payment is Cheque."));
			return;
		}
		const due = $page.find('[data-out="total_balance_due"]').val();
		frappe.confirm(
			__("Settle loan {0} in full for {1}? The loan will be closed and its payroll deductions stopped.", [
				frappe.utils.escape_html(loan),
				frappe.utils.escape_html(due || ""),
			]),
			() => {
				frappe.call({
					method: "karyo.desk.loan_servicing.settle",
					args: {
						loan: loan,
						refund_date: $page.find('[data-field="refund_date"]').val() || null,
						payment_type: payment_type,
						cheque_no: cheque_no,
						remarks: $page.find('[data-field="remarks"]').val() || null,
						ewf_waive_interest: $page.find('[data-field="ewf_waive_interest"]').is(":checked") ? 1 : 0,
					},
					freeze: true,
					freeze_message: __("Processing settlement…"),
					callback: (response) => {
						const result = response.message || {};
						lm_toast($root, result.message || __("Settlement processed."));
						if (result.permitted === false) return;
						// Keep the completed position visible: settlement is authoritative only
						// when every displayed balance is zero, including the final payment UI.
						for (const key of ["capital_due", "interest_due", "insurance_due", "total_balance_due"]) {
							$page.find(`[data-out="${key}"]`).each(function () {
								if (this.tagName === "INPUT") $(this).val(lm_money(0)); else $(this).text(lm_money(0));
							});
						}
						$page.find('[data-out="remaining_instalments"]').text("0");
						$page.find(".lm-sv-message").removeClass("lm-hidden").text(__("Settlement completed. Final balance: {0}.", [lm_money(result.figures?.balance_after || 0)]));
						$page.find(".lm-sv-settle").prop("disabled", true);
						$page.data("blocked", true).data("settled", true);
						// The settled loan is no longer eligible for a second transaction, so
						// invalidate cached choices for the next visit without erasing this result.
						$root.data("lm-servicing-options", null);
						$root.find("[data-txn]").data("ready", false).data("loans-for", null);
					},
				});
			}
		);
	});

	$root.on("click", ".lm-sv-confirm", function () {
		const $page = $(this).closest(".lm-page");
		const loan = $page.find('[data-field="loan"]').val();
		if (!loan) return;
		const capital = $page.find('[data-out="monthly_capital"]').val();
		frappe.confirm(
			__(
				"Apply the new schedule to loan {0}? The current schedule and payroll deductions are replaced from the effective date, at a new monthly capital refund of {1}.",
				[frappe.utils.escape_html(loan), frappe.utils.escape_html(capital || "")]
			),
			() => {
				frappe.call({
					method: "karyo.desk.loan_servicing.recast_apply",
					args: {
						loan: loan,
						effective_date: $page.find('[data-field="effective_date"]').val() || null,
						component: $page.find('[data-field="component"]').val() || null,
						direction: $page.find('[data-field="direction"]').val() || null,
						advance_payment: $page.find('[data-field="advance_payment"]').val() || 0,
						new_period: $page.find('[data-field="new_period"]').val() || 0,
						remarks: $page.find('[data-field="remarks"]').val() || null,
					},
					freeze: true,
					freeze_message: __("Updating schedule…"),
					callback: (response) => {
						const result = response.message || {};
						lm_toast($root, result.message || __("Schedule updated."));
						if (result.permitted === false) return;
						// The loan now runs on the new schedule, so the screen reloads its
						// position instead of leaving the applied preview on display.
						$page.data("compute", false).data("prefilled-loan", null);
						load_servicing($root, "advance");
					},
				});
			}
		);
	});
}

// --- Change of Interest screens ---------------------------------------------
// The client prototype's two interest screens keep their layout, but every figure
// comes from karyo.desk.loan_interest, which runs the governed
// Karyo Loan Interest Change controller: the prototype's inline
// cap*(rate/100/12)*((n+1)/2) arithmetic is never repeated in the browser.
// Both screens preserve the prototype's two-step safety — a server computation has
// to succeed before Apply / Proceed becomes available.
const LM_INTEREST_PAGES = {
	"global-interest": { title: "Global Change of Interest", crumb: "Global Change of Interest" },
	"individual-interest": {
		title: "Individual Change of Interest",
		crumb: "Individual Change of Interest",
	},
};

function interest_page(id) {
	const config = LM_INTEREST_PAGES[id];
	const escape = frappe.utils.escape_html;
	const field = (label, markup, options = {}) =>
		`<div class="lm-field"${options.span ? ` style="${options.span}"` : ""}><label class="${
			options.reqd ? "lm-req" : ""
		}">${escape(label)}</label>${markup}</div>`;
	const input = (name, type = "text", attributes = "") =>
		`<input type="${type}" class="lm-int-field" data-field="${name}"${attributes}>`;
	const readonly = (name) =>
		`<input type="text" class="lm-int-field" data-field="${name}" readonly value="—">`;
	const summary_row = (label, name, total = false) =>
		`<div class="lm-summary-row ${total ? "total" : ""}"><span>${escape(
			label
		)}</span><strong data-int="${name}">—</strong></div>`;
	const head = `<div class="lm-page-head"><div><h1>${__(config.title)}</h1><div class="lm-crumb">LMS / ${__(
		"Transactions"
	)} / ${__(
		config.crumb
	)}</div></div><div class="lm-toolbar"><button class="lm-btn secondary lm-int-history">${__(
		"Change History"
	)}</button></div></div>
		<div class="lm-notice warn lm-int-state lm-hidden"></div>`;

	if (id === "global-interest") {
		const columns = [
			"Select", "Loan Number", "Employee", "Loan Type", "Application Date", "Current Rate",
			"Outstanding Capital", "Remaining Duration", "Monthly Capital",
			"Current Monthly Interest", "New Rate", "New Monthly Interest", "New Monthly Refund",
			"Status",
		];
		const rules = [
			"Only active and approved loans are eligible.",
			"The effective date and revised rate are mandatory.",
			"Loans with pending refund, recast or individual changes are excluded.",
			"Old and new rates, effective date, user and reference are audited.",
		];
		return `<section class="lm-page" id="lm-${id}" data-txn="${id}">
			${head}
			<div class="lm-notice">${__(
				"Use this function to update the interest rate of multiple <strong>active loans</strong> from a specified effective date. Only selected loans are computed and updated, and each change is recorded in the audit trail."
			)}</div>
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Selection Criteria"
			)}</div><span class="lm-badge info">${__(
			"Bulk Processing"
		)}</span></div><div class="lm-card-body"><div class="lm-form-grid cols-3">
				${field(
					__("Loan Type"),
					`<select class="lm-int-field" data-field="loan_type"><option value="">${__(
						"All Active Loan Types"
					)}</option></select>`
				)}
				${field(__("Loan Number From"), input("loan_from"))}
				${field(__("Loan Number To"), input("loan_to"))}
				${field(__("Application Date From"), input("date_from", "date"))}
				${field(__("Application Date To"), input("date_to", "date"))}
				${field(__("New Interest Rate (%)"), input("new_rate", "number", ' min="0" max="100" step="0.01"'), {
					reqd: true,
				})}
				${field(__("Effective Date"), input("effective_date", "date"), { reqd: true })}
				${field(__("Approval / Reference"), input("reference"), { span: "grid-column:span 2" })}
			</div><div class="lm-separator"></div><div class="lm-toolbar"><button class="lm-btn primary lm-gi-populate">${__(
			"Populate Loan Details"
		)}</button><button class="lm-btn secondary lm-gi-reset">${__(
			"Reset"
		)}</button></div></div></div>
			<div class="lm-card"><div class="lm-card-head"><div><div class="lm-card-title">${__(
				"Eligible Active Loans"
			)}</div><div class="lm-muted lm-gi-note">${__(
			"Populate the loan details to list the loans in scope."
		)}</div></div><div class="lm-mini-actions"><button class="lm-btn small secondary lm-gi-all">${__(
			"Select All"
		)}</button><button class="lm-btn small secondary lm-gi-none">${__(
			"Clear"
		)}</button></div></div>
				<div class="lm-table-wrap"><table class="lm-table" style="min-width:1300px"><thead><tr>${columns
					.map((column) => `<th>${__(column)}</th>`)
					.join("")}<th>${__("Action")}</th></tr></thead><tbody class="lm-gi-body"><tr><td colspan="${
			columns.length + 1
		}" class="lm-muted">${__(
			"No loans populated yet."
		)}</td></tr></tbody></table></div>
				<div class="lm-card-body"><div class="lm-toolbar"><button class="lm-btn primary lm-gi-compute">${__(
					"Compute Selected Loans"
				)}</button><button class="lm-btn good lm-gi-apply" disabled>${__(
			"Apply Interest Change"
		)}</button></div></div></div>
			<div class="lm-grid-2">
				<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
					"Batch Summary"
				)}</div></div><div class="lm-card-body"><div class="lm-summary-box">${summary_row(
			__("Selected Loans"),
			"selected"
		)}${summary_row(__("Computed Loans"), "computed")}${summary_row(
			__("Applied Loans"),
			"applied"
		)}${summary_row(__("Batch Status"), "batch_status", true)}</div></div></div>
				<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
					"Processing Controls"
				)}</div></div><div class="lm-card-body"><ul style="margin:0;padding-left:20px;line-height:1.8">${rules
			.map((rule) => `<li>${__(rule)}</li>`)
			.join("")}</ul></div></div>
			</div>
		</section>`;
	}

	const audit_columns = [
		"Date / Time", "Loan Number", "Employee", "Old Rate", "New Rate", "Effective Date",
		"Reference", "User", "Status",
	];
	return `<section class="lm-page" id="lm-${id}" data-txn="${id}">
		${head}
		<div class="lm-notice">${__(
			"Use this function to apply an approved revised interest rate to one active loan from a specified effective date. Select <strong>Compute</strong> to preview the recalculated interest before selecting <strong>Proceed</strong>."
		)}</div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Loan Selection and Revised Rate"
		)}</div><span class="lm-badge good">${__(
		"Active Function"
	)}</span></div><div class="lm-card-body"><div class="lm-form-grid">
			${field(__("Loan Number"), `<select class="lm-int-field lm-ii-loan" data-field="loan"></select>`, {
				reqd: true,
			})}
			${field(__("Employee Code / Name"), readonly("employee"))}
			${field(__("Loan Type"), readonly("loan_type"))}
			${field(__("Loan Status"), readonly("status"))}
			${field(__("Old Interest Rate (%)"), readonly("old_rate"))}
			${field(__("New Interest Rate (%)"), input("new_rate", "number", ' min="0" max="100" step="0.01"'), {
				reqd: true,
			})}
			${field(__("Effective Date"), input("effective_date", "date"), { reqd: true })}
			${field(__("Approval / Reference"), input("reference"))}
			${field(__("Remarks"), `<textarea class="lm-int-field" data-field="remarks"></textarea>`, {
				reqd: true,
				span: "grid-column:1/-1",
			})}
		</div><div class="lm-separator"></div><div class="lm-toolbar"><button class="lm-btn primary lm-ii-compute">${__(
		"Compute"
	)}</button><button class="lm-btn secondary lm-ii-reset">${__("Reset")}</button></div></div></div>
		<div class="lm-grid-2">
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Current Loan Position"
			)}</div></div><div class="lm-card-body"><div class="lm-summary-box">${summary_row(
		__("Outstanding Capital"),
		"outstanding_capital"
	)}${summary_row(__("Outstanding Interest"), "outstanding_interest")}${summary_row(
		__("Remaining Duration"),
		"remaining_duration"
	)}${summary_row(__("Monthly Capital"), "monthly_capital")}${summary_row(
		__("Current Monthly Interest"),
		"current_monthly_interest"
	)}${summary_row(__("Monthly Insurance"), "monthly_insurance")}${summary_row(
		__("Current Monthly Refund"),
		"current_monthly_refund",
		true
	)}</div></div></div>
			<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
				"Loan After Applying New Rate"
			)}</div><span class="lm-badge gray lm-ii-preview-state">${__(
		"Not Computed"
	)}</span></div><div class="lm-card-body"><div class="lm-summary-box">${summary_row(
		__("Effective Date"),
		"p_effective_date"
	)}${summary_row(__("New Interest Rate"), "p_new_rate")}${summary_row(
		__("Remaining Duration"),
		"p_remaining_duration"
	)}${summary_row(__("Outstanding Capital"), "p_outstanding_capital")}${summary_row(
		__("Recomputed Outstanding Interest"),
		"p_new_total_interest"
	)}${summary_row(__("New Monthly Capital"), "p_new_monthly_capital")}${summary_row(
		__("New Monthly Interest"),
		"p_new_monthly_interest"
	)}${summary_row(
		__("New Total Monthly Refund"),
		"p_new_monthly_refund",
		true
	)}</div><div class="lm-separator"></div><button class="lm-btn good lm-ii-proceed" disabled>${__(
		"Proceed"
	)}</button></div></div>
		</div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Interest Change Audit"
		)}</div><span class="lm-muted">${__(
		"Latest transactions"
	)}</span></div><div class="lm-table-wrap"><table class="lm-table"><thead><tr>${audit_columns
		.map((column) => `<th>${__(column)}</th>`)
		.join("")}<th>${__("Action")}</th></tr></thead><tbody class="lm-ii-audit"><tr><td colspan="${
		audit_columns.length + 1
	}" class="lm-muted">${__("Loading…")}</td></tr></tbody></table></div></div>
	</section>`;
}

function load_interest($root, id) {
	const $page = $root.find(`#lm-${id}`);
	const escape = frappe.utils.escape_html;
	const global_screen = id === "global-interest";
	// Proceed keeps the applied preview on screen; every other refresh clears it.
	const keep_preview = Boolean($page.data("applied"));
	$page.removeData("applied");

	const block = (message) => {
		$page
			.find(".lm-int-state")
			.removeClass("lm-hidden")
			.text(message || __("This function is not available."));
		$page
			.find(".lm-gi-populate, .lm-gi-compute, .lm-gi-apply, .lm-ii-compute, .lm-ii-proceed")
			.prop("disabled", true);
	};

	if (global_screen) {
		$page
			.find(".lm-gi-body")
			.html(`<tr><td colspan="15" class="lm-muted">${__("No loans populated yet.")}</td></tr>`);
		$page.find(".lm-gi-note").text(__("Populate the loan details to list the loans in scope."));
		$page.find('[data-int="selected"], [data-int="computed"], [data-int="applied"]').text("0");
		$page.find('[data-int="batch_status"]').text(__("Ready for computation"));
		$page.find(".lm-gi-apply").prop("disabled", true);
		$page.removeData("criteria");
	} else if (!keep_preview) {
		$page.find('[data-int^="p_"]').text("—");
		$page
			.find(".lm-ii-preview-state")
			.attr("class", "lm-badge gray lm-ii-preview-state")
			.text(__("Not Computed"));
		$page.find(".lm-ii-proceed").prop("disabled", true);
	}

	frappe.call({
		method: "karyo.desk.loan_interest.options",
		freeze: false,
		callback: (response) => {
			const data = response.message || {};
			lm_set_currency(data.currency);
			$page.find(".lm-int-history").toggle(data.can_audit !== false);
			if (data.permitted === false) {
				block(data.message);
				if (!global_screen)
					$page
						.find(".lm-ii-audit")
						.html(`<tr><td colspan="10" class="lm-muted">${escape(data.message || "")}</td></tr>`);
				return;
			}
			// CF-010 keeps the whole function switched off; the screen says so rather
			// than letting the first Apply fail in the controller.
			const usable = Boolean(data.enabled) && Boolean(data.can_apply);
			$page
				.find(".lm-int-state")
				.toggleClass("lm-hidden", usable)
				.text(
					data.enabled
						? data.can_apply
							? ""
							: __("You do not have permission to apply loan interest changes.")
						: data.message || __("Change of Interest is disabled.")
				);
			$page.find(".lm-gi-compute, .lm-ii-compute").prop("disabled", !usable);
			$page.data("usable", usable);

			if (global_screen) {
				const $types = $page.find('[data-field="loan_type"]');
				if (!$types.data("ready")) {
					$types
						.data("ready", true)
						.append(
							(data.loan_types || [])
								.map(
									(type) =>
										`<option value="${escape(type.value)}">${escape(type.label)}</option>`
								)
								.join("")
						);
				}
				return;
			}

			const $loans = $page.find(".lm-ii-loan");
			if (!$loans.data("ready")) {
				$loans
					.data("ready", true)
					.html(
						(data.loans || [])
							.map((row) => `<option value="${escape(row.value)}">${escape(row.label)}</option>`)
							.join("")
					);
			}
			const loan = $loans.val();
			if (!loan) {
				$page
					.find(".lm-int-state")
					.removeClass("lm-hidden")
					.text(__("There is no active loan available for an interest change."));
				$page.find(".lm-ii-compute, .lm-ii-proceed").prop("disabled", true);
			} else {
				frappe.call({
					method: "karyo.desk.loan_interest.individual_detail",
					args: { loan: loan },
					freeze: false,
					callback: (detail_response) => {
						const detail = detail_response.message || {};
						lm_set_currency(detail.currency);
						if (detail.permitted === false) {
							block(detail.message);
							return;
						}
						const position = detail.position || {};
						$page.find('[data-field="employee"]').val(position.employee || "—");
						$page.find('[data-field="loan_type"]').val(position.loan_type || "—");
						$page.find('[data-field="status"]').val(position.status || "—");
						$page.find('[data-field="old_rate"]').val(flt(position.old_rate).toFixed(2));
						$page.find('[data-int="outstanding_capital"]').text(lm_money(position.outstanding_capital));
						$page.find('[data-int="outstanding_interest"]').text(lm_money(position.outstanding_interest));
						$page
							.find('[data-int="remaining_duration"]')
							.text(__("{0} months", [cint(position.remaining_duration)]));
						$page.find('[data-int="monthly_capital"]').text(lm_money(position.monthly_capital));
						$page
							.find('[data-int="current_monthly_interest"]')
							.text(lm_money(position.current_monthly_interest));
						$page.find('[data-int="monthly_insurance"]').text(lm_money(position.monthly_insurance));
						$page
							.find('[data-int="current_monthly_refund"]')
							.text(lm_money(position.current_monthly_refund));
						if (detail.blocked) {
							$page.find(".lm-int-state").removeClass("lm-hidden").text(detail.blocked);
						}
					},
				});
			}

			frappe.call({
				method: "karyo.desk.loan_interest.audit",
				args: { limit: 20 },
				freeze: false,
				callback: (audit_response) => {
					const audit = audit_response.message || {};
					const rows = audit.rows || [];
					$page
						.find(".lm-ii-audit")
						.html(
							audit.permitted === false
								? `<tr><td colspan="10" class="lm-muted">${escape(
										audit.message || __("You do not have permission to view the audit trail.")
								  )}</td></tr>`
								: rows
										.map(
											(row) =>
												`<tr><td>${escape(
													frappe.datetime.str_to_user(row.posted_on)
												)}</td><td>${escape(row.loan || "—")}</td><td>${escape(
													row.employee || "—"
												)}</td><td>${flt(row.old_rate).toFixed(2)}%</td><td>${flt(
													row.new_rate
												).toFixed(2)}%</td><td>${escape(
													frappe.datetime.str_to_user(row.effective_date)
												)}</td><td>${escape(row.reference || "—")}</td><td>${escape(
													row.user || "—"
												)}</td><td><span class="lm-badge ${
													row.cancelled ? "bad" : "good"
												}">${escape(row.status)}</span></td><td class="lm-row-actions">${loan_row_actions(row.loan)}</td></tr>`
										)
										.join("") ||
								  `<tr><td colspan="10" class="lm-muted">${__(
										"No interest changes recorded yet."
								  )}</td></tr>`
						);
				},
			});
		},
		error: () => block(__("This screen could not be loaded.")),
	});
}

function wire_interest($root) {
	const escape = frappe.utils.escape_html;
	const page_of = (element) => $(element).closest(".lm-page");
	const values = ($page) => {
		const data = {};
		$page.find(".lm-int-field").each(function () {
			data[this.dataset.field] = $(this).val();
		});
		return data;
	};
	// Selected rows only ever come from the populated grid, so a stale row can never
	// be applied: every row carries the loan it was rendered for.
	const selected = ($page) =>
		$page
			.find(".lm-gi-body tr")
			.filter(function () {
				return $(this).find(".lm-gi-pick").is(":checked");
			})
			.map(function () {
				return $(this).data("loan");
			})
			.get();

	// Apply stays disabled until every selected loan carries a server computation,
	// which is the prototype's two-step safety.
	const sync_global = ($page) => {
		const picked = $page.find(".lm-gi-body tr").filter(function () {
			return $(this).find(".lm-gi-pick").is(":checked");
		});
		const computed = picked.filter(function () {
			return $(this).attr("data-computed") === "1";
		});
		$page.find('[data-int="selected"]').text(picked.length);
		$page.find('[data-int="computed"]').text(computed.length);
		$page
			.find(".lm-gi-apply")
			.prop(
				"disabled",
				!($page.data("usable") && picked.length && picked.length === computed.length)
			);
	};

	const clear_computation = ($page) => {
		$page.find(".lm-gi-body tr").attr("data-computed", "0");
		$page.find(".lm-gi-new-rate, .lm-gi-new-interest, .lm-gi-new-refund").text("—");
		$page
			.find(".lm-gi-status")
			.attr("class", "lm-badge gray lm-gi-status")
			.text(__("Ready"));
		$page.find('[data-int="batch_status"]').text(__("Ready for computation"));
		sync_global($page);
	};

	$root.on("click", ".lm-int-history", function () {
		frappe.set_route("List", "Karyo Loan Interest Change");
	});

	// --- Global Change of Interest ------------------------------------------
	$root.on("click", ".lm-gi-populate", function () {
		const $page = page_of(this);
		const form = values($page);
		const criteria = {
			loan_type: form.loan_type || "",
			loan_from: form.loan_from || "",
			loan_to: form.loan_to || "",
			date_from: form.date_from || "",
			date_to: form.date_to || "",
		};
		$page.find(".lm-gi-body").html(`<tr><td colspan="15" class="lm-muted">${__("Loading…")}</td></tr>`);
		frappe.call({
			method: "karyo.desk.loan_interest.eligible",
			args: criteria,
			freeze: false,
			callback: (response) => {
				const data = response.message || {};
				lm_set_currency(data.currency);
				const rows = data.rows || [];
				if (data.permitted === false) {
					$page
						.find(".lm-gi-body")
						.html(
							`<tr><td colspan="15" class="lm-muted">${escape(
								data.message || __("You do not have permission to view these loans.")
							)}</td></tr>`
						);
					$page.find(".lm-gi-note").text("");
					return;
				}
				$page.data("criteria", criteria);
				$page.find('[data-int="applied"]').text("0");
				$page.find(".lm-gi-body").html(
					rows
						.map(
							(row) =>
								`<tr data-loan="${escape(row.loan)}" data-computed="0"><td><input type="checkbox" class="lm-gi-pick" checked></td><td>${escape(
									row.loan
								)}</td><td>${escape(row.employee || "—")}</td><td>${escape(
									row.loan_type || "—"
								)}</td><td>${
									row.date_applied
										? escape(frappe.datetime.str_to_user(row.date_applied))
										: "—"
								}</td><td class="lm-gi-rate">${flt(row.current_rate).toFixed(
									2
								)}%</td><td>${escape(lm_money(row.outstanding_capital))}</td><td>${cint(
									row.remaining_duration
								)}</td><td>${escape(lm_money(row.monthly_capital))}</td><td class="lm-gi-interest">${escape(
									lm_money(row.current_monthly_interest)
								)}</td><td class="lm-gi-new-rate">—</td><td class="lm-gi-new-interest">—</td><td class="lm-gi-new-refund">—</td><td><span class="lm-badge gray lm-gi-status">${__(
									"Ready"
								)}</span></td><td class="lm-row-actions">${loan_row_actions(row.loan)}</td></tr>`
						)
						.join("") ||
						`<tr><td colspan="15" class="lm-muted">${__(
							"No active loan matches these criteria."
						)}</td></tr>`
				);
				const excluded = data.excluded || [];
				$page
					.find(".lm-gi-note")
					.text(
						__("{0} matching loan(s) • select the records to update", [rows.length]) +
							(excluded.length
								? " • " +
								  __("{0} excluded: {1}", [
										excluded.length,
										excluded
											.slice(0, 3)
											.map((row) => `${row.loan} (${row.reason})`)
											.join(", "),
								  ])
								: "")
					);
				clear_computation($page);
			},
		});
	});

	$root.on("click", ".lm-gi-reset", function () {
		const $page = page_of(this);
		$page.find(".lm-int-field").val("");
		$page.find('[data-field="loan_type"]').prop("selectedIndex", 0);
		load_interest($root, "global-interest");
		lm_toast($root, __("Global change form reset."));
	});

	$root.on("click", ".lm-gi-all, .lm-gi-none", function () {
		const $page = page_of(this);
		$page.find(".lm-gi-pick").prop("checked", $(this).hasClass("lm-gi-all"));
		sync_global($page);
	});

	$root.on("change", ".lm-gi-pick", function () {
		sync_global(page_of(this));
	});

	// Editing the rate, the effective date or the criteria invalidates what was
	// computed, so Apply falls back to disabled until the batch is computed again.
	$root.on("change", "#lm-global-interest .lm-int-field", function () {
		clear_computation(page_of(this));
	});

	$root.on("click", ".lm-gi-compute", function () {
		const $page = page_of(this);
		const form = values($page);
		const loans = selected($page);
		if (!loans.length) {
			lm_toast($root, __("Select at least one loan to compute."));
			return;
		}
		frappe.call({
			method: "karyo.desk.loan_interest.compute_batch",
			args: {
				loans: JSON.stringify(loans),
				new_rate: form.new_rate,
				effective_date: form.effective_date,
			},
			freeze: true,
			freeze_message: __("Computing…"),
			callback: (response) => {
				const data = response.message || {};
				lm_set_currency(data.currency);
				if (data.permitted === false) {
					lm_toast($root, data.message || __("Not permitted."));
					return;
				}
				(data.rows || []).forEach((row) => {
					const $row = $page.find(`.lm-gi-body tr`).filter(function () {
						return $(this).data("loan") === row.loan;
					});
					const ok = row.new_monthly_refund !== undefined && row.new_monthly_refund !== null;
					$row.attr("data-computed", ok ? "1" : "0");
					$row.find(".lm-gi-new-rate").text(ok ? `${flt(row.new_rate).toFixed(2)}%` : "—");
					$row.find(".lm-gi-new-interest").text(ok ? lm_money(row.new_monthly_interest) : "—");
					$row.find(".lm-gi-new-refund").text(ok ? lm_money(row.new_monthly_refund) : "—");
					$row
						.find(".lm-gi-status")
						.attr("class", `lm-badge ${ok ? "info" : "warn"} lm-gi-status`)
						.attr("title", row.message || "")
						.text(row.status || (ok ? __("Computed") : __("Excluded")));
					if (!ok && row.message) $row.find(".lm-gi-pick").prop("checked", false);
				});
				$page
					.find('[data-int="batch_status"]')
					.text(__("Computed — ready to apply"));
				sync_global($page);
				lm_toast($root, __("{0} loan(s) computed.", [cint(data.computed)]));
			},
		});
	});

	$root.on("click", ".lm-gi-apply", function () {
		const $page = page_of(this);
		const form = values($page);
		const criteria = $page.data("criteria") || {};
		const loans = selected($page).filter(function (loan) {
			return (
				$page
					.find(".lm-gi-body tr")
					.filter(function () {
						return $(this).data("loan") === loan;
					})
					.attr("data-computed") === "1"
			);
		});
		if (!loans.length) {
			lm_toast($root, __("Compute the selected loans before applying the change."));
			return;
		}
		frappe.confirm(
			__(
				"Apply the revised interest rate to {0} selected loan(s)? Each loan's rate, remaining schedule and payroll deduction are updated.",
				[loans.length]
			),
			() => {
				frappe.call({
					method: "karyo.desk.loan_interest.apply_batch",
					args: {
						loans: JSON.stringify(loans),
						new_rate: form.new_rate,
						effective_date: form.effective_date,
						reference: form.reference || "",
						loan_type: criteria.loan_type || "",
						date_from: criteria.date_from || "",
						date_to: criteria.date_to || "",
					},
					freeze: true,
					freeze_message: __("Applying interest change…"),
					callback: (response) => {
						const data = response.message || {};
						if (data.permitted === false) {
							lm_toast($root, data.message || __("Not permitted."));
							return;
						}
						const applied = data.applied || [];
						applied.forEach((loan) => {
							const $row = $page.find(".lm-gi-body tr").filter(function () {
								return $(this).data("loan") === loan;
							});
							$row.attr("data-computed", "0");
							$row.find(".lm-gi-rate").text($row.find(".lm-gi-new-rate").text());
							$row.find(".lm-gi-interest").text($row.find(".lm-gi-new-interest").text());
							$row
								.find(".lm-gi-status")
								.attr("class", "lm-badge good lm-gi-status")
								.text(__("Applied"));
							$row.find(".lm-gi-pick").prop("checked", false);
						});
						(data.failed || []).forEach((row) => {
							$page
								.find(".lm-gi-body tr")
								.filter(function () {
									return $(this).data("loan") === row.loan;
								})
								.find(".lm-gi-status")
								.attr("class", "lm-badge bad lm-gi-status")
								.attr("title", row.message || "")
								.text(__("Failed"));
						});
						$page.find('[data-int="applied"]').text(applied.length);
						$page
							.find('[data-int="batch_status"]')
							.text(
								applied.length
									? __("Applied to {0} loan(s)", [applied.length])
									: __("Nothing applied")
							);
						sync_global($page);
						lm_toast($root, data.message || __("Interest change applied."));
					},
				});
			}
		);
	});

	// --- Individual Change of Interest --------------------------------------
	$root.on("change", ".lm-ii-loan", function () {
		load_interest($root, "individual-interest");
	});

	$root.on("change", "#lm-individual-interest .lm-int-field", function () {
		const $page = page_of(this);
		$page.find(".lm-ii-proceed").prop("disabled", true);
		$page
			.find(".lm-ii-preview-state")
			.attr("class", "lm-badge gray lm-ii-preview-state")
			.text(__("Not Computed"));
	});

	$root.on("click", ".lm-ii-reset", function () {
		const $page = page_of(this);
		$page.find('[data-field="new_rate"], [data-field="effective_date"], [data-field="reference"], [data-field="remarks"]').val("");
		load_interest($root, "individual-interest");
		lm_toast($root, __("Individual change form reset."));
	});

	$root.on("click", ".lm-ii-compute", function () {
		const $page = page_of(this);
		const form = values($page);
		frappe.call({
			method: "karyo.desk.loan_interest.individual_preview",
			args: {
				loan: form.loan,
				new_rate: form.new_rate,
				effective_date: form.effective_date,
				remarks: form.remarks,
				reference: form.reference || "",
			},
			freeze: true,
			freeze_message: __("Computing…"),
			callback: (response) => {
				const data = response.message || {};
				lm_set_currency(data.currency);
				if (data.permitted === false) {
					lm_toast($root, data.message || __("Not permitted."));
					return;
				}
				const preview = data.preview || {};
				$page
					.find('[data-int="p_effective_date"]')
					.text(frappe.datetime.str_to_user(preview.effective_date));
				$page.find('[data-int="p_new_rate"]').text(`${flt(preview.new_rate).toFixed(2)}%`);
				$page
					.find('[data-int="p_remaining_duration"]')
					.text(__("{0} months", [cint(preview.remaining_duration)]));
				$page.find('[data-int="p_outstanding_capital"]').text(lm_money(preview.outstanding_capital));
				$page.find('[data-int="p_new_total_interest"]').text(lm_money(preview.new_total_interest));
				$page.find('[data-int="p_new_monthly_capital"]').text(lm_money(preview.new_monthly_capital));
				$page.find('[data-int="p_new_monthly_interest"]').text(lm_money(preview.new_monthly_interest));
				$page.find('[data-int="p_new_monthly_refund"]').text(lm_money(preview.new_monthly_refund));
				$page
					.find(".lm-ii-preview-state")
					.attr("class", "lm-badge info lm-ii-preview-state")
					.text(__("Preview Ready"));
				$page.find(".lm-ii-proceed").prop("disabled", false);
				lm_toast($root, __("Revised interest computed. Review before proceeding."));
			},
		});
	});

	$root.on("click", ".lm-ii-proceed", function () {
		const $page = page_of(this);
		const form = values($page);
		frappe.confirm(
			__("Apply the revised interest rate to loan {0}? This updates the loan schedule and payroll deduction.", [
				form.loan,
			]),
			() => {
				frappe.call({
					method: "karyo.desk.loan_interest.individual_apply",
					args: {
						loan: form.loan,
						new_rate: form.new_rate,
						effective_date: form.effective_date,
						remarks: form.remarks,
						reference: form.reference || "",
					},
					freeze: true,
					freeze_message: __("Applying interest change…"),
					callback: (response) => {
						const data = response.message || {};
						if (data.permitted === false) {
							lm_toast($root, data.message || __("Not permitted."));
							return;
						}
						$page
							.find(".lm-ii-preview-state")
							.attr("class", "lm-badge good lm-ii-preview-state")
							.text(__("Applied"));
						$page.find(".lm-ii-proceed").prop("disabled", true);
						// The applied preview stays on screen while the position and the
						// audit trail are refreshed from the server.
						$page.data("applied", true);
						load_interest($root, "individual-interest");
						lm_toast($root, data.message || __("Interest change applied."));
					},
				});
			}
		);
	});
}

// --- Report catalogue -------------------------------------------------------
// The client prototype ships the Report Catalogue as fifteen static cards whose
// buttons only raise a toast. We keep the layout and the wording, but every card
// is resolved by karyo.desk.loan_reports against the reports actually installed
// on this site: a card the user may not run never arrives, an entry with no MBC
// counterpart renders disabled with the reason, and the buttons hand over to the
// real desk report (or the real print format) instead of faking a download.
const LM_REPORT_PAGES = {
	reports: { title: "Loan Reports", crumb: "Reports", heading: "Loan Report Catalogue" },
};

function report_page(id) {
	const config = LM_REPORT_PAGES[id];
	// data-rep-filter, not data-filter: the application register reads its own
	// filters with an unscoped $root.find('[data-filter="…"]'), so a second
	// loan_type/status control under the same attribute would capture it.
	return `<section class="lm-page" id="lm-${id}" data-txn="${id}">
		<div class="lm-page-head"><div><h1>${__(
			config.heading || config.title
		)}</h1><div class="lm-crumb">LMS / ${__(
		config.crumb
	)}</div></div><div class="lm-toolbar"><button class="lm-btn secondary lm-rep-history">${__(
		"Report History"
	)}</button></div></div>
		<div class="lm-notice warn lm-rep-notice lm-hidden"></div>
		<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">${__(
			"Standard Report Filters"
		)}</div></div><div class="lm-card-body"><div class="lm-filters">
			<div class="lm-field"><label>${__(
				"Employee"
			)}</label><select class="lm-rep-filter" data-rep-filter="employee"><option value="">${__(
		"All Employees"
	)}</option></select></div>
			<div class="lm-field"><label>${__(
				"Loan Type"
			)}</label><select class="lm-rep-filter" data-rep-filter="loan_type"><option value="">${__(
		"All Loan Types"
	)}</option></select></div>
			<div class="lm-field compact"><label>${__(
				"Status"
			)}</label><select class="lm-rep-filter" data-rep-filter="status"><option value="">${__(
		"All Statuses"
	)}</option></select></div>
			<div class="lm-field compact"><label>${__(
				"As At Date"
			)}</label><input type="date" class="lm-rep-filter" data-rep-filter="as_at_date" value="${frappe.datetime.get_today()}"></div>
			<button class="lm-btn primary lm-rep-apply">${__("Apply")}</button>
		</div></div></div>
		<div class="lm-report-cards lm-rep-cards"><div class="lm-muted">${__("Loading…")}</div></div>
	</section>`;
}

function load_report($root, id) {
	const $page = $root.find(`#lm-${id}`);
	const $cards = $page.find(".lm-rep-cards");
	const $notice = $page.find(".lm-rep-notice");
	const escape = frappe.utils.escape_html;
	$cards.html(`<div class="lm-muted">${__("Loading…")}</div>`);
	frappe.call({
		method: "karyo.desk.loan_reports.catalogue",
		freeze: false,
		callback: (response) => {
			const data = response.message || {};
			lm_set_currency(data.currency);

			if (data.permitted === false) {
				$page.data("cards", []);
				$notice
					.removeClass("lm-hidden")
					.text(data.message || __("You do not have permission to view the loan reports."));
				$cards.empty();
				return;
			}
			$notice.addClass("lm-hidden").text("");

			// Option lists are filled once so a re-run of the catalogue keeps the
			// filter values the user has already chosen.
			const options = data.filters || {};
			const fill = (key, rows) => {
				const $select = $page.find(`[data-rep-filter="${key}"]`);
				if ($select.data("ready")) return;
				$select
					.data("ready", true)
					.append(
						rows
							.map(
								(row) =>
									`<option value="${escape(row.value)}">${escape(row.label)}</option>`
							)
							.join("")
					);
			};
			fill("employee", options.employees || []);
			fill("loan_type", options.loan_types || []);
			fill(
				"status",
				(options.statuses || []).map((value) => ({ value: value, label: value }))
			);

			const cards = data.cards || [];
			$page.data("cards", cards);
			$cards.html(
				cards
					.map((card, index) => {
						// An unavailable card keeps its place in the catalogue but its
						// buttons are disabled, with the server's reason in muted text,
						// so nothing on this screen is a button that does nothing.
						const disabled = card.available ? "" : " disabled";
						const reason = card.reason
							? `<div class="lm-muted">${escape(card.reason)}</div>`
							: "";
						return `<div class="lm-report"><h3>${escape(
							card.title
						)}</h3><p>${escape(
							card.description
						)}</p>${reason}<div class="lm-report-actions"><button class="lm-btn small primary lm-rep-preview" data-card="${index}"${disabled}>${__(
							"Preview"
						)}</button><button class="lm-btn small secondary lm-rep-export" data-card="${index}"${disabled}>${__(
							"Export"
						)}</button></div></div>`;
					})
					.join("") ||
					`<div class="lm-muted">${__("No loan reports are available to you.")}</div>`
			);
		},
		error: () =>
			$cards.html(`<div class="lm-muted">${__("The report catalogue could not be loaded.")}</div>`),
	});
}

function wire_report($root) {
	// The four screen filters are mapped onto the fieldnames each target report
	// actually declares, so a report never receives a filter it would ignore.
	const report_filters = ($page, card) => {
		const values = Object.assign({}, card.defaults || {});
		Object.entries(card.filters || {}).forEach(([key, fieldname]) => {
			const value = $page.find(`[data-rep-filter="${key}"]`).val();
			if (value) values[fieldname] = value;
		});
		return values;
	};
	const card_of = (element) => {
		const $page = $(element).closest(".lm-page");
		const card = ($page.data("cards") || [])[cint(element.dataset.card)];
		return { $page: $page, card: card };
	};

	$root.on("click", ".lm-rep-apply", function () {
		const $page = $(this).closest(".lm-page");
		load_report($root, $page.data("txn"));
		lm_toast($root, __("Report filters applied."));
	});
	$root.on("click", ".lm-rep-history", function () {
		// Frappe records every generated run as a Prepared Report, so that list is
		// the real report history rather than an invented one.
		frappe.set_route("List", "Prepared Report");
		lm_toast($root, __("Report history lists previously generated reports."));
	});
	$root.on("click", ".lm-rep-preview", function () {
		const { $page, card } = card_of(this);
		if (!card || !card.available) return;
		const filters = report_filters($page, card);
		if (card.kind === "print") {
			// The agreement and the application form are printed from one loan, so
			// the card opens the loans the filters describe and names the format.
			frappe.set_route("List", card.doctype, filters);
			lm_toast($root, __("Open the loan, then Print with the {0} format.", [card.print_format]));
			return;
		}
		frappe.set_route("query-report", card.report, filters);
	});
	$root.on("click", ".lm-rep-export", function () {
		const { $page, card } = card_of(this);
		if (!card || !card.available) return;
		const filters = report_filters($page, card);
		if (card.kind === "print") {
			frappe.set_route("List", card.doctype, filters);
			lm_toast($root, __("Open the loan and print the {0} format to PDF.", [card.print_format]));
			return;
		}
		// The desk exports the report itself, with its real columns, permissions
		// and Prepared Report handling, so we hand over to it instead of building a
		// second download here that could disagree with the report.
		frappe.set_route("query-report", card.report, filters);
		lm_toast($root, __("Use Menu → Export in {0} to download it.", [card.report]));
	});
}

// View uses the read-only drawer; editing continues through the existing server checks.
function loan_row_actions(name, agreementAvailable = false) {
 const escaped = frappe.utils.escape_html(name || "");
 const agreement = agreementAvailable
  ? `<button class="lm-btn small secondary lm-view-agreement" data-loan="${escaped}">${__("View Agreement")}</button> `
  : "";
 return `${agreement}<button class="lm-btn small secondary lm-open-loan" data-loan="${escaped}" data-mode="edit"${frappe.model.can_write("Karyo Loan") ? "" : " disabled"}>${__("Edit")}</button> <button type="button" class="lm-btn small secondary lm-delete-record" data-doctype="Karyo Loan" data-name="${escaped}"${frappe.model.can_delete("Karyo Loan") ? "" : " disabled"}>${__("Delete")}</button>`;
}
