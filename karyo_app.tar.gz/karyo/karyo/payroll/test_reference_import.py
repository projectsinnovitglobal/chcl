from frappe.tests.utils import FrappeTestCase

from karyo.payroll.reference_import import preview_contribution_csv, preview_operation_code_csv


class TestPayrollReferenceImport(FrappeTestCase):
	def test_received_contribution_register_is_structurally_valid(self):
		content = (
			"scheme_code,description,calculation_mode,basis_operation_code,employee_pdb_code,"
			"employer_salary_component,effective_from,lower_salary,upper_salary,is_open_ended,"
			"employee_value,employer_value\n"
			"CSG,Contribution Sociale Generalisee,Percentage,GSAL,CSG,Employer CSG,"
			"2025-07-01,0,,1,0,4.5\n"
		)
		result = preview_contribution_csv(content)
		self.assertTrue(result["valid"], result["errors"])
		self.assertEqual(len(result["schemes"]), 1)
		self.assertEqual(result["schemes"][0]["scheme_code"], "CSG")
		self.assertEqual(result["schemes"][0]["band_count"], 1)

	def test_contribution_overlap_is_rejected(self):
		header = (
			"scheme_code,description,calculation_mode,basis_operation_code,employee_pdb_code,"
			"employer_salary_component,effective_from,lower_salary,upper_salary,is_open_ended,"
			"employee_value,employer_value\n"
		)
		rows = (
			"TEST,Test,Percentage,GSAL,CSG,Employer CSG,2025-07-01,0,50000,0,0,4.5\n"
			"TEST,Test,Percentage,GSAL,CSG,Employer CSG,2025-07-01,50000,,1,0,9\n"
		)
		result = preview_contribution_csv(header + rows)
		self.assertFalse(result["valid"])
		self.assertIn("salary bands overlap", result["errors"][0])

	def test_operation_preview_reports_missing_pdb(self):
		content = (
			"operation_code,description,operation_category,effective_from,pdb_code,sequence,aggregation_sign\n"
			"TEST,Test,Other,2025-07-01,DOES-NOT-EXIST,1,Add\n"
		)
		result = preview_operation_code_csv(content)
		self.assertTrue(result["valid"])
		self.assertEqual(result["operations"][0]["missing_pdb_codes"], ["DOES-NOT-EXIST"])
