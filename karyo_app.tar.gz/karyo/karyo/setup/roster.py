"""Install governed roster mappings and a complete PRB work-pattern catalogue."""

import re

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.utils import nowdate


PRB_GROUP_OPTIONS = "other\nworkmen\nsurveillant\nshift\nroster\nstaggered\nforty_hour"
PH_TREATMENT_OPTIONS = "Public holiday non-working\nPublic holiday working\nRoster applies\nAs per holiday calendar"

SHIFT_TYPES = (
	("PRB Standard Day", "STD-DAY", "08:00:00", "14:45:00"),
	("PRB 8-Hour Day", "SHIFT-DAY", "06:00:00", "14:00:00"),
	("PRB 8-Hour Evening", "SHIFT-EVE", "14:00:00", "22:00:00"),
	("PRB 8-Hour Night", "SHIFT-NIGHT", "22:00:00", "06:00:00"),
	("PRB Staggered Early", "STAG-EARLY", "07:00:00", "15:00:00"),
	("PRB Staggered Late", "STAG-LATE", "10:00:00", "18:00:00"),
)

WORK_PATTERNS = (
	("Standard 33.75 Hours", "Standard 33.75 Hours", "PRB Standard Day", "other", 33.75, 5),
	("Workmen 40 Hours", "Workmen 40 Hours", "PRB 8-Hour Day", "workmen", 40, 5),
	("Surveillant Duty", "Surveillant Duty", "PRB 8-Hour Day", "surveillant", 40, 6),
	("Shift Worker 40 Hours", "Shift Worker 40 Hours", "PRB 8-Hour Day", "shift", 40, 6),
	("Roster 40 Hours", "Roster 40 Hours", "PRB 8-Hour Day", "roster", 40, 6),
	("Staggered 40 Hours", "Staggered 40 Hours", "PRB Staggered Early", "staggered", 40, 5),
	("40-Hour Officer", "40-Hour Officer", "PRB 8-Hour Day", "forty_hour", 40, 5),
)

EMPLOYEE_GROUPS = (
	("Standard Officers", "STD", "other", "Standard 33.75 Hours", "PRB Standard Day"),
	("Workmen", "WORKMEN", "workmen", "Workmen 40 Hours", "PRB 8-Hour Day"),
	("Surveillants", "SURV", "surveillant", "Surveillant Duty", "PRB 8-Hour Day"),
	("Shift Workers", "SHIFT", "shift", "Shift Worker 40 Hours", "PRB 8-Hour Day"),
	("Roster Workers", "ROSTER", "roster", "Roster 40 Hours", "PRB 8-Hour Day"),
	("Staggered Hours", "STAG", "staggered", "Staggered 40 Hours", "PRB Staggered Early"),
	("40-Hour Officers", "40H", "forty_hour", "40-Hour Officer", "PRB 8-Hour Day"),
)


def _fields():
	create_custom_fields(
		{
			"Employee Group Table": [
				{
					"fieldname": "karyo_employee_name_selector",
					"fieldtype": "Autocomplete",
					"label": "Employee Name",
					"insert_after": "employee",
					"in_list_view": 1,
					"columns": 4,
				},
			],
			"Employee Group": [
				{"fieldname": "karyo_group_code", "fieldtype": "Data", "label": "Employee Group Code", "insert_after": "employee_group_name", "unique": 1, "in_list_view": 1},
				{"fieldname": "karyo_prb_group", "fieldtype": "Select", "label": "PRB Employee Group", "options": PRB_GROUP_OPTIONS, "default": "other", "insert_after": "karyo_group_code", "in_list_view": 1},
				{"fieldname": "karyo_work_pattern", "fieldtype": "Link", "label": "Work Pattern", "options": "Employee Work Pattern", "insert_after": "karyo_prb_group", "in_list_view": 1},
				{"fieldname": "karyo_default_shift", "fieldtype": "Link", "label": "Default Shift Type", "options": "Shift Type", "insert_after": "karyo_work_pattern"},
				{"fieldname": "karyo_default_shift_code", "fieldtype": "Data", "label": "Shift Code", "fetch_from": "karyo_default_shift.karyo_shift_code", "read_only": 1, "insert_after": "karyo_default_shift"},
				{"fieldname": "karyo_payroll_group", "fieldtype": "Link", "label": "Payroll Group", "options": "Employee Payroll Group", "insert_after": "karyo_default_shift_code"},
				{"fieldname": "karyo_normal_weekly_hours", "fieldtype": "Float", "label": "Normal Weekly Hours", "fetch_from": "karyo_work_pattern.normal_weekly_hours", "read_only": 1, "insert_after": "karyo_payroll_group", "in_list_view": 1},
			],
			"Employee Payroll Group": [
				{"fieldname": "karyo_employee_group", "fieldtype": "Link", "label": "Employee Group", "options": "Employee Group", "insert_after": "payroll_group_name"},
			],
			"Employee": [
				{"fieldname": "karyo_employee_group", "fieldtype": "Link", "label": "Employee Group Code", "options": "Employee Group", "insert_after": "karyo_employment_category_description", "in_standard_filter": 1},
				{"fieldname": "karyo_shift_code", "fieldtype": "Data", "label": "Shift Code", "fetch_from": "default_shift.karyo_shift_code", "read_only": 1, "insert_after": "default_shift"},
				{"fieldname": "karyo_roster_schedule", "fieldtype": "Link", "label": "Roster Schedule", "options": "Shift Schedule", "read_only": 1, "no_copy": 1, "insert_after": "karyo_shift_code"},
				{"fieldname": "karyo_shift_schedule_assignment", "fieldtype": "Link", "label": "Shift / Roster Assignment", "options": "Shift Schedule Assignment", "read_only": 1, "no_copy": 1, "insert_after": "karyo_roster_schedule"},
				{"fieldname": "karyo_shift_location", "fieldtype": "Link", "label": "Shift Location", "options": "Shift Location", "read_only": 1, "no_copy": 1, "insert_after": "karyo_shift_schedule_assignment"},
				{"fieldname": "karyo_roster_effective_from", "fieldtype": "Date", "label": "Roster Effective From", "read_only": 1, "no_copy": 1, "insert_after": "karyo_shift_location"},
				{"fieldname": "karyo_shift_roster_workspace", "fieldtype": "HTML", "label": "Shift & Roster Setup", "insert_after": "karyo_roster_effective_from"},
			],
			"Shift Schedule": [
				{"fieldname": "karyo_roster_code", "fieldtype": "Data", "label": "Roster Code", "insert_after": "shift_type", "unique": 1, "in_list_view": 1},
				{"fieldname": "karyo_is_rotational", "fieldtype": "Check", "label": "Rotational Roster", "insert_after": "frequency", "in_list_view": 1},
				{"fieldname": "karyo_rotation_cycle_days", "fieldtype": "Int", "label": "Rotation Cycle Days", "default": "7", "depends_on": "karyo_is_rotational", "mandatory_depends_on": "karyo_is_rotational", "insert_after": "karyo_is_rotational"},
				{"fieldname": "karyo_rotation_duty_section", "fieldtype": "Section Break", "label": "Rotation Steps", "depends_on": "karyo_is_rotational", "insert_after": "karyo_rotation_cycle_days"},
				{"fieldname": "karyo_rotation_steps", "fieldtype": "Table", "label": "Duty Rotation", "options": "Shift Rotation Step", "depends_on": "karyo_is_rotational", "insert_after": "karyo_rotation_duty_section"},
				{"fieldname": "karyo_weekly_calendar_section", "fieldtype": "Section Break", "label": "Roster Calendar", "insert_after": "karyo_rotation_steps"},
				{"fieldname": "karyo_schedule_calendar", "fieldtype": "HTML", "label": "Roster Calendar", "insert_after": "repeat_on_days"},
			],
			"Shift Schedule Assignment": [
				{"fieldname": "karyo_shift_type", "fieldtype": "Link", "label": "Shift Type", "options": "Shift Type", "reqd": 1, "in_list_view": 1, "insert_after": "schedule_settings_section"},
				{"fieldname": "karyo_shift_code", "fieldtype": "Data", "label": "Shift Code", "fetch_from": "karyo_shift_type.karyo_shift_code", "read_only": 1, "insert_after": "karyo_shift_type"},
				{"fieldname": "karyo_is_rotational_schedule", "fieldtype": "Check", "label": "Rotational Shift", "read_only": 1, "insert_after": "shift_schedule"},
				{"fieldname": "karyo_rotation_cycle_days_snapshot", "fieldtype": "Int", "label": "Rotation Cycle Days", "read_only": 1, "depends_on": "karyo_is_rotational_schedule", "insert_after": "karyo_is_rotational_schedule"},
				{"fieldname": "karyo_rotation_anchor_date", "fieldtype": "Date", "label": "Rotation Start / Cycle Day 1", "depends_on": "karyo_is_rotational_schedule", "mandatory_depends_on": "karyo_is_rotational_schedule", "insert_after": "karyo_rotation_cycle_days_snapshot"},
				{"fieldname": "karyo_rotation_pattern", "fieldtype": "Small Text", "label": "Rotation Pattern", "read_only": 1, "depends_on": "karyo_is_rotational_schedule", "insert_after": "karyo_rotation_anchor_date"},
			],
			"Shift Type": [
				{"fieldname": "karyo_attendance_config_section", "fieldtype": "Section Break", "label": "Attendance Configuration", "insert_after": "end_time"},
				{"fieldname": "karyo_description", "fieldtype": "Small Text", "label": "Description", "insert_after": "karyo_attendance_config_section"},
				{"fieldname": "karyo_department", "fieldtype": "Link", "label": "Department", "options": "Department", "insert_after": "karyo_description"},
				{"fieldname": "karyo_section", "fieldtype": "Link", "label": "Section", "options": "Employee Section", "insert_after": "karyo_department"},
				{"fieldname": "karyo_location", "fieldtype": "Link", "label": "Location", "options": "Employee Location", "insert_after": "karyo_section"},
				{"fieldname": "karyo_employee_category", "fieldtype": "Link", "label": "Employee Category", "options": "Employee Category", "insert_after": "karyo_location"},
				{"fieldname": "karyo_attendance_rules_column", "fieldtype": "Column Break", "insert_after": "karyo_employee_category"},
				{"fieldname": "karyo_working_days", "fieldtype": "Data", "label": "Working Days", "insert_after": "karyo_attendance_rules_column", "description": "Examples: Mon-Fri, Mon-Sat, or As per roster."},
				{"fieldname": "karyo_daily_hours", "fieldtype": "Float", "label": "Daily Hours", "precision": "2", "read_only": 1, "in_list_view": 1, "insert_after": "karyo_working_days"},
				{"fieldname": "karyo_saturday_working", "fieldtype": "Check", "label": "Saturday Working?", "insert_after": "karyo_daily_hours"},
				{"fieldname": "karyo_sunday_working", "fieldtype": "Check", "label": "Sunday Working?", "insert_after": "karyo_saturday_working"},
				{"fieldname": "karyo_ph_treatment", "fieldtype": "Select", "label": "PH Treatment", "options": PH_TREATMENT_OPTIONS, "default": "Public holiday non-working", "insert_after": "karyo_sunday_working"},
				{"fieldname": "karyo_effective_section", "fieldtype": "Section Break", "label": "Effective Period", "insert_after": "karyo_ph_treatment"},
				{"fieldname": "karyo_effective_from", "fieldtype": "Date", "label": "Effective From", "reqd": 1, "default": "Today", "insert_after": "karyo_effective_section"},
				{"fieldname": "karyo_effective_to", "fieldtype": "Date", "label": "Effective To", "insert_after": "karyo_effective_from"},
				{"fieldname": "karyo_remarks", "fieldtype": "Small Text", "label": "Remarks", "insert_after": "karyo_effective_to"},
			],
			"Holiday List": [
				{"fieldname": "karyo_calendar_code", "fieldtype": "Data", "label": "Calendar Code", "unique": 1, "in_list_view": 1, "in_standard_filter": 1, "insert_after": "holiday_list_name"},
				{"fieldname": "karyo_description", "fieldtype": "Small Text", "label": "Description", "insert_after": "karyo_calendar_code"},
				{"fieldname": "karyo_scope_section", "fieldtype": "Section Break", "label": "Attendance Scope", "insert_after": "to_date"},
				{"fieldname": "karyo_department", "fieldtype": "Link", "label": "Department", "options": "Department", "insert_after": "karyo_scope_section"},
				{"fieldname": "karyo_section", "fieldtype": "Link", "label": "Section", "options": "Employee Section", "insert_after": "karyo_department"},
				{"fieldname": "karyo_location", "fieldtype": "Link", "label": "Location", "options": "Employee Location", "insert_after": "karyo_section"},
				{"fieldname": "karyo_employee_category", "fieldtype": "Link", "label": "Employee Category", "options": "Employee Category", "insert_after": "karyo_location"},
				{"fieldname": "karyo_scope_column", "fieldtype": "Column Break", "insert_after": "karyo_employee_category"},
				{"fieldname": "karyo_working_days", "fieldtype": "Data", "label": "Working Days", "insert_after": "karyo_scope_column"},
				{"fieldname": "karyo_saturday_working", "fieldtype": "Check", "label": "Saturday Working?", "insert_after": "karyo_working_days"},
				{"fieldname": "karyo_sunday_working", "fieldtype": "Check", "label": "Sunday Working?", "insert_after": "karyo_saturday_working"},
				{"fieldname": "karyo_ph_treatment", "fieldtype": "Select", "label": "PH Treatment", "options": PH_TREATMENT_OPTIONS, "default": "Public holiday non-working", "insert_after": "karyo_sunday_working"},
				{"fieldname": "karyo_remarks", "fieldtype": "Small Text", "label": "Remarks", "insert_after": "karyo_ph_treatment"},
			],
		},
		update=True,
	)
	# Preserve the upstream storage fields while presenting two equivalent
	# selectors. The name selector stores the Employee document name internally,
	# so employees with the same human name remain unambiguous.
	make_property_setter("Employee Group Table", "employee", "label", "Employee Code", "Data")
	make_property_setter("Employee Group Table", "employee", "columns", 3, "Int")
	make_property_setter("Employee Group Table", "employee_name", "fetch_from", "employee.employee_name", "Data")
	make_property_setter("Employee Group Table", "employee_name", "hidden", 1, "Check")
	make_property_setter("Employee Group Table", "employee_name", "in_list_view", 0, "Check")
	make_property_setter("Employee Group Table", "user_id", "columns", 3, "Int")
	make_property_setter("Employee Group Table", "user_id", "read_only", 1, "Check")
	frappe.db.sql(
		"""update `tabEmployee Group Table`
		set karyo_employee_name_selector=employee
		where coalesce(employee, '') != ''
		and coalesce(karyo_employee_name_selector, '') != employee"""
	)
	# Keep the complete employee-bound result together on Attendance & Leaves.
	# This is the same data written by the guided setup page; there is no second
	# roster profile hidden elsewhere.
	for fieldname, insert_after in (
		("karyo_employee_group", "holiday_list"),
		("karyo_work_pattern", "karyo_employee_group"),
		("default_shift", "karyo_work_pattern"),
		("karyo_shift_code", "default_shift"),
		("karyo_roster_schedule", "karyo_shift_code"),
		("karyo_shift_schedule_assignment", "karyo_roster_schedule"),
		("karyo_shift_location", "karyo_shift_schedule_assignment"),
		("karyo_roster_effective_from", "karyo_shift_location"),
		("karyo_shift_roster_workspace", "karyo_roster_effective_from"),
	):
		if frappe.get_meta("Employee").has_field(fieldname):
			make_property_setter("Employee", fieldname, "insert_after", insert_after, "Data")
	# These fields are still written for HRMS attendance compatibility, but the
	# roster assignment is authoritative and is already shown in the employee's
	# synchronized Shift & Roster summary.
	make_property_setter("Employee", "default_shift", "hidden", 1, "Check")
	make_property_setter("Employee", "karyo_shift_code", "hidden", 1, "Check")
	# A schedule is an optional recurring rule for the mandatory Shift Type. When
	# none applies, the assignment and attendance engine use Shift Type directly.
	# Keep the native weekly-day table and visual calendar outside the conditional
	# rotational section so both weekly and rotational schedules can see them.
	make_property_setter(
		"Shift Schedule", "repeat_on_days", "insert_after", "karyo_weekly_calendar_section", "Data",
	)
	make_property_setter("Shift Schedule Assignment", "shift_schedule", "reqd", 0, "Check")
	make_property_setter(
		"Shift Schedule Assignment", "shift_schedule", "label", "Shift Schedule (optional)", "Data",
	)
	make_property_setter(
		"Shift Schedule Assignment", "shift_schedule", "description",
		"Automatically selected when one submitted schedule matches the Shift Type. Leave blank to track directly from Shift Type.",
		"Text",
	)
	# Employee Group's quick-entry dialog does not expose the employee child
	# table, which made a newly-created group look as if no employees existed.
	make_property_setter(
		"Employee Group", None, "quick_entry", 0, "Check",
		for_doctype=True, validate_fields_for_doctype=False,
	)


def _seed_shift_types():
	for name, code, start, end in SHIFT_TYPES:
		if not frappe.db.exists("Shift Type", name):
			frappe.get_doc({"doctype": "Shift Type", "name": name, "start_time": start, "end_time": end}).insert(ignore_permissions=True)
		frappe.db.set_value("Shift Type", name, "karyo_shift_code", code, update_modified=False)
	for name in frappe.get_all("Shift Type", pluck="name"):
		if not frappe.db.get_value("Shift Type", name, "karyo_shift_code"):
			code = re.sub(r"[^A-Z0-9]+", "-", name.upper()).strip("-")[:140]
			frappe.db.set_value("Shift Type", name, "karyo_shift_code", code, update_modified=False)


def _seed_work_patterns():
	for code, label, shift, group, hours, days in WORK_PATTERNS:
		values = {"work_pattern_name": label, "default_shift": shift,
			"default_shift_code": frappe.db.get_value("Shift Type", shift, "karyo_shift_code"),
			"prb_group": group, "normal_weekly_hours": hours,
			"maximum_work_days": days, "disabled": 0}
		if frappe.db.exists("Employee Work Pattern", code):
			frappe.db.set_value("Employee Work Pattern", code, values, update_modified=False)
		else:
			frappe.get_doc({"doctype": "Employee Work Pattern", "work_pattern_code": code, **values}).insert(ignore_permissions=True)
	if frappe.db.exists("Employee Work Pattern", "Full Time"):
		frappe.db.set_value("Employee Work Pattern", "Full Time", {
			"default_shift": "PRB Standard Day",
			"default_shift_code": frappe.db.get_value("Shift Type", "PRB Standard Day", "karyo_shift_code"),
			"prb_group": "other", "normal_weekly_hours": 33.75,
			"maximum_work_days": 5,
		}, update_modified=False)


def _seed_employee_groups():
	for name, code, group, pattern, shift in EMPLOYEE_GROUPS:
		if not frappe.db.exists("Employee Group", name):
			frappe.get_doc({"doctype": "Employee Group", "employee_group_name": name}).insert(ignore_permissions=True)
		hours = frappe.db.get_value("Employee Work Pattern", pattern, "normal_weekly_hours") or 0
		frappe.db.set_value("Employee Group", name, {"karyo_group_code": code,
			"karyo_prb_group": group, "karyo_work_pattern": pattern,
			"karyo_default_shift": shift,
			"karyo_default_shift_code": frappe.db.get_value("Shift Type", shift, "karyo_shift_code"),
			"karyo_normal_weekly_hours": hours}, update_modified=False)
	for payroll_group in ("Permanent", "Monthly Payroll"):
		if frappe.db.exists("Employee Payroll Group", payroll_group):
			frappe.db.set_value("Employee Payroll Group", payroll_group, "karyo_employee_group", "Standard Officers", update_modified=False)
	if frappe.db.exists("Employee Payroll Group", "Casual"):
		frappe.db.set_value("Employee Payroll Group", "Casual", "karyo_employee_group", "Workmen", update_modified=False)
	frappe.db.sql("""update `tabEmployee` set karyo_employee_group='Standard Officers'
		where coalesce(karyo_employee_group,'')='' and karyo_work_pattern='Full Time'""")
	frappe.db.sql("""update `tabEmployee` set karyo_work_pattern='Standard 33.75 Hours', default_shift='PRB Standard Day'
		where karyo_employee_group='Standard Officers' and karyo_work_pattern='Full Time'""")
	# A recurring Shift Schedule Assignment is the authoritative evidence that an
	# employee works a roster.  Map those employees after the general backfill.
	frappe.db.sql("""update `tabEmployee` employee
		inner join `tabShift Schedule Assignment` assignment
			on assignment.employee=employee.name and assignment.enabled=1
		inner join `tabShift Schedule` schedule on schedule.name=assignment.shift_schedule
		set employee.karyo_employee_group='Roster Workers',
			employee.karyo_work_pattern='Roster 40 Hours',
			employee.default_shift=schedule.shift_type
		where assignment.docstatus<2""")
	frappe.db.sql("""update `tabEmployee` employee
		left join `tabShift Type` shift_type on shift_type.name=employee.default_shift
		set employee.karyo_shift_code=shift_type.karyo_shift_code""")


def _seed_rotational_roster():
	name = "PRB 3-Shift Rotation"
	if frappe.db.exists("Shift Schedule", name):
		for row in frappe.get_all("Shift Rotation Step", filters={"parent": name}, fields=["name", "shift_type"]):
			if row.shift_type:
				frappe.db.set_value("Shift Rotation Step", row.name, "shift_code", frappe.db.get_value("Shift Type", row.shift_type, "karyo_shift_code"), update_modified=False)
		return
	doc = frappe.get_doc({
		"doctype": "Shift Schedule",
		"name": name,
		"shift_type": "PRB 8-Hour Day",
		"frequency": "Every Week",
		"karyo_roster_code": "ROT-3SHIFT-21D",
		"karyo_is_rotational": 1,
		"karyo_rotation_cycle_days": 21,
	})
	for day_name in ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"):
		doc.append("repeat_on_days", {"day": day_name})
	for day in range(1, 22):
		if day in {6, 7, 13, 14, 20, 21}:
			doc.append("karyo_rotation_steps", {"day_index": day, "duty_label": "Rest Day", "is_rest_day": 1})
		elif day <= 5:
			doc.append("karyo_rotation_steps", {"day_index": day, "duty_label": "Day Duty", "shift_type": "PRB 8-Hour Day"})
		elif day <= 12:
			doc.append("karyo_rotation_steps", {"day_index": day, "duty_label": "Evening Duty", "shift_type": "PRB 8-Hour Evening"})
		else:
			doc.append("karyo_rotation_steps", {"day_index": day, "duty_label": "Night Duty", "shift_type": "PRB 8-Hour Night"})
	doc.insert(ignore_permissions=True)
	doc.submit()


def _backfill_schedule_assignment_details():
	"""Populate the Shift Type and rotation snapshot on existing assignments."""
	from karyo.hr.roster import schedule_assignment_values

	updated = 0
	for row in frappe.get_all(
		"Shift Schedule Assignment", filters={"shift_schedule": ("is", "set")},
		fields=["name", "shift_schedule", "create_shifts_after", "karyo_rotation_anchor_date"],
		limit_page_length=0,
	):
		values = schedule_assignment_values(row.shift_schedule)
		if not values:
			continue
		if values["karyo_is_rotational_schedule"] and not row.karyo_rotation_anchor_date:
			values["karyo_rotation_anchor_date"] = row.create_shifts_after or nowdate()
		frappe.db.set_value(
			"Shift Schedule Assignment", row.name, values, update_modified=False,
		)
		updated += 1
	return updated


def _backfill_employee_assignment_snapshots():
	"""Expose every existing live roster assignment on the Employee Attendance tab."""
	from karyo.hr.roster import _assignment_snapshot

	seen = set()
	for row in frappe.get_all(
		"Shift Schedule Assignment", filters={"enabled": 1, "docstatus": ["<", 2]},
		fields=["name", "employee", "shift_schedule", "shift_location", "create_shifts_after",
			"karyo_rotation_anchor_date"],
		order_by="modified desc", limit_page_length=0,
	):
		if not row.employee or row.employee in seen:
			continue
		seen.add(row.employee)
		frappe.db.set_value("Employee", row.employee, _assignment_snapshot(row), update_modified=False)
	return len(seen)


def _backfill_attendance_configuration_fields():
	"""Populate the sheet register fields without changing legacy master identity."""
	from karyo.hr.roster import _time_hours, _working_days_label

	for row in frappe.get_all(
		"Shift Type",
		fields=["name", "start_time", "end_time", "creation", "karyo_description", "karyo_working_days",
			"karyo_saturday_working", "karyo_sunday_working", "karyo_effective_from"],
		limit_page_length=0,
	):
		frappe.db.set_value("Shift Type", row.name, {
			"karyo_description": row.karyo_description or row.name,
			"karyo_working_days": _working_days_label(row.karyo_working_days, row.karyo_saturday_working, row.karyo_sunday_working),
			"karyo_daily_hours": _time_hours(row.start_time, row.end_time),
			"karyo_effective_from": row.karyo_effective_from or row.creation.date(),
		}, update_modified=False)
	for row in frappe.get_all(
		"Employee Work Pattern",
		fields=["name", "prb_group", "maximum_work_days", "working_days", "saturday_working", "sunday_working",
			"effective_from", "creation"], limit_page_length=0,
	):
		saturday = row.saturday_working or int(row.maximum_work_days or 0) >= 6
		frappe.db.set_value("Employee Work Pattern", row.name, {
			"working_days": _working_days_label(row.working_days, saturday, row.sunday_working, row.prb_group == "roster"),
			"saturday_working": saturday,
			"effective_from": row.effective_from or row.creation.date(),
		}, update_modified=False)
	for row in frappe.get_all("Holiday List", fields=["name", "holiday_list_name"], limit_page_length=0):
		doc = frappe.get_doc("Holiday List", row.name)
		from karyo.hr.roster import validate_attendance_configuration_master
		validate_attendance_configuration_master(doc)
		frappe.db.set_value("Holiday List", row.name, {
			"karyo_calendar_code": doc.karyo_calendar_code,
			"karyo_description": doc.karyo_description,
			"karyo_working_days": doc.karyo_working_days,
		}, update_modified=False)


def apply():
	_fields()
	_seed_shift_types()
	_seed_work_patterns()
	_seed_employee_groups()
	_seed_rotational_roster()
	_backfill_schedule_assignment_details()
	_backfill_employee_assignment_snapshots()
	_backfill_attendance_configuration_fields()
	for dt in ("Employee", "Employee Group", "Employee Group Table", "Employee Payroll Group", "Employee Work Pattern", "Shift Type", "Holiday List", "Shift Schedule", "Shift Schedule Assignment"):
		frappe.clear_cache(doctype=dt)
