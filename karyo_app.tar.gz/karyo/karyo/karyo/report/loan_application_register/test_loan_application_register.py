from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.loan_application_register.loan_application_register import execute


class TestLoanApplicationRegister(FrappeTestCase):
	@patch("frappe.has_permission")
	@patch("frappe.get_all")
	@patch("frappe.get_list")
	def test_filters_permissions_organisation_and_totals(self, get_list, get_all, has_permission):
		get_list.return_value = [frappe._dict(name="LN-1", employee="EMP-1", amount_applied=1000,
			approved_amount=800, workflow_state="Approved")]
		get_all.return_value = [frappe._dict(name="EMP-1", department="Finance", branch="HQ")]
		columns, rows, _, _, summary = execute({"department": "Finance", "location": "HQ", "from_date": "2026-01-01", "to_date": "2026-12-31"})
		has_permission.assert_called_once_with("Karyo Loan", "read", throw=True)
		self.assertEqual(rows[0].variance, 200)
		self.assertEqual(summary[0]["value"], 1)
		self.assertEqual(summary[1]["value"], 1000)
		self.assertEqual(summary[2]["value"], 800)
		self.assertIn("date_applied", get_list.call_args.kwargs["filters"])
		self.assertTrue(any(c["fieldname"] == "department" for c in columns))
