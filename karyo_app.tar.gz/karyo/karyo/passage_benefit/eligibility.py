"""Shared, effective-dated Passage Benefit eligibility evaluation.

Bank initialisation, monthly/manual computation and ESS requests all call this
module so the client policy is enforced once and produces the same diagnostics.
"""

import frappe
from frappe import _
from frappe.utils import add_years, flt, getdate

CONFIRMATION_ONLY = "Confirmation only"
MINIMUM_SERVICE = "Minimum Service"
SALARY_THRESHOLD = "Salary Threshold"
SALARY_OR_SERVICE = "Salary or Service"
SALARY_AND_SERVICE = "Salary and Service"

LEGACY_MODES = {
	"Route-based (salary or service)": SALARY_OR_SERVICE,
	"All Conditions (AND)": SALARY_AND_SERVICE,
}


def _employee_facts(employee):
	return frappe.db.get_value(
		"Employee",
		employee,
		[
			"status",
			"pb_eligible",
			"karyo_date_confirmed",
			"karyo_date_joined_service",
			"date_of_joining",
			"employment_type",
			"karyo_employment_category",
			"karyo_permanent_pensionable",
		],
		as_dict=True,
	)


def _salary_at(employee, as_on):
	"""Return the submitted salary basis and its effective date as at ``as_on``."""
	row = frappe.db.get_value(
		"Salary Structure Assignment",
		{"employee": employee, "docstatus": 1, "from_date": ["<=", as_on]},
		["base", "from_date"],
		order_by="from_date desc",
		as_dict=True,
	)
	return (flt(row.base), getdate(row.from_date)) if row else (0.0, None)


def _is_permanent(facts):
	values = {
		str(facts.get("employment_type") or "").strip().lower(),
		str(facts.get("karyo_employment_category") or "").strip().lower(),
	}
	# PB-Setup Sheet2 row 5 is deliberately stricter than a generic
	# ``employment_type == Permanent`` check: non-pensionable employees are not
	# eligible.  The employee must therefore be both in the permanent category
	# and explicitly marked Permanent & Pensionable.
	permanent = bool(values.intersection({"permanent", "perm"}))
	return permanent and bool(facts.get("karyo_permanent_pensionable"))


def _failure(out, reason, message):
	out.reason = reason
	out.message = message
	out.block_reason = message
	out.eligibility_status = _("Not eligible")
	return out


def _rule(out, code, label, eligible, reason, blocking=True):
	"""Append one display-safe diagnostic without changing policy evaluation."""
	out.rules.append(
		{
			"code": code,
			"label": label,
			"eligible": bool(eligible),
			"status": _("Eligible") if eligible else _("Not eligible"),
			"reason": reason,
			"blocking": bool(blocking and not eligible),
		}
	)


def evaluate(employee, as_on, settings=None):
	"""Return eligibility, eligible-from date and rule diagnostics as at a date."""
	if settings is None:
		from karyo.passage_benefit.params import resolve

		settings = resolve(as_on)
	as_on = getdate(as_on)
	raw_mode = settings.get("eligibility_mode")
	mode = LEGACY_MODES.get(raw_mode, raw_mode)
	mode = mode or CONFIRMATION_ONLY
	facts = _employee_facts(employee)
	out = frappe._dict(
		eligible=False,
		eligibility_status=_("Not eligible"),
		reason="",
		message="",
		block_reason="",
		eligibility_mode=mode,
		rules=[],
		eligible_from_date=None,
		service_years=0,
		salary=0,
		salary_effective_date=None,
		salary_ok=False,
		service_ok=False,
		confirmation_ok=False,
		permanent_ok=False,
	)

	if not facts:
		_rule(out, "employee_exists", _("Employee record"), False,
			_("Employee {0} does not exist.").format(employee))
		return _failure(out, "employee_not_found", _("Employee {0} does not exist.").format(employee))
	_rule(
		out, "employee_active", _("Active employee"), facts.status == "Active",
		_("Employee is active.") if facts.status == "Active" else _("Employee {0} is not active.").format(employee),
	)
	if facts.status != "Active":
		return _failure(out, "employee_inactive", _("Employee {0} is not active.").format(employee))
	_rule(
		out, "pb_flag", _("Passage Benefit enabled"), bool(facts.pb_eligible),
		_("The Employee Passage Benefit flag is enabled.") if facts.pb_eligible else
		_("The Employee Passage Benefit flag is not set."),
	)
	if not facts.pb_eligible:
		return _failure(
			out,
			"flag_not_set",
			_("Employee {0} is not Passage Benefit eligible because the Employee PB flag is not set.").format(employee),
		)

	djs_raw = facts.karyo_date_joined_service or facts.date_of_joining
	djs = getdate(djs_raw) if djs_raw else None
	confirmed = getdate(facts.karyo_date_confirmed) if facts.karyo_date_confirmed else None
	confirmation_ok = bool(confirmed and confirmed <= as_on)
	permanent_ok = _is_permanent(facts)
	out.confirmation_ok = confirmation_ok
	out.permanent_ok = permanent_ok

	if settings.get("require_permanent_employee"):
		_rule(
			out, "permanent_employee", _("Permanent and pensionable"), permanent_ok,
			_("Employee is permanent and pensionable.") if permanent_ok else
			_("Only permanent and pensionable employees qualify for Passage Benefit."),
		)
	if settings.get("require_permanent_employee") and not permanent_ok:
		return _failure(
			out,
			"not_permanent",
			_("Employee {0} is not eligible because only permanent employees qualify for Passage Benefit.").format(employee),
		)
	if settings.get("require_confirmation") or mode == CONFIRMATION_ONLY:
		_rule(
			out, "confirmation", _("Confirmed employee"), confirmation_ok,
			_("Confirmation is effective from {0}.").format(confirmed) if confirmation_ok else
			_("No effective confirmation date exists as at {0}.").format(as_on),
		)
	if settings.get("require_confirmation") and not confirmation_ok:
		return _failure(
			out,
			"not_confirmed",
			_("Employee {0} is not eligible because no effective confirmation date exists as at {1}.").format(
				employee, as_on
			),
		)
	if not djs:
		_rule(out, "service_date", _("Service date available"), False,
			_("Date Joined Service or Date of Joining is missing."))
		return _failure(
			out,
			"service_date_missing",
			_("Employee {0} has no Date Joined Service or Date of Joining.").format(employee),
		)
	_rule(out, "service_date", _("Service date available"), True,
		_("Service date is {0}.").format(djs))

	threshold = flt(settings.get("min_salary_threshold"))
	min_years = int(settings.get("min_years_service") or 0)
	service_eligible_from = add_years(djs, min_years) if min_years > 0 else djs
	service_ok = service_eligible_from <= as_on
	salary, salary_effective_date = _salary_at(employee, as_on)
	salary_ok = salary >= threshold if threshold > 0 else True
	service_years = as_on.year - djs.year - ((as_on.month, as_on.day) < (djs.month, djs.day))
	out.update(
		service_years=service_years,
		salary=salary,
		salary_effective_date=salary_effective_date,
		salary_ok=salary_ok,
		service_ok=service_ok,
	)
	if mode in (SALARY_THRESHOLD, SALARY_AND_SERVICE, SALARY_OR_SERVICE):
		salary_reason = (
			_("Monthly salary {0} meets the minimum {1}.").format(salary, threshold)
			if salary_ok else _("Monthly salary {0} is below the minimum {1}.").format(salary, threshold)
		)
		_rule(
			out, "salary_threshold", _("Minimum salary"), salary_ok, salary_reason,
			blocking=mode != SALARY_OR_SERVICE or not service_ok,
		)
	if mode in (MINIMUM_SERVICE, SALARY_AND_SERVICE, SALARY_OR_SERVICE):
		service_reason = (
			_("Minimum service is met; eligible service date is {0}.").format(service_eligible_from)
			if service_ok else _("Minimum service is not met; eligible service date is {0}.").format(service_eligible_from)
		)
		_rule(
			out, "minimum_service", _("Minimum service"), service_ok, service_reason,
			blocking=mode != SALARY_OR_SERVICE or not salary_ok,
		)

	if mode == CONFIRMATION_ONLY:
		conditions_ok = confirmation_ok
		qualifying_dates = [confirmed]
	elif mode == MINIMUM_SERVICE:
		conditions_ok = service_ok
		qualifying_dates = [service_eligible_from]
	elif mode == SALARY_THRESHOLD:
		conditions_ok = salary_ok
		qualifying_dates = [salary_effective_date]
	elif mode == SALARY_AND_SERVICE:
		conditions_ok = salary_ok and service_ok
		qualifying_dates = [salary_effective_date, service_eligible_from]
	else:
		conditions_ok = salary_ok or service_ok
		qualifying_dates = []
		if salary_ok:
			qualifying_dates.append(salary_effective_date)
		if service_ok:
			qualifying_dates.append(service_eligible_from)

	if not conditions_ok:
		failed = []
		if mode in (SALARY_THRESHOLD, SALARY_AND_SERVICE, SALARY_OR_SERVICE) and not salary_ok:
			failed.append(_("salary threshold"))
		if mode in (MINIMUM_SERVICE, SALARY_AND_SERVICE, SALARY_OR_SERVICE) and not service_ok:
			failed.append(_("minimum service"))
		return _failure(
			out,
			"conditions_not_met",
			_("Employee {0} does not meet the configured Passage Benefit condition(s): {1}.").format(
				employee, _(" and ").join(failed) or _("eligibility policy")
			),
		)

	qualifying_dates = [getdate(value) for value in qualifying_dates if value]
	if raw_mode == "Route-based (salary or service)" and salary_ok:
		qualifying_dates = [confirmed or djs]
	elif mode == SALARY_OR_SERVICE and qualifying_dates:
		qualifying_dates = [min(qualifying_dates)]
	if settings.get("require_confirmation") and confirmed:
		# The legacy PB setup defines Date of Confirmation as the authoritative
		# Eligible From Date. Salary and service are eligibility gates evaluated as
		# at the computation date; they do not replace the recorded start date.
		out.eligible_from_date = confirmed
	else:
		out.eligible_from_date = max(qualifying_dates) if qualifying_dates else djs
	out.eligible = True
	out.eligibility_status = _("Eligible")
	out.message = _("All configured Passage Benefit eligibility conditions are satisfied.")
	out.block_reason = ""
	return out
