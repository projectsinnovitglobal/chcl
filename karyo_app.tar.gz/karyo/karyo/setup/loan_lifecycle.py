"""Karyo Loan lifecycle: guarantors, approval workflow, static deductions, settlement.

    bench --site dev.localhost execute karyo.setup.loan_lifecycle.setup

Adds guarantor + static-deduction child tables and lifecycle fields to Karyo
Loan, creates the loan deduction Salary Components (Deduction type), the
'Karyo Loan Committee' role, and the approval Workflow
(Draft -> Pending Committee -> Recommended -> Approved -> Disbursed -> Active
Loan -> Settled, + Rejected). Idempotent.
"""

import frappe
from frappe import _
from frappe.utils import add_days, add_months, flt, getdate, today
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype

DEDUCTION_COMPONENTS = {
	"Capital": ("Karyo Loan Capital", "KLC"),
	"Interest": ("Karyo Loan Interest", "KLI"),
	"Insurance": ("Karyo Loan Insurance", "KLIN"),
}

LOAN_COMPONENT_FIELDS = {
	"pdb_capital": "Karyo Loan Capital",
	"pdb_interest": "Karyo Loan Interest",
	"pdb_insurance": "Karyo Loan Insurance",
}

# Full client status model (Business Rules §6). doc_status: 0 = draft, 1 = submitted.
WORKFLOW_STATES = [
	("Draft", "0", "HR User"),
	("Printed", "0", "HR User"),
	("Approval Pending", "0", "HR User"),
	("Loan Committee Scheduled", "0", "Karyo Loan Committee"),
	("Under Loan Committee Review", "0", "Karyo Loan Committee"),
	("Recommended", "0", "Karyo Loan Committee"),
	("Pending", "0", "Karyo Loan Committee"),
	("Returned", "0", "HR User"),
	("Managing Director Approval Pending", "0", "HR Manager"),
	("Approved", "0", "HR Manager"),
	("Agreement Printed", "0", "HR Manager"),
	("Ready for Disbursement", "0", "Karyo Finance"),
	("Rejected", "0", "HR User"),
	("Disbursed", "0", "Karyo Finance"),
	("Active Loan", "1", "Karyo Finance"),
	("Settled", "1", "Karyo Finance"),
]
WORKFLOW_ACTIONS = [
	"Submit Application",
	"Print Application",
	"Submit for Approval",
	"Schedule Committee",
	"Approve Without Committee",
	"Start Review",
	"Recommend",
	"Keep Pending",
	"Reject",
	"Return for Rework",
	"Resubmit",
	"Send for MD Approval",
	"Approve",
	"Print Agreement",
	"Mark Ready for Disbursement",
	"Disburse",
	"Activate",
	"Settle",
]

# (state, action, next_state, allowed_role, condition-or-None). Committee/MD path
# runs when approval is required; a no-committee shortcut applies otherwise.
WORKFLOW_TRANSITIONS = [
	("Draft", "Submit Application", "Approval Pending", "Employee", 'doc.application_channel == "ESS" and doc.owner == frappe.session.user'),
	("Draft", "Print Application", "Printed", "HR User", None),
	("Printed", "Submit for Approval", "Approval Pending", "HR User", None),
	("Approval Pending", "Schedule Committee", "Loan Committee Scheduled", "HR User", "doc.is_approval_required"),
	("Approval Pending", "Approve Without Committee", "Approved", "HR Manager", "not doc.is_approval_required"),
	(
		"Loan Committee Scheduled",
		"Start Review",
		"Under Loan Committee Review",
		"Karyo Loan Committee",
		None,
	),
	("Under Loan Committee Review", "Recommend", "Recommended", "Karyo Loan Committee", None),
	("Under Loan Committee Review", "Keep Pending", "Pending", "Karyo Loan Committee", None),
	("Under Loan Committee Review", "Reject", "Rejected", "Karyo Loan Committee", None),
	("Under Loan Committee Review", "Return for Rework", "Returned", "Karyo Loan Committee", None),
	("Pending", "Recommend", "Recommended", "Karyo Loan Committee", None),
	("Pending", "Reject", "Rejected", "Karyo Loan Committee", None),
	("Pending", "Return for Rework", "Returned", "Karyo Loan Committee", None),
	("Returned", "Resubmit", "Approval Pending", "HR User", None),
	(
		"Recommended",
		"Send for MD Approval",
		"Managing Director Approval Pending",
		"HR Manager",
		"frappe.db.get_value('Loan Type', doc.loan_type, 'requires_md_approval')",
	),
	("Recommended", "Approve", "Approved", "HR Manager", "not frappe.db.get_value('Loan Type', doc.loan_type, 'requires_md_approval')"),
	("Recommended", "Reject", "Rejected", "HR Manager", None),
	("Recommended", "Return for Rework", "Returned", "HR Manager", None),
	("Managing Director Approval Pending", "Approve", "Approved", "HR Manager", None),
	("Managing Director Approval Pending", "Reject", "Rejected", "HR Manager", None),
	("Managing Director Approval Pending", "Return for Rework", "Returned", "HR Manager", None),
	("Approval Pending", "Approve Without Committee", "Approved", "Loan Approver", "not doc.is_approval_required"),
	("Recommended", "Approve", "Approved", "Loan Approver", "not frappe.db.get_value('Loan Type', doc.loan_type, 'requires_md_approval')"),
	("Recommended", "Reject", "Rejected", "Loan Approver", None),
	("Recommended", "Return for Rework", "Returned", "Loan Approver", None),
	("Recommended", "Send for MD Approval", "Managing Director Approval Pending", "Loan Approver", "frappe.db.get_value('Loan Type', doc.loan_type, 'requires_md_approval')"),
	("Managing Director Approval Pending", "Approve", "Approved", "Managing Director", None),
	("Managing Director Approval Pending", "Reject", "Rejected", "Managing Director", None),
	("Managing Director Approval Pending", "Return for Rework", "Returned", "Managing Director", None),
	("Approved", "Print Agreement", "Agreement Printed", "HR Manager", None),
	("Approved", "Return for Rework", "Returned", "HR Manager", None),
	("Agreement Printed", "Mark Ready for Disbursement", "Ready for Disbursement", "Karyo Finance", None),
	("Ready for Disbursement", "Disburse", "Disbursed", "Karyo Finance", None),
	("Disbursed", "Activate", "Active Loan", "Karyo Finance", None),
	("Active Loan", "Settle", "Settled", "Karyo Finance", None),
]


def create_components():
	for _type, (name, abbr) in DEDUCTION_COMPONENTS.items():
		if not frappe.db.exists("Salary Component", name):
			frappe.get_doc(
				{
					"doctype": "Salary Component",
					"salary_component": name,
					"salary_component_abbr": abbr,
					"type": "Deduction",
					"depends_on_payment_days": 0,
				}
			).insert(ignore_permissions=True)
			print(f"  + Salary Component: {name}")


def create_role(name):
	if not frappe.db.exists("Role", name):
		frappe.get_doc({"doctype": "Role", "role_name": name, "desk_access": 1}).insert(
			ignore_permissions=True
		)
		print(f"  + Role: {name}")


def create_child_doctypes():
	make_doctype(
		"Karyo Loan Guarantor",
		istable=1,
		fields=[
			f(
				"guarantor",
				"Link",
				"Guarantor",
				options="Employee",
				reqd=1,
				in_list_view=1,
				ignore_user_permissions=1,
			),
			f(
				"guarantor_name",
				"Data",
				"Name",
				fetch_from="guarantor.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("guarantor_status", "Data", "Status", fetch_from="guarantor.status", read_only=1),
			f("age", "Int", "Age", read_only=1, in_list_view=1),
			f("note", "Data", "Note"),
		],
	)
	make_doctype(
		"Karyo Loan Deduction",
		istable=1,
		fields=[
			f("component_type", "Data", "Component", in_list_view=1),
			f("salary_component", "Link", "Salary Component", options="Salary Component", in_list_view=1),
			f("monthly_amount", "Currency", "Monthly Amount", in_list_view=1),
			f("recurring_pdb", "Link", "Static PDB Entry", options="Employee Recurring PDB", read_only=1),
			f("additional_salary", "Link", "Additional Salary", options="Additional Salary", read_only=1),
			f("status", "Select", "Status", options="Active\nCancelled", default="Active", in_list_view=1),
		],
	)


def add_loan_fields():
	create_custom_fields(
		{
			"Karyo Loan": [
				{
					"fieldname": "workflow_state",
					"fieldtype": "Select",
					"label": "Workflow State",
					"options": "Draft\nPrinted\nApproval Pending\nLoan Committee Scheduled\nUnder Loan Committee Review\nRecommended\nPending\nReturned\nManaging Director Approval Pending\nApproved\nAgreement Printed\nReady for Disbursement\nRejected\nDisbursed\nActive Loan\nSettled",
					"default": "Draft",
					"read_only": 1,
					"in_standard_filter": 1,
					"allow_on_submit": 1,
					"insert_after": "status",
				},
				{
					"fieldname": "payment_method",
					"fieldtype": "Select",
					"label": "Payment Method",
					"options": "\nCash\nCheque\nBank Transfer",
					"insert_after": "repayment_start_date",
				},
				{
					"fieldname": "payment_reference",
					"fieldtype": "Data",
					"label": "Payment Reference",
					"insert_after": "payment_method",
				},
				{
					"fieldname": "guarantors_sb",
					"fieldtype": "Section Break",
					"label": "Guarantors",
					"insert_after": "schedule",
				},
				{
					"fieldname": "guarantors",
					"fieldtype": "Table",
					"label": "Guarantors",
					"options": "Karyo Loan Guarantor",
					"insert_after": "guarantors_sb",
				},
				{
					"fieldname": "deductions_sb",
					"fieldtype": "Section Break",
					"label": "Static Deductions",
					"insert_after": "guarantors",
				},
				{
					"fieldname": "deductions_posted",
					"fieldtype": "Check",
					"label": "Deductions Posted",
					"read_only": 1,
					"insert_after": "deductions_sb",
				},
				{
					"fieldname": "deductions",
					"fieldtype": "Table",
					"label": "Static Deductions",
					"options": "Karyo Loan Deduction",
					"insert_after": "deductions_posted",
				},
				{
					"fieldname": "settlement_date",
					"fieldtype": "Date",
					"label": "Settlement Date",
					"read_only": 1,
					"insert_after": "deductions",
				},
			]
		},
		ignore_validate=True,
	)
	print("  + Karyo Loan lifecycle fields ensured")


def create_workflow():
	for state, _ds, _role in WORKFLOW_STATES:
		if not frappe.db.exists("Workflow State", state):
			frappe.get_doc({"doctype": "Workflow State", "workflow_state_name": state, "style": ""}).insert(
				ignore_permissions=True
			)
	for action in WORKFLOW_ACTIONS:
		if not frappe.db.exists("Workflow Action Master", action):
			frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": action}).insert(
				ignore_permissions=True
			)

	states = [{"state": s, "doc_status": ds, "allow_edit": role} for s, ds, role in WORKFLOW_STATES]
	transitions = [
		{
			"state": s,
			"action": a,
			"next_state": ns,
			"allowed": role,
			"allow_self_approval": int(a == "Submit Application"),
			**({"condition": cond} if cond else {}),
		}
		for s, a, ns, role, cond in WORKFLOW_TRANSITIONS
	]
	# Operational roles keep their normal segregation, while a System Manager
	# has an explicit route through every loan step. This also makes the standard
	# Administrator account independent of custom role assignment drift.
	transitions.extend(
		{
			"state": s,
			"action": a,
			"next_state": ns,
			"allowed": "System Manager",
			"allow_self_approval": 1,
			"condition": " and ".join(filter(None, (
				f"({cond})" if cond else None,
				"frappe.session.user != 'Administrator' and not "
				f"frappe.db.get_value('Has Role', {{'parent': frappe.session.user, 'role': {role!r}}}, 'name')",
			))),
		}
		for s, a, ns, role, cond in WORKFLOW_TRANSITIONS
		if role != "System Manager"
	)

	# Upsert so re-running applies the current status model to an existing workflow.
	if frappe.db.exists("Workflow", "Karyo Loan Approval"):
		wf = frappe.get_doc("Workflow", "Karyo Loan Approval")
		# Repair legacy/misconfigured records as well as refreshing their rows.
		# The workflow name alone is not sufficient evidence that it is attached
		# to the intended document type.
		wf.document_type = "Karyo Loan"
		wf.workflow_state_field = "workflow_state"
		wf.send_email_alert = 0
		wf.set("states", states)
		wf.set("transitions", transitions)
		wf.is_active = 1
		wf.override_status = 1
		wf.save(ignore_permissions=True)
		print("  ~ Workflow updated: Karyo Loan Approval")
		return

	frappe.get_doc(
		{
			"doctype": "Workflow",
			"workflow_name": "Karyo Loan Approval",
			"document_type": "Karyo Loan",
			"is_active": 1,
			"override_status": 1,
			"workflow_state_field": "workflow_state",
			"send_email_alert": 0,
			"states": states,
			"transitions": transitions,
		}
	).insert(ignore_permissions=True)
	print("  + Workflow: Karyo Loan Approval")


def backfill_active_static_pdb_entries():
	"""Move legacy active-loan recurring Additional Salary sources into Static PDB."""
	if not frappe.get_meta("Karyo Loan Deduction").has_field("recurring_pdb"):
		return
	for row in frappe.get_all(
		"Karyo Loan Deduction", filters={"status": "Active"},
		fields=["name", "parent", "parenttype", "component_type", "salary_component", "monthly_amount", "additional_salary", "recurring_pdb"],
	):
		loan_name = row.parent if row.parenttype == "Karyo Loan" else frappe.db.get_value(row.parenttype, row.parent, "loan")
		if not loan_name:
			continue
		loan = frappe.db.get_value(
			"Karyo Loan", loan_name,
			["employee", "company", "status", "repayment_start_date", "disbursement_date", "planned_repayment_end_date", "period_months", "outstanding_capital", "outstanding_interest", "outstanding_insurance"],
			as_dict=True,
		)
		if not loan or loan.status != "Active" or flt(row.monthly_amount) <= 0 or not row.salary_component:
			continue
		if row.recurring_pdb and frappe.db.exists("Employee Recurring PDB", row.recurring_pdb):
			continue
		from karyo.payroll.recurring import static_deduction_pdb_code

		try:
			pdb_code = static_deduction_pdb_code(row.salary_component)
		except frappe.ValidationError:
			continue
		balance = flt(loan.get({"Capital": "outstanding_capital", "Interest": "outstanding_interest", "Insurance": "outstanding_insurance"}.get(row.component_type)))
		if balance <= 0:
			continue
		start = getdate(loan.repayment_start_date or loan.disbursement_date or today())
		end = loan.planned_repayment_end_date or add_days(add_months(start, int(loan.period_months or 1)), -1)
		recurring_name = frappe.db.get_value("Employee Recurring PDB", {
			"employee": loan.employee, "pdb_code": pdb_code, "loan_reference": loan_name,
			"status": ["in", ["Draft", "Active", "Suspended"]],
		}, "name")
		if not recurring_name:
			recurring = frappe.get_doc({
				"doctype": "Employee Recurring PDB", "employee": loan.employee,
				"company": loan.company, "pdb_code": pdb_code,
				"calculation_method": "Fixed Monthly", "amount": row.monthly_amount,
				"initial_balance": balance, "loan_reference": loan_name,
				"start_date": start, "end_date": end, "status": "Active",
				"remarks": _("{0} deduction for loan {1}").format(row.component_type, loan_name),
			}).insert(ignore_permissions=True)
			recurring_name = recurring.name
		frappe.db.set_value("Karyo Loan Deduction", row.name, "recurring_pdb", recurring_name, update_modified=False)
		if row.additional_salary and frappe.db.get_value("Additional Salary", row.additional_salary, "docstatus") == 1:
			additional = frappe.get_doc("Additional Salary", row.additional_salary)
			additional.flags.ignore_links = True
			additional.cancel()


def repair_swapped_loan_component_mappings():
	"""Repair only obvious swaps among the three canonical loan components.

	Custom loan components are intentionally preserved. This corrects legacy Loan
	Types where Interest and Insurance were accidentally configured in each
	other's field without overwriting client-specific mappings.
	"""
	if not frappe.db.table_exists("Loan Type"):
		return
	canonical = set(LOAN_COMPONENT_FIELDS.values())
	for row in frappe.get_all("Loan Type", fields=["name", *LOAN_COMPONENT_FIELDS]):
		updates = {
			fieldname: expected
			for fieldname, expected in LOAN_COMPONENT_FIELDS.items()
			if row.get(fieldname) in canonical and row.get(fieldname) != expected
		}
		if updates:
			frappe.db.set_value("Loan Type", row.name, updates, update_modified=False)


def setup():
	print("Karyo Loan lifecycle setup:")
	create_components()
	for role in (
		"Loan Applicant", "Loan Officer", "Karyo Loan Committee", "Loan Approver",
		"Managing Director", "Karyo Finance", "Payroll Finance", "Loan Auditor", "Loan Configuration Administrator",
	):
		create_role(role)
	create_child_doctypes()
	add_loan_fields()
	repair_swapped_loan_component_mappings()
	create_workflow()
	backfill_active_static_pdb_entries()
	frappe.db.commit()
	print("Done.")


def ensure_ess_submission_transition():
	"""Add the employee submission route without replacing configured approval rules."""
	action = "Submit Application"
	if not frappe.db.exists("Workflow Action Master", action):
		frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": action}).insert(ignore_permissions=True)
	name = frappe.db.get_value("Workflow", {"document_type": "Karyo Loan", "is_active": 1}, "name")
	if not name:
		frappe.throw("An active Karyo Loan workflow is required.")
	workflow = frappe.get_doc("Workflow", name)
	if not any(row.state == "Draft" and row.action == action and row.allowed == "Employee" for row in workflow.transitions):
		workflow.append("transitions", {"state": "Draft", "action": action, "next_state": "Approval Pending", "allowed": "Employee", "allow_self_approval": 1,
			"condition": 'doc.application_channel == "ESS" and doc.owner == frappe.session.user'})
		workflow.save(ignore_permissions=True)
