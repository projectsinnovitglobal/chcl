import unittest
from uuid import uuid4

import frappe
from karyo.hr import employee_claims as api


class TestEmployeeClaims(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('employee_claims_test')
        self.employee = frappe.get_doc('Employee', 'MBC/HR/00001')
        self.other = frappe.db.get_value('Employee', {'name': ('!=', self.employee.name), 'company':self.employee.company}, 'name')
        self.names=[]
        for index in range(27):
            name='claim-test-'+uuid4().hex
            frappe.get_doc({'doctype':'Expense Claim','name':name,'employee':self.employee.name if index<26 else self.other,
                'owner':self.employee.user_id,'company':self.employee.company,'posting_date':'2079-01-10',
                'status':'Draft' if index<25 else 'Unpaid','approval_status':'Draft','docstatus':0,
                'total_claimed_amount':100,'total_sanctioned_amount':0,'total_amount_reimbursed':0}).db_insert()
            self.names.append(name)
        frappe.set_user(self.employee.user_id)

    def tearDown(self):
        frappe.set_user('Administrator')
        frappe.db.rollback(save_point='employee_claims_test')
        frappe.set_user(self.user)

    def test_own_scope_and_pagination(self):
        first=api.get_claims(month='2079-01')
        self.assertEqual(first['expense_types'], frappe.get_all(
            'Expense Claim Type', pluck='name', order_by='expense_type asc'))
        self.assertTrue(first['expense_types'])
        self.assertEqual(first['total'],26)
        self.assertEqual(len(first['rows']),25)
        self.assertTrue(first['has_more'])
        second=api.get_claims(month='2079-01',start=25)
        self.assertEqual(len(second['rows']),1)
        self.assertFalse(second['has_more'])
        self.assertTrue(all(r.employee==self.employee.name for r in first['rows']+second['rows']))
        approved = frappe.get_doc('Expense Claim', self.names[0])
        approved.db_set('approval_status', 'Approved')
        self.assertEqual(api.get_claims(month='2079-01', status='Approved')['total'], 1)
        self.assertEqual(api.get_claims(month='2079-01', status='Approved')['rows'][0].display_status, 'Approved')

    def test_detail_ownership_and_edit_permission(self):
        record=api.get_record(self.names[0])
        self.assertEqual(record['employee'],self.employee.name)
        self.assertEqual(record['total_claimed_amount'],100)
        self.assertTrue(record['can_edit'])
        with self.assertRaises(frappe.PermissionError):api.get_record(self.names[-1])

    def test_invalid_filters_and_guest_are_denied(self):
        for month in ('invalid','2079-13'):
            with self.assertRaises(frappe.ValidationError):api.get_claims(month=month)
        with self.assertRaises(frappe.ValidationError):api.get_claims(status='unsupported')
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):api.get_claims()
