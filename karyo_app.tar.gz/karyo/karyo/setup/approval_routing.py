"""Approval-routing source markers and safe legacy-data backfill."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.hr.approval_routing import ROUTES, prepare_employee_approvers


def apply():
	create_custom_fields(
		{"Employee": [
			{"fieldname": "karyo_expense_approver_source", "fieldtype": "Select",
				"label": "Expense Approver Source", "options": "\nDepartment\nReporting Manager\nIndividual",
				"insert_after": "expense_approver", "hidden": 1, "no_copy": 1},
			{"fieldname": "karyo_leave_approver_source", "fieldtype": "Select",
				"label": "Leave Approver Source", "options": "\nDepartment\nReporting Manager\nIndividual",
				"insert_after": "leave_approver", "hidden": 1, "no_copy": 1},
			{"fieldname": "karyo_shift_approver_source", "fieldtype": "Select",
				"label": "Shift Approver Source", "options": "\nDepartment\nReporting Manager\nIndividual",
				"insert_after": "shift_request_approver", "hidden": 1, "no_copy": 1},
		]},
		ignore_validate=True,
	)
	backfill()
	frappe.clear_cache(doctype="Employee")
	print("  + Department/reporting approval routes configured")


def backfill():
	fields = [field for field in ROUTES] + [source for _table, source in ROUTES.values()]
	for name in frappe.get_all("Employee", pluck="name"):
		doc = frappe.get_doc("Employee", name)
		before = {field: doc.get(field) for field in fields}
		prepare_employee_approvers(doc)
		changed = {field: doc.get(field) for field in fields if doc.get(field) != before[field]}
		if changed:
			frappe.db.set_value("Employee", name, changed, update_modified=False)


def setup():
	apply()

