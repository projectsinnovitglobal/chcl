"""Governed MBC leave eligibility, bank and correction controls."""

import math

import frappe
from frappe import _, validate_and_sanitize_search_inputs
from frappe.utils import add_months, cint, cstr, flt, getdate, nowdate


RULE_FIELDS = [
	"karyo_is_retired",
	"karyo_mbc_leave_code", "karyo_min_service_months", "karyo_eligible_employment_categories",
	"karyo_eligible_gender", "karyo_requires_valid_contract", "karyo_max_days_per_application",
	"karyo_max_days_per_year", "karyo_max_days_total", "karyo_medical_certificate_after_days",
	"karyo_requires_attachment", "karyo_requires_leave_bank", "karyo_prerequisite_codes", "karyo_bank_type",
	"karyo_deducts_from_leave_type", "karyo_annual_entitlement_days",
]

LEAVE_DECISION_ROLES = {"System Manager", "HR Manager"}
PENDING_LEAVE_STATES = {"", "Open", "Pending"}
LOCKED_LEAVE_STATES = {"Approved", "Rejected", "Cancelled"}

LEAVE_APPLICATION_DETAIL_FIELDS = [
	"karyo_mbc_leave_code", "karyo_code_description", "karyo_paid", "is_lwp", "is_ppl",
	"fraction_of_daily_salary_per_leave", "allow_encashment", "earning_component",
	"karyo_bank_type", "karyo_requires_attachment",
]

LEAVE_SCHEME_CONDITIONS = (
	("General Leave policy", "All active employees", lambda employee: True),
	(
		"MBC Permanent Core Leave Policy", "Employment category is Permanent",
		lambda employee: cstr(employee.get("karyo_employment_category")).upper() in {"PERM", "PERMANENT"}
		or "PERMANENT" in cstr(employee.get("employment_type")).upper(),
	),
	(
		"MBC Contract Leave Policy", "Employment category is Contract",
		lambda employee: cstr(employee.get("karyo_employment_category")).upper() in {"CONT", "CONTRACT"}
		or "CONTRACT" in cstr(employee.get("employment_type")).upper(),
	),
	("MBC Maternity Leave Policy", "Gender is Female", lambda employee: employee.get("gender") == "Female"),
)

LEAVE_SCHEME_ELIGIBILITY_FIELDS = (
	"date_of_joining", "karyo_date_joined_service", "karyo_employment_category",
	"employment_type", "gender", "contract_end_date", "company", "status",
)


def _employee(employee):
	return frappe.db.get_value(
		"Employee", employee,
		["date_of_joining", "karyo_date_joined_service", "karyo_employment_category", "employment_type", "gender", "contract_end_date", "company", "status", "karyo_leave_scheme"],
		as_dict=True,
	)


def _submitted_policy_by_title():
	return {
		row.title: row.name for row in frappe.get_all(
			"Leave Policy", filters={"docstatus": 1}, fields=["name", "title"],
			limit_page_length=0,
		)
	}


def prepare_employee_leave_schemes(doc, method=None):
	"""Preserve HR selections and refresh attribute-driven Leave Schemes.

	An existing conditional row is regenerated only when one of the employee
	attributes that governs eligibility changes.  This distinction is important:
	removing a row in the Employee form is an explicit HR decision and must not be
	undone by this same before-validate hook.
	"""
	if not doc.meta.has_field("karyo_leave_schemes"):
		return
	previous = None if doc.is_new() else doc.get_doc_before_save()
	category_scheme = None
	if doc.get("karyo_employment_category"):
		category = frappe.db.get_value(
			"Employee Category", doc.karyo_employment_category,
			["map_dependencies", "leave_scheme", "disabled"], as_dict=True,
		)
		if category and cint(category.map_dependencies) and not cint(category.disabled):
			category_scheme = category.leave_scheme
	rows = []
	seen = set()
	for row in doc.get("karyo_leave_schemes") or []:
		if not row.leave_scheme or row.leave_scheme in seen:
			continue
		source = row.get("selection_source")
		if source == "Category" and row.leave_scheme != category_scheme:
			continue
		conditional = source == "Conditional"
		category_mapped = source == "Category"
		rows.append({
			"leave_scheme": row.leave_scheme,
			"selection_source": "Conditional" if conditional else "Category" if category_mapped else "Manual",
			"condition": row.get("condition") if conditional else _("Employee Category") if category_mapped else "",
			"is_active": 1 if category_mapped else cint(row.get("is_active", 1)),
		})
		seen.add(row.leave_scheme)
	if category_scheme and category_scheme not in seen:
		rows.insert(0, {
			"leave_scheme": category_scheme, "selection_source": "Category",
			"condition": _("Employee Category"), "is_active": 1,
		})
		seen.add(category_scheme)
	# Existing installations used one Link. Preserve it as the first explicit
	# selection when the multi-select table is initially introduced, or when HR
	# deliberately changes that Link.  Do not use it to resurrect a deleted row.
	primary_changed = previous and previous.get("karyo_leave_scheme") != doc.get("karyo_leave_scheme")
	if (doc.get("karyo_leave_scheme") and doc.karyo_leave_scheme not in seen
		and doc.karyo_leave_scheme != category_scheme and (not previous or primary_changed)):
		rows.insert(0, {
			"leave_scheme": doc.karyo_leave_scheme, "selection_source": "Manual",
			"condition": "", "is_active": 1,
		})
		seen.add(doc.karyo_leave_scheme)

	policies = _submitted_policy_by_title()
	refresh_conditional = not previous or any(
		previous.get(fieldname) != doc.get(fieldname) for fieldname in LEAVE_SCHEME_ELIGIBILITY_FIELDS
	)
	if refresh_conditional:
		rows = [row for row in rows if row["selection_source"] != "Conditional"]
		seen = {row["leave_scheme"] for row in rows}
	if refresh_conditional and doc.get("status") == "Active":
		for title, condition, applies in LEAVE_SCHEME_CONDITIONS:
			policy = policies.get(title)
			if policy and policy not in seen and applies(doc):
				rows.append({
					"leave_scheme": policy, "selection_source": "Conditional",
					"condition": condition, "is_active": 1,
				})
				seen.add(policy)
	doc.set("karyo_leave_schemes", rows)
	active = [row["leave_scheme"] for row in rows if cint(row["is_active"])]
	if doc.get("karyo_leave_scheme") not in active:
		doc.karyo_leave_scheme = policies.get("General Leave policy") if policies.get("General Leave policy") in active else (active[0] if active else None)


def sync_category_leave_scheme_selection(employee, leave_scheme):
	"""Keep the employee's multi-scheme list aligned with its category default."""
	if not frappe.db.exists("DocType", "Employee Leave Scheme Selection"):
		return
	frappe.db.delete("Employee Leave Scheme Selection", {
		"parent": employee,
		"parenttype": "Employee",
		"parentfield": "karyo_leave_schemes",
		"selection_source": "Category",
		"leave_scheme": ("!=", leave_scheme or ""),
	})
	if not leave_scheme:
		return
	existing = frappe.db.get_value("Employee Leave Scheme Selection", {
		"parent": employee,
		"parenttype": "Employee",
		"parentfield": "karyo_leave_schemes",
		"leave_scheme": leave_scheme,
	}, "name")
	if existing:
		frappe.db.set_value("Employee Leave Scheme Selection", existing, "is_active", 1, update_modified=False)
		return
	index = frappe.db.sql(
		"""select coalesce(max(idx), 0) from `tabEmployee Leave Scheme Selection`
		where parent=%s and parenttype='Employee' and parentfield='karyo_leave_schemes'""",
		(employee,),
	)[0][0]
	frappe.get_doc({
		"doctype": "Employee Leave Scheme Selection",
		"parent": employee,
		"parenttype": "Employee",
		"parentfield": "karyo_leave_schemes",
		"idx": cint(index) + 1,
		"leave_scheme": leave_scheme,
		"selection_source": "Category",
		"condition": _("Employee Category"),
		"is_active": 1,
	}).db_insert()


def _employee_leave_schemes(employee_name, primary=None):
	"""Return all active selected policies, retaining the legacy primary Link."""
	policies = []
	if frappe.db.exists("DocType", "Employee Leave Scheme Selection") and frappe.get_meta("Employee").has_field("karyo_leave_schemes"):
		policies = frappe.get_all(
			"Employee Leave Scheme Selection",
			filters={
				"parent": employee_name, "parenttype": "Employee",
				"parentfield": "karyo_leave_schemes", "is_active": 1,
			},
			pluck="leave_scheme", order_by="idx asc", limit_page_length=0,
		)
	primary = primary or frappe.db.get_value("Employee", employee_name, "karyo_leave_scheme")
	if primary:
		policies.insert(0, primary)
	return list(dict.fromkeys(policy for policy in policies if policy))


def backfill_employee_leave_schemes():
	"""Populate the new child table without firing unrelated Employee notifications."""
	if not frappe.db.exists("DocType", "Employee Leave Scheme Selection") or not frappe.get_meta("Employee").has_field("karyo_leave_schemes"):
		return 0
	updated = 0
	for name in frappe.get_all("Employee", pluck="name", limit_page_length=0):
		doc = frappe.get_doc("Employee", name)
		before = [(row.leave_scheme, row.selection_source, row.condition, cint(row.is_active)) for row in doc.karyo_leave_schemes]
		prepare_employee_leave_schemes(doc)
		after = [(row.leave_scheme, row.selection_source, row.condition, cint(row.is_active)) for row in doc.karyo_leave_schemes]
		if before == after:
			continue
		frappe.db.delete("Employee Leave Scheme Selection", {
			"parent": name, "parenttype": "Employee", "parentfield": "karyo_leave_schemes",
		})
		for index, row in enumerate(doc.karyo_leave_schemes, 1):
			frappe.get_doc({
				"doctype": "Employee Leave Scheme Selection", "parent": name,
				"parenttype": "Employee", "parentfield": "karyo_leave_schemes", "idx": index,
				"leave_scheme": row.leave_scheme, "selection_source": row.selection_source,
				"condition": row.condition, "is_active": row.is_active,
			}).db_insert()
		frappe.db.set_value("Employee", name, "karyo_leave_scheme", doc.karyo_leave_scheme, update_modified=False)
		updated += 1
	return updated


def _rules(leave_type):
	return frappe.db.get_value("Leave Type", leave_type, RULE_FIELDS, as_dict=True)


def _payroll_cycle_for_employee(employee, company, from_date, to_date=None):
	"""Resolve the one open payroll cycle that owns an employee transaction."""
	if not employee or not company or not from_date:
		return None
	to_date = to_date or from_date
	profile = frappe.db.get_value(
		"Employee", employee, ["karyo_payroll_type", "karyo_payroll_group"], as_dict=True,
	) or frappe._dict()
	rows = frappe.db.sql(
		"""
		select cycle.name, pay_day.payroll_type, pay_day.payroll_group
		from `tabPayroll Cycle` cycle
		inner join `tabPayroll Pay Day` pay_day on pay_day.name = cycle.pay_day
		where cycle.company = %(company)s
			and cycle.status not in ('Closed', 'Cancelled')
			and cycle.start_date <= %(from_date)s
			and cycle.end_date >= %(to_date)s
		order by cycle.creation desc
		""",
		{"company": company, "from_date": from_date, "to_date": to_date},
		as_dict=True,
	)
	if profile.karyo_payroll_type:
		rows = [row for row in rows if row.payroll_type == profile.karyo_payroll_type]
	if profile.karyo_payroll_group:
		# Prefer the employee's exact group. A Pay Day may intentionally cover all
		# groups for one payroll type, in which case its group is blank.
		exact = [row for row in rows if row.payroll_group == profile.karyo_payroll_group]
		rows = exact or [row for row in rows if not row.payroll_group]
	else:
		# An employee without a payroll group belongs to the ungrouped Pay Day.
		ungrouped = [row for row in rows if not row.payroll_group]
		if ungrouped:
			rows = ungrouped
	return rows[0].name if len(rows) == 1 else None


@frappe.whitelist()
def get_leave_type_details(leave_type):
	"""Return the display and payroll rule snapshot for a selected Leave Type."""
	if not leave_type:
		return {}
	row = frappe.db.get_value(
		"Leave Type", leave_type, LEAVE_APPLICATION_DETAIL_FIELDS, as_dict=True,
	)
	if not row:
		return {}
	return {
		"karyo_leave_code": row.karyo_mbc_leave_code,
		"karyo_leave_description": row.karyo_code_description,
		"karyo_paid_leave": cint(row.karyo_paid),
		"karyo_unpaid_leave": cint(row.is_lwp),
		"karyo_partially_paid_leave": cint(row.is_ppl),
		"karyo_paid_salary_fraction": flt(row.fraction_of_daily_salary_per_leave),
		"karyo_allow_encashment": cint(row.allow_encashment),
		"karyo_payroll_component": row.earning_component,
		"karyo_payroll_impact": cint(bool(row.is_lwp or row.is_ppl or row.allow_encashment)),
		"karyo_balance_source": row.karyo_bank_type,
		"karyo_attachment_required": cint(row.karyo_requires_attachment),
	}


def sync_leave_type_payroll_rules(doc, method=None):
	"""Keep the native payroll switches and encashment component usable together."""
	if doc.is_lwp:
		doc.karyo_paid = 0
	if not doc.allow_encashment:
		return
	if not doc.earning_component and frappe.db.exists("Salary Component", "Leave Encashment"):
		doc.earning_component = "Leave Encashment"
	if not doc.earning_component:
		frappe.throw(_("Select an Earning Component when Allow Encashment is checked."))
	component = frappe.db.get_value(
		"Salary Component", doc.earning_component, ["type", "disabled"], as_dict=True,
	)
	if not component or component.type != "Earning" or component.disabled:
		frappe.throw(_("Leave encashment requires an active Earning Salary Component."))


def validate_leave_type_parameters(doc, method=None):
	"""Reject invalid rule values before they can govern leave transactions."""
	for field in (
		"karyo_min_service_months", "karyo_max_days_per_application", "karyo_max_days_per_year",
		"karyo_max_days_total", "karyo_medical_certificate_after_days", "karyo_annual_entitlement_days",
		"karyo_bank_ceiling_days", "karyo_refund_cap_days", "karyo_refund_divisor",
		"karyo_advance_recovery_days",
	):
		value = flt(doc.get(field))
		if not math.isfinite(value) or value < 0:
			frappe.throw(_("{0} must be a non-negative number.").format(doc.meta.get_label(field)))
	code = doc.get("karyo_mbc_leave_code")
	for prerequisite in {v.strip() for v in (doc.get("karyo_prerequisite_codes") or "").split(",") if v.strip()}:
		if prerequisite == code:
			frappe.throw(_("A leave type cannot be its own prerequisite."))
		if not _leave_type_for_code(prerequisite):
			frappe.throw(_("Prerequisite Leave Code {0} does not exist.").format(prerequisite))


def notify_leave_parameters_changed(doc, method=None):
	frappe.publish_realtime("karyo_balance_updated", {
		"doctypes": ["Leave Type", "Leave Application", "Leave Allocation", "Leave Policy"],
	}, after_commit=True)


def _employee_ineligibility_reason(employee, rules, on_date):
	if not employee or employee.status != "Active":
		return _("Only an active employee can apply for this leave type.")
	service_start = employee.karyo_date_joined_service or employee.date_of_joining
	if rules.karyo_min_service_months and (
		not service_start or getdate(on_date) < add_months(getdate(service_start), rules.karyo_min_service_months)
	):
		return _("Requires at least {0} month(s) of service.").format(rules.karyo_min_service_months)
	categories = {v.strip() for v in (rules.karyo_eligible_employment_categories or "").split(",") if v.strip()}
	if categories and employee.karyo_employment_category not in categories:
		return _("Available only to these employment categories: {0}.").format(", ".join(sorted(categories)))
	if rules.karyo_eligible_gender and employee.gender != rules.karyo_eligible_gender:
		return _("Available only to employees whose gender is {0}.").format(rules.karyo_eligible_gender)
	if rules.karyo_requires_valid_contract and (
		not employee.contract_end_date or getdate(employee.contract_end_date) < getdate(on_date)
	):
		return _("A valid employment contract covering the leave date is required.")
	return None


def _is_employee_eligible(employee, rules, on_date):
	return not _employee_ineligibility_reason(employee, rules, on_date)


def _leave_type_for_code(code):
	return frappe.db.get_value("Leave Type", {"karyo_mbc_leave_code": code}, "name")


def leave_days_by_code(employee, code, year=None, exclude=None):
	"""Submitted approved days for a governed code, used by yearly/overall limits."""
	leave_type = _leave_type_for_code(code)
	if not leave_type:
		return 0
	filters = {"employee": employee, "leave_type": leave_type, "docstatus": 1, "status": "Approved"}
	if exclude:
		filters["name"] = ("!=", exclude)
	if year:
		filters.update(from_date=("<=", f"{int(year)}-12-31"), to_date=(">=", f"{int(year)}-01-01"))
		rows = frappe.get_all("Leave Application", filters=filters,
			fields=["leave_type", "from_date", "to_date", "total_leave_days", "half_day", "half_day_date"],
			limit_page_length=0)
		return sum(_leave_days_in_year(employee, row, year) for row in rows)
	return flt(frappe.db.get_value("Leave Application", filters, "sum(total_leave_days)"))


def _leave_days_in_year(employee, doc, year):
	"""Charge each calendar year's limit only for leave falling in that year."""
	from karyo.hr.settlement_balances import _leave_days

	start = max(getdate(doc.from_date), getdate(f"{year}-01-01"))
	end = min(getdate(doc.to_date), getdate(f"{year}-12-31"))
	return _leave_days(employee, doc, start, end)


def _prerequisite_balance(employee, code, on_date, exclude=None):
	if code == "SICK02":
		bank = _bank_values(employee)[0]
		return flt(bank.bank_days if bank else 0)
	if code == "SICK03":
		leave_type = _leave_type_for_code(code)
		limit = flt(_rules(leave_type).karyo_max_days_total) if leave_type else 0
		return max(0, limit - leave_days_by_code(employee, code, exclude=exclude))
	return _allocation_balance(employee, code, on_date)


def _leave_limit_reason(doc, rules):
	"""Share the configured duration limits between the preview and submission."""
	code = rules.karyo_mbc_leave_code
	if flt(rules.karyo_max_days_per_application) and flt(doc.total_leave_days) > flt(rules.karyo_max_days_per_application):
		return _("{0} cannot exceed {1} days per application.").format(doc.leave_type, rules.karyo_max_days_per_application)
	if flt(rules.karyo_max_days_per_year):
		for year in range(getdate(doc.from_date).year, getdate(doc.to_date or doc.from_date).year + 1):
			used = leave_days_by_code(doc.employee, code, year, exclude=doc.get("name"))
			if used + _leave_days_in_year(doc.employee, doc, year) > flt(rules.karyo_max_days_per_year):
				return _("{0} exceeds the {1}-day calendar-year limit for {2}.").format(doc.leave_type, rules.karyo_max_days_per_year, year)
	if flt(rules.karyo_max_days_total):
		bank = _bank_values(doc.employee)[0] if code == "SICK03" else None
		used = 0 if code == "SICK03" and bank and flt(bank.advance_balance_days) <= 0 else leave_days_by_code(doc.employee, code, exclude=doc.get("name"))
		if used + flt(doc.total_leave_days) > flt(rules.karyo_max_days_total):
			return _("{0} exceeds the overall limit of {1} days.").format(doc.leave_type, rules.karyo_max_days_total)
	return None


def _allocation_balance(employee, code, on_date):
	leave_type = _leave_type_for_code(code)
	if not leave_type:
		return 0
	from karyo.hr.lateness import effective_leave_balance
	try:
		return flt(effective_leave_balance(employee, leave_type, on_date))
	except (frappe.ValidationError, AttributeError, TypeError):
		return 0


def _bank_values(employee):
	return (
		frappe.db.get_value("Sick Leave Bank", {"employee": employee}, ["name", "status", "bank_days", "advance_balance_days"], as_dict=True),
		frappe.db.get_value("Vacation Leave Bank", {"employee": employee}, ["name", "status", "balance_days"], as_dict=True),
	)


def employee_standard_day_hours(employee, on_date=None):
	"""Return the employee's roster/shift working day, with the governed default as fallback."""
	on_date = getdate(on_date or nowdate())
	if employee:
		from karyo.hr.roster import employee_duty

		duty = employee_duty(employee, on_date)
		if duty and not cint(duty.get("is_rest_day")) and flt(duty.get("duty_hours")) > 0:
			return flt(duty.duty_hours)
	day_hours = flt(frappe.db.get_single_value("MBC Leave Settings", "standard_day_hours") or 8)
	if day_hours <= 0:
		frappe.throw(_("Standard Working Day (hours) must be greater than zero in Leave Parameters."))
	return day_hours


def is_two_hour_casual_permission(doc):
	code = doc.get("karyo_leave_code") or frappe.db.get_value(
		"Leave Type", doc.get("leave_type"), "karyo_mbc_leave_code"
	)
	return bool(
		code == "CASL01"
		and (
			cint(doc.get("karyo_two_hour_permission"))
			or (
				doc.get("karyo_leave_unit") == "Hours"
				and abs(flt(doc.get("karyo_requested_hours")) - 2.0) < 0.000001
			)
		)
	)


def casual_permission_balance_correction(employee, leave_type, from_date, to_date):
	"""Undo native HRMS' fixed half-day reading of approved fractional permissions."""
	if not employee or not leave_type or not from_date or not to_date:
		return 0.0
	if frappe.db.get_value("Leave Type", leave_type, "karyo_mbc_leave_code") != "CASL01":
		return 0.0
	permissions = frappe.get_all(
		"Leave Application",
		filters={
			"employee": employee, "leave_type": leave_type, "docstatus": 1,
			"status": "Approved", "karyo_two_hour_permission": 1,
			"from_date": (">=", from_date), "to_date": ("<=", to_date),
		},
		fields=["total_leave_days"], limit_page_length=0,
	)
	# get_leaves_for_period treats any non-integer application as 0.5 day. An
	# employee whose complete standard day is two hours produces an integer 1-day
	# permission, which native HRMS already reads correctly and needs no adjustment.
	correction = 0.0
	for row in permissions:
		actual = flt(row.total_leave_days)
		if actual % 1:
			correction += 0.5 - actual
	return correction


@frappe.whitelist()
def corrected_leave_details(employee, date, for_salary_slip=False):
	"""Return native leave details with exact two-hour permission consumption."""
	from hrms.hr.doctype.leave_application.leave_application import (
		get_leave_allocation_records,
		get_leave_details,
	)

	details = get_leave_details(employee, date, cint(for_salary_slip))
	allocations = get_leave_allocation_records(employee, date)
	for leave_type, row in details.get("leave_allocation", {}).items():
		allocation = allocations.get(leave_type)
		if not allocation:
			continue
		end_date = getdate(date) if cint(for_salary_slip) else allocation.to_date
		correction = casual_permission_balance_correction(
			employee, leave_type, allocation.from_date, end_date
		)
		if correction:
			row["remaining_leaves"] = flt(row.get("remaining_leaves")) + correction
			row["leaves_taken"] = max(0, flt(row.get("leaves_taken")) - correction)
	return details


def _normalize_hour_request(doc):
	if cint(doc.get("karyo_two_hour_permission")):
		code = doc.get("karyo_leave_code") or frappe.db.get_value(
			"Leave Type", doc.get("leave_type"), "karyo_mbc_leave_code"
		)
		if code != "CASL01":
			frappe.throw(_("A 2-Hour Permission can only be recorded against Casual Leave."))
		doc.karyo_leave_unit = "Hours"
		doc.karyo_requested_hours = 2
	if doc.get("karyo_leave_unit") != "Hours":
		return
	if getdate(doc.from_date) != getdate(doc.to_date):
		frappe.throw(_("An hour-based leave request must be for one date."))
	hours = flt(doc.get("karyo_requested_hours"))
	if hours <= 0:
		frappe.throw(_("Requested Hours must be greater than zero."))
	day_hours = employee_standard_day_hours(doc.get("employee"), doc.get("from_date"))
	if hours > day_hours:
		frappe.throw(_("Requested Hours cannot exceed the employee's {0}-hour working day.").format(day_hours))
	allowed = {2.0, day_hours / 2, day_hours}
	if not any(abs(hours - value) < 0.000001 for value in allowed):
		frappe.throw(_("Hour-based leave must be 2 hours, {0} hours (half day), or {1} hours (full day).").format(day_hours / 2, day_hours))
	code = doc.get("karyo_leave_code") or frappe.db.get_value(
		"Leave Type", doc.get("leave_type"), "karyo_mbc_leave_code"
	)
	if abs(hours - 2.0) < 0.000001 and code != "CASL01":
		frappe.throw(_("A 2-hour permission can only be recorded against Casual Leave."))
	doc.karyo_two_hour_permission = cint(code == "CASL01" and abs(hours - 2.0) < 0.000001)
	doc.half_day = cint(abs(hours - (day_hours / 2)) < 0.000001)
	doc.half_day_date = doc.from_date if doc.half_day else None
	doc.total_leave_days = round(hours / day_hours, 6)
	doc.karyo_standard_day_hours = day_hours
	doc.karyo_converted_leave_days = doc.total_leave_days


@frappe.whitelist()
def leave_duration_context(employee, on_date=None, requested_hours=2):
	"""Preview the employee-specific hours-to-leave conversion on both HR and ESS forms."""
	if frappe.session.user in (None, "", "Guest"):
		frappe.throw(_("Please sign in to calculate leave duration."), frappe.PermissionError)
	if not (
		frappe.has_permission("Leave Application", "create")
		or frappe.has_permission("Leave Application", "read")
	):
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	day_hours = employee_standard_day_hours(employee, on_date)
	hours = flt(requested_hours)
	return {
		"standard_day_hours": day_hours,
		"requested_hours": hours,
		"converted_leave_days": round(hours / day_hours, 6) if hours > 0 else 0,
	}


def validate_mbc_leave_rules(doc, method=None):
	"""Apply only rules explicitly configured on the selected Leave Type."""
	if doc.get("status") in ("Rejected", "Cancelled"):
		return
	rules = _rules(doc.leave_type)
	if not rules:
		return
	if cint(rules.karyo_is_retired):
		frappe.throw(_("This leave type is retired and cannot be requested."))
	employee = _employee(doc.employee)
	if not employee:
		return
	_normalize_hour_request(doc)
	if rules.karyo_mbc_leave_code and not (doc.get("description") or "").strip():
		frappe.throw(_("Reason is required for a governed MBC leave request."))
	reason = (_employee_ineligibility_reason(employee, rules, doc.from_date)
		or _employee_ineligibility_reason(employee, rules, doc.to_date or doc.from_date))
	if reason:
		frappe.throw(_("{0}: {1}").format(doc.leave_type, reason))
	if reason := _leave_limit_reason(doc, rules):
		frappe.throw(reason)
	code = rules.karyo_mbc_leave_code
	if code == "CASL01" and _allocation_balance(doc.employee, code, doc.from_date) < flt(doc.total_leave_days):
		frappe.throw(_("Insufficient Casual Leave balance for this request."))
	sick_bank, vacation_bank = _bank_values(doc.employee)
	for prerequisite in [v.strip() for v in (rules.karyo_prerequisite_codes or "").split(",") if v.strip()]:
		balance = _prerequisite_balance(doc.employee, prerequisite, doc.from_date, exclude=doc.name)
		if balance > 0:
			prerequisite_name = _leave_type_for_code(prerequisite) or prerequisite
			frappe.throw(_("{0} must be exhausted before applying for {1}.").format(prerequisite_name, doc.leave_type))
	if rules.karyo_bank_type == "Sick Leave Bank":
		if not sick_bank or sick_bank.status != "Active":
			frappe.throw(_("An active Sick Leave Bank is required for {0}.").format(doc.leave_type))
		if code not in ("SICK03", "SICK04") and flt(sick_bank.bank_days) < flt(doc.total_leave_days):
			frappe.throw(_("Insufficient active Sick Leave Bank balance for {0}.").format(doc.leave_type))
	if rules.karyo_bank_type == "Vacation Leave Bank":
		if not vacation_bank or vacation_bank.status != "Active" or flt(vacation_bank.balance_days) < flt(doc.total_leave_days):
			frappe.throw(_("Insufficient active Vacation Leave Bank balance for {0}.").format(doc.leave_type))
	if cint(rules.karyo_requires_leave_bank) and rules.karyo_bank_type not in ("Sick Leave Bank", "Vacation Leave Bank"):
		from karyo.hr.lateness import effective_leave_balance

		balance_type = rules.karyo_deducts_from_leave_type or doc.leave_type
		if flt(effective_leave_balance(doc.employee, balance_type, doc.from_date)) < flt(doc.total_leave_days):
			frappe.throw(_("Insufficient allocation balance for {0}.").format(balance_type))
	if code == "SICK03" and sick_bank and flt(sick_bank.advance_balance_days) > 0:
		frappe.throw(_("A further Advance Sick Leave Full Pay request is allowed only after the prior advance is fully recovered."))


def apply_request_source(doc, method=None):
	"""Distinguish ESS requests from HR/Registry entry without bypassing approval."""
	# Leave requests are workflow records, not stationery.  A stale company or
	# browser default must never make saving a request depend on a Letter Head.
	if doc.meta.has_field("letter_head"):
		doc.letter_head = None
	if not doc.leave_type or not frappe.db.get_value("Leave Type", doc.leave_type, "karyo_mbc_leave_code"):
		return
	employee_user = frappe.db.get_value("Employee", doc.employee, "user_id") if doc.employee else None
	roles = set(frappe.get_roles(frappe.session.user))
	if employee_user == frappe.session.user:
		doc.karyo_source_channel = "Employee Self Service"
	elif not doc.karyo_source_channel:
		doc.karyo_source_channel = "HR" if roles.intersection({"HR User", "HR Manager", "System Manager"}) else "Supervisor"
	if doc.is_new():
		doc.status = "Open"


def validate_leave_lifecycle(doc, method=None):
	"""Pending requests are editable; every decided/cancelled request is immutable."""
	if doc.is_new() or doc.flags.get("allow_leave_lifecycle_transition"):
		return
	previous = doc.get_doc_before_save()
	if previous and previous.status in LOCKED_LEAVE_STATES:
		frappe.throw(
			_("This leave request is locked because its status is {0}.").format(previous.status),
			frappe.ValidationError,
		)


def can_decide_leave_application(doc):
	roles = set(frappe.get_roles())
	return bool(
		frappe.session.user == "Administrator"
		or roles.intersection(LEAVE_DECISION_ROLES)
		or doc.get("leave_approver") == frappe.session.user
	)


def _reconcile_attendance_for_approved_leave(doc):
	"""Let native submission replace pre-generated Present rows with On Leave.

	HRMS already updates an existing Attendance row during ``on_submit``, but its
	validation blocks that same update when the row is Present/Work From Home.
	Temporarily marking only the conflicting rows Absent keeps the whole operation
	in one database transaction; native submission immediately converts them to
	On Leave/Half Day, and a later failure rolls everything back.
	"""
	if is_two_hour_casual_permission(doc):
		return []
	if not doc.employee or not doc.from_date or not doc.to_date:
		return []
	rows = frappe.get_all(
		"Attendance",
		filters={
			"employee": doc.employee,
			"attendance_date": ("between", [doc.from_date, doc.to_date]),
			"status": ("in", ["Present", "Work From Home"]),
			"docstatus": 1,
			"half_day_status": ("!=", "Absent"),
		},
		fields=["name", "attendance_date"],
		order_by="attendance_date asc",
	)
	for row in rows:
		frappe.db.set_value("Attendance", row.name, "status", "Absent", update_modified=False)
	return rows


@frappe.whitelist(methods=["POST"])
def decide_leave_application(name, decision, reason=None):
	"""Approve/reject and submit atomically, so a displayed decision is final."""
	if decision not in ("Approved", "Rejected"):
		frappe.throw(_("Decision must be Approved or Rejected."))
	doc = frappe.get_doc("Leave Application", name)
	doc.check_permission("read")
	if not can_decide_leave_application(doc):
		frappe.throw(_("Only the assigned leave approver or an administrator can decide this request."), frappe.PermissionError)
	if doc.docstatus != 0 or doc.status == "Cancelled":
		frappe.throw(_("Only a pending leave request can be approved or rejected."))
	if doc.status not in PENDING_LEAVE_STATES | {"Approved", "Rejected"}:
		frappe.throw(_("This leave request is not awaiting a decision."))
	doc.flags.ignore_permissions = True
	doc.flags.allow_leave_lifecycle_transition = True
	doc.status = decision
	reconciled_attendance = _reconcile_attendance_for_approved_leave(doc) if decision == "Approved" else []
	doc.save(ignore_permissions=True)
	doc.flags.ignore_permissions = True
	doc.flags.allow_leave_lifecycle_transition = True
	doc.submit()
	if reason:
		doc.add_comment("Comment", _("{0} reason: {1}").format(decision, cstr(reason).strip()))
	if reconciled_attendance:
		doc.add_comment(
			"Comment",
			_("Approval reconciled {0} existing attendance row(s) to this leave request.").format(
				len(reconciled_attendance),
			),
		)
	return {
		"name": doc.name,
		"status": doc.status,
		"docstatus": doc.docstatus,
		"attendance_reconciled": len(reconciled_attendance),
		"message": _("Leave request {0} was {1} and locked.").format(doc.name, decision.lower()),
	}


@frappe.whitelist(methods=["POST"])
def activate_leave_allocation(name):
	"""Submit an HR-created quota so it immediately enters the employee ledger."""
	doc = frappe.get_doc("Leave Allocation", name)
	doc.check_permission("read")
	if frappe.session.user != "Administrator" and not set(frappe.get_roles()).intersection(
		{"System Manager", "HR Manager", "HR User"}
	):
		frappe.throw(_("Only HR administrators can activate a leave allocation."), frappe.PermissionError)
	if doc.docstatus == 1:
		return {"name": doc.name, "docstatus": doc.docstatus, "message": _("Leave quota is already active.")}
	if doc.docstatus != 0:
		frappe.throw(_("Only a draft leave allocation can be activated."))
	doc.flags.ignore_permissions = True
	doc.submit()
	return {
		"name": doc.name,
		"docstatus": doc.docstatus,
		"message": _("Leave quota activated and synchronized to the employee leave bank."),
	}


@frappe.whitelist(methods=["POST"])
def cancel_pending_leave_application(name):
	"""Let the employee withdraw a still-pending request while retaining its audit row."""
	doc = frappe.get_doc("Leave Application", name)
	doc.check_permission("read")
	if not _can_view_employee_leave(doc.employee):
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	if doc.docstatus != 0 or (doc.status or "Open") not in PENDING_LEAVE_STATES:
		frappe.throw(_("Only a pending leave request can be cancelled."))
	doc.flags.ignore_permissions = True
	doc.flags.allow_leave_lifecycle_transition = True
	doc.status = "Cancelled"
	doc.save(ignore_permissions=True)
	return {
		"name": doc.name,
		"status": doc.status,
		"message": _("Leave request {0} was cancelled and locked.").format(doc.name),
	}


def sync_leave_transaction(doc, method=None):
	"""Project every Leave Application into the governed transaction register."""
	if not frappe.db.exists("DocType", "Leave Transaction") or not doc.name or not doc.leave_type:
		return
	type_row = frappe.db.get_value(
		"Leave Type", doc.leave_type,
		LEAVE_APPLICATION_DETAIL_FIELDS, as_dict=True,
	)
	if not type_row or not type_row.karyo_mbc_leave_code:
		return
	name = frappe.db.get_value("Leave Transaction", {"leave_request_id": doc.name}, "name")
	transaction = frappe.get_doc("Leave Transaction", name) if name else frappe.new_doc("Leave Transaction")
	cancelled = cint(doc.docstatus == 2 or doc.status == "Cancelled")
	approved = doc.status == "Approved"
	permission = is_two_hour_casual_permission(doc)
	transaction.update({
		"leave_request_id": doc.name,
		"employee": doc.employee,
		"employee_name": doc.employee_name,
		"leave_code": type_row.karyo_mbc_leave_code,
		"leave_type": doc.leave_type,
		"leave_description": type_row.karyo_code_description,
		"start_date": doc.from_date,
		"end_date": doc.to_date,
		"duration_units": flt(doc.total_leave_days),
		# duration_units is the normalized ledger quantity and therefore always
		# remains in days. The original hour request is retained alongside it.
		"duration_unit": "Days",
		"two_hour_permission": cint(permission),
		"requested_hours": flt(doc.get("karyo_requested_hours")) if permission else 0,
		"standard_day_hours": flt(doc.get("karyo_standard_day_hours")) if permission else 0,
		"equivalent_leave_days": flt(doc.total_leave_days) if permission else 0,
		"half_day": cint(doc.half_day),
		"reason_code": cstr(doc.description)[:140],
		"legacy_status": doc.status or ("Cancelled" if cancelled else "Open"),
		"applied_date": doc.posting_date or getdate(doc.creation),
		"approved_date": (transaction.approved_date or getdate(doc.modified)) if approved else None,
		"cancelled": cancelled,
		"cancellation_date": getdate(doc.modified) if cancelled else None,
		"source_record_audit_ref": f"Leave Application / {doc.name}",
		"lwp_payroll_period": _payroll_cycle_for_employee(
			doc.employee, doc.company, doc.from_date, doc.to_date,
		) if (type_row.is_lwp or type_row.is_ppl) else None,
		"paid_leave": cint(type_row.karyo_paid),
		"unpaid_leave": cint(type_row.is_lwp),
		"partially_paid_leave": cint(type_row.is_ppl),
		"payroll_impact": cint(bool(type_row.is_lwp or type_row.is_ppl or type_row.allow_encashment)),
		"attachment_required": cint(type_row.karyo_requires_attachment),
	})
	transaction.flags.ignore_permissions = True
	if transaction.is_new():
		transaction.insert(ignore_permissions=True)
	else:
		transaction.save(ignore_permissions=True)


def delete_leave_transaction(doc, method=None):
	"""Remove a draft application's projection when the source itself is deleted."""
	name = frappe.db.get_value("Leave Transaction", {"leave_request_id": doc.name}, "name")
	if name:
		frappe.delete_doc("Leave Transaction", name, ignore_permissions=True, force=True)


def sync_all_leave_transactions():
	"""Idempotently backfill the transaction register from existing applications."""
	if not frappe.db.exists("DocType", "Leave Transaction"):
		return 0
	count = 0
	for name in frappe.get_all("Leave Application", pluck="name", order_by="creation asc", limit_page_length=0):
		sync_leave_transaction(frappe.get_doc("Leave Application", name))
		count += 1
	return count


def validate_required_attachment(doc, method=None):
	if doc.status != "Approved":
		return
	rules = _rules(doc.leave_type)
	if not rules:
		return
	required = bool(rules.karyo_requires_attachment)
	if rules.karyo_medical_certificate_after_days:
		required = required and flt(doc.total_leave_days) > flt(rules.karyo_medical_certificate_after_days)
	if required and not frappe.db.exists("File", {"attached_to_doctype": "Leave Application", "attached_to_name": doc.name}):
		frappe.throw(_("Attach the required supporting document before submitting {0}.").format(doc.leave_type))


def validate_leave_correction(doc, method=None):
	"""Corrections must point to a cancelled application; originals are never rewritten."""
	original_name = doc.get("karyo_replaces_leave_application")
	if not original_name:
		return
	if original_name == doc.name:
		frappe.throw(_("A Leave Application cannot replace itself."))
	if not doc.get("karyo_correction_reason"):
		frappe.throw(_("Correction Reason is required when replacing a Leave Application."))
	original = frappe.db.get_value(
		"Leave Application", original_name, ["employee", "docstatus"], as_dict=True
	)
	if not original:
		frappe.throw(_("The replaced Leave Application does not exist."))
	if original.employee != doc.employee:
		frappe.throw(_("The replacement must belong to the same employee."))
	if original.docstatus != 2:
		frappe.throw(_("The original Leave Application must be cancelled before a replacement is created."))


def validate_closed_period_cancellation(doc, method=None):
	"""A cancellation affecting a closed payroll needs payroll authority and evidence."""
	governed = frappe.db.get_value("Leave Type", doc.leave_type, "karyo_mbc_leave_code")
	roles = set(frappe.get_roles(frappe.session.user))
	if governed:
		if frappe.session.user != "Administrator" and not roles.intersection({"HR User", "HR Manager", "System Manager"}):
			frappe.throw(_("Only an HR user may cancel approved leave."), frappe.PermissionError)
		if not doc.get("karyo_cancellation_reason"):
			frappe.throw(_("Cancellation Reason is required before approved leave can be cancelled."))
	closed_cycle = frappe.db.exists(
		"Payroll Cycle",
		{
			"company": doc.company,
			"status": "Closed",
			"start_date": ("<=", doc.to_date),
			"end_date": (">=", doc.from_date),
		},
	)
	if not closed_cycle:
		return
	if "Payroll Approver" not in frappe.get_roles(frappe.session.user):
		frappe.throw(_("Only a Payroll Approver may cancel leave affecting a closed payroll period."))
	if not doc.get("karyo_cancellation_approval_reference"):
		frappe.throw(_("Closed-period Cancellation Approval is required."))


def apply_bank_movement(doc, method=None):
	"""Post or reverse custom bank movements once, alongside the native leave ledger."""
	if method == "on_submit" and doc.status != "Approved":
		return
	if method == "on_cancel":
		previous_status = frappe.db.get_value(
			"Leave Transaction", {"leave_request_id": doc.name}, "legacy_status",
		)
		if previous_status != "Approved":
			return
	rules = _rules(doc.leave_type)
	if not rules or not rules.karyo_mbc_leave_code:
		return
	direction = -1 if method == "on_submit" else 1
	days = flt(doc.total_leave_days) * direction
	code = rules.karyo_mbc_leave_code
	if rules.karyo_bank_type == "Vacation Leave Bank":
		name = frappe.db.get_value("Vacation Leave Bank", {"employee": doc.employee}, "name", for_update=True)
		if not name:
			frappe.throw(_("Vacation Leave Bank is not initialized for this employee."))
		balance = flt(frappe.db.get_value("Vacation Leave Bank", name, "balance_days")) + days
		frappe.db.set_value("Vacation Leave Bank", name, "balance_days", balance)
		from karyo.karyo.doctype.vacation_leave_bank.vacation_leave_bank import refresh_balance_counters
		refresh_balance_counters(name)
	elif rules.karyo_bank_type == "Sick Leave Bank":
		name = frappe.db.get_value("Sick Leave Bank", {"employee": doc.employee}, "name", for_update=True)
		if not name:
			frappe.throw(_("Sick Leave Bank is not initialized for this employee."))
		if code in ("SICK03", "SICK04"):
			advance = flt(frappe.db.get_value("Sick Leave Bank", name, "advance_balance_days")) - days
			frappe.db.set_value("Sick Leave Bank", name, "advance_balance_days", max(0, advance))
		else:
			balance = flt(frappe.db.get_value("Sick Leave Bank", name, "bank_days")) + days
			frappe.db.set_value("Sick Leave Bank", name, "bank_days", balance)
		from karyo.karyo.doctype.sick_leave_bank.sick_leave_bank import refresh_balance_counters
		refresh_balance_counters(name)


def eligible_leave_types(employee, on_date=None):
	person = _employee(employee)
	if not person:
		return []
	on_date = getdate(on_date or nowdate())
	fields = ["name", *RULE_FIELDS, "karyo_code_description"]
	rows = frappe.get_all(
		"Leave Type", filters={
			"karyo_mbc_leave_code": ("is", "set"), "karyo_is_retired": 0,
		}, fields=fields,
		order_by="karyo_mbc_leave_group asc, karyo_mbc_leave_code asc", limit_page_length=0,
	)
	return [row for row in rows if _is_employee_eligible(person, row, on_date)]


def allocated_leave_type_names(employee, on_date=None):
	"""Current submitted Leave Allocation types visible to the requesting user."""
	if not employee:
		return []
	on_date = getdate(on_date or nowdate())
	return frappe.get_list(
		"Leave Allocation",
		filters={
			"employee": employee, "docstatus": 1,
			"from_date": ("<=", on_date), "to_date": (">=", on_date),
		},
		pluck="leave_type", order_by="leave_type asc", limit_page_length=0,
	)


@frappe.whitelist()
@validate_and_sanitize_search_inputs
def eligible_leave_type_query(doctype, txt, searchfield, start, page_len, filters):
	"""Return only leave types the selected employee is currently eligible to apply for."""
	needle = (txt or "").lower()
	filters = frappe._dict(filters or {})
	employee = _employee(filters.get("employee"))
	if not employee:
		return []
	on_date = getdate(filters.get("on_date") or nowdate())
	rows = frappe.get_all(
		"Leave Type",
		filters={
			"karyo_mbc_leave_code": ("is", "set"), "karyo_is_retired": 0,
		},
		fields=["name", "karyo_code_description", *RULE_FIELDS],
		order_by="karyo_mbc_leave_code asc",
		limit_page_length=0,
	)
	rows = [
		row for row in rows
		if _is_employee_eligible(employee, row, on_date) and (
			not needle
			or needle in row.name.lower()
			or needle in (row.karyo_mbc_leave_code or "").lower()
			or needle in (row.karyo_code_description or "").lower()
		)
	]
	return [[row.name, row.karyo_mbc_leave_code, row.karyo_code_description] for row in rows[cint(start):cint(start) + cint(page_len)]]


@frappe.whitelist()
@validate_and_sanitize_search_inputs
def leave_type_catalogue_query(doctype, txt, searchfield, start, page_len, filters):
	"""Show the complete active catalogue; eligibility is explained after selection."""
	needle = (txt or "").lower()
	rows = frappe.get_all(
		"Leave Type",
		filters={"karyo_is_retired": 0},
		fields=["name", "karyo_mbc_leave_code", "karyo_code_description"],
		order_by="karyo_mbc_leave_group asc, karyo_mbc_leave_code asc, name asc",
		limit_page_length=0,
	)
	rows = [
		row for row in rows
		if not needle
		or needle in row.name.lower()
		or needle in (row.karyo_mbc_leave_code or "").lower()
		or needle in (row.karyo_code_description or "").lower()
	]
	return [
		[row.name, row.karyo_mbc_leave_code or "", row.karyo_code_description or ""]
		for row in rows[cint(start):cint(start) + cint(page_len)]
	]


def _can_view_employee_leave(employee):
	if frappe.session.user == "Administrator" or set(frappe.get_roles()).intersection(LEAVE_DECISION_ROLES):
		return True
	return frappe.db.get_value("Employee", employee, "user_id") == frappe.session.user


def _leave_eligibility(
	employee, leave_type, on_date=None, to_date=None, balances=None,
	person=None, rules=None, type_row=None, calculate_days=True,
):
	"""Return one display-safe eligibility result without changing entitlement data."""
	on_date = getdate(on_date or nowdate())
	to_date = getdate(to_date or on_date)
	person = person or _employee(employee)
	type_row = type_row or frappe.db.get_value(
		"Leave Type", leave_type,
		["karyo_code_description", "is_lwp", *RULE_FIELDS], as_dict=True,
	)
	rules = rules or type_row
	result = frappe._dict(
		leave_type=leave_type,
		leave_code=type_row.karyo_mbc_leave_code if type_row else None,
		description=type_row.karyo_code_description if type_row else None,
		eligible=False,
		reason=None,
		available=None,
		requested_days=None,
	)
	if not person:
		result.reason = _("Employee record was not found.")
		return result
	if not type_row or cint(type_row.karyo_is_retired):
		result.reason = _("This leave type is not active.")
		return result
	if not rules:
		result.eligible = True
		result.reason = _("Eligible under the standard leave rules.")
		return result
	reason = (_employee_ineligibility_reason(person, rules, on_date)
		or _employee_ineligibility_reason(person, rules, to_date))
	if reason:
		result.reason = reason
		return result

	if balances is None:
		from karyo.hr.self_service import leave_balances
		balances = leave_balances(employee, on_date)
	balance = next((row for row in balances if row.get("leave_type") == leave_type), None)
	if not balance and rules.karyo_deducts_from_leave_type:
		balance = next((row for row in balances if row.get("leave_type") == rules.karyo_deducts_from_leave_type), None)
	if not balance and rules.karyo_bank_type == "Sick Leave Bank":
		balance = next((row for row in balances if row.get("leave_code") == "SICK02"), None)
	if not balance and rules.karyo_bank_type == "Vacation Leave Bank":
		balance = next((row for row in balances if row.get("leave_code") == "VAC01"), None)
	if balance:
		result.available = flt(balance.get("remaining"))

	needs_balance = bool(
		cint(rules.karyo_requires_leave_bank)
		or rules.karyo_bank_type in ("Annual Allocation", "Sick Leave Bank", "Vacation Leave Bank")
	)
	if needs_balance and (not balance or flt(balance.get("remaining")) <= 0):
		result.reason = _("No available allocation or leave-bank balance for this leave type.")
		return result

	for prerequisite in [v.strip() for v in (rules.karyo_prerequisite_codes or "").split(",") if v.strip()]:
		if _prerequisite_balance(employee, prerequisite, on_date) > 0:
			result.reason = _("{0} must be exhausted first.").format(_leave_type_for_code(prerequisite) or prerequisite)
			return result

	if calculate_days and on_date and to_date:
		try:
			from hrms.hr.doctype.leave_application.leave_application import get_number_of_leave_days
			result.requested_days = flt(get_number_of_leave_days(
				employee, leave_type, on_date, to_date, 0, None,
			))
		except (frappe.ValidationError, TypeError, ValueError):
			result.requested_days = None
	if result.requested_days is not None:
		request = frappe._dict(employee=employee, leave_type=leave_type, from_date=on_date,
			to_date=to_date, total_leave_days=result.requested_days, half_day=0)
		if reason := _leave_limit_reason(request, rules):
			result.reason = reason
			return result
	if needs_balance and result.requested_days is not None and result.available is not None and (
		result.requested_days > result.available
	):
		result.reason = _("Only {0} day(s) are currently available.").format(result.available)
		return result

	result.eligible = True
	result.reason = (
		_("Eligible · {0} day(s) currently available.").format(result.available)
		if result.available is not None else _("Eligible for this leave type.")
	)
	return result


@frappe.whitelist()
def leave_type_eligibility(employee, leave_type, from_date=None, to_date=None):
	if frappe.session.user == "Guest" or not _can_view_employee_leave(employee):
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	return _leave_eligibility(employee, leave_type, from_date, to_date)


@frappe.whitelist()
@validate_and_sanitize_search_inputs
def allocatable_leave_type_query(doctype, txt, searchfield, start, page_len, filters):
	"""Return the complete saved Leave Type catalogue for manual allocation."""
	needle = (txt or "").lower()
	rows = frappe.get_all(
		"Leave Type",
		filters={"karyo_mbc_leave_code": ("is", "set"), "karyo_is_retired": 0},
		fields=["name", "karyo_mbc_leave_code", "karyo_code_description"],
		order_by="karyo_mbc_leave_code asc",
		limit_page_length=0,
	)
	rows = [
		row for row in rows
		if not needle
		or needle in row.name.lower()
		or needle in (row.karyo_mbc_leave_code or "").lower()
		or needle in (row.karyo_code_description or "").lower()
	]
	return [[row.name, row.karyo_mbc_leave_code, row.karyo_code_description] for row in rows[cint(start):cint(start) + cint(page_len)]]


def _prorated_entitlement(employee, rules, year):
	start, end = getdate(f"{year}-01-01"), getdate(f"{year}-12-31")
	service_start = employee.karyo_date_joined_service or employee.date_of_joining
	if employee.date_of_joining:
		start = max(start, getdate(employee.date_of_joining))
	if rules.karyo_min_service_months and service_start:
		start = max(start, add_months(getdate(service_start), rules.karyo_min_service_months))
	if employee.contract_end_date:
		end = min(end, getdate(employee.contract_end_date))
	if start > end:
		return 0
	days_in_year = (getdate(f"{year}-12-31") - getdate(f"{year}-01-01")).days + 1
	eligible_days = (end - start).days + 1
	# Operational leave is posted in half-day units, so proration must not create
	# balances such as 4.438356 days that employees cannot actually request.
	return round(flt(rules.karyo_annual_entitlement_days) * eligible_days / days_in_year * 2) / 2


def ensure_employee_leave_entitlements(employee_name, on_date=None):
	"""Synchronize one active employee's selected scheme and eligibility rules.

	The Employee's Leave Scheme is the primary source. Additional annual
	entitlements (for example a newly eligible gender/service rule) are included
	automatically. Existing submitted allocations are reconciled through the
	native update-after-submit ledger path; approved leave is never invalidated.
	"""
	employee = _employee(employee_name)
	policies = _employee_leave_schemes(employee_name, employee.karyo_leave_scheme if employee else None)
	if not employee or employee.status != "Active" or not policies:
		return {"employee": employee_name, "allocations_created": 0, "allocations_updated": 0, "banks_created": 0}
	primary_policy = employee.karyo_leave_scheme or policies[0]
	on_date = getdate(on_date or nowdate())
	year = on_date.year
	from_date, to_date = getdate(f"{year}-01-01"), getdate(f"{year}-12-31")
	counts = {"employee": employee_name, "allocations_created": 0, "allocations_updated": 0, "banks_created": 0}

	if not frappe.db.exists("Sick Leave Bank", {"employee": employee_name}):
		allotment = flt(frappe.db.get_single_value("MBC Leave Settings", "advance_sick_full_pay_limit") or 180)
		frappe.get_doc({
			"doctype": "Sick Leave Bank", "employee": employee_name, "status": "Active",
			"opening_bank_days": 0, "bank_days": 0, "advance_allotted_days": allotment,
		}).insert(ignore_permissions=True)
		counts["banks_created"] += 1
	if not frappe.db.exists("Vacation Leave Bank", {"employee": employee_name}):
		frappe.get_doc({
			"doctype": "Vacation Leave Bank", "employee": employee_name, "status": "Active",
			"opening_balance_days": 0, "balance_days": 0,
		}).insert(ignore_permissions=True)
		counts["banks_created"] += 1

	policy_rows = frappe.get_all(
		"Leave Policy Detail",
		filters={"parent": ("in", policies), "parenttype": "Leave Policy", "docstatus": 1},
		fields=["leave_type", "annual_allocation"], order_by="idx asc", limit_page_length=0,
	)
	desired = {}
	for row in policy_rows:
		if flt(row.annual_allocation) > 0:
			# Schemes overlap by design (General + Permanent/Contract). The higher
			# applicable quota wins; overlapping schemes must never double a balance.
			desired[row.leave_type] = max(desired.get(row.leave_type, 0), flt(row.annual_allocation))
	policy_leave_types = set(desired)
	# Eligibility rules can add a new entitlement on an anniversary or after an
	# employee attribute changes, without requiring HR to reselect the scheme.
	for row in eligible_leave_types(employee_name, on_date):
		if row.karyo_bank_type == "Annual Allocation" and flt(row.karyo_annual_entitlement_days) > 0:
			desired.setdefault(row.name, flt(row.karyo_annual_entitlement_days))
	# A submitted opening balance is a carried-forward amount in addition to the
	# employee's current scheme entitlement. Preserve it during daily/settings
	# reconciliation so the admin posting and employee counter cannot drift apart.
	if frappe.db.exists("DocType", "Leave Opening Balance"):
		for opening in frappe.get_all(
			"Leave Opening Balance",
			filters={
				"employee": employee_name, "docstatus": 1,
				"balance_source": "Annual Allocation",
				"balance_as_at_date": ("<", to_date), "allocation_to_date": (">=", from_date),
			},
			fields=["leave_type", "balance_days"], limit_page_length=0,
		):
			desired[opening.leave_type] = flt(desired.get(opening.leave_type)) + flt(opening.balance_days)

	for leave_type, annual in desired.items():
		rules = _rules(leave_type)
		is_policy_entitlement = leave_type in policy_leave_types
		# The selected Leave Scheme is authoritative. A policy row must not be
		# silently ignored just because an older/custom Leave Type has incomplete
		# Karyo balance-source metadata. Rule-derived additions, on the other hand,
		# are allocations only when explicitly configured as Annual Allocation.
		if not is_policy_entitlement and (not rules or rules.karyo_bank_type != "Annual Allocation"):
			continue
		if frappe.db.get_value("Leave Type", leave_type, "is_lwp"):
			continue
		# A selected policy is an explicit HR entitlement. Rules still add other
		# eligible types, but do not remove a policy row merely because a legacy
		# category code is blank or differently named.
		calculation_rules = frappe._dict(rules)
		calculation_rules.karyo_annual_entitlement_days = annual
		# Selecting a scheme is an explicit HR grant.  Type-level eligibility
		# controls may add entitlements outside the scheme, but must not suppress
		# one of the quotas that HR deliberately included in the selected scheme.
		if leave_type in policy_leave_types:
			calculation_rules.karyo_min_service_months = 0
		amount = _prorated_entitlement(employee, calculation_rules, year)
		if amount <= 0:
			continue
		name = frappe.db.get_value(
			"Leave Allocation",
			{"employee": employee_name, "leave_type": leave_type, "docstatus": 1,
				"from_date": ("<=", on_date), "to_date": (">=", on_date)},
			"name",
		)
		if name:
			allocation = frappe.get_doc("Leave Allocation", name)
			# Keep older allocations connected to the Employee's authoritative
			# scheme too; many pre-date the scheme-driven synchronizer.
			if allocation.leave_policy != primary_policy:
				frappe.db.set_value(
					"Leave Allocation", allocation.name, "leave_policy",
					primary_policy, update_modified=False,
				)
				allocation.leave_policy = primary_policy
			current_amount = flt(allocation.new_leaves_allocated)
			# Settings reconciliation may grant an increase, but it must never
			# silently withdraw a submitted entitlement. A reduction can invalidate
			# approved leave and must be handled through an explicit HR correction.
			if amount > current_amount:
				from hrms.hr.doctype.leave_allocation.leave_allocation import LessAllocationError

				allocation.new_leaves_allocated = amount
				allocation.flags.ignore_permissions = True
				try:
					allocation.save()
				except LessAllocationError:
					# Historical approved leave is authoritative. Leave this allocation
					# untouched for explicit HR reconciliation instead of failing setup.
					frappe.clear_messages()
					continue
				counts["allocations_updated"] += 1
			continue
		allocation = frappe.get_doc({
			"doctype": "Leave Allocation", "employee": employee_name, "leave_type": leave_type,
			"from_date": from_date, "to_date": to_date, "new_leaves_allocated": amount,
			"leave_policy": primary_policy,
		})
		allocation.flags.ignore_permissions = True
		allocation.insert()
		allocation.submit()
		counts["allocations_created"] += 1
	return counts


def sync_leave_policy_entitlements(doc, method=None):
	"""Immediately project a submitted Leave Scheme change to its employees."""
	if cint(doc.get("docstatus")) != 1:
		return
	employees = set(frappe.get_all(
		"Employee",
		filters={"status": "Active", "karyo_leave_scheme": doc.name},
		pluck="name",
		limit_page_length=0,
	))
	if frappe.db.exists("DocType", "Employee Leave Scheme Selection"):
		employees.update(frappe.get_all(
			"Employee Leave Scheme Selection",
			filters={"leave_scheme": doc.name, "parenttype": "Employee", "is_active": 1},
			pluck="parent", limit_page_length=0,
		))
	for employee_name in employees:
		ensure_employee_leave_entitlements(employee_name)


def sync_leave_settings_and_entitlements(doc, method=None):
	"""Apply entitlement settings and refresh affected employee allocations now."""
	from karyo.setup.leave import sync_leave_settings

	sync_leave_settings(doc, method)
	sync_all_employee_leave_schemes()
	notify_leave_parameters_changed(doc, method)


def sync_employee_leave_scheme(doc, method=None):
	"""Employee hook: apply the saved Leave Scheme immediately and idempotently."""
	if doc.get("status") == "Active" and _employee_leave_schemes(doc.name, doc.get("karyo_leave_scheme")):
		ensure_employee_leave_entitlements(doc.name)


def sync_all_employee_leave_schemes():
	"""Daily/setup reconciliation for anniversaries and changed eligibility."""
	result = {"employees": 0, "allocations_created": 0, "allocations_updated": 0, "banks_created": 0}
	for employee in frappe.get_all("Employee", filters={"status": "Active"}, pluck="name", limit_page_length=0):
		row = ensure_employee_leave_entitlements(employee)
		if not _employee_leave_schemes(employee):
			continue
		result["employees"] += 1
		for field in ("allocations_created", "allocations_updated", "banks_created"):
			result[field] += cint(row[field])
	return result


@frappe.whitelist(methods=["POST"])
def initialize_leave_banks(company, year, entitlement_date=None):
	"""Bulk-open governed calendar-year allocations and sick/vacation banks."""
	if not set(frappe.get_roles()).intersection({"HR User", "HR Manager", "System Manager"}):
		frappe.throw(_("Only HR may initialize leave banks."), frappe.PermissionError)
	year = cint(year)
	if year < 2000 or year > 2100:
		frappe.throw(_("Choose a valid leave year."))
	if not frappe.db.exists("Company", company):
		frappe.throw(_("Choose a valid company."))
	from_date, to_date = getdate(f"{year}-01-01"), getdate(f"{year}-12-31")
	entitlement_date = getdate(entitlement_date or from_date)
	if entitlement_date.year != year:
		frappe.throw(_("Entitlement Date must be within the selected leave year."))
	counts = {"employees": 0, "sick_banks": 0, "vacation_banks": 0, "allocations": 0}
	advance_allotment = flt(
		frappe.db.get_single_value("MBC Leave Settings", "advance_sick_full_pay_limit") or 180
	)
	for employee_name in frappe.get_all("Employee", filters={"company": company, "status": "Active"}, pluck="name", limit_page_length=0):
		employee = _employee(employee_name)
		counts["employees"] += 1
		if not frappe.db.exists("Sick Leave Bank", {"employee": employee_name}):
			frappe.get_doc({
				"doctype": "Sick Leave Bank", "employee": employee_name,
				"opening_bank_days": 0, "bank_days": 0,
				"advance_allotted_days": advance_allotment,
			}).insert(ignore_permissions=True)
			counts["sick_banks"] += 1
		if not frappe.db.exists("Vacation Leave Bank", {"employee": employee_name}):
			frappe.get_doc({"doctype": "Vacation Leave Bank", "employee": employee_name, "opening_balance_days": 0, "balance_days": 0}).insert(ignore_permissions=True)
			counts["vacation_banks"] += 1
		for row in eligible_leave_types(employee_name, entitlement_date):
			if row.karyo_bank_type != "Annual Allocation" or not row.karyo_annual_entitlement_days:
				continue
			if frappe.db.exists("Leave Allocation", {"employee": employee_name, "leave_type": row.name, "docstatus": 1, "from_date": from_date, "to_date": to_date}):
				continue
			amount = _prorated_entitlement(employee, row, year)
			if amount <= 0:
				continue
			allocation = frappe.get_doc({
				"doctype": "Leave Allocation", "employee": employee_name, "leave_type": row.name,
				"from_date": from_date, "to_date": to_date, "new_leaves_allocated": amount,
				"description": _("MBC governed leave initialization for {0}").format(year),
			})
			allocation.flags.ignore_permissions = True
			allocation.insert()
			allocation.submit()
			counts["allocations"] += 1
	frappe.db.commit()
	return counts


def ensure_employee_advance_sick_allotment(doc, method=None):
	"""Initialize the recoverable Advance Sick facility for a new active employee."""
	if doc.status != "Active":
		return
	if frappe.db.exists("Sick Leave Bank", {"employee": doc.name}):
		return
	allotment = flt(
		frappe.db.get_single_value("MBC Leave Settings", "advance_sick_full_pay_limit") or 180
	)
	frappe.get_doc({
		"doctype": "Sick Leave Bank", "employee": doc.name, "status": "Active",
		"opening_bank_days": 0, "bank_days": 0,
		"advance_allotted_days": allotment,
	}).insert(ignore_permissions=True)
