"""Activate the official MRA 2026/27 PAYE reference and retire the demo version."""

import json

import frappe


OFFICIAL_CONFIGURATION = "MRA-PAYE-2026-27-OFFICIAL-1"
DEMO_CONFIGURATION = "DEMO-PAYE-2026-DEMO-1"
MRA_SOURCE = (
	"https://www.mra.mu/individuals/reliefs-deductions-allowances; "
	"https://www.mra.mu/employers/paye"
)
APPROVAL_REFERENCE = "Production selection authorised by user on 2026-09-28"


def execute():
	"""Correct, approve and select the official 2026/27 PAYE configuration."""
	year_name = frappe.db.get_value(
		"Payroll PAYE Year",
		{"tax_year": ("in", ["2026-27", "2026-2027", "2026/2027"]), "company": "MBC"},
		"name",
		order_by="modified desc",
	)
	if not year_name:
		return

	configuration = _official_configuration(year_name)
	_update_paye_year(year_name, configuration.name)
	frappe.db.set_single_value(
		"Karyo Payroll Settings", "default_paye_configuration", configuration.name
	)

	# Open records must use the production selection. Closed cycles and their
	# statutory results retain their original configuration for audit history.
	frappe.db.set_value(
		"Payroll Cycle",
		{
			"paye_configuration": DEMO_CONFIGURATION,
			"docstatus": 0,
			"status": ("not in", ["Closed"]),
		},
		"paye_configuration",
		configuration.name,
		update_modified=False,
	)

	if frappe.db.exists("Payroll Configuration Version", DEMO_CONFIGURATION):
		demo = frappe.get_doc("Payroll Configuration Version", DEMO_CONFIGURATION)
		if demo.configuration_status == "Demo":
			demo.approval_reference = "Retired when official MRA 2026/27 configuration was activated"
			demo.configuration_status = "Retired"
			demo.save(ignore_permissions=True)


def _official_configuration(year_name):
	payload = {
		"income_year": "2026/2027",
		"periods": 13,
		"monthly_no_paye_threshold": 38462,
		"bands": [
			{"upper_chargeable_income": 500000, "tax_rate": 0},
			{"upper_chargeable_income": 1000000, "tax_rate": 10},
			{"is_open_ended": 1, "tax_rate": 20},
		],
		"dependent_reliefs": [110000, 190000, 275000, 355000],
		"fair_share_threshold": 12000000,
		"fair_share_rate": 15,
	}
	if not frappe.db.exists("Payroll Configuration Version", OFFICIAL_CONFIGURATION):
		frappe.get_doc(
			{
				"doctype": "Payroll Configuration Version",
				"config_key": "MRA-PAYE-2026-27",
				"configuration_type": "PAYE",
				"company": "MBC",
				"version": "OFFICIAL-1",
				"configuration_status": "Draft",
				"effective_from": "2026-07-01",
				"effective_to": "2027-06-30",
				"source_reference": MRA_SOURCE,
			}
		).insert(ignore_permissions=True)

	doc = frappe.get_doc("Payroll Configuration Version", OFFICIAL_CONFIGURATION)
	if doc.configuration_status == "Draft":
		doc.update(
			{
				"approval_reference": APPROVAL_REFERENCE,
				"configuration_json": json.dumps(payload, indent=2),
				"reference_doctype": "Payroll PAYE Year",
				"reference_name": year_name,
				"notes": "Official MRA 2026/27 PAYE rules selected for production.",
			}
		)
		doc.save(ignore_permissions=True)
		doc.configuration_status = "Validated"
		doc.save(ignore_permissions=True)
	if doc.configuration_status == "Validated":
		doc.configuration_status = "Approved"
		doc.save(ignore_permissions=True)
	if doc.configuration_status == "Approved":
		doc.configuration_status = "Active"
		doc.is_production_eligible = 1
		doc.save(ignore_permissions=True)
	return doc


def _update_paye_year(year_name, configuration_name):
	doc = frappe.get_doc("Payroll PAYE Year", year_name)
	doc.update(
		{
			"tax_year": "2026/2027",
			"version": "OFFICIAL-1",
			"company": "MBC",
			"currency": "MUR",
			"periods_per_year": 13,
			"currency_precision": 0,
			"band_boundary_rounding": "Exact Fraction",
			"no_edf_rate": 15,
			"no_edf_optional_rate": 20,
			"monthly_no_paye_threshold": 38462,
			"director_flat_rate": 15,
			"fair_share_threshold": 12000000,
			"fair_share_rate": 15,
			"dependent_1_relief": 110000,
			"dependent_2_relief": 190000,
			"dependent_3_relief": 275000,
			"dependent_4_plus_relief": 355000,
			"effective_from": "2026-07-01",
			"effective_to": "2027-06-30",
			"is_active": 1,
			"configuration_version": configuration_name,
			"source_reference": MRA_SOURCE,
		}
	)
	doc.set("bands", [])
	for upper, rate, open_ended in ((500000, 0, 0), (1000000, 10, 0), (None, 20, 1)):
		doc.append(
			"bands",
			{
				"upper_chargeable_income": upper,
				"tax_rate": rate,
				"is_open_ended": open_ended,
			},
		)
	doc.save(ignore_permissions=True)
