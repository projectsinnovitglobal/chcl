"""Backfill approval and processing audit fields on existing PB claims."""

import frappe


def execute():
	if not frappe.db.table_exists("Passage Benefit Application"):
		return
	if not frappe.db.has_column("Passage Benefit Application", "approved_amount"):
		return

	frappe.db.sql(
		"""
		UPDATE `tabPassage Benefit Application`
		SET approved_amount = CASE
				WHEN COALESCE(approved_amount, 0) = 0 THEN claimable_amount
				ELSE approved_amount
			END,
			approval_date = COALESCE(approval_date, DATE(modified))
		WHERE workflow_state IN ('Approved', 'Processed')
		"""
	)
	frappe.db.sql(
		"""
		UPDATE `tabPassage Benefit Application`
		SET processed_date = COALESCE(processed_date, DATE(modified)),
			payment_reference = COALESCE(
				NULLIF(payment_reference, ''),
				NULLIF(processed_reference, ''),
				additional_salary
			)
		WHERE workflow_state = 'Processed' OR processed = 1
		"""
	)
	frappe.db.sql(
		"""
		UPDATE `tabPassage Benefit Application`
		SET migration_status = 'Not Migrated'
		WHERE COALESCE(migration_status, '') = ''
		"""
	)
