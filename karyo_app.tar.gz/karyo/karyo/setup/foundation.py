"""Programmatic creation of Karyo foundation + Passage Benefit DocTypes.

Run once (developer_mode on) to scaffold DocTypes as files:
    bench --site dev.localhost execute karyo.setup.foundation.create_all

DocType JSON is exported to the module folder in developer mode, then
the controllers are hand-authored. Re-running is idempotent (skips existing).
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

MODULE = "Karyo"
ROLES = ["System Manager", "HR Manager", "HR User"]


def _perms(submittable=False):
	perms = []
	for role in ROLES:
		p = {
			"role": role,
			"read": 1,
			"write": 1,
			"create": 1,
			"delete": 1,
			"report": 1,
			"export": 1,
			"print": 1,
			"email": 1,
			"share": 1,
		}
		if submittable:
			p.update({"submit": 1, "cancel": 1, "amend": 1})
		perms.append(p)
	return perms


def make_doctype(
	name,
	fields,
	*,
	issingle=0,
	istable=0,
	is_submittable=0,
	autoname=None,
	naming_rule=None,
	title_field=None,
	track_changes=1,
	sort_field="modified",
	sort_order="DESC",
):
	if frappe.db.exists("DocType", name):
		print(f"  = DocType exists: {name}")
		return
	doc = {
		"doctype": "DocType",
		"name": name,
		"module": MODULE,
		"custom": 0,
		"issingle": issingle,
		"istable": istable,
		"is_submittable": is_submittable,
		"track_changes": track_changes,
		"sort_field": sort_field,
		"sort_order": sort_order,
		"fields": fields,
		"permissions": [] if istable else _perms(submittable=bool(is_submittable)),
	}
	if autoname:
		doc["autoname"] = autoname
	if naming_rule:
		doc["naming_rule"] = naming_rule
	if title_field:
		doc["title_field"] = title_field
	frappe.get_doc(doc).insert(ignore_permissions=True)
	print(f"  + Created DocType: {name}")


def f(fieldname, fieldtype, label=None, **kw):
	d = {"fieldname": fieldname, "fieldtype": fieldtype}
	if label is not None:
		d["label"] = label
	d.update(kw)
	return d


def create_settings():
	make_doctype(
		"Karyo Settings",
		issingle=1,
		fields=[
			f("computation_sb", "Section Break", "Computation Defaults"),
			f("rounding_precision", "Int", "Rounding Precision (decimals)", default="2"),
			f(
				"rounding_method",
				"Select",
				"Rounding Method",
				options="Round Half Up\nRound Half to Even",
				default="Round Half Up",
			),
			f(
				"day_count_basis",
				"Select",
				"Day-count Basis",
				options="365 Fixed\nActual (366 in leap years)",
				default="365 Fixed",
			),
			f("modules_sb", "Section Break", "Module Toggles"),
			f("enable_passage_benefit", "Check", "Enable Passage Benefit", default="1"),
			f("enable_loan_management", "Check", "Enable Loan Management", default="0"),
			f("enable_prb_payroll", "Check", "Enable PRB Payroll", default="0"),
		],
	)
	make_doctype(
		"Passage Benefit Settings",
		issingle=1,
		fields=[
			f("entitlement_sb", "Section Break", "Entitlement Rules"),
			f("pb_percentage", "Percent", "Passage Benefit %", default="5"),
			f(
				"salary_basis",
				"Select",
				"Salary Basis",
				options="Monthly Gross x 12\nAnnual Gross\nBasic Salary",
				default="Monthly Gross x 12",
			),
			f("min_years_service", "Int", "Minimum Years of Service", default="5"),
			f("min_salary_threshold", "Currency", "Minimum Monthly Salary Threshold", default="37290"),
			f(
				"leap_year_treatment",
				"Select",
				"Leap-year Denominator",
				options="Always 365\n366 in leap years",
				default="366 in leap years",
			),
			f("default_min_balance_credit", "Currency", "Default Minimum Balance Credit", default="0"),
			f(
				"configuration_version",
				"Link",
				"Approved Configuration Version",
				options="Payroll Configuration Version",
			),
			f("posting_cb", "Column Break"),
			f("non_taxable", "Check", "Passage Benefit is Non-taxable", default="1"),
			f(
				"entitlement_operation_code", "Link", "Operation Code for Entitlement / Salary Basis",
				options="Payroll Operation Code",
			),
			f("adjustment_operation_code", "Link", "Operation Code for Adjustment", options="Payroll Operation Code"),
			f("payroll_pdb_type", "Link", "Payroll PDB Type", options="Payroll PDB Type"),
			f("payroll_pdb_code", "Link", "Payroll PDB Code", options="Payroll PDB Code"),
			f("pdb_salary_component", "Link", "Payroll Component (PDB)", options="Salary Component"),
			f("controls_sb", "Section Break", "Eligibility & Controls"),
			f(
				"eligibility_mode", "Select", "Eligibility Mode",
				options=(
					"Confirmation only\nMinimum Service\nSalary Threshold\nSalary or Service\n"
					"Salary and Service\nRoute-based (salary or service)\nAll Conditions (AND)"
				),
				default="Salary and Service",
			),
			f("require_confirmation", "Check", "Require Confirmed Employee", default="1"),
			f("require_permanent_employee", "Check", "Require Permanent Employee", default="1"),
			f("require_payroll_closure", "Check", "Require Payroll Closure Before Computation", default="1"),
			f("controls_cb", "Column Break"),
			f(
				"min_balance_timing", "Select", "Minimum Balance Timing",
				options="Before claim\nAfter claim", default="Before claim",
			),
			f(
				"insufficient_balance_treatment", "Select", "Insufficient Balance Treatment",
				options="Block\nCap", default="Block",
			),
			f("allow_negative_balance", "Check", "Allow Negative Balance (Override)", default="0"),
			f("vacation_leave_type", "Link", "Vacation Leave Type", options="Leave Type"),
		],
	)


def create_employee_fields():
	create_custom_fields(
		{
			"Employee": [
				{
					"fieldname": "karyo_hr_sb",
					"fieldtype": "Section Break",
					"label": "PRB & PB Settings",
					"insert_after": "date_of_joining",
					"collapsible": 0,
				},
				{
					"fieldname": "pb_eligible",
					"fieldtype": "Check",
					"label": "Passage Benefit Eligible",
					"insert_after": "karyo_hr_sb",
				},
				{
					"fieldname": "karyo_permanent_pensionable",
					"fieldtype": "Check",
					"label": "Permanent & Pensionable",
					"insert_after": "pb_eligible",
				},
				{
					"fieldname": "karyo_prb_opted_in",
					"fieldtype": "Check",
					"label": "PRB 2026 Opted In",
					"insert_after": "karyo_permanent_pensionable",
				},
				{"fieldname": "karyo_cb1", "fieldtype": "Column Break", "insert_after": "karyo_prb_opted_in"},
				{
					"fieldname": "karyo_prb_grade",
					"fieldtype": "Link",
					"options": "PRB Grade Scale",
					"label": "PRB Grade",
					"insert_after": "karyo_cb1",
				},
				{
					"fieldname": "karyo_prb_salary_point",
					"fieldtype": "Select",
					"label": "PRB Salary Point",
					"insert_after": "karyo_prb_grade",
					"description": "Salary-point code; resolved against PRB Salary Point by review year.",
				},
				{
					"fieldname": "karyo_date_joined_service",
					"fieldtype": "Date",
					"label": "Date Joined Service (PRB)",
					"insert_after": "karyo_prb_salary_point",
					"description": "Service reckoning date for PRB/Passage Benefit. Defaults to Date of Joining if blank.",
				},
				{
					"fieldname": "karyo_date_confirmed",
					"fieldtype": "Date",
					"label": "Date of Confirmation",
					"insert_after": "karyo_date_joined_service",
					"description": "Confirmation date — drives the salary/confirmation-route Passage Benefit Eligible-From-Date (PB-ELG-005).",
				},
				{
					"fieldname": "karyo_legacy_employee_id",
					"fieldtype": "Data",
					"label": "Legacy Employee ID",
					"insert_after": "karyo_date_confirmed",
					"unique": 1,
				},
				{
					"fieldname": "karyo_employment_category",
					"fieldtype": "Link",
					"label": "Category Code",
					"options": "Employee Category",
					"insert_after": "employment_type",
					"read_only": 1,
				},
				{
					"fieldname": "karyo_retirement_date",
					"fieldtype": "Date",
					"label": "Retirement Date",
					"insert_after": "karyo_employment_category",
				},
				{
					"fieldname": "karyo_work_pattern",
					"fieldtype": "Data",
					"label": "Work Pattern",
					"insert_after": "karyo_retirement_date",
				},
				{
					"fieldname": "karyo_payroll_group",
					"fieldtype": "Data",
					"label": "Payroll Group",
					"insert_after": "karyo_work_pattern",
				},
			]
		},
		ignore_validate=True,
	)
	print("  + Employee custom fields ensured")


def create_passage_benefit():
	# 1) Usage Item
	make_doctype(
		"Passage Benefit Usage Item",
		autoname="field:usage_item_code",
		naming_rule="By fieldname",
		title_field="usage_item_name",
		fields=[
			f("usage_item_code", "Data", "Usage Item Code", reqd=1, unique=1, in_list_view=1),
			f("usage_item_name", "Data", "Usage Item Name", reqd=1, in_list_view=1),
			f("encash_rate", "Percent", "Encash Rate", reqd=1, default="100", in_list_view=1),
			f("min_balance_credit", "Currency", "Minimum Balance Credit"),
			f("effective_from", "Date", "Effective From", in_list_view=1),
			f("effective_to", "Date", "Effective To"),
			f("requires_document", "Check", "Requires Supporting Document"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("cb", "Column Break"),
			f("pdb_salary_component", "Link", "Payroll Component (PDB)", options="Salary Component"),
			f("description", "Small Text", "Description"),
			f("remarks", "Small Text", "Remarks"),
		],
	)
	# 2) PB Bank (one per employee; named as employee id)
	make_doctype(
		"Passage Benefit Bank",
		autoname="field:employee",
		naming_rule="By fieldname",
		title_field="employee_name",
		fields=[
			f("employee", "Link", "Employee", options="Employee", reqd=1, unique=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("company", "Link", "Company", options="Company"),
			f("status", "Select", "Status", options="Active\nInactive", default="Active"),
			f("dates_cb", "Column Break"),
			f("eligible_from_date", "Date", "Eligible From Date"),
			f("opening_date", "Date", "Opening Date", reqd=1),
			f("opening_balance", "Currency", "Opening Balance", default="0"),
			f("balances_sb", "Section Break", "Balances"),
			f("total_earned", "Currency", "Total Earned", read_only=1),
			f("total_taken", "Currency", "Total Taken", read_only=1),
			f("total_adjustments", "Currency", "Total Adjustments", read_only=1),
			f("bal_cb", "Column Break"),
			f("current_balance", "Currency", "Current Balance", read_only=1, in_list_view=1),
			f("last_computation_date", "Date", "As At / Last Computation Date", read_only=1),
			f("last_salary_basis", "Currency", "Last Salary Basis", read_only=1),
			f("migration_sb", "Section Break", "Legacy Opening Balance Migration", collapsible=1),
			f("migration_batch", "Link", "Migration Batch", options="MBC Migration Batch", read_only=1),
			f(
				"migration_status", "Select", "Migration Status",
				options="Not Migrated\nLoaded\nReconciled\nException",
				default="Not Migrated", read_only=1,
			),
			f("legacy_employee_code", "Data", "Legacy Employee Code", read_only=1),
			f("legacy_pb_period", "Data", "PB Year / Period", read_only=1),
			f("migration_values_cb", "Column Break"),
			f("legacy_opening_balance", "Currency", "Legacy Opening Balance", read_only=1),
			f("legacy_earned", "Currency", "Legacy Earned", read_only=1),
			f("legacy_adjustments", "Currency", "Legacy Adjustments", read_only=1),
			f("legacy_claims_used", "Currency", "Legacy Claims / Used", read_only=1),
			f("legacy_closing_balance", "Currency", "Legacy Closing Balance", read_only=1),
			f("legacy_as_at_date", "Date", "Legacy As At Date", read_only=1),
			f("legacy_last_salary_basis", "Currency", "Legacy Last Salary Basis", read_only=1),
			f(
				"legacy_reconciliation_difference", "Currency",
				"Legacy Reconciliation Difference", read_only=1,
			),
			f("migration_source_sb", "Section Break", "Migration Source"),
			f("legacy_source_reference", "Data", "Source Report / Ref", read_only=1),
			f("legacy_remarks", "Small Text", "Legacy Remarks", read_only=1),
		],
	)
	# 3) Ledger Entry (submittable, append-only event source)
	make_doctype(
		"Passage Benefit Ledger Entry",
		is_submittable=1,
		autoname="naming_series:",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="PBLE-.YYYY.-.#####",
				default="PBLE-.YYYY.-.#####",
			),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("pb_bank", "Link", "Passage Benefit Bank", options="Passage Benefit Bank"),
			f("posting_date", "Date", "Posting Date", reqd=1, in_list_view=1),
			f(
				"entry_type",
				"Select",
				"Entry Type",
				options="Opening\nEarning\nClaim\nAdjustment",
				reqd=1,
				in_list_view=1,
			),
			f(
				"amount",
				"Currency",
				"Amount (signed)",
				reqd=1,
				in_list_view=1,
				description="Positive for Opening/Earning/positive Adjustment; negative for Claim.",
			),
			f("balance_after", "Currency", "Balance After", read_only=1),
			f("detail_cb", "Column Break"),
			f("pay_period", "Data", "Pay Period"),
			f("eligible_days", "Int", "Eligible Days"),
			f("salary_used", "Currency", "Salary Used"),
			f("daily_rate", "Currency", "Daily Rate"),
			f("ref_sb", "Section Break", "Reference & Audit"),
			f("reference_doctype", "Link", "Reference DocType", options="DocType"),
			f("reference_name", "Dynamic Link", "Reference Name", options="reference_doctype"),
			f("remarks", "Small Text", "Remarks"),
			f("computation_details", "Long Text", "Computation Details (JSON)"),
		],
	)
	# 4) Computation Segment (child)
	make_doctype(
		"Passage Benefit Computation Segment",
		istable=1,
		fields=[
			f("salary_from", "Date", "From", in_list_view=1, read_only=1),
			f("salary_to", "Date", "To", in_list_view=1, read_only=1),
			f("monthly_salary", "Currency", "Monthly Salary", reqd=1, in_list_view=1, read_only=1),
			f("eligible_days", "Int", "Eligible Days", reqd=1, in_list_view=1, read_only=1),
			f("excluded_days", "Int", "Excluded Days", read_only=1),
			f("annual_salary", "Currency", "Annual Salary", read_only=1),
			f("daily_rate", "Currency", "Daily Rate", read_only=1),
			f("denominator", "Int", "Day-count Denominator", read_only=1),
			f("segment_amount", "Currency", "Segment Amount", read_only=1, in_list_view=1),
			f("salary_source", "Data", "Salary Source", read_only=1),
			f("salary_reference", "Data", "Salary Reference", read_only=1),
		],
	)
	# 5) Computation (submittable earning run)
	make_doctype(
		"Passage Benefit Computation",
		is_submittable=1,
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="PBC-.YYYY.-.#####", default="PBC-.YYYY.-.#####"),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1),
			f("pb_bank", "Link", "Passage Benefit Bank", options="Passage Benefit Bank", read_only=1),
			f("period_cb", "Column Break"),
			f("from_date", "Date", "From Date", reqd=1),
			f("to_date", "Date", "To Date", reqd=1),
			f("pay_period", "Data", "Pay Period"),
			f("parameter_version", "Data", "Parameter Version", read_only=1),
			f("seg_sb", "Section Break", "Salary Segments"),
			f("segments", "Table", "Segments", options="Passage Benefit Computation Segment", read_only=1),
			f("result_sb", "Section Break", "Result"),
			f("eligible_days_total", "Int", "Total Eligible Days", read_only=1),
			f("earned_amount", "Currency", "Earned Amount", read_only=1, in_list_view=1),
			f("computation_log", "Long Text", "Computation Log", read_only=1),
		],
	)
	# 6) Not-Earned Period
	make_doctype(
		"Passage Benefit Not Earned Period",
		fields=[
			f("pay_day", "Link", "Period", options="Payroll Pay Day", reqd=1, in_list_view=1),
			f("pay_period", "Data", "Pay Period", fetch_from="pay_day.pay_period_label", read_only=1),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1),
			f("company", "Link", "Company", options="Company", fetch_from="employee.company", read_only=1),
			f("date_from", "Date", "Date From", reqd=1, in_list_view=1),
			f("date_to", "Date", "Date To", reqd=1, in_list_view=1),
			f("days", "Int", "Days", read_only=1, in_list_view=1),
			f("remarks", "Small Text", "Remarks"),
		],
	)


def create_all():
	print("Karyo foundation setup:")
	create_settings()
	create_employee_fields()
	create_passage_benefit()
	frappe.db.commit()
	print("Done.")


def apply_employee_salary_point_schema():
	"""Keep the Employee salary point as a year-resolved dropdown code."""
	name = frappe.db.get_value(
		"Custom Field", {"dt": "Employee", "fieldname": "karyo_prb_salary_point"}, "name"
	)
	if name and frappe.db.get_value("Custom Field", name, "fieldtype") != "Select":
		# Options are loaded from the PRB Salary Point master on the Employee
		# form.  Keeping them out of static metadata lets new master rows appear
		# immediately and avoids linking to the year-prefixed document name.
		frappe.db.set_value("Custom Field", name, {"fieldtype": "Select", "options": None})
		frappe.clear_cache(doctype="Employee")
