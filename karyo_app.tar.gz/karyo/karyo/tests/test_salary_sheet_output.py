"""Generate Outputs / Salary Sheet stays scoped to one generated pay day."""

import unittest
from io import BytesIO
from uuid import uuid4

import frappe
from openpyxl import load_workbook

from karyo.desk.payroll_management import download_salary_sheet, payslip_generation_context, screen_data
from karyo.desk.payroll_screens import generated_payslip_period_options
from karyo.payroll.screen_specs import SCREENS


class TestSalarySheetOutput(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("salary_sheet_output_test")
		self.major = payslip_generation_context("payday::MBC-2026-07-MAJOR")["selected"]
		self.minor = payslip_generation_context("payday::MBC-2026-07-MINOR")["selected"]

	def tearDown(self):
		frappe.db.rollback(save_point="salary_sheet_output_test")
		frappe.set_user(self.user)

	def make_slip(self, cycle, gross, deduction):
		name = "salary-sheet-" + uuid4().hex
		frappe.get_doc({
			"doctype": "Salary Slip",
			"name": name,
			"employee": "MBC/HR/00001",
			"employee_name": "Salary Sheet Employee",
			"company": cycle.company,
			"start_date": cycle.start_date,
			"end_date": cycle.end_date,
			"karyo_payroll_cycle": cycle.name,
			"docstatus": 0,
			"currency": "MUR",
			"gross_pay": gross,
			"total_deduction": deduction,
			"net_pay": gross - deduction,
		}).db_insert()
		return name

	def test_menu_and_sheet_use_only_the_selected_generated_pay_day(self):
		major_slip = self.make_slip(self.major, 1000, 100)
		minor_slip = self.make_slip(self.minor, 500, 50)

		self.assertEqual(SCREENS["salarysheet"]["group"], "Generate Outputs")
		self.assertEqual(SCREENS["salarysheet"]["title"], "Salary Sheet")
		options = generated_payslip_period_options()
		self.assertIn("MBC-2026-07-MAJOR", [row["pay_day"] for row in options])

		data = screen_data("salarysheet", pay_day="payday::MBC-2026-07-MAJOR")
		row_names = [row.name for row in data["list"]["rows"]]
		self.assertIn(major_slip, row_names)
		self.assertNotIn(minor_slip, row_names)
		self.assertEqual(data["selected_cycle"], "payday::MBC-2026-07-MAJOR")
		self.assertGreaterEqual(data["totals"]["count"], 1)

	def test_download_is_an_xlsx_for_the_complete_selected_sheet(self):
		name = self.make_slip(self.major, 1234, 234)
		download_salary_sheet("payday::MBC-2026-07-MAJOR")

		self.assertEqual(frappe.response["type"], "binary")
		self.assertTrue(frappe.response["filename"].endswith(".xlsx"))
		workbook = load_workbook(BytesIO(frappe.response["filecontent"]), read_only=True)
		values = [cell for row in workbook["Salary Sheet"].iter_rows(values_only=True) for cell in row]
		self.assertIn(name, frappe.get_all("Salary Slip", filters={"name": name}, pluck="name"))
		self.assertIn("MBC/HR/00001", values)
		self.assertIn(1234, values)


if __name__ == "__main__":
	unittest.main()
