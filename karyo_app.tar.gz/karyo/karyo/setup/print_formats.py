"""Branded Karyo print formats: Loan Agreement + Passage Benefit Claim.

bench --site dev.localhost execute karyo.setup.print_formats.setup
"""

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter

from karyo.loan.closing_documents import CLOSING_TEMPLATE

HEADER = """
<div style="background:linear-gradient(135deg,#FA9C3C 0%,#F6821F 55%,#E06710 100%);
 color:#fff;padding:18px 22px;border-radius:10px;display:flex;align-items:center;
 justify-content:space-between;font-family:Inter,Helvetica,sans-serif;">
  <div>
    <div style="font-size:22px;font-weight:700;letter-spacing:-0.3px;">{title}</div>
    <div style="opacity:.85;font-size:11px;margin-top:2px;">MBC HRMS &middot; {{{{ doc.name }}}}</div>
  </div>
  <img src="/assets/karyo/images/mbc-logo.jpg"
   style="height:46px;background:#fff;border-radius:10px;padding:4px;" alt="MBC HRMS"/>
</div>
"""

_H3 = (
	'style="color:#171717;border-bottom:2px solid #FFE9D3;padding-bottom:5px;margin-top:20px;font-size:15px;"'
)
_TD = 'style="padding:4px 8px;"'
_TDL = 'style="padding:4px 8px;color:#737373;width:130px;"'

LOAN_AGREEMENT = (
	HEADER.format(title="Loan Agreement")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Employee</td><td {_TD}><b>{{{{ doc.employee_name }}}}</b> ({{{{ doc.employee }}}})</td>
      <td {_TDL}>Loan Type</td><td {_TD}>{{{{ doc.loan_type }}}}</td></tr>
  <tr><td {_TDL}>Disbursement</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.disbursement_date) }}}}</td>
      <td {_TDL}>Status</td><td {_TD}>{{{{ doc.status }}}}</td></tr>
 </table>
 <h3 {_H3}>Loan Terms</h3>
 <table style="width:100%;">
  <tr><td {_TDL}>Principal</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.approved_amount) }}}}</td>
      <td {_TDL}>Annual Interest</td><td {_TD}>{{{{ doc.interest_rate }}}}%</td></tr>
  <tr><td {_TDL}>Period</td><td {_TD}>{{{{ doc.period_months }}}} months</td>
      <td {_TDL}>Monthly Refund</td><td {_TD}><b style="color:#C95A0A;">{{{{ frappe.utils.fmt_money(doc.monthly_refund) }}}}</b></td></tr>
  <tr><td {_TDL}>Monthly Capital</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.monthly_capital) }}}}</td>
      <td {_TDL}>Monthly Interest</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.monthly_interest) }}}}</td></tr>
  <tr><td {_TDL}>Total Interest</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.total_interest) }}}}</td>
      <td {_TDL}>Monthly Insurance</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.monthly_insurance) }}}}</td></tr>
  <tr><td {_TDL}>Net Loan Amount</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.net_loan_amount) }}}}</td>
      <td {_TDL}>Loan Reference</td><td {_TD}>{{{{ doc.loan_reference_no or doc.name }}}}</td></tr>
  <tr><td {_TDL}>Amount in Words</td><td {_TD} colspan="3"><i>{{{{ doc.approved_amount_words }}}}</i></td></tr>
 </table>
 {{% if doc.guarantors %}}
 <h3 {_H3}>Guarantors</h3>
 <p style="font-size:11px;color:#64748b;">Policy reference PL-POL-008: the borrower contract requires two establishment guarantors, liable on default.</p>
 <table style="width:100%;border-collapse:collapse;">
  <tr style="background:#FFF5EB;color:#C95A0A;"><th {_TD}>Name</th><th {_TD}>Employee</th><th {_TD}>Age</th></tr>
  {{% for g in doc.guarantors %}}
  <tr style="border-bottom:1px solid #E8E8E8;"><td {_TD}>{{{{ g.guarantor_name }}}}</td>
   <td {_TD}>{{{{ g.guarantor }}}}</td><td {_TD}>{{{{ g.age }}}}</td></tr>
  {{% endfor %}}
 </table>
 {{% endif %}}
 <h3 {_H3}>Repayment Schedule (first 6 of {{{{ doc.period_months }}}})</h3>
 <table style="width:100%;border-collapse:collapse;font-size:12px;">
  <tr style="background:#FAFAFA;color:#525252;">
   <th {_TD}>#</th><th {_TD}>Opening</th><th {_TD}>Capital</th><th {_TD}>Interest</th>
   <th {_TD}>Insurance</th><th {_TD}>Total</th><th {_TD}>Closing</th></tr>
  {{% for s in doc.schedule[:6] %}}
  <tr style="border-bottom:1px solid #E8E8E8;text-align:right;">
   <td {_TD}>{{{{ s.month }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(s.opening_balance) }}}}</td>
   <td {_TD}>{{{{ frappe.utils.fmt_money(s.capital) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(s.interest) }}}}</td>
   <td {_TD}>{{{{ frappe.utils.fmt_money(s.insurance) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(s.total) }}}}</td>
   <td {_TD}>{{{{ frappe.utils.fmt_money(s.closing_balance) }}}}</td></tr>
  {{% endfor %}}
 </table>
 <h3 {_H3}>Terms &amp; Conditions</h3>
 <ol style="font-size:12px;color:#525252;line-height:1.7;padding-left:18px;">
  <li>The borrower authorises recovery of the monthly capital, interest and insurance components by payroll deduction until the loan is fully repaid.</li>
  <li>Capital, interest and insurance are recovered as separate deductions linked to the loan reference number.</li>
  <li>Early settlement, advance payment or a change in repayment period shall be processed in accordance with the approved loan rules.</li>
  {{% if doc.get('lien_status') and doc.lien_status not in ('Not Applicable', '') %}}
  <li>The vehicle financed under this loan is subject to a registered lien until the loan is fully settled (Registration No. {{{{ doc.lien_registration_no or 'pending' }}}}).</li>
  {{% endif %}}
 </ol>
 <div style="font-size:10px;color:#A3A3A3;margin-top:6px;">Sample clauses — final agreement wording per loan type is a client deliverable (OI-FAR-007).</div>
 <table style="width:100%;margin-top:40px;font-size:12px;color:#737373;">
  <tr><td style="border-top:1px solid #A3A3A3;padding-top:6px;">Employee signature</td>
      <td style="width:40px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">For MBC HRMS (Approver)</td></tr>
 </table>
</div>
"""
)

APPLICATION_FORM = (
	HEADER.format(title="Loan Application &amp; Appraisal Form")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Employee</td><td {_TD}><b>{{{{ doc.employee_name }}}}</b> ({{{{ doc.employee }}}})</td>
      <td {_TDL}>Loan Type</td><td {_TD}>{{{{ doc.loan_type }}}}</td></tr>
  <tr><td {_TDL}>Date Applied</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.date_applied) }}}}</td>
      <td {_TDL}>Status</td><td {_TD}>{{{{ doc.workflow_state or doc.status }}}}</td></tr>
  <tr><td {_TDL}>Payroll Cycle / Period</td><td {_TD}>{{{{ doc.appraisal_payroll_cycle or '-' }}}} / {{{{ doc.appraisal_payroll_period or '-' }}}}</td>
      <td {_TDL}>Planned End Date</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.planned_repayment_end_date) if doc.planned_repayment_end_date else '-' }}}}</td></tr>
 </table>
 <h3 {_H3}>Loan Request</h3>
 <table style="width:100%;">
  <tr><td {_TDL}>Amount Applied</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.amount_applied) }}}}</td>
      <td {_TDL}>Amount Approved</td><td {_TD}><b>{{{{ frappe.utils.fmt_money(doc.approved_amount) }}}}</b></td></tr>
  <tr><td {_TDL}>Period</td><td {_TD}>{{{{ doc.period_months }}}} months</td>
      <td {_TDL}>Interest</td><td {_TD}>{{{{ doc.interest_rate }}}}%</td></tr>
  <tr><td {_TDL}>Purpose</td><td {_TD} colspan="3">{{{{ doc.purpose or '-' }}}}</td></tr>
  <tr><td {_TDL}>Amount in Words</td><td {_TD} colspan="3"><i>{{{{ doc.approved_amount_words }}}}</i></td></tr>
 </table>
 <div style="margin-top:14px;padding:9px;background:#F8FAFC;border:1px solid #E2E8F0;font-size:11px;">
  Form Version: MBC-LOAN-APPLICATION-1.0 · Source Loan Version: {{{{ doc.schedule_version or 1 }}}}<br>
  Verification Reference: {{{{ doc.approval_snapshot_hash or doc.appraisal_snapshot_hash or doc.name }}}}<br>
  Frozen Appraisal: {{{{ doc.appraisal_snapshot_hash or '-' }}}}<br>
  Record created by {{{{ doc.owner }}}} on {{{{ frappe.utils.format_datetime(doc.creation) }}}}.
  {{% if doc.approval_snapshot_hash and doc.workflow_state == 'Returned' %}} <b>SUPERSEDED — RETURNED FOR REWORK</b>{{% endif %}}
 </div>
 <h3 {_H3}>Computation</h3>
 <table style="width:100%;">
  <tr><td {_TDL}>Monthly Capital</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.monthly_capital) }}}}</td>
      <td {_TDL}>Monthly Interest</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.monthly_interest) }}}}</td></tr>
  <tr><td {_TDL}>Monthly Insurance</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.monthly_insurance) }}}}</td>
      <td {_TDL}>Monthly Refund</td><td {_TD}><b style="color:#C95A0A;">{{{{ frappe.utils.fmt_money(doc.monthly_refund) }}}}</b></td></tr>
 </table>
 <h3 {_H3}>Payroll Appraisal</h3>
 <table style="width:100%;">
  <tr><td {_TDL}>Eligible Salary</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.eligible_salary) }}}}</td>
      <td {_TDL}>Other Deductions</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.existing_deductions) }}}}</td></tr>
  <tr><td {_TDL}>Deduction %</td><td {_TD}>{{{{ doc.deduction_pct }}}}%</td>
      <td {_TDL}>Appraisal</td><td {_TD}>{{{{ doc.appraisal_status }}}}</td></tr>
 </table>
 {{% if doc.guarantors %}}
 <h3 {_H3}>Guarantors</h3>
 <p style="font-size:11px;color:#64748b;">Policy reference PL-POL-008: the borrower contract requires two establishment guarantors, liable on default.</p>
 <table style="width:100%;border-collapse:collapse;">
  <tr style="background:#FFF5EB;color:#C95A0A;"><th {_TD}>Name</th><th {_TD}>Employee</th><th {_TD}>Age</th></tr>
  {{% for g in doc.guarantors %}}
  <tr style="border-bottom:1px solid #E8E8E8;"><td {_TD}>{{{{ g.guarantor_name }}}}</td>
   <td {_TD}>{{{{ g.guarantor }}}}</td><td {_TD}>{{{{ g.age }}}}</td></tr>
  {{% endfor %}}
 </table>
 {{% endif %}}
 <table style="width:100%;margin-top:48px;font-size:12px;color:#737373;">
  <tr><td style="border-top:1px solid #A3A3A3;padding-top:6px;">Applicant</td>
      <td style="width:30px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">HR Loan Officer</td>
      <td style="width:30px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">Loan Committee</td></tr>
 </table>
</div>
"""
)

PB_CLAIM = (
	HEADER.format(title="Passage Benefit Claim")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Employee</td><td {_TD}><b>{{{{ doc.employee_name }}}}</b> ({{{{ doc.employee }}}})</td>
      <td {_TDL}>Status</td><td {_TD}>{{{{ doc.workflow_state }}}}</td></tr>
  <tr><td {_TDL}>Application Date</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.posting_date) }}}}</td>
      <td {_TDL}>Pay Period</td><td {_TD}>{{{{ doc.pay_period }}}}</td></tr>
 </table>
 <h3 {_H3}>Claim Details</h3>
 <table style="width:100%;">
  <tr><td {_TDL}>Usage Item</td><td {_TD}>{{{{ doc.usage_item_name or doc.usage_item }}}}</td>
      <td {_TDL}>Encash Rate</td><td {_TD}>{{{{ doc.encash_rate }}}}%</td></tr>
  <tr><td {_TDL}>Request Amount</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.request_amount) }}}}</td>
      <td {_TDL}>Claimable</td><td {_TD}><b style="color:#059669;">{{{{ frappe.utils.fmt_money(doc.claimable_amount) }}}}</b></td></tr>
  <tr><td {_TDL}>Available Balance</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.available_balance) }}}}</td>
      <td {_TDL}>Amount Taken</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.amount_taken) }}}}</td></tr>
  <tr><td {_TDL}>Processing Route</td><td {_TD}>{{{{ doc.processing_route }}}}</td>
      <td {_TDL}>Payroll Component</td><td {_TD}>{{{{ doc.pdb_component or '-' }}}}</td></tr>
 </table>
 <table style="width:100%;margin-top:48px;font-size:12px;color:#737373;">
  <tr><td style="border-top:1px solid #A3A3A3;padding-top:6px;">Employee</td>
      <td style="width:40px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">Finance (Processing)</td></tr>
 </table>
</div>
"""
)

LOAN_SETTLEMENT_RECEIPT = (
	HEADER.format(title="Loan Settlement Statement &amp; Receipt")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Receipt Reference</td><td {_TD}><b>{{{{ doc.receipt_reference or doc.name }}}}</b></td>
      <td {_TDL}>Settlement Date</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.refund_date) }}}}</td></tr>
  <tr><td {_TDL}>Employee</td><td {_TD}>{{{{ doc.employee }}}}</td>
      <td {_TDL}>Loan</td><td {_TD}>{{{{ doc.loan }}}}</td></tr>
  <tr><td {_TDL}>Loan Type</td><td {_TD}>{{{{ doc.loan_type }}}}</td>
      <td {_TDL}>Document Status</td><td {_TD}>{{{{ 'Cancelled' if doc.docstatus == 2 else 'Settled' if doc.docstatus == 1 else 'Draft' }}}}</td></tr>
 </table>
 <h3 {_H3}>Settlement Breakdown</h3>
 <table style="width:100%;border-collapse:collapse;">
  <tr style="background:#FFF5EB;color:#C95A0A;"><th {_TD}>Component</th><th {_TD}>Amount</th></tr>
  <tr><td {_TD}>Capital</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.capital_due) }}}}</td></tr>
  <tr><td {_TD}>Interest{{{{ ' (EWF waived)' if doc.ewf_waive_interest else '' }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.interest_due) }}}}</td></tr>
  <tr><td {_TD}>Insurance</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.insurance_due) }}}}</td></tr>
  <tr style="font-weight:700;border-top:2px solid #F6821F;"><td {_TD}>Total Balance Due</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.total_balance_due) }}}}</td></tr>
  <tr><td {_TD}>Amount Received</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.amount_received) }}}}</td></tr>
 </table>
 <h3 {_H3}>Payment &amp; Authorisation</h3>
 <table style="width:100%;">
  <tr><td {_TDL}>Payment Method</td><td {_TD}>{{{{ doc.payment_type }}}}</td>
      <td {_TDL}>Payment Reference</td><td {_TD}>{{{{ doc.cheque_no or doc.payment_reference or '-' }}}}</td></tr>
  <tr><td {_TDL}>Approval Reference</td><td {_TD}>{{{{ doc.approval_reference or '-' }}}}</td>
      <td {_TDL}>Remaining Instalments</td><td {_TD}>{{{{ doc.remaining_instalments }}}}</td></tr>
  <tr><td {_TDL}>Remarks</td><td {_TD} colspan="3">{{{{ doc.remarks or '-' }}}}</td></tr>
 </table>
 <div style="margin-top:28px;padding:12px;background:#F0FDF4;border:1px solid #BBF7D0;border-radius:6px;color:#166534;">
  This statement confirms that the recorded settlement amount reconciled to the component balance at the settlement date.
 </div>
 <table style="width:100%;margin-top:48px;font-size:12px;color:#737373;">
  <tr><td style="border-top:1px solid #A3A3A3;padding-top:6px;">Employee</td><td style="width:30px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">Loan Officer</td><td style="width:30px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">Finance</td></tr>
 </table>
</div>
"""
)

LOAN_REPAYMENT_SCHEDULE = f"""
<div style="font-family:Inter,Helvetica,sans-serif;font-size:10px;">
 <h2>Loan Repayment Schedule</h2>
 <p><b>Loan:</b> {{{{ doc.name }}}} &nbsp; <b>Employee:</b> {{{{ doc.employee }}}} &nbsp; <b>Method:</b> {{{{ doc.interest_recovery_method or '-' }}}}</p>
 <table style="width:100%;border-collapse:collapse;">
  <thead><tr><th {_TD}>Month</th><th {_TD}>Repayment Date</th><th {_TD}>Opening</th><th {_TD}>Capital</th><th {_TD}>Reducing Interest</th><th {_TD}>Interest Deduction</th><th {_TD}>Insurance</th><th {_TD}>Total</th><th {_TD}>Closing</th><th {_TD}>Status</th><th {_TD}>Remarks</th></tr></thead>
  <tbody>{{% for row in doc.schedule %}}<tr><td {_TD}>{{{{ row.month }}}}</td><td {_TD}>{{{{ frappe.utils.formatdate(row.due_date) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(row.opening_balance) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(row.capital) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(row.interest_generated) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(row.interest) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(row.insurance) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(row.total) }}}}</td><td {_TD}>{{{{ frappe.utils.fmt_money(row.closing_balance) }}}}</td><td {_TD}>{{{{ row.status }}}}</td><td {_TD}>{{{{ row.remarks or '' }}}}</td></tr>{{% endfor %}}</tbody>
 </table>
</div>
"""

SALARY_SLIP = """
{% set employee = frappe.get_doc("Employee", doc.employee) %}
<style>
@page { size:A4; margin:13mm; }
.mbc-slip { border:1.5px solid #111; color:#111; font:12px Arial,sans-serif; }
.mbc-slip table { width:100%; border-collapse:collapse; }
.mbc-slip .head { padding:14px 18px; border-bottom:1.5px solid #111; }
.mbc-slip .head img { max-width:105px; max-height:68px; margin-right:34px; vertical-align:middle; }
.mbc-slip .head .company { display:inline-block; vertical-align:middle; }
.mbc-slip .identity td { padding:5px 8px; border:0; }
.mbc-slip .identity .value { font-weight:600; }
.mbc-slip .days { margin:10px 0; border-top:1.5px solid #111; border-bottom:1.5px solid #111; }
.mbc-slip .days td,.mbc-slip .components th,.mbc-slip .components td { border:1px solid #111; padding:6px; }
.mbc-slip .components th { text-align:center; background:#f7f7f7; }
.mbc-slip .money { text-align:right; white-space:nowrap; }
.mbc-slip .total td,.mbc-slip .total th,.mbc-slip .net td,.mbc-slip .net th { font-weight:700; border-top:2px solid #111; }
.mbc-slip .net th { text-align:right; font-size:14px; }
</style>
<section class="mbc-slip">
 <header class="head"><img src="/assets/karyo/images/mbc-logo.jpg"><span class="company">
  <div>Pay Slip for <b>{{ frappe.utils.formatdate(doc.start_date, "MMMM yyyy") }}</b></div></span></header>
 <table class="identity"><tbody>
  <tr><td>Employee ID</td><td>:</td><td class="value">{{ doc.employee }}</td><td>National ID</td><td>:</td><td class="value">{{ employee.karyo_national_id or "—" }}</td></tr>
  <tr><td>Employee Name</td><td>:</td><td class="value">{{ doc.employee_name }}</td><td>Tax ID</td><td>:</td><td class="value">{{ employee.pan_number or "—" }}</td></tr>
  <tr><td>Designation</td><td>:</td><td class="value">{{ doc.designation or "—" }}</td><td>Bank</td><td>:</td><td class="value">{{ doc.bank_name or employee.karyo_payroll_bank or employee.bank_name or "—" }}</td></tr>
  <tr><td>Department</td><td>:</td><td class="value">{{ doc.department or "—" }}</td><td>Account No.</td><td>:</td><td class="value">{{ doc.bank_account_no or employee.bank_ac_no or "—" }}</td></tr>
  <tr><td>Date of Joining</td><td>:</td><td class="value" colspan="4">{{ frappe.utils.formatdate(employee.date_of_joining) }}</td></tr>
 </tbody></table>
 <table class="days"><tbody>
  <tr><td>Basic Pay</td><td class="value">{{ frappe.utils.fmt_money(doc.karyo_basic_pay or 0, currency=doc.currency) }}</td><td>Gross Pay</td><td class="value">{{ frappe.utils.fmt_money(doc.gross_pay, currency=doc.currency) }}</td></tr>
  <tr><td>Total Working Days</td><td>{{ doc.total_working_days }}</td><td>Paid Days</td><td>{{ doc.payment_days }}</td></tr>
  <tr><td>Leave Days</td><td>{{ doc.karyo_leave_days or 0 }}</td><td>Absent Days</td><td>{{ doc.absent_days or 0 }}</td></tr>
  <tr><td>LOP Days</td><td colspan="3">{{ doc.leave_without_pay or 0 }}</td></tr>
 </tbody></table>
 <table class="components"><thead><tr><th>Earnings</th><th>Amount</th><th>Deductions</th><th>Amount</th></tr></thead><tbody>
  {% for row in doc.earnings %}<tr><td>{{ row.salary_component }}</td><td class="money">{{ frappe.utils.fmt_money(row.amount, currency=doc.currency) }}</td><td></td><td></td></tr>{% endfor %}
  {% for row in doc.deductions %}<tr><td></td><td></td><td>{{ row.salary_component }}</td><td class="money">{{ frappe.utils.fmt_money(row.amount, currency=doc.currency) }}</td></tr>{% endfor %}
  <tr class="total"><th>Total Earnings</th><td class="money">{{ frappe.utils.fmt_money(doc.gross_pay, currency=doc.currency) }}</td><th>Total Deductions</th><td class="money">{{ frappe.utils.fmt_money(doc.total_deduction, currency=doc.currency) }}</td></tr>
  <tr class="net"><th colspan="3">Net Salary</th><td class="money">{{ frappe.utils.fmt_money(doc.net_pay, currency=doc.currency) }}</td></tr>
 </tbody></table>
</section>
"""

LEAVE_APPLICATION = (
	HEADER.format(title="Leave Application")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Employee</td><td {_TD}><b>{{{{ doc.employee_name }}}}</b> ({{{{ doc.employee }}}})</td>
      <td {_TDL}>Status</td><td {_TD}>{{{{ doc.status }}}}</td></tr>
  <tr><td {_TDL}>Leave Type</td><td {_TD}>{{{{ doc.leave_type }}}}</td>
      <td {_TDL}>Application Date</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.posting_date) }}}}</td></tr>
  <tr><td {_TDL}>From</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.from_date) }}}}</td>
      <td {_TDL}>To</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.to_date) }}}}</td></tr>
  <tr><td {_TDL}>Leave Days</td><td {_TD}>{{{{ doc.total_leave_days }}}}</td>
      <td {_TDL}>Half Day</td><td {_TD}>{{{{ 'Yes' if doc.half_day else 'No' }}}}</td></tr>
  <tr><td {_TDL}>Reason</td><td {_TD} colspan="3">{{{{ doc.description or '-' }}}}</td></tr>
 </table>
 <table style="width:100%;margin-top:48px;font-size:12px;color:#737373;">
  <tr><td style="border-top:1px solid #A3A3A3;padding-top:6px;">Employee</td><td style="width:40px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">Approver</td></tr>
 </table>
</div>
"""
)

ATTENDANCE_RECORD = (
	HEADER.format(title="Attendance Record")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Employee</td><td {_TD}><b>{{{{ doc.employee_name }}}}</b> ({{{{ doc.employee }}}})</td>
      <td {_TDL}>Date</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.attendance_date) }}}}</td></tr>
  <tr><td {_TDL}>Status</td><td {_TD}>{{{{ doc.status }}}}</td>
      <td {_TDL}>Shift</td><td {_TD}>{{{{ doc.shift or '-' }}}}</td></tr>
  <tr><td {_TDL}>In Time</td><td {_TD}>{{{{ frappe.utils.format_datetime(doc.in_time) if doc.in_time else '-' }}}}</td>
      <td {_TDL}>Out Time</td><td {_TD}>{{{{ frappe.utils.format_datetime(doc.out_time) if doc.out_time else '-' }}}}</td></tr>
  <tr><td {_TDL}>Working Hours</td><td {_TD}>{{{{ doc.working_hours or 0 }}}}</td>
      <td {_TDL}>Company</td><td {_TD}>{{{{ doc.company }}}}</td></tr>
 </table>
</div>
"""
)

ATTENDANCE_REQUEST = (
	HEADER.format(title="Attendance Request")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Employee</td><td {_TD}><b>{{{{ doc.employee_name or doc.employee }}}}</b></td>
      <td {_TDL}>Status</td><td {_TD}>{{{{ doc.workflow_state or ('Submitted' if doc.docstatus == 1 else 'Draft') }}}}</td></tr>
  <tr><td {_TDL}>From</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.from_date) }}}}</td>
      <td {_TDL}>To</td><td {_TD}>{{{{ frappe.utils.formatdate(doc.to_date) }}}}</td></tr>
  <tr><td {_TDL}>Reason</td><td {_TD}>{{{{ doc.reason or '-' }}}}</td>
      <td {_TDL}>Half Day</td><td {_TD}>{{{{ 'Yes' if doc.half_day else 'No' }}}}</td></tr>
  <tr><td {_TDL}>Explanation</td><td {_TD} colspan="3">{{{{ doc.explanation or '-' }}}}</td></tr>
 </table>
</div>
"""
)

LOAN_APPROVAL = (
	HEADER.format(title="MBC Loan Approval")
	+ f"""
<div style="font-family:Inter,Helvetica,sans-serif;color:#404040;font-size:13px;">
 <table style="width:100%;margin-top:16px;">
  <tr><td {_TDL}>Employee</td><td {_TD}><b>{{{{ doc.employee_name }}}}</b> ({{{{ doc.employee }}}})</td>
      <td {_TDL}>MBC Loan</td><td {_TD}>{{{{ doc.name }}}}</td></tr>
  <tr><td {_TDL}>Loan Type</td><td {_TD}>{{{{ doc.loan_type }}}}</td>
      <td {_TDL}>Decision</td><td {_TD}><b>{{{{ doc.workflow_state or doc.status }}}}</b></td></tr>
  <tr><td {_TDL}>Amount Applied</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.amount_applied) }}}}</td>
      <td {_TDL}>Amount Approved</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.approved_amount) }}}}</td></tr>
  <tr><td {_TDL}>Period</td><td {_TD}>{{{{ doc.period_months }}}} months</td>
      <td {_TDL}>Monthly Refund</td><td {_TD}>{{{{ frappe.utils.fmt_money(doc.monthly_refund) }}}}</td></tr>
  <tr><td {_TDL}>Committee Decision</td><td {_TD}>{{{{ doc.committee_decision or '-' }}}}</td>
      <td {_TDL}>MD Decision</td><td {_TD}>{{{{ doc.md_decision or '-' }}}}</td></tr>
  <tr><td {_TDL}>Remarks</td><td {_TD} colspan="3">{{{{ doc.committee_remarks or doc.rejection_reason or '-' }}}}</td></tr>
 </table>
 <table style="width:100%;margin-top:48px;font-size:12px;color:#737373;">
  <tr><td style="border-top:1px solid #A3A3A3;padding-top:6px;">Loan Officer</td><td style="width:30px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">Committee</td><td style="width:30px;"></td>
      <td style="border-top:1px solid #A3A3A3;padding-top:6px;">Authorised Approver</td></tr>
 </table>
</div>
"""
)

FORMATS = [
	("MBC Salary Slip", "Salary Slip", SALARY_SLIP),
	("MBC Leave Application", "Leave Application", LEAVE_APPLICATION),
	("MBC Attendance Record", "Attendance", ATTENDANCE_RECORD),
	("MBC Attendance Request", "Attendance Request", ATTENDANCE_REQUEST),
	("MBC Loan Agreement", "Karyo Loan", LOAN_AGREEMENT),
	("MBC Loan Application Form", "Karyo Loan", APPLICATION_FORM),
	("MBC Loan Approval", "Karyo Loan", LOAN_APPROVAL),
	("MBC Loan Repayment Schedule", "Karyo Loan", LOAN_REPAYMENT_SCHEDULE),
	("MBC Loan Settlement Statement and Receipt", "Karyo Loan Settlement", LOAN_SETTLEMENT_RECEIPT),
	("MBC Loan Closing Certificate", "Karyo Loan", CLOSING_TEMPLATE),
	("MBC Passage Benefit Claim", "Passage Benefit Application", PB_CLAIM),
]

ACTIVE_PRINT_DOCTYPES = {doctype for _name, doctype, _html in FORMATS}
ACTIVE_PRINT_FORMATS = {name for name, _doctype, _html in FORMATS}


def _remove_out_of_scope_formats():
	"""Remove ERP sales, buying, stock and test formats from this HRMS site."""
	for row in frappe.get_all("Print Format", fields=["name", "doc_type"]):
		if row.name in ACTIVE_PRINT_FORMATS or row.doc_type in ACTIVE_PRINT_DOCTYPES:
			continue
		frappe.delete_doc("Print Format", row.name, ignore_permissions=True, force=True)


def verify():
	loan = frappe.db.get_value("Karyo Loan", {"docstatus": 1}, "name")
	app = frappe.db.get_value("Passage Benefit Application", {"docstatus": 1}, "name")
	if loan:
		html = frappe.get_print("Karyo Loan", loan, print_format="MBC Loan Agreement")
		print(f"  OK Loan Agreement for {loan}: {len(html)} chars, logo={'karyo-mark' in html}")
		html = frappe.get_print("Karyo Loan", loan, print_format="MBC Loan Application Form")
		print(f"  OK Application Form for {loan}: {len(html)} chars")
		if frappe.db.get_value("Karyo Loan", loan, "status") in ("Settled", "Closed"):
			html = frappe.get_print("Karyo Loan", loan, print_format="MBC Loan Closing Certificate")
			print(f"  OK Closing Certificate for {loan}: {len(html)} chars")
	if app:
		html = frappe.get_print(
			"Passage Benefit Application", app, print_format="MBC Passage Benefit Claim"
		)
		print(f"  OK PB Claim for {app}: {len(html)} chars")


def setup():
	print("Karyo print formats:")
	for name, doctype, html in FORMATS:
		if frappe.db.exists("Print Format", name):
			doc = frappe.get_doc("Print Format", name)
			doc.custom_format = 1
			doc.print_format_type = "Jinja"
			doc.html = html
			doc.save(ignore_permissions=True)
			print(f"  = Updated: {name}")
			continue
		frappe.get_doc(
			{
				"doctype": "Print Format",
				"name": name,
				"doc_type": doctype,
				"module": "Karyo",
				"print_format_type": "Jinja",
				"custom_format": 1,
				"standard": "No",
				"html": html,
			}
		).insert(ignore_permissions=True)
		print(f"  + Created: {name}")
	frappe.db.set_value("DocType", "Salary Slip", "default_print_format", "MBC Salary Slip")
	_remove_out_of_scope_formats()
	for fieldname in ("custom_html_help", "print_format_help"):
		make_property_setter("Print Format", fieldname, "hidden", 1, "Check")
	make_property_setter("Print Format", "doc_type", "label", "Document Type", "Data")
	make_property_setter("Print Format", "doc_type", "read_only", 1, "Check")
	make_property_setter("Print Format", "module", "read_only", 1, "Check")
	frappe.clear_cache(doctype="Print Format")
	frappe.db.commit()
	print("Done.")
