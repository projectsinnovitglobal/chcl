import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.setup.communication_templates import EMAIL_TEMPLATES, OUT_OF_SCOPE_TEMPLATES
from karyo.setup.print_formats import ACTIVE_PRINT_DOCTYPES, ACTIVE_PRINT_FORMATS


class TestCuratedTemplates(FrappeTestCase):
	def test_only_current_module_print_formats_remain(self):
		rows = frappe.get_all("Print Format", fields=["name", "doc_type"])
		self.assertTrue(ACTIVE_PRINT_FORMATS.issubset({row.name for row in rows}))
		self.assertTrue(all(row.doc_type in ACTIVE_PRINT_DOCTYPES for row in rows))

	def test_current_email_templates_replace_upstream_examples(self):
		names = set(frappe.get_all("Email Template", pluck="name"))
		self.assertTrue(set(EMAIL_TEMPLATES).issubset(names))
		self.assertFalse(names & OUT_OF_SCOPE_TEMPLATES)

	def test_template_help_and_arbitrary_doctype_selection_are_hidden(self):
		email_meta = frappe.get_meta("Email Template")
		print_meta = frappe.get_meta("Print Format")
		self.assertTrue(email_meta.get_field("email_reply_help").hidden)
		self.assertTrue(print_meta.get_field("custom_html_help").hidden)
		self.assertTrue(print_meta.get_field("print_format_help").hidden)
		self.assertTrue(print_meta.get_field("doc_type").read_only)
		self.assertEqual(print_meta.get_field("doc_type").label, "Document Type")
		self.assertTrue(print_meta.get_field("module").read_only)

	def test_loan_governance_block_is_not_user_facing(self):
		meta = frappe.get_meta("Loan Accounting Mapping")
		for fieldname in (
			"governance_sb", "configuration_status", "configuration_version",
			"is_production_eligible", "source_reference", "approval_reference",
			"approved_by", "approved_on",
		):
			self.assertTrue(meta.get_field(fieldname).hidden, fieldname)
