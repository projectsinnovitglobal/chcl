from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase
from frappe.utils import add_days, add_months, flt, getdate, nowdate
from hrms.hr.doctype.leave_application.leave_application import get_number_of_leave_days

from karyo.hr.leave_application import KaryoLeaveApplication
from karyo.hr.leave_controls import (
	_reconcile_attendance_for_approved_leave,
	decide_leave_application,
	employee_standard_day_hours,
)
from karyo.hr.self_service import leave_balances, vacation_accrual_snapshot

from karyo.hr.leave_controls import _normalize_hour_request


class TestCasualLeavePermission(FrappeTestCase):
	@patch("karyo.hr.leave_controls.employee_standard_day_hours", return_value=8)
	def test_two_hour_permission_converts_to_quarter_day(self, _day_hours):
		doc = frappe._dict(
			karyo_leave_code="CASL01", karyo_two_hour_permission=1,
			karyo_leave_unit="Hours", karyo_requested_hours=2,
			employee="EMP-1",
			from_date="2026-10-01", to_date="2026-10-01", half_day=0,
		)
		_normalize_hour_request(doc)
		self.assertEqual(doc.total_leave_days, 0.25)
		self.assertEqual(doc.half_day, 0)
		self.assertEqual(doc.karyo_standard_day_hours, 8)
		self.assertEqual(doc.karyo_converted_leave_days, 0.25)

	@patch("karyo.hr.leave_controls.employee_standard_day_hours", return_value=10)
	def test_two_hour_permission_uses_employee_working_day(self, _day_hours):
		doc = frappe._dict(
			karyo_leave_code="CASL01", karyo_two_hour_permission=1,
			karyo_leave_unit="Days", karyo_requested_hours=0, employee="EMP-10H",
			from_date="2026-10-01", to_date="2026-10-01", half_day=0,
		)
		_normalize_hour_request(doc)
		self.assertEqual(doc.karyo_leave_unit, "Hours")
		self.assertEqual(doc.karyo_requested_hours, 2)
		self.assertEqual(doc.total_leave_days, 0.2)

	@patch("karyo.hr.leave_controls.employee_standard_day_hours", return_value=8)
	def test_two_hour_permission_is_restricted_to_casual_leave(self, _day_hours):
		doc = frappe._dict(
			karyo_leave_code="ANN", karyo_two_hour_permission=1,
			karyo_leave_unit="Hours", karyo_requested_hours=2, employee="EMP-1",
			from_date="2026-10-01", to_date="2026-10-01",
		)
		with self.assertRaisesRegex(frappe.ValidationError, "only be recorded against Casual Leave"):
			_normalize_hour_request(doc)

	def test_permission_skips_full_day_attendance_posting(self):
		doc = frappe._dict(
			karyo_leave_code="CASL01", karyo_two_hour_permission=1,
			karyo_leave_unit="Hours", karyo_requested_hours=2,
		)
		with patch(
			"hrms.hr.doctype.leave_application.leave_application.LeaveApplication.update_attendance"
		) as native_update:
			KaryoLeaveApplication.update_attendance(doc)
		native_update.assert_not_called()

	@patch("karyo.hr.leave_controls.frappe.get_all")
	def test_permission_approval_does_not_replace_present_attendance(self, get_all):
		doc = frappe._dict(
			karyo_leave_code="CASL01", karyo_two_hour_permission=1,
			karyo_leave_unit="Hours", karyo_requested_hours=2,
			employee="EMP-1", from_date="2026-10-01", to_date="2026-10-01",
		)
		self.assertEqual(_reconcile_attendance_for_approved_leave(doc), [])
		get_all.assert_not_called()

	def test_submitted_permission_debits_fractional_casual_balance_only(self):
		casual = frappe.db.get_value("Leave Type", {"karyo_mbc_leave_code": "CASL01"}, "name")
		allocations = frappe.get_all(
			"Leave Allocation",
			filters={
				"leave_type": casual, "docstatus": 1,
				"from_date": ("<=", nowdate()), "to_date": (">=", add_days(nowdate(), 20)),
			},
			fields=["employee", "from_date", "to_date"],
			limit_page_length=0,
		)
		employee = None
		for allocation in allocations:
			profile = frappe.db.get_value(
				"Employee", allocation.employee,
				["status", "date_of_joining", "karyo_date_joined_service", "karyo_employment_category"],
				as_dict=True,
			)
			joined = profile and (profile.karyo_date_joined_service or profile.date_of_joining)
			if (
				profile and profile.status == "Active" and profile.karyo_employment_category == "PERM"
				and joined and getdate(joined) <= getdate(add_months(nowdate(), -12))
			):
				employee = allocation.employee
				break
		if not employee:
			self.skipTest("No active substantive employee with a current Casual Leave allocation")

		permission_date = None
		for offset in range(1, 21):
			candidate = add_days(nowdate(), offset)
			if frappe.db.exists("Leave Application", {
				"employee": employee, "docstatus": ("<", 2),
				"from_date": ("<=", candidate), "to_date": (">=", candidate),
			}):
				continue
			if get_number_of_leave_days(employee, casual, candidate, candidate) > 0:
				permission_date = candidate
				break
		if not permission_date:
			self.skipTest("No free working date available for Casual Leave permission test")

		day_hours = employee_standard_day_hours(employee, permission_date)
		expected_days = round(2 / day_hours, 6)
		before_balance = next(
			row["remaining"] for row in leave_balances(employee, permission_date)
			if row.get("leave_code") == "CASL01"
		)
		doc = frappe.get_doc({
			"doctype": "Leave Application",
			"employee": employee,
			"leave_type": casual,
			"from_date": permission_date,
			"to_date": permission_date,
			"leave_approver": "Administrator",
			"status": "Open",
			"description": "Automated two-hour Casual Leave permission test",
			"karyo_two_hour_permission": 1,
			"karyo_leave_unit": "Hours",
			"karyo_requested_hours": 2,
		}).insert(ignore_permissions=True)
		self.assertIsInstance(doc, KaryoLeaveApplication)
		self.assertAlmostEqual(doc.total_leave_days, expected_days, places=6)

		decide_leave_application(doc.name, "Approved")
		doc.reload()
		ledger_debit = flt(frappe.db.get_value(
			"Leave Ledger Entry",
			{"transaction_type": "Leave Application", "transaction_name": doc.name, "docstatus": 1},
			"sum(leaves)",
		))
		self.assertAlmostEqual(ledger_debit, -expected_days, places=6)
		after_balance = next(
			row["remaining"] for row in leave_balances(employee, permission_date)
			if row.get("leave_code") == "CASL01"
		)
		self.assertAlmostEqual(
			before_balance - after_balance, expected_days, places=6,
			msg=f"before={before_balance}, after={after_balance}, expected={expected_days}",
		)
		transaction = frappe.db.get_value(
			"Leave Transaction", {"leave_request_id": doc.name},
			["duration_units", "duration_unit", "two_hour_permission", "requested_hours",
			 "standard_day_hours", "equivalent_leave_days"], as_dict=True,
		)
		self.assertEqual(transaction.duration_unit, "Days")
		self.assertEqual(transaction.two_hour_permission, 1)
		self.assertEqual(transaction.requested_hours, 2)
		self.assertAlmostEqual(transaction.standard_day_hours, day_hours, places=6)
		self.assertAlmostEqual(transaction.equivalent_leave_days, expected_days, places=6)
		self.assertFalse(frappe.db.exists("Attendance", {"leave_application": doc.name, "docstatus": ("<", 2)}))

	@patch("karyo.hr.self_service.frappe.get_cached_doc")
	@patch("karyo.hr.self_service.frappe.db.exists", return_value=True)
	@patch("karyo.hr.self_service.frappe.db.get_value")
	def test_vacation_daily_accrual_uses_service_band_and_leap_year(
		self, get_value, _exists, get_cached_doc
	):
		get_value.return_value = frappe._dict(
			date_of_joining="2018-01-01", karyo_date_joined_service="2018-01-01"
		)
		get_cached_doc.return_value = frappe._dict(vacation_leave_bands=[
			frappe._dict(
				service_from_years=5, service_to_years=10,
				annual_entitlement_days=30, accumulation_ceiling_days=140,
			),
		])
		snapshot = vacation_accrual_snapshot("EMP-1", "2024-07-01")
		self.assertEqual(snapshot.annual_accrual_days, 30)
		self.assertEqual(snapshot.daily_accrual_days, round(30 / 366, 6))
		self.assertEqual(snapshot.ceiling_days, 140)
