"""Employee grievance confidentiality and ESS defaults."""

from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.grievance import validate_employee_grievance
from karyo.security import grievance_permission, grievance_query


class TestEmployeeGrievance(FrappeTestCase):
	def test_employee_query_and_permission_are_owner_scoped(self):
		with patch("frappe.get_roles", return_value=["Employee", "Payroll Processor"]), patch(
			"karyo.security._employee_for_user", return_value="EMP-SELF"
		):
			condition = grievance_query("employee@example.com")
			self.assertIn("`tabEmployee Grievance`.`raised_by`", condition)
			self.assertIn("EMP-SELF", condition)
			own = frappe._dict(raised_by="EMP-SELF", status="Open", docstatus=0)
			other = frappe._dict(raised_by="EMP-OTHER", status="Open", docstatus=0)
			self.assertTrue(grievance_permission(own, "read", "employee@example.com"))
			self.assertTrue(grievance_permission(own, "write", "employee@example.com"))
			self.assertFalse(grievance_permission(other, "read", "employee@example.com"))
			own.status = "Resolved"
			self.assertFalse(grievance_permission(own, "write", "employee@example.com"))
		with patch("frappe.get_roles", return_value=["HR User"]):
			self.assertIsNone(grievance_query("hr@example.com"))

	def test_new_employee_grievance_fixes_identity_and_hr_fields(self):
		doc = frappe.new_doc("Employee Grievance")
		doc.raised_by = "EMP-OTHER"
		doc.status = "Resolved"
		doc.resolution_detail = "Must not be accepted from ESS"
		with patch("karyo.hr.grievance._is_hr_user", return_value=False), patch(
			"karyo.hr.grievance._own_employee", return_value=frappe._dict(name="EMP-SELF")
		):
			validate_employee_grievance(doc)
		self.assertEqual(doc.raised_by, "EMP-SELF")
		self.assertEqual(doc.status, "Open")
		self.assertFalse(doc.resolution_detail)
		self.assertTrue(doc.date)

	def test_hr_users_keep_native_investigation_workflow(self):
		doc = frappe.new_doc("Employee Grievance")
		doc.raised_by = "EMP-SELECTED"
		doc.status = "Resolved"
		with patch("karyo.hr.grievance._is_hr_user", return_value=True):
			validate_employee_grievance(doc)
		self.assertEqual(doc.raised_by, "EMP-SELECTED")
		self.assertEqual(doc.status, "Resolved")
