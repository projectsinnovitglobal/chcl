"""Install explicit committee outcomes without replacing the configured workflow."""
import frappe

COMMITTEE_STATES = ("Loan Committee Scheduled", "Under Loan Committee Review", "Pending")


def setup():
	from frappe.model.workflow import get_workflow_name

	name = get_workflow_name("Karyo Loan") or frappe.db.get_value(
		"Workflow", {"document_type": "Karyo Loan", "is_active": 1}, "name"
	)
	if not name:
		return
	workflow = frappe.get_doc("Workflow", name)
	for outcome in ("Approved", "Cancelled", "Rejected"):
		if not frappe.db.exists("Workflow State", outcome):
			frappe.get_doc({"doctype": "Workflow State", "workflow_state_name": outcome}).insert(
				ignore_permissions=True
			)
		if not frappe.db.exists("Workflow Action Master", outcome):
			frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": outcome}).insert(
				ignore_permissions=True
			)
		if outcome not in [row.state for row in workflow.states]:
			workflow.append(
				"states", {"state": outcome, "doc_status": "0", "allow_edit": "Karyo Loan Committee"}
			)
		for state in COMMITTEE_STATES:
			if not any(
				row.state == state and row.action == outcome and row.allowed == "Karyo Loan Committee"
				for row in workflow.transitions
			):
				workflow.append("transitions", {
					"state": state, "action": outcome, "next_state": outcome,
					"allowed": "Karyo Loan Committee", "allow_self_approval": 0,
				})
			if not any(
				row.state == state and row.action == outcome and row.allowed == "System Manager"
				for row in workflow.transitions
			):
				workflow.append("transitions", {
					"state": state, "action": outcome, "next_state": outcome,
					"allowed": "System Manager", "allow_self_approval": 1,
					"condition": "frappe.session.user != 'Administrator' and not frappe.db.get_value('Has Role', {'parent': frappe.session.user, 'role': 'Karyo Loan Committee'}, 'name')",
				})
			else:
				admin_row = next(
					row for row in workflow.transitions
					if row.state == state and row.action == outcome and row.allowed == "System Manager"
				)
				admin_row.condition = "frappe.session.user != 'Administrator' and not frappe.db.get_value('Has Role', {'parent': frappe.session.user, 'role': 'Karyo Loan Committee'}, 'name')"
	workflow.save(ignore_permissions=True)
	for field, additions in (("workflow_state", ["Cancelled"]), ("committee_decision", ["Approved", "Cancelled"])):
		meta = frappe.get_meta("Karyo Loan").get_field(field)
		options = (meta.options or "").split("\n")
		options.extend(value for value in additions if value not in options)
		custom_field = frappe.db.get_value("Custom Field", {"dt": "Karyo Loan", "fieldname": field}, "name")
		if custom_field:
			doc = frappe.get_doc("Custom Field", custom_field)
			doc.options = "\n".join(options)
			doc.save(ignore_permissions=True)
		else:
			from frappe.custom.doctype.property_setter.property_setter import make_property_setter

			make_property_setter("Karyo Loan", field, "options", "\n".join(options), "Text")
	frappe.clear_cache(doctype="Karyo Loan")
