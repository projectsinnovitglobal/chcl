from unittest.mock import patch
import unittest

import frappe

from karyo.security import employee_owned_permission, employee_owned_query, loan_file_permission


class TestEmployeeOwnedPermissions(unittest.TestCase):
	@patch("karyo.security._employee_for_user", return_value="EMP-001")
	@patch("karyo.security.frappe.get_roles", return_value=["Employee"])
	def test_employee_query_is_scoped_to_linked_employee(self, _roles, _employee):
		condition = employee_owned_query("employee@example.test", "Karyo Loan")
		self.assertIn("`tabKaryo Loan`.`employee`", condition)
		self.assertIn("EMP-001", condition)

	@patch("karyo.security._employee_for_user", return_value="EMP-001")
	@patch("karyo.security.frappe.get_roles", return_value=["Employee"])
	def test_employee_cannot_read_or_write_another_record(self, _roles, _employee):
		other = frappe._dict(employee="EMP-002")
		self.assertFalse(employee_owned_permission(other, "read", "employee@example.test"))
		self.assertFalse(employee_owned_permission(other, "write", "employee@example.test"))

	@patch("karyo.security.frappe.get_roles", return_value=["Passage Benefit Officer"])
	def test_privileged_role_defers_to_doctype_permissions(self, _roles):
		self.assertIsNone(employee_owned_query("pb@example.test", "Passage Benefit Bank"))
		self.assertIsNone(employee_owned_permission(frappe._dict(employee="EMP-002"), "read", "pb@example.test"))

	@patch("karyo.security.frappe.get_doc", return_value=frappe._dict(employee="EMP-002"))
	@patch("karyo.security._employee_for_user", return_value="EMP-001")
	@patch("karyo.security.frappe.get_roles", return_value=["Employee"])
	def test_private_loan_attachment_cannot_cross_employee_boundary(self, _roles, _employee, _loan):
		file_doc = frappe._dict(attached_to_doctype="Karyo Loan", attached_to_name="LOAN-OTHER")
		self.assertFalse(loan_file_permission(file_doc, "read", "employee@example.test"))
		self.assertFalse(loan_file_permission(file_doc, "write", "employee@example.test"))


if __name__ == "__main__":
	unittest.main()
