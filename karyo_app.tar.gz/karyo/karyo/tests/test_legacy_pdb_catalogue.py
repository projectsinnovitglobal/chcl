import unittest

from karyo.setup.legacy_pdb_catalogue import (
	_load_catalogue,
	_resolved_code,
	_target_type,
	_type_plan,
)


class TestLegacyPDBCatalogue(unittest.TestCase):
	def test_source_rows_exclude_sample_and_resolve_duplicate_codes(self):
		_payload, rows = _load_catalogue()
		self.assertEqual(len(rows), 382)
		self.assertNotIn("SAMPLE-PDB", {row["pdb_code"] for row in rows})
		occurrences = {}
		resolved = []
		for row in rows:
			code = row["pdb_code"]
			occurrences[code] = occurrences.get(code, 0) + 1
			resolved.append(_resolved_code(row, occurrences[code]))
		self.assertEqual(len(resolved), len(set(resolved)))
		self.assertIn("PASS-GEN", resolved)
		self.assertIn("RTAX-PAYE", resolved)

	def test_mixed_types_are_split_by_payment_or_deduction(self):
		_payload, rows = _load_catalogue()
		classifications, primary = _type_plan(rows)
		all_deduction = next(
			row for row in rows
			if row["pdb_type"] == "ALL" and row["payment_deduction"] == "D"
		)
		comp_deduction = next(
			row for row in rows
			if row["pdb_type"] == "COMP" and row["payment_deduction"] == "D"
		)
		self.assertEqual(_target_type(all_deduction, classifications, primary), "ALL-D")
		self.assertEqual(_target_type(comp_deduction, classifications, primary), "COMP-D")
