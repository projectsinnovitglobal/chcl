"""Persisted payment progress and payslip output availability."""
import frappe
from frappe import _

STATUSES = ('Draft', 'Processing', 'PAID')


def dashboard_filters():
    """Only period-backed, non-cancelled slips belong in generated payslip lists."""
    return {'docstatus': ('<', 2), 'start_date': ('is', 'set'), 'end_date': ('is', 'set')}


def status_info(doc):
    from karyo.desk.payroll_management import ADMIN_ROLES
    value = doc.get('karyo_payment_status') or 'Draft'
    manager = frappe.session.user == 'Administrator' or bool(ADMIN_ROLES.intersection(frappe.get_roles()))
    return {'payment_status': value, 'can_download': doc.docstatus != 2 and value == 'PAID',
        'can_set_payment_status': bool(manager and doc.docstatus != 2 and doc.has_permission('write'))}


def require_paid(name):
    doc = frappe.get_doc('Salary Slip', name)
    if not status_info(doc)['can_download']:
        frappe.throw(_('Payslip download is available only when Payment Status is PAID.'))


@frappe.whitelist(methods=['POST'])
def set_status(name, status):
    from karyo.desk.payroll_management import _admin
    _admin()
    if status not in STATUSES:
        frappe.throw(_('Choose Draft, Processing or PAID.'))
    frappe.db.sql('select name from `tabSalary Slip` where name=%s for update', name)
    doc = frappe.get_doc('Salary Slip', name)
    doc.check_permission('read'); doc.check_permission('write')
    if doc.docstatus == 2:
        frappe.throw(_('Cancelled payslips cannot change payment status.'))
    previous = doc.get('karyo_payment_status') or 'Draft'
    if previous != status:
        if status == 'PAID' and doc.docstatus != 1:
            frappe.throw(_(
                'Submit the Salary Slip before marking it PAID. Loan repayments '
                'are posted only from a submitted payslip.'
            ))
        if previous == 'PAID' and frappe.db.exists('Karyo Loan Payroll Allocation', {
            'salary_slip': doc.name, 'status': 'Paid', 'is_reversal': 0,
        }):
            frappe.throw(_('A paid payslip with posted loan deductions cannot be moved backwards. Cancel the Salary Slip to reverse it.'))
        if status == 'PAID':
            # Loan recovery becomes financial only at the same durable milestone
            # that makes the payslip available to the employee.
            from karyo.loan.payroll import salary_slip_paid
            salary_slip_paid(doc)
        doc.db_set('karyo_payment_status', status)
        doc.add_comment('Info', _('Payment Status changed from {0} to {1}.').format(previous, status))
        doc.notify_update()
        from karyo.hr.self_service import notify_employee_request
        notify_employee_request(doc)
    return status_info(doc)


@frappe.whitelist()
def admin_payslips(start=0, pending_only=0, page_length=25):
    from karyo.desk.payroll_management import _admin, payslip_run_context
    from frappe.utils import cint
    _admin()
    if not frappe.has_permission('Salary Slip', 'read'):
        frappe.throw(_('You do not have access to payslips.'), frappe.PermissionError)
    start = max(0, cint(start))
    page_length = max(1, min(cint(page_length) or 25, 25))
    rows = frappe.get_list('Salary Slip', filters=dashboard_filters(),
        or_filters=[['karyo_payment_status', 'is', 'not set'], ['karyo_payment_status', '!=', 'PAID']]
            if cint(pending_only) else None,
        fields=['name','employee','employee_name','start_date','end_date','net_pay','currency','creation','docstatus','karyo_calculated_paye'],
        order_by='creation desc, name desc', limit_start=start, limit_page_length=page_length + 1)
    for row in rows[:page_length]:
        slip = frappe.get_doc('Salary Slip', row.name)
        row.update(status_info(slip))
        row.update(payslip_run_context(slip))
        row['generated_on'] = row.creation
    return {'rows': rows[:page_length], 'has_more': len(rows) > page_length}
