from unittest.mock import patch
import frappe
from frappe.utils import nowdate, add_days
from karyo.tests.test_leave_balances import TestLeaveBalanceCalculation
from karyo.hr.self_service import leave_balances


class TestLiveCounters(TestLeaveBalanceCalculation):
	def test_manual_expiry_at_allocation_end_and_reversal(self):
		from hrms.hr.doctype.leave_ledger_entry.leave_ledger_entry import expire_allocation
		kind=self.make_allocation()
		allocation=frappe.get_doc('Leave Allocation',frappe.db.get_value('Leave Allocation',{'employee':self.employee.name,'leave_type':kind},'name'))
		expire_allocation(allocation)
		b=leave_balances(self.employee.name)[0]
		self.assertEqual((b['total'],b['taken'],b['expired'],b['remaining']),(12,0,12,0))
		entry=frappe.get_doc('Leave Ledger Entry',frappe.db.get_value('Leave Ledger Entry',{'transaction_name':allocation.name,'is_expired':1,'docstatus':1},'name'))
		entry.cancel()
		b=leave_balances(self.employee.name)[0]
		self.assertEqual((b['expired'],b['remaining']),(0,12))

	def test_multiple_partial_expiries_are_summed(self):
		from hrms.hr.doctype.leave_ledger_entry.leave_ledger_entry import create_leave_ledger_entry
		kind=self.make_allocation();allocation=frappe.get_doc('Leave Allocation',frappe.db.get_value('Leave Allocation',{'employee':self.employee.name,'leave_type':kind},'name'))
		for offset,amount in [(1,-3),(2,-2)]:
			create_leave_ledger_entry(allocation,{'leaves':amount,'transaction_name':allocation.name,'transaction_type':'Leave Allocation','from_date':add_days(nowdate(),offset),'to_date':add_days(nowdate(),offset),'is_carry_forward':0,'is_expired':1})
		b=leave_balances(self.employee.name)[0]
		self.assertEqual((b['expired'],b['remaining']),(5,7))

	def test_pb_posting_cancellation_and_live_events(self):
		frappe.db.set_value('Employee',self.employee.name,{'pb_eligible':1,'date_of_joining':'1990-01-01','karyo_date_confirmed':'1991-01-01','karyo_permanent_pensionable':1})
		bank=frappe.get_doc({'doctype':'Passage Benefit Bank','employee':self.employee.name,'opening_date':nowdate(),'opening_balance':10000}).insert()
		entries=[]
		with patch('frappe.publish_realtime') as publish:
			for kind,amount in [('Earning',1000),('Claim',-400),('Adjustment',200)]:
				doc=frappe.get_doc({'doctype':'Passage Benefit Ledger Entry','employee':self.employee.name,'pb_bank':bank.name,'posting_date':nowdate(),'entry_type':kind,'amount':amount}).insert();doc.submit();entries.append(doc)
			self.assertTrue(any(c.args and c.args[0]=='karyo_balance_updated' and c.kwargs.get('after_commit') for c in publish.call_args_list))
		bank.reload()
		self.assertEqual((bank.total_earned,bank.total_taken,bank.total_adjustments,bank.current_balance),(1000,400,200,10800))
		self.assertEqual(bank.periods[0].current_balance,10800)
		entries[0].cancel();bank.reload()
		self.assertEqual((bank.total_earned,bank.total_taken,bank.total_adjustments,bank.current_balance),(0,400,200,9800))
		self.assertEqual(bank.periods[0].current_balance,9800)

	def test_scheduled_calculation_posts_earned_balance(self):
		from uuid import uuid4
		from karyo.tasks import _run_passage_benefit_period
		frappe.db.set_value('Employee',self.employee.name,{'pb_eligible':1,'date_of_joining':'1990-01-01','karyo_date_confirmed':'1991-01-01','karyo_permanent_pensionable':1})
		bank=frappe.get_doc({'doctype':'Passage Benefit Bank','employee':self.employee.name,'opening_date':nowdate(),'opening_balance':0}).insert()
		# All setup is transaction-local and rolled back with the employee fixture.
		operation='counter-operation-'+uuid4().hex
		frappe.get_doc({'doctype':'Payroll Operation Code','name':operation,'is_active':1,'effective_from':nowdate()}).db_insert()
		from karyo.passage_benefit.params import resolve
		params=frappe._dict(resolve(nowdate()));params.update(pb_percentage=5,entitlement_operation_code=operation)
		# Isolated salary/closure inputs; no live payroll or policy is modified.
		frappe.get_doc({'doctype':'Salary Structure Assignment','name':'counter-salary-'+uuid4().hex,'employee':self.employee.name,'company':self.employee.company,'from_date':nowdate(),'base':30000,'docstatus':1}).db_insert()
		frappe.get_doc({'doctype':'Payroll Cycle','name':'counter-cycle-'+uuid4().hex,'company':self.employee.company,'start_date':nowdate(),'end_date':nowdate(),'status':'Closed'}).db_insert()
		previous=frappe.flags.in_test;frappe.flags.in_test=True
		try:
			with patch('karyo.tasks.resolve_pb_params',return_value=params), patch('karyo.karyo.doctype.passage_benefit_computation.passage_benefit_computation.resolve_params',return_value=params), patch('karyo.karyo.doctype.passage_benefit_computation.passage_benefit_computation.PassageBenefitComputation._operation_salary_at',return_value=(30000,'Fixture salary','fixture')):
				result=_run_passage_benefit_period(nowdate(),nowdate(),pay_period='counter-'+uuid4().hex[:8],employees=[self.employee.name],run_source='Scheduled')
		finally:frappe.flags.in_test=previous
		self.assertEqual(result['failed'],[])
		self.assertEqual(len(result['created']),1)
		bank.reload();earned=result['created'][0]['earned']
		self.assertGreater(earned,0)
		self.assertEqual(bank.total_earned,earned)
		self.assertEqual(bank.current_balance,earned)
		self.assertEqual(bank.periods[-1].opening_amount,earned)

		# A backdated adjustment must carry through the newly opened period.
		adjustment=frappe.get_doc({'doctype':'Passage Benefit Ledger Entry','employee':self.employee.name,'pb_bank':bank.name,'posting_date':nowdate(),'entry_type':'Adjustment','amount':200}).insert()
		adjustment.submit();bank.reload()
		self.assertEqual(bank.periods[-1].opening_amount,earned+200)
		adjustment.cancel();bank.reload()
		self.assertEqual(bank.periods[-1].opening_amount,earned)
		frappe.get_doc('Passage Benefit Computation',result['created'][0]['name']).cancel();bank.reload()
		self.assertEqual((bank.total_earned,bank.current_balance),(0,0))
		self.assertEqual(len(bank.periods),1)
