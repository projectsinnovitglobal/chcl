// My HR — employee self-service (ESS).
// PB-APP-001/002: apply only when a PB Bank exists (button guarded + clear error);
// PB-APP-005: bank values shown read-only; PB-APP-010 / PB-VIEW-005: own
// application + PB history; plus my loans, payslips, leave and sick leave bank.

frappe.pages["my-hr"].on_page_load = function (wrapper) {
	const $body = karyo.pages.scaffold(wrapper, {
		title: __("My HR"),
		subtitle: __("Your balances, claims, loans, payslips and leave — all in one place"),
		actions: [
			{label: __("My PB Bank"), onclick:()=>frappe.set_route("my-pb-bank")},
			{label: __("Bank Accounts"), onclick:()=>open_bank_accounts()},
			{label: __("Migration Upload"), onclick:()=>frappe.set_route("my-migration")},
			{
				label: __("Apply for Leave"),
				onclick: () => frappe.new_doc("Leave Application"),
			},
			{
				label: __("Ask AI"),
				onclick: () => karyo.ai.chat && karyo.ai.chat.open(),
			},
		],
	});
	const $pbBankAction = $(wrapper)
		.find(".karyo-page-actions .btn")
		.filter((_, button) => $(button).text().trim() === __("My PB Bank"))
		.prop("disabled", true);
	const $salaryBankAction = $(wrapper)
		.find(".karyo-page-actions .btn")
		.filter((_, button) => $(button).text().trim() === __("Bank Accounts"))
		.prop("disabled", true);
	const $migrationAction = $(wrapper)
		.find(".karyo-page-actions .btn")
		.filter((_, button) => $(button).text().trim() === __("Migration Upload"));
	if (!karyo.migration.can_upload()) $migrationAction.remove();

	const load = () => karyo.live.request(wrapper, {
		method: "karyo.desk.overview.my_hr",
		callback: (r) => render(r.message || {}),
	});
	load();

	async function open_bank_accounts() {
		let data;
		try {
			data = await frappe.xcall("karyo.desk.overview.my_bank_accounts");
		} catch (error) {
			frappe.msgprint({ title: __("Unable to load bank accounts"), indicator: "red", message: karyo.ui?.error_message(error, __("Please try again.")) || __("Please try again.") });
			return;
		}
		const bankOptions = [{ label: __("Select bank"), value: "" }, ...(data.banks || []).map((bank) => ({
			label: [bank.karyo_bank_code, bank.bank_name || bank.name].filter(Boolean).join(" · "), value: bank.name,
		}))];
		const branchesFor = (bank) => [{ label: __("Select branch"), value: "" }, ...(data.branches || [])
			.filter((branch) => !bank || branch.bank === bank)
			.map((branch) => ({ label: [branch.branch_code, branch.branch_name || branch.name].filter(Boolean).join(" · "), value: branch.name }))];
		let saving = false;
		const dialog = new frappe.ui.Dialog({
			title: __("Salary Bank Accounts"),
			size: "large",
			fields: [
				{ fieldtype: "HTML", fieldname: "split_rule", options: `<div class="alert alert-info mb-3">${frappe.utils.escape_html(data.rule || "")}</div>` },
				{ fieldtype: "Section Break", label: __("Primary Salary Bank") },
				{ fieldname: "primary_bank", fieldtype: "Select", label: __("Bank"), options: bankOptions, reqd: 1 },
				{ fieldname: "primary_branch", fieldtype: "Select", label: __("Branch"), reqd: 1 },
				{ fieldname: "primary_account", fieldtype: "Data", label: __("Account Number"), reqd: 1 },
				{ fieldname: "primary_account_holder", fieldtype: "Data", label: __("Account Holder") },
				{ fieldtype: "Column Break" },
				{ fieldname: "primary_effective_from", fieldtype: "Date", label: __("Effective From") },
				{ fieldname: "primary_effective_to", fieldtype: "Date", label: __("Effective To") },
				{ fieldtype: "Section Break", label: __("Secondary Salary Bank (Optional)") },
				{ fieldname: "secondary_bank", fieldtype: "Select", label: __("Bank"), options: bankOptions },
				{ fieldname: "secondary_branch", fieldtype: "Select", label: __("Branch") },
				{ fieldname: "secondary_account", fieldtype: "Data", label: __("Account Number") },
				{ fieldname: "secondary_account_holder", fieldtype: "Data", label: __("Account Holder") },
				{ fieldtype: "Column Break" },
				{ fieldname: "secondary_fixed_amount", fieldtype: "Currency", options: data.currency, label: __("Fixed Amount to Secondary Bank"), description: __("The remaining net salary is transferred to the primary account.") },
				{ fieldname: "secondary_effective_from", fieldtype: "Date", label: __("Effective From") },
				{ fieldname: "secondary_effective_to", fieldtype: "Date", label: __("Effective To") },
			],
			primary_action_label: __("Save Bank Accounts"),
			primary_action(values) {
				if (saving) return;
				const secondaryConfigured = flt(values.secondary_fixed_amount) || values.secondary_bank || values.secondary_branch || values.secondary_account;
				if (secondaryConfigured && (!values.secondary_bank || !values.secondary_branch || !values.secondary_account)) {
					frappe.msgprint(__("Complete the secondary bank, branch and account number, or clear the secondary account."));
					return;
				}
				saving = true;
				dialog.disable_primary_action();
				frappe.call({
					method: "karyo.desk.overview.update_my_bank_accounts",
					args: { ...values, employee_modified: data.modified },
					callback: (r) => {
						if (!r.message) return;
						dialog.hide();
						frappe.show_alert({ message: __("Salary bank accounts updated"), indicator: "green" });
						load();
					},
					always: () => { saving = false; dialog.enable_primary_action(); },
				});
			},
		});
		const updateBranchOptions = (prefix) => {
			const bank = dialog.get_value(`${prefix}_bank`);
			const branchField = dialog.fields_dict[`${prefix}_branch`];
			const current = dialog.get_value(`${prefix}_branch`);
			branchField.df.options = branchesFor(bank);
			branchField.refresh();
			if (current && !(data.branches || []).some((branch) => branch.name === current && branch.bank === bank)) {
				dialog.set_value(`${prefix}_branch`, "");
			}
		};
		dialog.fields_dict.primary_bank.df.onchange = () => updateBranchOptions("primary");
		dialog.fields_dict.secondary_bank.df.onchange = () => updateBranchOptions("secondary");
		dialog.show();
		for (const prefix of ["primary", "secondary"]) {
			dialog.fields_dict[`${prefix}_branch`].df.options = branchesFor(data[prefix]?.bank);
			dialog.fields_dict[`${prefix}_branch`].refresh();
		}
		dialog.set_values({
			primary_bank: data.primary?.bank || "", primary_branch: data.primary?.branch || "",
			primary_account: data.primary?.account || "", primary_account_holder: data.primary?.account_holder || "",
			primary_effective_from: data.primary?.effective_from || "", primary_effective_to: data.primary?.effective_to || "",
			secondary_bank: data.secondary?.bank || "", secondary_branch: data.secondary?.branch || "",
			secondary_account: data.secondary?.account || "", secondary_account_holder: data.secondary?.account_holder || "",
			secondary_fixed_amount: data.secondary?.fixed_amount || 0,
			secondary_effective_from: data.secondary?.effective_from || "", secondary_effective_to: data.secondary?.effective_to || "",
		});
	}

	function apply_for_loan(d) {
		const types = d.loan_types || [];
		if (!types.length) {
			frappe.msgprint(__("No active loan types are available. Please contact HR."));
			return;
		}
		let submitting = false;
		const dialog = new frappe.ui.Dialog({
			title: __("Apply for a Loan"),
			fields: [
				{
					fieldname: "loan_type",
					fieldtype: "Select",
					label: __("Loan Type"),
					options: types.map((type) => ({ label: type.label, value: type.value })),
					reqd: 1,
				},
				{ fieldname: "amount", fieldtype: "Currency", label: __("Requested Amount"), reqd: 1 },
				{ fieldname: "period_months", fieldtype: "Int", label: __("Repayment Period (Months)"), reqd: 1 },
				{ fieldname: "purpose", fieldtype: "Small Text", label: __("Purpose of Loan"), reqd: 1 },
				{ fieldname: "terms", fieldtype: "HTML" },
			],
			primary_action_label: __("Submit Application"),
			async primary_action(values) {
				if (submitting) return;
				submitting = true;
				dialog.disable_primary_action();
				dialog.get_primary_btn().prop("disabled", true).text(__("Submitting…"));
				frappe.call({
					method: "karyo.desk.overview.submit_ess_loan_application",
					args: values,
					callback: (r) => {
						if (!r.message) return;
						dialog.hide();
						frappe.show_alert({ message: __("Loan application {0} submitted", [r.message.name]), indicator: "green" });
						load();
					},
					error: (error) => frappe.msgprint({title: __("Unable to submit loan application"), indicator: "red", message: karyo.ui?.error_message(error, __("Please check the application and try again.")) || __("Please check the application and try again."), clear: true}),
					always: () => {
						submitting = false;
						dialog.enable_primary_action();
						dialog.get_primary_btn().prop("disabled", false).text(__("Submit Application"));
					},
				});
			},
		});
		const update_limits = () => {
			const selected = types.find((type) => type.value === dialog.get_value("loan_type")) || types[0];
			if (!selected) return;
			const amount = selected.max_amount ? format_currency(selected.max_amount) : __("As per eligibility");
			const term = selected.max_period_months ? __("{0} months", [selected.max_period_months]) : __("As per eligibility");
			dialog.fields_dict.terms.$wrapper.html(
				`<div class="text-muted small">${__("Rate")}: ${selected.interest_rate}% &nbsp; · &nbsp; ${__("Maximum")}: ${amount} &nbsp; · &nbsp; ${__("Maximum term")}: ${term}</div>`
			);
		};
		dialog.fields_dict.loan_type.df.onchange = update_limits;
		dialog.set_value("loan_type", types[0].value);
		update_limits();
		dialog.show();
	}

	function render(d) {
		$body.empty();
		if (!d.employee) {
			$pbBankAction.remove();
			$salaryBankAction.remove();
			$body.append(
				`<div class="karyo-home-card"><div class="karyo-home-empty">${__(
					"No Employee record is linked to your user. Ask HR to link one."
				)}</div></div>`
			);
			return;
		}
		$pbBankAction.prop("disabled", false);
		$salaryBankAction.prop("disabled", false);

		const salaryBanks = d.bank_accounts || {};
		const $bankGrid = karyo.pages.grid($body, 2);
		const $salaryBank = karyo.pages.panel($bankGrid, { title: __("Salary bank accounts"), span: 2 });
		const primary = salaryBanks.primary || {}, secondary = salaryBanks.secondary || {};
		$salaryBank.append(
			$("<p class='text-muted mb-3'>").text(salaryBanks.rule || __("Your net salary is routed to the configured accounts.")),
			$(`<div class="row"><div class="col-md-6 mb-3"><small class="text-muted d-block">${__("Primary account · remaining net salary")}</small><strong></strong><div class="text-muted small"></div></div><div class="col-md-6 mb-3"><small class="text-muted d-block">${__("Secondary account · fixed amount")}</small><strong></strong><div class="text-muted small"></div></div></div>`)
		);
		const $bankCols = $salaryBank.find(".row > div");
		$bankCols.eq(0).find("strong").text(primary.bank || __("Not configured"));
		$bankCols.eq(0).find("div").text([primary.branch, primary.account].filter(Boolean).join(" · ") || __("Add your primary salary account"));
		$bankCols.eq(1).find("strong").text(secondary.bank || __("Not configured"));
		$bankCols.eq(1).find("div").text(secondary.bank ? [secondary.branch, secondary.account, format_currency(secondary.fixed_amount || 0, salaryBanks.currency)].filter(Boolean).join(" · ") : __("No fixed secondary transfer"));
		$("<button class='btn btn-primary btn-sm'>").text(__("Update Bank Accounts")).on("click", open_bank_accounts).appendTo($salaryBank);

		const $resources = $('<section>').appendTo($body);
		karyo.employee_resources.mount($resources, 'my-hr-resources');
		if (d.salary_allocation) karyo.salary_scales.render_history($body, d.salary_allocation);
		const pb = d.pb;
		const my_flows = [...(d.shift_requests || []), ...(d.pb_applications || []), ...(d.loans || []), ...(d.expense_claims || []), ...(d.leave || []), ...(d.grievances || [])]
			.filter((item) => item.pill || item.status)
			.slice(0, 8)
			.map((item) => ({ title: item.label, context: item.description, route: item.route, status: item.pill || item.status, icon: "activity" }));
		karyo.pages.task_queue($body, { title: __("My requests in progress"), tasks: my_flows });
		const $myTime = $('<section class="sil-cycle"></section>').appendTo($body);
		karyo.pages.section_head($myTime, { title: __("My time"), action: { label: __("Request leave"), onclick: () => frappe.new_doc("Leave Application", { employee: d.employee.name }) } });
		karyo.pages.handoff($myTime, [
			{ title: __("Bank Accounts"), description: secondary.bank ? __("Primary plus fixed secondary transfer") : __("Primary salary account"), onclick: open_bank_accounts },
			{ title: __("Attendance"), description: __("{0} recent records", [(d.attendance || []).length]), route: "my-attendance" },
			{ title: __("Request a shift change"), description: (d.shift_requests || []).length ? __("Latest status: {0}", [d.shift_requests[0].pill]) : __("Current shift, requested shift, reason and duration"), onclick: () => karyo.shift_change.open({ on_success: load }) },
			{ title: __("Overtime Claim"), description: __("Overtime request, approval status, approved hours and payroll claim amount"), route: "my-overtime-bonuses" },
			...(karyo.migration.can_upload() ? [
				{ title: __("Upload Previous Leave / PB Balances"), description: __("Upload historical Employee, Leave and Passage Benefit CSV files for approval"), onclick: () => frappe.set_route("my-migration") },
				{ title: __("Process Previous Year Leaves"), description: __("Carry forward eligible previous-year leave balances"), route: "process-previous-year-leaves" },
			] : []),
			{ title: __("Leave"), description: __("{0} recent requests", [(d.leave || []).length]), route: "leave-application" },
			{ title: __("Sick bank"), description: d.sick_leave_bank ? __("{0} days", [d.sick_leave_bank.bank_days || 0]) : __("Not opened"), route: "sick-leave-bank" },
			{ title: __("Vacation bank"), description: d.vacation_leave_bank ? __("{0} days", [d.vacation_leave_bank.balance_days || 0]) : __("Not opened"), route: "vacation-leave-bank" },
		]);
		karyo.pages.task_queue($body, {
			title: __("Loan management"),
			action: { label: __("Apply for a loan"), onclick: () => apply_for_loan(d) },
			tasks: (d.loans || []).map((loan) => ({
				title: loan.label,
				context: `${loan.description} · ${__("Outstanding")} ${format_currency(loan.outstanding_capital || 0)}`,
				status: loan.workflow_state || loan.status,
				route: loan.route,
				icon: "circle-dollar-sign",
			})),
		});
		karyo.pages.stats($body, [
			{
				label: __("Passage benefit balance"),
				value: pb ? pb.current_balance : 0,
				currency: 1,
				sub: pb ? __("Bank {0}", [pb.name]) : __("No PB Bank yet"),
			},
			{ label: __("PB earned to date"), value: pb ? pb.total_earned : 0, currency: 1 },
			{ label: __("PB taken to date"), value: pb ? pb.total_taken : 0, currency: 1 },
			{
				label: __("Sick leave available"),
				value: d.sick_leave_bank ? d.sick_leave_bank.available_days : 0,
				sub: d.sick_leave_bank
					? __("{0} allocated · {1} taken", [d.sick_leave_bank.allotted_days || 0, d.sick_leave_bank.taken_days || 0])
					: __("No sick leave allocation"),
			},
		]);

		// ---- Balances at a glance: PB gauge, leave banks, loan repayment ----
		const $widgets = karyo.pages.grid($body, 3);
		karyo.pages.chart_card($widgets, {
			title: __("Passage benefit"),
			type: "donut",
			height: 170,
			data: pb && {
				labels: [__("Available"), __("Taken")],
				datasets: [{ values: [pb.current_balance || 0, pb.total_taken || 0] }],
			},
			colors: ["#10b981", "#f6821f"],
		});

		const $banks = karyo.pages.panel($widgets, { title: __("My leave banks") });
		const vac = d.vacation_leave_bank;
		const sick = d.sick_leave_bank;
		if (!vac && d.vacation_accrual) {
			const $rate = $('<div class="karyo-bank-counter"><div><span></span><strong></strong></div></div>').appendTo($banks);
			$rate.find('span').text(__("Vacation earned per day"));
			$rate.find('strong').text(__("{0} days", [
				karyo.pages.leave_days(d.vacation_accrual.daily_accrual_days),
			]));
		}
		if (vac) {
			karyo.pages.progress($banks, {
				label: __("Vacation leave"),
				value: vac.balance_days || 0,
				max: vac.ceiling_days || vac.balance_days || 1,
				color: "#0b6cfb",
				sub: vac.daily_accrual_days != null
					? __("earning {0} days per day · ceiling {1} days", [
						karyo.pages.leave_days(vac.daily_accrual_days), vac.ceiling_days || 0,
					])
					: (vac.ceiling_days ? __("ceiling {0} days", [vac.ceiling_days]) : ""),
			});
		}
		if (sick) {
			karyo.pages.progress($banks, {
				label: __("Sick leave bank"),
				value: sick.bank_days || 0,
				max: Math.max(sick.bank_days || 0, sick.opening_bank_days || 0) || 1,
				color: "#10b981",
				sub: sick.advance_balance_days
					? __("advance taken: {0} days", [sick.advance_balance_days])
					: "",
			});
		}
		if (!vac && !sick) {
			karyo.pages.empty_state($banks, { title: __("No leave banks yet") });
		}
		if ((d.leave_balances || []).length) {
			const leaveDays = karyo.pages.leave_days;
			const $counter = $('<div class="karyo-bank-counter"></div>').appendTo($banks);
			(d.leave_balances || []).forEach((balance) => {
				const $row = $('<div><span></span><strong></strong></div>').appendTo($counter);
				const $label = $row.find('span').text(__(balance.leave_type));
				if (balance.is_carry_forward) {
					$label.append(karyo.pages.pill(__(balance.tag || "Carry Forward"), "green"));
				}
				const summary = __('{0} allocated · {1} taken · {2} remaining', [
					leaveDays(balance.total), leaveDays(balance.taken), leaveDays(balance.remaining),
				]);
				const accrual = balance.leave_code === 'VAC01' && balance.daily_accrual_days != null
					? __(' · earning {0} days per day', [leaveDays(balance.daily_accrual_days)])
					: '';
				const opening = balance.opening_balance
					? __(' · includes {0} opening as at {1}', [
						leaveDays(balance.opening_balance),
						frappe.datetime.str_to_user(balance.opening_balance_as_at),
					])
					: '';
				$row.find('strong').text(summary + accrual + opening);
			});
		}

		const $loanProg = karyo.pages.panel($widgets, { title: __("Loan repayment") });
		const repayable = (d.loans || []).filter((l) => l.approved_amount);
		repayable.forEach((l) => {
			const outstanding = l.outstanding_total ?? l.outstanding_capital ?? 0;
			const repaymentStatus = l.repayment_status || __("Not started");
			karyo.pages.progress($loanProg, {
				label: l.label,
				value: (l.approved_amount || 0) - (l.outstanding_capital || 0),
				max: l.approved_amount || 1,
				currency: 1,
				color: l.status === "Active" ? "#0b6cfb" : "#10b981",
				sub: __(
					"Last EMI: {0} · Total paid: {1} · Outstanding: {2}",
					[__(repaymentStatus), format_currency(l.total_paid || 0), format_currency(outstanding)]
				),
			});
		});
		if (!repayable.length) {
			karyo.pages.empty_state($loanProg, { title: __("No loans") });
		}

		const $grid = karyo.pages.grid($body, 2);

		// PB claims — the New Claim button enforces PB-APP-001/002 client-side
		const $pbcol = karyo.pages.card_list(
			$grid,
			{
				title: __("My passage benefit claims"),
				empty: pb
					? __("No claims yet — use “New Claim” to apply")
					: __("You need a PB Bank before you can apply. Contact HR."),
			},
			d.pb_applications
		);
		const $claim = $(
			`<button class="btn btn-sm btn-primary" style="margin-top:8px">${__("New Claim")}</button>`
		).on("click", () => {
			if (!pb) {
				// PB-APP-002: block with a clear error when no PB Bank exists
				frappe.msgprint({
					title: __("No PB Bank"),
					message: __(
						"You cannot apply for a passage benefit because no PB Bank exists for you yet. Please contact HR."
					),
					indicator: "red",
				});
				return;
			}
			frappe.set_route("my-pb-bank");
		});
		$pbcol.append($claim);

		const $payslips = karyo.pages.panel($grid, {title: __("My payslips"), span: 1});
		$("<button class='btn btn-default btn-sm mb-2'>").text(__("All payslips / filter by month"))
			.on("click", () => frappe.set_route("my-payroll")).appendTo($payslips);
		if (!(d.payslips || []).length) $("<p class='text-muted'>").text(__("No generated payslips yet.")).appendTo($payslips);
		else karyo.payroll.employee_payslip_table($payslips, d.payslips, {view:name=>frappe.set_route("my-payroll",name)});

		karyo.pages.card_list(
			$grid,
			{ title: __("My leave"), empty: __("No leave applications yet") },
			d.leave
		);
		const $exp = karyo.pages.card_list(
			$grid,
			{ title: __("My expense claims"), empty: __("No expense claims yet") },
			d.expense_claims
		);
		$exp.append(
			$(
				`<button class="btn btn-sm karyo-btn-secondary" style="margin-top:8px">${__("New Expense Claim")}</button>`
			).on("click", () => frappe.new_doc("Expense Claim", { employee: d.employee.name }))
		);
		karyo.pages.card_list(
			$grid,
			{ title: __("My attendance"), empty: __("No attendance records yet") },
			d.attendance
		);
	}
};
