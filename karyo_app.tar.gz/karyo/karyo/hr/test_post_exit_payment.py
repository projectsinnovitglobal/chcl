"""Transactional regression for reactivation and genuine native supplemental payroll."""
import unittest
from uuid import uuid4
from unittest.mock import patch

import frappe
from frappe.utils import add_days, getdate, get_first_day, get_last_day, nowdate

from karyo.hr import final_settlement as api
from karyo.desk.payroll_management import employee_run_eligibility
from karyo.setup.employee_master import deactivate_separated_employee


class TestPostExitPayment(unittest.TestCase):
	def setUp(self):
		self.user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("post_exit_payment")
		self.mail = patch("frappe.sendmail"); self.mail.start(); self.addCleanup(self.mail.stop)
		self.events = patch("frappe.publish_realtime"); self.events.start(); self.addCleanup(self.events.stop)
		self.uid = uuid4().hex[:10]
		assigned = frappe.get_all("Salary Structure Assignment", filters={"docstatus": 1},
			fields=["employee", "name"], order_by="from_date asc", limit_page_length=0)
		source = next((r for r in assigned if frappe.db.get_value("Employee", r.employee, "status") == "Active"), None)
		if not source:
			self.skipTest("An active assigned employee is required")
		self.employee = frappe.copy_doc(frappe.get_doc("Employee", source.employee))
		self.employee.name = "POSTEXIT-" + self.uid
		self.employee.docstatus = 0
		self.employee.user_id = None
		self.employee.status = "Inactive"
		self.employee.date_of_joining = "2000-01-01"
		self.employee.relieving_date = add_days(get_first_day(nowdate()), -1)
		self.employee.karyo_post_exit_payroll_enabled = 0
		self.employee.karyo_post_exit_payroll_until = None
		self.employee.karyo_post_exit_payment_reference = None
		self.employee.karyo_payroll_setup_pending_activation = 0
		for field in self.employee.meta.fields:
			if field.unique: self.employee.set(field.fieldname, None)
		self.employee.db_insert()
		assignment = frappe.copy_doc(frappe.get_doc("Salary Structure Assignment", source.name))
		assignment.name = "POSTEXIT-SSA-" + self.uid
		assignment.docstatus = 1
		assignment.employee = self.employee.name
		assignment.from_date = "2000-01-01"
		assignment.db_insert()
		self.structure = assignment.salary_structure
		self.separation = frappe.get_doc({"doctype": "Employee Separation", "name": "POSTEXIT-SEP-" + self.uid,
			"employee": self.employee.name, "company": self.employee.company, "docstatus": 1,
			"boarding_status": "Completed", "karyo_leaving_date": self.employee.relieving_date,
			"karyo_settlement_status": "Finalized"})
		self.separation.db_insert()
		self.until = get_last_day(nowdate())

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="post_exit_payment")
		self.mail.stop(); self.events.stop()
		frappe.set_user(self.user)

	def open(self):
		return api.open_post_exit_payment(self.employee.name, self.until, "APPROVED-LATE-PAYMENT-" + self.uid)

	def additional(self, amount=1234, recurring=False):
		component = frappe.db.get_value("Salary Component", {"type": "Earning", "is_flexible_benefit": 0,
			"variable_based_on_taxable_salary": 0}, "name")
		return frappe.get_doc({"doctype": "Additional Salary", "employee": self.employee.name,
			"company": self.employee.company, "salary_component": component, "type": "Earning", "amount": amount,
			"payroll_date": nowdate(), "is_recurring": int(recurring),
			"from_date": get_first_day(nowdate()) if recurring else None,
			"to_date": self.until if recurring else None})

	def slip(self):
		return frappe.get_doc({"doctype": "Salary Slip", "employee": self.employee.name,
			"company": self.employee.company, "posting_date": nowdate(), "start_date": get_first_day(nowdate()),
			"end_date": get_last_day(nowdate()), "payroll_frequency": "Monthly",
			"currency": frappe.db.get_value("Company", self.employee.company, "default_currency"), "exchange_rate": 1})

	def test_open_edit_repeat_completion_close_and_reopen_keep_history(self):
		leaving = self.employee.relieving_date
		self.assertTrue(self.open()["active"])
		self.employee.reload()
		self.employee.cell_number = "12345"
		self.employee.save()
		deactivate_separated_employee(self.separation)
		self.employee.reload()
		self.assertEqual(self.employee.status, "Active")
		self.assertEqual(getdate(self.employee.relieving_date), getdate(leaving))
		self.assertEqual(self.separation.boarding_status, "Completed")
		from karyo.desk.people import employee_360
		from karyo.desk.payroll_screens import employee_header
		self.assertEqual(employee_360(self.employee.name)["post_exit_payment"], employee_header(self.employee.name)["post_exit_payment"])
		self.assertEqual(api.close_post_exit_payment(self.employee.name)["status"], "Inactive")
		self.assertTrue(self.open()["active"])
		self.assertGreaterEqual(frappe.db.count("Comment", {"reference_doctype": "Employee", "reference_name": self.employee.name}), 3)

	def test_authority_and_date_validation_and_no_plain_status_bypass(self):
		for until, reference in [(None, "OK"), (add_days(nowdate(), -1), "OK"), (self.until, " ")]:
			with self.assertRaises(frappe.ValidationError): api.open_post_exit_payment(self.employee.name, until, reference)
		self.employee.status = "Active"
		with self.assertRaises(frappe.ValidationError): self.employee.save()
		self.open(); self.employee.reload()
		self.employee.karyo_post_exit_payment_reference = "tampered"
		with self.assertRaises(frappe.ValidationError): self.employee.save()
		frappe.set_user("Guest")
		with self.assertRaises(frappe.PermissionError): self.open()

	def test_payroll_reactivation_keeps_separated_login_disabled(self):
		user = frappe.get_doc({"doctype": "User", "email": "postexit-" + self.uid + "@example.test",
			"first_name": "Post exit test", "enabled": 0, "send_welcome_email": 0,
			"roles": [{"role": "Employee"}]}).insert(ignore_permissions=True)
		frappe.db.set_value("Employee", self.employee.name, "user_id", user.name)
		self.open()
		self.assertEqual(frappe.db.get_value("User", user.name, "enabled"), 0)
		self.employee.reload(); self.employee.save()
		self.assertEqual(frappe.db.get_value("User", user.name, "enabled"), 0)

	def test_closed_window_cannot_deactivate_an_ordinary_employee(self):
		frappe.db.set_value("Employee", self.employee.name, "status", "Active")
		self.assertEqual(api.close_post_exit_payment(self.employee.name)["status"], "Active")

	def test_expired_authority_blocks_payroll_before_scheduler_and_scheduler_closes(self):
		self.open()
		frappe.db.set_value("Employee", self.employee.name, "karyo_post_exit_payroll_until", add_days(nowdate(), -1))
		self.employee.reload()
		self.assertFalse(employee_run_eligibility(self.employee, get_first_day(nowdate()), self.until)["eligible"])
		with self.assertRaises(frappe.ValidationError): self.additional().insert()
		api.close_expired_post_exit_windows()
		self.employee.reload()
		self.assertEqual(self.employee.status, "Inactive")
		self.assertFalse(self.employee.karyo_post_exit_payroll_enabled)

	def test_processing_readiness_and_closing_include_the_same_approved_employee(self):
		from karyo.payroll.employee_processing import resolve_employees
		from karyo.payroll.employee_closing import population
		from karyo.payroll.readiness import validate_employee
		cycle = frappe._dict(name="POSTEXIT-CYCLE-" + self.uid, company=self.employee.company,
			pay_day=None, payroll_entry=None, payroll_type=self.employee.karyo_payroll_type,
			start_date=get_first_day(nowdate()), end_date=self.until, payment_date=getdate(nowdate()))
		with self.assertRaises(frappe.ValidationError): resolve_employees(cycle, [self.employee.name])
		self.open()
		self.assertEqual(resolve_employees(cycle, [self.employee.name])[0], [self.employee.name])
		self.assertIn(self.employee.name, population(cycle))
		self.assertNotIn("EMPLOYEE_INACTIVE", {r["validation_code"] for r in validate_employee(cycle, self.employee.name)})
		api.close_post_exit_payment(self.employee.name)
		with self.assertRaises(frappe.ValidationError): resolve_employees(cycle, [self.employee.name])

	def test_regular_employee_keeps_normal_salary_components(self):
		frappe.db.delete("Employee Separation", {"name": self.separation.name})
		frappe.db.set_value("Employee", self.employee.name, {"status": "Active", "relieving_date": None})
		for day in range(1, getdate(self.until).day + 1):
			frappe.get_doc({"doctype": "Attendance", "name": "POSTEXIT-ATT-" + frappe.generate_hash(),
				"employee": self.employee.name, "company": self.employee.company,
				"attendance_date": getdate(nowdate()).replace(day=day), "status": "Present", "docstatus": 1}).db_insert()
		slip = self.slip().insert()
		self.assertGreater(slip.karyo_basic_pay, 0)
		self.assertTrue(any(not row.additional_salary for row in slip.earnings))

	def test_native_additional_salary_and_salary_slip_process_only_submitted_one_off_pay(self):
		self.open()
		with self.assertRaises(frappe.ValidationError): self.additional(recurring=True).insert()
		with self.assertRaises(frappe.ValidationError): self.slip().insert()
		payment = self.additional().insert(); payment.submit()
		# A legacy recurring input must not start regular payments again.
		frappe.get_doc({"doctype": "Additional Salary", "name": "POSTEXIT-REC-" + self.uid,
			"employee": self.employee.name, "company": self.employee.company,
			"salary_component": payment.salary_component, "type": "Earning", "amount": 9999,
			"is_recurring": 1, "from_date": get_first_day(nowdate()), "to_date": self.until, "docstatus": 1}).db_insert()
		slip = self.slip().insert()
		self.assertEqual(slip.gross_pay, 1234)
		self.assertEqual({r.additional_salary for r in slip.earnings}, {payment.name})
		self.assertEqual(getdate(frappe.db.get_value("Employee", self.employee.name, "relieving_date")), getdate(self.employee.relieving_date))
		# Native duplicate guards continue to apply.
		with self.assertRaises(frappe.ValidationError): self.slip().insert()
		slip.submit()
		self.assertEqual(slip.docstatus, 1)
		self.assertEqual(slip.gross_pay, 1234)
		api.close_post_exit_payment(self.employee.name)
		with self.assertRaises(frappe.ValidationError): self.additional(200).insert()
