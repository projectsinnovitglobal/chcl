from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.leave_encashment import (
	KaryoLeaveEncashment,
	_bind_employee_and_cycle,
	_current_open_cycle,
	encashable_balances,
	encashment_defaults,
	prepare_payroll_mapping,
	sync_payroll_mapping,
)


class TestKaryoLeaveEncashment(FrappeTestCase):
	def test_encashment_days_start_at_zero_until_employee_enters_quantity(self):
		doc = KaryoLeaveEncashment({
			"doctype": "Leave Encashment", "actual_encashable_days": 10,
			"encashment_days": None,
		})
		doc.set_encashment_days()
		self.assertEqual(doc.encashment_days, 0)

	def test_leave_encashment_is_a_traced_payroll_source(self):
		from karyo.payroll.source_trace import CATEGORY_BY_SOURCE, TRACE_FIELDS

		self.assertEqual(CATEGORY_BY_SOURCE["Leave Encashment"], "Leave Encashment")
		self.assertIn("encashment_days", TRACE_FIELDS["Leave Encashment"])

	def test_approval_deducts_leave_and_posts_pdb_earning_to_current_cycle(self):
		frappe.set_user("Administrator")
		row = next((row for row in encashable_balances() if row["available_days"] >= 0.5), None)
		if not row:
			self.skipTest("No employee has a qualified encashable balance")
		cycle = _current_open_cycle(row["employee"])
		if not cycle:
			self.skipTest("No open payroll cycle for a qualified employee")
		doc = frappe.get_doc({
			"doctype": "Leave Encashment",
			"employee": row["employee"],
			"leave_type": row["leave_type"],
			"encashment_date": cycle.payment_date or cycle.end_date,
			"encashment_days": 0.5,
			"pay_via_payment_entry": 0,
		}).insert()
		if doc.encashment_amount <= 0:
			self.skipTest("Qualified employee has no configured encashment rate")
		doc.submit()
		doc.reload()
		earning = frappe.db.get_value(
			"Additional Salary", doc.additional_salary,
			["docstatus", "karyo_payroll_cycle", "karyo_pdb_code", "karyo_transaction_category", "amount"],
			as_dict=True,
		)
		self.assertEqual(earning.docstatus, 1)
		self.assertEqual(earning.karyo_payroll_cycle, cycle.name)
		self.assertEqual(earning.karyo_pdb_code, "LENC")
		self.assertEqual(earning.karyo_transaction_category, "Leave Encashment")
		self.assertEqual(earning.amount, doc.encashment_amount)
		self.assertTrue(frappe.db.exists(
			"Leave Ledger Entry",
			{"transaction_type": "Leave Encashment", "transaction_name": doc.name, "docstatus": 1},
		))

	@patch("karyo.hr.leave_encashment.encashable_balances")
	@patch("karyo.hr.leave_encashment._current_open_cycle")
	@patch("karyo.hr.leave_encashment._is_encashment_admin", return_value=True)
	@patch("karyo.hr.leave_encashment.frappe.db.get_value")
	def test_defaults_include_qualified_counter_and_current_cycle(self, get_value, _admin, cycle, balances):
		get_value.return_value = frappe._dict(
			name="EMP-1", employee_name="Employee One", department="Operations", company="MBC",
		)
		cycle.return_value = frappe._dict(
			name="PAYC-1", status="Input Open", payment_date="2026-09-25",
			end_date="2026-09-30", pay_period_label="September 2026",
		)
		balances.return_value = [{"leave_type": "Annual Leave", "available_days": 5}]
		result = encashment_defaults("EMP-1")
		self.assertEqual(result["karyo_payroll_cycle"], "PAYC-1")
		self.assertEqual(result["available_balances"][0]["available_days"], 5)

	@patch("karyo.hr.leave_encashment.frappe.db.sql")
	@patch("karyo.hr.leave_encashment.frappe.db.get_value")
	def test_current_cycle_uses_ungrouped_pay_day_as_profile_fallback(self, get_value, sql):
		get_value.return_value = frappe._dict(
			company="MBC", karyo_payroll_type="Major", karyo_payroll_group="Permanent",
		)
		sql.return_value = [
			frappe._dict(name="MINOR", payroll_type="Minor", payroll_group="Permanent"),
			frappe._dict(
				name="MAJOR", payroll_type="Major", payroll_group=None,
				status="Input Open", start_date="2026-07-01", end_date="2026-07-31",
				payment_date="2026-07-25", pay_period_label="July 2026",
			),
		]
		self.assertEqual(_current_open_cycle("EMP-1").name, "MAJOR")

	@patch("karyo.hr.leave_encashment._current_open_cycle")
	@patch("karyo.hr.leave_encashment._is_encashment_admin", return_value=True)
	@patch("karyo.hr.leave_encashment.frappe.db.get_value")
	def test_binding_moves_payroll_date_inside_current_cycle(self, get_value, _admin, cycle):
		get_value.return_value = frappe._dict(
			employee_name="Employee One", department="Operations", company="MBC",
		)
		cycle.return_value = frappe._dict(
			name="PAYC-1", start_date="2026-07-01", end_date="2026-07-31",
			payment_date="2026-07-25",
		)
		doc = frappe._dict(
			employee="EMP-1", company="MBC", encashment_date="2026-09-19",
			pay_via_payment_entry=1,
			meta=frappe._dict(has_field=lambda field: field == "karyo_payroll_cycle"),
		)
		_bind_employee_and_cycle(doc)
		self.assertEqual(doc.karyo_payroll_cycle, "PAYC-1")
		self.assertEqual(doc.encashment_date, "2026-07-25")
		self.assertEqual(doc.pay_via_payment_entry, 0)

	def test_missing_daily_rate_uses_assigned_base_and_refund_divisor(self):
		doc = KaryoLeaveEncashment({
			"doctype": "Leave Encashment", "encashment_days": 2,
			"encashment_amount": 0, "employee": "EMP-1",
			"encashment_date": "2026-09-19", "leave_type": "Annual Leave",
		})
		doc._salary_structure = "STRUCT-1"
		with patch(
			"karyo.hr.leave_encashment.LeaveEncashment.set_encashment_amount"
		) as native_calculation, patch(
			"karyo.hr.leave_encashment.frappe.db.get_single_value", return_value=22,
		), patch(
			"karyo.hr.leave_encashment.frappe.db.get_value",
			side_effect=[frappe._dict(base=44000, leave_encashment_amount_per_day=0), 0],
		):
			doc.set_encashment_amount()
		native_calculation.assert_called_once_with()
		self.assertEqual(doc.karyo_encashment_rate_per_day, 2000)
		self.assertEqual(doc.encashment_amount, 4000)

	@patch("karyo.hr.self_service.leave_balances")
	@patch("karyo.hr.leave_encashment.frappe.get_all")
	def test_available_counter_applies_reserved_and_maximum_days(self, get_all, balances):
		get_all.side_effect = [
			[frappe._dict(
				name="Annual Leave", earning_component="Leave Encashment",
				non_encashable_leaves=4, max_encashable_leaves=5,
				karyo_mbc_leave_code="ANN",
			)],
			[frappe._dict(
				name="ALLOC-1", employee="EMP-1", employee_name="Employee One",
				leave_type="Annual Leave", from_date="2026-01-01", to_date="2026-12-31",
			)],
		]
		balances.return_value = [{
			"leave_type": "Annual Leave", "confirmed_remaining": 12,
		}]
		rows = encashable_balances("EMP-1")
		self.assertEqual(rows[0]["available_days"], 5)
		self.assertEqual(rows[0]["earning_component"], "Leave Encashment")

	@patch("karyo.hr.leave_encashment.frappe.db.get_value")
	def test_prepare_requires_active_earning_component(self, get_value):
		get_value.side_effect = ["Leave Encashment", frappe._dict(type="Earning", disabled=0)]
		doc = frappe._dict(
			leave_type="Annual Leave", pay_via_payment_entry=0,
			meta=frappe._dict(has_field=lambda field: field == "karyo_earning_component"),
		)
		prepare_payroll_mapping(doc)
		self.assertEqual(doc.karyo_earning_component, "Leave Encashment")

	@patch("karyo.hr.leave_encashment.frappe.db.get_value")
	def test_approved_encashment_links_employee_earning_and_cycle(self, get_value):
		get_value.side_effect = [
			frappe._dict(
				name="ADD-SAL-1", employee="EMP-1", salary_component="Leave Encashment",
				karyo_payroll_cycle="PAY-CYCLE-1",
			),
			"Leave Encashment",
		]
		doc = frappe._dict(
			docstatus=1, pay_via_payment_entry=0, name="ENC-1", employee="EMP-1",
			leave_type="Annual Leave", additional_salary=None,
			meta=frappe._dict(has_field=lambda field: field in {"karyo_earning_component", "karyo_payroll_cycle"}),
		)
		captured = {}
		doc.db_set = lambda values, update_modified=False: captured.update(values)
		sync_payroll_mapping(doc)
		self.assertEqual(captured["additional_salary"], "ADD-SAL-1")
		self.assertEqual(captured["karyo_earning_component"], "Leave Encashment")
		self.assertEqual(captured["karyo_payroll_cycle"], "PAY-CYCLE-1")
