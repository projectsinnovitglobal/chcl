import frappe
from frappe import _
from frappe.utils import flt, getdate, nowdate

from karyo.karyo.report.loan_report_utils import add_loan_permission_condition

SOURCE_DOCTYPES = ("Karyo Loan", "Karyo Loan Recast", "Karyo Loan Interest Change", "Karyo Loan Insurance Change")


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if filters.from_date and filters.to_date and getdate(filters.from_date) > getdate(filters.to_date):
		frappe.throw(_("Effective From cannot be after Effective To."))
	conditions = ["a.ref_doctype in %(source_doctypes)s"]
	filters.source_doctypes = SOURCE_DOCTYPES
	loan_expression = "coalesce(if(a.ref_doctype='Karyo Loan', a.ref_docname, null), r.loan, ic.loan, ins.loan)"
	if not add_loan_permission_condition(conditions, filters, loan_expression):
		return _columns(), [], None, None, []
	for field, expression in (("company", "a.company"), ("employee", "a.employee")):
		if filters.get(field):
			conditions.append(f"{expression}=%({field})s")
	if filters.loan:
		conditions.append("coalesce(if(a.ref_doctype='Karyo Loan', a.ref_docname, null), r.loan, ic.loan, ins.loan)=%(loan)s")
	if filters.from_date:
		conditions.append("coalesce(a.to_date, a.payroll_date, a.from_date) >= %(from_date)s")
	if filters.to_date:
		conditions.append("coalesce(a.from_date, a.payroll_date) <= %(to_date)s")
	rows = frappe.db.sql(
		f"""select a.name additional_salary, a.employee, a.employee_name, a.company,
			a.salary_component, a.amount monthly_amount,
			coalesce(rp.start_date, a.from_date) effective_from,
			coalesce(rp.end_date, a.to_date) effective_to,
			a.payroll_date, a.ref_doctype source_doctype,
			a.ref_docname source_name, a.docstatus additional_salary_docstatus,
			a.disabled, a.creation,
			coalesce(if(a.ref_doctype='Karyo Loan', a.ref_docname, null), r.loan, ic.loan, ins.loan) loan,
			coalesce(d.component_type,
				case when a.salary_component like '%%Capital%%' then 'Capital'
					when a.salary_component like '%%Interest%%' then 'Interest'
					when a.salary_component like '%%Insurance%%' then 'Insurance' end) component,
			d.status deduction_row_status, rp.status recurring_status,
			group_concat(distinct if(ss.docstatus=1, ss.name, null) order by ss.start_date separator ', ') salary_slips,
			group_concat(distinct if(ss.docstatus=1, concat(date_format(ss.start_date, '%%Y-%%m-%%d'), ' to ', date_format(ss.end_date, '%%Y-%%m-%%d')), null) order by ss.start_date separator ', ') payroll_periods,
			group_concat(distinct if(ss.docstatus=1, ss.karyo_payroll_cycle, null) order by ss.start_date separator ', ') payroll_cycles,
			count(distinct if(ss.docstatus=1, ss.name, null)) payroll_use_count,
			min(if(ss.docstatus=1, ss.posting_date, null)) first_payroll_date,
			max(if(ss.docstatus=1, ss.posting_date, null)) last_payroll_date
		from `tabAdditional Salary` a
		left join `tabKaryo Loan Recast` r on a.ref_doctype='Karyo Loan Recast' and r.name=a.ref_docname
		left join `tabKaryo Loan Interest Change` ic on a.ref_doctype='Karyo Loan Interest Change' and ic.name=a.ref_docname
		left join `tabKaryo Loan Insurance Change` ins on a.ref_doctype='Karyo Loan Insurance Change' and ins.name=a.ref_docname
		left join `tabKaryo Loan Deduction` d on d.additional_salary=a.name
		left join `tabEmployee Recurring PDB` rp on rp.name=d.recurring_pdb
		left join `tabSalary Detail` sd on sd.additional_salary=a.name and sd.parenttype='Salary Slip'
		left join `tabSalary Slip` ss on ss.name=sd.parent
		where {' and '.join(conditions)}
		group by a.name
		order by a.employee, loan, component, a.from_date, a.creation""",
		filters, as_dict=True,
	)
	_set_statuses(rows)
	data = [row for row in rows if (not filters.component or row.component == filters.component)
		and (not filters.status or row.status == filters.status)]
	data = _combine_loan_rows(_select_current_components(data))
	summary = [
		{"value": len(data), "indicator": "Blue", "label": _("Loans"), "datatype": "Int"},
		{"value": sum(flt(row.total_monthly_emi) for row in data if row.status == "Active"), "indicator": "Green", "label": _("Active Monthly Total"), "datatype": "Currency"},
		{"value": sum(int(row.payroll_use_count or 0) for row in data), "indicator": "Grey", "label": _("Payroll Uses"), "datatype": "Int"},
	]
	return _columns(), data, None, None, summary


def _set_statuses(rows):
	today = getdate(nowdate())
	groups = {}
	for row in rows:
		groups.setdefault((row.loan, row.employee, row.component), []).append(row)
	for group in groups.values():
		group.sort(key=lambda row: (row.effective_from or row.payroll_date or "", row.creation or "", row.additional_salary))
		for index, row in enumerate(group):
			if row.recurring_status:
				row.status = row.recurring_status
			elif row.additional_salary_docstatus == 2 or row.deduction_row_status == "Cancelled":
				row.status = "Cancelled"
			elif row.disabled and any(later.additional_salary_docstatus == 1 and not later.disabled for later in group[index + 1:]):
				row.status = "Superseded"
			elif row.effective_to and getdate(row.effective_to) < today:
				row.status = "Ended"
			elif row.additional_salary_docstatus == 1 and not row.disabled:
				row.status = "Active"
			else:
				row.status = "Cancelled"


def _select_current_components(rows):
	"""Keep the current instruction when a loan component has versioned rows."""
	selected = {}
	priority = {"Active": 4, "Superseded": 3, "Ended": 2, "Cancelled": 1}
	for row in rows:
		key = (row.loan, row.component)
		rank = (
			priority.get(row.status, 0),
			str(row.effective_from or row.payroll_date or ""),
			str(row.creation or ""),
			str(row.additional_salary or ""),
		)
		if key not in selected or rank > selected[key][0]:
			selected[key] = (rank, row)
	return [value[1] for value in selected.values()]


def _combine_loan_rows(rows):
	"""Present capital, interest and insurance as columns on one row per loan."""
	groups = {}
	for row in rows:
		group = groups.setdefault(row.loan, frappe._dict({
			"loan": row.loan, "employee": row.employee, "employee_name": row.get("employee_name"),
			"company": row.get("company"), "effective_from": row.get("effective_from"),
			"effective_to": row.get("effective_to"), "capital_amount": 0,
			"interest_amount": 0, "insurance_amount": 0, "payroll_use_count": 0,
			"first_payroll_date": row.get("first_payroll_date"),
			"last_payroll_date": row.get("last_payroll_date"),
			"_statuses": set(), "_salary_components": set(), "_sources": set(),
			"_source_names": set(), "_additional_salaries": set(), "_salary_slips": set(),
			"_payroll_periods": set(), "_payroll_cycles": set(),
		}))
		component = (row.component or "").lower()
		if component in ("capital", "interest", "insurance"):
			group[f"{component}_amount"] += flt(row.monthly_amount)
		group.payroll_use_count = max(group.payroll_use_count, int(row.payroll_use_count or 0))
		for target, value in (
			("_statuses", row.status), ("_salary_components", row.get("salary_component")),
			("_sources", row.get("source_doctype")), ("_source_names", row.get("source_name")),
			("_additional_salaries", row.get("additional_salary")),
			("_salary_slips", row.get("salary_slips")),
			("_payroll_periods", row.get("payroll_periods")),
			("_payroll_cycles", row.get("payroll_cycles")),
		):
			if value:
				group[target].update(item.strip() for item in str(value).split(",") if item.strip())
		for fieldname, pick_earliest in (("effective_from", True), ("first_payroll_date", True),
			("effective_to", False), ("last_payroll_date", False)):
			value = row.get(fieldname)
			current = group.get(fieldname)
			if value and (not current or (value < current if pick_earliest else value > current)):
				group[fieldname] = value
	for group in groups.values():
		group.total_monthly_emi = flt(
			group.capital_amount + group.interest_amount + group.insurance_amount, 2
		)
		for fieldname, source in (
			("status", "_statuses"), ("salary_component", "_salary_components"),
			("source_doctype", "_sources"), ("source_name", "_source_names"),
			("additional_salary", "_additional_salaries"), ("salary_slips", "_salary_slips"),
			("payroll_periods", "_payroll_periods"), ("payroll_cycles", "_payroll_cycles"),
		):
			group[fieldname] = ", ".join(sorted(group.pop(source)))
	return sorted(groups.values(), key=lambda row: (row.employee or "", row.loan or ""))


def _columns():
	def c(fieldname, label, fieldtype="Data", width=120, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("loan", "Loan", "Link", 145, "Karyo Loan"), c("employee", "Employee", "Link", 125, "Employee"),
		c("employee_name", "Employee Name", width=155),
		c("capital_amount", "Loan Capital", "Currency", 115), c("interest_amount", "Loan Interest", "Currency", 115),
		c("insurance_amount", "Loan Insurance", "Currency", 115), c("total_monthly_emi", "Total Monthly EMI", "Currency", 135),
		c("salary_component", "Salary Components", width=190),
		c("status", "Status", width=100), c("effective_from", "Effective From", "Date", 105), c("effective_to", "Effective To", "Date", 100),
		c("source_doctype", "Source Type(s)", width=155), c("source_name", "Source(s)", width=155),
		c("additional_salary", "Additional Salaries", width=190), c("payroll_use_count", "Payroll Uses", "Int", 95),
		c("salary_slips", "Salary Slips", width=220), c("payroll_periods", "Payroll Periods", width=220), c("payroll_cycles", "Payroll Cycles", width=180),
		c("first_payroll_date", "First Payroll", "Date", 100), c("last_payroll_date", "Last Payroll", "Date", 100), c("company", "Company", "Link", 140, "Company")]
