frappe.query_reports["Leave Transaction Register"] = {
	filters: [
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
		{fieldname: "leave_code", label: __("Leave Code"), fieldtype: "Data"},
		{fieldname: "from_date", label: __("Start Date From"), fieldtype: "Date"},
		{fieldname: "to_date", label: __("End Date To"), fieldtype: "Date"},
		{fieldname: "status", label: __("Status"), fieldtype: "Data"},
		{fieldname: "cancelled", label: __("Cancelled"), fieldtype: "Select", options: "\nNo\nYes"},
	],
};
