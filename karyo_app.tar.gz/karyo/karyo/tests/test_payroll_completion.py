import unittest
from uuid import uuid4
from unittest.mock import patch
import frappe
from karyo.payroll.completion import cycle_status, run_step, employee_status, set_salary_point


class TestPayrollCompletion(unittest.TestCase):
	def setUp(self):
		self.user=frappe.session.user;frappe.set_user('Administrator');frappe.db.savepoint('completion_test')
		self.mail=patch('frappe.sendmail');self.mail.start()
		self.realtime=patch('frappe.publish_realtime');self.realtime.start()
		template = frappe.db.get_value('Payroll Pay Day', {'payroll_type': 'Major'}, 'name', order_by='start_date')
		day=frappe.copy_doc(frappe.get_doc('Payroll Pay Day', template))
		day.name='completion-'+uuid4().hex;day.pay_day_code=day.name;day.status='Active';day.payroll_type='Minor';day.pay_period_label='Completion test '+uuid4().hex[:8];day.docstatus=0;day.db_insert()
		self.cycle=frappe.get_doc({'doctype':'Payroll Cycle','company':day.company,'pay_day':day.name,'status':'Draft'}).insert()

	def tearDown(self):
		frappe.set_user('Administrator');frappe.db.rollback(save_point='completion_test');self.mail.stop();self.realtime.stop();frappe.set_user(self.user)

	def test_actions_follow_workflow_and_cannot_skip_review(self):
		self.assertEqual([x['action'] for x in cycle_status(self.cycle.name)['actions']],['Open Inputs'])
		with self.assertRaises(frappe.PermissionError):run_step(self.cycle.name,'Approve Payroll')
		run_step(self.cycle.name,'Open Inputs')
		with self.assertRaises(frappe.ValidationError):run_step(self.cycle.name,'Start Processing')
		self.assertEqual(frappe.db.get_value('Payroll Cycle',self.cycle.name,'status'),'Input Open')

	def test_approval_submits_cycle_after_required_review(self):
		run_step(self.cycle.name,'Open Inputs')
		frappe.db.set_value('Payroll Cycle',self.cycle.name,'readiness_status','Ready')
		run_step(self.cycle.name,'Start Processing');run_step(self.cycle.name,'Send for Review')
		frappe.db.set_value('Payroll Cycle',self.cycle.name,'processed_by','Guest')
		with self.assertRaises(frappe.ValidationError):run_step(self.cycle.name,'Approve Payroll')
		frappe.get_doc({'doctype':'Payroll Statutory Result','name':'completion-result-'+uuid4().hex,'payroll_cycle':self.cycle.name,'status':'Reviewed','result_type':'PAYE'}).db_insert()
		result=run_step(self.cycle.name,'Approve Payroll')
		self.assertIn('Submitted',result['message'])
		doc=frappe.get_doc('Payroll Cycle',self.cycle.name)
		self.assertEqual((doc.status,doc.docstatus),('Approved',1))
		with self.assertRaises(frappe.ValidationError):run_step(self.cycle.name,'Submit Salary Slips')

	def test_close_is_blocked_until_payroll_outputs_are_complete(self):
		# A direct Workflow/API action must enforce the same prerequisite that the
		# Payroll Management stepper displays; UI disabling alone is not a control.
		frappe.db.set_value(
			"Payroll Cycle", self.cycle.name, {"status": "Approved", "docstatus": 1}
		)
		with self.assertRaisesRegex(frappe.ValidationError, "Payroll Entry processing"):
			run_step(self.cycle.name, "Close Payroll")
		self.assertEqual(frappe.db.get_value("Payroll Cycle", self.cycle.name, "status"), "Approved")

	def test_guest_cannot_process_or_read_dependencies(self):
		frappe.set_user('Guest')
		for fn,args in [(run_step,(self.cycle.name,'Open Inputs')),(cycle_status,(self.cycle.name,)),(employee_status,('MBC/HR/00001',))]:
			with self.assertRaises(frappe.PermissionError):fn(*args)

	def test_prb_exception_blocks_submit_and_valid_point_submits(self):
		doc=frappe.copy_doc(frappe.get_doc('PRB Payroll Run','PRBR-2026-00004'));doc.docstatus=0;doc.payroll_cycle=self.cycle.name
		doc.salary_point='INVALID-TEST-'+uuid4().hex
		frappe.db.set_value('Employee',doc.employee,'karyo_prb_salary_point',doc.salary_point)
		doc.insert()
		self.assertEqual(doc.exception_code,'NO_RULE')
		with self.assertRaises(frappe.ValidationError):doc.submit()
		doc.reload();point=frappe.db.get_value('PRB Salary Point',{'review_year':doc.review_year},'salary_point');set_salary_point(doc.name,point);doc.reload();doc.submit()
		self.assertEqual((doc.docstatus,doc.snapshot_status),(1,'Approved'))

	def test_period_binds_cycle_and_rejects_mismatch(self):
		from karyo.payroll.completion import run_period_options
		doc=frappe.copy_doc(frappe.get_doc('PRB Payroll Run','PRBR-2026-00004'));doc.docstatus=0
		doc.payroll_cycle=self.cycle.name;doc.payroll_period=None;doc._set_context()
		self.assertEqual(doc.payroll_period,self.cycle.payroll_period)
		self.assertEqual(doc.period,self.cycle.pay_period_label)
		options=run_period_options(doc.employee,doc.payroll_period)
		self.assertIn(self.cycle.name,[row.name for row in options['cycles']])
		period=frappe.copy_doc(frappe.get_doc('Payroll Period',doc.payroll_period));period.name='completion-period-'+uuid4().hex;period.docstatus=0;period.db_insert()
		doc.payroll_period=period.name
		with self.assertRaises(frappe.ValidationError):doc._set_context()
		doc.payroll_period=self.cycle.payroll_period
		frappe.db.set_value('Payroll Cycle',self.cycle.name,'docstatus',2)
		with self.assertRaises(frappe.ValidationError):doc._set_context()
		self.assertNotIn(self.cycle.name,[row.name for row in run_period_options(doc.employee,doc.payroll_period)['cycles']])

	def test_period_auto_selects_only_unique_matching_cycle(self):
		doc=frappe.copy_doc(frappe.get_doc('PRB Payroll Run','PRBR-2026-00004'));doc.docstatus=0
		period=frappe.copy_doc(frappe.get_doc('Payroll Period',self.cycle.payroll_period));period.name='completion-period-'+uuid4().hex;period.docstatus=0;period.db_insert()
		frappe.db.set_value('Payroll Cycle',self.cycle.name,'payroll_period',period.name)
		doc.payroll_cycle=None;doc.payroll_period=period.name;doc._set_context()
		self.assertEqual(doc.payroll_cycle,self.cycle.name)
		other=frappe.copy_doc(self.cycle);other.name='completion-cycle-'+uuid4().hex;other.payroll_period=period.name;other.docstatus=0;other.db_insert()
		doc.payroll_cycle=None;doc._set_context();self.assertFalse(doc.payroll_cycle)
		frappe.db.set_value('Payroll Period',period.name,'company','completion-other-company')
		with self.assertRaises(frappe.ValidationError):doc._set_context()
