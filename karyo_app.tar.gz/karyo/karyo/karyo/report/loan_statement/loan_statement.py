import frappe
from frappe import _
from frappe.utils import flt


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if not filters.loan:
		frappe.throw(_("Loan is required."))
	frappe.has_permission("Karyo Loan", "read", filters.loan, throw=True)
	conditions = ["e.loan=%(loan)s"]
	if filters.from_date:
		conditions.append("e.transaction_date >= %(from_date)s")
	if filters.to_date:
		conditions.append("e.transaction_date <= %(to_date)s")
	if filters.include_reversals in (0, "0", False):
		conditions.append("coalesce(e.is_reversal,0)=0")
	rows = frappe.db.sql(f"""select e.name ledger_entry, e.transaction_date, e.date_processed,
		e.ref_type, e.period, e.payroll_cycle, e.debit, e.credit, e.balance_after,
		e.reference, e.source_doctype, e.source_name, e.pdb_code, e.department, e.branch,
		e.allocation_references, e.is_reversal, e.reversal_of, e.remarks
		from `tabKaryo Loan Ledger Entry` e where {' and '.join(conditions)}
		order by e.transaction_date, e.creation, e.name""", filters, as_dict=True)
	running = 0
	data = []
	for row in rows:
		row.component = _component(row.ref_type)
		if filters.component and row.component != filters.component:
			continue
		running += flt(row.debit) - flt(row.credit)
		row.net_movement = flt(row.debit) - flt(row.credit)
		row.running_total = running
		data.append(row)
	return _columns(), data


def _component(ref_type):
	value = (ref_type or "").lower()
	if "capital" in value or value in ("disbursement", "settlement", "settlement reversal", "advance payment", "advance payment reversal", "refund", "refund reversal", "recast"):
		return "Capital"
	if "interest" in value:
		return "Interest"
	if "insurance" in value:
		return "Insurance"
	return "Other"


def _columns():
	def c(fieldname, label, fieldtype="Data", width=115, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("transaction_date", "Transaction Date", "Date", 105), c("ledger_entry", "Ledger Entry", "Link", 145, "Karyo Loan Ledger Entry"),
		c("component", "Component", width=85), c("ref_type", "Movement", width=145), c("debit", "Debit", "Currency"),
		c("credit", "Credit", "Currency"), c("net_movement", "Net Movement", "Currency", 125), c("running_total", "Running Total", "Currency", 125),
		c("balance_after", "Component Balance", "Currency", 130), c("period", "Period", width=90),
		c("payroll_cycle", "Payroll Cycle", "Link", 130, "Payroll Cycle"), c("pdb_code", "PDB", width=90),
		c("source_doctype", "Source Type", "Link", 120, "DocType"), c("source_name", "Source", "Dynamic Link", 150, "source_doctype"),
		c("reference", "Reference", width=140), c("is_reversal", "Reversal", "Check", 70),
		c("reversal_of", "Reversal Of", "Link", 140, "Karyo Loan Ledger Entry"), c("department", "Department", "Link", 120, "Department"),
		c("branch", "Location", "Link", 110, "Branch"), c("allocation_references", "Schedule Allocations", width=180), c("remarks", "Remarks", width=220)]
