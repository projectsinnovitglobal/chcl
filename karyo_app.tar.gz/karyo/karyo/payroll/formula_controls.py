"""Admin-facing controls for Salary Structure conditions and formulas.

Salary Structure rows are the values the payroll engine actually evaluates.
This module deliberately edits those rows (including submitted structures) by
using the same versioned ``db_update_all`` pattern as HRMS' Salary Component
sync.  Existing Salary Slips remain immutable; new calculations read the
updated structure immediately after its cache is cleared.
"""

from __future__ import annotations

import copy
import json

import frappe
from frappe import _
from frappe.utils import cint, flt, now
from hrms.payroll.utils import sanitize_expression


EDIT_ROLES = {"System Manager"}
ROW_FIELDS = ("name", "condition", "formula", "amount_based_on_formula")


def _can_edit() -> bool:
	return frappe.session.user == "Administrator" or bool(EDIT_ROLES.intersection(frappe.get_roles()))


def _require_access() -> None:
	if not _can_edit():
		frappe.throw(
			_("Only a System Manager can change payroll formulas and conditions."),
			frappe.PermissionError,
		)


def _parse_rows(rows) -> list[dict]:
	if isinstance(rows, str):
		rows = json.loads(rows or "[]")
	if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
		frappe.throw(_("Formula rows must be supplied as a list."))
	return rows


def _structures():
	return frappe.get_all(
		"Salary Structure",
		filters={"docstatus": ("!=", 2)},
		fields=["name", "company", "currency", "docstatus", "is_active", "payroll_frequency", "modified"],
		order_by="is_active desc, docstatus desc, name asc",
	)


def _row_data(row, kind: str) -> dict:
	return {
		"name": row.name,
		"kind": kind,
		"salary_component": row.salary_component,
		"abbr": row.abbr,
		"amount": flt(row.amount),
		"amount_based_on_formula": cint(row.amount_based_on_formula),
		"condition": row.condition or "",
		"formula": row.formula or "",
		"variable_based_on_taxable_salary": cint(row.variable_based_on_taxable_salary),
		"statistical_component": cint(row.statistical_component),
		"do_not_include_in_total": cint(row.do_not_include_in_total),
	}


def _structure_data(summary) -> dict:
	doc = frappe.get_doc("Salary Structure", summary.name)
	rows = []
	for kind in ("earnings", "deductions"):
		rows.extend(_row_data(row, kind) for row in doc.get(kind))
	return {
		"name": doc.name,
		"company": doc.company,
		"currency": doc.currency,
		"docstatus": doc.docstatus,
		"is_active": doc.is_active,
		"payroll_frequency": doc.payroll_frequency,
		"modified": str(doc.modified),
		"rows": rows,
	}


@frappe.whitelist()
def get_controls(base=50000):
	"""Return every live/draft structure row and a base-value preview."""
	_require_access()
	structures = [_structure_data(row) for row in _structures()]
	for structure in structures:
		preview = _preview(structure["name"], base, structure["rows"])
		for row in structure["rows"]:
			row.update(preview["rows"].get(row["name"], {}))
		structure["totals"] = preview["totals"]
	return {
		"can_edit": True,
		"base": flt(base),
		"structures": structures,
		"help": {
			"condition": _("The condition is checked first. Leave it blank to always apply the row."),
			"formula": _("Use base and earlier component abbreviations, for example base * 0.10."),
		},
	}


def _apply_proposed_rows(structure, proposed_rows: list[dict]):
	actual = {row.name: row for kind in ("earnings", "deductions") for row in structure.get(kind)}
	seen = set()
	for proposed in proposed_rows:
		name = proposed.get("name")
		if not name or name not in actual or name in seen:
			frappe.throw(_("A formula row no longer belongs to Salary Structure {0}. Refresh and try again.").format(structure.name))
		seen.add(name)
		row = actual[name]
		condition = sanitize_expression(proposed.get("condition")) or ""
		formula = sanitize_expression(proposed.get("formula")) or ""
		if row.variable_based_on_taxable_salary and formula:
			frappe.throw(
				_("{0} is calculated from taxable salary during payroll and cannot use a structure formula.").format(
					row.salary_component
				)
			)
		row.condition = condition
		row.formula = formula
		row.amount_based_on_formula = 1 if formula else 0
	return actual


def _preview(structure_name: str, base, rows) -> dict:
	structure = frappe.get_doc("Salary Structure", structure_name)
	proposed = _parse_rows(rows)
	_apply_proposed_rows(structure, proposed)

	# Use HRMS' own safe condition/formula evaluator and its complete variable
	# map.  This keeps the preview identical to the next payroll calculation.
	slip = frappe.new_doc("Salary Slip")
	slip.update({
		"salary_structure": structure.name,
		"company": structure.company,
		"currency": structure.currency,
		"base": flt(base),
		"variable": 0,
	})
	values = frappe._dict()
	# Employee/assignment fields are available to real payroll formulas. The
	# simple Admin preview has no employee selector, so seed every known field
	# with a neutral value and then apply the test base entered by the user.
	for doctype in ("Employee", "Salary Structure Assignment"):
		for field in frappe.get_meta(doctype).fields:
			if field.fieldtype in ("Int", "Float", "Currency", "Percent", "Check"):
				values.setdefault(field.fieldname, 0)
			else:
				values.setdefault(field.fieldname, None)
	values.update(slip.as_dict())
	values.update(slip.get_component_abbr_map())
	values.update({"base": flt(base), "variable": 0})
	result = {}
	totals = {"earnings": 0.0, "deductions": 0.0, "net": 0.0}
	for kind in ("earnings", "deductions"):
		for row in structure.get(kind):
			if row.variable_based_on_taxable_salary and not row.amount_based_on_formula:
				result[row.name] = {"preview_amount": None, "preview_status": _("Calculated in payroll")}
				continue
			try:
				amount = slip.eval_condition_and_formula(row, values)
			except Exception as error:
				# HRMS raises a ValidationError containing the row/component context.
				result[row.name] = {
					"preview_amount": None,
					"preview_status": _("Invalid"),
					"preview_error": frappe.utils.strip_html(str(error)),
				}
				continue
			if amount is None:
				result[row.name] = {"preview_amount": 0.0, "preview_status": _("Condition not met")}
				values[row.abbr] = 0.0
				continue
			amount = flt(amount)
			values[row.abbr] = amount
			result[row.name] = {"preview_amount": amount, "preview_status": _("Applied")}
			if not row.statistical_component and not row.do_not_include_in_total:
				totals[kind] += amount
	totals["net"] = totals["earnings"] - totals["deductions"]
	return {"base": flt(base), "currency": structure.currency, "rows": result, "totals": totals}


@frappe.whitelist()
def preview(structure, base=50000, rows=None):
	"""Preview unsaved box values without changing any payroll records."""
	_require_access()
	return _preview(structure, base, rows or [])


@frappe.whitelist()
def save(structure, base=50000, rows=None, modified=None):
	"""Validate, version and apply changed formula/condition boxes."""
	_require_access()
	doc = frappe.get_doc("Salary Structure", structure)
	if modified and str(doc.modified) != str(modified):
		frappe.throw(_("Salary Structure {0} changed after this page was opened. Refresh before saving.").format(doc.name))

	proposed = _parse_rows(rows)
	if not proposed:
		return {"message": _("No formula changes to save."), "structure": _structure_data(doc)}

	before = copy.deepcopy(doc)
	actual = _apply_proposed_rows(doc, proposed)
	preview_result = _preview(doc.name, base, proposed)
	invalid = [item.get("preview_error") for item in preview_result["rows"].values() if item.get("preview_error")]
	if invalid:
		frappe.throw(invalid[0])

	changed = []
	before_rows = {row.name: row for kind in ("earnings", "deductions") for row in before.get(kind)}
	for name, row in actual.items():
		old = before_rows[name]
		if any(row.get(field) != old.get(field) for field in ROW_FIELDS[1:]):
			changed.append(row.salary_component)
	if not changed:
		return {"message": _("No formula changes to save."), "structure": _structure_data(doc), "preview": preview_result}

	# Submitted structures are intentionally updated in place, matching the
	# native Salary Component sync. Save a Version so every rule change retains
	# actor, timestamp, before and after values.
	doc._doc_before_save = before
	timestamp = now()
	doc.modified = timestamp
	doc.modified_by = frappe.session.user
	for child in doc.get_all_children():
		child.modified = timestamp
		child.modified_by = frappe.session.user
	doc.db_update_all()
	doc.flags.updater_reference = {
		"doctype": "Salary Structure",
		"docname": doc.name,
		"label": _("via Formula & Condition Controls"),
	}
	doc.save_version()
	doc.clear_cache()

	updated = _structure_data(frappe.get_doc("Salary Structure", doc.name))
	return {
		"message": _("Updated {0} formula row(s) in {1}.").format(len(changed), doc.name),
		"changed": changed,
		"structure": updated,
		"preview": _preview(doc.name, base, updated["rows"]),
	}
