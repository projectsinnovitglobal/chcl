"""Payroll bank validation and masked-readiness helpers."""

import frappe
from frappe import _
from frappe.utils import flt, getdate

from karyo.payroll.configuration import assert_production_eligible


def mask_account(value, visible=4):
	value = str(value or "").strip()
	if not value:
		return ""
	if len(value) <= visible:
		return "*" * len(value)
	return "*" * (len(value) - visible) + value[-visible:]


def validate_bank(doc, method=None):
	if not doc.karyo_payroll_active:
		return
	doc.karyo_bank_code = (doc.karyo_bank_code or "").strip().upper()
	if not doc.karyo_bank_code:
		frappe.throw(_("Payroll Bank Code is required for a bank active for payroll."))
	if doc.karyo_bank_effective_to and (
		getdate(doc.karyo_bank_effective_to) < getdate(doc.karyo_bank_effective_from)
	):
		frappe.throw(_("Bank Effective To cannot be before Effective From."))
	if not doc.karyo_bank_configuration:
		frappe.throw(_("Configuration Version is required for a bank active for payroll."))
	configuration = frappe.get_doc("Payroll Configuration Version", doc.karyo_bank_configuration)
	if configuration.configuration_type != "Bank Export":
		frappe.throw(_("Bank Configuration Version must be a Bank Export configuration."))
	mode = frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo"
	if mode == "Production":
		assert_production_eligible(configuration)


def validate_employee_bank_links(doc, method=None):
	if doc.salary_mode != "Bank":
		return
	branch_fields = {
		"karyo_branch_code": "branch_code",
		"karyo_branch_name": "branch_name",
		"karyo_branch_transfer_code": "transfer_code",
		"karyo_branch_other_code": "other_code",
		"karyo_branch_active": "is_active",
	}
	bank_fields = {
		"karyo_bank_code": "karyo_bank_code",
		"karyo_bank_swift_code": "swift_number",
		"karyo_bank_transfer_code": "karyo_bank_transfer_code",
		"karyo_bank_other_code": "karyo_bank_other_code",
	}
	if doc.karyo_payroll_bank_branch:
		branch = frappe.db.get_value(
			"Payroll Bank Branch", doc.karyo_payroll_bank_branch,
			["bank", "branch_code", "branch_name", "transfer_code", "other_code", "is_active"], as_dict=True,
		)
		if not branch or not branch.is_active:
			frappe.throw(_("Select an active Payroll Bank Branch."))
		if doc.karyo_payroll_bank and branch.bank != doc.karyo_payroll_bank:
			frappe.throw(_("Payroll Bank Branch belongs to a different bank."))
		doc.karyo_payroll_bank = doc.karyo_payroll_bank or branch.bank
		for target, source in branch_fields.items():
			if doc.meta.has_field(target):
				doc.set(target, branch.get(source))
	else:
		for target in branch_fields:
			if doc.meta.has_field(target):
				doc.set(target, None)
	if doc.karyo_payroll_bank:
		bank = frappe.db.get_value(
			"Bank", doc.karyo_payroll_bank,
			[
				"karyo_bank_code", "swift_number", "karyo_bank_transfer_code",
				"karyo_bank_other_code", "karyo_payroll_active",
			],
			as_dict=True,
		)
		if not bank or not bank.karyo_payroll_active:
			frappe.throw(_("Select a bank that is active for Payroll."))
		doc.bank_name = doc.karyo_payroll_bank
		for target, source in bank_fields.items():
			if doc.meta.has_field(target):
				doc.set(target, bank.get(source))
	else:
		doc.bank_name = None
		for target in bank_fields:
			if doc.meta.has_field(target):
				doc.set(target, None)


def get_employee_bank_readiness(employee, on_date=None):
	"""Return payroll readiness without exposing the full account number."""
	on_date = getdate(on_date)
	emp = frappe.db.get_value(
		"Employee",
		employee,
		[
			"salary_mode",
			"bank_name",
			"bank_ac_no",
			"karyo_payroll_bank",
			"karyo_payroll_bank_branch",
			"karyo_bank_account_effective_from",
			"karyo_bank_account_effective_to",
			"karyo_secondary_payroll_bank",
			"karyo_secondary_payroll_bank_branch",
			"karyo_secondary_bank_account_no",
			"karyo_secondary_bank_fixed_amount",
			"karyo_secondary_bank_effective_from",
			"karyo_secondary_bank_effective_to",
		],
		as_dict=True,
	)
	if not emp:
		return {"ready": False, "errors": [_("Employee does not exist.")], "masked_account": ""}
	if emp.salary_mode != "Bank":
		return {"ready": True, "errors": [], "masked_account": "", "payment_mode": emp.salary_mode}

	errors = []
	mode = frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo"
	if not emp.bank_ac_no:
		errors.append(_("Bank account number is missing."))
	if emp.karyo_bank_account_effective_from and getdate(emp.karyo_bank_account_effective_from) > on_date:
		errors.append(_("Employee bank account is not yet effective."))
	elif emp.karyo_bank_account_effective_to and getdate(emp.karyo_bank_account_effective_to) < on_date:
		errors.append(_("Employee bank account is no longer effective."))
	bank_name = emp.karyo_payroll_bank or emp.bank_name
	if not bank_name:
		errors.append(_("Payroll bank is missing."))
	else:
		bank = frappe.db.get_value(
			"Bank",
			bank_name,
			[
				"karyo_bank_code",
				"karyo_payroll_active",
				"karyo_bank_effective_from",
				"karyo_bank_effective_to",
				"karyo_bank_configuration",
			],
			as_dict=True,
		)
		if not bank or not bank.karyo_payroll_active or not bank.karyo_bank_code:
			errors.append(_("Payroll bank is not configured or active."))
		elif bank.karyo_bank_effective_from and getdate(bank.karyo_bank_effective_from) > on_date:
			errors.append(_("Payroll bank is not yet effective."))
		elif bank.karyo_bank_effective_to and getdate(bank.karyo_bank_effective_to) < on_date:
			errors.append(_("Payroll bank is no longer effective."))
		elif mode == "Production":
			try:
				assert_production_eligible(bank.karyo_bank_configuration)
			except frappe.ValidationError:
				errors.append(_("Payroll bank configuration is not approved for production."))

	if not emp.karyo_payroll_bank_branch:
		errors.append(_("Payroll bank branch is missing."))
	else:
		branch = frappe.db.get_value(
			"Payroll Bank Branch",
			emp.karyo_payroll_bank_branch,
			["bank", "is_active", "effective_from", "effective_to", "configuration_version"],
			as_dict=True,
		)
		if not branch or not branch.is_active or branch.bank != bank_name:
			errors.append(_("Payroll bank branch is invalid or inactive."))
		elif branch.effective_from and getdate(branch.effective_from) > on_date:
			errors.append(_("Payroll bank branch is not yet effective."))
		elif branch.effective_to and getdate(branch.effective_to) < on_date:
			errors.append(_("Payroll bank branch is no longer effective."))
		elif mode == "Production":
			try:
				assert_production_eligible(branch.configuration_version)
			except frappe.ValidationError:
				errors.append(_("Payroll bank branch configuration is not approved for production."))

	secondary_active = (
		flt(emp.karyo_secondary_bank_fixed_amount) > 0
		and (not emp.karyo_secondary_bank_effective_from or getdate(emp.karyo_secondary_bank_effective_from) <= on_date)
		and (not emp.karyo_secondary_bank_effective_to or getdate(emp.karyo_secondary_bank_effective_to) >= on_date)
	)
	if secondary_active:
		if not emp.karyo_secondary_bank_account_no:
			errors.append(_("Secondary bank account number is missing."))
		secondary_bank = frappe.db.get_value(
			"Bank", emp.karyo_secondary_payroll_bank,
			["karyo_payroll_active", "karyo_bank_effective_from", "karyo_bank_effective_to", "karyo_bank_configuration"],
			as_dict=True,
		) if emp.karyo_secondary_payroll_bank else None
		if not secondary_bank or not secondary_bank.karyo_payroll_active:
			errors.append(_("Secondary payroll bank is missing or inactive."))
		elif secondary_bank.karyo_bank_effective_from and getdate(secondary_bank.karyo_bank_effective_from) > on_date:
			errors.append(_("Secondary payroll bank is not yet effective."))
		elif secondary_bank.karyo_bank_effective_to and getdate(secondary_bank.karyo_bank_effective_to) < on_date:
			errors.append(_("Secondary payroll bank is no longer effective."))
		elif mode == "Production":
			try:
				assert_production_eligible(secondary_bank.karyo_bank_configuration)
			except frappe.ValidationError:
				errors.append(_("Secondary payroll bank configuration is not approved for production."))

		secondary_branch = frappe.db.get_value(
			"Payroll Bank Branch", emp.karyo_secondary_payroll_bank_branch,
			["bank", "is_active", "effective_from", "effective_to", "configuration_version"],
			as_dict=True,
		) if emp.karyo_secondary_payroll_bank_branch else None
		if not secondary_branch or not secondary_branch.is_active or secondary_branch.bank != emp.karyo_secondary_payroll_bank:
			errors.append(_("Secondary payroll bank branch is missing, invalid or inactive."))
		elif secondary_branch.effective_from and getdate(secondary_branch.effective_from) > on_date:
			errors.append(_("Secondary payroll bank branch is not yet effective."))
		elif secondary_branch.effective_to and getdate(secondary_branch.effective_to) < on_date:
			errors.append(_("Secondary payroll bank branch is no longer effective."))
		elif mode == "Production":
			try:
				assert_production_eligible(secondary_branch.configuration_version)
			except frappe.ValidationError:
				errors.append(_("Secondary payroll bank branch configuration is not approved for production."))

	return {
		"ready": not errors,
		"errors": errors,
		"masked_account": mask_account(emp.bank_ac_no),
		"payment_mode": "Bank",
		"bank": bank_name,
		"branch": emp.karyo_payroll_bank_branch,
	}
