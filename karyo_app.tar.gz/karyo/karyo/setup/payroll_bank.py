"""Extend standard Bank/Employee and maintain the governed payroll branch catalogue."""

import json
from pathlib import Path

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.utils import now_datetime

from karyo.setup.foundation import f, make_doctype


DEMO_BANKS = [
	("Mauritius Commercial Bank", "MCB-DEMO", "MCB", "001"),
	("State Bank of Mauritius", "SBM-DEMO", "SBM", "001"),
	("Barclays Mauritius", "BARCLAYS-DEMO", "BARCLAYS", "001"),
]

BANK_BRANCH_REFERENCE = Path(__file__).resolve().parents[1] / "payroll" / "data" / "mauritius_bank_branches.json"


def create_doctype():
	make_doctype(
		"Payroll Bank Branch",
		autoname="format:{bank}-{branch_code}",
		title_field="branch_name",
		fields=[
			f("identity_sb", "Section Break", "Branch Identity"),
			f("bank", "Link", "Bank", options="Bank", reqd=1, in_list_view=1),
			f("branch_code", "Data", "Branch Code", reqd=1, in_list_view=1),
			f("branch_name", "Data", "Branch Name", reqd=1, in_list_view=1),
			f("identity_cb", "Column Break"),
			f("transfer_code", "Data", "Transfer Code"),
			f("other_code", "Data", "Other Code"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("contact_sb", "Section Break", "Contact and Address"),
			f("address_line_1", "Data", "Address Line 1"),
			f("address_line_2", "Data", "Address Line 2"),
			f("postal_code", "Data", "Postal Code"),
			f("contact_cb", "Column Break"),
			f("telephone", "Data", "Telephone"),
			f("fax", "Data", "Fax"),
			f("governance_sb", "Section Break", "Validity and Governance"),
			f("effective_from", "Date", "Effective From", reqd=1, default="2026-01-01"),
			f("effective_to", "Date", "Effective To"),
			f(
				"configuration_version",
				"Link",
				"Configuration Version",
				options="Payroll Configuration Version",
				reqd=1,
			),
			f("source_reference", "Data", "Source Reference"),
		],
	)


def add_custom_fields():
	create_custom_fields(
		{
			"Bank": [
				{
					"fieldname": "karyo_payroll_bank_sb",
					"fieldtype": "Section Break",
					"label": "Payroll Routing",
					"insert_after": "website",
					"collapsible": 1,
				},
				{
					"fieldname": "karyo_bank_code",
					"fieldtype": "Data",
					"label": "Payroll Bank Code",
					"insert_after": "karyo_payroll_bank_sb",
					"unique": 1,
					"in_list_view": 1,
				},
				{
					"fieldname": "karyo_bank_transfer_code",
					"fieldtype": "Data",
					"label": "Transfer Code",
					"insert_after": "karyo_bank_code",
				},
				{
					"fieldname": "karyo_bank_other_code",
					"fieldtype": "Data",
					"label": "Other Code",
					"insert_after": "karyo_bank_transfer_code",
				},
				{
					"fieldname": "karyo_bank_cb",
					"fieldtype": "Column Break",
					"insert_after": "karyo_bank_other_code",
				},
				{
					"fieldname": "karyo_payroll_active",
					"fieldtype": "Check",
					"label": "Active for Payroll",
					"default": "0",
					"insert_after": "karyo_bank_cb",
				},
				{
					"fieldname": "karyo_bank_effective_from",
					"fieldtype": "Date",
					"label": "Effective From",
					"insert_after": "karyo_payroll_active",
				},
				{
					"fieldname": "karyo_bank_effective_to",
					"fieldtype": "Date",
					"label": "Effective To",
					"insert_after": "karyo_bank_effective_from",
				},
				{
					"fieldname": "karyo_bank_configuration",
					"fieldtype": "Link",
					"label": "Configuration Version",
					"options": "Payroll Configuration Version",
					"insert_after": "karyo_bank_effective_to",
				},
			],
			"Employee": [
				{
					"fieldname": "karyo_payroll_bank",
					"fieldtype": "Link",
					"label": "Payroll Bank",
					"options": "Bank",
					"insert_after": "bank_name",
					"depends_on": "eval:doc.salary_mode == 'Bank'",
				},
				{
					"fieldname": "karyo_payroll_bank_branch",
					"fieldtype": "Link",
					"label": "Payroll Bank Branch",
					"options": "Payroll Bank Branch",
					"insert_after": "karyo_payroll_bank",
					"depends_on": "eval:doc.salary_mode == 'Bank'",
				},
			],
		},
		ignore_validate=True,
	)


def _configuration():
	return frappe.db.get_value(
		"Payroll Configuration Version",
		{"config_key": "DEMO-BANK-FORMATS-2026", "version": "DEMO-1"},
		"name",
	)


def seed_demo_data():
	configuration = _configuration()
	if not configuration:
		return
	for bank_name, bank_code, transfer_code, branch_code in DEMO_BANKS:
		# The bank code is unique, so match on it first: the bank master may have
		# been renamed since it was seeded.
		existing = frappe.db.get_value("Bank", {"karyo_bank_code": bank_code}, "name")
		if existing:
			bank_name = existing
		elif not frappe.db.exists("Bank", bank_name):
			frappe.get_doc(
				{
					"doctype": "Bank",
					"bank_name": bank_name,
					"karyo_bank_code": bank_code,
					"karyo_bank_transfer_code": transfer_code,
					"karyo_payroll_active": 1,
					"karyo_bank_effective_from": "2026-01-01",
					"karyo_bank_configuration": configuration,
				}
			).insert(ignore_permissions=True)
		if not frappe.db.exists("Payroll Bank Branch", {"bank": bank_name, "branch_code": branch_code}):
			frappe.get_doc(
				{
					"doctype": "Payroll Bank Branch",
					"bank": bank_name,
					"branch_code": branch_code,
					"branch_name": "Head Office",
					"transfer_code": transfer_code,
					"is_active": 1,
					"effective_from": "2026-01-01",
					"configuration_version": configuration,
					"source_reference": "DEMO bank catalogue — not for payment submission",
				}
			).insert(ignore_permissions=True)


def _authoritative_configuration(data):
	config_key, version = "MBC-BANK-BRANCH", "SHEET-2026-09-19"
	name = frappe.db.get_value(
		"Payroll Configuration Version", {"config_key": config_key, "version": version}, "name"
	)
	payload = json.dumps({
		"spreadsheet_id": data["source"]["spreadsheet_id"],
		"sheet": data["source"]["sheet"],
		"bank_count": len(data["banks"]),
		"branch_count": len(data["branches"]),
		"duplicate_resolution": data["duplicate_resolution"],
		"conflicts": data["conflicts"],
	}, indent=2)
	values = {
		"configuration_type": "Bank Export",
		"company": frappe.db.get_value("Company", {"abbr": "MBC"}, "name"),
		"configuration_status": "Active",
		"is_production_eligible": 1,
		"effective_from": "2026-01-01",
		"source_reference": data["source"]["url"],
		"approval_reference": "User-provided Bank-Branch catalogue",
		"approved_by": frappe.session.user,
		"approved_on": now_datetime(),
		"configuration_json": payload,
		"notes": "Imported into Bank and Payroll Bank Branch masters. Duplicate bank/branch codes use the later detailed row from the supplied sheet.",
	}
	if name:
		frappe.db.set_value("Payroll Configuration Version", name, values, update_modified=False)
		return name
	return frappe.get_doc({
		"doctype": "Payroll Configuration Version",
		"config_key": config_key,
		"version": version,
		**values,
	}).insert(ignore_permissions=True).name


def seed_authoritative_data():
	"""Upsert the user-supplied Mauritius bank/branch list into the payroll masters."""
	data = json.loads(BANK_BRANCH_REFERENCE.read_text())
	configuration = _authoritative_configuration(data)
	banks_by_code = {}
	for row in data["banks"]:
		bank_name = frappe.db.get_value("Bank", {"karyo_bank_code": row["bank_code"]}, "name")
		bank_name = bank_name or frappe.db.get_value("Bank", {"bank_name": row["bank_name"]}, "name")
		values = {
			"bank_name": row["bank_name"],
			"swift_number": row.get("swift_code") or None,
			"karyo_bank_code": row["bank_code"],
			"karyo_bank_transfer_code": row.get("transfer_code") or None,
			"karyo_payroll_active": int(row.get("active", True)),
			"karyo_bank_effective_from": "2026-01-01",
			"karyo_bank_configuration": configuration,
		}
		if bank_name:
			frappe.db.set_value("Bank", bank_name, values, update_modified=False)
		else:
			bank_name = frappe.get_doc({"doctype": "Bank", **values}).insert(ignore_permissions=True).name
		banks_by_code[row["bank_code"]] = bank_name

	for row in data["branches"]:
		bank_name = banks_by_code.get(row["bank_code"])
		if not bank_name:
			continue
		values = {
			"bank": bank_name,
			"branch_code": row["branch_code"],
			"branch_name": row["branch_name"],
			"transfer_code": row.get("transfer_code") or None,
			"is_active": int(row.get("active", True)),
			"effective_from": "2026-01-01",
			"configuration_version": configuration,
			"source_reference": "Bank-Branch Sheet1",
		}
		branch = frappe.db.get_value(
			"Payroll Bank Branch", {"bank": bank_name, "branch_code": row["branch_code"]}, "name"
		)
		if branch:
			frappe.db.set_value("Payroll Bank Branch", branch, values, update_modified=False)
		else:
			frappe.get_doc({"doctype": "Payroll Bank Branch", **values}).insert(ignore_permissions=True)
	return {"banks": len(data["banks"]), "branches": len(data["branches"]), "configuration": configuration}


def apply():
	frappe.reload_doc("karyo", "doctype", "payroll_bank_branch")
	add_custom_fields()
	seed_authoritative_data()
	frappe.clear_cache(doctype="Bank")
	frappe.clear_cache(doctype="Payroll Bank Branch")


def setup():
	print("Karyo Payroll bank and branch setup:")
	create_doctype()
	add_custom_fields()
	result = seed_authoritative_data()
	from karyo.install import samples_enabled

	if samples_enabled():
		seed_demo_data()
	frappe.db.commit()
	print(f"Done ({result['banks']} banks and {result['branches']} branches mapped to payroll masters).")
