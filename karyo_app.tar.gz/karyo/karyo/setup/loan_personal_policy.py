"""Personal Loan Annex policy register, controls, and transaction fields.

Run with::

    bench --site <site> execute karyo.setup.loan_personal_policy.setup

The policy register mirrors the supplied spreadsheet and preserves each row's
validation status.  A Loan Type must be explicitly opted into the controls.
"""

from unittest.mock import patch

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


POLICY_ROWS = (
	("PL-POL-001", "Permanent staff – five years", "At least 5 years; maximum Rs 60,000 for 60 months.", "To Validate"),
	("PL-POL-002", "Permanent staff – two years", "At least 2 years; maximum Rs 20,000 for 24 months.", "To Validate"),
	("PL-POL-003", "Contractual staff", "Maximum 2 months basic, capped at Rs 40,000 for 12 months; outstanding balance offsets gratuity at contract end.", "To Validate"),
	("PL-POL-004", "Interest", "Personal loan ceiling Rs 60,000 at 8%; ceiling changes require Board approval.", "To Validate"),
	("PL-POL-005", "Recast eligibility", "Recast is permitted after half of capital has been paid.", "To Validate"),
	("PL-POL-006", "Recast administration fee", "Recast administration fee is Rs 500.", "To Validate"),
	("PL-POL-007", "Payroll recovery", "Recover capital, interest and insurance through separate monthly payroll deductions.", "Validated"),
	("PL-POL-008", "Guarantees", "A borrower contract requires two establishment guarantors; guarantors are liable on default.", "To Validate"),
	("PL-POL-009", "Death insurance", "Personal loans use SICOM death insurance.", "To Validate"),
	("PL-POL-010", "Contract registration", "All loan contracts are registered.", "To Validate"),
	("PL-POL-011", "Approval flow", "Application and SICOM form → HR eligibility → MFO capacity/recommendation → DG approval → FOO computation → SFO verification → contract/system input → disbursement.", "To Validate"),
	("PL-POL-012", "New-loan worked example", "Rs 60,000 at 8% for 60 months: capital Rs 1,000; total interest Rs 12,200; monthly interest Rs 203.33; refund Rs 1,203.33.", "Reference only"),
	("PL-POL-013", "Fees worked example", "Registration source fee Rs 150, shown rounded to Rs 200; insurance 1.60% = Rs 960; net amount Rs 58,840.", "Open"),
	("PL-POL-014", "Recast worked example", "Rs 60,000 less balance Rs 39,836.74, admin Rs 500, registration Rs 200 and insurance Rs 960 = Rs 18,503.26.", "Reference only"),
)


def create_policy_register():
	make_doctype(
		"Loan Policy Rule",
		autoname="field:policy_reference",
		naming_rule="By fieldname",
		title_field="loan_area",
		fields=[
			f("policy_reference", "Data", "Policy Reference", reqd=1, unique=1, in_list_view=1),
			f("loan_area", "Data", "Loan / Area", reqd=1, in_list_view=1),
			f("rule_text", "Small Text", "Eligibility / Rule", reqd=1),
			f("validation_status", "Select", "Validation Status", options="To Validate\nValidated\nOpen\nReference only", reqd=1, in_list_view=1),
			f("source", "Data", "Source", default="MBC Personal Loan Annex", read_only=1),
			f("stakeholder_remarks", "Small Text", "Stakeholder Remarks"),
		],
	)


def add_policy_fields():
	create_custom_fields(
		{
			"Loan Type": [
				{"fieldname": "annex_policy_sb", "fieldtype": "Section Break", "label": "Personal Loan Annex Policy", "insert_after": "recast_cap_pct"},
				{"fieldname": "annex_policy_enabled", "fieldtype": "Check", "label": "Apply Personal Loan Annex", "default": "0", "insert_after": "annex_policy_sb"},
				{"fieldname": "required_guarantors", "fieldtype": "Int", "label": "Required Guarantors", "default": "2", "depends_on": "annex_policy_enabled", "insert_after": "annex_policy_enabled"},
				{"fieldname": "default_insurance_provider", "fieldtype": "Data", "label": "Default Insurance Provider", "default": "SICOM", "depends_on": "annex_policy_enabled", "insert_after": "required_guarantors"},
				{"fieldname": "contract_registration_required", "fieldtype": "Check", "label": "Contract Registration Required", "default": "1", "depends_on": "annex_policy_enabled", "insert_after": "default_insurance_provider"},
				{"fieldname": "annex_policy_cb", "fieldtype": "Column Break", "insert_after": "contract_registration_required"},
				{"fieldname": "loan_registration_fee", "fieldtype": "Currency", "label": "Registration Fee", "default": "200", "depends_on": "annex_policy_enabled", "insert_after": "annex_policy_cb"},
				{"fieldname": "source_registration_fee", "fieldtype": "Currency", "label": "Source Registration Fee", "default": "150", "read_only": 1, "depends_on": "annex_policy_enabled", "insert_after": "loan_registration_fee"},
				{"fieldname": "upfront_insurance_pct", "fieldtype": "Percent", "label": "Upfront Insurance %", "default": "1.6", "depends_on": "annex_policy_enabled", "insert_after": "source_registration_fee"},
				{"fieldname": "registration_fee_validation_status", "fieldtype": "Data", "label": "Fee Validation Status", "default": "Open – confirm rounding and insurance basis", "read_only": 1, "depends_on": "annex_policy_enabled", "insert_after": "upfront_insurance_pct"},
				{"fieldname": "annex_eligibility_sb", "fieldtype": "Section Break", "label": "Annex Eligibility Bands", "depends_on": "annex_policy_enabled", "insert_after": "registration_fee_validation_status"},
				{"fieldname": "permanent_five_year_min_service", "fieldtype": "Int", "label": "Permanent Band 1 Min Service (Years)", "default": "5", "insert_after": "annex_eligibility_sb"},
				{"fieldname": "permanent_five_year_max_amount", "fieldtype": "Currency", "label": "Permanent Band 1 Maximum", "default": "60000", "insert_after": "permanent_five_year_min_service"},
				{"fieldname": "permanent_five_year_max_period", "fieldtype": "Int", "label": "Permanent Band 1 Period (Months)", "default": "60", "insert_after": "permanent_five_year_max_amount"},
				{"fieldname": "annex_eligibility_cb", "fieldtype": "Column Break", "insert_after": "permanent_five_year_max_period"},
				{"fieldname": "permanent_two_year_min_service", "fieldtype": "Int", "label": "Permanent Band 2 Min Service (Years)", "default": "2", "insert_after": "annex_eligibility_cb"},
				{"fieldname": "permanent_two_year_max_amount", "fieldtype": "Currency", "label": "Permanent Band 2 Maximum", "default": "20000", "insert_after": "permanent_two_year_min_service"},
				{"fieldname": "permanent_two_year_max_period", "fieldtype": "Int", "label": "Permanent Band 2 Period (Months)", "default": "24", "insert_after": "permanent_two_year_max_amount"},
				{"fieldname": "annex_contract_sb", "fieldtype": "Section Break", "label": "Contractual Staff Band", "depends_on": "annex_policy_enabled", "insert_after": "permanent_two_year_max_period"},
				{"fieldname": "contractual_salary_multiple", "fieldtype": "Float", "label": "Basic Salary Multiple", "default": "2", "insert_after": "annex_contract_sb"},
				{"fieldname": "contractual_max_amount", "fieldtype": "Currency", "label": "Contractual Maximum", "default": "40000", "insert_after": "contractual_salary_multiple"},
				{"fieldname": "contractual_max_period", "fieldtype": "Int", "label": "Contractual Period (Months)", "default": "12", "insert_after": "contractual_max_amount"},
				{"fieldname": "annex_recast_cb", "fieldtype": "Column Break", "insert_after": "contractual_max_period"},
				{"fieldname": "recast_min_capital_paid_pct", "fieldtype": "Percent", "label": "Recast Minimum Capital Paid %", "default": "50", "insert_after": "annex_recast_cb"},
				{"fieldname": "recast_administration_fee", "fieldtype": "Currency", "label": "Recast Administration Fee", "default": "500", "insert_after": "recast_min_capital_paid_pct"},
			],
			"Karyo Loan": [
				{"fieldname": "annex_policy_result_sb", "fieldtype": "Section Break", "label": "Personal Loan Policy Result", "insert_after": "net_loan_amount", "depends_on": "eval:doc.policy_reference"},
				{"fieldname": "policy_reference", "fieldtype": "Data", "label": "Eligibility Policy", "read_only": 1, "insert_after": "annex_policy_result_sb"},
				{"fieldname": "policy_employment_category", "fieldtype": "Data", "label": "Employment Category", "read_only": 1, "insert_after": "policy_reference"},
				{"fieldname": "policy_service_years", "fieldtype": "Int", "label": "Completed Service (Years)", "read_only": 1, "insert_after": "policy_employment_category"},
				{"fieldname": "policy_result_cb", "fieldtype": "Column Break", "insert_after": "policy_service_years"},
				{"fieldname": "policy_max_amount", "fieldtype": "Currency", "label": "Policy Maximum Amount", "read_only": 1, "insert_after": "policy_result_cb"},
				{"fieldname": "policy_max_period_months", "fieldtype": "Int", "label": "Policy Maximum Period", "read_only": 1, "insert_after": "policy_max_amount"},
				{"fieldname": "outstanding_offset_source", "fieldtype": "Data", "label": "Outstanding Balance Offset", "read_only": 1, "insert_after": "policy_max_period_months"},
				{"fieldname": "upfront_insurance_fee", "fieldtype": "Currency", "label": "Upfront Insurance Fee", "read_only": 1, "insert_after": "outstanding_offset_source"},
				{"fieldname": "annex_flow_sb", "fieldtype": "Section Break", "label": "Personal Loan Annex Flow", "insert_after": "guarantors", "depends_on": "eval:doc.policy_reference"},
				{"fieldname": "sicom_form_attachment", "fieldtype": "Attach", "label": "SICOM Form", "insert_after": "annex_flow_sb"},
				{"fieldname": "hr_eligibility_confirmed", "fieldtype": "Check", "label": "HR Eligibility Confirmed", "read_only": 1, "insert_after": "sicom_form_attachment"},
				{"fieldname": "mfo_capacity_confirmed", "fieldtype": "Check", "label": "MFO Capacity Confirmed", "insert_after": "hr_eligibility_confirmed"},
				{"fieldname": "mfo_recommended", "fieldtype": "Check", "label": "MFO Recommended", "read_only": 1, "insert_after": "mfo_capacity_confirmed"},
				{"fieldname": "dg_approved", "fieldtype": "Check", "label": "DG Approved", "read_only": 1, "insert_after": "mfo_recommended"},
				{"fieldname": "annex_flow_cb", "fieldtype": "Column Break", "insert_after": "dg_approved"},
				{"fieldname": "foo_computation_confirmed", "fieldtype": "Check", "label": "FOO Computation Confirmed", "insert_after": "annex_flow_cb"},
				{"fieldname": "sfo_verified", "fieldtype": "Check", "label": "SFO Verified", "insert_after": "foo_computation_confirmed"},
				{"fieldname": "contract_registered", "fieldtype": "Check", "label": "Contract Registered", "insert_after": "sfo_verified"},
				{"fieldname": "contract_registration_reference", "fieldtype": "Data", "label": "Registration Reference", "depends_on": "contract_registered", "insert_after": "contract_registered"},
				{"fieldname": "contract_registration_date", "fieldtype": "Date", "label": "Registration Date", "depends_on": "contract_registered", "insert_after": "contract_registration_reference"},
				{"fieldname": "system_input_completed", "fieldtype": "Check", "label": "System Input Completed", "insert_after": "contract_registration_date"},
			],
			"Karyo Loan Guarantor": [
				{"fieldname": "liable_on_default", "fieldtype": "Check", "label": "Liable on Default", "default": "1", "read_only": 1, "in_list_view": 1, "insert_after": "guarantor_status"},
			],
			"Karyo Loan Recast": [
				{"fieldname": "recast_mode", "fieldtype": "Select", "label": "Recast Mode", "options": "Reschedule\nRefinance / New Loan", "default": "Reschedule", "insert_after": "effective_date"},
				{"fieldname": "new_principal", "fieldtype": "Currency", "label": "New Loan Amount", "depends_on": "eval:doc.recast_mode=='Refinance / New Loan'", "insert_after": "recast_mode"},
				{"fieldname": "capital_paid_pct", "fieldtype": "Percent", "label": "Capital Paid %", "read_only": 1, "insert_after": "outstanding_before"},
				{"fieldname": "administration_fee", "fieldtype": "Currency", "label": "Administration Fee", "read_only": 1, "insert_after": "capital_paid_pct"},
				{"fieldname": "recast_registration_fee", "fieldtype": "Currency", "label": "Registration Fee", "read_only": 1, "insert_after": "administration_fee"},
				{"fieldname": "recast_insurance_fee", "fieldtype": "Currency", "label": "Upfront Insurance Fee", "read_only": 1, "insert_after": "recast_registration_fee"},
				{"fieldname": "net_amount_payable", "fieldtype": "Currency", "label": "Net Amount Payable", "read_only": 1, "insert_after": "recast_insurance_fee"},
			],
		},
		ignore_validate=True,
	)


def seed_policy_register():
	for reference, area, rule, status in POLICY_ROWS:
		values = {
			"loan_area": area,
			"rule_text": rule,
			"validation_status": status,
			"source": "MBC Personal Loan Annex",
		}
		if frappe.db.exists("Loan Policy Rule", reference):
			frappe.db.set_value("Loan Policy Rule", reference, values, update_modified=False)
		else:
			frappe.get_doc({"doctype": "Loan Policy Rule", "policy_reference": reference, **values}).insert(ignore_permissions=True)


def configure_personal_loan(loan_type="PERS"):
	"""Apply the supplied annex defaults to one explicitly selected Loan Type."""
	if not frappe.db.exists("Loan Type", loan_type):
		frappe.throw(f"Loan Type {loan_type} does not exist")
	values = {
		"annex_policy_enabled": 1,
		"requires_md_approval": 1,
		"interest_rate": 8,
		"max_amount": 60000,
		"max_period_months": 60,
		"insurance_required": 1,
		"pdb_capital": "Karyo Loan Capital",
		"pdb_interest": "Karyo Loan Interest",
		"pdb_insurance": "Karyo Loan Insurance",
		"required_guarantors": 2,
		"default_insurance_provider": "SICOM",
		"contract_registration_required": 1,
		"loan_registration_fee": 200,
		"source_registration_fee": 150,
		"upfront_insurance_pct": 1.6,
		"registration_fee_validation_status": "Open – confirm rounding and insurance basis",
		"permanent_five_year_min_service": 5,
		"permanent_five_year_max_amount": 60000,
		"permanent_five_year_max_period": 60,
		"permanent_two_year_min_service": 2,
		"permanent_two_year_max_amount": 20000,
		"permanent_two_year_max_period": 24,
		"contractual_salary_multiple": 2,
		"contractual_max_amount": 40000,
		"contractual_max_period": 12,
		"recast_min_capital_paid_pct": 50,
		"recast_administration_fee": 500,
		"source_reference": "MBC Personal Loan Annex / PL-POL-001..014",
	}
	frappe.db.set_value("Loan Type", loan_type, values, update_modified=True)
	frappe.db.commit()
	return values


def run_acceptance_test(loan_type="PERS"):
	"""Exercise the deployed controller without inserting test transactions."""
	employee = frappe.db.get_value(
		"Employee",
		{
			"status": "Active",
			"employment_type": "Permanent",
			"date_of_joining": ["<=", "2021-09-20"],
		},
		["name", "company"],
		as_dict=True,
	)
	if not employee:
		frappe.throw("Acceptance test requires an active permanent employee with at least five years of service")
	base = {
		"doctype": "Karyo Loan",
		"employee": employee.name,
		"company": employee.company,
		"loan_type": loan_type,
		"amount_applied": 60000,
		"approved_amount": 60000,
		"period_months": 60,
		"eligible_salary": 40000,
		"date_applied": "2026-09-20",
		"disbursement_date": "2026-09-20",
		"repayment_start_date": "2026-10-01",
		"workflow_state": "Draft",
	}
	loan = frappe.get_doc(base)
	loan.run_method("validate")
	actual = {
		"policy_reference": loan.policy_reference,
		"interest_rate": loan.interest_rate,
		"policy_max_amount": loan.policy_max_amount,
		"policy_max_period_months": loan.policy_max_period_months,
		"registration_fee": loan.registration_fee,
		"upfront_insurance_fee": loan.upfront_insurance_fee,
		"net_loan_amount": loan.net_loan_amount,
		"total_interest": loan.total_interest,
		"monthly_capital": loan.monthly_capital,
		"monthly_interest": loan.monthly_interest,
		"monthly_refund": loan.monthly_refund,
		"insurance_provider": loan.insurance_provider,
		"schedule_rows": len(loan.schedule),
	}
	expected = {
		"policy_reference": "PL-POL-001",
		"interest_rate": 8,
		"policy_max_amount": 60000,
		"policy_max_period_months": 60,
		"registration_fee": 200,
		"upfront_insurance_fee": 960,
		"net_loan_amount": 58840,
		"total_interest": 12200,
		"monthly_capital": 1000,
		"monthly_interest": 203.33,
		"monthly_refund": 1203.33,
		"insurance_provider": "SICOM",
		"schedule_rows": 60,
	}
	if actual != expected:
		frappe.throw(f"Personal-loan acceptance test failed: expected {expected}, got {actual}")
	blocked = {}
	for check, changes in (
		("over_policy_maximum", {"amount_applied": 60001, "approved_amount": 60001}),
	):
		candidate = frappe.get_doc({**base, **changes})
		try:
			candidate.run_method("validate")
		except frappe.ValidationError as exc:
			blocked[check] = str(exc)
		else:
			frappe.throw(f"Personal-loan acceptance test failed: {check} was not blocked")
	guarantor_check = frappe.get_doc({**base, "workflow_state": "Approved"})
	try:
		guarantor_check._validate_guarantors()
	except frappe.ValidationError as exc:
		blocked["approval_without_guarantors"] = str(exc)
	else:
		frappe.throw("Personal-loan acceptance test failed: approval_without_guarantors was not blocked")
	direct_approval = frappe.get_doc({**base, "workflow_state": "Approved", "mfo_recommended": 1})
	with patch.object(
		direct_approval,
		"get_doc_before_save",
		return_value=frappe._dict(workflow_state="Recommended"),
	):
		try:
			direct_approval._validate_workflow_controls()
		except frappe.ValidationError as exc:
			blocked["approval_without_dg_path"] = str(exc)
		else:
			frappe.throw("Personal-loan acceptance test failed: approval_without_dg_path was not blocked")
	missing_sicom = frappe.get_doc({**base, "workflow_state": "Approval Pending"})
	with patch.object(
		missing_sicom,
		"get_doc_before_save",
		return_value=frappe._dict(workflow_state="Printed"),
	):
		try:
			missing_sicom._validate_workflow_controls()
		except frappe.ValidationError as exc:
			blocked["approval_without_sicom_form"] = str(exc)
		else:
			frappe.throw("Personal-loan acceptance test failed: approval_without_sicom_form was not blocked")
	return {"status": "passed", "employee": employee.name, "actual": actual, "blocked_controls": blocked}


def setup():
	print("Personal Loan Annex policy setup:")
	create_policy_register()
	add_policy_fields()
	seed_policy_register()
	frappe.db.commit()
	print("Done.")
