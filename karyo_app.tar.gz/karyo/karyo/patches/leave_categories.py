from karyo.setup.leave import seed_leave_categories


def execute():
	seed_leave_categories()
