"""Banded compensation calculation and eligibility checks."""

from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP, Decimal

import frappe
from frappe import _
from frappe.utils import getdate

from karyo.payroll.configuration import assert_production_eligible


def is_employee_eligible(scheme, employee):
	doc = scheme if hasattr(scheme, "doctype") else frappe.get_doc("Payroll Compensation Scheme", scheme)
	emp = frappe.db.get_value(
		"Employee",
		employee,
		["company", "employment_type", "department", "designation", "karyo_prb_grade"],
		as_dict=True,
	)
	if not emp:
		return False
	return all(
		(
			not configured or configured == actual
			for configured, actual in (
				(doc.company, emp.company),
				(doc.employment_type, emp.employment_type),
				(doc.department, emp.department),
				(doc.designation, emp.designation),
				(doc.prb_grade, emp.karyo_prb_grade),
			)
		)
	)


def calculate_compensation(scheme, salary_basis, on_date=None, employee=None, company=None):
	doc = frappe.get_doc("Payroll Compensation Scheme", scheme)
	on_date = getdate(on_date)
	basis = Decimal(str(salary_basis or 0))
	if basis < 0:
		frappe.throw(_("Compensation salary basis cannot be negative."))
	if not doc.is_active:
		frappe.throw(_("Compensation Scheme {0} is inactive.").format(scheme))
	if getdate(doc.effective_from) > on_date or (
		doc.effective_to and getdate(doc.effective_to) < on_date
	):
		frappe.throw(_("Compensation Scheme {0} is not effective on {1}.").format(scheme, on_date))
	if company and doc.company and company != doc.company:
		frappe.throw(_("Compensation Scheme belongs to a different company."))
	if employee and not is_employee_eligible(doc, employee):
		frappe.throw(_("Employee is not eligible for Compensation Scheme {0}.").format(scheme))
	mode = frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo"
	if mode == "Production":
		assert_production_eligible(doc.configuration_version)

	band = next(
		(
			row
			for row in sorted(doc.bands, key=lambda item: item.lower_salary)
			if basis >= Decimal(str(row.lower_salary))
			and (row.is_open_ended or basis <= Decimal(str(row.upper_salary)))
		),
		None,
	)
	if not band:
		frappe.throw(_("No compensation band covers salary basis {0}.").format(basis))
	percentage_amount = basis * Decimal(str(band.percentage or 0)) / Decimal("100")
	flat_amount = Decimal(str(band.flat_amount or 0))
	if doc.calculation_method == "Percentage":
		raw = percentage_amount
		selected_value = "Percentage"
	elif doc.calculation_method == "Flat Amount":
		raw = flat_amount
		selected_value = "Flat Amount"
	elif doc.calculation_method == "Percentage Plus Flat":
		raw = percentage_amount + flat_amount
		selected_value = "Percentage Plus Flat"
	elif doc.calculation_method == "Higher of Percentage or Flat":
		raw = max(percentage_amount, flat_amount)
		selected_value = "Percentage" if percentage_amount >= flat_amount else "Flat Amount"
	else:
		frappe.throw(_("Unsupported compensation calculation method {0}.").format(doc.calculation_method))
	rounding = ROUND_HALF_EVEN if doc.rounding_method == "Round Half to Even" else ROUND_HALF_UP
	amount = raw.quantize(Decimal("1").scaleb(-int(doc.rounding_precision)), rounding=rounding)
	return {
		"scheme": doc.name,
		"employee": employee,
		"salary_basis": float(basis),
		"calculation_method": doc.calculation_method,
		"selected_value": selected_value,
		"percentage_amount": float(percentage_amount),
		"flat_amount": float(flat_amount),
		"compensation_amount": float(amount),
		"pdb_code": doc.compensation_pdb_code,
		"band": {
			"lower_salary": band.lower_salary,
			"upper_salary": None if band.is_open_ended else band.upper_salary,
			"percentage": band.percentage,
			"flat_amount": band.flat_amount,
		},
	}
