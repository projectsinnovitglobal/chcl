"""Transactional login setup tests; callers must provide a connected test database."""
import unittest
from unittest.mock import patch
from uuid import uuid4

import frappe
from frappe.core.doctype.user.user import User
from frappe.utils.password import check_password

from karyo.desk import employee_account
from karyo.hr.clocking import dashboard


class TestEmployeeAccount(unittest.TestCase):
	def setUp(self):
		self.previous_user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("employee_login_test")
		self.email = "profile-test-" + uuid4().hex + "@example.test"
		self.password = "N7!" + uuid4().hex + "zQ@"

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="employee_login_test")
		frappe.clear_cache(user=self.email)
		frappe.set_user(self.previous_user)

	def employee(self):
		return frappe.get_doc({"doctype": "Employee", "first_name": "Profile Login Test",
			"gender": "Female", "date_of_birth": "1990-01-01", "date_of_joining": "2020-01-01",
			"status": "Active", "company": frappe.db.get_value("Company", {}, "name")})

	def setup_login(self, doc, **overrides):
		doc._mbc_account_setup = {"link_user": 1, "login_email": self.email,
			"password": self.password, "confirm_password": self.password, **overrides}
		return doc

	def test_new_employee_login_and_dashboard(self):
		doc = self.setup_login(self.employee()).insert()
		self.assertEqual(doc.user_id, self.email)
		self.assertNotIn("_mbc_account_setup", doc.__dict__)
		self.assertNotIn(self.password, frappe.as_json(doc.as_dict()))
		self.assertEqual(check_password(self.email, self.password), self.email)
		self.assertTrue(User.find_by_credentials(self.email, self.password).is_authenticated)
		self.assertEqual(frappe.db.get_value("User", self.email, "user_type"), "System User")
		self.assertTrue({"Employee", "Employee Self Service"}.issubset(frappe.get_roles(self.email)))
		frappe.set_user(self.email)
		self.assertEqual(dashboard()["self"]["employee"], doc.name)
		self.assertTrue(frappe.has_permission("Employee", "read", doc=doc))
		self.assertFalse(frappe.has_permission("User", "create"))

	def test_existing_employee_link_and_password_change(self):
		doc = self.employee().insert()
		self.setup_login(doc).save()
		self.password = "New!" + uuid4().hex + "X9"
		self.setup_login(doc, link_user=0).save()
		self.assertEqual(check_password(self.email, self.password), self.email)
		self.assertEqual(frappe.db.count("Employee", {"user_id": self.email}), 1)

	def test_saved_employee_profile_endpoint_creates_login(self):
		doc = self.employee().insert()
		result = employee_account.save_employee_account(
			doc.name, self.password, self.password, link_user=1, login_email=self.email
		)
		self.assertEqual(result, {"updated": True, "user": self.email})
		self.assertEqual(frappe.db.get_value("Employee", doc.name, "user_id"), self.email)
		self.assertEqual(check_password(self.email, self.password), self.email)

	def test_existing_unlinked_user_is_reused(self):
		frappe.get_doc({"doctype": "User", "email": self.email, "first_name": "Profile Test", "send_welcome_email": 0}).insert()
		doc = self.setup_login(self.employee()).insert()
		self.assertEqual(doc.user_id, self.email)
		self.assertEqual(check_password(self.email, self.password), self.email)

	def test_other_employee_cannot_claim_linked_account(self):
		self.setup_login(self.employee()).insert()
		with self.assertRaises(frappe.ValidationError):
			self.setup_login(self.employee()).insert()
		self.assertEqual(frappe.db.count("Employee", {"user_id": self.email}), 1)

	def test_password_mismatch_and_missing_link_do_not_create_user(self):
		for overrides in ({"confirm_password": "different"}, {"link_user": 0}):
			with self.assertRaises(frappe.ValidationError):
				self.setup_login(self.employee(), **overrides).insert()
			self.assertFalse(frappe.db.exists("User", self.email))

	def test_weak_password_is_rejected(self):
		with patch.dict(frappe.flags, {"in_test": False}), patch("frappe.core.doctype.user.user.test_password_strength", return_value={"feedback": {"password_policy_validation_passed": False, "suggestions": ["Choose a stronger password"]}}):
			with self.assertRaises(frappe.ValidationError):
				self.setup_login(self.employee(), password="123", confirm_password="123").insert()
		self.assertFalse(frappe.db.exists("User", self.email))

	def test_email_is_optional_and_targets_login_account(self):
		with patch.object(employee_account, "_email_ready", return_value=True), patch("frappe.sendmail") as mail:
			doc = self.setup_login(self.employee(), send_credentials=1).insert()
			self.assertEqual(mail.call_count, 1)
			kwargs = mail.call_args.kwargs
			self.assertEqual(kwargs["recipients"], [self.email])
			self.assertIn(self.password, kwargs["message"])
			self.assertIn("/app/sil-home", kwargs["message"])
			self.assertFalse(kwargs["now"])
			self.assertNotIn("mbc_login_email", doc.flags)
			mail.reset_mock()
			doc.save()
			mail.assert_not_called()

	def test_unconfigured_email_fails_before_account_creation(self):
		with patch.object(employee_account, "_email_ready", return_value=False):
			with self.assertRaises(frappe.ValidationError):
				self.setup_login(self.employee(), send_credentials=1).insert()
		self.assertFalse(frappe.db.exists("User", self.email))

	def test_inactive_employee_is_rejected(self):
		doc = self.employee()
		doc.status = "Inactive"
		with self.assertRaises(frappe.ValidationError):
			self.setup_login(doc).insert()
		self.assertFalse(frappe.db.exists("User", self.email))

	def test_no_permission_to_create_user(self):
		doc = self.setup_login(self.employee())
		with patch("frappe.has_permission", side_effect=frappe.PermissionError):
			with self.assertRaises(frappe.PermissionError):
				employee_account.prepare_employee_account(doc)
		self.assertFalse(frappe.db.exists("User", self.email))

	def test_employee_validation_failure_rolls_back_account(self):
		frappe.db.savepoint("invalid_employee")
		doc = self.setup_login(self.employee())
		doc.karyo_date_confirmed = "2019-01-01"
		with self.assertRaises(frappe.ValidationError):
			doc.insert()
		# Mirrors Frappe's failed-request transaction rollback.
		frappe.db.rollback(save_point="invalid_employee")
		self.assertFalse(frappe.db.exists("User", self.email))

	def test_employee_cannot_change_another_employees_password(self):
		self.setup_login(self.employee()).insert()
		other = self.employee().insert()
		frappe.set_user(self.email)
		with self.assertRaises(frappe.PermissionError):
			employee_account.set_password(other.name, self.password, self.password)

	def test_email_queue_failure_rolls_back_login_setup(self):
		frappe.db.savepoint("failed_login_email")
		with patch.object(employee_account, "_email_ready", return_value=True), patch("frappe.sendmail", side_effect=frappe.OutgoingEmailError):
			with self.assertRaises(frappe.OutgoingEmailError):
				self.setup_login(self.employee(), send_credentials=1).insert()
		frappe.db.rollback(save_point="failed_login_email")
		self.assertFalse(frappe.db.exists("User", self.email))
		self.assertFalse(frappe.db.exists("Employee", {"user_id": self.email}))
