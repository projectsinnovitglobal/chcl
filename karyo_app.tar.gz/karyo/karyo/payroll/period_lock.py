import frappe
from frappe import _


def reject_closed_cycle(payroll_cycle):
	"""Closed payroll inputs are immutable until the governed cycle is reopened."""
	status = frappe.db.get_value("Payroll Cycle", payroll_cycle, "status")
	if status == "Closed":
		frappe.throw(_("Payroll inputs cannot be changed after the Payroll Cycle is closed."))
