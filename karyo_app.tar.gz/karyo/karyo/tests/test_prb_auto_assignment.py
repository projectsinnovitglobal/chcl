"""PRB changes verified against real appointments, native payroll and rollback."""
import unittest
from unittest.mock import patch

import frappe
from karyo.tests import test_prb_two_phases as fixtures
from karyo.prb.revisions import apply_due_revisions, apply_revision
from karyo.payroll.salary_scales import approved_appointment, _assignment_at, validate_salary_slip_base
from karyo.setup.payroll_profiles import prb_salary_value


class TestPRBAutoAssignment(unittest.TestCase):
    make_scale = fixtures.TestPRBTwoPhases.make_scale
    appointment = fixtures.TestPRBTwoPhases.appointment
    prb_appointment = fixtures.TestPRBTwoPhases.prb_appointment

    def setUp(self):
        fixtures.TestPRBTwoPhases.setUp(self)
        get_all = frappe.get_all
        def scoped(doctype, *args, **kwargs):
            filters = kwargs.get('filters')
            if doctype == 'Employee' and isinstance(filters, dict) and filters.get('karyo_prb_opted_in') == 1:
                kwargs['filters'] = {**filters, 'name': self.employee.name}
            return get_all(doctype, *args, **kwargs)
        self.population = patch.object(frappe, 'get_all', side_effect=scoped)
        self.population.start()
        self.date = patch('karyo.prb.revisions.nowdate', return_value='2026-10-05')
        self.date.start()

    def tearDown(self):
        self.date.stop(); self.population.stop()
        fixtures.TestPRBTwoPhases.tearDown(self)

    def revision(self, **values):
        return frappe.get_doc({'doctype': 'PRB Salary Revision', 'title': 'TEST PRB conversion',
            'company': self.employee.company, 'effective_from': '2026-10-01',
            'source_review_year': 2026, 'review_year': 2026,
            'source_reference': 'Isolated TEST rule, not official production authority',
            'official_rules_confirmed': 1,
            'mappings': [{'from_grade': 'EDU-PRIMARY-EDUCATOR', 'from_point': '081',
                'to_grade': 'EDU-PRIMARY-EDUCATOR', 'to_point': '082',
                'rule_reference': 'TEST conversion 081 to 082'}], **values}).insert()

    def test_due_change_syncs_profile_history_native_payroll_and_is_idempotent(self):
        old = self.prb_appointment()
        before = prb_salary_value('081', 2026, '2026-09-30')
        revision = self.revision().submit(); revision.reload()
        self.assertEqual((revision.status, revision.applied_count, revision.blocked_count), ('Applied', 1, 0))
        new = approved_appointment(self.employee.name, '2026-10-01')
        expected = prb_salary_value('082', 2026, '2026-10-01')
        self.assertEqual((new.prb_grade, new.prb_salary_point, new.basic_salary), ('EDU-PRIMARY-EDUCATOR', '082', expected))
        self.assertEqual(str(frappe.db.get_value('Employee Salary Appointment', old.name, 'effective_to')), '2026-09-30')
        self.assertEqual(approved_appointment(self.employee.name, '2026-09-30').basic_salary, before)
        self.assertEqual(_assignment_at(self.employee.name, '2026-09-30').base, before)
        for date in ['2026-10-01', '2027-01-01']:
            self.assertEqual(_assignment_at(self.employee.name, date).base, prb_salary_value('082', 2026, date))
            self.assertEqual(frappe.db.get_value('Salary Structure Assignment', _assignment_at(self.employee.name, date).name,
                'karyo_salary_appointment'), new.name)
        profile = frappe.get_doc('Employee', self.employee.name)
        self.assertEqual((profile.karyo_prb_grade, profile.karyo_prb_salary_point, profile.ctc,
            profile.karyo_scale_basic_salary), ('EDU-PRIMARY-EDUCATOR', '082', expected, expected))
        run = frappe.get_doc({'doctype': 'PRB Payroll Run', 'employee': self.employee.name,
            'calculation_date': '2026-10-31', 'review_year': 2026})
        run._compute_basic()
        self.assertFalse(run.exception_code); self.assertEqual(run.basic_salary, expected)
        slip = frappe._dict(employee=self.employee.name, salary_structure=self.structure,
            start_date='2026-10-01', end_date='2026-10-31', posting_date='2026-10-31')
        validate_salary_slip_base(slip); self.assertEqual(slip.karyo_salary_base, expected)
        from hrms.payroll.doctype.salary_structure.salary_structure import make_salary_slip
        target = frappe.new_doc('Salary Slip'); target.start_date='2026-10-01'; target.end_date='2026-10-31'
        native_slip = make_salary_slip(self.structure, target_doc=target, employee=self.employee.name,
            posting_date='2026-10-31', for_preview=1)
        self.assertEqual(next(row.default_amount for row in native_slip.earnings if row.salary_component == 'Basic'), expected)
        counts = [frappe.db.count(dt, {'employee': self.employee.name}) for dt in
            ['Employee Salary Appointment', 'Salary Structure Assignment']]
        apply_revision(revision.name)
        self.assertEqual(counts, [frappe.db.count(dt, {'employee': self.employee.name}) for dt in
            ['Employee Salary Appointment', 'Salary Structure Assignment']])
        self.assertEqual(revision.results[0].appointment, new.name)
        with self.assertRaises(frappe.ValidationError): revision.cancel()

    def test_future_change_waits_then_scheduler_applies(self):
        old = self.prb_appointment()
        revision = self.revision(effective_from='2027-01-01').submit(); revision.reload()
        self.assertEqual(revision.status, 'Scheduled')
        self.assertEqual(apply_revision(revision.name)['applied'], 0)
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').name, old.name)
        with patch('karyo.prb.revisions.nowdate', return_value='2027-01-01'):
            apply_due_revisions()
        revision.reload(); self.assertEqual((revision.status, revision.applied_count), ('Applied', 1))
        self.assertEqual(approved_appointment(self.employee.name, '2027-01-01').basic_salary, prb_salary_value('082', 2026))

    def test_missing_mapping_is_visible_and_does_not_change_salary(self):
        old = self.prb_appointment(prb_salary_point='080')
        revision = self.revision().submit(); revision.reload()
        self.assertEqual((revision.status, revision.blocked_count), ('Partially Applied', 1))
        self.assertIn('No unique conversion rule', revision.results[0].detail)
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').name, old.name)

    def test_failed_payroll_sync_rolls_back_employee_and_old_period_then_retry_works(self):
        old = self.prb_appointment()
        with patch('karyo.payroll.salary_scales._assign_structure', side_effect=frappe.ValidationError('TEST payroll sync failure')):
            revision = self.revision().submit()
        revision.reload(); self.assertEqual(revision.blocked_count, 1)
        self.assertEqual(str(frappe.db.get_value('Employee Salary Appointment', old.name, 'effective_to')), '2027-12-31')
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'karyo_prb_salary_point'), '081')
        self.assertEqual(frappe.db.count('Employee Salary Appointment', {'employee': self.employee.name, 'docstatus': 1}), 1)
        self.assertEqual(apply_revision(revision.name)['applied'], 1)

    def test_duplicate_out_of_range_unverified_and_permission_checks(self):
        mapping = {'from_grade': 'EDU-PRIMARY-EDUCATOR', 'from_point': '081',
            'to_grade': 'EDU-PRIMARY-EDUCATOR', 'to_point': '082', 'rule_reference': 'TEST'}
        with self.assertRaises(frappe.ValidationError): self.revision(mappings=[mapping, mapping])
        with self.assertRaises(frappe.ValidationError): self.revision(mappings=[{**mapping, 'to_point': '999'}])
        revision = self.revision(official_rules_confirmed=0)
        with self.assertRaises(frappe.ValidationError): revision.submit()
        with patch('frappe.get_roles', return_value=['Employee']), self.assertRaises(frappe.PermissionError):
            apply_revision(revision.name)

    def test_posted_payroll_blocks_revision_without_history_change(self):
        old = self.prb_appointment()
        original = frappe.db.exists
        def exists(doctype, *args, **kwargs):
            return 'POSTED-TEST' if doctype == 'Salary Slip' else original(doctype, *args, **kwargs)
        with patch.object(frappe.db, 'exists', side_effect=exists):
            revision = self.revision().submit()
        revision.reload(); self.assertEqual(revision.blocked_count, 1)
        self.assertIn('Submitted Salary Slips', revision.results[0].detail)
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').name, old.name)

    def test_review_year_pinned_and_new_year_mapping(self):
        old = self.prb_appointment()
        frappe.get_doc({'doctype': 'PRB Salary Point', 'salary_point': '082', 'review_year': 2028,
            'gross_2025': 60000, 'revised_2026': 65000}).insert()
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').basic_salary, prb_salary_value('081', 2026, '2026-10-01'))
        revision = self.revision(review_year=2028, effective_from='2028-01-01').submit()
        # Extend the source fixture so the future revision has continuous history.
        old.effective_to=None; old.save()
        with patch('karyo.prb.revisions.nowdate', return_value='2028-01-01'):
            result = apply_revision(revision.name)
        self.assertEqual(result['blocked'], 0)
        self.assertEqual(approved_appointment(self.employee.name, '2028-01-01').prb_year, 2028)
        self.assertEqual(_assignment_at(self.employee.name, '2028-01-01').base, 65000)

    def test_legacy_prb_profile_is_converted_to_governed_appointment(self):
        from karyo.payroll.salary_scales import _assign_structure
        frappe.db.set_value('Employee', self.employee.name, {'karyo_prb_opted_in': 1,
            'karyo_prb_grade': 'EDU-PRIMARY-EDUCATOR', 'karyo_prb_salary_point': '081'})
        _assign_structure(self.employee.name, self.structure, '2026-01-01',
            prb_salary_value('081', 2026, '2026-01-01'), self.income_tax_slab)
        revision = self.revision().submit(); revision.reload()
        self.assertEqual(revision.applied_count, 1)
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').prb_salary_point, '082')

    def test_grade_scale_conversion_updates_employee_and_keeps_previous_grade_history(self):
        old = self.prb_appointment()
        target_grade = frappe.copy_doc(frappe.get_doc('PRB Grade Scale', 'EDU-PRIMARY-EDUCATOR'))
        target_grade.grade_id = 'PRB-REVISION-TEST-' + self.uid
        target_grade.insert()
        revision = self.revision(mappings=[{'from_grade': 'EDU-PRIMARY-EDUCATOR', 'from_point': '081',
            'to_grade': target_grade.name, 'to_point': '082', 'rule_reference': 'TEST grade and point change'}]).submit()
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'karyo_prb_grade'), target_grade.name)
        self.assertEqual(approved_appointment(self.employee.name, '2026-09-30').prb_grade, 'EDU-PRIMARY-EDUCATOR')
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').prb_grade, target_grade.name)
        revision.reload(); revision.source_reference = 'tampered'
        with self.assertRaises(frappe.ValidationError): revision.save()

    def test_existing_draft_salary_slip_recalculates_to_revised_base(self):
        from hrms.payroll.doctype.salary_structure.salary_structure import make_salary_slip
        self.prb_appointment()
        # This fixture has no Attendance; use leave-based payment days for the draft.
        frappe.db.set_single_value('Payroll Settings', 'payroll_based_on', 'Leave')
        target = frappe.new_doc('Salary Slip'); target.start_date='2026-10-01'; target.end_date='2026-10-31'
        slip = make_salary_slip(self.structure, target_doc=target, employee=self.employee.name,
            posting_date='2026-10-31', for_preview=1)
        slip.insert()
        revision=self.revision().submit(); revision.reload()
        self.assertEqual(revision.status, 'Applied')
        slip.reload()
        expected = prb_salary_value('082', 2026, '2026-10-01')
        self.assertEqual(slip.karyo_salary_base, expected)
        self.assertEqual(next(row.default_amount for row in slip.earnings if row.salary_component == 'Basic'), expected)
