"""Post approved PRB snapshots into payroll and reconcile Salary Slip earnings."""

import json

import frappe
from frappe import _
from frappe.utils import flt


def _mapping(component_code):
	mapping = frappe.db.get_value(
		"PRB Payroll Component Mapping",
		{"component_code": component_code, "is_active": 1},
		["pdb_code", "posting_mode"],
		as_dict=True,
	)
	if not mapping:
		frappe.throw(_("PRB component {0} has no active payroll mapping.").format(component_code))
	pdb = frappe.db.get_value(
		"Payroll PDB Code",
		mapping.pdb_code,
		["salary_component", "is_active"],
		as_dict=True,
	)
	if not pdb or not pdb.is_active:
		frappe.throw(_("PRB component {0} maps to an inactive PDB Code.").format(component_code))
	if frappe.db.get_value("Salary Component", pdb.salary_component, "disabled"):
		frappe.throw(_("PRB component {0} maps to a disabled Salary Component.").format(component_code))
	return mapping, pdb


def validate_mappings(run):
	mapped = {}
	for row in run.components:
		mapped[row.component_code] = _mapping(row.component_code)
	return mapped


@frappe.whitelist()
def post_run(name):
	run = frappe.get_doc("PRB Payroll Run", name)
	if run.docstatus != 1 or run.snapshot_status != "Approved":
		frappe.throw(_("Only an approved PRB Payroll Run can be posted."))
	if run.run_purpose in ("Attendance Bonus", "Incentive Attendance Bonus", "PRB Attendance Bonuses"):
		from karyo.payroll.attendance_bonus import automatic_bonus_eligibility

		cycle = frappe.get_doc("Payroll Cycle", run.payroll_cycle)
		if not automatic_bonus_eligibility(run.employee, cycle).eligible:
			frappe.throw(_(
				"PRB Attendance Bonus cannot be posted because the employee has no submitted working Attendance in this payroll month."
			))
	if run.exception_code:
		frappe.throw(_("Blocking PRB exception {0} must be resolved first.").format(run.exception_code))
	if run.posting_status == "Posted":
		return {"run": run.name, "posted": [r.additional_salary for r in run.components], "already_posted": True}
	mappings = validate_mappings(run)
	payment_date = run.calculation_date
	if run.payroll_cycle:
		payment_date = frappe.db.get_value("Payroll Cycle", run.payroll_cycle, "payment_date")
	if not payment_date:
		frappe.throw(_("A payroll payment date is required."))

	posted = []
	for row in run.components:
		mapping, pdb = mappings[row.component_code]
		amount = flt(row.delta_amount) if run.run_type == "Delta" else flt(row.amount)
		if not amount:
			continue
		additional_salary = frappe.get_doc(
			{
				"doctype": "Additional Salary",
				"employee": run.employee,
				"company": run.company,
				"salary_component": pdb.salary_component,
				"amount": amount,
				"payroll_date": payment_date,
				"overwrite_salary_structure_amount": mapping.posting_mode == "Overwrite",
				"ref_doctype": run.doctype,
				"ref_docname": run.name,
				"karyo_transaction_category": "PRB Payroll",
				"karyo_payroll_cycle": run.payroll_cycle,
			}
		).insert(ignore_permissions=True)
		additional_salary.submit()
		row.db_set(
			{
				"pdb_code": mapping.pdb_code,
				"salary_component": pdb.salary_component,
				"additional_salary": additional_salary.name,
			},
			update_modified=False,
		)
		posted.append(additional_salary.name)
	run.db_set(
		{
			"posting_status": "Posted",
			"posted_total": sum(
				flt(frappe.db.get_value("Additional Salary", item, "amount")) for item in posted
			),
			"reconciliation_status": "Pending",
		},
		update_modified=False,
	)
	return {"run": run.name, "posted": posted, "already_posted": False}


def reverse_run_postings(doc, method=None):
	for row in doc.components:
		if row.additional_salary and frappe.db.get_value("Additional Salary", row.additional_salary, "docstatus") == 1:
			additional_salary = frappe.get_doc("Additional Salary", row.additional_salary)
			additional_salary.flags.ignore_links = True
			additional_salary.cancel()
	if doc.posting_status == "Posted":
		doc.db_set("posting_status", "Reversed", update_modified=False)


def validate_payroll_entry(doc, method=None):
	employees = [row.employee for row in doc.employees if row.employee]
	if not employees:
		return
	filters = {
		"employee": ("in", employees),
		"exception_code": ("is", "set"),
		"docstatus": ("<", 2),
	}
	if doc.get("karyo_payroll_cycle"):
		filters["payroll_cycle"] = doc.karyo_payroll_cycle
	blocked = frappe.get_all(
		"PRB Payroll Run",
		filters=filters,
		fields=["name", "employee", "exception_code", "calculation_date"],
		limit=50,
	)
	blocked = blocked[:10]
	if blocked:
		detail = ", ".join(f"{row.employee}: {row.exception_code} ({row.name})" for row in blocked)
		frappe.throw(_("Payroll Entry is blocked by PRB exceptions: {0}").format(detail))


@frappe.whitelist()
def reconcile_salary_slip(run_name, salary_slip):
	run = frappe.get_doc("PRB Payroll Run", run_name)
	slip = frappe.get_doc("Salary Slip", salary_slip)
	if slip.employee != run.employee:
		frappe.throw(_("Salary Slip employee does not match the PRB run."))
	expected = {}
	for row in run.components:
		if row.salary_component:
			expected[row.salary_component] = expected.get(row.salary_component, 0) + (
				flt(row.delta_amount) if run.run_type == "Delta" else flt(row.amount)
			)
	actual = {}
	for row in slip.earnings:
		if row.salary_component in expected:
			actual[row.salary_component] = actual.get(row.salary_component, 0) + flt(row.amount)
	expected_total = sum(expected.values())
	actual_total = sum(actual.values())
	status = "Matched" if abs(expected_total - actual_total) < 0.005 else "Mismatch"
	run.db_set("reconciliation_status", status, update_modified=False)
	return {
		"status": status,
		"expected_total": expected_total,
		"actual_total": actual_total,
		"difference": actual_total - expected_total,
		"components": json.dumps({"expected": expected, "actual": actual}, sort_keys=True),
	}
