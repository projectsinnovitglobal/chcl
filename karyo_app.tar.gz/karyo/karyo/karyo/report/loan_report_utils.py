import frappe
from frappe import _


REFERENCE_ROLES = {"System Manager", "Karyo Finance", "Loan Officer", "Payroll Finance"}


def permitted_loan_names():
	"""Return loans visible through Frappe's normal DocType/user-permission engine."""
	frappe.has_permission("Karyo Loan", "read", throw=True)
	return tuple(row.name for row in frappe.get_list(
		"Karyo Loan", fields=["name"], limit_page_length=0
	))


def add_loan_permission_condition(conditions, params, expression="l.name"):
	loans = permitted_loan_names()
	if not loans:
		return False
	conditions.append(f"{expression} in %(permitted_loan_names)s")
	params["permitted_loan_names"] = loans
	return True


def can_view_payment_references():
	return bool(set(frappe.get_roles()) & REFERENCE_ROLES)


def mask_reference(value):
	"""Keep exports useful without exposing full bank/cheque references to auditors."""
	if not value or can_view_payment_references():
		return value
	value = str(value)
	return _("Masked ({0})").format(value[-4:].rjust(len(value), "•"))
