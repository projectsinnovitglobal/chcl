# Copyright (c) 2026, AstraFlow and contributors
# For license information, please see license.txt

"""PB Request Register (§9.2 #3) — track employee claims and statuses.

Minimum fields (BRD §9.2): sequence number, employee, usage item, request amount,
claimable amount, status, approver, pay period.
"""

import frappe


def execute(filters=None):
	filters = frappe._dict(filters or {})
	return _columns(), _data(filters)


def _columns():
	return [
		{
			"label": "Request",
			"fieldname": "request",
			"fieldtype": "Link",
			"options": "Passage Benefit Application",
			"width": 160,
		},
		{"label": "Posting Date", "fieldname": "posting_date", "fieldtype": "Date", "width": 100},
		{
			"label": "Employee",
			"fieldname": "employee",
			"fieldtype": "Link",
			"options": "Employee",
			"width": 110,
		},
		{"label": "Employee Name", "fieldname": "employee_name", "fieldtype": "Data", "width": 160},
		{"label": "Usage Item", "fieldname": "usage_item", "fieldtype": "Data", "width": 130},
		{"label": "Encash Rate", "fieldname": "encash_rate", "fieldtype": "Percent", "width": 105},
		{"label": "Request Amount", "fieldname": "request_amount", "fieldtype": "Currency", "width": 130},
		{"label": "Claimable Amount", "fieldname": "claimable_amount", "fieldtype": "Currency", "width": 130},
		{"label": "Status", "fieldname": "workflow_state", "fieldtype": "Data", "width": 130},
		{"label": "Passage Method", "fieldname": "processing_route", "fieldtype": "Data", "width": 110},
		{"label": "Approver", "fieldname": "approver", "fieldtype": "Link", "options": "User", "width": 150},
		{"label": "Pay Period", "fieldname": "pay_period", "fieldtype": "Data", "width": 90},
	]


def _data(filters):
	conditions = {"docstatus": ["<", 2]}
	if filters.get("employee"):
		conditions["employee"] = filters.employee
	if filters.get("workflow_state"):
		conditions["workflow_state"] = filters.workflow_state
	if filters.get("pay_period"):
		conditions["pay_period"] = filters.pay_period
	if filters.get("from_date") and filters.get("to_date"):
		conditions["posting_date"] = ["between", [filters.from_date, filters.to_date]]
	elif filters.get("from_date"):
		conditions["posting_date"] = [">=", filters.from_date]
	elif filters.get("to_date"):
		conditions["posting_date"] = ["<=", filters.to_date]

	rows = frappe.get_all(
		"Passage Benefit Application",
		filters=conditions,
		fields=[
			"name as request",
			"posting_date",
			"employee",
			"employee_name",
			"usage_item_name as usage_item",
			"encash_rate",
			"request_amount",
			"claimable_amount",
			"workflow_state",
			"processing_route",
			"pay_period",
			"modified_by as approver",
		],
		order_by="posting_date desc, name desc",
	)
	# The approver is only meaningful once the request has left Draft/Pending.
	for r in rows:
		if r["workflow_state"] in (None, "Draft", "Pending Approval"):
			r["approver"] = None
	return rows
