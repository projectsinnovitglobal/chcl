"""Apply the client PB-Setup workbook rules to Passage Benefit configuration."""

import json
from pathlib import Path

import frappe


DATA_FILE = Path(__file__).resolve().parent.parent / "payroll" / "data" / "pb_setup_rules.json"
GSPB_DATA_FILE = Path(__file__).resolve().parent.parent / "payroll" / "data" / "pb_gspb_salary_basis.json"
PB_CONFIG_KEY = "MBC-PB-RULES-2026"
OP_CONFIG_KEY = "MBC-PB-OPERATIONS-2026"
PB_CONFIG_VERSION = "SHEET-1"
OP_CONFIG_VERSION = "SHEET-2"
EFFECTIVE_FROM = "2026-01-01"
ENTITLEMENT_OPERATION = "GSPB"


def _load_source():
	with DATA_FILE.open(encoding="utf-8") as handle:
		return json.load(handle)


def _load_gspb_source():
	with GSPB_DATA_FILE.open(encoding="utf-8") as handle:
		return json.load(handle)


def _ensure_configuration(payload, *, key, version, configuration_type, purpose):
	name = f"{key}-{version}"
	if frappe.db.exists("Payroll Configuration Version", name):
		# Keep the stable configuration identity and governance state, but refresh
		# its source trace when the client republishes the same rules in a new file.
		frappe.db.set_value(
			"Payroll Configuration Version",
			name,
			{
				"source_reference": payload["source_url"],
				"configuration_json": json.dumps({
					"workbook": payload["workbook_title"],
					"sheet": payload["sheet"],
					"range": payload["range"],
					"excluded_rows": payload["excluded_rows"],
					"purpose": purpose,
				}, sort_keys=True),
			},
			update_modified=False,
		)
		return name, False
	doc = frappe.get_doc({
		"doctype": "Payroll Configuration Version",
		"config_key": key,
		"configuration_type": configuration_type,
		"version": version,
		"configuration_status": "Draft",
		"is_production_eligible": 0,
		"effective_from": payload.get("effective_date_fallback") or EFFECTIVE_FROM,
		"source_reference": payload["source_url"],
		"configuration_json": json.dumps({
			"workbook": payload["workbook_title"],
			"sheet": payload["sheet"],
			"range": payload["range"],
			"excluded_rows": payload["excluded_rows"],
			"purpose": purpose,
		}, sort_keys=True),
		"notes": (
			"Captured from the client PB spreadsheet. The documented sample row is excluded. "
			"The sheet provides no effective date for the real rules, so 2026-01-01 is the migration fallback."
		),
	})
	doc.insert(ignore_permissions=True)
	return doc.name, True


def _unique_gspb_rows(payload):
	rows = []
	duplicates = []
	seen = set()
	for row in payload["rows"]:
		code = row["pdb_code"].strip().upper()
		if code in seen:
			duplicates.append({"pdb_code": code, "sheet_row": row["sheet_row"]})
			continue
		seen.add(code)
		rows.append({
			**row,
			"pdb_code": code,
			"salary_basis_treatment": payload.get("source_treatment_label")
				or row["salary_basis_treatment"],
		})
	return rows, duplicates


def _ensure_gspb(payload):
	rows, duplicates = _unique_gspb_rows(payload)
	missing = [row["pdb_code"] for row in rows if not frappe.db.exists("Payroll PDB Code", row["pdb_code"])]
	if missing:
		from karyo.setup.legacy_pdb_catalogue import import_legacy_pdb_catalogue

		import_legacy_pdb_catalogue(commit=False)
	missing = [row["pdb_code"] for row in rows if not frappe.db.exists("Payroll PDB Code", row["pdb_code"])]
	if missing:
		frappe.throw("Missing PDB Codes required by the GSPB sheet: {0}".format(", ".join(missing)))
	configuration, _ = _ensure_configuration(
		payload,
		key=OP_CONFIG_KEY,
		version=OP_CONFIG_VERSION,
		configuration_type="Operation Codes",
		purpose="GSPB salary-basis components paid in the relevant payroll period",
	)
	created = not frappe.db.exists("Payroll Operation Code", ENTITLEMENT_OPERATION)
	doc = (
		frappe.new_doc("Payroll Operation Code")
		if created
		else frappe.get_doc("Payroll Operation Code", ENTITLEMENT_OPERATION)
	)
	doc.update({
		"operation_code": ENTITLEMENT_OPERATION,
		"description": "Passage Benefit Salary Basis",
		"operation_category": "Earnings Total",
		"is_active": 1,
		"effective_from": payload.get("effective_date_fallback") or EFFECTIVE_FROM,
		"effective_to": None,
		"configuration_version": configuration,
		"source_reference": f"{payload['workbook_title']} {payload['sheet']}!A5:H29",
		"notes": (
			"Source-backed GSPB mapping. Components count only when present on a submitted "
			"Salary Slip for the relevant payroll period. Duplicate C26 at source row 28 is "
			"stored in the source snapshot and mapped once."
		),
	})
	doc.set("items", [])
	for sequence, row in enumerate(rows, start=1):
		doc.append("items", {
			"pdb_code": row["pdb_code"],
			"sequence": sequence,
			"aggregation_sign": "Add",
			"inclusion_percentage": row["inclusion_percentage"],
			"salary_basis_treatment": row["salary_basis_treatment"],
			"effective_from": row.get("effective_from") or payload.get("effective_date_fallback") or EFFECTIVE_FROM,
			"effective_to": row.get("effective_to"),
			"remarks": row.get("remarks") or (
				f"{payload['workbook_title']} {payload['sheet']} row {row['sheet_row']}"
			),
		})
	if created:
		doc.insert(ignore_permissions=True)
	else:
		doc.save(ignore_permissions=True)
	return ENTITLEMENT_OPERATION, created, len(rows), duplicates


def apply_pb_setup_rules(commit=True):
	"""Apply the retained PB rules and the current GSPB component mapping."""
	payload = _load_source()
	gspb_payload = _load_gspb_source()
	operation, operation_created, operation_items, duplicate_rows = _ensure_gspb(gspb_payload)
	pb_configuration, pb_configuration_created = _ensure_configuration(
		payload,
		key=PB_CONFIG_KEY,
		version=PB_CONFIG_VERSION,
		configuration_type="Passage Benefit Rules",
		purpose="Passage Benefit eligibility and computation rules",
	)

	settings = frappe.get_doc("Passage Benefit Settings")
	settings.eligibility_mode = "Salary and Service"
	settings.require_confirmation = 1
	settings.require_permanent_employee = 1
	settings.min_salary_threshold = 37290
	settings.min_years_service = 5
	settings.salary_basis = "Monthly Gross x 12"
	settings.leap_year_treatment = "366 in leap years"
	settings.entitlement_operation_code = operation
	if not settings.configuration_version:
		settings.configuration_version = pb_configuration
	settings.save(ignore_permissions=True)
	frappe.clear_cache(doctype="Passage Benefit Settings")
	if commit:
		frappe.db.commit()
	return {
		"source": f"{gspb_payload['workbook_title']} {gspb_payload['sheet']}!A1:H29",
		"rules": len(payload["rules"]),
		"operation": operation,
		"operation_created": operation_created,
		"operation_items": operation_items,
		"duplicate_source_rows": duplicate_rows,
		"pb_configuration": pb_configuration,
		"pb_configuration_created": pb_configuration_created,
	}


def setup():
	return apply_pb_setup_rules()
