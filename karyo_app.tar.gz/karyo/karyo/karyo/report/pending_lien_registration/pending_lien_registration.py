from datetime import timedelta

import frappe
from frappe import _
from frappe.utils import date_diff, getdate
from karyo.karyo.report.loan_report_utils import add_loan_permission_condition


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if not filters.as_at_date:
		frappe.throw(_("As At Date is required."))
	conditions = ["t.lien_required = 1", "l.docstatus < 2", "coalesce(l.lien_status, 'Pending') not in ('Registered', 'Released', 'Cancelled', 'Not Applicable')", "l.status not in ('Settled', 'Closed')"]
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	for field, expression in (("company", "l.company"), ("loan", "l.name"), ("employee", "l.employee"), ("loan_type", "l.loan_type"), ("owner", "l.owner"), ("lien_status", "l.lien_status")):
		if filters.get(field):
			conditions.append(f"{expression} = %({field})s")
	rows = frappe.db.sql(
		f"""select l.name loan, l.employee, l.employee_name, l.loan_type, l.company,
			l.workflow_state, coalesce(l.lien_status, 'Pending') lien_status,
			l.date_applied, l.creation, l.owner, l.lien_return_reason
		from `tabKaryo Loan` l inner join `tabLoan Type` t on t.name=l.loan_type
		where {' and '.join(conditions)} order by l.date_applied, l.name""",
		filters, as_dict=True,
	)
	data = []
	for row in rows:
		_enrich(row, filters.as_at_date, filters.get("follow_up_days"))
		if not filters.follow_up_status or row.follow_up_status == filters.follow_up_status:
			data.append(row)
	return _columns(), data


def _enrich(row, as_at_date, follow_up_days=7):
	base_date = getdate(row.date_applied or row.creation)
	as_at = getdate(as_at_date)
	row.age_days = max(0, date_diff(as_at, base_date))
	row.due_date = base_date + timedelta(days=max(0, int(follow_up_days or 7)))
	if row.lien_status == "Returned":
		row.follow_up_status = "Returned"
	elif row.due_date < as_at:
		row.follow_up_status = "Overdue"
	elif row.due_date == as_at:
		row.follow_up_status = "Due Today"
	elif date_diff(row.due_date, as_at) <= 2:
		row.follow_up_status = "Due Soon"
	else:
		row.follow_up_status = "Pending"

	documents = frappe.get_all("Karyo Loan Document", filters={"parent": row.loan}, fields=["document_type", "attachment", "verified"])
	received = {d.document_type for d in documents if d.attachment}
	required = _required_documents(row.loan_type, base_date)
	row.required_documents = ", ".join(sorted(required)) or "Lien"
	row.received_documents = ", ".join(sorted(received & required)) or "None"
	row.missing_documents = ", ".join(sorted(required - received)) or "None"
	row.returned_documents = row.lien_return_reason or ("Lien" if row.lien_status == "Returned" else "None")


def _required_documents(loan_type, on_date):
	rules = frappe.get_all("Loan Document Requirement", filters={"is_active": 1, "start_date": ["<=", on_date]}, fields=["loan_type", "document_type", "end_date", "when_lien_required"])
	return {r.document_type for r in rules if (not r.loan_type or r.loan_type == loan_type) and (not r.end_date or getdate(r.end_date) >= on_date) and (r.when_lien_required or r.document_type in ("Registration", "Lien"))}


def _columns():
	def c(fieldname, label, fieldtype="Data", width=120, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("loan", "Loan", "Link", 145, "Karyo Loan"), c("employee", "Employee", "Link", 125, "Employee"), c("employee_name", "Employee Name", width=155),
		c("loan_type", "Loan Type", "Link", 130, "Loan Type"), c("company", "Company", "Link", 140, "Company"), c("workflow_state", "Workflow State", width=155),
		c("lien_status", "Lien Status", width=110), c("required_documents", "Required Documents", width=180), c("received_documents", "Received Documents", width=180),
		c("missing_documents", "Missing Documents", width=180), c("returned_documents", "Returned Documents / Reason", width=220), c("owner", "Owner", "Link", 145, "User"),
		c("age_days", "Age (Days)", "Int", 85), c("due_date", "Follow-up Due", "Date", 105), c("follow_up_status", "Follow-up Status", width=115)]
