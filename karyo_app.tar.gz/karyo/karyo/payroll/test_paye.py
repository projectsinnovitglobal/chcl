"""PAYE engine tests anchored to the client PAYE Computation.xlsx workbook.

The workbook covers income year 2025/26 over 13 PAYE periods
(July..June plus the separate End-of-Year Bonus period).
"""

from unittest import TestCase

from frappe.utils import getdate

from karyo.payroll.paye import (
	calculate_cumulative_paye,
	cumulative_edf_deduction,
	edf_scenario_diagnostics,
	progressive_tax,
	statutory_income_year_bounds,
	statutory_period_index,
)

PAYE_2025_26 = [
	{"upper": 500000, "rate": 0},
	{"upper": 1000000, "rate": 10},
	{"upper": None, "rate": 20},
]

# Workbook column order: July .. November, EOY Bonus, December .. June.
WORKBOOK_EMOLUMENTS = [
	129356.18, 77908.09, 111447.85, 100486.31, 104812.12,
	271546.83, 82242.46, 217574.53, 129200.75,
]


def _run(annual_iet, edf_submitted=True, **kwargs):
	"""Replay the workbook months and return (cumulative, monthly) PAYE."""
	cumulative_emoluments = 0.0
	previous = 0.0
	cumulative, monthly = [], []
	for index, amount in enumerate(WORKBOOK_EMOLUMENTS, start=1):
		cumulative_emoluments += amount
		result = calculate_cumulative_paye(
			cumulative_emoluments=cumulative_emoluments,
			period_index=index,
			bands=PAYE_2025_26,
			cumulative_iet=annual_iet * index / 13,
			previous_paye=previous,
			edf_submitted=edf_submitted,
			**kwargs,
		)
		cumulative.append(result["cumulative_tax"])
		monthly.append(result["current_paye"])
		# The workbook's "Less Previous month PAYE" row is the tax actually
		# withheld so far, not the previous cumulative liability. Payroll carries
		# the same figure forward from the PAYE deducted on submitted slips, so a
		# month whose liability falls below the amount already withheld does not
		# reduce what later months collect.
		previous += result["current_paye"]
	return cumulative, monthly


class TestMauritiusPAYE2025_26(TestCase):
	def test_all_thirteen_edf_scenarios_are_reported_with_one_matching_rule(self):
		year = {"effective_from": "2025-07-01"}
		declaration = {
			"declaration_status": "Submitted",
			"employment_basis": "First Employment",
			"appointment_date": "2025-08-01",
			"effective_from": "2025-08-01",
		}
		rows = edf_scenario_diagnostics(declaration, year, "2025-10-31", cumulative_iet=27500)
		self.assertEqual(len(rows), 13)
		self.assertEqual([row["scenario_id"] for row in rows if row["eligible"]], [1])
		self.assertEqual(rows[0]["calculated_cumulative_iet"], 27500)
		self.assertTrue(all(row["reason"] for row in rows))

	def test_fresh_edf_and_no_edf_scenarios_are_explicit(self):
		year = {"effective_from": "2025-07-01"}
		fresh = {
			"declaration_status": "Submitted",
			"employment_basis": "Not First Employment",
			"appointment_date": "2025-07-01",
			"effective_from": "2025-11-01",
		}
		fresh_rows = edf_scenario_diagnostics(
			fresh, year, "2025-12-31", previous_declaration={"name": "EDF-OLD"}
		)
		self.assertEqual([row["scenario_id"] for row in fresh_rows if row["eligible"]], [11])
		no_edf_rows = edf_scenario_diagnostics(None, year, "2025-12-31")
		self.assertEqual([row["scenario_id"] for row in no_edf_rows if row["eligible"]], [13])
		self.assertEqual(no_edf_rows[12]["status"], "Eligible")

	def test_statutory_month_positions_include_the_bonus_period(self):
		self.assertEqual(statutory_period_index("2025-07-31", "2025-07-01"), 1)
		self.assertEqual(statutory_period_index("2025-11-30", "2025-07-01"), 5)
		self.assertEqual(statutory_period_index("2025-12-31", "2025-07-01"), 7)
		self.assertEqual(statutory_period_index("2026-06-30", "2025-07-01"), 13)

	def test_statutory_positions_defend_against_calendar_year_configuration(self):
		# The ESS schedule must remain July-to-June even if legacy master data
		# mistakenly supplied a January effective date.
		self.assertEqual(statutory_period_index("2026-09-30", "2026-01-01"), 3)
		self.assertEqual(statutory_income_year_bounds("2026-09-30"), (
			getdate("2026-07-01"), getdate("2027-06-30")
		))

	def test_first_employment_february_uses_five_remaining_periods(self):
		# MRA illustration 5: 110,000 is allowed 1/5 through 5/5, while
		# the progressive bands remain at calendar positions 9 through 13.
		values = [
			cumulative_edf_deduction(
				annual_amount=110000,
				period_index=index,
				year_start="2025-07-01",
				appointment_date="2026-02-01",
				first_employment=True,
			)
			for index in range(9, 14)
		]
		self.assertEqual([float(value) for value in values], [22000, 44000, 66000, 88000, 110000])

	def test_late_edf_first_and_subsequent_employment_use_different_denominators(self):
		# MRA illustrations 6 and 8: both joined in August and filed in
		# October, but first employment uses 3/12 and later employment 3/13.
		first = cumulative_edf_deduction(
			annual_amount=110000,
			period_index=4,
			year_start="2025-07-01",
			appointment_date="2025-08-01",
			first_employment=True,
		)
		subsequent = cumulative_edf_deduction(
			annual_amount=190000,
			period_index=4,
			year_start="2025-07-01",
			appointment_date="2025-08-01",
			first_employment=False,
		)
		self.assertEqual(round(float(first), 2), 27500)
		self.assertEqual(round(float(subsequent), 2), 43846.15)

	def test_fresh_edf_spreads_only_the_variance(self):
		# MRA illustration 12(ii): existing 235,000 entitlement plus the
		# 80,000 variance over the nine positions from November to June.
		value = cumulative_edf_deduction(
			annual_amount=315000,
			period_index=5,
			year_start="2025-07-01",
			effective_from="2025-11-30",
			previous_annual_amount=235000,
			previous_cumulative_amount=235000 * 5 / 13,
		)
		self.assertEqual(round(float(value), 2), 99273.5)

	def test_progressive_annual_bands(self):
		self.assertEqual(progressive_tax(500000, PAYE_2025_26)["tax"], 0)
		self.assertEqual(progressive_tax(750000, PAYE_2025_26)["tax"], 25000)
		self.assertEqual(progressive_tax(1224575.12, PAYE_2025_26)["tax"], 94915)

	def test_bands_are_apportioned_over_the_income_year(self):
		# Period 1 of 13 sees one thirteenth of each annual bracket, which is the
		# "Cumulative Chargeable Income" table in the client workbook.
		result = progressive_tax(129356.18, PAYE_2025_26, band_factor=1 / 13)
		self.assertEqual(result["tax"], 14333)
		self.assertEqual(round(result["bands"][0]["to"], 2), 38461.54)
		self.assertEqual(round(result["bands"][1]["to"], 2), 76923.08)

	def test_september_minor_then_major_share_period_three_cumulative_position(self):
		"""Business-rule scenario: Minor is included before September Major."""
		# The supplied scenario carries Rs 1,153 from July and Rs 1,154 from
		# August into September. Both September runs then use P=3.
		withheld_before_september = 1153 + 1154
		minor = calculate_cumulative_paye(
			cumulative_emoluments=250000, current_emoluments=150000,
			period_index=3, bands=PAYE_2025_26, previous_paye=withheld_before_september,
		)
		major = calculate_cumulative_paye(
			cumulative_emoluments=300000, current_emoluments=50000,
			period_index=3, bands=PAYE_2025_26,
			previous_paye=withheld_before_september + minor["current_paye"],
		)
		self.assertEqual(
			[minor["current_paye"], major["current_paye"]], [13077, 10000],
		)
		self.assertEqual(minor["cumulative_tax"], 15384)
		self.assertEqual(major["cumulative_tax"], 25384)
		self.assertEqual(minor["period_index"], major["period_index"])
		self.assertEqual(minor["current_paye"] + major["current_paye"], 23077)
		self.assertEqual(withheld_before_september + minor["current_paye"] + major["current_paye"], 25384)

	def test_guide_whole_rupee_band_boundaries_are_configurable(self):
		result = progressive_tax(
			129356.18,
			PAYE_2025_26,
			band_factor=1 / 13,
			band_boundary_rounding="Whole Rupee",
		)
		self.assertEqual(result["bands"][0]["to"], 38462)

	def test_workbook_iet_no_dependent(self):
		cumulative, monthly = _run(0)
		self.assertEqual(cumulative, [14333, 18376, 29127, 37686, 47110, 89881, 94791, 126767, 141068])
		self.assertEqual(monthly, [14333, 4043, 10751, 8559, 9424, 42771, 4910, 31976, 14301])

	def test_workbook_iet_one_dependent(self):
		cumulative, monthly = _run(110000)
		self.assertEqual(cumulative, [12640, 14991, 24050, 30917, 38648, 79727, 82945, 113228, 125838])
		self.assertEqual(monthly, [12640, 2351, 9059, 6867, 7731, 41079, 3218, 30283, 12610])

	def test_workbook_iet_two_dependents(self):
		cumulative, monthly = _run(190000)
		self.assertEqual(cumulative, [11410, 12529, 20357, 25994, 32495, 72342, 74329, 103382, 114761])
		self.assertEqual(monthly, [11410, 1119, 7828, 5637, 6501, 39847, 1987, 29053, 11379])

	def test_workbook_three_dependents_plus_medical_insurance(self):
		# 275,000 for three dependents plus 25,000 self medical insurance relief.
		cumulative, monthly = _run(300000)
		self.assertEqual(cumulative, [9717, 9145, 15280, 19225, 24033, 62188, 62483, 89844, 99530])
		# August's liability falls below the July withholding, so nothing is
		# withheld and September collects against the July figure.
		self.assertEqual(monthly, [9717, 0, 5563, 3945, 4808, 38155, 295, 27361, 9686])

	def test_workbook_no_edf_submitted(self):
		cumulative, monthly = _run(0, edf_submitted=False)
		self.assertEqual(cumulative, [19403, 31090, 47807, 62880, 78602, 119334, 131670, 164306, 183686])
		self.assertEqual(monthly, [19403, 11687, 16717, 15073, 15722, 40732, 12336, 32636, 19380])

	def test_edf_relief_is_apportioned_over_thirteen_periods(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=600000,
			period_index=6,
			bands=PAYE_2025_26,
			annual_reliefs=110000,
		)
		self.assertEqual(result["allowed_reliefs"], 50769.23)
		self.assertEqual(result["chargeable_income"], 549230.77)
		# Period 6 of 13: 0% to 230,769.23, 10% to 461,538.46, 20% above.
		self.assertEqual(result["cumulative_tax"], 40615)

	def test_twenty_percent_no_edf_option(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=100000,
			period_index=1,
			bands=PAYE_2025_26,
			edf_submitted=False,
			no_edf_rate=20,
		)
		self.assertEqual(result["current_paye"], 20000)

	def test_no_edf_taxes_the_current_payment_without_prior_period_catchup(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=300000,
			current_emoluments=50000,
			period_index=4,
			bands=PAYE_2025_26,
			edf_submitted=False,
			no_edf_rate=15,
			previous_paye=1000,
		)
		self.assertEqual(result["current_paye"], 7500)

	def test_current_period_tax_never_refunds_automatically(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=600000,
			period_index=6,
			bands=PAYE_2025_26,
			previous_paye=100000,
		)
		self.assertEqual(result["current_paye"], 0)

	def test_monthly_exempt_threshold_withholds_nothing(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=38000,
			period_index=1,
			bands=PAYE_2025_26,
			current_emoluments=38000,
			no_paye_threshold=38462,
		)
		self.assertTrue(result["exempt_period"])
		self.assertEqual(result["current_paye"], 0)

	def test_exempt_threshold_does_not_erase_the_cumulative_position(self):
		# A quiet month withholds nothing; the tax is collected once a later
		# month lifts cumulative emoluments back above the apportioned bands.
		quiet = calculate_cumulative_paye(
			cumulative_emoluments=38000,
			period_index=1,
			bands=PAYE_2025_26,
			current_emoluments=38000,
			no_paye_threshold=38462,
		)
		self.assertEqual(quiet["current_paye"], 0)
		busy = calculate_cumulative_paye(
			cumulative_emoluments=238000,
			period_index=2,
			bands=PAYE_2025_26,
			current_emoluments=200000,
			no_paye_threshold=38462,
			previous_paye=quiet["current_paye"],
		)
		self.assertFalse(busy["exempt_period"])
		self.assertEqual(busy["current_paye"], busy["cumulative_tax"])

	def test_director_and_board_member_fees_use_the_flat_rate(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=30000,
			period_index=1,
			bands=PAYE_2025_26,
			annual_reliefs=500000,
			current_emoluments=30000,
			no_paye_threshold=38462,
			flat_rate=15,
		)
		self.assertEqual(result["mode"], "Director or Board Member Flat Rate")
		self.assertFalse(result["exempt_period"])
		self.assertEqual(result["current_paye"], 4500)

	def test_fair_share_contribution_applies_above_the_threshold(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=13000000,
			period_index=13,
			bands=PAYE_2025_26,
			fair_share_threshold=12000000,
			fair_share_rate=15,
		)
		self.assertEqual(result["fair_share_contribution"], 150000)
		self.assertEqual(result["cumulative_tax"], progressive_tax(13000000, PAYE_2025_26)["tax"] + 150000)

	def test_fair_share_contribution_is_off_when_unconfigured(self):
		result = calculate_cumulative_paye(
			cumulative_emoluments=13000000,
			period_index=13,
			bands=PAYE_2025_26,
		)
		self.assertEqual(result["fair_share_contribution"], 0)
