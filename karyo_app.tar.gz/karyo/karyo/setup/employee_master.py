"""Employee and Company fields required by the payroll-management manual."""

import re

import frappe
from frappe import _
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.utils import cint, getdate, nowdate


MASTER_SLUGS = (
	"education_level",
	"marital_status",
	"employee_section",
	"employee_category",
	"employee_payroll_group",
	"employee_work_pattern",
	"employee_loan_eligibility_group",
)

EMPLOYEE_HOURLY_RATE_FIELDS = [
	{
		"fieldname": "karyo_hourly_rate",
		"fieldtype": "Currency",
		"label": "Normal Hourly Rate",
		"options": "Company:company:default_currency",
		"precision": "6",
		"insert_after": "karyo_work_pattern",
		"read_only": 1,
		"no_copy": 1,
	},
	{
		"fieldname": "karyo_hourly_rate_calculation",
		"fieldtype": "Small Text",
		"label": "Hourly Rate Calculation",
		"insert_after": "karyo_hourly_rate",
		"read_only": 1,
		"no_copy": 1,
	},
]


# Authoritative Employee Category / Employment Type mapping supplied in the
# MBC migration template.  Category Code is the Employee Category document
# name; Employment Type remains the value selected on Employee.
EMPLOYEE_CATEGORY_TYPES = (
	("PERM", "Permanent", "Permanent"),
	("RELF", "Relief", "Relief"),
	("CONT", "Contract", "Contract"),
	("CASL", "Casual", "Casual"),
	("PT", "Part-Time", "Part-Time"),
	("PEN", "Pensioner", "Pensioner"),
	("TEMP", "Temporary", "Temporary"),
	("FS", "Freelance Sessional", "Freelance Sessional"),
	("FM", "Freelance Monthly", "Freelance Monthly"),
	("STUD", "Intern", "Intern"),
	("BOARD", "Board Member", "Board Member"),
	("RESP", "Resource Person", "Resource Person"),
	("PANEL", "Panel Member", "Panel Member"),
	("DISC", "Disciplinary Member", "Disciplinary Member"),
	("TRAIN", "Trainee", "Trainee"),
	("PROB", "Probation", "Probation"),
)

MARITAL_STATUSES = (
	("D", "Divorced"),
	("M", "Married"),
	("S", "Single"),
	("W", "Widowed"),
)

# Approved Location / Site Master rows from the client migration sheet.
# The sample row in that sheet is deliberately excluded.
LOCATION_CODES = (
	("ADM", "Administration"),
	("HR", "Human Resource"),
	("FIN", "Finance"),
	("NA", "Not Applicable"),
)

LEGACY_EMPLOYMENT_TYPE_MAP = {
	"Full-time": "Permanent",
	"Part-time": "Part-Time",
	"Permanent": "Permanent",
	"Contract": "Contract",
	"Casual": "Casual",
	"Temporary": "Temporary",
	"Intern": "Intern",
	"Probation": "Probation",
}

LEGACY_CATEGORY_TYPE_MAP = {
	"Permanent": "Permanent",
	"Contract": "Contract",
	"Casual": "Casual",
	"Temporary": "Temporary",
	"Part-time": "Part-Time",
	"Intern": "Intern",
	"Probation": "Probation",
}


def apply():
	for slug in MASTER_SLUGS:
		frappe.reload_doc("karyo", "doctype", slug)
	_seed_reference_masters()
	_seed_marital_statuses()
	_seed_locations()
	_create_fields()
	_replace_employee_categories()
	_backfill_employee_attendance_defaults()
	_backfill_leave_bank_counters()
	_apply_labels_and_dependencies()
	_backfill_marital_status_codes()
	_seed_education_levels()
	_backfill_reference_codes()
	_backfill_company_profile()
	_backfill_locations()
	_backfill_employee_bank_routing()
	_secure_employee_documents()
	_repair_premature_pending_separations()
	_backfill_approved_separations()
	frappe.clear_cache()


def setup():
	apply()


def _seed(doctype, code_field, name_field, values):
	for value in sorted({str(value).strip() for value in values if str(value or "").strip()}):
		if not frappe.db.exists(doctype, value):
			frappe.get_doc({
				"doctype": doctype,
				code_field: value,
				name_field: value,
			}).insert(ignore_permissions=True)


def _distinct_employee_values(fieldname):
	return [row[0] for row in frappe.db.sql(
		f"select distinct `{fieldname}` from `tabEmployee` where coalesce(`{fieldname}`, '')<>''"
	)]


def _distinct_values(doctype, fieldname):
	if not frappe.db.table_exists(doctype) or not frappe.db.has_column(doctype, fieldname):
		return []
	return [row[0] for row in frappe.db.sql(
		f"select distinct `{fieldname}` from `tab{doctype}` where coalesce(`{fieldname}`, '')<>''"
	)]


def _seed_reference_masters():
	_seed(
		"Employee Payroll Group", "payroll_group_code", "payroll_group_name",
		[
			"Permanent", "Casual", "Board Member",
			*_distinct_employee_values("karyo_payroll_group"),
			*_distinct_values("Pay Day", "payroll_group"),
			*_distinct_values("Payroll Pay Day", "payroll_group"),
		],
	)


def _seed_marital_statuses():
	for code, description in MARITAL_STATUSES:
		if not frappe.db.exists("Marital Status", code):
			frappe.get_doc({
				"doctype": "Marital Status",
				"marital_status_code": code,
				"marital_status_description": description,
				"is_active": 1,
			}).insert(ignore_permissions=True)


def _seed_locations():
	"""Create or refresh the approved code-to-name Location master mapping."""
	for code, location_name in LOCATION_CODES:
		if frappe.db.exists("Employee Location", code):
			frappe.db.set_value(
				"Employee Location", code,
				{"location_code": code, "location_name": location_name},
				update_modified=False,
			)
		else:
			doc = frappe.get_doc({
				"doctype": "Employee Location",
				"location_code": code,
				"location_name": location_name,
			})
			# These imported reference codes pre-date the governed organisation
			# hierarchy. Keep them as inactive assignment candidates until an HR
			# administrator links each one to a Department and Section.
			doc.flags.allow_unmapped_location = True
			doc.insert(ignore_permissions=True, ignore_mandatory=True)


def _backfill_marital_status_codes():
	"""Translate ERPNext's former Select values to governed master codes."""
	description_to_code = {description: code for code, description in MARITAL_STATUSES}
	for description, code in description_to_code.items():
		frappe.db.sql(
			"update `tabEmployee` set marital_status=%s where marital_status=%s",
			(code, description),
		)
	_seed(
		"Employee Work Pattern", "work_pattern_code", "work_pattern_name",
		_distinct_employee_values("karyo_work_pattern"),
	)
	_seed(
		"Employee Loan Eligibility Group", "eligibility_group_code", "eligibility_group_name",
		["General", "Permanent", "Contract", "Temporary", "Casual", "Secondment"],
	)

def _replace_employee_categories():
	"""Replace legacy rows with the approved mapping and repair all live links."""
	desired_types = {employment_type for _, _, employment_type in EMPLOYEE_CATEGORY_TYPES}
	type_to_category = {
		employment_type: (code, description)
		for code, description, employment_type in EMPLOYEE_CATEGORY_TYPES
	}
	dependency_fields = [
		"map_dependencies", "pensionable", "payroll_eligible", "pb_eligibility_rule",
		"leave_scheme", "loan_eligibility_group", "contribution_group", "remarks", "disabled",
	]
	category_meta = frappe.get_meta("Employee Category")
	dependency_fields = [fieldname for fieldname in dependency_fields if category_meta.has_field(fieldname)]
	existing_categories = frappe.get_all(
		"Employee Category", fields=["name", "employment_type", *dependency_fields], limit_page_length=0
	)
	category_type_by_name = {row.name: row.employment_type for row in existing_categories}
	category_defaults_by_type = {row.employment_type: row for row in existing_categories if row.employment_type}

	def target_type(value):
		value = str(value or "").strip()
		if value in desired_types:
			return value
		return LEGACY_EMPLOYMENT_TYPE_MAP.get(value)

	employees = frappe.get_all(
		"Employee", fields=["name", "employment_type", "karyo_employment_category"], limit_page_length=0
	)
	linked_rows = []
	link_fields = frappe.get_all(
		"DocField", filters={"fieldtype": "Link", "options": "Employment Type"},
		fields=["parent", "fieldname"], limit_page_length=0,
	) + frappe.get_all(
		"Custom Field", filters={"fieldtype": "Link", "options": "Employment Type"},
		fields=["dt as parent", "fieldname"], limit_page_length=0,
	)
	seen_fields = set()
	for field in link_fields:
		key = (field.parent, field.fieldname)
		if key in seen_fields or field.parent in ("Employee", "Employee Category"):
			continue
		seen_fields.add(key)
		if not frappe.db.table_exists(field.parent) or not frappe.db.has_column(field.parent, field.fieldname):
			continue
		for row in frappe.get_all(field.parent, fields=["name", field.fieldname], limit_page_length=0):
			value = row.get(field.fieldname)
			if value:
				linked_rows.append((field.parent, row.name, field.fieldname, target_type(value)))
	category_linked_rows = []
	category_link_fields = frappe.get_all(
		"DocField", filters={"fieldtype": "Link", "options": "Employee Category"},
		fields=["parent", "fieldname"], limit_page_length=0,
	) + frappe.get_all(
		"Custom Field", filters={"fieldtype": "Link", "options": "Employee Category"},
		fields=["dt as parent", "fieldname"], limit_page_length=0,
	)
	seen_category_fields = set()
	for field in category_link_fields:
		key = (field.parent, field.fieldname)
		if key in seen_category_fields or field.parent in ("Employee", "Employee Category"):
			continue
		seen_category_fields.add(key)
		if not frappe.db.table_exists(field.parent) or not frappe.db.has_column(field.parent, field.fieldname):
			continue
		for row in frappe.get_all(field.parent, fields=["name", field.fieldname], limit_page_length=0):
			value = row.get(field.fieldname)
			employment_type = category_type_by_name.get(value)
			if value and employment_type in type_to_category:
				category_linked_rows.append(
					(field.parent, row.name, field.fieldname, type_to_category[employment_type][0])
				)

	# Delete the former master rows directly after their live references have
	# been captured. This prevents Frappe's link guard from retaining obsolete
	# entries while still allowing dependent documents to be repaired below.
	frappe.db.sql("delete from `tabEmployee Category`")
	frappe.db.sql("delete from `tabEmployment Type`")

	for _, _, employment_type in EMPLOYEE_CATEGORY_TYPES:
		frappe.get_doc({
			"doctype": "Employment Type", "employee_type_name": employment_type,
		}).insert(ignore_permissions=True)
	for code, description, employment_type in EMPLOYEE_CATEGORY_TYPES:
		preserved = category_defaults_by_type.get(employment_type) or {}
		frappe.get_doc({
			"doctype": "Employee Category",
			"employment_type": employment_type,
			"category_code": code,
			"category_name": description,
			**{fieldname: preserved.get(fieldname) for fieldname in dependency_fields},
		}).insert(ignore_permissions=True)

	for doctype, name, fieldname, value in linked_rows:
		frappe.db.set_value(doctype, name, fieldname, value, update_modified=False)
	for doctype, name, fieldname, value in category_linked_rows:
		frappe.db.set_value(doctype, name, fieldname, value, update_modified=False)
	for employee in employees:
		employment_type = target_type(employee.employment_type)
		if not employment_type:
			employment_type = LEGACY_CATEGORY_TYPE_MAP.get(employee.karyo_employment_category)
		category_code, description = type_to_category.get(employment_type, (None, None))
		frappe.db.set_value(
			"Employee", employee.name,
			{
				"employment_type": employment_type,
				"karyo_employment_category": category_code,
				"karyo_employment_category_description": description,
			},
			update_modified=False,
		)


def _seed_education_levels():
	for level in ("Graduate", "Post Graduate"):
		if not frappe.db.exists("Education Level", level):
			frappe.get_doc({"doctype": "Education Level", "level_name": level}).insert(ignore_permissions=True)


def _create_fields():
	# Frappe intentionally blocks fieldtype changes through Custom Field.save().
	# These columns already store text Link keys, so update their metadata first
	# and let create_custom_fields perform the remaining idempotent properties.
	for fieldname, options in (
		("karyo_employment_category", "Employee Category"),
		("karyo_work_pattern", "Employee Work Pattern"),
		("karyo_payroll_group", "Employee Payroll Group"),
	):
		name = frappe.db.get_value("Custom Field", {"dt": "Employee", "fieldname": fieldname}, "name")
		if name:
			frappe.db.set_value(
				"Custom Field", name, {"fieldtype": "Link", "options": options}, update_modified=False
			)
	frappe.clear_cache(doctype="Employee")
	create_custom_fields(
		{
			"Employee": [
				{"fieldname": "karyo_payroll_setup_pending_activation", "fieldtype": "Check",
				 "label": "Payroll Setup Pending Activation", "insert_after": "status", "default": "0",
				 "hidden": 1, "read_only": 1, "no_copy": 1},
				{"fieldname": "karyo_address_line_1", "fieldtype": "Data", "label": "Address 1", "insert_after": "address_section"},
				{"fieldname": "karyo_address_line_2", "fieldtype": "Data", "label": "Address 2", "insert_after": "karyo_address_line_1"},
				{"fieldname": "karyo_employment_start_date", "fieldtype": "Date", "label": "Employment Start Date", "insert_after": "karyo_date_joined_service"},
				{"fieldname": "karyo_section", "fieldtype": "Link", "label": "Section Code", "options": "Employee Section", "insert_after": "department", "in_standard_filter": 1},
				{"fieldname": "karyo_on_payroll", "fieldtype": "Check", "label": "On Payroll?", "insert_after": "karyo_payroll_group", "default": "0", "in_standard_filter": 1},
				{"fieldname": "karyo_contribution_group", "fieldtype": "Link", "label": "Contribution Group", "options": "Payroll Contribution Scheme", "insert_after": "karyo_pay_day"},
				{"fieldname": "karyo_leave_scheme", "fieldtype": "Link", "label": "Primary Leave Scheme", "options": "Leave Policy", "insert_after": "karyo_contribution_group"},
				{"fieldname": "karyo_leave_block_list", "fieldtype": "Link", "label": "Leave Block", "options": "Leave Block List", "insert_after": "karyo_leave_scheme"},
				{"fieldname": "karyo_loan_eligibility_group", "fieldtype": "Link", "label": "Loan Eligibility Group", "options": "Employee Loan Eligibility Group", "insert_after": "karyo_leave_scheme"},
				{"fieldname": "karyo_employment_category", "fieldtype": "Link", "label": "Category Code", "options": "Employee Category", "insert_after": "employment_type", "read_only": 1},
				{"fieldname": "karyo_employment_category_description", "fieldtype": "Data", "label": "Category Description", "insert_after": "karyo_employment_category", "fetch_from": "karyo_employment_category.category_name", "read_only": 1},
				{"fieldname": "karyo_payroll_eligible", "fieldtype": "Check", "label": "Payroll Eligible?", "insert_after": "karyo_employment_category_description", "default": "0", "read_only": 1, "no_copy": 1, "description": "Eligibility inherited from Employee Category. This does not activate On Payroll."},
				{"fieldname": "karyo_pb_eligibility_rule", "fieldtype": "Select", "label": "PB Eligibility Rule", "options": "Not Eligible\nEligible\nEligible after Confirmation", "insert_after": "karyo_payroll_eligible", "read_only": 1, "no_copy": 1},
				{"fieldname": "karyo_disciplined_force", "fieldtype": "Check", "label": "Disciplined Force (Fire / Police / Prisons)", "insert_after": "karyo_pb_eligibility_rule", "default": "0"},
				{"fieldname": "karyo_work_pattern", "fieldtype": "Link", "label": "Work Pattern", "options": "Employee Work Pattern", "insert_after": "holiday_list"},
				*EMPLOYEE_HOURLY_RATE_FIELDS,
				{"fieldname": "karyo_payroll_group", "fieldtype": "Link", "label": "Payroll Group", "options": "Employee Payroll Group", "insert_after": "karyo_hr_sb"},
				{"fieldname": "karyo_national_id", "fieldtype": "Data", "label": "NIC / Passport", "insert_after": "karyo_legacy_employee_id", "in_standard_filter": 1},
				{"fieldname": "karyo_employee_bank_details_tab", "fieldtype": "Tab Break", "label": "Employee Bank Details", "insert_after": "salary_information"},
				{"fieldname": "karyo_payment_details_sb", "fieldtype": "Section Break", "label": "Salary Payment Destination", "insert_after": "karyo_employee_bank_details_tab"},
				{"fieldname": "karyo_payroll_bank", "fieldtype": "Link", "label": "Primary Payroll Bank", "options": "Bank", "insert_after": "karyo_payment_details_sb", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_payroll_bank_branch", "fieldtype": "Link", "label": "Primary Payroll Bank Branch", "options": "Payroll Bank Branch", "insert_after": "karyo_payroll_bank", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_employee_code", "fieldtype": "Data", "label": "Employee Code", "read_only": 1, "no_copy": 1, "insert_after": "bank_details_section", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_account_holder_name", "fieldtype": "Data", "label": "Primary Account Holder", "insert_after": "bank_ac_no", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_employee_bank_account_cb", "fieldtype": "Column Break", "insert_after": "karyo_payroll_bank_branch"},
				{"fieldname": "karyo_bank_account_is_primary", "fieldtype": "Check", "label": "Primary Account?", "default": "1", "insert_after": "karyo_employee_bank_account_cb", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_account_effective_from", "fieldtype": "Date", "label": "Primary Account Effective From", "insert_after": "karyo_bank_account_is_primary", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_account_effective_to", "fieldtype": "Date", "label": "Primary Account Effective To", "insert_after": "karyo_bank_account_effective_from", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_routing_sb", "fieldtype": "Section Break", "label": "Primary Bank and Branch Master Mapping", "insert_after": "karyo_secondary_bank_effective_to", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_code", "fieldtype": "Data", "label": "Bank Code", "fetch_from": "karyo_payroll_bank.karyo_bank_code", "read_only": 1, "insert_after": "karyo_payroll_bank_branch", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_swift_code", "fieldtype": "Data", "label": "SWIFT Code", "fetch_from": "karyo_payroll_bank.swift_number", "read_only": 1, "insert_after": "karyo_bank_code", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_transfer_code", "fieldtype": "Data", "label": "Bank Transfer Code", "fetch_from": "karyo_payroll_bank.karyo_bank_transfer_code", "read_only": 1, "insert_after": "karyo_bank_swift_code", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_other_code", "fieldtype": "Data", "label": "Bank Other Code", "fetch_from": "karyo_payroll_bank.karyo_bank_other_code", "read_only": 1, "insert_after": "karyo_bank_transfer_code", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_routing_cb", "fieldtype": "Column Break", "insert_after": "karyo_bank_other_code", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_branch_code", "fieldtype": "Data", "label": "Branch Code", "fetch_from": "karyo_payroll_bank_branch.branch_code", "read_only": 1, "insert_after": "karyo_bank_routing_cb", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_branch_name", "fieldtype": "Data", "label": "Branch Name", "fetch_from": "karyo_payroll_bank_branch.branch_name", "read_only": 1, "insert_after": "karyo_branch_code", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_branch_transfer_code", "fieldtype": "Data", "label": "Branch Transfer Code", "fetch_from": "karyo_payroll_bank_branch.transfer_code", "read_only": 1, "insert_after": "karyo_branch_name", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_branch_other_code", "fieldtype": "Data", "label": "Branch Other Code", "fetch_from": "karyo_payroll_bank_branch.other_code", "read_only": 1, "insert_after": "karyo_branch_transfer_code", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_branch_active", "fieldtype": "Check", "label": "Branch Active", "fetch_from": "karyo_payroll_bank_branch.is_active", "read_only": 1, "insert_after": "karyo_branch_other_code", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_bank_master_details", "fieldtype": "HTML", "label": "Bank and Branch Master Details", "insert_after": "karyo_branch_active", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_cheque_details_sb", "fieldtype": "Section Break", "label": "Cheque Details", "insert_after": "karyo_bank_master_details", "hidden": 1},
				{"fieldname": "karyo_cheque_number", "fieldtype": "Data", "label": "Cheque Number", "insert_after": "karyo_cheque_details_sb", "hidden": 1},
				{"fieldname": "karyo_cheque_date", "fieldtype": "Date", "label": "Cheque Date", "insert_after": "karyo_cheque_number", "hidden": 1},
				{"fieldname": "karyo_cheque_bank", "fieldtype": "Data", "label": "Cheque Bank / Drawer", "insert_after": "karyo_cheque_date", "hidden": 1},
				{"fieldname": "karyo_cheque_reference", "fieldtype": "Data", "label": "Cheque Reference", "insert_after": "karyo_cheque_bank", "hidden": 1},
				{"fieldname": "karyo_cash_details_sb", "fieldtype": "Section Break", "label": "Cash Details", "insert_after": "karyo_cheque_reference", "hidden": 1},
				{"fieldname": "karyo_cash_receipt_number", "fieldtype": "Data", "label": "Cash Receipt Number", "insert_after": "karyo_cash_details_sb", "hidden": 1},
				{"fieldname": "karyo_cash_reference", "fieldtype": "Data", "label": "Cash Reference Number", "insert_after": "karyo_cash_receipt_number", "hidden": 1},
				{"fieldname": "karyo_cash_collection_point", "fieldtype": "Data", "label": "Cash Collection Point", "insert_after": "karyo_cash_reference", "hidden": 1},
				{"fieldname": "karyo_employee_payroll_tab", "fieldtype": "Tab Break", "label": "Payroll", "insert_after": "karyo_cash_collection_point"},
				{"fieldname": "karyo_offer_letter_issued_on", "fieldtype": "Date", "label": "Offer Letter Issued On", "insert_after": "offer_letter", "depends_on": "eval:doc.offer_letter"},
				{"fieldname": "karyo_joining_letter_issued_on", "fieldtype": "Date", "label": "Joining Letter Issued On", "insert_after": "joining_letter", "depends_on": "eval:doc.joining_letter"},
				{"fieldname": "karyo_other_letters", "fieldtype": "Attach", "label": "Other Letter", "insert_after": "karyo_joining_letter_issued_on"},
				 {"fieldname": "karyo_other_letter_issued_on", "fieldtype": "Date", "label": "Other Letter Issued On", "insert_after": "karyo_other_letters", "depends_on": "eval:doc.karyo_other_letters"},
				{"fieldname": "karyo_tax_declaration_tab", "fieldtype": "Tab Break", "label": "Tax Declaration", "insert_after": "old_parent"},
				{"fieldname": "karyo_tax_declaration_workspace", "fieldtype": "HTML", "label": "Employee Tax Declaration", "insert_after": "karyo_tax_declaration_tab"},
			],
			"Employee Separation": [
				{"fieldname": "karyo_previous_employee_status", "fieldtype": "Data", "label": "Previous Employee Status", "insert_after": "amended_from", "hidden": 1, "read_only": 1, "no_copy": 1},
				{"fieldname": "karyo_previous_user_enabled", "fieldtype": "Check", "label": "Previous User Enabled", "insert_after": "karyo_previous_employee_status", "hidden": 1, "read_only": 1, "no_copy": 1},
			],
			"Company": [
				{"fieldname": "karyo_company_code", "fieldtype": "Data", "label": "Code", "insert_after": "company_name", "read_only": 1, "reqd": 1, "unique": 1, "in_list_view": 1},
				{"fieldname": "karyo_financial_year", "fieldtype": "Link", "label": "Financial Year", "options": "Fiscal Year", "insert_after": "karyo_paye_number"},
				{"fieldname": "karyo_fin_start_date", "fieldtype": "Date", "label": "Fin Start Date", "insert_after": "karyo_financial_year", "fetch_from": "karyo_financial_year.year_start_date", "read_only": 1},
				{"fieldname": "karyo_fin_end_date", "fieldtype": "Date", "label": "Fin End Date", "insert_after": "karyo_fin_start_date", "fetch_from": "karyo_financial_year.year_end_date", "read_only": 1},
				{"fieldname": "karyo_calendar_year", "fieldtype": "Int", "label": "Calendar Year", "insert_after": "karyo_fin_end_date", "read_only": 1},
				{"fieldname": "karyo_payroll_bank", "fieldtype": "Link", "label": "Payroll Bank Name", "options": "Bank", "insert_after": "hr_settings_section"},
				{"fieldname": "karyo_payroll_bank_branch", "fieldtype": "Link", "label": "Branch Name", "options": "Payroll Bank Branch", "insert_after": "karyo_payroll_bank"},
				{"fieldname": "karyo_company_payroll_accounts_cb", "fieldtype": "Column Break", "insert_after": "karyo_payroll_bank_branch"},
			],
			"Department": [
				{"fieldname": "karyo_department_code", "fieldtype": "Data", "label": "Department Code", "insert_after": "department_name", "reqd": 1, "unique": 1, "in_list_view": 1, "in_standard_filter": 1},
			],
			"Designation": [
				{"fieldname": "karyo_job_code", "fieldtype": "Data", "label": "Post / Job Code", "insert_after": "designation_name", "reqd": 1, "unique": 1, "in_list_view": 1, "in_standard_filter": 1},
			],
			"Shift Type": [
				{"fieldname": "karyo_shift_code", "fieldtype": "Data", "label": "Shift Code", "insert_after": "start_time", "reqd": 1, "unique": 1, "in_list_view": 1, "in_standard_filter": 1},
			],
			"Employee External Work History": [
				{"fieldname": "karyo_from_date", "fieldtype": "Date", "label": "From Date", "insert_after": "designation", "in_list_view": 1},
				{"fieldname": "karyo_to_date", "fieldtype": "Date", "label": "To Date", "insert_after": "karyo_from_date", "in_list_view": 1},
			],
		},
		update=True,
	)


def ensure_hourly_rate_fields():
	"""Install only the Attendance & Leaves hourly-rate display fields."""
	create_custom_fields({"Employee": EMPLOYEE_HOURLY_RATE_FIELDS}, update=True)
	frappe.clear_cache(doctype="Employee")


def _property(doctype, fieldname, prop, value, prop_type="Data"):
	make_property_setter(
		doctype, fieldname, prop, value, prop_type, for_doctype=fieldname is None
	)


def _apply_labels_and_dependencies():
	employee_labels = {
		"employee": "Employee Code",
		"salutation": "Title",
		"last_name": "Surname",
		"cell_number": "Phone",
		"date_of_joining": "Date Joined Organisation",
		"karyo_date_joined_service": "Date Joined Service",
		"final_confirmation_date": "Confirmation Date",
		"contract_end_date": "Employment End Date",
		"date_of_retirement": "Retirement Date",
		"status": "Employee Status",
		"employment_type": "Employment Type",
		"karyo_employment_category": "Category Code",
		"karyo_permanent_pensionable": "Pensionable?",
		"pb_eligible": "PB Eligible?",
		"salary_mode": "Payment Mode",
		"department": "Department Code",
		"karyo_location": "Location / Site Code",
		"payroll_cost_center": "Cost Centre",
		"karyo_job_family": "Job Family Code",
		"designation": "Post / Job Code",
		"grade": "Grade Code",
		"karyo_salary_scale": "Salary Scale Code",
		"karyo_scale_salary_point": "Salary Step / Point",
		"karyo_scale_basic_salary": "Basic Salary",
		"holiday_list": "Calendar Code",
		"default_shift": "Shift Type",
	}
	for fieldname, label in employee_labels.items():
		_property("Employee", fieldname, "label", label)

	company_labels = {
		"company_name": "Name",
		"abbr": "Abbreviation Name",
		"karyo_address_line_1": "Address",
		"karyo_address_line_2": "Address 2",
		"karyo_address_line_3": "Address 3",
		"phone_no": "Phone",
		"karyo_paye_number": "PAYE No",
	}
	for fieldname, label in company_labels.items():
		_property("Company", fieldname, "label", label)

	payroll_required = (
		"karyo_national_id", "last_name", "department", "karyo_location", "designation", "grade",
		"karyo_salary_scale", "karyo_scale_salary_point", "karyo_scale_basic_salary",
		"karyo_payroll_group", "karyo_employment_start_date", "salary_mode",
	)
	for fieldname in payroll_required:
		_property("Employee", fieldname, "mandatory_depends_on", "eval:doc.karyo_on_payroll", "Data")
	# Joining dates stay together; PRB/PB and salary controls live on Payroll.
	_property("Employee", "karyo_date_joined_service", "insert_after", "final_confirmation_date", "Data")
	_property("Employee", "karyo_employment_start_date", "insert_after", "karyo_date_joined_service", "Data")
	_property("Employee", "karyo_date_confirmed", "hidden", 1, "Check")
	# Shift & Roster Setup is the single employee-facing source of the assigned
	# shift. ``default_shift`` remains as the upstream HRMS compatibility/storage
	# field, but exposing it beside the live roster assignment presents the same
	# value twice and lets users edit the non-authoritative copy.
	_property("Employee", "default_shift", "hidden", 1, "Check")
	_property("Employee", "karyo_shift_code", "hidden", 1, "Check")
	_property("Employee", "karyo_hr_sb", "insert_after", "salary_information", "Data")
	_property("Employee", "ctc", "label", "Cost to Company (CTC)")
	_property("Employee", "ctc", "read_only", 1, "Check")
	_property("Employee", "ctc", "insert_after", "karyo_scale_salary_point", "Data")
	_property("Employee", "karyo_scale_basic_salary", "hidden", 1, "Check")
	_property("Employee", "karyo_salary_effective_from", "insert_after", "ctc", "Data")
	_property("Employee", "salary_information", "hidden", 1, "Check")
	_property("Employee", "karyo_employee_bank_details_tab", "insert_after", "salary_information", "Data")
	_property("Employee", "karyo_payment_details_sb", "insert_after", "karyo_employee_bank_details_tab", "Data")
	_property("Employee", "salary_mode", "insert_after", "karyo_payment_details_sb", "Data")
	_property("Employee", "salary_mode", "options", "\nBank\nCheque\nCash", "Text")
	_property("Employee", "bank_details_section", "insert_after", "salary_mode", "Data")
	_property("Employee", "bank_details_section", "label", "Primary Salary Bank", "Data")
	_property("Employee", "bank_details_section", "hidden", 0, "Check")
	_property("Employee", "karyo_bank_employee_code", "insert_after", "bank_details_section", "Data")
	_property("Employee", "karyo_payroll_bank", "insert_after", "karyo_bank_employee_code", "Data")
	_property("Employee", "karyo_payroll_bank", "label", "Primary Bank", "Data")
	_property("Employee", "karyo_bank_code", "insert_after", "karyo_payroll_bank", "Data")
	_property("Employee", "bank_name", "insert_after", "karyo_bank_code", "Data")
	_property("Employee", "bank_name", "read_only", 1, "Check")
	_property("Employee", "bank_name", "hidden", 1, "Check")
	_property("Employee", "karyo_payroll_bank_branch", "insert_after", "bank_name", "Data")
	_property("Employee", "karyo_payroll_bank_branch", "label", "Primary Branch", "Data")
	_property("Employee", "karyo_branch_code", "insert_after", "karyo_payroll_bank_branch", "Data")
	# IFSC and MICR are India-specific ERP defaults and are not part of the
	# supplied Mauritius payroll bank catalogue.
	_property("Employee", "ifsc_code", "hidden", 1, "Check")
	_property("Employee", "micr_code", "hidden", 1, "Check")
	_property("Employee", "bank_ac_no", "insert_after", "karyo_branch_code", "Data")
	_property("Employee", "bank_ac_no", "label", "Primary Account Number", "Data")
	_property("Employee", "karyo_bank_account_holder_name", "insert_after", "bank_ac_no", "Data")
	_property("Employee", "karyo_bank_account_holder_name", "label", "Primary Account Holder", "Data")
	_property("Employee", "karyo_employee_bank_account_cb", "insert_after", "karyo_bank_account_holder_name", "Data")
	_property("Employee", "karyo_bank_account_is_primary", "insert_after", "karyo_employee_bank_account_cb", "Data")
	_property("Employee", "karyo_bank_account_effective_from", "insert_after", "karyo_bank_account_is_primary", "Data")
	_property("Employee", "karyo_bank_account_effective_to", "insert_after", "karyo_bank_account_effective_from", "Data")
	_property("Employee", "iban", "insert_after", "karyo_bank_account_effective_to", "Data")
	_property("Employee", "iban", "hidden", 1, "Check")
	_property("Employee", "karyo_bank_account_effective_from", "label", "Primary Account Effective From", "Data")
	_property("Employee", "karyo_bank_account_effective_to", "label", "Primary Account Effective To", "Data")
	_property("Employee", "karyo_secondary_bank_sb", "insert_after", "iban", "Data")
	_property("Employee", "karyo_secondary_bank_sb", "collapsible", 0, "Check")
	_property("Employee", "karyo_bank_routing_sb", "insert_after", "karyo_secondary_bank_effective_to", "Data")
	_property("Employee", "karyo_bank_routing_sb", "label", "Primary Bank and Branch Master Mapping", "Data")
	_property("Employee", "karyo_bank_swift_code", "insert_after", "karyo_bank_routing_sb", "Data")
	_property("Employee", "karyo_branch_name", "insert_after", "karyo_bank_routing_cb", "Data")
	_property("Employee", "karyo_cheque_details_sb", "insert_after", "karyo_bank_master_details", "Data")
	_property("Employee", "karyo_cheque_number", "insert_after", "karyo_cheque_details_sb", "Data")
	_property("Employee", "karyo_cash_details_sb", "insert_after", "karyo_cheque_reference", "Data")
	_property("Employee", "karyo_cash_receipt_number", "insert_after", "karyo_cash_details_sb", "Data")
	_property("Employee", "karyo_employee_payroll_tab", "insert_after", "karyo_cash_collection_point", "Data")
	_property("Employee", "karyo_salary_workspace_section", "insert_after", "karyo_employee_payroll_tab", "Data")
	for fieldname in ("karyo_hr_sb", "karyo_loan_eligibility_section"):
		_property("Employee", fieldname, "hidden", 1, "Check")
	_property("Employee", "karyo_payment_details_sb", "hidden", 0, "Check")
	for fieldname, mode in {
		"karyo_payroll_bank": "Bank", "karyo_payroll_bank_branch": "Bank", "bank_ac_no": "Bank",
	}.items():
		_property(
			"Employee", fieldname, "mandatory_depends_on",
			f"eval:doc.karyo_on_payroll && doc.salary_mode == '{mode}'", "Data",
		)
	for fieldname in (
		"karyo_cheque_details_sb", "karyo_cheque_number", "karyo_cheque_date",
		"karyo_cheque_bank", "karyo_cheque_reference", "karyo_cash_details_sb",
		"karyo_cash_receipt_number", "karyo_cash_reference", "karyo_cash_collection_point",
	):
		_property("Employee", fieldname, "hidden", 1, "Check")
		_property("Employee", fieldname, "mandatory_depends_on", "", "Data")
	for fieldname in (
		"karyo_bank_employee_code", "karyo_payroll_bank", "karyo_bank_code",
		"karyo_payroll_bank_branch", "karyo_branch_code", "bank_ac_no",
	):
		_property(
			"Employee", fieldname, "mandatory_depends_on",
			"eval:doc.salary_mode == 'Bank'", "Data",
		)
	# Department hierarchy remains available internally, but users create a
	# normal Department without an exposed Is Group checkbox.
	_property("Department", "is_group", "hidden", 1, "Check")
	# Passport identity fields no longer clutter Personal Details; the actual
	# passport attachment remains on Documents with the other issued letters.
	for fieldname in ("passport_details_section", "passport_number", "date_of_issue", "valid_upto", "place_of_issue"):
		_property("Employee", fieldname, "hidden", 1, "Check")
	for fieldname in ("documents", "adhaar"):
		_property("Employee", fieldname, "hidden", 1, "Check")
	_property("Employee", "held_on", "hidden", 1, "Check")
	_property("Employee", "new_workplace", "hidden", 1, "Check")
	_property("Employee Separation", "exit_interview", "hidden", 1, "Check")
	_property("Employee Separation", "boarding_status", "read_only", 0, "Check")
	_property("Employee Separation", "boarding_status", "options", "Pending\nIn Process\nCompleted", "Text")
	# Attendance and leave controls belong together on the native Attendance & Leaves tab.
	# The governed rate is a payroll result, so keep it next to Salary Calculation
	# instead of hiding it among the attendance selectors.
	_property("Employee", "karyo_work_pattern", "insert_after", "holiday_list", "Data")
	_property("Employee", "karyo_time_payroll_section", "insert_after", "karyo_salary_workspace", "Data")
	_property("Employee", "karyo_hourly_rate", "insert_after", "karyo_time_payroll_section", "Data")
	_property("Employee", "karyo_hourly_rate_calculation", "insert_after", "karyo_hourly_rate", "Data")
	_property("Employee", "karyo_time_payroll_linkage", "insert_after", "karyo_hourly_rate_calculation", "Data")
	_property("Employee", "default_shift", "insert_after", "karyo_work_pattern", "Data")
	if frappe.get_meta("Employee").has_field("karyo_shift_code"):
		_property("Employee", "karyo_shift_code", "insert_after", "default_shift", "Data")
		_property("Employee", "karyo_leave_scheme", "insert_after", "karyo_shift_code", "Data")
	else:
		_property("Employee", "karyo_leave_scheme", "insert_after", "default_shift", "Data")
	_property("Employee", "karyo_leave_scheme", "label", "Primary Leave Scheme", "Data")
	if frappe.get_meta("Employee").has_field("karyo_leave_schemes"):
		_property("Employee", "karyo_leave_schemes", "insert_after", "karyo_leave_scheme", "Data")
		_property("Employee", "karyo_leave_block_list", "insert_after", "karyo_leave_schemes", "Data")
	else:
		_property("Employee", "karyo_leave_block_list", "insert_after", "karyo_leave_scheme", "Data")
	_property("Employee", "attendance_device_id", "hidden", 1, "Check")
	# Loan eligibility is payroll configuration and belongs on the Payroll tab.
	_property("Employee", "karyo_loan_eligibility_section", "insert_after", "karyo_prb_pb_status", "Data")
	_property("Employee", "karyo_loan_eligibility_group", "insert_after", "karyo_loan_eligibility_section", "Data")
	_property("Employee", "karyo_loan_payroll_period", "insert_after", "karyo_loan_eligibility_group", "Data")
	_property("Employee", "karyo_payment_details_sb", "insert_after", "karyo_loan_payroll_period", "Data")
	# Education Level is governed by a small master instead of a hard-coded list.
	_property("Employee Education", "level", "options", "Education Level", "Text")
	_property("Employee Education", "level", "fieldtype", "Link", "Data")
	# Marital Status is governed by the legacy-code master instead of a hard-coded list.
	_property("Employee", "marital_status", "options", "Marital Status", "Text")
	_property("Employee", "marital_status", "fieldtype", "Link", "Data")
	# Previous work history keeps employment dates and a derived duration; salary is not captured here.
	_property("Employee External Work History", "salary", "hidden", 1, "Check")
	_property("Employee External Work History", "salary", "in_list_view", 0, "Check")
	_property("Employee External Work History", "address", "label", "Company Address")
	_property("Employee External Work History", "address", "insert_after", "company_name", "Data")
	_property("Employee External Work History", "designation", "insert_after", "address", "Data")
	_property("Employee External Work History", "total_experience", "insert_after", "karyo_to_date", "Data")
	_property("Employee External Work History", "total_experience", "read_only", 1, "Check")
	_property("Employee External Work History", "total_experience", "label", "Total Experience")
	for fieldname in ("company_name", "address", "designation", "total_experience"):
		_property("Employee External Work History", fieldname, "in_list_view", 1, "Check")
	_property("Company", "karyo_company_code", "read_only", 1, "Check")
	_property("Company", "hr_and_payroll_tab", "label", "Payroll")
	_property("Company", "hr_settings_section", "label", "Payroll Accounts")
	_property("Company", "default_bank_account", "label", "Payroll Bank Account")
	_property("Company", "default_payroll_payable_account", "label", "Payroll Payable Account")
	_property("Company", "default_expense_claim_payable_account", "label", "Expense Claim Payable Account")
	_property("Company", "default_employee_advance_account", "label", "Employee Advance Account")
	_property("Company", "default_bank_account", "insert_after", "karyo_company_payroll_accounts_cb", "Data")
	_property("Company", "default_payroll_payable_account", "insert_after", "default_bank_account", "Data")
	_property("Company", "default_expense_claim_payable_account", "insert_after", "default_payroll_payable_account", "Data")
	_property("Company", "default_employee_advance_account", "insert_after", "default_expense_claim_payable_account", "Data")
	_property("Shift Type", None, "search_fields", "karyo_shift_code", "Data")


def _normalized_code(value):
	return re.sub(r"[^A-Z0-9]+", "-", str(value or "").upper()).strip("-") or "CODE"


def _unique_code(doctype, fieldname, base, name):
	code = _normalized_code(base)[:120]
	candidate = code
	index = 2
	while frappe.db.exists(doctype, {fieldname: candidate, "name": ("!=", name)}):
		candidate = f"{code[:115]}-{index}"
		index += 1
	return candidate


def _attendance_default_values(company=None):
	patterns = frappe.get_all(
		"Employee Work Pattern", filters={"disabled": 0}, pluck="name", limit_page_length=2
	)
	policies = frappe.get_all(
		"Leave Policy", filters={"docstatus": 1}, pluck="name", order_by="modified desc", limit_page_length=2
	)
	block_filters = {"company": company} if company else {}
	blocks = frappe.get_all(
		"Leave Block List", filters=block_filters, pluck="name", order_by="modified desc", limit_page_length=2
	)
	return {
		"karyo_work_pattern": patterns[0] if len(patterns) == 1 else None,
		"karyo_leave_scheme": policies[0] if len(policies) == 1 else None,
		"karyo_leave_block_list": blocks[0] if len(blocks) == 1 else None,
	}


@frappe.whitelist()
@frappe.validate_and_sanitize_search_inputs
def attendance_master_query(doctype, txt, searchfield, start, page_len, filters):
	"""Populate every Attendance & Leaves selector from its governed master."""
	filters = frappe.parse_json(filters) if isinstance(filters, str) else (filters or {})
	fieldname = filters.get("employee_field")
	masters = {
		"holiday_list": ("Holiday List", {}, "holiday_list_name"),
		"karyo_work_pattern": ("Employee Work Pattern", {"disabled": 0}, "work_pattern_name"),
		"default_shift": ("Shift Type", {}, "karyo_shift_code"),
		"karyo_leave_scheme": ("Leave Policy", {"docstatus": 1}, "title"),
		"karyo_leave_block_list": ("Leave Block List", {}, "leave_block_list_name"),
	}
	if fieldname not in masters or doctype != masters[fieldname][0]:
		frappe.throw(_("Invalid attendance master query."), frappe.PermissionError)
	allowed = {"System Manager", "HR Manager", "HR User", "Payroll Manager", "Payroll User",
		"Payroll Processor", "Payroll Reviewer", "Payroll Approver", "Payroll Finance"}
	if frappe.session.user != "Administrator" and not allowed.intersection(frappe.get_roles()):
		frappe.throw(_("HR or Payroll access is required."), frappe.PermissionError)
	target, master_filters, label_field = masters[fieldname]
	master_filters = dict(master_filters)
	company = filters.get("company")
	if company and fieldname == "karyo_leave_block_list":
		master_filters["company"] = company
	or_filters = {}
	if txt:
		like = "%{0}%".format(txt)
		or_filters = {"name": ("like", like), label_field: ("like", like)}
	rows = frappe.get_all(
		target, filters=master_filters, or_filters=or_filters,
		fields=["name", label_field], order_by="name asc",
		limit_start=max(0, cint(start)), limit_page_length=min(cint(page_len) or 20, 100),
	)
	# The second column makes the source master visible in Frappe's Link menu:
	# users can search by either the stored key/code or the descriptive master name.
	return [[row.name, row.get(label_field) or row.name] for row in rows]


def _apply_employee_attendance_defaults(doc):
	for fieldname, value in _attendance_default_values(doc.get("company")).items():
		if value and not doc.get(fieldname):
			setattr(doc, fieldname, value)


def _backfill_employee_attendance_defaults():
	if not frappe.get_meta("Employee").has_field("karyo_leave_block_list"):
		return
	for employee in frappe.get_all(
		"Employee",
		fields=["name", "company", "karyo_work_pattern", "karyo_leave_scheme", "karyo_leave_block_list"],
		limit_page_length=0,
	):
		values = _attendance_default_values(employee.company)
		updates = {
			fieldname: value for fieldname, value in values.items()
			if value and not employee.get(fieldname)
		}
		if updates:
			frappe.db.set_value("Employee", employee.name, updates, update_modified=False)


def _backfill_leave_bank_counters():
	if frappe.get_meta("Sick Leave Bank").has_field("allotted_days"):
		from karyo.karyo.doctype.sick_leave_bank.sick_leave_bank import refresh_balance_counters
		for row in frappe.get_all("Sick Leave Bank", fields=["name", "employee"], limit_page_length=0):
			if row.employee and frappe.db.exists("Employee", row.employee):
				refresh_balance_counters(row.name)
	if frappe.get_meta("Vacation Leave Bank").has_field("allotted_days"):
		from karyo.karyo.doctype.vacation_leave_bank.vacation_leave_bank import refresh_balance_counters
		for row in frappe.get_all("Vacation Leave Bank", fields=["name", "employee"], limit_page_length=0):
			if row.employee and frappe.db.exists("Employee", row.employee):
				refresh_balance_counters(row.name)


def prepare_org_code(doc, method=None):
	if doc.doctype == "Department" and not doc.get("karyo_department_code"):
		company = frappe.db.get_value("Company", doc.company, "abbr") if doc.company else None
		doc.karyo_department_code = _unique_code(
			"Department", "karyo_department_code", f"{company or 'ORG'}-{doc.department_name}", doc.name
		)
	elif doc.doctype == "Designation" and not doc.get("karyo_job_code"):
		doc.karyo_job_code = _unique_code(
			"Designation", "karyo_job_code", doc.designation_name, doc.name
		)
	elif doc.doctype == "Shift Type" and not doc.get("karyo_shift_code"):
		doc.karyo_shift_code = _unique_code(
			"Shift Type", "karyo_shift_code", doc.name or "SHIFT", doc.name
		)


def prepare_employee_master(doc, method=None):
	_apply_employee_attendance_defaults(doc)
	_sync_employee_location_defaults(doc)
	# Employee onboarding is not operational until the mandatory employee-bound
	# payroll wizard succeeds. Preserve the generated Employee ID as an inactive
	# staging record so salary appointments can be bound atomically to that ID.
	is_new = callable(getattr(doc, "is_new", None)) and doc.is_new()
	meta = getattr(doc, "meta", None)
	if is_new and meta and meta.has_field("karyo_payroll_setup_pending_activation"):
		doc.karyo_payroll_setup_pending_activation = 1
		doc.status = "Inactive"
	if doc.get("salary_mode") and doc.salary_mode not in ("Bank", "Cheque", "Cash"):
		frappe.throw(_("Payment Mode must be Bank, Cheque or Cash."))
	if doc.get("salary_mode") == "Bank":
		doc.karyo_bank_employee_code = doc.get("employee") or doc.get("name")
		if not doc.get("karyo_bank_account_holder_name"):
			doc.karyo_bank_account_holder_name = doc.get("employee_name")
		if doc.get("karyo_bank_account_is_primary") is None:
			doc.karyo_bank_account_is_primary = 1
		if not doc.get("karyo_bank_account_effective_from"):
			doc.karyo_bank_account_effective_from = (
				doc.get("karyo_employment_start_date") or doc.get("date_of_joining") or nowdate()
			)
		if doc.get("karyo_bank_account_effective_to") and getdate(
			doc.karyo_bank_account_effective_to
		) < getdate(doc.karyo_bank_account_effective_from):
			frappe.throw(_("Bank Account Effective To cannot be before Effective From."))
	if not doc.get("karyo_national_id") and doc.get("passport_number"):
		doc.karyo_national_id = doc.passport_number
	if not doc.get("karyo_employment_start_date"):
		doc.karyo_employment_start_date = doc.date_of_joining
	if doc.get("karyo_work_pattern"):
		pattern = frappe.db.get_value(
			"Employee Work Pattern", doc.karyo_work_pattern, ["default_shift", "calendar_code"], as_dict=True
		)
		if pattern:
			# Work Pattern owns its mapped Shift and Calendar. Refresh configured
			# values so an older dependency cannot remain after the pattern changes.
			if pattern.default_shift:
				doc.default_shift = pattern.default_shift
			if pattern.calendar_code:
				doc.holiday_list = pattern.calendar_code
	if doc.get("karyo_section"):
		section = frappe.db.get_value(
			"Employee Section", doc.karyo_section, ["department", "company", "disabled"], as_dict=True
		)
		if not section or section.disabled:
			frappe.throw(_("Select an active Section Code."))
		if section.department != doc.department:
			frappe.throw(_("Section Code {0} does not belong to Department {1}.").format(
				doc.karyo_section, doc.department or _("(not selected)")
			))
		if section.company and doc.company and section.company != doc.company:
			frappe.throw(_("Section Code {0} does not belong to Company {1}.").format(
				doc.karyo_section, doc.company
			))
	if doc.get("karyo_on_payroll"):
		required = {
			"karyo_national_id": _("NIC / Passport"),
			"last_name": _("Surname"),
			"department": _("Department Code"),
			"karyo_location": _("Location / Site Code"),
			"designation": _("Post / Job Code"),
			"grade": _("Grade Code"),
			"karyo_salary_scale": _("Salary Scale Code"),
			"karyo_scale_salary_point": _("Salary Step / Point"),
			"karyo_scale_basic_salary": _("Basic Salary"),
			"karyo_payroll_group": _("Payroll Group"),
			"karyo_employment_start_date": _("Employment Start Date"),
			"salary_mode": _("Payment Mode"),
		}
		mode_required = {
			"Bank": {
				"karyo_payroll_bank": _("Payroll Bank"),
				"karyo_payroll_bank_branch": _("Payroll Bank Branch"),
				"bank_ac_no": _("Bank Account Number"),
			},
		}
		required.update(mode_required.get(doc.get("salary_mode"), {}))
		missing = [label for fieldname, label in required.items() if not doc.get(fieldname)]
		if missing:
			frappe.throw(_("Complete these payroll fields before enabling On Payroll: {0}.").format(", ".join(missing)))
	if doc.get("contract_end_date") and doc.get("karyo_employment_start_date"):
		if getdate(doc.contract_end_date) < getdate(doc.karyo_employment_start_date):
			frappe.throw(_("Employment End Date cannot be before Employment Start Date."))
	for row in doc.get("external_work_history") or []:
		_start, _end = row.get("karyo_from_date"), row.get("karyo_to_date")
		if not (_start and _end):
			row.total_experience = None
			continue
		_start, _end = getdate(_start), getdate(_end)
		if _end < _start:
			frappe.throw(_("Previous Work Experience row {0}: To Date cannot be before From Date.").format(row.idx))
		months = (_end.year - _start.year) * 12 + _end.month - _start.month
		if _end.day < _start.day:
			months -= 1
		years, remaining = divmod(max(months, 0), 12)
		parts = []
		if years:
			parts.append(_("{0} year(s)").format(years))
		parts.append(_("{0} month(s)").format(remaining))
		row.total_experience = " ".join(parts)


def _sync_employee_location_defaults(doc):
	"""Apply a Location master mapping without overwriting employee overrides."""
	location = doc.get("karyo_location")
	if not location:
		return
	from karyo.karyo.doctype.employee_location.employee_location import EMPLOYEE_MAPPING, location_context

	row = location_context(location)
	if not row:
		# Lightweight validation fixtures use frappe._dict values without a
		# DocType. Real Employee documents and imports must resolve the master.
		if doc.get("doctype") == "Employee":
			frappe.throw(_("Location / Site Code {0} does not exist.").format(location))
		return
	previous = doc.get_doc_before_save() if callable(getattr(doc, "get_doc_before_save", None)) else None
	location_changed = not previous or previous.get("karyo_location") != location
	if not row.is_active and location_changed:
		frappe.throw(_("Select an active Location / Site Code."))
	hierarchy_changed = not previous or any(
		previous.get(fieldname) != doc.get(fieldname)
		for fieldname in ("department", "karyo_section", "karyo_location")
	)
	if hierarchy_changed and (not row.department or not row.section):
		frappe.throw(_(
			"Location / Site Code {0} must be linked to a Department and Section before assignment."
		).format(location))

	old_row = location_context(previous.get("karyo_location")) if previous and location_changed else frappe._dict()
	for source, target in EMPLOYEE_MAPPING.items():
		mapped = row.get(source)
		if not mapped:
			continue
		current = doc.get(target)
		# New/blank employees inherit the Location mapping. When the Location
		# changes, replace the previous inherited value but preserve overrides.
		if not current or (location_changed and current == old_row.get(source)):
			doc.set(target, mapped)
	if hierarchy_changed and (
		doc.get("department") != row.department or doc.get("karyo_section") != row.section
	):
		frappe.throw(_(
			"Location / Site Code {0} does not belong to the selected Department and Section."
		).format(location))


def prepare_company_master(doc, method=None):
	if not doc.get("default_currency"):
		doc.default_currency = "MUR"
	if not doc.get("karyo_company_code") and doc.get("abbr"):
		doc.karyo_company_code = _unique_code("Company", "karyo_company_code", doc.abbr, doc.name)
	if doc.get("karyo_financial_year"):
		year = frappe.db.get_value(
			"Fiscal Year", doc.karyo_financial_year, ["year_start_date", "year_end_date"], as_dict=True
		)
		if year:
			doc.karyo_fin_start_date = year.year_start_date
			doc.karyo_fin_end_date = year.year_end_date
			doc.karyo_calendar_year = getdate(year.year_start_date).year
	if doc.get("karyo_payroll_bank_branch"):
		branch = frappe.db.get_value(
			"Payroll Bank Branch", doc.karyo_payroll_bank_branch, ["bank", "is_active"], as_dict=True
		)
		if not branch:
			frappe.throw(_("Select a valid Payroll Bank Branch."))
		if not branch.is_active:
			frappe.throw(_("Select an active Payroll Bank Branch."))
		if doc.get("karyo_payroll_bank") and doc.karyo_payroll_bank != branch.bank:
			frappe.throw(_("The selected Branch Name does not belong to Payroll Bank Name {0}.").format(
				doc.karyo_payroll_bank
			))
		doc.karyo_payroll_bank = branch.bank
	if doc.get("karyo_payroll_bank") and not frappe.db.get_value(
		"Bank", doc.karyo_payroll_bank, "karyo_payroll_active"
	):
		frappe.throw(_("Select a bank that is active for Payroll."))


def _backfill_reference_codes():
	for row in frappe.get_all("Department", fields=["name", "department_name", "company", "karyo_department_code"]):
		if row.karyo_department_code:
			continue
		company = frappe.db.get_value("Company", row.company, "abbr") if row.company else None
		code = _unique_code("Department", "karyo_department_code", f"{company or 'ORG'}-{row.department_name}", row.name)
		frappe.db.set_value("Department", row.name, "karyo_department_code", code, update_modified=False)
	for row in frappe.get_all("Designation", fields=["name", "designation_name", "karyo_job_code"]):
		if not row.karyo_job_code:
			code = _unique_code("Designation", "karyo_job_code", row.designation_name, row.name)
			frappe.db.set_value("Designation", row.name, "karyo_job_code", code, update_modified=False)
	for row in frappe.get_all("Shift Type", fields=["name", "karyo_shift_code"]):
		if not row.karyo_shift_code:
			code = _unique_code("Shift Type", "karyo_shift_code", row.name, row.name)
			frappe.db.set_value("Shift Type", row.name, "karyo_shift_code", code, update_modified=False)


def _current_fiscal_year():
	return frappe.db.get_value(
		"Fiscal Year",
		{"disabled": 0, "year_start_date": ("<=", nowdate()), "year_end_date": (">=", nowdate())},
		"name",
		order_by="year_start_date desc",
	)


def _backfill_company_profile():
	default_year = _current_fiscal_year()
	for row in frappe.get_all("Company", fields=["name", "abbr", "karyo_company_code", "karyo_financial_year"]):
		values = {}
		if not row.karyo_company_code:
			values["karyo_company_code"] = _unique_code("Company", "karyo_company_code", row.abbr or row.name, row.name)
		year_name = row.karyo_financial_year or default_year
		if year_name:
			year = frappe.db.get_value("Fiscal Year", year_name, ["year_start_date", "year_end_date"], as_dict=True)
			values.update({
				"karyo_financial_year": year_name,
				"karyo_fin_start_date": year.year_start_date,
				"karyo_fin_end_date": year.year_end_date,
				"karyo_calendar_year": getdate(year.year_start_date).year,
			})
		if values:
			frappe.db.set_value("Company", row.name, values, update_modified=False)


def _backfill_locations():
	for branch in frappe.get_all("Branch", fields=["name"]):
		location = frappe.db.get_value("Employee Location", {"location_name": branch.name}, "name")
		if not location:
			code = _unique_code("Employee Location", "location_code", branch.name, "")
			location = frappe.get_doc({
				"doctype": "Employee Location",
				"location_code": code,
				"location_name": branch.name,
			}).insert(ignore_permissions=True).name
		frappe.db.set_value(
			"Employee", {"branch": branch.name, "karyo_location": ("is", "not set")},
			"karyo_location", location, update_modified=False,
		)


def _backfill_employee_bank_routing():
	"""Materialize routing codes for existing links; master details remain live in the form."""
	for employee in frappe.get_all(
		"Employee", filters={"salary_mode": "Bank", "karyo_payroll_bank": ("is", "set")},
		fields=[
			"name", "employee_name", "date_of_joining", "karyo_employment_start_date",
			"karyo_payroll_bank", "karyo_payroll_bank_branch",
			"karyo_bank_account_holder_name", "karyo_bank_account_effective_from",
		], limit_page_length=0,
	):
		bank = frappe.db.get_value(
			"Bank", employee.karyo_payroll_bank,
			["karyo_bank_code", "swift_number", "karyo_bank_transfer_code", "karyo_bank_other_code"], as_dict=True,
		) or {}
		branch = frappe.db.get_value(
			"Payroll Bank Branch", employee.karyo_payroll_bank_branch,
			["branch_code", "branch_name", "transfer_code", "other_code", "is_active"], as_dict=True,
		) if employee.karyo_payroll_bank_branch else {}
		branch = branch or {}
		frappe.db.set_value("Employee", employee.name, {
			"karyo_bank_employee_code": employee.name,
			"karyo_bank_account_holder_name": employee.karyo_bank_account_holder_name or employee.employee_name,
			"karyo_bank_account_is_primary": 1,
			"karyo_bank_account_effective_from": employee.karyo_bank_account_effective_from
				or employee.karyo_employment_start_date or employee.date_of_joining or nowdate(),
			"bank_name": employee.karyo_payroll_bank,
			"karyo_bank_code": bank.get("karyo_bank_code"),
			"karyo_bank_swift_code": bank.get("swift_number"),
			"karyo_bank_transfer_code": bank.get("karyo_bank_transfer_code"),
			"karyo_bank_other_code": bank.get("karyo_bank_other_code"),
			"karyo_branch_code": branch.get("branch_code"),
			"karyo_branch_name": branch.get("branch_name"),
			"karyo_branch_transfer_code": branch.get("transfer_code"),
			"karyo_branch_other_code": branch.get("other_code"),
			"karyo_branch_active": branch.get("is_active"),
		}, update_modified=False)


def _secure_employee_documents():
	"""Move legacy public Employee document attachments into private storage."""
	document_fields = (
		"passport", "driving_licence", "offer_letter", "joining_letter",
		"karyo_other_letters", "documents", "adhaar",
	)
	files = frappe.get_all(
		"File",
		filters={
			"attached_to_doctype": "Employee",
			"attached_to_field": ("in", document_fields),
			"is_private": 0,
		},
		pluck="name",
	)
	for name in files:
		file_doc = frappe.get_doc("File", name)
		private_url = "/private/files/" + str(file_doc.file_url or "").rsplit("/", 1)[-1]
		private_filters = {"file_url": private_url, "is_private": 1}
		if file_doc.content_hash:
			private_filters["content_hash"] = file_doc.content_hash
		private_source = frappe.db.get_value("File", private_filters, "name")
		if private_source:
			# Frappe does not overwrite an existing private blob with the same name.
			# Reuse that identical private attachment and remove the public copy.
			if file_doc.attached_to_name and frappe.db.exists("Employee", file_doc.attached_to_name):
				source = frappe.get_doc("File", private_source)
				source.create_attachment_copy(
					"Employee", file_doc.attached_to_name, file_doc.attached_to_field,
					ignore_permissions=True,
				)
				frappe.db.set_value(
					"Employee", file_doc.attached_to_name, file_doc.attached_to_field,
					private_url, update_modified=False,
				)
			frappe.delete_doc("File", file_doc.name, ignore_permissions=True)
			continue
		file_doc.is_private = 1
		file_doc.save(ignore_permissions=True)


def capture_separation_employee_status(doc, method=None):
	"""Remember the pre-separation state before the process is approved."""
	if doc.get("employee"):
		doc.karyo_previous_employee_status = frappe.db.get_value("Employee", doc.employee, "status") or "Active"
		user = frappe.db.get_value("Employee", doc.employee, "user_id")
		doc.karyo_previous_user_enabled = cint(
			frappe.db.get_value("User", user, "enabled") if user and frappe.db.exists("User", user) else 0
		)


def deactivate_separated_employee(doc, method=None):
	"""Deactivate only at the irreversible Completed boundary."""
	if doc.get("boarding_status") != "Completed" or cint(doc.get("docstatus")) != 1:
		return
	if doc.get("employee") and frappe.db.exists("Employee", doc.employee):
		if not doc.get("karyo_previous_employee_status"):
			status = frappe.db.get_value("Employee", doc.employee, "status") or "Active"
			frappe.db.set_value(
				"Employee Separation", doc.name, "karyo_previous_employee_status", status,
				update_modified=False,
			)
		if not doc.get("karyo_previous_user_enabled"):
			user = frappe.db.get_value("Employee", doc.employee, "user_id")
			if user and frappe.db.exists("User", user):
				frappe.db.set_value(
					"Employee Separation", doc.name, "karyo_previous_user_enabled",
					cint(frappe.db.get_value("User", user, "enabled")), update_modified=False,
				)
		from karyo.hr.final_settlement import payment_window_active
		if payment_window_active(doc.employee):
			return
		values = {"status": "Inactive", "karyo_post_exit_payroll_enabled": 0, "karyo_post_exit_payroll_until": None}
		if doc.get("karyo_leaving_date"):
			values["relieving_date"] = doc.karyo_leaving_date
		frappe.db.set_value("Employee", doc.employee, values)
		frappe.get_doc("Employee", doc.employee).notify_update()
		from karyo.hr.lifecycle import disable_employee_user

		disable_employee_user(doc.employee)


def sync_separation_employee_status(doc, method=None):
	"""Apply the employee status only after the separation reaches Completed."""
	deactivate_separated_employee(doc)


def validate_separation_lifecycle(doc, method=None):
	"""A completed separation is final and cannot return to an earlier state."""
	if doc.is_new():
		return
	previous = doc.get_db_value("boarding_status")
	if previous == "Completed" and doc.get("boarding_status") != "Completed":
		frappe.throw(_("A completed Employee Separation is irreversible."))


def prevent_completed_separation_cancellation(doc, method=None):
	if doc.get("boarding_status") == "Completed":
		frappe.throw(_("A completed Employee Separation is irreversible and cannot be cancelled."))


def prevent_completed_separation_reactivation(doc, method=None):
	"""Allow ordinary edits in an authorized window; protect its authority fields."""
	if doc.is_new():
		return
	from karyo.hr.final_settlement import POST_EXIT_FIELDS, payment_window_active
	stored = frappe.db.get_value("Employee", doc.name, ["status", "relieving_date", *POST_EXIT_FIELDS], as_dict=True)
	service_action = getattr(doc.flags, "allow_post_exit_reactivation", False)
	if not service_action and any(
		(getdate(doc.get(field)) if doc.get(field) else None) != (getdate(stored.get(field)) if stored.get(field) else None)
		if field == "karyo_post_exit_payroll_until" else doc.get(field) != stored.get(field)
		for field in POST_EXIT_FIELDS):
		frappe.throw(_("Use the Post-Exit Payment Window actions to change payment authority."))
	completed = frappe.db.exists("Employee Separation",
		{"employee": doc.name, "docstatus": 1, "boarding_status": "Completed"})
	if not completed:
		return
	if doc.get("relieving_date") != stored.relieving_date:
		frappe.throw(_("The leaving date of a separated employee cannot be changed."))
	if doc.get("status") == "Inactive":
		return
	if payment_window_active(doc) and (service_action or payment_window_active(stored)):
		return
	frappe.throw(_(
		"Employee {0} has completed separation {1}. Use Open Post-Exit Payment Window with an approval reference for a temporary payroll-only reactivation."
	).format(doc.name, completed))


def sync_completed_separation_from_project(project, method=None):
	"""Finalize a separation when HRMS derives Completed from its project tasks."""
	separation = frappe.db.get_value(
		"Employee Separation", {"project": project.name, "docstatus": 1},
		["name", "employee", "boarding_status", "docstatus", "karyo_previous_employee_status",
		 "karyo_previous_user_enabled"], as_dict=True,
	)
	if separation:
		from karyo.hr.final_settlement import finalize_completed_separation, refresh_separation_snapshot

		if separation.boarding_status == "Completed":
			doc = finalize_completed_separation(separation.name)
			deactivate_separated_employee(doc)
		else:
			refresh_separation_snapshot(separation.name)


def restore_separated_employee(doc, method=None):
	# Completion is a final employment event. This branch is retained only for
	# pending/in-process cancellations created before completion.
	if doc.get("boarding_status") == "Completed":
		return
	if not doc.get("employee") or not frappe.db.exists("Employee", doc.employee):
		return
	other = frappe.db.exists(
		"Employee Separation", {"employee": doc.employee, "docstatus": 1, "name": ("!=", doc.name)}
	)
	if not other and frappe.db.get_value("Employee", doc.employee, "status") == "Inactive":
		frappe.db.set_value(
			"Employee", doc.employee, "status", doc.get("karyo_previous_employee_status") or "Active"
		)
		from karyo.hr.lifecycle import restore_employee_user

		restore_employee_user(doc.employee, doc.get("karyo_previous_user_enabled"))


def _backfill_approved_separations():
	if not frappe.db.table_exists("Employee Separation"):
		return
	for separation in frappe.get_all(
		"Employee Separation", filters={"docstatus": 1, "boarding_status": "Completed"},
		fields=[
			"name", "employee", "karyo_previous_employee_status",
			"karyo_previous_user_enabled",
		], limit_page_length=0,
	):
		if not separation.employee or not frappe.db.exists("Employee", separation.employee):
			continue
		status = frappe.db.get_value("Employee", separation.employee, "status") or "Active"
		if not separation.karyo_previous_employee_status:
			frappe.db.set_value(
				"Employee Separation", separation.name, "karyo_previous_employee_status", status,
				update_modified=False,
			)
		if status != "Inactive":
			frappe.db.set_value("Employee", separation.employee, "status", "Inactive", update_modified=False)
		user = frappe.db.get_value("Employee", separation.employee, "user_id")
		if not separation.karyo_previous_user_enabled and user and frappe.db.exists("User", user):
			frappe.db.set_value(
				"Employee Separation", separation.name, "karyo_previous_user_enabled",
				cint(frappe.db.get_value("User", user, "enabled")), update_modified=False,
			)
		from karyo.hr.lifecycle import disable_employee_user

		disable_employee_user(separation.employee)


def _repair_premature_pending_separations():
	"""Undo the former submit-time deactivation for unfinished separations."""
	if not frappe.db.table_exists("Employee Separation"):
		return
	for separation in frappe.get_all(
		"Employee Separation",
		filters={"docstatus": 1, "boarding_status": ("!=", "Completed")},
		fields=[
			"name", "employee", "karyo_previous_employee_status",
			"karyo_previous_user_enabled",
		],
		limit_page_length=0,
	):
		previous = separation.karyo_previous_employee_status
		if not separation.employee or not previous or previous == "Inactive":
			continue
		if frappe.db.exists(
			"Employee Separation",
			{"employee": separation.employee, "docstatus": 1, "boarding_status": "Completed"},
		):
			continue
		if frappe.db.get_value("Employee", separation.employee, "status") != "Inactive":
			continue
		frappe.db.set_value(
			"Employee", separation.employee, "status", previous, update_modified=False,
		)
		from karyo.hr.lifecycle import restore_employee_user

		restore_employee_user(separation.employee, separation.karyo_previous_user_enabled)
