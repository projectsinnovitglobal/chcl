"""Governed administrator entry for back-dated attendance and payroll inputs."""

from datetime import datetime, timedelta

import frappe
from frappe import _
from frappe.utils import add_days, date_diff, flt, get_datetime, get_time, getdate, now_datetime, nowdate

from karyo.hr.clocking import ADMIN_ROLES


ATTENDANCE_STATUSES = {"Present", "Half Day", "Absent", "Work From Home"}
ADDITIONAL_TYPES = {"Overtime", "Night Duty", "Excess Hours"}
BONUS_TYPES = {
	"Attendance Bonus": "attendancebonus",
	"Incentive Attendance Bonus": "incentiveattendancebonus",
	"PRB Attendance Bonuses": "presencebonus",
}
MAX_BULK_ATTENDANCE_DAYS = 366


def _require_admin():
	if not ADMIN_ROLES.intersection(frappe.get_roles()):
		frappe.throw(_("Only an HR administrator may record manual attendance or payroll inputs."), frappe.PermissionError)


def _employee(employee):
	row = frappe.db.get_value(
		"Employee",
		employee,
		["name", "employee_name", "company", "department", "default_shift", "holiday_list",
		 "karyo_employee_group", "karyo_work_pattern", "date_of_joining", "relieving_date"],
		as_dict=True,
	)
	if not row or frappe.db.get_value("Employee", employee, "status") != "Active":
		frappe.throw(_("Select an active Employee."))
	if not frappe.has_permission("Employee", "read", doc=employee, throw=False):
		frappe.throw(_("You do not have permission to access this employee."), frappe.PermissionError)
	return row


def _past_or_today(value):
	date = getdate(value)
	if date > getdate(nowdate()):
		frappe.throw(_("Manual actuals may be entered only for today or a past date."))
	return date


def _shift_window(employee, attendance_date, requested_shift=None):
	from karyo.hr.roster import current_duty, shift_context

	duty = current_duty(employee.name, attendance_date)
	if duty and requested_shift and requested_shift != duty.shift_type:
		frappe.throw(
			_("The selected Shift does not match the employee's dated duty {0}.").format(duty.shift_type)
		)
	shift_name = (duty.shift_type if duty else None) or requested_shift or employee.default_shift
	shift = shift_context(shift_name)
	start_time = duty.start_time if duty else shift.start_time
	end_time = duty.end_time if duty else shift.end_time
	if not shift_name or start_time is None or end_time is None:
		return frappe._dict(
			shift=shift_name, shift_code=None, start=None, end=None, duty_hours=0,
			roster_assignment=duty.assignment if duty else None,
			roster_schedule=duty.schedule if duty else None,
		)
	start = datetime.combine(attendance_date, get_time(start_time))
	end = datetime.combine(attendance_date, get_time(end_time))
	if end <= start:
		end += timedelta(days=1)
	return frappe._dict(
		shift=shift_name,
		shift_code=duty.shift_code if duty else shift.shift_code,
		start=start,
		end=end,
		duty_hours=flt(duty.duty_hours if duty else shift.duty_hours, 4),
		roster_assignment=duty.assignment if duty else None,
		roster_schedule=duty.schedule if duty else None,
	)


def _audit(reference):
	reference = str(reference or "").strip()
	if not reference:
		frappe.throw(_("Enter a Manual Input Reference explaining the source or approval."))
	if len(reference) > 1000:
		frappe.throw(_("Keep the Manual Input Reference within 1000 characters."))
	return {
		"custom_entry_source": "Manual Input",
		"custom_manual_reference": reference,
		"custom_manual_by": frappe.session.user,
		"custom_manual_on": now_datetime(),
	}


def _context_row(person, date, shift=None):
	window = _shift_window(person, date, shift)
	existing = frappe.db.get_value(
		"Attendance",
		{"employee": person.name, "attendance_date": date, "docstatus": ("!=", 2)},
		["name", "status", "shift", "in_time", "out_time", "working_hours"],
		as_dict=True,
	)
	assignment = None
	if window.roster_assignment:
		assignment = frappe.db.get_value(
			"Shift Assignment", window.roster_assignment,
			["name", "shift_schedule_assignment", "shift_location"], as_dict=True,
		)
	return {
		"attendance_date": date,
		"shift": window.shift,
		"shift_code": window.shift_code,
		"clock_in": window.start,
		"clock_out": window.end,
		"duty_hours": window.duty_hours,
		"roster_assignment": window.roster_assignment,
		"roster_schedule": window.roster_schedule,
		"shift_schedule_assignment": assignment.shift_schedule_assignment if assignment else None,
		"shift_location": assignment.shift_location if assignment else None,
		"existing_attendance": existing,
	}


def _approved_additional_hours(employee, attendance_date):
	"""Submitted rule results that must extend a manually-entered duty day."""
	return flt(frappe.db.sql(
		"""select coalesce(sum(approved_hours), 0)
		from `tabPRB Overtime Authorization`
		where employee=%s and docstatus=1 and authorization_status='Recorded'
			and date(actual_start)=%s""",
		(employee, attendance_date),
	)[0][0], 6)


@frappe.whitelist()
def manual_entry_context(employee, attendance_date=None, shift=None, from_date=None, to_date=None):
	"""Return assigned values and a dated preview for a manual attendance range."""
	_require_admin()
	person = _employee(employee)
	start = _past_or_today(from_date or attendance_date)
	end = _past_or_today(to_date or from_date or attendance_date)
	if end < start:
		frappe.throw(_("To Date cannot be before From Date."))
	if date_diff(end, start) + 1 > MAX_BULK_ATTENDANCE_DAYS:
		frappe.throw(_("Select a date range of up to {0} days.").format(MAX_BULK_ATTENDANCE_DAYS))
	rows = [_context_row(person, getdate(add_days(start, offset)), shift if start == end else None)
		for offset in range(date_diff(end, start) + 1)]
	first = rows[0]
	return {
		"employee_name": person.employee_name,
		"employee_group": person.karyo_employee_group,
		"work_pattern": person.karyo_work_pattern,
		"holiday_list": person.holiday_list,
		**first,
		"range_rows": rows,
	}


def _create_attendance(values, person, audit):
	date = _past_or_today(values.get("attendance_date"))
	status = str(values.get("status") or "Present").strip()
	if status not in ATTENDANCE_STATUSES:
		frappe.throw(_("Choose a valid Attendance Status."))
	existing = frappe.db.get_value(
		"Attendance", {"employee": person.name, "attendance_date": date, "docstatus": ("!=", 2)}, "name"
	)
	if existing:
		frappe.throw(
			_("Attendance {0} already exists for this employee and date. Use an Attendance Request for corrections.").format(existing)
		)
	window = _shift_window(person, date, values.get("shift"))
	working_status = status in {"Present", "Half Day", "Work From Home"}
	clock_in = get_datetime(values.get("clock_in") or window.start) if working_status else None
	clock_out = get_datetime(values.get("clock_out") or window.end) if working_status else None
	# When governed additional hours were entered before the base attendance,
	# extend the default shift end by the approved (not merely requested) amount.
	if working_status and not values.get("clock_out") and clock_out:
		clock_out += timedelta(hours=_approved_additional_hours(person.name, date))
	if working_status and (not clock_in or not clock_out):
		frappe.throw(_("The assigned Shift has no start/end time. Enter Clock In and Clock Out manually."))
	if clock_in and clock_out and clock_out <= clock_in:
		frappe.throw(_("Clock Out must be after Clock In."))
	hours = flt((clock_out - clock_in).total_seconds() / 3600, 4) if clock_in and clock_out else 0
	checkins = []
	for log_type, time in (("IN", clock_in), ("OUT", clock_out)):
		if not time:
			continue
		checkin = frappe.get_doc({
			"doctype": "Employee Checkin",
			"employee": person.name,
			"log_type": log_type,
			"time": time,
			"device_id": "Manual Input",
			"skip_auto_attendance": 1,
			"shift": window.shift,
			"shift_start": window.start,
			"shift_end": window.end,
			"custom_clock_note": audit["custom_manual_reference"],
			**audit,
		})
		checkin.insert(ignore_permissions=True)
		checkins.append(checkin.name)
	attendance_values = {
		"doctype": "Attendance",
		"employee": person.name,
		"attendance_date": date,
		"status": status,
		"company": person.company,
		"department": person.department,
		"shift": window.shift,
		"in_time": clock_in,
		"out_time": clock_out,
		"working_hours": hours,
		**audit,
	}
	if frappe.get_meta("Attendance").has_field("custom_attendance_remark"):
		attendance_values["custom_attendance_remark"] = "Manually Adjusted"
	attendance = frappe.get_doc(attendance_values)
	attendance.flags.ignore_permissions = True
	attendance.insert(ignore_permissions=True)
	attendance.submit()
	for name in checkins:
		frappe.db.set_value("Employee Checkin", name, "attendance", attendance.name, update_modified=False)
	return {
		"doctype": "Attendance", "name": attendance.name, "checkins": checkins,
		"shift": window.shift, "working_hours": hours, "status": status,
		"message": _("Manual Attendance {0} recorded with {1} working hours.").format(attendance.name, hours),
	}


def _create_attendance_range(values, person, audit):
	start = _past_or_today(values.get("from_date") or values.get("attendance_date"))
	end = _past_or_today(values.get("to_date") or start)
	if end < start:
		frappe.throw(_("To Date cannot be before From Date."))
	days = date_diff(end, start) + 1
	if days > MAX_BULK_ATTENDANCE_DAYS:
		frappe.throw(_("Select a date range of up to {0} days.").format(MAX_BULK_ATTENDANCE_DAYS))
	created, skipped = [], []
	for offset in range(days):
		date = getdate(add_days(start, offset))
		if person.date_of_joining and date < getdate(person.date_of_joining):
			skipped.append({"date": date, "reason": _("Before joining date")})
			continue
		if person.relieving_date and date > getdate(person.relieving_date):
			skipped.append({"date": date, "reason": _("After relieving date")})
			continue
		existing = frappe.db.get_value(
			"Attendance", {"employee": person.name, "attendance_date": date, "docstatus": ("!=", 2)}, "name"
		)
		if existing:
			skipped.append({"date": date, "reason": _("Attendance already exists"), "name": existing})
			continue
		day_values = frappe._dict(dict(values))
		day_values.attendance_date = date
		# A multi-day range resolves each dated roster independently. A single-day
		# entry may retain explicitly adjusted clock values from the dialog.
		if days > 1:
			day_values.shift = None
			day_values.clock_in = None
			day_values.clock_out = None
		created.append(_create_attendance(day_values, person, audit))
	return {
		"doctype": "Attendance",
		"created": created,
		"skipped": skipped,
		"target_route": "/app/attendance",
		"target_label": _("Attendance Register"),
		"message": _("Manual attendance recorded for {0} day(s); {1} day(s) skipped.").format(
			len(created), len(skipped)
		),
	}


def _editable_attendance(name):
	"""Return one active Attendance that an HR administrator may correct."""
	_require_admin()
	doc = frappe.get_doc("Attendance", name)
	if doc.docstatus == 2:
		frappe.throw(_("A cancelled Attendance record cannot be changed."))
	if not frappe.has_permission("Attendance", "read", doc=doc, throw=False):
		frappe.throw(_("You do not have permission to access this Attendance record."), frappe.PermissionError)
	return doc


def _manual_attendance(name):
	"""Return one manual Attendance for destructive actions such as deletion."""
	doc = _editable_attendance(name)
	if doc.get("custom_entry_source") != "Manual Input":
		frappe.throw(_("Only Attendance records created through Manual Input can be deleted here."))
	return doc


@frappe.whitelist()
def manual_attendance_rows(limit=500):
	"""Audited manual Attendance register used below Employee Checkins."""
	_require_admin()
	limit = max(1, min(int(limit or 500), 500))
	rows = frappe.get_list(
		"Attendance",
		filters={"custom_entry_source": "Manual Input", "docstatus": ("!=", 2)},
		fields=[
			"name", "employee", "employee_name", "attendance_date", "status", "shift",
			"in_time", "out_time", "working_hours", "custom_attendance_remark",
			"custom_manual_reference", "custom_manual_by", "custom_manual_on", "modified",
		],
		order_by="attendance_date desc, modified desc, name desc",
		limit_page_length=limit,
	)
	if rows:
		from karyo.hr.clocking import (
			_additional_hours_by_employee_date,
			_attendance_bonuses_by_employee_date,
			_complete_total_hours,
			_empty_additional_hours,
			_empty_attendance_bonuses,
		)
		from karyo.hr.roster import shift_context

		additional = _additional_hours_by_employee_date(rows)
		bonuses = _attendance_bonuses_by_employee_date(rows)
		shift_hours = {}
		for row in rows:
			key = (row.employee, getdate(row.attendance_date))
			row.update(additional.get(key, _empty_additional_hours()))
			row.update(bonuses.get(key, _empty_attendance_bonuses()))
			if row.shift not in shift_hours:
				shift_hours[row.shift] = shift_context(row.shift).duty_hours if row.shift else None
			row.duty_hours = shift_hours[row.shift] if shift_hours[row.shift] is not None else row.working_hours
			row.total_hours = _complete_total_hours(row)
	return {"rows": rows, "total": frappe.db.count("Attendance", {
		"custom_entry_source": "Manual Input", "docstatus": ("!=", 2),
	})}


@frappe.whitelist()
def attendance_edit_detail(name):
	"""Authoritative values for the shared Attendance and payroll-input editor."""
	doc = _editable_attendance(name)
	additional_inputs = {}
	for row in frappe.db.sql(
		"""select name, claim_type, actual_start, actual_end, claimed_hours, approved_hours,
			overtime_period, urgent_unpostponable, equivalent_time_off_unavailable,
			lying_in_hours, excess_hours_basis, custom_manual_reference
		from `tabPRB Overtime Authorization`
		where employee=%s and docstatus=1
			and date(actual_start)=%s
		order by modified desc""",
		(doc.employee, doc.attendance_date), as_dict=True,
	):
		additional_inputs.setdefault(row.claim_type, row)
	bonus_inputs = {}
	runs = frappe.get_all(
		"PRB Payroll Run",
		filters={
			"employee": doc.employee, "docstatus": 0,
			"calculation_date": doc.attendance_date,
		},
		fields=["name", "run_purpose", "payroll_cycle", "custom_manual_reference"],
		order_by="modified desc", limit_page_length=50,
	)
	for row in runs:
		if row.run_purpose in bonus_inputs:
			continue
		run = frappe.get_doc("PRB Payroll Run", row.name)
		bonus_inputs[row.run_purpose] = {
			**row,
			"base_amounts": {item.input_code: item.amount for item in run.get("employee_inputs") or []},
		}
	return {
		"name": doc.name,
		"employee": doc.employee,
		"employee_name": doc.employee_name,
		"attendance_date": doc.attendance_date,
		"status": doc.status,
		"shift": doc.shift,
		"clock_in": doc.in_time,
		"clock_out": doc.out_time,
		"working_hours": doc.working_hours,
		"work_pattern": doc.get("karyo_work_pattern"),
		"roster_schedule": doc.get("karyo_roster_schedule"),
		"manual_reference": doc.get("custom_manual_reference"),
		"entry_source": doc.get("custom_entry_source"),
		"remark": doc.get("custom_attendance_remark"),
		"additional_inputs": additional_inputs,
		"bonus_inputs": bonus_inputs,
	}


@frappe.whitelist()
def manual_attendance_detail(name):
	"""Backward-compatible alias for callers using the former manual-only API."""
	return attendance_edit_detail(name)


def _replace_manual_checkins(attendance, person, clock_in, clock_out, audit, window):
	"""Synchronize the authoritative IN/OUT punches without duplicating ESS rows."""
	linked = frappe.get_all(
		"Employee Checkin",
		filters={"attendance": attendance.name},
		fields=["name", "log_type", "time", "custom_entry_source"],
		order_by="time asc",
		limit_page_length=100,
	)
	created = []
	for log_type, time in (("IN", clock_in), ("OUT", clock_out)):
		if not time:
			continue
		candidates = [row for row in linked if row.log_type == log_type]
		target = (candidates[0] if log_type == "IN" else candidates[-1]) if candidates else None
		if target:
			frappe.db.set_value("Employee Checkin", target.name, {
				"time": time, "device_id": "Manual Adjustment", "skip_auto_attendance": 1,
				"shift": window.shift, "shift_start": window.start, "shift_end": window.end,
				"custom_clock_note": audit["custom_manual_reference"], **audit,
			}, update_modified=True)
			created.append(target.name)
			continue
		checkin = frappe.get_doc({
			"doctype": "Employee Checkin", "employee": person.name, "log_type": log_type,
			"time": time, "device_id": "Manual Adjustment", "skip_auto_attendance": 1,
			"shift": window.shift, "shift_start": window.start, "shift_end": window.end,
			"custom_clock_note": audit["custom_manual_reference"], **audit,
		})
		checkin.insert(ignore_permissions=True)
		frappe.db.set_value("Employee Checkin", checkin.name, "attendance", attendance.name, update_modified=False)
		created.append(checkin.name)
	return created


@frappe.whitelist(methods=["POST"])
def update_manual_attendance(name, status, clock_in=None, clock_out=None, manual_reference=None,
	employee=None, attendance_date=None, shift=None):
	"""Governed edit that synchronizes Attendance and its linked clock punches."""
	doc = _editable_attendance(name)
	status = str(status or "").strip()
	if status not in ATTENDANCE_STATUSES:
		frappe.throw(_("Choose a valid Attendance Status."))
	person = _employee(employee or doc.employee)
	date = _past_or_today(attendance_date or doc.attendance_date)
	existing = frappe.db.get_value(
		"Attendance",
		{
			"name": ("!=", doc.name), "employee": person.name,
			"attendance_date": date, "docstatus": ("!=", 2),
		},
		"name",
	)
	if existing:
		frappe.throw(_("Attendance {0} already exists for this employee and date.").format(existing))
	audit = _audit(manual_reference or doc.get("custom_manual_reference"))
	working = status in {"Present", "Half Day", "Work From Home"}
	in_value = get_datetime(clock_in) if working and clock_in else None
	out_value = get_datetime(clock_out) if working and clock_out else None
	if working and (not in_value or not out_value):
		frappe.throw(_("Clock In and Clock Out are required for a working Attendance status."))
	if in_value and out_value and out_value <= in_value:
		frappe.throw(_("Clock Out must be after Clock In."))
	if in_value and getdate(in_value) != date:
		frappe.throw(_("Clock In must fall on the selected Attendance Date."))
	window = _shift_window(person, date, shift or None)
	hours = flt((out_value - in_value).total_seconds() / 3600, 4) if in_value and out_value else 0
	checkins = _replace_manual_checkins(doc, person, in_value, out_value, audit, window)
	values = {
		"employee": person.name,
		"employee_name": person.employee_name,
		"attendance_date": date,
		"company": person.company,
		"department": person.department,
		"status": status,
		"shift": window.shift,
		"in_time": in_value,
		"out_time": out_value,
		"working_hours": hours,
		"custom_attendance_remark": "Manually Adjusted",
		**audit,
	}
	meta = frappe.get_meta("Attendance")
	for fieldname, value in {
		"karyo_shift_code": window.shift_code,
		"karyo_roster_assignment": window.roster_assignment,
		"karyo_roster_schedule": window.roster_schedule,
		"karyo_work_pattern": person.karyo_work_pattern,
	}.items():
		if meta.has_field(fieldname):
			values[fieldname] = value
	frappe.db.set_value("Attendance", doc.name, values, update_modified=True)
	frappe.publish_realtime(
		"karyo_clock_updated", {"employee": person.name, "attendance": doc.name}, after_commit=True
	)
	return {
		"name": doc.name, "checkins": checkins, "working_hours": hours,
		"message": _("Attendance {0} was manually adjusted and synchronized everywhere.").format(doc.name),
	}


@frappe.whitelist(methods=["POST"])
def delete_manual_attendance(name):
	"""Delete only an audited manual Attendance and its linked manual punches."""
	doc = _manual_attendance(name)
	employee = doc.employee
	doc.flags.ignore_permissions = True
	if doc.docstatus == 1:
		doc.cancel()
	linked = frappe.get_all(
		"Employee Checkin",
		filters={"attendance": doc.name, "custom_entry_source": "Manual Input"},
		pluck="name",
		limit_page_length=100,
	)
	for checkin in linked:
		frappe.delete_doc("Employee Checkin", checkin, ignore_permissions=True, force=True)
	frappe.delete_doc("Attendance", doc.name, ignore_permissions=True, force=True)
	return {
		"name": name, "employee": employee,
		"message": _("Manual Attendance {0} and its linked manual check-ins were deleted.").format(name),
	}


def _default_rate_period(claim_type, start):
	if claim_type == "Night Duty":
		return "weekday_night"
	if get_datetime(start).weekday() == 6:
		return "sunday"
	return "weekday_night" if get_datetime(start).hour >= 23 else "weekday_day"


def _additional_scenario(values, person, claim_type):
	"""Build the exact governed rule scenario used by preview and save."""
	from karyo.karyo.doctype.prb_overtime_authorization.prb_overtime_authorization import attendance_context

	date = _past_or_today(values.get("attendance_date") or values.get("clock_in"))
	window = _shift_window(person, date)
	attendance = frappe.db.get_value(
		"Attendance",
		{"employee": person.name, "attendance_date": date, "docstatus": 1},
		["name", "in_time", "out_time", "working_hours", "shift"],
		as_dict=True,
	)
	requested = flt(values.get("requested_hours"), 6)
	start = get_datetime(values.get("clock_in") or (attendance and attendance.out_time) or window.end)
	end = get_datetime(values.get("clock_out")) if values.get("clock_out") else None
	if requested <= 0 and start and end:
		requested = flt((end - start).total_seconds() / 3600, 6)
	if requested <= 0:
		frappe.throw(_("Enter requested hours greater than zero."))
	if not start:
		frappe.throw(_("The assigned Shift has no end time. Enter Work Start manually."))
	end = start + timedelta(hours=requested)
	context = frappe._dict(attendance_context(person.name, start, 1))
	base_hours = flt(attendance.working_hours if attendance else window.duty_hours, 6)
	# Attendance context already includes a submitted base Attendance. When it
	# does not yet exist, include this dated shift in the projected weekly total.
	period_actual = flt(context.total_actual_hours, 6)
	if not attendance:
		period_actual += base_hours
	return frappe._dict(
		date=date, window=window, attendance=attendance, requested_hours=requested,
		start=start, end=end, base_hours=base_hours, context=context,
		projected_total_hours=period_actual + requested,
	)


def _scenario_doc(values, person, claim_type, scenario, audit=None):
	doc = frappe.get_doc({
		"doctype": "PRB Overtime Authorization",
		"employee": person.name,
		"claim_type": claim_type,
		"planned_start": scenario.start,
		"planned_end": scenario.end,
		"period_weeks": 1,
		"overtime_period": values.get("overtime_period") or _default_rate_period(claim_type, scenario.start),
		"authority_reference": (audit or {}).get("custom_manual_reference") or _("Manual rule preview"),
		"outside_normal_schedule": 1,
		"unavoidable_service_need": 1 if claim_type == "Overtime" else 0,
		"urgent_unpostponable": int(bool(values.get("urgent_unpostponable"))),
		"equivalent_time_off_unavailable": 1 if claim_type == "Excess Hours" else int(bool(values.get("equivalent_time_off_unavailable"))),
		"excess_hours_basis": values.get("excess_hours_basis") or "Week",
		"lying_in_hours": flt(values.get("lying_in_hours")),
		**(audit or {}),
	})
	return doc


def _calculate_scenario(doc, scenario):
	doc.flags.karyo_manual_backdate = True
	doc._set_employee_context()
	doc._set_planned_hours()
	doc.actual_start = scenario.start
	doc.actual_end = scenario.end
	doc.claimed_hours = scenario.requested_hours
	doc.total_actual_hours = scenario.projected_total_hours
	doc.deemed_worked_hours = scenario.context.deemed_worked_hours
	doc.deemed_hours_reference = scenario.context.deemed_hours_reference
	doc.days_worked = max(int(scenario.context.days_worked or 0), 1)
	doc._set_actual_result()
	doc._set_calculation_explanation()
	return doc


@frappe.whitelist()
def manual_additional_hours_context(employee, attendance_date, entry_type, requested_hours,
	overtime_period=None, urgent_unpostponable=0, equivalent_time_off_unavailable=0,
	lying_in_hours=0, excess_hours_basis="Week", replace_existing=0, authorization_name=None):
	"""Read-only rule preview for the manual additional-hours box."""
	_require_admin()
	if entry_type not in ADDITIONAL_TYPES:
		frappe.throw(_("Choose Overtime, Night Duty or Excess Hours."))
	person = _employee(employee)
	values = frappe._dict(locals())
	scenario = _additional_scenario(values, person, entry_type)
	if int(replace_existing or 0):
		existing = _editable_additional(
			authorization_name, person.name, scenario.date, entry_type
		) if authorization_name else _existing_manual_additional(person.name, scenario.date, entry_type)
		if existing and scenario.attendance:
			old_approved = flt(existing.approved_hours, 6)
			scenario.base_hours = max(flt(scenario.base_hours, 6) - old_approved, 0)
			scenario.projected_total_hours = max(flt(scenario.projected_total_hours, 6) - old_approved, 0)
	doc = _calculate_scenario(_scenario_doc(values, person, entry_type, scenario), scenario)
	return {
		"employee_name": person.employee_name,
		"employee_group": person.karyo_employee_group,
		"work_pattern": person.karyo_work_pattern,
		"shift": scenario.window.shift,
		"shift_code": scenario.window.shift_code,
		"roster_schedule": scenario.window.roster_schedule,
		"clock_in": scenario.start,
		"clock_out": scenario.end,
		"base_hours": scenario.base_hours,
		"requested_hours": scenario.requested_hours,
		"eligible_hours": flt(doc.approved_hours, 6),
		"projected_total_hours": flt(scenario.base_hours + flt(doc.approved_hours), 6),
		"eligibility_reason": doc.eligibility_reason,
		"calculation_explanation": doc.calculation_explanation,
		"attendance": scenario.attendance.name if scenario.attendance else None,
	}


def _extend_attendance_for_additional_hours(person, scenario, approved_hours, audit):
	"""Extend Clock Out/Total Hours while keeping the approved hours in their own columns."""
	approved = flt(approved_hours, 6)
	attendance = scenario.attendance
	if not attendance or approved <= 0:
		return None
	base_out = get_datetime(attendance.out_time or scenario.window.end)
	if not base_out:
		return None
	extended_out = base_out + timedelta(hours=approved)
	checkin = frappe.get_doc({
		"doctype": "Employee Checkin", "employee": person.name, "log_type": "OUT",
		"time": extended_out, "device_id": "Manual Input", "skip_auto_attendance": 1,
		"shift": attendance.shift or scenario.window.shift,
		"shift_start": scenario.window.start, "shift_end": scenario.window.end,
		"custom_clock_note": audit["custom_manual_reference"], **audit,
	})
	checkin.insert(ignore_permissions=True)
	frappe.db.set_value("Employee Checkin", checkin.name, "attendance", attendance.name, update_modified=False)
	working_hours = flt(scenario.base_hours + approved, 4)
	frappe.db.set_value("Attendance", attendance.name, {
		"out_time": extended_out,
		"working_hours": working_hours,
		"custom_attendance_remark": "Manually Adjusted",
	}, update_modified=True)
	return {"attendance": attendance.name, "clock_out": extended_out, "working_hours": working_hours,
		"checkin": checkin.name}


def _create_additional_hours(values, person, audit, claim_type):
	scenario = _additional_scenario(values, person, claim_type)
	doc = _scenario_doc(values, person, claim_type, scenario, audit)
	doc.insert(ignore_permissions=True)
	doc.flags.ignore_permissions = True
	doc.flags.karyo_manual_backdate = True
	doc.submit()
	doc.actual_start = scenario.start
	doc.actual_end = scenario.end
	doc.claimed_hours = scenario.requested_hours
	doc.total_actual_hours = scenario.projected_total_hours
	doc.deemed_worked_hours = scenario.context.deemed_worked_hours
	doc.deemed_hours_reference = scenario.context.deemed_hours_reference
	doc.days_worked = max(int(scenario.context.days_worked or 0), 1)
	doc.flags.ignore_permissions = True
	doc.flags.karyo_manual_backdate = True
	doc.save()
	attendance_result = _extend_attendance_for_additional_hours(person, scenario, doc.approved_hours, audit)
	return {
		"doctype": doc.doctype, "name": doc.name, "status": doc.authorization_status,
		"approved_hours": doc.approved_hours, "eligibility": doc.eligibility_reason,
		"attendance": attendance_result,
		"target_route": "/app/prb-overtime-authorization",
		"target_label": _("Overtime / Night Duty Records"),
		"message": _("Manual {0} {1} recorded. Payroll approval remains governed by the calculated eligibility result.").format(claim_type, doc.name),
	}


def _existing_manual_additional(employee, attendance_date, claim_type):
	rows = frappe.get_all(
		"PRB Overtime Authorization",
		filters={
			"employee": employee, "claim_type": claim_type, "docstatus": 1,
			"custom_entry_source": "Manual Input",
		},
		fields=["name", "approved_hours", "actual_start", "actual_end", "custom_manual_reference"],
		order_by="modified desc", limit_page_length=100,
	)
	date = getdate(attendance_date)
	return next((row for row in rows if getdate(row.actual_start) == date), None)


def _editable_additional(name, employee, attendance_date, claim_type):
	row = frappe.db.get_value(
		"PRB Overtime Authorization", name,
		["name", "employee", "claim_type", "docstatus", "approved_hours", "actual_start", "actual_end",
		 "custom_manual_reference"], as_dict=True,
	)
	if not row or row.docstatus != 1 or row.employee != employee or row.claim_type != claim_type \
		or getdate(row.actual_start) != getdate(attendance_date):
		frappe.throw(_("The linked additional-hours record no longer matches this Attendance."))
	return row


def _upsert_additional_hours(values, person, audit, claim_type):
	"""Update one dated manual claim without accumulating the previous hours twice."""
	date = _past_or_today(values.get("attendance_date") or values.get("clock_in"))
	existing = (
		_editable_additional(values.get("authorization_name"), person.name, date, claim_type)
		if values.get("authorization_name") else
		_existing_manual_additional(person.name, date, claim_type)
	)
	if not existing:
		return _create_additional_hours(values, person, audit, claim_type)
	scenario = _additional_scenario(values, person, claim_type)
	old_approved = flt(existing.approved_hours, 6)
	if scenario.attendance:
		scenario.base_hours = max(flt(scenario.attendance.working_hours, 6) - old_approved, 0)
		scenario.projected_total_hours = max(flt(scenario.projected_total_hours, 6) - old_approved, 0)
	calculated = _calculate_scenario(_scenario_doc(values, person, claim_type, scenario, audit), scenario)
	new_approved = flt(calculated.approved_hours, 6)
	frappe.db.set_value("PRB Overtime Authorization", existing.name, {
		"planned_start": scenario.start,
		"planned_end": scenario.end,
		"planned_hours": scenario.requested_hours,
		"actual_start": scenario.start,
		"actual_end": scenario.end,
		"actual_hours": calculated.actual_hours,
		"claimed_hours": scenario.requested_hours,
		"approved_hours": new_approved,
		"total_actual_hours": calculated.total_actual_hours,
		"deemed_worked_hours": calculated.deemed_worked_hours,
		"deemed_hours_reference": calculated.deemed_hours_reference,
		"days_worked": calculated.days_worked,
		"overtime_period": calculated.overtime_period,
		"lying_in_hours": calculated.lying_in_hours,
		"equivalent_time_off_unavailable": calculated.equivalent_time_off_unavailable,
		"excess_hours_basis": calculated.excess_hours_basis,
		"authorization_status": calculated.authorization_status,
		"eligibility_reason": calculated.eligibility_reason,
		"calculation_explanation": calculated.calculation_explanation,
		"authority_reference": audit["custom_manual_reference"],
		**audit,
	}, update_modified=True)
	attendance_result = None
	if scenario.attendance:
		attendance = scenario.attendance
		current_out = get_datetime(attendance.out_time or scenario.window.end)
		new_out = current_out + timedelta(hours=new_approved - old_approved)
		new_hours = flt(scenario.base_hours + new_approved, 4)
		old_checkins = frappe.get_all(
			"Employee Checkin",
			filters={
				"attendance": attendance.name, "log_type": "OUT",
				"custom_entry_source": "Manual Input",
				"custom_manual_reference": existing.custom_manual_reference,
			},
			pluck="name", limit_page_length=20,
		)
		for name in old_checkins:
			frappe.delete_doc("Employee Checkin", name, ignore_permissions=True, force=True)
		checkin_name = frappe.db.get_value(
			"Employee Checkin", {"employee": person.name, "time": new_out}, "name"
		)
		if not checkin_name:
			checkin = frappe.get_doc({
				"doctype": "Employee Checkin", "employee": person.name, "log_type": "OUT",
				"time": new_out, "device_id": "Manual Input", "skip_auto_attendance": 1,
				"shift": attendance.shift or scenario.window.shift,
				"shift_start": scenario.window.start, "shift_end": scenario.window.end,
				"custom_clock_note": audit["custom_manual_reference"], **audit,
			})
			checkin.insert(ignore_permissions=True)
			checkin_name = checkin.name
			frappe.db.set_value("Employee Checkin", checkin_name, "attendance", attendance.name, update_modified=False)
		frappe.db.set_value("Attendance", attendance.name, {
			"out_time": new_out, "working_hours": new_hours,
			"custom_attendance_remark": "Manually Adjusted",
		}, update_modified=True)
		attendance_result = {
			"attendance": attendance.name, "clock_out": new_out,
			"working_hours": new_hours, "checkin": checkin_name,
		}
	return {
		"doctype": "PRB Overtime Authorization", "name": existing.name,
		"status": calculated.authorization_status, "approved_hours": new_approved,
		"eligibility": calculated.eligibility_reason, "attendance": attendance_result,
		"target_route": "/app/prb-overtime-authorization",
		"target_label": _("Overtime / Night Duty Records"),
		"message": _("Manual {0} {1} was updated using the current eligibility rule.").format(
			claim_type, existing.name
		),
	}


def _bonus_context(person, cycle, entry_type, values=None):
	from karyo.payroll.attendance_bonus import configured_bonus_base, presence_leave_units
	from karyo.payroll.screen_specs import SCREENS
	from karyo.prb.allowances import attendance_bonus

	screen = BONUS_TYPES[entry_type]
	breakdown = presence_leave_units(person.name, cycle.start_date, cycle.end_date)
	leaves = breakdown.total
	values = frappe._dict(values or {})
	manual_bases = {
		"ATTENDANCE_BONUS": values.get("attendance_bonus_base"),
		"INCENTIVE_ATTENDANCE": values.get("incentive_attendance_bonus_base"),
	}
	items = []
	for row in SCREENS[screen]["bonus_inputs"]:
		manual_base = manual_bases.get(row["input_code"])
		base = flt(manual_base) if flt(manual_base) > 0 else configured_bonus_base(row["input_code"])
		amount = attendance_bonus(leaves, base)
		items.append({**row, "base": base, "amount": amount})
	total = flt(sum(item["amount"] for item in items), 2)
	eligible = total > 0
	return frappe._dict(
		screen=screen, leave_units=leaves, leave_breakdown=breakdown, items=items, total=total, eligible=eligible,
		status=_("Eligible") if eligible else _("Not Eligible"),
		reason=(
			_("Attendance and approved leave give {0} unique absence unit(s); the configured rule produces a payable bonus.").format(leaves)
			if eligible else
			_("Attendance and approved leave give {0} unique absence unit(s); the configured attendance-bonus rule produces zero payable bonus.").format(leaves)
		),
	)


@frappe.whitelist()
def manual_bonus_context(employee, payroll_cycle, entry_type, attendance_bonus_base=None,
	incentive_attendance_bonus_base=None):
	"""Read-only attendance-bonus eligibility preview using the saved payroll rule."""
	_require_admin()
	if entry_type not in BONUS_TYPES:
		frappe.throw(_("Choose an Attendance Bonus type."))
	person = _employee(employee)
	cycle = frappe.db.get_value(
		"Payroll Cycle", payroll_cycle,
		["name", "company", "start_date", "end_date", "payment_date", "docstatus"], as_dict=True,
	)
	if not cycle or cycle.docstatus == 2:
		frappe.throw(_("Select an available Payroll Cycle."))
	if cycle.company and cycle.company != person.company:
		frappe.throw(_("The Payroll Cycle company does not match the employee company."))
	result = _bonus_context(person, cycle, entry_type, {
		"attendance_bonus_base": attendance_bonus_base,
		"incentive_attendance_bonus_base": incentive_attendance_bonus_base,
	})
	return {
		"employee_name": person.employee_name, "employee_group": person.karyo_employee_group,
		"work_pattern": person.karyo_work_pattern, "payroll_cycle": cycle.name,
		"period_start": cycle.start_date, "period_end": cycle.end_date,
		"leave_units": result.leave_units, "items": result["items"], "total": result.total,
		"leave_breakdown": result.leave_breakdown,
		"eligible": result.eligible, "eligibility_status": result.status,
		"eligibility_reason": result.reason,
	}


def _create_bonus(values, person, audit, entry_type, existing_name=None):
	from karyo.desk.payroll_drawer import record_save
	from karyo.payroll.screen_specs import SCREENS

	cycle_name = values.get("payroll_cycle")
	cycle = frappe.db.get_value(
		"Payroll Cycle", cycle_name,
		["name", "company", "payroll_period", "payment_date", "start_date", "end_date", "docstatus"],
		as_dict=True,
	)
	if not cycle or cycle.docstatus == 2:
		frappe.throw(_("Select an available Payroll Cycle."))
	if cycle.company and cycle.company != person.company:
		frappe.throw(_("The Payroll Cycle company does not match the employee company."))
	eligibility = _bonus_context(person, frappe._dict(cycle), entry_type, values)
	screen = BONUS_TYPES[entry_type]
	base_by_code = {row["input_code"]: row["base"] for row in eligibility["items"]}
	inputs = [{**row, "amount": base_by_code[row["input_code"]]}
		for row in SCREENS[screen]["bonus_inputs"]]
	if existing_name:
		doc = frappe.get_doc("PRB Payroll Run", existing_name)
		if doc.docstatus != 0:
			frappe.throw(_("Only a Draft attendance-bonus calculation can be updated."))
		rows_by_code = {row.input_code: row for row in doc.get("employee_inputs") or []}
		for row in inputs:
			if row["input_code"] in rows_by_code:
				rows_by_code[row["input_code"]].amount = row["amount"]
			else:
				doc.append("employee_inputs", row)
		doc.calculation_date = values.get("attendance_date") or cycle.payment_date
		doc.flags.ignore_permissions = True
		doc.save(ignore_permissions=True)
		result = {"name": doc.name}
	else:
		result = record_save(
			screen,
			"PRB Payroll Run",
			{
				"employee": person.name,
				"payroll_cycle": cycle.name,
				"payroll_period": cycle.payroll_period,
				"company": cycle.company,
				"calculation_date": values.get("attendance_date") or cycle.payment_date,
				"employee_inputs": inputs,
			},
			is_admin=True,
		)
	frappe.db.set_value("PRB Payroll Run", result["name"], {
		**audit,
		"custom_eligibility_status": "Eligible" if eligibility.eligible else "Not Eligible",
		"custom_eligibility_reason": eligibility.reason,
	}, update_modified=False)
	return {
		"doctype": "PRB Payroll Run", "name": result["name"],
		"eligibility": "Eligible" if eligibility.eligible else "Not Eligible",
		"eligibility_reason": eligibility.reason,
		"target_route": f"/app/payroll-management/{screen}",
		"target_label": _(entry_type),
		"message": _("Manual {0} calculation {1} {2} in Draft with result: {3}. Review, submit and Post to Payroll after approval.").format(
			entry_type, result["name"], _("updated") if existing_name else _("created"),
			_("Eligible") if eligibility.eligible else _("Not Eligible")
		),
	}


def _upsert_bonus(values, person, audit, entry_type):
	cycle = values.get("payroll_cycle")
	existing = values.get("payroll_run_name")
	if existing:
		linked = frappe.db.get_value(
			"PRB Payroll Run", existing,
			["employee", "payroll_cycle", "run_purpose", "docstatus"], as_dict=True,
		)
		if not linked or linked.employee != person.name or linked.payroll_cycle != cycle \
			or linked.run_purpose != entry_type or linked.docstatus != 0:
			frappe.throw(_("The linked attendance-bonus calculation can no longer be edited."))
	else:
		existing = frappe.db.get_value(
			"PRB Payroll Run",
			{
				"employee": person.name, "payroll_cycle": cycle,
				"run_purpose": entry_type, "custom_entry_source": "Manual Input", "docstatus": 0,
			},
			"name",
			order_by="modified desc",
		)
	return _create_bonus(values, person, audit, entry_type, existing_name=existing)


@frappe.whitelist(methods=["POST"])
def create_manual_input(values):
	"""Create one audited manual input while retaining the normal calculation rules."""
	_require_admin()
	values = frappe.parse_json(values) if isinstance(values, str) else frappe._dict(values or {})
	entry_type = str(values.get("entry_type") or "Attendance").strip()
	if entry_type not in {"Attendance", *ADDITIONAL_TYPES, *BONUS_TYPES}:
		frappe.throw(_("Choose a valid Manual Input Type."))
	person = _employee(values.get("employee"))
	audit = _audit(values.get("manual_reference"))
	if entry_type == "Attendance":
		return _create_attendance_range(values, person, audit)
	if entry_type in ADDITIONAL_TYPES:
		return _create_additional_hours(values, person, audit, entry_type)
	return _create_bonus(values, person, audit, entry_type)


@frappe.whitelist(methods=["POST"])
def update_manual_input(attendance_name, values):
	"""Edit any active Attendance through the same three governed input sections."""
	attendance = _editable_attendance(attendance_name)
	values = frappe.parse_json(values) if isinstance(values, str) else frappe._dict(values or {})
	entry_type = str(values.get("entry_type") or "Attendance").strip()
	if entry_type not in {"Attendance", *ADDITIONAL_TYPES, *BONUS_TYPES}:
		frappe.throw(_("Choose a valid Manual Input Type."))
	if values.get("employee") and values.employee != attendance.employee:
		frappe.throw(_("Employee is fixed when editing an existing Attendance."))
	if values.get("attendance_date") and getdate(values.attendance_date) != getdate(attendance.attendance_date):
		frappe.throw(_("Attendance Date is fixed when editing an existing Attendance."))
	person = _employee(attendance.employee)
	values.employee = attendance.employee
	values.attendance_date = attendance.attendance_date
	values.from_date = attendance.attendance_date
	values.to_date = attendance.attendance_date
	values.shift = attendance.shift
	audit = _audit(values.get("manual_reference") or attendance.get("custom_manual_reference"))
	if entry_type == "Attendance":
		return update_manual_attendance(
			name=attendance.name, employee=attendance.employee,
			attendance_date=attendance.attendance_date, shift=attendance.shift,
			status=values.get("status") or attendance.status,
			clock_in=values.get("clock_in"), clock_out=values.get("clock_out"),
			manual_reference=audit["custom_manual_reference"],
		)
	if entry_type in ADDITIONAL_TYPES:
		return _upsert_additional_hours(values, person, audit, entry_type)
	return _upsert_bonus(values, person, audit, entry_type)
