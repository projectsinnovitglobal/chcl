"""Allow a first salary to be entered on a draft employee promotion."""
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


def apply():
	create_custom_fields({
		"Employee Promotion": [
			{"fieldname": "karyo_new_salary_point", "fieldtype": "Select",
			 "label": "New Salary Point", "insert_after": "current_ctc",
			 "description": "Choose a governed salary point from the new grade scale."},
			{"fieldname": "karyo_salary_appointment", "fieldtype": "Link",
			 "label": "Salary Appointment", "options": "Employee Salary Appointment",
			 "insert_after": "revised_ctc", "hidden": 1, "read_only": 1, "no_copy": 1},
			{"fieldname": "karyo_previous_salary_appointment", "fieldtype": "Link",
			 "label": "Previous Salary Appointment", "options": "Employee Salary Appointment",
			 "insert_after": "karyo_salary_appointment", "hidden": 1, "read_only": 1, "no_copy": 1},
			{"fieldname": "karyo_previous_salary_effective_to", "fieldtype": "Date",
			 "label": "Previous Salary Effective To", "insert_after": "karyo_previous_salary_appointment",
			 "hidden": 1, "read_only": 1, "no_copy": 1},
		],
	}, ignore_validate=True)
	# Promotions use governed monthly basic salary, never a free-form CTC value.
	for field, prop in (("revised_ctc", "depends_on"), ("current_ctc", "mandatory_depends_on")):
		make_property_setter(
			"Employee Promotion", field, prop, "", "Data", validate_fields_for_doctype=False
		)
	for field, label in (("current_ctc", "Current Basic Salary"), ("revised_ctc", "New Basic Salary")):
		make_property_setter(
			"Employee Promotion", field, "label", label, "Data", validate_fields_for_doctype=False
		)
		make_property_setter(
			"Employee Promotion", field, "read_only", 1, "Check", validate_fields_for_doctype=False
		)
	make_property_setter(
		"Employee Promotion", "current_ctc", "fetch_from", "employee.karyo_scale_basic_salary",
		"Data", validate_fields_for_doctype=False,
	)
	make_property_setter(
		"Employee Promotion", "salary_details_section", "label", "Basic Salary Details",
		"Data", validate_fields_for_doctype=False,
	)
	make_property_setter(
		"Employee Promotion", None, "quick_entry", 0, "Check",
		for_doctype=True, validate_fields_for_doctype=False,
	)
	frappe.clear_cache(doctype="Employee Promotion")

	from karyo.setup.employee_movements import apply as apply_movement_fields
	apply_movement_fields()
