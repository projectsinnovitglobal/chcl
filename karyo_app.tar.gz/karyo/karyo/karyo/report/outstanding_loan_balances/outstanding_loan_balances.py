import frappe
from frappe import _
from frappe.utils import flt
from karyo.karyo.report.loan_report_utils import add_loan_permission_condition


CAPITAL_TYPES = ("Disbursement", "Loan Capital", "Loan Capital Reversal", "Advance Payment", "Advance Payment Reversal", "Refund", "Refund Reversal", "Settlement", "Settlement Reversal")


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if not filters.as_at_date:
		frappe.throw(_("As At Date is required."))
	conditions = ["coalesce(l.disbursement_date, l.creation) <= %(as_at_date)s"]
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	if filters.loan:
		conditions.append("l.name=%(loan)s")
	if filters.employee:
		conditions.append("l.employee=%(employee)s")
	if filters.loan_type:
		conditions.append("l.loan_type=%(loan_type)s")
	loans = frappe.db.sql(f"""select l.name loan, l.employee, l.employee_name, l.loan_type,
		l.approved_amount, l.total_interest, l.total_insurance, l.status, l.schedule_version
		from `tabKaryo Loan` l where {' and '.join(conditions)} order by l.employee, l.name""", filters, as_dict=True)
	loan_names = [row.loan for row in loans]
	ledger_by_loan = {}
	settlements = {}
	schedule_interest = {}
	if loan_names:
		for entry in frappe.get_all("Karyo Loan Ledger Entry",
			filters={"loan": ("in", loan_names), "transaction_date": ("<=", filters.as_at_date)},
			fields=["loan", "ref_type", "debit", "credit"], limit_page_length=0):
			ledger_by_loan.setdefault(entry.loan, []).append(entry)
		for settlement in frappe.get_all("Karyo Loan Settlement", filters={"loan": ("in", loan_names), "docstatus": 1,
			"ewf_waive_interest": 1, "refund_date": ("<=", filters.as_at_date)},
			fields=["loan", "interest_due"], order_by="refund_date desc, creation desc", limit_page_length=0):
			settlements.setdefault(settlement.loan, settlement)
		for item in frappe.db.sql("""select parent loan, coalesce(sum(interest), 0) total_interest
			from `tabKaryo Loan Schedule` where parent in %(loans)s and is_current=1 group by parent""",
			{"loans": loan_names}, as_dict=True):
			schedule_interest[item.loan] = flt(item.total_interest)
	data = []
	for row in loans:
		ledger_rows = ledger_by_loan.get(row.loan, [])
		capital_balance = sum(flt(e.debit) - flt(e.credit) for e in ledger_rows if e.ref_type in CAPITAL_TYPES)
		capital_paid = sum(flt(e.credit) - flt(e.debit) for e in ledger_rows if e.ref_type in ("Loan Capital", "Loan Capital Reversal", "Advance Payment", "Advance Payment Reversal", "Settlement", "Settlement Reversal"))
		interest_paid = sum(flt(e.credit) - flt(e.debit) for e in ledger_rows if e.ref_type in ("Loan Interest", "Loan Interest Reversal"))
		insurance_paid = sum(flt(e.credit) - flt(e.debit) for e in ledger_rows if e.ref_type in ("Loan Insurance", "Loan Insurance Reversal"))
		refunds = sum(flt(e.debit) - flt(e.credit) for e in ledger_rows if e.ref_type in ("Refund", "Refund Reversal"))
		waived = _waived_interest(row.loan, filters.as_at_date, interest_paid,
			settlements.get(row.loan), schedule_interest.get(row.loan))
		row.capital_paid = max(0, capital_paid)
		row.interest_paid = max(0, interest_paid)
		row.insurance_paid = max(0, insurance_paid)
		row.waived_interest = waived
		row.refunded = refunds
		row.outstanding_capital = max(0, capital_balance)
		row.outstanding_interest = max(0, flt(row.total_interest) - row.interest_paid - waived)
		row.outstanding_insurance = max(0, flt(row.total_insurance) - row.insurance_paid)
		row.outstanding_total = row.outstanding_capital + row.outstanding_interest + row.outstanding_insurance
		if filters.include_settled or row.outstanding_total > 0.005:
			data.append(row)
	return _columns(), data


def _waived_interest(loan, as_at_date, interest_paid, settlement=None, total=None):
	if settlement is None:
		settlement = frappe.db.get_value("Karyo Loan Settlement", {"loan": loan, "docstatus": 1,
			"ewf_waive_interest": 1, "refund_date": ["<=", as_at_date]}, ["interest_due"], as_dict=True)
	if not settlement:
		return 0
	if total is None:
		total = frappe.db.sql("select coalesce(sum(interest),0) from `tabKaryo Loan Schedule` where parent=%s and is_current=1", loan)[0][0]
	return max(0, flt(total) - flt(interest_paid) - flt(settlement.interest_due))


def _columns():
	def c(fieldname, label, fieldtype="Currency", width=120, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("loan", "Loan", "Link", 145, "Karyo Loan"), c("employee", "Employee", "Link", 130, "Employee"),
		c("employee_name", "Employee Name", "Data", 160), c("loan_type", "Loan Type", "Link", 120, "Loan Type"),
		c("status", "Status", "Data", 85), c("schedule_version", "Version", "Int", 65), c("approved_amount", "Approved"),
		c("capital_paid", "Capital Paid"), c("interest_paid", "Interest Paid"), c("insurance_paid", "Insurance Paid"),
		c("waived_interest", "Interest Waived"), c("refunded", "Refunded"), c("outstanding_capital", "Capital Balance"),
		c("outstanding_interest", "Interest Balance"), c("outstanding_insurance", "Insurance Balance"),
		c("outstanding_total", "Total Outstanding", "Currency", 140)]
