// Copyright (c) 2026, AstraFlow and contributors
// For license information, please see license.txt

frappe.query_reports["Loan Ledger to GL Reconciliation"] = {
	"filters": [

	]
};
