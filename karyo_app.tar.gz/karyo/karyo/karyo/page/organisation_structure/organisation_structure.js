frappe.pages["organisation-structure"].on_page_load = function (wrapper) {
	wrapper.organisation_structure = new KaryoOrganisationStructure(wrapper);
};

frappe.pages["organisation-structure"].on_page_show = function (wrapper) {
	wrapper.organisation_structure?.load();
};

class KaryoOrganisationStructure {
	constructor(wrapper) {
		this.page = frappe.ui.make_app_page({
			parent: wrapper,
			title: __("Organisation Structure"),
			single_column: true,
		});
		this.current = "department";
		this.active_section = "";
		this.config = {
			department: {
				label: __("Departments"),
				doctype: "Department",
				add_label: __("Add Department"),
				columns: [__("Department"), __("Department Code"), __("Company"), __("Status"), __("Actions")],
			},
			section: {
				label: __("Sections"),
				doctype: "Employee Section",
				add_label: __("Add Section"),
				columns: [__("Section"), __("Section Code"), __("Department"), __("Status"), __("Actions")],
			},
			location: {
				label: __("Locations"),
				doctype: "Employee Location",
				add_label: __("Add Location"),
				columns: [__("Location"), __("Location Code"), __("Section"), __("Status"), __("Actions")],
			},
		};
		this.make();
		this.activate("department");
	}

	make() {
		this.$root = $('<div class="karyo-organisation-structure"></div>').appendTo(this.page.main);
		$('<p class="karyo-organisation-subtitle"></p>')
			.text(__("Maintain Departments, Sections and Locations in a controlled hierarchy."))
			.appendTo(this.$root);
		this.$tabs = $('<div class="karyo-organisation-tabs" role="tablist"></div>').appendTo(this.$root);
		for (const [key, config] of Object.entries(this.config)) {
			$('<button type="button" role="tab"></button>')
				.attr("data-level", key)
				.text(config.label)
				.on("click", () => this.activate(key))
				.appendTo(this.$tabs);
		}
		this.$panel = $('<section class="karyo-organisation-panel"></section>').appendTo(this.$root);
		$('<div class="karyo-organisation-chain"></div>')
			.append(
				$("<strong></strong>").text(__("Department")),
				$("<span></span>").text("→"),
				$("<strong></strong>").text(__("Section")),
				$("<span></span>").text("→"),
				$("<strong></strong>").text(__("Location")),
			)
			.appendTo(this.$panel);
		this.$filters = $('<div class="karyo-organisation-filters"></div>').appendTo(this.$panel);
		this.$status = $('<div class="karyo-organisation-load-status" role="status"></div>').appendTo(this.$panel);
		this.$table = $('<div class="table-responsive karyo-organisation-table"></div>').appendTo(this.$panel);
	}

	async activate(level, defaults = {}) {
		this.current = level;
		this.active_section = defaults.section || "";
		this.$tabs.find("button").each(function () {
			const active = $(this).attr("data-level") === level;
			$(this).toggleClass("active", active).attr("aria-selected", active ? "true" : "false");
		});
		this.make_filters();
		if (defaults.department && this.department_control) {
			this.updating_filters = true;
			await this.department_control.set_value(defaults.department);
			this.updating_filters = false;
		}
		this.update_primary_action();
		await this.load();
	}

	make_filters() {
		this.$filters.empty();
		this.department_control = null;
		this.$search = $('<input type="search" class="form-control karyo-organisation-search">')
			.attr("placeholder", __("Search by name or code"))
			.on("keydown", event => {
				if (event.key === "Enter") this.load();
			})
			.appendTo(this.$filters);

		if (this.current !== "department") {
			const $parent = $('<div class="karyo-organisation-department-filter"></div>').appendTo(this.$filters);
			this.department_control = frappe.ui.form.make_control({
				parent: $parent,
				render_input: true,
				df: {
					fieldname: "department",
					fieldtype: "Link",
					label: __("All Departments"),
					options: "Department",
					get_query: () => ({ filters: { disabled: 0, is_group: 0 } }),
					onchange: () => {
						if (this.updating_filters) return;
						this.active_section = "";
					},
				},
			});
			this.department_control.refresh();
			this.department_control.$input?.attr("placeholder", __("All Departments"));
		}

		this.$status_filter = $('<select class="form-control"></select>')
			.append($('<option value=""></option>').text(__("All Statuses")))
			.append($('<option value="enabled"></option>').text(__("Enabled")))
			.append($('<option value="disabled"></option>').text(__("Disabled")))
			.appendTo(this.$filters);
		$('<button type="button" class="btn btn-default karyo-organisation-search-button"></button>')
			.text(__("Search"))
			.on("click", () => this.load())
			.appendTo(this.$filters);
		this.$filters.toggleClass("has-department", this.current !== "department");
	}

	department() {
		return this.department_control?.get_value() || "";
	}

	update_primary_action() {
		const config = this.config[this.current];
		this.page.clear_primary_action();
		if (!frappe.model.can_create(config.doctype)) return;
		this.page.set_primary_action(config.add_label, () => this.open_record(null), "add");
	}

	async open_record(name) {
		const config = this.config[this.current];
		const defaults = {
			...(this.department() ? { department: this.department() } : {}),
			...(this.current === "location" && this.active_section ? { section: this.active_section } : {}),
		};
		if (karyo.org_units?.supports?.(config.doctype)) {
			const dialog = name
				? await karyo.org_units.open_editor(config.doctype, name)
				: await karyo.org_units.open_new(config.doctype, defaults);
			dialog?.$wrapper?.one("hidden.bs.modal", () => this.load());
			return;
		}
		if (name) frappe.set_route("Form", config.doctype, name);
		else frappe.new_doc(config.doctype, defaults);
	}

	async load() {
		if (!this.$table) return;
		const revision = (this.load_revision || 0) + 1;
		this.load_revision = revision;
		this.$status.text(__("Loading…"));
		try {
			const rows = await frappe.xcall("karyo.desk.org_units.get_structure_rows", {
				entity: this.current,
				search: (this.$search?.val() || "").trim(),
				department: this.department(),
				section: this.current === "location" ? this.active_section : "",
				status: this.$status_filter?.val() || "",
			});
			if (revision !== this.load_revision) return;
			this.render(rows || []);
			this.$status.text(rows?.length ? __("{0} records", [rows.length]) : __("No records found"));
		} catch (error) {
			if (revision !== this.load_revision) return;
			this.$table.empty();
			this.$status.text(__("Could not load organisation structure records."));
		}
	}

	render(rows) {
		const config = this.config[this.current];
		const $table = $('<table class="table"><thead><tr></tr></thead><tbody></tbody></table>');
		config.columns.forEach(label => $("<th></th>").text(label).appendTo($table.find("thead tr")));
		rows.forEach(row => this.render_row($table.find("tbody"), row));
		if (!rows.length) {
			$('<tr><td class="text-muted text-center"></td></tr>')
				.find("td").attr("colspan", config.columns.length).text(__("No matching records"))
				.end().appendTo($table.find("tbody"));
		}
		this.$table.empty().append($table);
	}

	render_row($body, row) {
		const $row = $("<tr></tr>").appendTo($body);
		const values = this.current === "department"
			? [row.department_name, row.karyo_department_code || "—", row.company]
			: this.current === "section"
				? [row.section_name, row.section_code, row.department]
				: [row.location_name, row.location_code, row.section || "—"];
		values.forEach(value => $("<td></td>").text(value || "—").appendTo($row));
		const mappingNeeded = this.current === "location" && !row.mapping_complete;
		$("<td></td>")
			.append($('<span class="karyo-organisation-status"></span>')
				.addClass(mappingNeeded || row.disabled ? "is-disabled" : "is-enabled")
				.text(mappingNeeded ? __("Needs mapping") : row.disabled ? __("Disabled") : __("Enabled")))
			.appendTo($row);
		const $actions = $('<td class="karyo-organisation-actions"></td>').appendTo($row);
		$('<button type="button" class="btn btn-link btn-xs"></button>')
			.text(__("Edit")).on("click", () => this.open_record(row.name)).appendTo($actions);
		if (this.current === "department") {
			$('<button type="button" class="btn btn-link btn-xs"></button>')
				.text(__("View Sections"))
				.on("click", () => this.activate("section", { department: row.name }))
				.appendTo($actions);
		} else if (this.current === "section") {
			$('<button type="button" class="btn btn-link btn-xs"></button>')
				.text(__("View Locations"))
				.on("click", () => this.activate("location", { department: row.department, section: row.name }))
				.appendTo($actions);
		} else {
			$('<button type="button" class="btn btn-link btn-xs"></button>')
				.text(__("View Details"))
				.on("click", () => frappe.set_route("Form", "Employee Location", row.name))
				.appendTo($actions);
		}
	}
}
