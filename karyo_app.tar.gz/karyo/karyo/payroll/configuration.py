"""Production-safety helpers for configurable payroll rules."""

import frappe
from frappe import _
from frappe.utils import getdate


def get_configuration(config_key, on_date=None, company=None, allow_demo=None):
	"""Resolve one effective payroll configuration.

	Production mode returns only approved, production-eligible records. Demo mode may resolve explicitly
	labelled demo records, unless callers override ``allow_demo``.
	"""
	on_date = getdate(on_date)
	mode = frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo"
	if allow_demo is None:
		allow_demo = mode == "Demo"

	filters = {"config_key": config_key, "effective_from": ("<=", on_date)}
	if allow_demo:
		filters["configuration_status"] = ("in", ["Demo", "Approved", "Active"])
	else:
		filters.update({"configuration_status": "Active", "is_production_eligible": 1})

	rows = frappe.get_all(
		"Payroll Configuration Version",
		filters=filters,
		fields=[
			"name",
			"company",
			"configuration_status",
			"is_production_eligible",
			"effective_from",
			"effective_to",
		],
		order_by="is_production_eligible desc, effective_from desc, modified desc",
	)
	rows = [row for row in rows if not row.effective_to or getdate(row.effective_to) >= on_date]
	if company:
		rows = [row for row in rows if not row.company or row.company == company]
	if not rows:
		frappe.throw(
			_("No eligible payroll configuration {0} exists for {1}.").format(config_key, on_date),
			title=_("Payroll Configuration Missing"),
		)
	return frappe.get_doc("Payroll Configuration Version", rows[0].name)


def assert_production_eligible(configuration):
	"""Block a demo/draft configuration from production processing."""
	if isinstance(configuration, str):
		configuration = frappe.get_doc("Payroll Configuration Version", configuration)
	if configuration.configuration_status != "Active" or not configuration.is_production_eligible:
		frappe.throw(
			_("Configuration {0} is not active for production payroll.").format(configuration.name),
			title=_("Unapproved Payroll Configuration"),
		)
	return configuration
