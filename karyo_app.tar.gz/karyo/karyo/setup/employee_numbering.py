"""Keep Employee IDs automatic and expose the generated code read-only."""

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


def apply():
	make_property_setter("Employee", "naming_series", "hidden", 1, "Check")
	make_property_setter("Employee", "employee", "hidden", 0, "Check")
	make_property_setter("Employee", "employee", "label", "Employee Code", "Data")
	make_property_setter("Employee", "employee", "read_only", 1, "Check")
	frappe.clear_cache(doctype="Employee")


def setup():
	apply()
