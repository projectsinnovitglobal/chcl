import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.doctype.karyo_loan_settlement import test_karyo_loan_settlement as loan_helpers
from karyo.karyo.report.loan_statement.loan_statement import execute


class TestLoanStatement(FrappeTestCase):
	_assign_salary_structure = loan_helpers.TestKaryoLoanSettlement._assign_salary_structure
	_activate_loan = loan_helpers.TestKaryoLoanSettlement._activate_loan

	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		cls.company = frappe.db.get_value("Company", {}, "name")
		if cls.company and not frappe.db.exists("Loan Type", "PERSONAL"):
			frappe.get_doc({"doctype": "Loan Type", "loan_code": "PERSONAL", "loan_name": "Personal Loan",
				"loan_category": "Personal", "interest_rate": 6, "is_active": 1}).insert(ignore_permissions=True)

	def test_statement_has_disbursement_and_running_total(self):
		if not self.company:
			self.skipTest("no Company on site")
		frappe.db.set_single_value("Karyo Settings", "max_deduction_pct", 40)
		frappe.db.set_single_value("Karyo Settings", "require_appraisal_payroll_cycle", 0)
		frappe.db.set_value("Loan Type", "PERSONAL", {"pdb_capital": "Karyo Loan Capital", "pdb_interest": "Karyo Loan Interest", "pdb_insurance": "Karyo Loan Insurance"}, update_modified=False)
		self.emp = frappe.get_doc({"doctype": "Employee", "first_name": "Statement", "last_name": "Borrower",
			"gender": frappe.db.get_value("Gender", {}, "name") or "Male", "date_of_birth": "1985-01-01",
			"date_of_joining": "2016-01-01", "company": self.company, "status": "Active"}).insert(ignore_permissions=True, ignore_mandatory=True)
		self._assign_salary_structure(self.emp.name)
		loan = self._activate_loan()
		_columns, rows = execute({"loan": loan.name, "include_reversals": 1})
		self.assertTrue(rows)
		self.assertEqual(rows[0].ref_type, "Disbursement")
		self.assertEqual(rows[0].component, "Capital")
		self.assertEqual(rows[0].running_total, loan.approved_amount)
