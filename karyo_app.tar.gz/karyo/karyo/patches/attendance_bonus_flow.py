"""Install the Attendance-menu bonus scope and its payroll mappings."""

from karyo.setup.prb_posting import ensure_attendance_business_mappings
from karyo.setup.prb_run import ensure_extension_fields


def execute():
	ensure_extension_fields()
	ensure_attendance_business_mappings()
