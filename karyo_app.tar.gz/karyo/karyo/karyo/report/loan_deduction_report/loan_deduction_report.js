frappe.query_reports["Loan Deduction Report"] = {
	filters: [
		{ fieldname: "from_date", label: __("From Date"), fieldtype: "Date" },
		{ fieldname: "to_date", label: __("To Date"), fieldtype: "Date" },
		{ fieldname: "payroll_period", label: __("Payroll Period"), fieldtype: "Data" },
		{ fieldname: "payroll_cycle", label: __("Payroll Cycle"), fieldtype: "Link", options: "Payroll Cycle" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "pdb_code", label: __("PDB Code"), fieldtype: "Data" },
		{ fieldname: "component", label: __("Component"), fieldtype: "Select", options: "\nCapital\nInterest\nInsurance" },
		{ fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department" },
		{ fieldname: "location", label: __("Location / Branch"), fieldtype: "Link", options: "Branch" },
	],
};
