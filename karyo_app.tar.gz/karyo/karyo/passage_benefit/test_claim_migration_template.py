import json
from pathlib import Path
import unittest


SOURCE = (
	Path(__file__).resolve().parents[1]
	/ "payroll"
	/ "data"
	/ "pb_claim_migration_template.json"
)


class TestPassageBenefitClaimMigrationTemplate(unittest.TestCase):
	def test_live_sheet_columns_are_captured_exactly(self):
		payload = json.loads(SOURCE.read_text())
		self.assertEqual(payload["workbook_title"], "PB-Claim")
		self.assertEqual(payload["sheet"], "Sheet2")
		self.assertEqual(payload["range"], "A1:K4")
		self.assertEqual(payload["header_row"], 3)
		self.assertEqual(
			payload["columns"],
			[
				"Claim / Application Ref*",
				"Employee Code*",
				"PB Usage / Claim Type*",
				"Request Date*",
				"Requested Amount*",
				"Approved Amount",
				"Approval Date",
				"Legacy Status*",
				"Processed Date",
				"PDB / Payment Reference",
				"Remarks",
			],
		)

	def test_sample_row_is_excluded_and_no_business_rows_are_invented(self):
		payload = json.loads(SOURCE.read_text())
		self.assertEqual(payload["excluded_rows"], [4])
		self.assertEqual(payload["rows"], [])
