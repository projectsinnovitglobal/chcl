"""Apply the confirmed MBC eligibility baseline to pre-existing PB settings."""

import frappe


def execute():
	# New installs receive these values from DocType defaults. Existing Singles do
	# not automatically receive defaults for fields added after their creation.
	existing = frappe.db.exists(
		"Singles",
		{"doctype": "Passage Benefit Settings", "field": "require_confirmation"},
	)
	if existing:
		return
	frappe.db.set_single_value("Passage Benefit Settings", "eligibility_mode", "Confirmation only")
	frappe.db.set_single_value("Passage Benefit Settings", "require_confirmation", 1)
	frappe.db.set_single_value("Passage Benefit Settings", "require_permanent_employee", 1)
	frappe.db.sql(
		"""update `tabPassage Benefit Parameter Version`
		set eligibility_mode = %s, require_confirmation = 1, require_permanent_employee = 1
		where parenttype = 'Passage Benefit Settings'""",
		("Confirmation only",),
	)
	frappe.clear_cache(doctype="Passage Benefit Settings")
