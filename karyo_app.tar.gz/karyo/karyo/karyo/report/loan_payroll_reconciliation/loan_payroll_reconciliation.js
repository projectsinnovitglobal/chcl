frappe.query_reports["Loan Payroll Reconciliation"] = {
	filters: [
		{ fieldname: "from_date", label: __("From Date"), fieldtype: "Date", reqd: 1 },
		{ fieldname: "to_date", label: __("To Date"), fieldtype: "Date", reqd: 1 },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
	],
};
