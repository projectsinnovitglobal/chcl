"""Self-service clocking and permission-scoped live presence."""
import math
import re

import frappe
from frappe import _
from frappe.utils import flt, get_datetime, getdate, now_datetime, nowdate

ADMIN_ROLES = {"System Manager", "HR Manager", "HR User"}


def _require_login():
	if frappe.session.user == "Guest":
		frappe.throw(_("Please sign in to clock in or out."), frappe.PermissionError)


def _own_employee(required=False):
	_require_login()
	rows = frappe.get_all("Employee", filters={"user_id": frappe.session.user, "status": "Active"}, fields=["name", "employee_name", "branch"], limit_page_length=2)
	if len(rows) > 1:
		frappe.throw(_("More than one active employee is linked to your account. Contact HR."))
	if required and not rows:
		frappe.throw(_("No active employee is linked to your account. Contact HR."))
	return rows[0] if rows else None


def _can_view_team_attendance():
	return bool(
		ADMIN_ROLES.intersection(frappe.get_roles())
		and frappe.has_permission("Attendance", "read")
		and frappe.has_permission("Employee Checkin", "read")
	)


def _active_clock_authorization(employee, at_time):
	"""Return a submitted advance authority covering the requested clock time."""
	rows = frappe.get_all(
		"PRB Overtime Authorization",
		filters={
			"employee": employee,
			"docstatus": 1,
			"authorization_status": "Authorised",
			"planned_start": ("<=", at_time),
			"planned_end": (">=", at_time),
		},
		fields=["name", "claim_type", "planned_start", "planned_end", "shift_type"],
		order_by="planned_start desc, creation desc",
		limit_page_length=1,
	)
	return rows[0] if rows else None


def _clock_access(employee, at_time=None, latest=None):
	"""Enforce normal duty or a submitted additional-hours authorisation."""
	from erpnext.setup.doctype.employee.employee import is_holiday
	from hrms.hr.doctype.shift_assignment.shift_assignment import get_shift_details
	from karyo.hr.roster import current_duty

	at_time = get_datetime(at_time or now_datetime())
	if latest and latest.log_type == "IN":
		return {
			"can_clock_in": False,
			"can_clock_out": True,
			"reason": _("You are already clocked in."),
			"authorization": None,
		}

	holiday = bool(is_holiday(employee, at_time.date(), raise_exception=False))
	duty = current_duty(employee, at_time.date())
	shift_name = duty.shift_type if duty else frappe.get_cached_value("Employee", employee, "default_shift")
	inside_shift = True
	if shift_name:
		shift = get_shift_details(shift_name, at_time)
		inside_shift = bool(shift and shift.start_datetime <= at_time <= shift.end_datetime)
	authorization = _active_clock_authorization(employee, at_time) if holiday or not inside_shift else None
	allowed = (not holiday and inside_shift) or bool(authorization)
	if allowed:
		reason = (
			_("Additional-hours authority {0} is active.").format(authorization.name)
			if authorization else _("Clocking is open for your scheduled shift.")
		)
	elif holiday:
		reason = _("Clocking is disabled on holidays and weekly-off days unless HR submits an overtime, night-duty or excess-hours authority for this time.")
	else:
		reason = _("Clocking outside your scheduled shift requires a submitted overtime, night-duty or excess-hours authority covering this time.")
	return {
		"can_clock_in": allowed,
		"can_clock_out": False,
		"reason": reason,
		"authorization": authorization.name if authorization else None,
	}


def _team_today_live_rows(filters=None):
	"""Provisional today rows for active employees not yet processed into Attendance."""
	from frappe.utils import evaluate_filters
	from karyo.hr.attendance_rules import display_status

	duty_date = getdate(nowdate())
	employees = frappe.get_list(
		"Employee",
		filters={"status": "Active", "date_of_joining": ("<=", duty_date)},
		fields=[
			"name", "employee_name", "company", "default_shift", "holiday_list",
			"relieving_date", "karyo_work_pattern",
		],
		order_by="employee_name asc",
		limit_page_length=500,
	)
	employees = [
		employee for employee in employees
		if not employee.relieving_date or getdate(employee.relieving_date) >= duty_date
	]
	if not employees:
		return [], {}
	names = tuple(employee.name for employee in employees)
	existing = set(frappe.get_list(
		"Attendance",
		filters={"employee": ("in", names), "attendance_date": duty_date, "docstatus": ("!=", 2)},
		pluck="employee", limit_page_length=500,
	))
	checkins = frappe.db.sql(
		"""select employee,
		min(case when log_type='IN' then time end) as clock_in,
		max(case when log_type='OUT' then time end) as clock_out,
		max(case when custom_entry_source='Automatic Clocking' then 1 else 0 end) as automatic_clocking,
		max(coalesce(shift, '')) as shift
		from `tabEmployee Checkin`
		where employee in %(employees)s and date(coalesce(shift_start, time))=%(duty_date)s
		group by employee""",
		{"employees": names, "duty_date": duty_date}, as_dict=True,
	)
	checkins = {row.employee: row for row in checkins}
	leaves = set(frappe.get_all(
		"Leave Application",
		filters={
			"employee": ("in", names), "docstatus": 1, "status": "Approved",
			"from_date": ("<=", duty_date), "to_date": (">=", duty_date),
		},
		pluck="employee", limit_page_length=500,
	))
	company_names = tuple({employee.company for employee in employees if employee.company})
	company_holidays = dict(frappe.get_all(
		"Company", filters={"name": ("in", company_names)},
		fields=["name", "default_holiday_list"], as_list=True, limit_page_length=500,
	)) if company_names else {}
	holiday_lists = {
		employee.holiday_list or company_holidays.get(employee.company)
		for employee in employees
		if employee.holiday_list or company_holidays.get(employee.company)
	}
	holiday_lists_today = set(frappe.get_all(
		"Holiday", filters={"parent": ("in", tuple(holiday_lists)), "holiday_date": duty_date},
		pluck="parent", limit_page_length=500,
	)) if holiday_lists else set()
	additional_hours = _additional_hours_by_employee_date([
		frappe._dict(employee=employee.name, attendance_date=duty_date) for employee in employees
	])
	bonuses = _attendance_bonuses_by_employee_date([
		frappe._dict(employee=employee.name, attendance_date=duty_date) for employee in employees
	])

	rows = []
	records = {}
	for employee in employees:
		if employee.name in existing:
			continue
		checkin = checkins.get(employee.name)
		holiday_list = employee.holiday_list or company_holidays.get(employee.company)
		if not checkin and holiday_list in holiday_lists_today:
			continue
		if checkin:
			raw_status = "Present"
		elif employee.name in leaves:
			raw_status = "On Leave"
		else:
			raw_status = "Absent"
		row = frappe._dict(
			name=f"live-team-{duty_date}-{employee.name}",
			employee=employee.name,
			employee_name=employee.employee_name,
			attendance_date=duty_date,
			status=raw_status,
			shift=(checkin.shift if checkin else None) or employee.default_shift,
			docstatus=1,
			__clock_live=True,
		)
		metrics = _attendance_metrics(
			row,
			checkin.clock_in if checkin else None,
			checkin.clock_out if checkin else None,
			employee.name,
		) if checkin else {
			"clock_in": None, "clock_out": None, "hours": None,
			"clock_in_status": None, "clock_out_status": None,
			"shift": row.shift, "shift_code": None, "scheduled_start": None,
			"scheduled_end": None, "duty_hours": None, "roster_assignment": None,
			"shift_schedule_assignment": None, "shift_schedule": None,
			"work_pattern": employee.karyo_work_pattern,
		}
		metrics.update(additional_hours.get((employee.name, duty_date), _empty_additional_hours()))
		_set_complete_total_hours(metrics)
		metrics.update(bonuses.get((employee.name, duty_date), _empty_attendance_bonuses()))
		row.status = display_status(raw_status, metrics.get("clock_in_status"))
		if filters and not evaluate_filters(row, filters):
			continue
		records[row.name] = {
			"employee_name": employee.employee_name,
			"attendance_date": duty_date,
			"attendance_status": raw_status,
			"status": row.status,
			"clock_in": checkin.clock_in if checkin else None,
			"clock_out": checkin.clock_out if checkin else None,
			"entry_source": "Automatic Clocking" if checkin and checkin.automatic_clocking else None,
			"remark": _("Automatic (ESS Clock In/Out)") if checkin and checkin.automatic_clocking else None,
			**metrics,
		}
		rows.append(row)
	return rows, records


def team_today_attendance_counts():
	"""Current-day HR dashboard counts, including rows awaiting processing."""
	cache = getattr(frappe.local, "karyo_team_today_attendance_counts", None)
	if cache is not None:
		return cache
	rows = frappe.get_list(
		"Attendance",
		filters={"attendance_date": nowdate(), "docstatus": ("!=", 2)},
		fields=["employee", "status"], limit_page_length=500,
	)
	live_rows, _records = _team_today_live_rows()
	rows.extend(live_rows)
	present = {"Present", "Work From Home", "Half Day", "On-time", "Late"}
	cache = {
		"present": sum(row.status in present for row in rows),
		"absent": sum(row.status == "Absent" for row in rows),
	}
	frappe.local.karyo_team_today_attendance_counts = cache
	return cache


@frappe.whitelist()
def employee_checkin_daily_status(checkin_date=None, employee=None, shift=None):
	"""Permission-scoped daily employee clock status, including employees with no punch."""
	if not _can_view_team_attendance():
		frappe.throw(_("Only an HR administrator may view the employee clock-status table."), frappe.PermissionError)
	from karyo.hr.roster import current_duty

	day = getdate(checkin_date or nowdate())
	filters = {"status": "Active", "date_of_joining": ("<=", day)}
	if employee:
		filters["name"] = employee
	employees = frappe.get_list(
		"Employee", filters=filters,
		fields=["name", "employee_name", "default_shift", "relieving_date"],
		order_by="employee_name asc", limit_page_length=500,
	)
	employees = [row for row in employees if not row.relieving_date or getdate(row.relieving_date) >= day]
	if not employees:
		return {"date": day, "rows": [], "total": 0}
	names = tuple(row.name for row in employees)
	logs = frappe.db.sql(
		"""select employee,
			min(case when log_type='IN' then time end) as clock_in,
			max(case when log_type='OUT' then time end) as clock_out,
			substring_index(group_concat(log_type order by time desc, creation desc), ',', 1) as latest_type,
			max(coalesce(shift, '')) as logged_shift
		from `tabEmployee Checkin`
		where employee in %(employees)s
			and date(coalesce(shift_start, time))=%(day)s
		group by employee""",
		{"employees": names, "day": day}, as_dict=True,
	)
	logs = {row.employee: row for row in logs}
	rows = []
	for person in employees:
		duty = current_duty(person.name, day)
		logged = logs.get(person.name)
		shift_name = (duty.shift_type if duty else None) or (logged.logged_shift if logged else None) or person.default_shift
		if shift and shift_name != shift:
			continue
		if not logged:
			status = _("Not Clocked In")
		elif logged.latest_type == "IN":
			status = _("Clocked In")
		else:
			status = _("Clocked Out")
		rows.append({
			"employee": person.name,
			"employee_name": person.employee_name,
			"shift": shift_name,
			"clock_in": logged.clock_in if logged else None,
			"clock_out": logged.clock_out if logged else None,
			"clock_status": status,
		})
	return {"date": day, "rows": rows, "total": len(rows)}



def _latest(employee, lock=False, on_date=None):
	values = [employee]
	date_filter = ""
	if on_date:
		date_filter = " and date(time)=%s"
		values.append(on_date)
	rows = frappe.db.sql(
		"""select name, employee, log_type, time, device_id, shift, custom_clock_note
		from `tabEmployee Checkin` where employee=%s""" + date_filter + """
		order by time desc, creation desc, name desc limit 1""" + (" for update" if lock else ""),
		tuple(values), as_dict=True,
	)
	return rows[0] if rows else None


def _status(employee, latest=None, include_access=False):
	result = {
		"employee": employee.name, "employee_name": employee.employee_name,
		"branch": employee.get("branch"), "clocked_in": bool(latest and latest.log_type == "IN"),
		"last_log_type": latest.log_type if latest else None,
		"time": latest.time if latest else None,
		"location": latest.device_id if latest else None,
		"checkin": latest.name if latest else None,
		"shift": latest.shift if latest else None,
	}
	if include_access:
		result.update(_clock_access(employee.name, latest=latest))
	return result


@frappe.whitelist()
def dashboard(scope="self", employee=None):
	own = _own_employee()
	today = nowdate()
	result = {"self": _status(own, _latest(own.name), include_access=True) if own else None,
		"current_date": today,
		"gps_required": bool(frappe.db.get_single_value("HR Settings", "allow_geolocation_tracking")), "team": None, "target": None}
	if employee:
		doc = frappe.get_doc("Employee", employee)
		doc.check_permission("read")
		latest = _latest(employee)
		if latest and (not own or own.name != employee):
			frappe.get_doc("Employee Checkin", latest.name).check_permission("read")
		result["target"] = _status(doc, latest, include_access=bool(own and own.name == employee))
	if scope == "team" and ADMIN_ROLES.intersection(frappe.get_roles()) and frappe.has_permission("Employee Checkin", "read"):
		result["team"] = []
		for person in frappe.get_list("Employee", filters={"status": "Active"}, fields=["name", "employee_name", "branch"], order_by="employee_name", limit_page_length=0):
			latest = _latest(person.name)
			if latest and not frappe.has_permission("Employee Checkin", "read", doc=frappe.get_doc("Employee Checkin", latest.name)):
				continue
			result["team"].append(_status(person, latest))
	return result


@frappe.whitelist(methods=["POST"])
def clock(log_type, location, request_id, note=None, latitude=None, longitude=None):
	person = _own_employee(required=True)
	if log_type not in {"IN", "OUT"}:
		frappe.throw(_("Choose Clock In or Clock Out."))
	location = str(location or "").strip()
	if not location or len(location) > 140:
		frappe.throw(_("Enter a work location of up to 140 characters."))
	if not re.fullmatch(r"[A-Za-z0-9-]{16,64}", str(request_id or "")):
		frappe.throw(_("Invalid clocking request. Reopen the clocking form."))
	if len(str(note or "")) > 1000:
		frappe.throw(_("Keep the note within 1000 characters."))
	coordinates = {}
	if latitude not in (None, "") or longitude not in (None, ""):
		try:
			lat, lon = float(latitude), float(longitude)
			if not math.isfinite(lat) or not math.isfinite(lon) or not (-90 <= lat <= 90 and -180 <= lon <= 180):
				raise ValueError
		except (TypeError, ValueError):
			frappe.throw(_("Provide valid latitude and longitude coordinates."))
		coordinates = {"latitude": lat, "longitude": lon}
	# A stable row lock serializes simultaneous requests from multiple tabs/devices.
	frappe.db.sql("select name from `tabEmployee` where name=%s for update", (person.name,))
	previous_rows = frappe.db.sql("select employee, log_type from `tabEmployee Checkin` where custom_clock_request_id=%s for update", (request_id,), as_dict=True)
	previous = previous_rows[0] if previous_rows else None
	if previous:
		if previous.employee != person.name or previous.log_type != log_type:
			frappe.throw(_("This clocking request has already been used."))
		return _status(person, _latest(person.name, lock=True))
	latest = _latest(person.name, lock=True)
	access = _clock_access(person.name, latest=latest)
	if log_type == "IN" and not access["can_clock_in"]:
		frappe.throw(access["reason"])
	if log_type == "OUT" and not access["can_clock_out"]:
		frappe.throw(access["reason"] or _("Clock in before clocking out."))
	if log_type == "IN" and latest and latest.log_type == "IN":
		frappe.throw(_("You are already clocked in. Clock out before clocking in again."))
	if log_type == "OUT" and (not latest or latest.log_type != "IN"):
		frappe.throw(_("Clock in before clocking out."))
	doc = frappe.get_doc({"doctype": "Employee Checkin", "employee": person.name,
		"log_type": log_type, "time": now_datetime(), "device_id": location,
		"custom_clock_note": str(note or "").strip(), "custom_clock_request_id": request_id,
		"custom_entry_source": "Automatic Clocking", **coordinates})
	# Self-service identity and server time are fixed above. Native shift, duplicate,
	# active-employee and geofence validation still runs; no caller-selected employee.
	doc.insert(ignore_permissions=True)
	if log_type == "OUT":
		_record_authorized_work(person.name, latest, doc)
	return _status(person, doc)


def _record_authorized_work(employee, clock_in, clock_out):
	"""Copy an authorised punch pair into overtime and holiday attendance."""
	from erpnext.setup.doctype.employee.employee import is_holiday

	if not clock_in or clock_in.log_type != "IN":
		return
	authorization = _active_clock_authorization(employee, get_datetime(clock_in.time))
	if not authorization:
		return
	# A calculation error must never strand an employee in a clocked-in state.
	frappe.db.savepoint("sync_overtime_clock")
	try:
		authority = frappe.get_doc("PRB Overtime Authorization", authorization.name)
		authority.actual_start = clock_in.time
		authority.actual_end = clock_out.time
		authority.save(ignore_permissions=True)
	except Exception:
		frappe.db.rollback(save_point="sync_overtime_clock")
		frappe.log_error(
			title=_("Overtime clock synchronisation failed"),
			message=frappe.get_traceback(with_context=True),
		)

	work_date = getdate(clock_in.time)
	existing = frappe.db.get_value(
		"Attendance",
		{"employee": employee, "attendance_date": work_date, "docstatus": ("!=", 2)},
		"name",
	)
	attendance_name = existing
	if not existing and is_holiday(employee, work_date, raise_exception=False):
		frappe.db.savepoint("authorized_holiday_attendance")
		try:
			hours = max(0, (get_datetime(clock_out.time) - get_datetime(clock_in.time)).total_seconds() / 3600)
			attendance = frappe.get_doc({
				"doctype": "Attendance",
				"employee": employee,
				"attendance_date": work_date,
				"status": "Present",
				"shift": clock_out.shift or clock_in.shift or authorization.shift_type,
				"working_hours": hours,
				"in_time": clock_in.time,
				"out_time": clock_out.time,
			})
			attendance.flags.ignore_permissions = True
			attendance.insert(ignore_permissions=True)
			attendance.submit()
			attendance_name = attendance.name
		except Exception:
			frappe.db.rollback(save_point="authorized_holiday_attendance")
			frappe.log_error(
				title=_("Authorised holiday attendance creation failed"),
				message=frappe.get_traceback(with_context=True),
			)
	if attendance_name:
		for name in (clock_in.name, clock_out.name):
			frappe.db.set_value("Employee Checkin", name, "attendance", attendance_name, update_modified=False)
		_sync_automatic_attendance_source(attendance_name)


def changed(doc, method=None):
	"""Invalidate only the affected employee's and authorised HR users' dashboards."""
	if frappe.flags.in_install or frappe.flags.in_migrate:
		return
	if doc.get("attendance") and doc.get("custom_entry_source") == "Automatic Clocking":
		_sync_automatic_attendance_source(doc.attendance)
	employees = {doc.employee}
	before = doc.get_doc_before_save()
	if before and before.employee:
		employees.add(before.employee)
	admins = {"Administrator"} | set(frappe.get_all("Has Role", filters={"role": ["in", list(ADMIN_ROLES)], "parenttype": "User"}, pluck="parent"))
	for employee in employees:
		person = frappe.get_doc("Employee", employee)
		recipients = {person.user_id} if person.user_id else set()
		for user in admins:
			if frappe.get_cached_value("User", user, "enabled") and frappe.has_permission("Employee", "read", doc=person, user=user) and frappe.has_permission("Employee Checkin", "read", doc=doc, user=user):
				recipients.add(user)
		for user in recipients:
			frappe.publish_realtime("karyo_clock_updated", {"employee": employee}, user=user, after_commit=True)


def _sync_automatic_attendance_source(attendance):
	"""Persist the ESS source label once an automatic punch is linked to Attendance."""
	if not attendance or not frappe.db.exists(
		"Employee Checkin", {"attendance": attendance, "custom_entry_source": "Automatic Clocking"}
	):
		return
	if frappe.db.get_value("Attendance", attendance, "custom_entry_source") == "Manual Input":
		return
	frappe.db.set_value("Attendance", attendance, {
		"custom_entry_source": "Automatic Clocking",
		"custom_attendance_remark": "Automatic (ESS Clock In/Out)",
	}, update_modified=False)


def mark_automatic_attendance(doc, method=None):
	_sync_automatic_attendance_source(doc.name)


def attendance_changed(doc, method=None):
	"""Refresh the same saved Attendance row on HR and employee dashboards."""
	if frappe.flags.in_install or frappe.flags.in_migrate:
		return
	employees = {doc.employee} if doc.get("employee") else set()
	before = doc.get_doc_before_save()
	if before and before.get("employee"):
		employees.add(before.employee)
	admins = {"Administrator"} | set(frappe.get_all(
		"Has Role",
		filters={"role": ["in", list(ADMIN_ROLES)], "parenttype": "User"},
		pluck="parent",
	))
	for employee in employees:
		person = frappe.get_doc("Employee", employee)
		recipients = {person.user_id} if person.user_id else set()
		for user in admins:
			if (
				frappe.get_cached_value("User", user, "enabled")
				and frappe.has_permission("Employee", "read", doc=person, user=user)
				and frappe.has_permission("Attendance", "read", doc=doc, user=user)
			):
				recipients.add(user)
		for user in recipients:
			frappe.publish_realtime(
				"karyo_attendance_updated",
				{
					"doctype": "Attendance",
					"name": doc.name,
					"employee": employee,
					"attendance_date": str(doc.attendance_date),
					"source": doc.get("custom_entry_source"),
					"deleted": method == "on_trash",
				},
				user=user,
				after_commit=True,
			)


@frappe.whitelist()
def attendance_times(names):
	"""Live first IN / last OUT for permission-visible attendance rows."""
	person = _own_employee()
	team_scope = _can_view_team_attendance()
	if not person and not team_scope:
		_own_employee(required=True)
	names = frappe.parse_json(names) if isinstance(names, str) else names
	if not isinstance(names, list) or len(names) > 500 or not all(isinstance(n, str) for n in names):
		frappe.throw(_("Invalid attendance rows."))
	if not names:
		return {}
	filters = {"name": ["in", names]}
	if not team_scope:
		filters["employee"] = person.name
	rows = frappe.get_list("Attendance", filters=filters,
		fields=["name", "employee", "employee_name", "attendance_date", "status", "shift", "in_time", "out_time", "late_entry",
			"karyo_late_entry_grace_minutes", "karyo_early_exit_grace_minutes", "karyo_grace_source", "karyo_scheduled_working_minutes",
			"attendance_request", "karyo_is_corrected", "custom_entry_source", "custom_attendance_remark"], limit_page_length=500)
	additional_hours = _additional_hours_by_employee_date(rows)
	bonuses = _attendance_bonuses_by_employee_date(rows)
	result = {}
	for row in rows:
		# Linked logs are authoritative. Unprocessed shift logs use the shift start
		# date, including an OUT after midnight, rather than the calendar date.
		times = frappe.db.sql("""
			select min(case when log_type='IN' then time end) as clock_in,
			max(case when log_type='OUT' then time end) as clock_out,
			max(case when custom_entry_source='Automatic Clocking' then 1 else 0 end) as automatic_clocking
			from `tabEmployee Checkin` where employee=%s and
			(attendance=%s or (coalesce(attendance, '')='' and
			date(coalesce(shift_start, time))=%s and coalesce(shift, '')=%s))
		""", (row.employee, row.name, row.attendance_date, row.shift or ""), as_dict=True)[0]
		clock_in, clock_out = times.clock_in or row.in_time, times.clock_out or row.out_time
		metrics = _attendance_metrics(row, clock_in, clock_out, row.employee)
		metrics.update(additional_hours.get(
			(row.employee, getdate(row.attendance_date)), _empty_additional_hours()
		))
		_set_complete_total_hours(metrics)
		metrics.update(bonuses.get(
			(row.employee, getdate(row.attendance_date)), _empty_attendance_bonuses()
		))
		from karyo.hr.attendance_rules import display_status
		automatic = bool(times.automatic_clocking or row.custom_entry_source == "Automatic Clocking")
		source = row.custom_entry_source or ("Automatic Clocking" if automatic else None)
		default_remark = {
			"Automatic Clocking": _("Automatic (ESS Clock In/Out)"),
			"Manual Input": _("Manually Adjusted"),
			"Attendance Import": _("Attendance Import"),
		}.get(source)
		result[row.name] = {"employee_name": row.employee_name, "clock_in": clock_in, "clock_out": clock_out,
			"attendance_date": row.attendance_date, "attendance_status": row.status,
			"entry_source": source,
			"remark": row.custom_attendance_remark or default_remark,
			"status": display_status(
				row.status,
				metrics.get("clock_in_status"),
				row.get("late_entry"),
				confirmed_present=bool(
					row.attendance_request
					or row.karyo_is_corrected
					or row.custom_entry_source in {"Manual Input", "Attendance Import"}
				),
			),
			**metrics}
	return result


def _empty_additional_hours():
	return {
		"overtime_hours": 0.0,
		"night_duty_hours": 0.0,
		"excess_hours": 0.0,
		"overtime_status": None,
		"night_duty_status": None,
		"excess_hours_status": None,
		"overtime_reason": None,
		"night_duty_reason": None,
		"excess_hours_reason": None,
		"additional_hours": 0.0,
	}


def _complete_total_hours(values):
	"""Return scheduled shift hours plus every approved additional-hour type."""
	from frappe.utils import flt

	additional_fields = ("overtime_hours", "excess_hours", "night_duty_hours")
	base = values.get("duty_hours")
	if base is None:
		base = values.get("hours")
	if base is None and not any(flt(values.get(field)) for field in additional_fields):
		return None
	return flt(flt(base) + sum(flt(values.get(field)) for field in additional_fields), 4)


def _set_complete_total_hours(values):
	values["total_hours"] = _complete_total_hours(values)
	return values


def _additional_hours_by_employee_date(attendance_rows):
	"""Return governed additional hours for the permission-visible attendance days."""
	from frappe.utils import flt, getdate

	scope = {
		(row.employee, getdate(row.attendance_date))
		for row in attendance_rows
		if row.get("employee") and row.get("attendance_date")
	}
	if not scope:
		return {}
	employees = tuple(sorted({employee for employee, _day in scope}))
	days = [day for _employee, day in scope]
	rows = frappe.db.sql(
		"""
		select employee, date(actual_start) as attendance_date,
			sum(case when claim_type='Overtime' then approved_hours else 0 end) as overtime_hours,
			sum(case when claim_type='Night Duty' then approved_hours else 0 end) as night_duty_hours,
			sum(case when claim_type='Excess Hours' then approved_hours else 0 end) as excess_hours,
			sum(case when claim_type='Overtime' then 1 else 0 end) as overtime_records,
			sum(case when claim_type='Night Duty' then 1 else 0 end) as night_duty_records,
			sum(case when claim_type='Excess Hours' then 1 else 0 end) as excess_hours_records,
			max(case when claim_type='Overtime' then eligibility_reason end) as overtime_reason,
			max(case when claim_type='Night Duty' then eligibility_reason end) as night_duty_reason,
			max(case when claim_type='Excess Hours' then eligibility_reason end) as excess_hours_reason
		from `tabPRB Overtime Authorization`
		where docstatus=1 and employee in %(employees)s
			and date(actual_start) between %(from_date)s and %(to_date)s
		group by employee, date(actual_start)
		""",
		{"employees": employees, "from_date": min(days), "to_date": max(days)},
		as_dict=True,
	)
	result = {}
	for row in rows:
		key = (row.employee, getdate(row.attendance_date))
		if key not in scope:
			continue
		values = {
			"overtime_hours": flt(row.overtime_hours),
			"night_duty_hours": flt(row.night_duty_hours),
			"excess_hours": flt(row.excess_hours),
			"overtime_status": "Eligible" if flt(row.overtime_hours) > 0 else "Not Eligible" if row.overtime_records else None,
			"night_duty_status": "Eligible" if flt(row.night_duty_hours) > 0 else "Not Eligible" if row.night_duty_records else None,
			"excess_hours_status": "Eligible" if flt(row.excess_hours) > 0 else "Not Eligible" if row.excess_hours_records else None,
			"overtime_reason": row.overtime_reason,
			"night_duty_reason": row.night_duty_reason,
			"excess_hours_reason": row.excess_hours_reason,
		}
		values["additional_hours"] = sum(values[field] for field in ("overtime_hours", "night_duty_hours", "excess_hours"))
		result[key] = values
	return result


def _empty_attendance_bonuses():
	return {
		"attendance_bonus": None,
		"attendance_bonus_status": None,
		"attendance_bonus_reason": None,
		"attendance_bonus_run": None,
		"attendance_bonus_source": None,
		"incentive_bonus": None,
		"incentive_bonus_status": None,
		"incentive_bonus_reason": None,
		"incentive_bonus_run": None,
		"incentive_bonus_source": None,
	}


def _attendance_bonuses_by_employee_date(attendance_rows):
	"""Project authoritative attendance-bonus components onto Attendance days.

	A payroll component is stored once in PRB Payroll Run and read everywhere
	else.  Submitted results take precedence over drafts; within the same state,
	the most recently calculated run wins.  This prevents combined and individual
	bonus runs from being added together for one employee and calculation date.
	"""
	from frappe.utils import flt, getdate

	scope = {
		(row.employee, getdate(row.attendance_date))
		for row in attendance_rows
		if row.get("employee") and row.get("attendance_date")
	}
	if not scope:
		return {}
	employees = tuple(sorted({employee for employee, _day in scope}))
	days = [day for _employee, day in scope]
	rows = frappe.db.sql(
		"""
		select r.employee, r.calculation_date as attendance_date,
			r.name as payroll_run, r.docstatus, r.modified,
			r.custom_entry_source, r.custom_eligibility_status,
			r.custom_eligibility_reason, c.component_code, c.amount
		from `tabPRB Payroll Run` r
		inner join `tabPRB Payroll Component` c on c.parent=r.name
		where r.docstatus<2 and r.employee in %(employees)s
			and r.calculation_date between %(from_date)s and %(to_date)s
			and c.component_code in ('ATTENDANCE_BONUS', 'INCENTIVE_ATTENDANCE')
		order by r.employee, r.calculation_date, c.component_code,
			r.docstatus desc, r.modified desc, r.name desc
		""",
		{"employees": employees, "from_date": min(days), "to_date": max(days)},
		as_dict=True,
	)
	result = {}
	seen = set()
	field_by_component = {
		"ATTENDANCE_BONUS": "attendance_bonus",
		"INCENTIVE_ATTENDANCE": "incentive_bonus",
	}
	for row in rows:
		key = (row.employee, getdate(row.attendance_date))
		field = field_by_component.get(row.component_code)
		selection = (*key, field)
		if key not in scope or not field or selection in seen:
			continue
		seen.add(selection)
		values = result.setdefault(key, _empty_attendance_bonuses())
		values[field] = flt(row.amount)
		values[f"{field}_status"] = row.custom_eligibility_status or (
			"Eligible" if flt(row.amount) > 0 else "Not Eligible"
		)
		values[f"{field}_reason"] = row.custom_eligibility_reason
		values[f"{field}_run"] = row.payroll_run
		values[f"{field}_source"] = row.custom_entry_source
	return result


def _attendance_metrics(row, clock_in, clock_out, employee):
	from datetime import datetime, timedelta
	from frappe.utils import get_datetime, getdate, get_time
	from hrms.hr.doctype.shift_assignment.shift_assignment import get_employee_shift
	from karyo.hr.roster import current_duty, shift_context

	start = get_datetime(clock_in) if clock_in else None
	end = get_datetime(clock_out) if clock_out else None
	result = {"hours": round((end - start).total_seconds() / 3600, 4) if start and end and end >= start else None,
		"lateness_minutes": None, "late_arrival_minutes": None, "early_departure_minutes": None,
		"clock_in_status": None, "clock_out_status": None, "shift": row.shift,
		"shift_code": None, "scheduled_start": None, "scheduled_end": None,
		"duty_hours": None, "roster_assignment": None, "shift_schedule_assignment": None,
		"shift_schedule": None, "work_pattern": None}
	# The dated, submitted Shift Assignment is authoritative.  It represents
	# either one generated roster duty or a direct Shift Type assignment.
	duty = current_duty(employee, row.attendance_date)
	shift_name = duty.shift_type if duty else row.shift
	if not shift_name:
		details = get_employee_shift(employee, start or get_datetime(str(row.attendance_date) + " 12:00:00"), consider_default_shift=True)
		shift_name = details.get("shift_type", {}).get("name") if details else None
	if not shift_name:
		return result
	shift = frappe.get_cached_doc("Shift Type", shift_name)
	context = shift_context(shift_name)
	scheduled_start = datetime.combine(
		getdate(row.attendance_date), get_time(duty.start_time if duty else shift.start_time)
	)
	scheduled_end = datetime.combine(
		getdate(row.attendance_date), get_time(duty.end_time if duty else shift.end_time)
	)
	if scheduled_end <= scheduled_start:
		scheduled_end += timedelta(days=1)
	result.update({
		"shift": shift_name,
		"shift_code": duty.shift_code if duty else context.shift_code,
		"scheduled_start": scheduled_start,
		"scheduled_end": scheduled_end,
		"duty_hours": duty.duty_hours if duty else context.duty_hours,
		"roster_assignment": duty.assignment if duty else None,
		"shift_schedule_assignment": duty.schedule_assignment if duty else None,
		"shift_schedule": duty.schedule if duty else None,
		"work_pattern": frappe.db.get_value("Employee", employee, "karyo_work_pattern"),
	})
	from karyo.hr.lateness import employee_grace_minutes, lateness_after_grace_threshold
	# Saved attendance keeps the policy used when it was processed. Unprocessed
	# clock rows use the current configuration, identically for HR and ESS.
	recorded = row.get("karyo_grace_source") or flt(row.get("karyo_scheduled_working_minutes")) > 0
	if recorded:
		start_grace, end_grace, source = (flt(row.karyo_late_entry_grace_minutes),
			flt(row.karyo_early_exit_grace_minutes), row.karyo_grace_source or "Recorded Grace")
	else:
		start_grace, end_grace, source = employee_grace_minutes(employee, shift)
	result.update(karyo_late_entry_grace_minutes=start_grace,
		karyo_early_exit_grace_minutes=end_grace, karyo_grace_source=source)
	# Display the full late arrival / early departure once the corresponding
	# grace threshold is crossed. Approved deduction snapshots remain separate.
	late_arrival = lateness_after_grace_threshold((start - scheduled_start).total_seconds() / 60, start_grace) if start else 0
	early_departure = lateness_after_grace_threshold((scheduled_end - end).total_seconds() / 60, end_grace) if end else 0
	if start or end:
		result.update(lateness_minutes=round(late_arrival + early_departure, 2),
			late_arrival_minutes=round(late_arrival, 2) if start else None,
			early_departure_minutes=round(early_departure, 2) if end else None)
	if start:
		result["clock_in_status"] = "Late" if start > scheduled_start + timedelta(minutes=start_grace) else "On-time"
	if end:
		result["clock_out_status"] = "Early" if end < scheduled_end - timedelta(minutes=end_grace) else "Late" if end > scheduled_end else "On-time"
	if not recorded:
		from frappe.utils import cint
		late_minutes = max(0, (start - scheduled_start).total_seconds() / 60 - start_grace) if start and cint(shift.enable_late_entry_marking) else 0
		early_minutes = max(0, (scheduled_end - end).total_seconds() / 60 - end_grace) if end and cint(shift.enable_early_exit_marking) else 0
		result.update(karyo_detected_late_entry_minutes=round(late_minutes, 2),
			karyo_detected_early_exit_minutes=round(early_minutes, 2),
			karyo_detected_late_minutes=round(late_minutes + early_minutes, 2))
	return result


@frappe.whitelist()
def attendance_clock_view(names, filters=None, from_date=None, to_date=None):
	"""Include saved punches awaiting attendance processing, including previous days."""
	from frappe.utils import today, evaluate_filters, getdate
	person = _own_employee()
	team_scope = _can_view_team_attendance()
	if not person and not team_scope:
		_own_employee(required=True)
	filters = frappe.parse_json(filters) if isinstance(filters, str) else (filters or [])
	records = attendance_times(names)
	# HR/admin lists share the employee table's live clock columns. Their native
	# Attendance list remains the permission-scoped source of rows; unprocessed
	# personal punches are only synthesised in self service.
	if team_scope:
		live_rows, live_records = _team_today_live_rows(filters)
		records.update(live_records)
		return {"records": records, "live_rows": live_rows}
	groups = frappe.db.sql("""
		select date(coalesce(shift_start,time)) as attendance_date, coalesce(shift,'') as shift,
		min(case when log_type='IN' then time end) as clock_in,
		max(case when log_type='OUT' then time end) as clock_out
		from `tabEmployee Checkin` where employee=%s and
		(coalesce(attendance,'')='' or date(time)=%s or date(shift_start)=%s)
		and (%s is null or date(coalesce(shift_start,time)) >= %s)
		and (%s is null or date(coalesce(shift_start,time)) <= %s)
		group by date(coalesce(shift_start,time)), coalesce(shift,'')
		order by attendance_date desc
		limit 500
	""", (person.name, today(), today(), from_date, getdate(from_date) if from_date else None, to_date, getdate(to_date) if to_date else None), as_dict=True)
	additional_hours = _additional_hours_by_employee_date([
		frappe._dict(employee=person.name, attendance_date=group.attendance_date) for group in groups
	])
	bonuses = _attendance_bonuses_by_employee_date([
		frappe._dict(employee=person.name, attendance_date=group.attendance_date) for group in groups
	])
	live_rows = []
	for group in groups:
		matching = frappe.get_list("Attendance", filters={"employee":person.name,
			"attendance_date":group.attendance_date,"docstatus":1},
			fields=["name","employee","employee_name","attendance_date","status","shift","docstatus","late_entry"], limit_page_length=20)
		matching = [r for r in matching if (r.shift or "") == group.shift or not r.shift or not group.shift]
		if matching:
			row = matching[0]
		else:
			row = frappe._dict(name="live-clock-"+str(group.attendance_date)+"-"+group.shift,
				employee=person.name, employee_name=person.employee_name,
				attendance_date=group.attendance_date,shift=group.shift,
				status="Clocked Out" if group.clock_out and (not group.clock_in or group.clock_out >= group.clock_in) else "Clocked In",
				docstatus=0, __clock_live=True)
		if not evaluate_filters(row, filters):
			continue
		metrics = _attendance_metrics(row,group.clock_in,group.clock_out,person.name)
		metrics.update(additional_hours.get(
			(person.name, getdate(row.attendance_date)), _empty_additional_hours()
		))
		_set_complete_total_hours(metrics)
		metrics.update(bonuses.get(
			(person.name, getdate(row.attendance_date)), _empty_attendance_bonuses()
		))
		from karyo.hr.attendance_rules import display_status
		records[row.name] = {"employee_name":person.employee_name,
			"attendance_date":row.attendance_date,"attendance_status":row.status,
			"status":display_status(row.status, metrics.get("clock_in_status"), row.get("late_entry")),
			"clock_in":group.clock_in,"clock_out":group.clock_out, **metrics}
		row.status = records[row.name]["status"]
		live_rows.append(row)
	return {"records":records,"live_rows":live_rows}
