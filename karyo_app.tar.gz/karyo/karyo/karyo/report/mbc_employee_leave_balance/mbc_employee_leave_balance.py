import frappe
from frappe import _
from frappe.utils import cint


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = ["1=1"]
	values = {}
	for field, expression in (
		("company", "e.company"),
		("department", "e.department"),
		("employee", "lb.employee"),
		("leave_code", "lb.leave_code"),
	):
		if filters.get(field):
			conditions.append(f"{expression} = %({field})s")
			values[field] = filters.get(field)
	if filters.get("leave_year"):
		conditions.append("lb.leave_year = %(leave_year)s")
		values["leave_year"] = cint(filters.leave_year)
	if filters.get("as_at_date"):
		conditions.append("lb.as_at_date <= %(as_at_date)s")
		values["as_at_date"] = filters.as_at_date

	data = frappe.db.sql(
		f"""
		select employee, employee_name, company, department, leave_year, leave_code,
			leave_type, leave_description, closing_balance, as_at_date,
			advance_sick_outstanding_days, advance_sick_recovery_required
		from (
			select lb.employee, lb.employee_name, e.company, e.department, lb.leave_year,
				lb.leave_code, lb.leave_type, lb.leave_description, lb.closing_balance,
				lb.as_at_date, lb.advance_sick_outstanding_days,
				lb.advance_sick_recovery_required,
				row_number() over (
					partition by lb.employee, lb.leave_year, lb.leave_code
					order by lb.as_at_date desc, lb.creation desc
				) as row_no
			from `tabLeave Balance` lb
			inner join `tabEmployee` e on e.name = lb.employee
			where {' and '.join(conditions)}
		) balances
		where row_no = 1
		order by employee_name, leave_code
		""",
		values,
		as_dict=True,
	)
	return _columns(), data, None, None, [
		{"label": _("Balance rows"), "value": len(data), "indicator": "Blue", "datatype": "Int"}
	]


def _columns():
	return [
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 135},
		{"fieldname": "employee_name", "label": _("Employee Name"), "width": 180},
		{"fieldname": "company", "label": _("Company"), "fieldtype": "Link", "options": "Company", "width": 110},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 145},
		{"fieldname": "leave_year", "label": _("Year"), "fieldtype": "Int", "width": 70},
		{"fieldname": "leave_code", "label": _("Leave Code"), "width": 95},
		{"fieldname": "leave_type", "label": _("Leave Type"), "fieldtype": "Link", "options": "Leave Type", "width": 170},
		{"fieldname": "leave_description", "label": _("Description"), "width": 195},
		{"fieldname": "closing_balance", "label": _("Available Balance"), "fieldtype": "Float", "width": 125},
		{"fieldname": "as_at_date", "label": _("As At"), "fieldtype": "Date", "width": 105},
		{"fieldname": "advance_sick_outstanding_days", "label": _("Advance Sick Outstanding"), "fieldtype": "Float", "width": 160},
		{"fieldname": "advance_sick_recovery_required", "label": _("Recovery Required"), "fieldtype": "Check", "width": 120},
	]
