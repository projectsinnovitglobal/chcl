import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.desk.payroll_drawer import record_tools
from karyo.payroll.screen_specs import ENTITIES
from karyo.payroll.statutory import delete_generated_result


class TestGeneratedResultActions(FrappeTestCase):
	def test_open_zero_result_can_edit_rule_and_delete_safely(self):
		scheme = frappe.db.get_value("Payroll Contribution Scheme", {}, "name")
		employee = frappe.db.get_value("Employee", {}, ["name", "company"], as_dict=True)
		if not scheme or not employee:
			self.skipTest("Contribution and employee fixtures are unavailable")
		cycle = frappe.get_doc(
			{
				"doctype": "Payroll Cycle", "company": employee.company,
				"payment_date": "2026-09-30", "status": "Processing",
			}
		)
		cycle.name = frappe.generate_hash(length=10)
		cycle.db_insert()
		result = frappe.get_doc(
			{
				"doctype": "Payroll Statutory Result", "payroll_cycle": cycle.name,
				"employee": employee.name, "company": employee.company,
				"result_type": "Employee Contribution", "rule_reference": scheme,
				"current_amount": 0,
				"status": "Applied", "calculation_hash": frappe.generate_hash(length=64),
			}
		).insert(ignore_permissions=True)

		tools = record_tools(result, ENTITIES[result.doctype])
		self.assertTrue(tools["can_edit"])
		self.assertEqual((tools["edit_doctype"], tools["edit_name"]), ("Payroll Contribution Scheme", scheme))
		self.assertTrue(tools["can_delete"])

		delete_generated_result(result.name, ignore_permissions=True)
		self.assertFalse(frappe.db.exists(result.doctype, result.name))
