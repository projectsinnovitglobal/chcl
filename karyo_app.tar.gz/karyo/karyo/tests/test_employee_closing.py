"""Employee closure is scoped, gated, idempotent and preserves the global workflow."""
import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.payroll.employee_closing import state, close_employees, guard_closed_slip
from karyo.payroll.completion import run_step


class TestEmployeeClosing(unittest.TestCase):
    def setUp(self):
        self.user=frappe.session.user
        frappe.set_user('Administrator');frappe.db.savepoint('employee_closing_test')
        self.patches=[]
        for target in ('frappe.sendmail','frappe.publish_realtime','karyo.payroll.payslip_notice.notify_on_close'):
            p=patch(target,return_value={});p.start();self.patches.append(p)
        day=frappe.copy_doc(frappe.get_doc('Payroll Pay Day',frappe.db.get_value('Payroll Pay Day',{'payroll_type':'Minor'},'name')))
        day.name='closing-'+uuid4().hex;day.pay_day_code=day.name;day.pay_period_label=day.name;day.status='Active';day.docstatus=0;day.db_insert()
        self.day_name=day.name
        self.cycle=frappe.get_doc({'doctype':'Payroll Cycle','company':day.company,'pay_day':day.name,'status':'Draft'}).insert()
        self.employees=frappe.get_all('Employee',filters={'company':day.company,'status':'Active'},pluck='name',limit_page_length=2)
        self.assertEqual(len(self.employees),2)
        p=patch('karyo.payroll.employee_closing.population',return_value=set(self.employees));p.start();self.patches.append(p)
        p=patch('karyo.payroll.employee_closing.loan_blocked',return_value=False);self.loan=p.start();self.patches.append(p)
        p=patch.object(type(self.cycle),'_validate_loan_reconciliation');p.start();self.patches.append(p)
        entry=frappe.get_doc({'doctype':'Payroll Entry','name':'closing-entry-'+uuid4().hex,'company':day.company,'karyo_payroll_cycle':self.cycle.name});entry.db_insert()
        self.entry_name=entry.name
        frappe.db.set_value('Payroll Cycle',self.cycle.name,{'status':'Approved','docstatus':1,'readiness_status':'Ready','payroll_entry':entry.name})
        self.cycle.reload();self.slips=[]
        for employee in self.employees:
            slip=frappe.get_doc({'doctype':'Salary Slip','name':'closing-slip-'+uuid4().hex,'employee':employee,'company':day.company,
                'payroll_entry':entry.name,'karyo_payroll_cycle':self.cycle.name,'docstatus':1,'gross_pay':1000,'net_pay':900});slip.db_insert();self.slips.append(slip)
            frappe.get_doc({'doctype':'Payroll Statutory Result','name':'closing-result-'+uuid4().hex,'payroll_cycle':self.cycle.name,
                'employee':employee,'result_type':'PAYE','status':'Applied'}).db_insert()

    def tearDown(self):
        frappe.set_user('Administrator');frappe.db.rollback(save_point='employee_closing_test')
        # Some close-payroll paths cross transaction boundaries. Remove the
        # deliberately prefixed fixture chain explicitly so running this module
        # against a site never leaves test Pay Days in the live setup list.
        cycle_name=getattr(getattr(self,'cycle',None),'name',None)
        if cycle_name:
            for doctype in ('Payroll Cycle Employee','Payroll Readiness Exception','Payroll Statutory Result'):
                frappe.db.delete(doctype,{'payroll_cycle':cycle_name})
            frappe.db.delete('Salary Slip',{'karyo_payroll_cycle':cycle_name})
            frappe.db.delete('Payroll Cycle',{'name':cycle_name})
        if getattr(self,'entry_name',None):
            frappe.db.delete('Payroll Entry',{'name':self.entry_name})
        if getattr(self,'day_name',None):
            frappe.db.delete('Payroll Pay Day',{'name':self.day_name})
        frappe.db.commit()
        for p in reversed(self.patches):p.stop()
        frappe.set_user(self.user)

    def test_single_repeat_group_and_final_cycle(self):
        first=close_employees(self.cycle.name,[self.employees[0]])
        self.assertEqual(first['closed'],self.employees[:1]);self.assertEqual(first['cycle_status'],'Approved')
        self.assertEqual(frappe.db.get_value('Payroll Cycle Employee', {
            'payroll_cycle':self.cycle.name,'employee':self.employees[0]}, 'status'), 'Closed')
        self.assertFalse(frappe.db.exists('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':self.employees[1],'closed_on':('is','set')}))
        self.assertEqual(close_employees(self.cycle.name,[self.employees[0]])['closed'],[])
        # Global Close Payroll cannot jump over the employee still open.
        with self.assertRaisesRegex(frappe.ValidationError,'Close all employees'):
            run_step(self.cycle.name,'Close Payroll')
        result=close_employees(self.cycle.name,self.employees)
        self.assertEqual(result['closed'],self.employees[1:]);self.assertEqual(result['cycle_status'],'Closed')
        self.assertEqual(state(frappe.get_doc('Payroll Cycle',self.cycle.name))['closed'],2)

    def test_mixed_batch_skips_blocked_and_rejects_unapproved(self):
        frappe.db.set_value('Salary Slip',self.slips[1].name,'docstatus',0)
        result=close_employees(self.cycle.name,self.employees)
        self.assertEqual(result['closed'],self.employees[:1]);self.assertEqual(result['blocked'][0]['employee'],self.employees[1])
        self.assertEqual(result['cycle_status'],'Approved')
        frappe.db.set_value('Payroll Cycle',self.cycle.name,{'status':'Input Open','docstatus':0})
        self.assertEqual(close_employees(self.cycle.name,self.employees)['closed'],[])

    def test_finance_permission_invalid_scope_and_slip_lock(self):
        with self.assertRaises(frappe.ValidationError):close_employees(self.cycle.name,['not-an-employee'])
        with patch('karyo.payroll.employee_closing.has_actor_role',return_value=False):
            with self.assertRaises(frappe.PermissionError):close_employees(self.cycle.name,self.employees)
        close_employees(self.cycle.name,self.employees[:1])
        with self.assertRaisesRegex(frappe.ValidationError,'payroll is closed'):guard_closed_slip(self.slips[0])
        guard_closed_slip(self.slips[1])
        old=frappe.get_doc('Payroll Cycle',self.cycle.name);self.cycle.status='Reopened';self.cycle._doc_before_save=old
        self.cycle._reset_employee_closures_on_reopen()
        guard_closed_slip(self.slips[0])

    def test_statutory_readiness_loans_and_final_guard(self):
        self.loan.return_value=True
        self.assertTrue(all('loan' in r['reason'] for r in state(self.cycle)['rows']))
        self.loan.return_value=False
        frappe.db.set_value('Payroll Statutory Result',{'payroll_cycle':self.cycle.name,'employee':self.employees[0]},'status','Reviewed')
        self.assertIn('Apply',state(self.cycle,[self.employees[0]])['rows'][0]['reason'])
        frappe.get_doc({'doctype':'Payroll Readiness Exception','name':'closing-exception-'+uuid4().hex,'payroll_cycle':self.cycle.name,
            'employee':self.employees[1],'severity':'Blocking','status':'Open','validation_code':'TEST','message':'Fix test prerequisite'}).db_insert()
        self.assertEqual(state(self.cycle,[self.employees[1]])['rows'][0]['exception_code'],'TEST')
        from karyo.payroll.completion import readiness_exception_details
        details=readiness_exception_details(self.cycle.name,'TEST',[self.employees[1]],employee_scope='closing')
        self.assertEqual(len(details),1)
        self.assertEqual(details[0].employee,self.employees[1])
        frappe.get_doc({'doctype':'Payroll Readiness Exception','name':'global-closing-'+uuid4().hex,'payroll_cycle':self.cycle.name,
            'severity':'Blocking','status':'Open','validation_code':'GLOBAL','message':'Cycle-wide requirement'}).db_insert()
        self.assertEqual(len(readiness_exception_details(self.cycle.name,'GLOBAL',[self.employees[0]],employee_scope='closing')),1)

        frappe.db.delete('Payroll Readiness Exception',{'payroll_cycle':self.cycle.name})
        frappe.db.set_value('Payroll Statutory Result',{'payroll_cycle':self.cycle.name},'status','Applied')
        with patch('karyo.payroll.completion.run_step',side_effect=frappe.ValidationError('Cycle reconciliation incomplete')):
            result=close_employees(self.cycle.name,self.employees)
        self.assertEqual(result['cycle_status'],'Approved');self.assertEqual(len(result['closed']),2)
        self.assertIn('reconciliation incomplete',result['final_reason'])

    def test_global_close_cannot_ignore_missing_employee(self):
        frappe.db.delete('Salary Slip', {'name':self.slips[1].name})
        with self.assertRaisesRegex(frappe.ValidationError, 'every employee'):
            run_step(self.cycle.name, 'Close Payroll')
        self.assertEqual(frappe.db.get_value('Payroll Cycle',self.cycle.name,'status'),'Approved')

    def test_filtered_screen_totals_and_protected_closure_record(self):
        from karyo.desk.payroll_management import screen_data
        data=screen_data('close',payroll_period='payday::'+self.cycle.pay_day,employees=[self.employees[0]])
        self.assertEqual(len(data['employees']),1)
        self.assertEqual(data['closing_scope']['summary']['net_pay'],900)
        self.assertEqual(data['statutory'][0]['employees'],1)
        self.assertEqual(data['statutory'][0]['reviewed'],1)
        close_employees(self.cycle.name,self.employees[:1])
        name=frappe.db.get_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':self.employees[0]},'name')
        doc=frappe.get_doc('Payroll Cycle Employee',name);doc.closed_on=None
        with self.assertRaises(frappe.ValidationError):doc.save()
        with self.assertRaises(frappe.ValidationError):frappe.delete_doc('Payroll Cycle Employee',name)
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):close_employees(self.cycle.name,self.employees)
