frappe.pages["overtime-register"].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({
		parent: wrapper,
		title: __("Overtime & Additional Hours"),
		single_column: true,
	});
	const state = {
		from_date: frappe.datetime.month_start(),
		to_date: frappe.datetime.month_end(),
		company: frappe.defaults.get_user_default("Company") || "",
		employee: "",
	};
	const $root = $('<div class="overtime-register-page">').appendTo(page.main);
	const esc = frappe.utils.escape_html;

	async function load() {
		$root.html(`<div class="text-muted p-4">${__("Loading additional hours…")}</div>`);
		try {
			const data = await frappe.xcall("karyo.payroll.overtime_process.register_context", state);
			render(data);
		} catch (error) {
			$root.html(`<div class="alert alert-danger">${esc(karyo.ui?.error_message(error, __("Could not load overtime.")) || __("Could not load overtime."))}</div>`);
		}
	}

	function render(data) {
		const totals = data.totals || {};
		const rows = data.summary || [];
		$root.html(`
			<div class="card mb-3"><div class="card-body">
				<div class="form-row align-items-end">
					<div class="col-md-2"><label>${__("From Date")}</label><input type="date" class="form-control ot-from" value="${esc(data.from_date || state.from_date)}"></div>
					<div class="col-md-2"><label>${__("To Date")}</label><input type="date" class="form-control ot-to" value="${esc(data.to_date || state.to_date)}"></div>
					<div class="col-md-3"><label>${__("Company")}</label><input type="text" class="form-control ot-company" value="${esc(state.company)}"></div>
					<div class="col-md-3"><label>${__("Employee")}</label><div class="ot-employee-link"></div><small class="text-muted ot-employee-name"></small></div>
					<div class="col-md-2"><button class="btn btn-primary btn-block ot-apply">${__("Apply")}</button></div>
				</div>
				<div class="mt-3 d-flex flex-wrap" style="gap:8px">
					<button class="btn btn-default btn-sm ot-new">${__("New Overtime / Night Duty / Excess Hours")}</button>
					<button class="btn btn-default btn-sm ot-payroll">${__("Open Payroll Overtime Process")}</button>
					<button class="btn btn-default btn-sm ot-attendance-report">${__("Monthly Attendance Report")}</button>
				</div>
			</div></div>
			<div class="row mb-3">
				${metric("Employees", totals.employees)}${metric("Records", totals.records)}${metric("Overtime", totals.overtime_hours, " hrs")}
				${metric("Night Duty", totals.night_duty_hours, " hrs")}${metric("Work on Holiday", totals.work_on_holiday_hours, " hrs")}
				${metric("Excess Hours", totals.excess_hours, " hrs")}${metric("Total Hours", totals.total_additional_hours, " hrs")}
			</div>
			<div class="card"><div class="card-body"><h4>${__("Employees with additional hours")}</h4>
				<div class="table-responsive"><table class="table table-bordered table-hover table-sm">
					<thead><tr><th>${__("Employee")}</th><th>${__("Name")}</th><th>${__("Overtime")}</th><th>${__("Night Duty")}</th><th>${__("Work on Holiday")}</th><th>${__("Excess Hours")}</th><th>${__("Total Hours")}</th><th>${__("Payroll Amount")}</th><th>${__("Payroll")}</th><th></th></tr></thead>
					<tbody>${rows.length ? rows.map(rowHtml).join("") : `<tr><td colspan="10" class="text-muted text-center p-4">${__("No additional-hours records in this period.")}</td></tr>`}</tbody>
				</table></div>
			</div></div>`);
		bind();
	}

	function metric(label, value, suffix = "") {
		return `<div class="col-md-3 col-lg mb-2"><div class="card h-100"><div class="card-body py-3"><small class="text-muted">${esc(__(label))}</small><div class="h4 mb-0">${esc(format_number(value || 0))}${suffix}</div></div></div></div>`;
	}

	function rowHtml(row) {
		return `<tr>
			<td><button class="btn btn-link btn-sm p-0 ot-employee-open" data-employee="${esc(row.employee)}">${esc(row.employee)}</button></td>
			<td>${esc(row.employee_name)}</td><td>${hours(row.overtime_hours)}</td><td>${hours(row.night_duty_hours)}</td>
			<td>${hours(row.work_on_holiday_hours)}</td><td>${hours(row.excess_hours)}</td><td><strong>${hours(row.total_additional_hours)}</strong></td>
			<td>${esc(format_currency(row.payroll_amount || 0))}</td><td>${esc(__(row.payroll_status || ""))}</td>
			<td><button class="btn btn-default btn-xs ot-records" data-employee="${esc(row.employee)}">${__("Records")}</button></td>
		</tr>`;
	}

	function hours(value) { return esc(format_number(value || 0, null, 2)); }

	function bind() {
		const employeeControl = frappe.ui.form.make_control({
			parent: $root.find(".ot-employee-link"),
			df: {fieldtype: "Link", fieldname: "employee", options: "Employee", placeholder: __("Select Employee")},
			render_input: true,
		});
		employeeControl.set_value(state.employee);
		const showEmployeeName = async () => {
			const employee = employeeControl.get_value();
			const result = employee ? await frappe.db.get_value("Employee", employee, "employee_name") : null;
			$root.find(".ot-employee-name").text(result?.message?.employee_name || "");
		};
		employeeControl.$input.on("change", showEmployeeName);
		showEmployeeName();
		$root.find(".ot-apply").on("click", () => {
			state.from_date = $root.find(".ot-from").val();
			state.to_date = $root.find(".ot-to").val();
			state.company = $root.find(".ot-company").val().trim();
			state.employee = employeeControl.get_value() || "";
			load();
		});
		$root.find(".ot-new").on("click", () => karyo.additional_hours.launch({employee: state.employee}));
		$root.find(".ot-payroll").on("click", () => frappe.set_route("payroll-management", "overtime"));
		$root.find(".ot-attendance-report").on("click", () => frappe.set_route("query-report", "Monthly Attendance Sheet"));
		$root.find(".ot-employee-open").on("click", function () { frappe.set_route("Form", "Employee", this.dataset.employee); });
		$root.find(".ot-records").on("click", function () {
			frappe.route_options = {employee: this.dataset.employee};
			frappe.set_route("List", "PRB Overtime Authorization");
		});
	}

	load();
};
