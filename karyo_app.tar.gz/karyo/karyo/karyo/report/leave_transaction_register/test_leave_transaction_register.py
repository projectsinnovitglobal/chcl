from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.leave_transaction_register.leave_transaction_register import execute


class TestLeaveTransactionRegister(FrappeTestCase):
	@patch("frappe.get_list")
	@patch("frappe.has_permission")
	def test_filters_and_output_columns(self, has_permission, get_list):
		get_list.return_value = [frappe._dict(name="LTX-1", employee="EMP-1")]
		columns, rows = execute({
			"employee": "EMP-1", "leave_code": "VAC01", "from_date": "2026-01-01",
			"to_date": "2026-01-31", "status": "Approved", "cancelled": "No",
		})
		has_permission.assert_called_once_with("Leave Transaction", "read", throw=True)
		filters = get_list.call_args.kwargs["filters"]
		self.assertEqual(filters["employee"], "EMP-1")
		self.assertEqual(filters["legacy_status"], "Approved")
		self.assertEqual(filters["cancelled"], 0)
		self.assertEqual(filters["end_date"], [">=", "2026-01-01"])
		self.assertEqual(filters["start_date"], ["<=", "2026-01-31"])
		self.assertEqual(rows[0].name, "LTX-1")
		self.assertIn("source_record_audit_ref", {column["fieldname"] for column in columns})
