frappe.pages["hr-reports"].on_page_load = function (wrapper) {
	const body = karyo.pages.scaffold(wrapper, {
		title: __("Reports"),
		subtitle: __("Filter the approved report catalogue and open a clean table report"),
		actions: [{ label: __("Open Analytics"), onclick: () => frappe.set_route("hr-analytics") }],
	});
	const host = $('<section class="karyo-report-catalogue">').appendTo(body);
	const filters = $(
		`<div class="report-catalogue-filters">
			<label class="report-catalogue-search"><span></span><input type="search" class="form-control"></label>
			<label><span></span><select class="form-control"><option value=""></option></select></label>
			<button type="button" class="btn btn-default report-catalogue-clear"></button>
		</div>`
	).appendTo(host);
	filters.find("label").eq(0).find("span").text(__("Search reports"));
	filters.find("input").attr({
		placeholder: __("Search by ID, report, purpose or module"),
		"aria-label": __("Search reports"),
	});
	filters.find("label").eq(1).find("span").text(__("Module"));
	filters.find("select").attr("aria-label", __("Filter by module"));
	filters.find("option").text(__("All modules"));
	filters.find(".report-catalogue-clear").text(__("Clear filters"));

	const count = $('<p class="report-catalogue-count text-muted" aria-live="polite">').appendTo(host);
	const table = $(
		`<div class="karyo-payroll-management hr-shared-table report-catalogue-table">
			<div class="pm-table-wrap">
				<table class="pm-table">
					<thead><tr><th></th><th></th><th></th><th></th><th></th></tr></thead>
					<tbody></tbody>
				</table>
			</div>
		</div>`
	).appendTo(host);
	[__("ID"), __("Report"), __("Module"), __("Purpose"), __("Action")].forEach((value, index) =>
		table.find("th").eq(index).text(value)
	);

	let rows = [];
	function render() {
		const search = filters.find("input").val().trim().toLowerCase();
		const group = filters.find("select").val();
		const selected = rows.filter((row) => {
			const searchable = [row.id, row.label, row.group, row.description, row.report]
				.filter(Boolean)
				.join(" ")
				.toLowerCase();
			return (!group || row.group === group) && (!search || searchable.includes(search));
		});
		count.text(__("{0} of {1} reports", [selected.length, rows.length]));
		const tbody = table.find("tbody").empty();
		for (const row of selected) {
			const tr = $("<tr>").appendTo(tbody);
			$('<td class="report-catalogue-id">').text(row.id || "—").appendTo(tr);
			$('<td class="report-catalogue-name">').text(row.label).appendTo(tr);
			$("<td>").text(row.group).appendTo(tr);
			$('<td class="report-catalogue-purpose">').text(row.description || "").appendTo(tr);
			$('<a class="btn btn-sm btn-primary">')
				.text(__("Open Report"))
				.attr({ href: row.route, "aria-label": __("Open {0}", [row.label]) })
				.appendTo($("<td>").appendTo(tr));
		}
		if (!selected.length) {
			$('<tr><td colspan="5" class="report-catalogue-empty"></td></tr>')
				.find("td")
				.text(__("No reports match the selected filters."))
				.end()
				.appendTo(tbody);
		}
	}

	filters.on("input change", "input,select", render);
	filters.find(".report-catalogue-clear").on("click", () => {
		filters.find("input").val("");
		filters.find("select").val("");
		render();
		filters.find("input").trigger("focus");
	});

	karyo.live.request(wrapper, {
		method: "karyo.desk.section_overview.get",
		args: { section: "hr-reports" },
		callback: (response) => {
			rows = (response.message?.widgets || []).flatMap((widget) =>
				(widget.items || []).map((item) => ({ ...item, group: widget.title }))
			);
			filters.find("option:not(:first)").remove();
			[...new Set(rows.map((row) => row.group))].forEach((group) =>
				$("<option>").val(group).text(group).appendTo(filters.find("select"))
			);
			render();
		},
	});
};
