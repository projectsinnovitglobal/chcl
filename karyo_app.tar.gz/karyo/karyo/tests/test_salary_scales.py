import unittest
from uuid import uuid4
from unittest.mock import patch
from types import SimpleNamespace

import frappe
from karyo.payroll.salary_scales import (
    allocation_options, bulk_salary_setup, employee_salary, generate_points,
    my_salary, resync_promoted_employee, salary_history,
)
from karyo.desk.payroll_drawer import record_form, record_save
from karyo.desk.payroll_screens import _list_block
from karyo.payroll.salary_scales import validate_salary_slip_base
from karyo.payroll.recurring import calculate_amount as calculate_recurring_amount
from karyo.setup.payroll_profiles import _sync_employee_category

FAR17 = [(16785,260),(17825,275),(18925,300),(19525,325),(21475,375),(22225,400),(23425,525),(26050,675),(27400,825),(34825,0)]


class TestSalaryScales(unittest.TestCase):
    def setUp(self):
        self.user=frappe.session.user;frappe.set_user('Administrator');frappe.db.savepoint('salary_scales_test')
        self.mail=patch('frappe.sendmail');self.mail.start();self.addCleanup(self.mail.stop)
        self.events=patch('frappe.publish_realtime');self.events.start();self.addCleanup(self.events.stop)
        self.uid=uuid4().hex[:10]
        assigned_employee = frappe.db.get_value('Salary Structure Assignment', {'docstatus': 1}, 'employee')
        filters = {'status': 'Active', **({'name': assigned_employee} if assigned_employee else {})}
        source=frappe.get_all('Employee',filters=filters,fields=['name','company'],limit=1)[0]
        self.source=source
        self.structure=frappe.db.get_value('Salary Structure Assignment',
            {'employee':source.name,'docstatus':1},'salary_structure',order_by='from_date desc, creation desc')
        self.income_tax_slab=frappe.db.get_value('Salary Structure Assignment',
            {'employee':source.name,'docstatus':1},'income_tax_slab',order_by='from_date desc, creation desc')
        self.employee=frappe.copy_doc(frappe.get_doc('Employee',source.name))
        self.employee.docstatus=0;self.employee.name='SALTEST-'+self.uid;self.employee.user_id=None;self.employee.grade=None
        self.employee.date_of_joining='2000-01-01';self.employee.relieving_date=None
        self.employee.karyo_prb_opted_in=0;self.employee.karyo_prb_grade=None;self.employee.karyo_prb_salary_point=None
        self.employee.karyo_prb_row3_salary=0
        for field in self.employee.meta.fields:
            if field.unique: self.employee.set(field.fieldname,None)
        self.employee.db_insert()
        self.currency=frappe.db.get_value('Company',source.company,'default_currency')
        self.scale=self.make_scale('FAR17-'+self.uid)
        self.scale.submit()
        self.grade=frappe.get_doc({'doctype':'Employee Grade','name':'GRADE-'+self.uid,'karyo_grade_description':'Driver',
            'karyo_salary_scales':[{'salary_scale':self.scale.name,'effective_from':'2026-01-01','effective_to':'2026-12-31'}]}).insert()

    def tearDown(self):
        frappe.set_user('Administrator');frappe.db.rollback(save_point='salary_scales_test')
        self.mail.stop();self.events.stop();frappe.set_user(self.user)

    def make_scale(self,code,bands=FAR17):
        return frappe.get_doc({'doctype':'Salary Scale','scale_code':code,'description':'FAR17 document example (test)',
            'scale_type':'Test','prb_year':2026,'currency':self.currency,'valid_from':'2026-01-01','valid_to':'2026-12-31',
            'lowest_salary':bands[0][0],'upper_salary':bands[-1][0],'source_reference':'Guide 1.0 test only',
            'bands':[{'salary':s,'increment':i} for s,i in bands]}).insert()

    def appointment(self,**kw):
        return frappe.get_doc({'doctype':'Employee Salary Appointment','employee':self.employee.name,'grade':self.grade.name,
            'effective_from':'2026-01-01','effective_to':'2026-12-31','salary_point':'1',
            'salary_structure':self.structure,'income_tax_slab':self.income_tax_slab,
            'authority_reference':'Isolated test',**kw})

    def test_far17_exact_38_points_and_recalculation(self):
        values=[r.salary for r in self.scale.points]
        self.assertEqual(len(values),38);self.assertEqual(values[:6],[16785,17045,17305,17565,17825,18100]);self.assertEqual(values[-1],34825)
        self.assertEqual(values,sorted(set(values)))
        first_step = frappe.db.get_value('Salary Scale Step',
            {'salary_scale': self.scale.name, 'step_sequence': 1}, 'increment_amount')
        top_step = frappe.db.get_value('Salary Scale Step',
            {'salary_scale': self.scale.name, 'step_sequence': 38}, 'increment_amount')
        self.assertEqual(first_step, 260)
        self.assertEqual(top_step, 0)
        flat=self.make_scale('FLAT-'+self.uid,[(100,0)])
        self.assertEqual(flat.point_count,1)
        draft=self.make_scale('CHANGE-'+self.uid,[(100,25),(200,0)])
        draft.bands[0].increment=50;draft.save()
        self.assertEqual([r.salary for r in draft.points],[100,150,200])
        draft.points[0].salary=999;draft.save();self.assertEqual(draft.points[0].salary,100)

    def test_flat_salary_skips_bands_points_and_salary_point_allocation(self):
        flat = frappe.get_doc({
            'doctype': 'Salary Scale', 'scale_code': 'FLAT-SALARY-' + self.uid,
            'description': 'Direct basic salary', 'scale_type': 'Flat Salary',
            'prb_year': 2026, 'currency': self.currency, 'basic_salary': 25000,
            'valid_from': '2026-01-01', 'valid_to': '2026-12-31',
            'source_reference': 'Flat salary test',
        }).insert()
        flat.submit()
        self.assertEqual((flat.lowest_salary, flat.upper_salary), (25000, 25000))
        self.assertEqual(flat.point_count, 0)
        self.assertFalse(flat.points)
        self.assertFalse(flat.bands)
        self.assertFalse(frappe.db.exists('Salary Scale Step', {'salary_scale': flat.name}))

        grade = frappe.get_doc({
            'doctype': 'Employee Grade', 'name': 'FLAT-GRADE-' + self.uid,
            'karyo_grade_description': 'Flat salary grade',
            'karyo_salary_scales': [{
                'salary_scale': flat.name, 'effective_from': '2026-01-01',
                'effective_to': '2026-12-31',
            }],
        }).insert()
        options = allocation_options(grade.name, '2026-06-01')
        self.assertTrue(options['flat_salary'])
        self.assertEqual(options['basic_salary'], 25000)
        self.assertFalse(options['points'])

        appointment = self.appointment(
            grade=grade.name, salary_point=None, basic_salary=25000,
        ).insert()
        self.assertEqual(appointment.basic_salary, 25000)
        self.assertFalse(appointment.salary_point)

    def test_increment_band_master_populates_scale_row_and_is_protected(self):
        first=frappe.get_doc({'doctype':'Salary Increment Band','band_code':'IB-START-'+self.uid,
            'description':'Starting band','salary_breakpoint':100,'increment_amount':25,'currency':self.currency,
            'effective_from':'2026-01-01','effective_to':'2026-12-31'}).insert()
        final=frappe.get_doc({'doctype':'Salary Increment Band','band_code':'IB-END-'+self.uid,
            'description':'Upper band','salary_breakpoint':200,'increment_amount':0,'currency':self.currency,
            'effective_from':'2026-01-01','effective_to':'2026-12-31'}).insert()
        scale=frappe.get_doc({'doctype':'Salary Scale','scale_code':'MASTER-'+self.uid,'description':'Master-backed scale',
            'scale_type':'Step Scale','prb_year':2026,'currency':self.currency,'valid_from':'2026-01-01','valid_to':'2026-12-31',
            'lowest_salary':100,'upper_salary':200,'source_reference':'Master band test',
            'bands':[{'increment_band':first.name,'salary':999,'increment':999},
                     {'increment_band':final.name,'salary':999,'increment':999}]}).insert()
        self.assertEqual((scale.bands[0].band_description,scale.bands[0].salary,scale.bands[0].increment),('Starting band',100,25))
        self.assertEqual([point.salary for point in scale.points],[100,125,150,175,200])
        scale.submit();first.increment_amount=50
        with self.assertRaises(frappe.ValidationError):first.save()

    def test_invalid_bands_and_duplicate_code(self):
        for bands in [[(100,30),(200,0)],[(100,-10),(200,0)],[(100,0),(200,0)],[(100,20),(100,20),(200,0)],[(100,25),(200,1)],[(100,25),(150,25),(140,25),(200,0)]]:
            with self.subTest(bands=bands),self.assertRaises(frappe.ValidationError):
                generate_points(100,200,[{'salary':s,'increment':i} for s,i in bands])
        for low,high in [(200,100),(-1,100),('NaN',100),(0,'Infinity')]:
            with self.assertRaises(frappe.ValidationError):generate_points(low,high,[{'salary':100,'increment':0}])
        self.assertEqual(generate_points('0.10','0.30',[{'salary':'0.10','increment':'0.10'},{'salary':'0.30','increment':0}])[-1]['salary'],0.3)
        with self.assertRaises(frappe.DuplicateEntryError):self.make_scale(self.scale.name)

    def test_grade_requires_approved_scale_and_nonoverlap(self):
        self.assertEqual(self.grade.karyo_grade_code, self.grade.name)
        self.assertEqual(self.grade.karyo_salary_scales[0].scale_description, self.scale.description)
        draft=self.make_scale('DRAFT-'+self.uid)
        self.grade.karyo_salary_scales[0].salary_scale=draft.name
        with self.assertRaises(frappe.ValidationError):self.grade.save()
        self.grade.reload();self.grade.append('karyo_salary_scales',{'salary_scale':self.scale.name,'effective_from':'2026-06-01','effective_to':'2026-08-31'})
        with self.assertRaises(frappe.ValidationError):self.grade.save()
        self.grade.reload();self.grade.karyo_salary_scales[0].effective_to='2027-01-01'
        with self.assertRaises(frappe.ValidationError):self.grade.save()
        options=allocation_options(self.grade.name,'2026-09-01');self.assertEqual(options['salary_scale'],self.scale.name);self.assertEqual(len(options['points']),38)
        self.assertEqual(options['points'][0]['salary'], 16785)
        self.assertEqual(options['points'][0]['increment_amount'], 260)
        self.assertEqual(options['points'][1]['increment_amount'], 260)
        self.assertEqual(options['points'][-1]['increment_amount'], 0)
        self.assertEqual(options['grade_description'], self.grade.karyo_grade_description)

    def test_grade_workspace_uses_code_description_and_salary_scale_linkage(self):
        payload = record_form('master-employee-grade', 'Employee Grade')
        self.assertEqual(payload['label'], 'Employee Grade Code')
        self.assertEqual(payload['sections'][0]['fields'][0]['label'], 'Grade Code')
        fields = {field['fieldname']: field for section in payload['sections'] for field in section['fields']}
        self.assertEqual(fields['karyo_grade_description']['label'], 'Grade Description')
        self.assertEqual(fields['karyo_employee_category']['label'], 'Employee Category / Grade Group')
        self.assertEqual(fields['karyo_is_active']['label'], 'Active?')
        self.assertEqual(fields['karyo_remarks']['label'], 'Remarks')
        table = next(row for row in payload['tables'] if row['fieldname'] == 'karyo_salary_scales')
        self.assertEqual(table['label'], 'Salary Scale')
        self.assertEqual(table['fields'][0]['options'], 'Salary Scale')
        grade_code = 'DRAWER-' + self.uid
        result = record_save('master-employee-grade', 'Employee Grade', {
            'record_name': grade_code,
            'karyo_grade_description': 'Drawer-linked grade',
            'karyo_salary_scales': [{
                'salary_scale': self.scale.name,
                'effective_from': '2026-01-01',
                'effective_to': '2026-12-31',
            }],
        }, is_admin=True)
        self.assertEqual(result['name'], grade_code)
        saved = frappe.get_doc('Employee Grade', grade_code)
        self.assertEqual(saved.karyo_grade_code, grade_code)
        self.assertEqual(saved.karyo_salary_scales[0].scale_description, self.scale.description)
        listing = _list_block('Employee Grade', filters={'name': self.grade.name})
        self.assertIn('Salary Scale Code', [column['label'] for column in listing['columns']])
        self.assertEqual(listing['rows'][0]['salary_scale_code'], self.scale.name)

    def test_grade_category_active_and_remarks_are_mapped(self):
        category = frappe.get_all(
            'Employee Category', filters={'disabled': 0},
            fields=['name', 'employment_type', 'category_name'], limit=1,
        )[0]
        self.grade.update({
            'karyo_employee_category': category.name,
            'karyo_remarks': 'Migration master note',
        })
        self.grade.save()
        options = allocation_options(self.grade.name, '2026-09-01')
        self.assertEqual(options['employee_category'], category.name)

        self.employee.reload()
        self.employee.grade = self.grade.name
        _sync_employee_category(self.employee)
        self.assertEqual(self.employee.karyo_employment_category, category.name)
        self.assertEqual(self.employee.employment_type, category.employment_type)
        self.assertEqual(self.employee.karyo_grade_description, self.grade.karyo_grade_description)

        frappe.db.set_value('Employee', self.employee.name, {
            'employment_type': category.employment_type,
            'karyo_employment_category': category.name,
        }, update_modified=False)
        on_payroll_before = self.employee.karyo_on_payroll
        category_doc = frappe.get_doc('Employee Category', category.name)
        leave_scheme = frappe.db.get_value('Leave Policy', {'docstatus': 1}, 'name')
        loan_group = frappe.db.get_value('Employee Loan Eligibility Group', {'disabled': 0}, 'name')
        contribution_group = frappe.db.get_value('Payroll Contribution Scheme', {'is_active': 1}, 'name')
        category_doc.update({
            'map_dependencies': 1,
            'pensionable': 1,
            'payroll_eligible': 1,
            'pb_eligibility_rule': 'Eligible',
            'leave_scheme': leave_scheme,
            'loan_eligibility_group': loan_group,
            'contribution_group': contribution_group,
        })
        category_doc.save()
        self.employee.reload()
        self.assertEqual(self.employee.karyo_payroll_eligible, 1)
        self.assertEqual(self.employee.karyo_permanent_pensionable, 1)
        self.assertEqual(self.employee.karyo_pb_eligibility_rule, 'Eligible')
        self.assertEqual(self.employee.pb_eligible, 1)
        self.assertEqual(self.employee.karyo_on_payroll, on_payroll_before)
        self.assertEqual(self.employee.karyo_leave_scheme, leave_scheme)
        self.assertEqual(self.employee.karyo_loan_eligibility_group, loan_group)
        self.assertEqual(self.employee.karyo_contribution_group, contribution_group)
        if leave_scheme:
            self.assertTrue(frappe.db.exists('Employee Leave Scheme Selection', {
                'parent': self.employee.name,
                'parenttype': 'Employee',
                'parentfield': 'karyo_leave_schemes',
                'leave_scheme': leave_scheme,
            }))

        self.grade.karyo_is_active = 0
        self.grade.save()
        with self.assertRaisesRegex(frappe.ValidationError, 'inactive'):
            allocation_options(self.grade.name, '2026-09-01')

    def test_appointment_updates_ctc_and_native_formula_base(self):
        template_name = frappe.db.get_value(
            'Salary Structure Assignment',
            {'company': self.employee.company, 'docstatus': 1},
            'name', order_by='from_date desc',
        )
        if not template_name:
            self.skipTest('A submitted salary structure assignment is required for this integration test.')
        assignment = frappe.copy_doc(frappe.get_doc('Salary Structure Assignment', template_name))
        assignment.update({
            'employee': self.employee.name, 'employee_name': self.employee.employee_name,
            'from_date': '2026-01-01', 'base': 1, 'docstatus': 0, 'amended_from': None,
        })
        assignment.insert().submit()
        appointment = self.appointment().insert()
        appointment.submit()
        latest = frappe.db.get_value(
            'Salary Structure Assignment',
            {'employee': self.employee.name, 'docstatus': 1},
            ['name', 'salary_structure', 'base'], as_dict=True,
            order_by='from_date desc, creation desc',
        )
        self.assertEqual(latest.base, 16785)
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'ctc'), 16785)
        slip = frappe._dict({
            'employee': self.employee.name, 'salary_structure': latest.salary_structure,
            'start_date': '2026-09-01', 'end_date': '2026-09-30', 'posting_date': '2026-09-30',
        })
        validate_salary_slip_base(slip)
        self.assertEqual(slip.karyo_salary_appointment, appointment.name)
        self.assertEqual(slip.karyo_salary_scale, self.scale.name)
        self.assertEqual(slip.karyo_salary_point, 1)
        self.assertEqual(slip.karyo_salary_base, 16785)
        frappe.db.set_value('Salary Structure Assignment', latest.name, 'base', 0, update_modified=False)
        with self.assertRaisesRegex(frappe.ValidationError, 'effective on'):
            validate_salary_slip_base(slip)
        frappe.db.set_value('Salary Structure Assignment', latest.name, 'base', 16785, update_modified=False)
        recurring = frappe._dict({
            'name': 'FORMULA-CHECK', 'employee': self.employee.name,
            'calculation_method': 'Formula', 'formula': 'base_salary * 0.10',
            'remaining_balance': 0, 'is_reducing_balance': 0,
        })
        cycle = frappe._dict({'company': self.employee.company, 'end_date': '2026-09-01'})
        self.assertEqual(calculate_recurring_amount(recurring, cycle), 1678.5)

    def test_single_or_multiple_employee_bulk_salary_setup(self):
        structure = frappe.db.get_value(
            'Salary Structure Assignment',
            {'employee': self.source.name, 'docstatus': 1},
            'salary_structure', order_by='from_date desc',
        )
        if not structure:
            self.skipTest('A submitted salary structure is required for this integration test.')
        income_tax_slab = frappe.db.get_value(
            'Salary Structure Assignment',
            {'employee': self.source.name, 'docstatus': 1},
            'income_tax_slab', order_by='from_date desc',
        )
        second = frappe.copy_doc(frappe.get_doc('Employee', self.source.name))
        second.docstatus = 0
        second.name = 'SALBULK-' + self.uid
        second.user_id = None
        second.grade = None
        second.date_of_joining = '2000-01-01'
        second.relieving_date = None
        second.karyo_prb_opted_in = 0
        second.karyo_prb_grade = None
        second.karyo_prb_salary_point = None
        second.karyo_prb_row3_salary = 0
        for field in second.meta.fields:
            if field.unique:
                second.set(field.fieldname, None)
        second.db_insert()

        result = bulk_salary_setup(
            [self.employee.name, second.name], self.grade.name, 2, '2026-01-01',
            'Bulk salary test', salary_structure=structure, income_tax_slab=income_tax_slab,
            effective_to='2026-12-31',
        )
        self.assertEqual(len(result['created']), 2, result)
        self.assertFalse(result['failed'])
        self.assertTrue(all(row['status'] == 'Completed' for row in result['created']))

        for employee in (self.employee.name, second.name):
            appointment = frappe.db.get_value(
                'Employee Salary Appointment', {'employee': employee, 'docstatus': 1},
                ['name', 'salary_scale', 'salary_point', 'basic_salary', 'salary_structure',
                 'salary_structure_assignment'], as_dict=True,
            )
            self.assertEqual(appointment.salary_scale, self.scale.name)
            self.assertEqual(int(appointment.salary_point), 2)
            self.assertEqual(appointment.basic_salary, 17045)
            assignment = frappe.db.get_value(
                'Salary Structure Assignment', {'employee': employee, 'docstatus': 1},
                ['name', 'salary_structure', 'base', 'karyo_salary_appointment',
                 'karyo_salary_scale', 'karyo_salary_point'], as_dict=True, order_by='from_date desc',
            )
            self.assertEqual(assignment.salary_structure, structure)
            self.assertEqual(assignment.base, 17045)
            self.assertEqual(appointment.salary_structure, assignment.salary_structure)
            self.assertEqual(appointment.salary_structure_assignment, assignment.name)
            self.assertEqual(assignment.karyo_salary_appointment, appointment.name)
            self.assertEqual(assignment.karyo_salary_scale, appointment.salary_scale)
            self.assertEqual(assignment.karyo_salary_point, int(appointment.salary_point))
            self.assertEqual(frappe.db.get_value('Employee', employee, 'ctc'), 17045)
        repeated = bulk_salary_setup(
            [self.employee.name, second.name], self.grade.name, 2, '2026-01-01',
            'Bulk salary test', salary_structure=structure, income_tax_slab=income_tax_slab,
            effective_to='2026-12-31',
        )
        self.assertFalse(repeated['failed'])
        self.assertTrue(all(row['status'] == 'Already complete' for row in repeated['created']))
        listing = _list_block('Employee Salary Appointment', filters={'employee':self.employee.name})
        self.assertEqual(listing['rows'][0]['_state'], 'Complete')
        self.assertIn('Status', [column['label'] for column in listing['columns']])

    def test_non_prb_employee_with_stale_legacy_grade_uses_salary_structure(self):
        from karyo.payroll.basic_salary import from_salary_structure
        frappe.db.set_value('Employee', self.source.name, {
            'karyo_prb_opted_in': 0,
            'karyo_prb_grade': 'Legacy imported PRB text',
            'karyo_prb_salary_point': None,
        }, update_modified=False)
        # This regression concerns stale PRB text, not the live site's
        # assignment history on a hard-coded September date.
        assignment_date = frappe.db.get_value('Salary Structure Assignment',
            {'employee': self.source.name, 'docstatus': 1}, 'from_date',
            order_by='from_date desc, creation desc')
        result = from_salary_structure(frappe._dict(
            employee=self.source.name,
            company=self.source.company,
            calculation_date=assignment_date,
        ))
        self.assertTrue(result)
        self.assertEqual(result['salary_structure'], self.structure)

    def test_payroll_setup_prb_profile_requires_grade_and_point_only_when_opted_in(self):
        from karyo.payroll.salary_scales import (
            PAYROLL_PROFILE_FIELDS, _payroll_setup_profile, _validate_employee_payroll_profile,
        )
        self.assertEqual(PAYROLL_PROFILE_FIELDS['prb_opted_in'], 'karyo_prb_opted_in')
        self.assertEqual(PAYROLL_PROFILE_FIELDS['prb_grade'], 'karyo_prb_grade')
        self.assertEqual(PAYROLL_PROFILE_FIELDS['prb_salary_point'], 'karyo_prb_salary_point')
        profile = _payroll_setup_profile({
            'prb_opted_in': 0, 'prb_grade': '', 'prb_salary_point': '',
        })
        self.assertEqual(profile['prb_opted_in'], 0)
        doc = frappe._dict(
            karyo_payroll_group='Monthly Payroll', karyo_payroll_type='Major',
            karyo_pay_day='Monthly', karyo_work_pattern='Standard', salary_mode='Other',
            karyo_prb_opted_in=1, karyo_prb_grade=None, karyo_prb_salary_point=None,
        )
        with self.assertRaisesRegex(frappe.ValidationError, 'PRB Grade, PRB Salary Point'):
            _validate_employee_payroll_profile(doc)
        doc.karyo_prb_grade = 'CS-GENERAL-WORKER'
        doc.karyo_prb_salary_point = '003'
        _validate_employee_payroll_profile(doc)

    def test_allocation_point_amount_and_period_validation(self):
        for kwargs in [{'salary_point':'39'},{'salary_point':'1.5'},{'basic_salary':1},{'effective_from':'2025-12-31'}, {'effective_to':'2027-01-01'}, {'effective_from':'2026-06-01','effective_to':'2026-05-01'}]:
            with self.subTest(kwargs=kwargs),self.assertRaises(frappe.ValidationError):self.appointment(**kwargs).insert()
        first=self.appointment(effective_to='2026-06-30').insert();first.submit()
        with self.assertRaises(frappe.ValidationError):self.appointment(effective_from='2026-06-30').insert()
        second=self.appointment(effective_from='2026-07-01',salary_point='2').insert();second.submit()
        self.assertEqual(second.basic_salary,17045)
        self.assertEqual(second.grade_description,'Driver')
        history=salary_history(self.employee.name);self.assertEqual(len(history['history']),2);self.assertEqual(history['current'].name,second.name)
        self.assertEqual(frappe.db.get_value('Employee',self.employee.name,'grade'),self.grade.name)
        self.assertEqual(frappe.db.get_value('Employee',self.employee.name,'ctc'),17045)
        frappe.db.set_value('Employee',self.employee.name,'ctc',1)
        resync_promoted_employee(frappe._dict(employee=self.employee.name))
        self.assertEqual(frappe.db.get_value('Employee',self.employee.name,'ctc'),17045)

    def test_history_and_approval_are_protected(self):
        appointment=self.appointment().insert();appointment.submit()
        self.assertEqual(appointment.approved_by,'Administrator');self.assertTrue(appointment.approved_on)
        appointment.basic_salary=1
        with self.assertRaises(frappe.ValidationError):appointment.save()
        self.grade.set('karyo_salary_scales',[])
        with self.assertRaises(frappe.ValidationError):self.grade.save()
        with self.assertRaises(frappe.ValidationError):self.scale.cancel()
        self.employee.reload();self.employee.grade=None
        with self.assertRaises(frappe.ValidationError):self.employee.save()

    def test_payroll_uses_dated_allocation_and_preserves_trace(self):
        first=self.appointment(effective_to='2026-06-30').insert();first.submit()
        second=self.appointment(effective_from='2026-07-01',salary_point='2').insert();second.submit()
        run=frappe.get_doc({'doctype':'PRB Payroll Run','employee':self.employee.name,'calculation_date':'2026-04-01','review_year':2026,'salary_point':'INVALID-LEGACY','increment_due':0})
        run._compute_basic();self.assertEqual(run.basic_salary,16785);self.assertEqual(run.karyo_salary_appointment,first.name);self.assertFalse(run.exception_code)
        run.calculation_date='2026-09-01';run._compute_basic();self.assertEqual(run.basic_salary,17045);self.assertEqual(run._basic_salary_source['appointment'],second.name)
        run.increment_due=1;run._compute_basic();self.assertEqual(run.exception_code,'INVALID_SALARY_APPOINTMENT')
        run.increment_due=0;run.calculation_date='2027-01-01';run._compute_basic();self.assertEqual(run.exception_code,'MISSING_SALARY_APPOINTMENT');self.assertEqual(run.basic_salary,0)
        run.calculation_date='2026-09-01';run.review_year=2025;run._compute_basic();self.assertEqual(run.exception_code,'INVALID_SALARY_APPOINTMENT')

    def test_close_period_and_block_used_payroll_changes(self):
        appointment=self.appointment().insert();appointment.submit()
        run=frappe.get_doc({'doctype':'PRB Payroll Run','name':'SAL-RUN-'+self.uid,'docstatus':0,'employee':self.employee.name,'calculation_date':'2026-09-01','karyo_salary_appointment':appointment.name})
        run.db_insert()
        appointment.effective_to='2026-08-31'
        with self.assertRaises(frappe.ValidationError):appointment.save()
        appointment.reload();appointment.effective_to='2026-09-30';appointment.save()
        with self.assertRaises(frappe.ValidationError):appointment.cancel()
        self.appointment(effective_from='2026-10-01',salary_point='2').insert()

    def test_cancellation_clears_current_salary_without_legacy_fallback(self):
        appointment=self.appointment().insert();appointment.submit();appointment.cancel()
        values=frappe.db.get_value('Employee',self.employee.name,['karyo_salary_appointment','karyo_scale_salary_point','karyo_scale_basic_salary','ctc'],as_dict=True)
        self.assertFalse(values.karyo_salary_appointment);self.assertEqual(values.karyo_scale_salary_point,0);self.assertEqual(values.karyo_scale_basic_salary,0);self.assertEqual(values.ctc,0)
        run=frappe.get_doc({'doctype':'PRB Payroll Run','employee':self.employee.name,'calculation_date':'2026-09-13','review_year':2026})
        run._compute_basic();self.assertEqual(run.exception_code,'MISSING_SALARY_APPOINTMENT')
        self.assertEqual(salary_history(self.employee.name)['history'][0].docstatus,2)

    def test_self_service_is_scoped_and_read_only(self):
        user=frappe.get_doc({'doctype':'User','email':'salary-'+self.uid+'@example.invalid','first_name':'Salary Test','send_welcome_email':0,'roles':[{'role':'Employee'}]}).insert(ignore_permissions=True)
        frappe.db.set_value('Employee',self.employee.name,'user_id',user.name)
        appointment=self.appointment().insert();appointment.submit()
        frappe.set_user(user.name)
        result=my_salary();self.assertEqual(result['current'].name,appointment.name)
        with self.assertRaises(frappe.PermissionError):employee_salary(self.employee.name)
        with self.assertRaises(frappe.PermissionError):allocation_options(self.grade.name,'2026-09-01')
        self.assertFalse(frappe.has_permission('Employee Salary Appointment','write'))
        self.assertFalse(frappe.has_permission('Employee Salary Appointment','read'))
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):my_salary()
