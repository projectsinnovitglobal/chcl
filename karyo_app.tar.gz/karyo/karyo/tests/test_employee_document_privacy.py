from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.security import loan_file_permission, validate_private_employee_file


class TestEmployeeDocumentPrivacy(FrappeTestCase):
	def test_employee_documents_cannot_be_public(self):
		file_doc = frappe._dict({
			"attached_to_doctype": "Employee",
			"attached_to_name": "HR-EMP-TEST",
			"attached_to_field": "passport",
			"is_private": 0,
		})
		with self.assertRaises(frappe.PermissionError):
			validate_private_employee_file(file_doc)

	def test_only_employee_and_hr_admin_can_read_employee_document(self):
		file_doc = frappe._dict({
			"attached_to_doctype": "Employee",
			"attached_to_name": "HR-EMP-TEST",
			"attached_to_field": "offer_letter",
		})
		with patch("karyo.security.frappe.get_roles", return_value=["Employee"]), \
			patch("karyo.security.frappe.db.get_value", return_value="HR-EMP-TEST"):
			self.assertTrue(loan_file_permission(file_doc, user="employee@example.test"))
		with patch("karyo.security.frappe.get_roles", return_value=["Employee"]), \
			patch("karyo.security.frappe.db.get_value", return_value="OTHER-EMPLOYEE"):
			self.assertFalse(loan_file_permission(file_doc, user="other@example.test"))
		with patch("karyo.security.frappe.get_roles", return_value=["HR Manager"]):
			self.assertIsNone(loan_file_permission(file_doc, user="hr@example.test"))
