import frappe
from frappe import _
from frappe.utils import getdate


def execute(filters=None):
	filters = frappe._dict(filters or {})
	loan_filters = {field: filters.get(field) for field in ("employee", "loan_type", "workflow_state") if filters.get(field)}
	if filters.loan:
		loan_filters["name"] = filters.loan
	loans = frappe.get_list("Karyo Loan", filters=loan_filters,
		fields=["name", "employee", "employee_name", "loan_type", "workflow_state", "approved_amount", "agreement_printed_on", "insurance_rate", "lien_required"],
		order_by="agreement_printed_on desc, creation desc", limit_page_length=0)
	loan_names = [loan.name for loan in loans]
	documents_by_loan = {}
	if loan_names:
		for document in frappe.get_all("Karyo Loan Document", filters={"parent": ("in", loan_names)},
			fields=["parent", "document_type", "attachment", "document_reference", "verified", "verified_by", "verified_on", "uploaded_by", "uploaded_on", "idx"],
			order_by="parent, idx desc", limit_page_length=0):
			documents_by_loan.setdefault(document.parent, []).append(document)
	rules = frappe.get_all("Loan Document Requirement", filters={"is_active": 1, "required_before": "Agreement"},
		fields=["loan_type", "document_type", "when_insurance_required", "when_lien_required"], limit_page_length=0)
	data = []
	for loan in loans:
		row = _agreement_row(frappe._dict(loan), documents_by_loan.get(loan.name, []), rules)
		if _matches(row, filters):
			data.append(row)
	summary = [
		{"label": _("Loans"), "value": len(data), "indicator": "Blue", "datatype": "Int"},
		{"label": _("Generated"), "value": sum(r.generated_status == "Generated" for r in data), "indicator": "Blue", "datatype": "Int"},
		{"label": _("Signed"), "value": sum(r.signed_status == "Signed" for r in data), "indicator": "Green", "datatype": "Int"},
		{"label": _("Missing Documents"), "value": sum(bool(r.missing_document_flag) for r in data), "indicator": "Orange", "datatype": "Int"},
	]
	return _columns(), data, None, None, summary


def _agreement_row(loan, documents=None, rules=None):
	if documents is None:
		documents = frappe.get_all("Karyo Loan Document", filters={"parent": loan.name},
			fields=["document_type", "attachment", "document_reference", "verified", "verified_by", "verified_on", "uploaded_by", "uploaded_on"], order_by="idx desc")
	agreements = [d for d in documents if d.document_type == "Agreement" and d.attachment]
	signed = agreements[0] if agreements else frappe._dict()
	required = _required_document_types(loan, rules)
	present = {d.document_type for d in documents if d.attachment}
	missing = sorted(required - present)
	generated = bool(loan.agreement_printed_on)
	return frappe._dict(loan=loan.name, employee=loan.employee, employee_name=loan.employee_name, loan_type=loan.loan_type,
		workflow_state=loan.workflow_state, approved_amount=loan.approved_amount, generated_on=loan.agreement_printed_on,
		generated_status="Generated" if generated else "Not Generated", template="MBC Loan Agreement" if generated else None,
		template_version=signed.get("document_reference") or ("Current" if generated else None),
		signed_status="Signed" if agreements else "Not Signed", signed_attachment=signed.get("attachment"),
		signed_on=signed.get("uploaded_on"), signed_by=signed.get("uploaded_by"),
		verified_status="Verified" if signed.get("verified") else "Pending Verification" if agreements else "Not Signed",
		verified_by=signed.get("verified_by"), verified_on=signed.get("verified_on"),
		missing_document_flag=1 if missing else 0, missing_documents=", ".join(missing))


def _required_document_types(loan, rules=None):
	if rules is None:
		filters = {"is_active": 1, "required_before": "Agreement", "loan_type": ("in", ["", loan.loan_type])}
		rules = frappe.get_all("Loan Document Requirement", filters=filters,
			fields=["document_type", "when_insurance_required", "when_lien_required"])
	result = set()
	for rule in rules:
		if rule.get("loan_type") not in (None, "", loan.loan_type):
			continue
		if rule.when_insurance_required and not loan.get("insurance_rate"):
			continue
		if rule.when_lien_required and not loan.get("lien_required"):
			continue
		result.add(rule.document_type)
	return result


def _matches(row, filters):
	for field in ("generated_status", "signed_status", "verified_status"):
		if filters.get(field) and row.get(field) != filters.get(field):
			return False
	if filters.missing_documents and not row.missing_document_flag:
		return False
	date = getdate(row.generated_on) if row.generated_on else None
	return not ((filters.from_date and (not date or date < getdate(filters.from_date))) or (filters.to_date and (not date or date > getdate(filters.to_date))))


def _columns():
	def c(fieldname, label, fieldtype="Data", width=120, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("loan", "Loan", "Link", 145, "Karyo Loan"), c("employee", "Employee", "Link", 125, "Employee"), c("employee_name", "Employee Name", width=160),
		c("loan_type", "Loan Type", "Link", 120, "Loan Type"), c("workflow_state", "Loan State", width=145), c("approved_amount", "Approved", "Currency"),
		c("generated_status", "Generated", width=105), c("generated_on", "Generated On", "Date", 105), c("template", "Template", width=155), c("template_version", "Template / Document Version", width=155),
		c("signed_status", "Signed", width=90), c("signed_attachment", "Signed Attachment", "Attach", 170), c("signed_by", "Uploaded By", "Link", 140, "User"), c("signed_on", "Uploaded On", "Date", 100),
		c("verified_status", "Verification", width=135), c("verified_by", "Verified By", "Link", 140, "User"), c("verified_on", "Verified On", "Datetime", 150),
		c("missing_document_flag", "Missing?", "Check", 80), c("missing_documents", "Missing Required Documents", width=220)]
