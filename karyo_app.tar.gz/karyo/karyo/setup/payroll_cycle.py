"""Central Payroll Cycle and its audit/detail records (PAY-020)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Payroll Cycle Step Log",
		istable=1,
		fields=[
			f("step", "Data", "Step", reqd=1, in_list_view=1),
			f(
				"status",
				"Select",
				"Status",
				options="Pending\nRunning\nCompleted\nFailed\nSkipped",
				default="Pending",
				reqd=1,
				in_list_view=1,
			),
			f("started_on", "Datetime", "Started On"),
			f("completed_on", "Datetime", "Completed On"),
			f("message", "Small Text", "Message"),
			f("reference_doctype", "Link", "Reference Type", options="DocType"),
			f("reference_name", "Dynamic Link", "Reference", options="reference_doctype"),
		],
	)
	make_doctype(
		"Payroll Cycle Validation Result",
		istable=1,
		fields=[
			f(
				"severity",
				"Select",
				"Severity",
				options="Blocking\nApproval Required\nWarning",
				reqd=1,
				in_list_view=1,
			),
			f("validation_code", "Data", "Code", reqd=1, in_list_view=1),
			f("employee", "Link", "Employee", options="Employee", in_list_view=1),
			f("message", "Small Text", "Message", reqd=1, in_list_view=1),
			f("is_resolved", "Check", "Resolved", default="0", in_list_view=1),
			f("resolution_note", "Small Text", "Resolution Note"),
			f("reference_doctype", "Link", "Reference Type", options="DocType"),
			f("reference_name", "Dynamic Link", "Reference", options="reference_doctype"),
		],
	)
	make_doctype(
		"Payroll Cycle Artifact",
		istable=1,
		fields=[
			f(
				"artifact_type",
				"Select",
				"Artifact Type",
				options="Report\nBank File\nStatutory File\nPayslip Batch\nReconciliation\nOther",
				reqd=1,
				in_list_view=1,
			),
			f("artifact_name", "Data", "Artifact", reqd=1, in_list_view=1),
			f(
				"status",
				"Select",
				"Status",
				options="Draft\nGenerated\nVerified\nReleased\nRevoked\nFailed",
				default="Draft",
				in_list_view=1,
			),
			f("file", "Attach", "File"),
			f("generated_on", "Datetime", "Generated On"),
			f("content_hash", "Data", "Content Hash"),
			f("reference_doctype", "Link", "Reference Type", options="DocType"),
			f("reference_name", "Dynamic Link", "Reference", options="reference_doctype"),
		],
	)
	make_doctype(
		"Payroll Cycle",
		is_submittable=1,
		title_field="pay_period_label",
		fields=[
			f("identity_sb", "Section Break", "Cycle Identity"),
			f("company", "Link", "Company", options="Company", reqd=1, in_list_view=1),
			f("pay_day", "Link", "Pay Day", options="Payroll Pay Day", reqd=1, in_list_view=1),
			f("payroll_period", "Link", "Payroll Period", options="Payroll Period", read_only=1),
			f("identity_cb", "Column Break"),
			f("payroll_type", "Data", "Payroll Type", read_only=1, in_list_view=1),
			f("pay_period_label", "Data", "Pay Period", read_only=1, in_list_view=1),
			f(
				"status",
				"Select",
				"Status",
				options="Draft\nInput Open\nProcessing\nReview\nApproved\nClosed\nReopened\nCancelled",
				default="Draft",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
				allow_on_submit=1,
			),
			f("dates_sb", "Section Break", "Pay Day Snapshot"),
			f("start_date", "Date", "Start Date", read_only=1),
			f("end_date", "Date", "End Date", read_only=1),
			f("payment_date", "Date", "Payment Date", read_only=1),
			f("dates_cb", "Column Break"),
			f("input_cutoff_date", "Date", "Input Cut-off Date", read_only=1),
			f("environment_mode", "Data", "Environment Snapshot", read_only=1),
			f("calculated_on", "Datetime", "Last Calculated On", read_only=1, allow_on_submit=1),
			f("config_sb", "Section Break", "Configuration Snapshot", collapsible=1),
			f("pdb_configuration", "Link", "PDB Catalogue", options="Payroll Configuration Version", read_only=1),
			f(
				"calendar_configuration",
				"Link",
				"Payroll Calendar",
				options="Payroll Configuration Version",
				read_only=1,
			),
			f("paye_configuration", "Link", "PAYE", options="Payroll Configuration Version", read_only=1),
			f("config_cb", "Column Break"),
			f(
				"contribution_configuration",
				"Link",
				"Contributions",
				options="Payroll Configuration Version",
				read_only=1,
			),
			f("bank_configuration", "Link", "Bank Export", options="Payroll Configuration Version", read_only=1),
			f(
				"statutory_configuration",
				"Link",
				"Statutory Export",
				options="Payroll Configuration Version",
				read_only=1,
			),
			f("configuration_snapshot", "Code", "Configuration Snapshot", options="JSON", read_only=1),
			f("processing_sb", "Section Break", "Processing"),
			f("payroll_entry", "Link", "Payroll Entry", options="Payroll Entry", allow_on_submit=1),
			f("employee_count", "Int", "Employees", read_only=1, allow_on_submit=1),
			f("exception_count", "Int", "Open Exceptions", read_only=1, allow_on_submit=1),
			f("totals_sb", "Section Break", "Control Totals", collapsible=1),
			f("gross_pay", "Currency", "Gross Pay", read_only=1, allow_on_submit=1),
			f("total_deductions", "Currency", "Total Deductions", read_only=1, allow_on_submit=1),
			f("net_pay", "Currency", "Net Pay", read_only=1, allow_on_submit=1),
			f("totals_cb", "Column Break"),
			f("employee_contributions", "Currency", "Employee Contributions", read_only=1, allow_on_submit=1),
			f("employer_contributions", "Currency", "Employer Contributions", read_only=1, allow_on_submit=1),
			f("paye_total", "Currency", "PAYE", read_only=1, allow_on_submit=1),
			f("approval_sb", "Section Break", "Review and Approval"),
			f("processed_by", "Link", "Processed By", options="User", read_only=1, allow_on_submit=1),
			f("reviewed_by", "Link", "Reviewed By", options="User", read_only=1, allow_on_submit=1),
			f("approved_by", "Link", "Approved By", options="User", read_only=1, allow_on_submit=1),
			f("approval_cb", "Column Break"),
			f("processed_on", "Datetime", "Processed On", read_only=1, allow_on_submit=1),
			f("reviewed_on", "Datetime", "Reviewed On", read_only=1, allow_on_submit=1),
			f("approved_on", "Datetime", "Approved On", read_only=1, allow_on_submit=1),
			f("details_sb", "Section Break", "Validation, Logs, and Artifacts"),
			f(
				"validation_results",
				"Table",
				"Validation Results",
				options="Payroll Cycle Validation Result",
				allow_on_submit=1,
			),
			f("step_logs", "Table", "Processing Log", options="Payroll Cycle Step Log", allow_on_submit=1),
			f("artifacts", "Table", "Generated Artifacts", options="Payroll Cycle Artifact", allow_on_submit=1),
		],
	)


def seed_demo_cycle():
	company = frappe.defaults.get_global_default("company")
	pay_day = frappe.db.get_value(
		"Payroll Pay Day",
		{"company": company, "payroll_type": "Major", "status": "Planned"},
		"name",
		order_by="start_date asc",
	)
	if not pay_day or frappe.db.exists("Payroll Cycle", {"pay_day": pay_day, "docstatus": ("<", 2)}):
		return
	frappe.get_doc(
		{
			"doctype": "Payroll Cycle",
			"company": company,
			"pay_day": pay_day,
			"status": "Draft",
		}
	).insert(ignore_permissions=True)


def add_downstream_links():
	create_custom_fields(
		{
			"Payroll Entry": [
				{
					"fieldname": "karyo_payroll_cycle",
					"fieldtype": "Link",
					"label": "Payroll Cycle",
					"options": "Payroll Cycle",
					"insert_after": "payroll_period",
					"read_only": 1,
				},
			],
			"Salary Slip": [
				{
					"fieldname": "karyo_payroll_cycle",
					"fieldtype": "Link",
					"label": "Payroll Cycle",
					"options": "Payroll Cycle",
					"insert_after": "payroll_entry",
					"read_only": 1,
				},
			],
			"PRB Payroll Run": [
				{
					"fieldname": "payroll_cycle",
					"fieldtype": "Link",
					"label": "Payroll Cycle",
					"options": "Payroll Cycle",
					"insert_after": "period",
				},
			],
		},
		ignore_validate=True,
	)


def setup():
	print("Karyo Payroll Cycle setup:")
	create_doctypes()
	add_downstream_links()
	from karyo.install import samples_enabled

	if samples_enabled():
		seed_demo_cycle()
	frappe.db.commit()
	print("Done (central Payroll Cycle, logs, validation results, and artifacts created).")
