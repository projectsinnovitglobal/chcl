from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.pending_lien_registration.pending_lien_registration import _enrich


class TestPendingLienRegistration(FrappeTestCase):
	@patch("karyo.karyo.report.pending_lien_registration.pending_lien_registration._required_documents", return_value={"Lien", "Registration"})
	@patch("frappe.get_all")
	def test_document_gaps_and_overdue_follow_up(self, get_all, _requirements):
		get_all.return_value = [frappe._dict(document_type="Lien", attachment="/private/files/lien.pdf", verified=1)]
		row = frappe._dict(loan="LOAN-1", loan_type="Vehicle Loan", date_applied="2026-09-01", creation="2026-09-01", lien_status="Pending", lien_return_reason=None)
		_enrich(row, "2026-09-10", 7)
		self.assertEqual(row.follow_up_status, "Overdue")
		self.assertEqual(row.age_days, 9)
		self.assertEqual(row.received_documents, "Lien")
		self.assertEqual(row.missing_documents, "Registration")

