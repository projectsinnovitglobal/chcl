"""Effective PRB 2026 salaries; Row 3 remains the full recommendation."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

import frappe
from frappe import _
from frappe.utils import getdate


def phase_percentage(effective_date):
    date = getdate(effective_date)
    return 0 if date < getdate('2026-01-01') else 50 if date < getdate('2027-01-01') else 100


def phased_salary(baseline, full_salary, effective_date):
    try:
        baseline, full = Decimal(str(baseline)), Decimal(str(full_salary))
        if not baseline.is_finite() or not full.is_finite() or baseline <= 0 or full < baseline:
            raise ValueError
    except (InvalidOperation, TypeError, ValueError):
        frappe.throw(_('PRB phases require a positive Row 2 (2025 salary) and a valid Row 3 salary at least equal to Row 2. Correct the PRB Salary Point master.'))
    percentage = phase_percentage(effective_date)
    amount = baseline + (full - baseline) * Decimal(percentage) / 100
    return float(amount.quantize(Decimal('.01'), rounding=ROUND_HALF_UP))


def phased_lookups(effective_date, review_year=2026):
    rows = frappe.get_all('PRB Salary Point', filters={'review_year': review_year},
        fields=['salary_point', 'gross_2025', 'revised_2026'], order_by='salary_point asc')
    return ({str(row.salary_point): phased_salary(row.gross_2025, row.revised_2026, effective_date)
             for row in rows}, [str(row.salary_point) for row in rows])


@frappe.whitelist()
def preview(employee, grade=None, salary_point=None):
    """Read-only comparison, including explicitly selected illustrative mappings."""
    from karyo.payroll.salary_scales import prb_allocation, require_admin

    require_admin()
    emp = frappe.get_doc('Employee', employee)
    emp.check_permission('read')
    grade = grade or emp.get('karyo_prb_grade')
    salary_point = salary_point or emp.get('karyo_prb_salary_point')
    if not grade or not salary_point:
        frappe.throw(_('Select a PRB Grade and Salary Point to preview both phases.'))
    allocation = prb_allocation(grade, salary_point, emp.company, '2026-01-01')
    baseline = frappe.db.get_value('PRB Salary Point', {
        'review_year': allocation['prb_year'], 'salary_point': str(salary_point)
    }, 'gross_2025')
    mapped = bool(emp.get('karyo_prb_opted_in') and grade == emp.get('karyo_prb_grade')
                  and str(salary_point) == str(emp.get('karyo_prb_salary_point')))
    return {
        'employee': employee, 'employee_name': emp.employee_name,
        'opted_in': bool(emp.get('karyo_prb_opted_in')), 'profile_mapping_matches': mapped,
        'grade': grade, 'salary_point': str(salary_point), 'review_year': allocation['prb_year'],
        'currency': allocation['currency'], 'baseline_salary': baseline,
        'recommended_salary': allocation['full_salary'],
        'total_increase': allocation['full_salary'] - baseline,
        'phases': [
            {'effective_from': date, 'percentage': phase_percentage(date),
             'basic_salary': phased_salary(baseline, allocation['full_salary'], date)}
            for date in ['2026-01-01', '2027-01-01']
        ],
        'notice': _('Preview only. No employee, appointment or payroll record is changed.'),
    }
