"""Controlled period-specific once-off PDB batches (PAY-031)."""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Once-Off PDB Line",
		istable=1,
		fields=[
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1),
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1, in_list_view=1),
			f("pdb_type", "Link", "PDB Type", options="Payroll PDB Type", read_only=1),
			f("salary_component", "Link", "Salary Component", options="Salary Component", read_only=1),
			f("amount", "Currency", "Amount", reqd=1, in_list_view=1),
			f("tax_treatment", "Select", "Tax Treatment", options="Standard\nTaxable\nExempt", read_only=1),
			f("transaction_reference", "Data", "Transaction Reference"),
			f("remarks", "Small Text", "Remarks"),
			f("business_key", "Data", "Business Key", read_only=1),
			f("additional_salary", "Link", "Additional Salary", options="Additional Salary", read_only=1),
			f(
				"allocation",
				"Link",
				"Transaction Allocation",
				options="Payroll Transaction Allocation",
				read_only=1,
			),
		],
	)
	make_doctype(
		"Once-Off PDB Batch",
		autoname="format:ONCE-{company_abbr}-.YYYY.-.#####",
		title_field="batch_description",
		fields=[
			f("company", "Link", "Company", options="Company", reqd=1, in_list_view=1),
			f("company_abbr", "Data", "Company Abbreviation", read_only=1, hidden=1),
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1),
			f("pay_period_label", "Data", "Pay Period", read_only=1, in_list_view=1),
			f("identity_cb", "Column Break"),
			f("batch_description", "Data", "Description", reqd=1),
			f(
				"status",
				"Select",
				"Status",
				options="Draft\nApproved\nPosted\nRejected\nCancelled",
				default="Draft",
				reqd=1,
				in_list_view=1,
				in_standard_filter=1,
			),
			f("amends", "Link", "Amends Batch", options="Once-Off PDB Batch", read_only=1),
			f("lines_sb", "Section Break", "Once-Off Transactions"),
			f("lines", "Table", "Transactions", options="Once-Off PDB Line", reqd=1),
			f("controls_sb", "Section Break", "Controls and Approval"),
			f("line_count", "Int", "Line Count", read_only=1),
			f("control_total", "Currency", "Control Total", read_only=1),
			f("approval_cb", "Column Break"),
			f("approved_by", "Link", "Approved By", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
			f("posted_by", "Link", "Posted By", options="User", read_only=1),
			f("posted_on", "Datetime", "Posted On", read_only=1),
			f("decision_reason", "Small Text", "Decision / Correction Reason"),
		],
	)


def add_permissions():
	meta = frappe.get_doc("DocType", "Once-Off PDB Batch")
	matrix = {
		"Payroll Input": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Processor": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Reviewer": {"read": 1, "write": 1, "report": 1},
		"Payroll Approver": {"read": 1, "write": 1, "report": 1},
		"Payroll Auditor": {"read": 1, "report": 1, "export": 1},
	}
	for role, values in matrix.items():
		row = next((permission for permission in meta.permissions if permission.role == role), None)
		if not row:
			row = meta.append("permissions", {"role": role})
		for fieldname, value in values.items():
			row.set(fieldname, value)
	meta.save(ignore_permissions=True)


def setup():
	print("Karyo once-off PDB setup:")
	create_doctypes()
	add_permissions()
	frappe.db.commit()
	print("Done (controlled once-off batch, lines, approval, and posting created).")
