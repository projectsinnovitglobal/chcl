import unittest
from unittest.mock import patch
import frappe
from karyo.hr import employee_attendance as api
from karyo.hr.clocking import _attendance_bonuses_by_employee_date, _complete_total_hours

class TestEmployeeAttendance(unittest.TestCase):
 def setUp(self):
  self.person=frappe._dict(name='OWN-EMPLOYEE',employee_name='Own Employee')
  self.identity=patch.object(api,'_own_employee',return_value=self.person)
  self.identity.start()
 def tearDown(self):self.identity.stop()
 def test_own_month_scope_and_live_rows_merge_without_duplicates(self):
  saved=frappe._dict(name='ATT-1',employee=self.person.name,attendance_date='2026-09-10',status='Present')
  live=frappe._dict(name='live-clock-2026-09-11',employee=self.person.name,attendance_date='2026-09-11',status='Clocked In',__clock_live=True)
  period=frappe._dict(start_date=frappe.utils.getdate('2026-08-26'),end_date=frappe.utils.getdate('2026-09-25'))
  with patch.object(api,'attendance_period_for_company',return_value=period),patch.object(frappe,'get_list',return_value=[saved]) as listing, patch.object(api,'attendance_clock_view',return_value={'records':{'ATT-1':{'hours':8}},'live_rows':[saved,live]}) as clocks:
   result=api.get_attendance(month='2026-09')
   self.assertEqual(listing.call_args_list[0].kwargs['filters']['employee'],self.person.name)
   self.assertEqual(listing.call_args_list[0].kwargs['filters']['docstatus'],1)
   self.assertEqual(str(clocks.call_args.kwargs['from_date']),'2026-08-26')
   self.assertEqual(str(clocks.call_args.kwargs['to_date']),'2026-09-25')
   self.assertEqual([r.name for r in result['rows']],[live.name,saved.name])
   self.assertEqual(result['rows'][1].hours,8)
 def test_period_comes_from_employee_pay_day_master(self):
  master=frappe._dict(name='MBC-MAJOR-25-ALL',pay_day_name='Major Pay Day (25)',company='MBC',day_of_month=25,is_active=1)
  with patch.object(frappe.db,'get_value',return_value=master):
   period=api.attendance_period_for_company('MBC','2026-09',master.name)
  self.assertEqual(str(period.start_date),'2026-08-26')
  self.assertEqual(str(period.end_date),'2026-09-25')
  self.assertEqual(str(period.payment_date),'2026-09-25')
  self.assertEqual(period.pay_day_master,master.name)
 def test_calendar_month_is_fallback_without_pay_day_master(self):
  with patch.object(frappe,'get_all',return_value=[]):
   period=api.attendance_period_for_company('MBC','2026-09')
  self.assertEqual(str(period.start_date),'2026-09-01')
  self.assertEqual(str(period.end_date),'2026-09-30')
  self.assertEqual(period.source,'Calendar Month')
 def test_status_is_applied_before_pagination(self):
  rows=[frappe._dict(name=f'ATT-{i:02}',attendance_date='2026-09-10',status='Present' if i<27 else 'Absent') for i in range(30)]
  with patch.object(frappe,'get_list',return_value=rows),patch.object(api,'attendance_clock_view',return_value={'records':{},'live_rows':[]}):
   result=api.get_attendance(month='2026-09',status='Present',start=25)
   self.assertEqual(result['total'],27)
   self.assertEqual(len(result['rows']),2)
   self.assertFalse(result['has_more'])
 def test_approved_present_correction_is_not_shown_as_awaiting_clock_in(self):
  saved=frappe._dict(name='ATT-APPROVED',employee=self.person.name,attendance_date='2026-09-10',status='Present',attendance_request='REQ-APPROVED',karyo_is_corrected=1)
  with patch.object(frappe,'get_list',return_value=[saved]),patch.object(api,'attendance_clock_view',return_value={'records':{'ATT-APPROVED':{'clock_in_status':None}},'live_rows':[]}):
   result=api.get_attendance(month='2026-09')
  self.assertEqual(result['rows'][0].status,'Present')
 def test_imported_present_attendance_is_confirmed_without_clock_logs(self):
  saved=frappe._dict(name='ATT-IMPORTED',employee=self.person.name,attendance_date='2026-09-10',status='Present',custom_entry_source='Attendance Import')
  records={'ATT-IMPORTED':{'clock_in_status':None,'entry_source':'Attendance Import','remark':'Attendance Import'}}
  with patch.object(frappe,'get_list',return_value=[saved]),patch.object(api,'attendance_clock_view',return_value={'records':records,'live_rows':[]}):
   result=api.get_attendance(month='2026-09')
  self.assertEqual(result['rows'][0].status,'Present')
  self.assertEqual(result['rows'][0].entry_source,'Attendance Import')
 def test_clock_timing_does_not_replace_saved_attendance_status(self):
  saved=frappe._dict(name='ATT-LATE',employee=self.person.name,attendance_date='2026-09-10',status='Present')
  records={'ATT-LATE':{'attendance_status':'Present','status':'Late','clock_in_status':'Late'}}
  with patch.object(frappe,'get_list',return_value=[saved]),patch.object(api,'attendance_clock_view',return_value={'records':records,'live_rows':[]}):
   result=api.get_attendance(month='2026-09')
  self.assertEqual(result['rows'][0].status,'Present')
  self.assertEqual(result['rows'][0].clock_in_status,'Late')
 def test_other_employee_detail_is_denied(self):
  with patch.object(frappe.db,'get_value',return_value='OTHER-EMPLOYEE'),self.assertRaises(frappe.PermissionError):
   api.get_record('FOREIGN-ATTENDANCE')
 def test_invalid_status_is_rejected(self):
  with self.assertRaises(frappe.ValidationError):api.get_attendance(month='2026-09',status='Unsupported')
 def test_summary_weights_half_days_and_excludes_unsubmitted_rows(self):
  rows=[frappe._dict(status='Present'),frappe._dict(status='Work From Home'),frappe._dict(status='Half Day'),frappe._dict(status='Absent')]
  with patch.object(frappe,'get_all',return_value=rows) as listing:
   result=api.attendance_summary(self.person.name,'2026-09-01','2026-09-30')
  self.assertEqual(listing.call_args.kwargs['filters']['docstatus'],1)
  self.assertEqual(result['present_days'],2.5)
  self.assertEqual(result['total'],4)
 def test_total_hours_include_shift_and_all_approved_additional_hours(self):
  row=frappe._dict(duty_hours=8,overtime_hours=2,excess_hours=1.5,night_duty_hours=0.5,hours=7.75)
  self.assertEqual(_complete_total_hours(row),12)
 def test_total_hours_fall_back_to_clocked_hours_when_no_shift_exists(self):
  row=frappe._dict(duty_hours=None,hours=6,overtime_hours=1,excess_hours=0,night_duty_hours=0)
  self.assertEqual(_complete_total_hours(row),7)
 def test_saved_correction_requests_are_returned_for_employee_table(self):
  request=frappe._dict(name='REQ-1',from_date='2026-09-10',to_date='2026-09-10',karyo_request_status='Pending Approval')
  with patch.object(frappe,'get_list',return_value=[]),patch.object(frappe,'get_all',return_value=[request]),patch.object(api,'attendance_clock_view',return_value={'records':{},'live_rows':[]}):
   result=api.get_attendance(month='2026-09')
  self.assertEqual([row.name for row in result['requests']],['REQ-1'])
 def test_overtime_bonus_view_is_scoped_to_own_employee(self):
  overtime=frappe._dict(claim_type='Overtime',planned_hours=4,approved_hours=3,docstatus=1,amount=435.76)
  bonus=frappe._dict(component_code='ATTENDANCE_BONUS',amount=2140)
  duty=frappe._dict(name='HDA-1',assignment_type='Acting')
  period=frappe._dict(start_date=frappe.utils.getdate('2026-08-26'),end_date=frappe.utils.getdate('2026-09-25'))
  with patch.object(api,'attendance_period_for_company',return_value=period), \
   patch.object(frappe.db,'get_value',return_value=frappe._dict(employee_name='Own Employee',employee_number='OWN-001',department='HR',company='MBC')), \
   patch.object(frappe.db,'sql',side_effect=[[overtime],[bonus]]) as query, \
   patch.object(frappe,'get_all',return_value=[duty]) as assignments:
   result=api.get_overtime_bonuses(month='2026-09')
  self.assertEqual(query.call_args_list[0].args[1]['employee'],self.person.name)
  self.assertEqual(query.call_args_list[1].args[1]['employee'],self.person.name)
  self.assertEqual(assignments.call_args.kwargs['filters']['employee'],self.person.name)
  self.assertEqual(result['summary']['overtime_hours'],3)
  self.assertEqual(result['summary']['assigned_overtime_hours'],4)
  self.assertEqual(result['summary']['bonus_total'],2140)
  self.assertEqual(result['time_rows'][0].claim_type,'Overtime')
  self.assertEqual(result['higher_duties'][0].name,'HDA-1')

 def test_my_payroll_additional_pay_excludes_pending_encashment_from_approved_amount(self):
  time_rows=[
   frappe._dict(name='OT-1',claim_type='Overtime',planned_hours=4,actual_hours=3,approved_hours=3,payroll_amount=435.76,docstatus=1),
   frappe._dict(name='EX-1',claim_type='Excess Hours',planned_hours=6,actual_hours=6,approved_hours=5,payroll_amount=400,docstatus=1),
  ]
  approved=frappe._dict(name='ENC-APP',encashment_date='2026-09-25',actual_encashable_days=10,
   encashment_days=1,karyo_encashment_rate_per_day=100,encashment_amount=100,currency='MUR',
   karyo_payroll_cycle='CYCLE-1',additional_salary='AS-1',docstatus=1,creation='2026-09-25')
  pending=frappe._dict(name='ENC-PENDING',encashment_date='2026-09-26',actual_encashable_days=9,
   encashment_days=2,karyo_encashment_rate_per_day=100,encashment_amount=200,currency='MUR',
   karyo_payroll_cycle='CYCLE-1',additional_salary=None,docstatus=0,creation='2026-09-26')
  salary=frappe._dict(name='AS-1',salary_component='Leave Encashment',amount=100,payroll_date='2026-09-30',docstatus=1)
  overtime={'employee':self.person.name,'employee_name':'Own Employee','company':'MBC','time_rows':time_rows,
   'from_date':'2026-08-26','to_date':'2026-09-25'}
  with patch.object(api,'get_overtime_bonuses',return_value=overtime), \
   patch.object(frappe,'get_all',side_effect=[[pending,approved],[salary]]) as listing, \
   patch.object(frappe.db,'get_value',return_value='LENC'):
   result=api.get_additional_pay_analytics(month='2026-09')
  self.assertEqual(listing.call_args_list[0].kwargs['filters']['employee'],self.person.name)
  self.assertEqual(result['additional_hours']['approved_hours'],8)
  self.assertEqual(result['additional_hours']['amount'],835.76)
  self.assertEqual(result['by_type']['Overtime']['approved_hours'],3)
  self.assertEqual(result['by_type']['Excess Hours']['approved_hours'],5)
  self.assertEqual(result['encashment']['approved_days'],1)
  self.assertEqual(result['encashment']['approved_amount'],100)
  self.assertEqual(result['encashment']['pending_requests'],1)
  self.assertEqual(result['encashment']['requested_days'],3)
  self.assertEqual(result['encashment']['latest_qualified_days'],9)
  self.assertEqual(result['encashment']['records'][0].request_status,'Pending approval')
  self.assertIn('1.0 day(s)',result['encashment']['records'][1].formula)

 def test_attendance_uses_one_authoritative_bonus_component_per_type(self):
  day='2026-09-21'
  rows=[
   frappe._dict(employee=self.person.name,attendance_date=day,component_code='ATTENDANCE_BONUS',amount=2140,payroll_run='SUBMITTED',custom_eligibility_status='Eligible',custom_eligibility_reason='Full award',custom_entry_source='Automatic Clocking'),
   frappe._dict(employee=self.person.name,attendance_date=day,component_code='ATTENDANCE_BONUS',amount=1070,payroll_run='DRAFT',custom_eligibility_status='Eligible',custom_eligibility_reason='Draft',custom_entry_source='Manual Input'),
   frappe._dict(employee=self.person.name,attendance_date=day,component_code='INCENTIVE_ATTENDANCE',amount=0,payroll_run='INCENTIVE',custom_eligibility_status='Not Eligible',custom_eligibility_reason='Leave threshold',custom_entry_source='Automatic Clocking'),
  ]
  with patch.object(frappe.db,'sql',return_value=rows):
   result=_attendance_bonuses_by_employee_date([frappe._dict(employee=self.person.name,attendance_date=day)])
  values=result[(self.person.name,frappe.utils.getdate(day))]
  self.assertEqual(values['attendance_bonus'],2140)
  self.assertEqual(values['attendance_bonus_run'],'SUBMITTED')
  self.assertEqual(values['incentive_bonus'],0)
  self.assertEqual(values['incentive_bonus_status'],'Not Eligible')
