"""Backfill the governed transaction register from all Leave Applications."""

from karyo.hr.leave_controls import sync_all_leave_transactions


def execute():
	sync_all_leave_transactions()
