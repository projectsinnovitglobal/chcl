"""Karyo Loan — Individual / Global Change of Interest (Phase 4E).

    bench --site dev.localhost execute karyo.setup.loan_interest_change.setup

Creates the Karyo Loan Interest Change transaction (revised rate on one active
loan, with a recomputed-interest preview) and the `enable_interest_change` toggle
on Karyo Settings. Per CF-010 these functions are DISABLED by default and blocked
unless the client enables them. The global batch runs the individual mechanism
over matching active loans (karyo...apply_global). Idempotent.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctype():
	make_doctype(
		"Karyo Loan Interest Change",
		is_submittable=1,
		autoname="naming_series:",
		title_field="loan",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="KLIC-.YYYY.-.#####",
				default="KLIC-.YYYY.-.#####",
			),
			f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
			f("employee", "Data", "Employee", read_only=1, in_list_view=1),
			f("loan_type", "Data", "Loan Type", read_only=1),
			f("cb1", "Column Break"),
			f("old_rate", "Percent", "Old Interest Rate", read_only=1),
			f("new_rate", "Percent", "New Interest Rate", reqd=1, in_list_view=1),
			f("effective_date", "Date", "Effective Date", reqd=1),
			f("reference", "Data", "Approval / Reference"),
			f("pos_sb", "Section Break", "Current Position"),
			f("outstanding_capital", "Currency", "Outstanding Capital", read_only=1),
			f("remaining_duration", "Int", "Remaining Duration (Months)", read_only=1),
			f("monthly_capital", "Currency", "Monthly Capital", read_only=1),
			f("current_monthly_interest", "Currency", "Current Monthly Interest", read_only=1),
			f("cb2", "Column Break"),
			f("monthly_insurance", "Currency", "Monthly Insurance", read_only=1),
			f("current_monthly_refund", "Currency", "Current Monthly Refund", read_only=1),
			f("prev_sb", "Section Break", "After New Rate"),
			f("new_total_interest", "Currency", "Recomputed Total Interest", read_only=1),
			f("new_monthly_interest", "Currency", "New Monthly Interest", read_only=1),
			f("cb3", "Column Break"),
			f("new_monthly_refund", "Currency", "New Monthly Refund", read_only=1),
			f("remarks_sb", "Section Break", "Remarks"),
			f("remarks", "Small Text", "Remarks", reqd=1),
		],
	)


def add_settings_toggle():
	create_custom_fields(
		{
			"Karyo Loan Interest Change": [
				{"fieldname": "prior_state_snapshot", "fieldtype": "Long Text", "label": "Prior State Snapshot", "read_only": 1, "hidden": 1, "insert_after": "remarks"},
				{"fieldname": "applied_schedule_version", "fieldtype": "Int", "label": "Applied Schedule Version", "read_only": 1, "insert_after": "prior_state_snapshot"},
				{"fieldname": "idempotency_key", "fieldtype": "Data", "label": "Idempotency Key", "read_only": 1, "unique": 1, "insert_after": "applied_schedule_version"},
				{"fieldname": "reversal_processed", "fieldtype": "Check", "label": "Reversal Processed", "read_only": 1, "insert_after": "idempotency_key"},
			],
			"Karyo Settings": [
				{
					"fieldname": "enable_interest_change",
					"fieldtype": "Check",
					"label": "Enable Change of Interest (Individual / Global)",
					"insert_after": "enable_loan_management",
					"description": "Disabled by default (CF-010). Enable only when the client requires interest-change functions.",
				}
			]
		},
		ignore_validate=True,
	)
	print("  + enable_interest_change toggle ensured")


def setup():
	print("Karyo Loan interest change setup:")
	create_doctype()
	add_settings_toggle()
	frappe.db.commit()
	print("Done.")
