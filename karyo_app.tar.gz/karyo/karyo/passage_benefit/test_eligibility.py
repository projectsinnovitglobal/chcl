from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.passage_benefit.eligibility import evaluate


class TestPassageBenefitEligibility(FrappeTestCase):
	def _settings(self, **overrides):
		values = {
			"eligibility_mode": "Confirmation only",
			"require_confirmation": 1,
			"require_permanent_employee": 1,
			"min_years_service": 5,
			"min_salary_threshold": 37290,
		}
		values.update(overrides)
		return frappe._dict(values)

	def _facts(self, **overrides):
		values = {
			"status": "Active",
			"pb_eligible": 1,
			"karyo_date_confirmed": "2020-06-01",
			"karyo_date_joined_service": "2015-01-01",
			"date_of_joining": "2015-01-01",
			"employment_type": "Permanent",
			"karyo_employment_category": None,
			"karyo_permanent_pensionable": 1,
		}
		values.update(overrides)
		return frappe._dict(values)

	def _evaluate(self, *, facts=None, salary=(40000, "2024-01-01"), settings=None, as_on="2026-04-30"):
		with (
			patch("karyo.passage_benefit.eligibility._employee_facts", return_value=facts or self._facts()),
			patch("karyo.passage_benefit.eligibility._salary_at", return_value=salary),
		):
			return evaluate("EMP-001", as_on, settings=settings or self._settings())

	def test_active_flag_confirmed_and_permanent_are_mandatory_gates(self):
		cases = (
			(self._facts(status="Left"), "employee_inactive"),
			(self._facts(pb_eligible=0), "flag_not_set"),
			(self._facts(karyo_date_confirmed=None), "not_confirmed"),
			(self._facts(employment_type="Contract"), "not_permanent"),
		)
		for facts, reason in cases:
			with self.subTest(reason=reason):
				self.assertEqual(self._evaluate(facts=facts).reason, reason)

	def test_confirmation_only_starts_on_confirmation_date(self):
		result = self._evaluate()
		self.assertTrue(result.eligible)
		self.assertEqual(result.eligibility_status, "Eligible")
		self.assertFalse(result.block_reason)
		self.assertTrue(all("reason" in rule for rule in result.rules))
		self.assertEqual(result.eligible_from_date.isoformat(), "2020-06-01")

	def test_failed_rule_exposes_not_eligible_status_and_block_reason(self):
		result = self._evaluate(facts=self._facts(pb_eligible=0))
		self.assertFalse(result.eligible)
		self.assertEqual(result.eligibility_status, "Not eligible")
		self.assertEqual(result.block_reason, result.message)
		failed = [rule for rule in result.rules if rule["blocking"]]
		self.assertEqual(failed[0]["code"], "pb_flag")
		self.assertIn("not set", failed[0]["reason"])

	def test_non_pensionable_or_non_permanent_staff_are_ineligible(self):
		for facts in (
			self._facts(karyo_permanent_pensionable=0),
			self._facts(employment_type="Contract", karyo_employment_category="CONT"),
			self._facts(employment_type="Temporary", karyo_employment_category="TEMP"),
		):
			with self.subTest(facts=facts):
				self.assertEqual(self._evaluate(facts=facts).reason, "not_permanent")

	def test_confirmation_date_remains_eligible_from_date_when_all_gates_pass(self):
		settings = self._settings(eligibility_mode="Salary and Service")
		result = self._evaluate(settings=settings, salary=(40000, "2024-01-01"))
		self.assertTrue(result.eligible)
		self.assertEqual(result.eligible_from_date.isoformat(), "2020-06-01")

	def test_service_uses_exact_anniversary(self):
		settings = self._settings(
			eligibility_mode="Minimum Service", require_confirmation=0, require_permanent_employee=0
		)
		facts = self._facts(karyo_date_joined_service="2021-05-01")
		self.assertFalse(self._evaluate(facts=facts, settings=settings, as_on="2026-04-30").eligible)
		result = self._evaluate(facts=facts, settings=settings, as_on="2026-05-01")
		self.assertTrue(result.eligible)
		self.assertEqual(result.eligible_from_date.isoformat(), "2026-05-01")

	def test_and_mode_starts_only_when_both_routes_are_effective(self):
		settings = self._settings(
			eligibility_mode="Salary and Service", require_confirmation=0, require_permanent_employee=0
		)
		result = self._evaluate(settings=settings, salary=(40000, "2024-01-01"))
		self.assertTrue(result.eligible)
		self.assertEqual(result.eligible_from_date.isoformat(), "2024-01-01")

	def test_or_mode_uses_first_successful_route_date(self):
		settings = self._settings(
			eligibility_mode="Salary or Service", require_confirmation=0, require_permanent_employee=0
		)
		result = self._evaluate(settings=settings, salary=(40000, "2024-01-01"))
		self.assertEqual(result.eligible_from_date.isoformat(), "2020-01-01")

	def test_or_mode_shows_failed_route_without_marking_it_as_blocking(self):
		settings = self._settings(
			eligibility_mode="Salary or Service", require_confirmation=0, require_permanent_employee=0
		)
		result = self._evaluate(settings=settings, salary=(10000, "2024-01-01"))
		self.assertTrue(result.eligible)
		salary_rule = next(rule for rule in result.rules if rule["code"] == "salary_threshold")
		self.assertFalse(salary_rule["eligible"])
		self.assertFalse(salary_rule["blocking"])

	def test_salary_lookup_is_as_of_reference_date(self):
		with patch("karyo.passage_benefit.eligibility.frappe.db.get_value") as get_value:
			get_value.return_value = frappe._dict(base=40000, from_date="2026-01-01")
			from karyo.passage_benefit.eligibility import _salary_at

			_salary_at("EMP-001", "2026-04-30")
			filters = get_value.call_args.args[1]
			self.assertEqual(filters["from_date"], ["<=", "2026-04-30"])
