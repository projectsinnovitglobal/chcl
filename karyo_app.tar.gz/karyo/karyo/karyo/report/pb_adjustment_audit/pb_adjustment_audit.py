# Copyright (c) 2026, AstraFlow and contributors
# For license information, please see license.txt

"""PB Adjustment Audit (§9.2 #5) — track manual balance corrections.

Minimum fields (BRD §9.2): old values, new values, user, date/time, remarks
(approval if applicable). Old/new balances come from the PB-ADJ-004 snapshot.
"""

import frappe


def execute(filters=None):
	filters = frappe._dict(filters or {})
	return _columns(), _data(filters)


def _columns():
	return [
		{
			"label": "Adjustment",
			"fieldname": "adjustment",
			"fieldtype": "Link",
			"options": "Passage Benefit Adjustment",
			"width": 160,
		},
		{"label": "Posting Date", "fieldname": "posting_date", "fieldtype": "Date", "width": 100},
		{
			"label": "Employee",
			"fieldname": "employee",
			"fieldtype": "Link",
			"options": "Employee",
			"width": 110,
		},
		{"label": "Employee Name", "fieldname": "employee_name", "fieldtype": "Data", "width": 160},
		{"label": "Balance Before", "fieldname": "balance_before", "fieldtype": "Currency", "width": 130},
		{"label": "Adjustment", "fieldname": "amount", "fieldtype": "Currency", "width": 120},
		{"label": "Balance After", "fieldname": "balance_after", "fieldtype": "Currency", "width": 130},
		{"label": "User", "fieldname": "owner", "fieldtype": "Link", "options": "User", "width": 150},
		{"label": "Recorded At", "fieldname": "modified", "fieldtype": "Datetime", "width": 160},
		{"label": "Docstatus", "fieldname": "status", "fieldtype": "Data", "width": 90},
		{"label": "Remarks", "fieldname": "remarks", "fieldtype": "Small Text", "width": 240},
	]


def _data(filters):
	conditions = {"docstatus": ["<", 2]}
	if filters.get("employee"):
		conditions["employee"] = filters.employee
	if filters.get("from_date") and filters.get("to_date"):
		conditions["posting_date"] = ["between", [filters.from_date, filters.to_date]]
	elif filters.get("from_date"):
		conditions["posting_date"] = [">=", filters.from_date]
	elif filters.get("to_date"):
		conditions["posting_date"] = ["<=", filters.to_date]

	rows = frappe.get_all(
		"Passage Benefit Adjustment",
		filters=conditions,
		fields=[
			"name as adjustment",
			"posting_date",
			"employee",
			"employee_name",
			"balance_before",
			"amount",
			"balance_after",
			"owner",
			"modified",
			"docstatus",
			"remarks",
		],
		order_by="posting_date desc, modified desc",
	)
	for r in rows:
		r["status"] = {0: "Draft", 1: "Submitted", 2: "Cancelled"}.get(r.pop("docstatus"), "")
	return rows
