"""Confirmation uses native calculation without persisting payroll records."""
import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.desk.payroll_management import preview_employee_payslip


class TestPayslipConfirmation(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('confirmation_test')
        source = frappe.get_doc('Salary Structure Assignment', frappe.db.get_value(
            'Salary Structure Assignment', {'docstatus': 1, 'salary_structure': 'Karyo Demo Structure'}, 'name'))
        employee = frappe.copy_doc(frappe.get_doc('Employee', source.employee))
        employee.name = 'confirmation-' + uuid4().hex
        employee.user_id = None
        employee.karyo_legacy_employee_id = None
        employee.status = 'Active'
        employee.docstatus = 0
        employee.date_of_joining = '2015-01-01'
        employee.relieving_date = None
        employee.db_insert()
        self.employee = employee
        for day in range(1, 31):
            frappe.get_doc({'doctype': 'Attendance', 'name': 'confirmation-' + uuid4().hex,
                'employee': employee.name, 'company': employee.company, 'docstatus': 1,
                'attendance_date': f'2026-06-{day:02}', 'status': 'Present'}).db_insert()
        assignment = frappe.copy_doc(source)
        assignment.name = 'confirmation-' + uuid4().hex
        assignment.employee = employee.name
        assignment.from_date = '2015-01-01'
        assignment.docstatus = 1
        slab = frappe.copy_doc(frappe.get_doc('Income Tax Slab', frappe.db.get_value('Income Tax Slab', {'docstatus': 1}, 'name')))
        slab.name = 'confirmation-tax-' + uuid4().hex
        slab.effective_from = '2015-01-01'
        slab.docstatus = 1
        slab.db_insert()
        for child in slab.get_all_children():
            child.parent = slab.name
            child.docstatus = 1
            child.name = 'confirmation-tax-row-' + uuid4().hex
            child.db_insert()
        assignment.income_tax_slab = slab.name
        assignment.db_insert()
        self.cycle = frappe._dict(name='confirmation-run', company=employee.company,
            start_date='2026-06-01', end_date='2026-06-30', payroll_entry=None)
        self.context = patch('karyo.desk.payroll_management.payslip_generation_context',
                             return_value={'selected': self.cycle, 'ready': False})
        self.context_mock = self.context.start()

    def tearDown(self):
        self.context.stop()
        frappe.db.rollback(save_point='confirmation_test')
        frappe.set_user(self.user)

    def preview(self):
        return preview_employee_payslip('2025-2026 (MBC)', self.cycle.name, self.employee.name)

    def test_native_preview_does_not_save_and_uses_assigned_structure(self):
        before = frappe.db.count('Salary Slip')
        result = self.preview()
        slip = result['slip']
        self.assertFalse(result['existing'])
        self.assertEqual(slip['employee'], self.employee.name)
        self.assertEqual(slip['salary_structure'], 'Karyo Demo Structure')
        self.assertTrue(slip['earnings'])
        self.assertAlmostEqual(slip['net_pay'], slip['gross_pay'] - slip['total_deduction'], places=2)
        self.assertEqual(frappe.db.count('Salary Slip'), before)
        self.assertFalse(slip.get('name'))

    def test_missing_assignment_and_guest_are_rejected(self):
        frappe.db.delete('Salary Structure Assignment', {'employee': self.employee.name})
        with self.assertRaisesRegex(frappe.ValidationError, 'Assign an active'):
            self.preview()
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            self.preview()
        frappe.set_user('Administrator')

    def test_native_side_effect_is_rolled_back_on_error(self):
        def fail(doc, *args, **kwargs):
            frappe.db.set_value('Employee', self.employee.name, 'employee_name', 'Preview side effect')
            raise RuntimeError('calculation failed')
        with patch('hrms.payroll.doctype.salary_slip.salary_slip.SalarySlip.validate', fail):
            with self.assertRaisesRegex(RuntimeError, 'calculation failed'):
                self.preview()
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'employee_name'), self.employee.employee_name)

    def test_period_without_run_previews_selected_month_without_saving(self):
        period = 'confirmation-period-' + uuid4().hex
        frappe.get_doc({'doctype': 'Payroll Period', 'name': period, 'docstatus': 0,
            'company': self.employee.company, 'start_date': '2026-06-01',
            'end_date': '2026-06-30'}).db_insert()
        self.context_mock.return_value = {'selected': None, 'preview_months': ['2026-06'],
                                         'preview_month': '2026-06'}
        before = frappe.db.count('Salary Slip')
        result = preview_employee_payslip(period, employee=self.employee.name)
        self.assertTrue(result['slip']['earnings'])
        self.assertIsNone(result['slip'].get('karyo_payroll_cycle'))
        self.assertEqual(str(result['slip']['start_date']), '2026-06-01')
        self.assertEqual(frappe.db.count('Salary Slip'), before)
        with self.assertRaises(frappe.ValidationError):
            preview_employee_payslip(period, employee=self.employee.name, month='2026-07')

    def test_calculation_blocker_returns_structure_with_pending_totals(self):
        with patch('hrms.payroll.doctype.salary_slip.salary_slip.SalarySlip.validate',
                   side_effect=frappe.ValidationError('Income Tax Slab not set')):
            result = self.preview()
        self.assertIn('Income Tax Slab', result['calculation_error'])
        self.assertTrue(result['slip']['earnings'])
        self.assertIsNone(result['slip']['net_pay'])
        self.assertIsNone(result['slip']['gross_pay'])
