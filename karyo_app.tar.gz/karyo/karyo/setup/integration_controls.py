"""Governed external-integration profiles and execution evidence."""

import frappe

from karyo.setup.foundation import f, make_doctype
from karyo.setup.migration import permission


PROFILE_PERMISSIONS = [
	permission("System Manager", read=1, write=1, create=1, delete=1, report=1, export=1),
	permission("Integration Manager", read=1, write=1, create=1, report=1, export=1),
	permission("Payroll Auditor", read=1, report=1, export=1),
]
EVENT_PERMISSIONS = [
	permission("System Manager", read=1, create=1, report=1, export=1),
	permission("Integration Manager", read=1, create=1, report=1, export=1),
	permission("Payroll Auditor", read=1, report=1, export=1),
]


def create_doctypes():
	make_doctype(
		"MBC Integration Profile",
		autoname="field:integration_code",
		naming_rule="By fieldname",
		fields=[
			f("integration_code", "Data", "Integration Code", reqd=1, unique=1, in_list_view=1),
			f("integration_name", "Data", "Integration Name", reqd=1, in_list_view=1),
			f("integration_type", "Select", "Type", options="Attendance\nNotification\nBank\nFinance / GL\nStatutory\nOther", reqd=1, in_list_view=1),
			f("direction", "Select", "Direction", options="Inbound\nOutbound\nBidirectional", reqd=1),
			f("status", "Select", "Status", options="Draft\nApproved\nActive\nInactive", default="Draft", reqd=1, in_list_view=1),
			f("connection_sb", "Section Break", "Connection and Security"),
			f("endpoint_url", "Data", "Endpoint URL"),
			f("authentication_type", "Select", "Authentication", options="None\nAPI Key\nBasic\nOAuth 2.0\nMutual TLS\nSFTP Key\nManaged Adapter", reqd=1),
			f("credential_reference", "Data", "Secret/Credential Reference"),
			f("encryption_required", "Check", "Encryption Required", default="1"),
			f("timeout_seconds", "Int", "Timeout Seconds", default="30", reqd=1),
			f("maximum_retries", "Int", "Maximum Retries", default="3", reqd=1),
			f("retry_backoff_seconds", "Int", "Retry Backoff Seconds", default="60", reqd=1),
			f("control_sb", "Section Break", "Control and Approval"),
			f("reconciliation_required", "Check", "Reconciliation Required", default="1"),
			f("source_reference", "Data", "Source Specification"),
			f("approval_reference", "Data", "Approval Reference"),
			f("owner_role", "Link", "Operational Owner Role", options="Role", reqd=1),
			f("failure_recipient", "Data", "Failure Recipient / Route"),
		],
	)
	make_doctype(
		"MBC Integration Event",
		autoname="field:idempotency_key",
		naming_rule="By fieldname",
		fields=[
			f("idempotency_key", "Data", "Idempotency Key", reqd=1, unique=1, in_list_view=1),
			f("integration_profile", "Link", "Integration Profile", options="MBC Integration Profile", reqd=1, in_list_view=1),
			f("occurred_on", "Datetime", "Occurred On", reqd=1, in_list_view=1),
			f("status", "Select", "Status", options="Started\nSucceeded\nFailed\nReconciled", reqd=1, in_list_view=1),
			f("attempt", "Int", "Attempt", default="1", reqd=1),
			f("control_sb", "Section Break", "Reconciliation"),
			f("source_count", "Int", "Source Count", read_only=1),
			f("target_count", "Int", "Target Count", read_only=1),
			f("source_total", "Currency", "Source Total", read_only=1),
			f("target_total", "Currency", "Target Total", read_only=1),
			f("difference", "Currency", "Difference", read_only=1),
			f("evidence_sb", "Section Break", "Evidence"),
			f("source_reference", "Data", "Source/Message Reference", reqd=1),
			f("payload_checksum", "Data", "Payload SHA-256"),
			f("error_message", "Small Text", "Error Message"),
			f("reconciliation_reference", "Data", "Reconciliation Reference"),
		],
	)


def configure_security():
	for role in ("Integration Manager", "Payroll Auditor"):
		if not frappe.db.exists("Role", role):
			frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1}).insert(ignore_permissions=True)
	for doctype, permissions in (
		("MBC Integration Profile", PROFILE_PERMISSIONS),
		("MBC Integration Event", EVENT_PERMISSIONS),
	):
		meta = frappe.get_doc("DocType", doctype)
		meta.set("permissions", permissions)
		meta.save(ignore_permissions=True)


def setup():
	print("Karyo integration controls setup:")
	create_doctypes()
	configure_security()
	frappe.db.commit()
	print("Done (approved profiles, retry/security policy and event reconciliation created).")
