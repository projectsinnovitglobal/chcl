import frappe
from frappe import _
from frappe.utils import getdate, nowdate


REQUIRED_TYPES = (
	"PDB Catalogue",
	"Operation Codes",
	"PAYE",
	"Contribution",
	"Payroll Calendar",
	"Bank Export",
	"Statutory Export",
	"PRB Grade Scale",
	"Leave Rules",
	"Attendance Rules",
	"Passage Benefit Rules",
	"Loan Rules",
	"Loan Insurance",
	"Loan Operation Codes",
)

LOAN_MASTERS = {
	"Loan Type": ("Loan Rules", "loan_code", "start_date", "end_date"),
	"Loan Condition": ("Loan Rules", "name", "start_date", "end_date"),
	"Loan Insurance Rate": ("Loan Insurance", "name", "effective_date", None),
	"Loan Operation Code": ("Loan Operation Codes", "operation_code", None, None),
	"Loan Recomputation Parameter": ("Loan Rules", "name", "start_date", "end_date"),
	"Loan Approval Authority": ("Loan Rules", "name", "start_date", "end_date"),
	"Loan Document Requirement": ("Loan Rules", "name", "start_date", "end_date"),
}


def execute(filters=None):
	filters = frappe._dict(filters or {})
	on_date = getdate(filters.get("on_date") or nowdate())
	company = filters.get("company")
	rows = frappe.get_all(
		"Payroll Configuration Version",
		filters={"company": company} if company else {},
		fields=[
			"name",
			"config_key",
			"configuration_type",
			"version",
			"configuration_status",
			"is_production_eligible",
			"effective_from",
			"effective_to",
			"source_reference",
			"approval_reference",
		],
		order_by="configuration_type, config_key, effective_from desc",
	)
	data = [_assess(row, on_date) for row in rows]
	data.extend(_loan_master_rows(on_date))
	active_types = {row.configuration_type for row in data if row.readiness == "Ready"}
	for configuration_type in REQUIRED_TYPES:
		if configuration_type not in active_types:
			data.append(
				frappe._dict(
					configuration_type=configuration_type,
					readiness="Missing",
					blocking_reason=_("No active approved configuration for the selected date."),
				)
			)
	return _columns(), data


def _loan_master_rows(on_date):
	data = []
	for doctype, (configuration_type, key_field, from_field, to_field) in LOAN_MASTERS.items():
		meta = frappe.get_meta(doctype)
		if not meta.has_field("configuration_status"):
			continue
		fields = ["name", key_field, "configuration_status", "configuration_version", "is_production_eligible", "source_reference", "approval_reference"]
		for fieldname in (from_field, to_field):
			if fieldname and fieldname not in fields:
				fields.append(fieldname)
		for source in frappe.get_all(doctype, fields=fields):
			row = frappe._dict(
				name=source.name,
				configuration_type=configuration_type,
				config_key=f"{doctype}: {source.get(key_field)}",
				version=source.configuration_version,
				configuration_status=source.configuration_status,
				is_production_eligible=source.is_production_eligible,
				effective_from=source.get(from_field) if from_field else None,
				effective_to=source.get(to_field) if to_field else None,
				source_reference=source.source_reference,
				approval_reference=source.approval_reference,
			)
			data.append(_assess(row, on_date))
	return data


def _assess(row, on_date):
	reasons = []
	if row.configuration_status != "Active" or not row.is_production_eligible:
		reasons.append(_("Not Active"))
	if row.effective_from and getdate(row.effective_from) > on_date:
		reasons.append(_("Not yet effective"))
	if row.effective_to and getdate(row.effective_to) < on_date:
		reasons.append(_("Expired"))
	if not row.source_reference:
		reasons.append(_("Missing source reference"))
	if not row.approval_reference:
		reasons.append(_("Missing approval reference"))
	row.readiness = "Blocked" if reasons else "Ready"
	row.blocking_reason = "; ".join(reasons)
	return row


def _columns():
	return [
		{"fieldname": "readiness", "label": _("Readiness"), "fieldtype": "Data", "width": 90},
		{"fieldname": "configuration_type", "label": _("Type"), "fieldtype": "Data", "width": 150},
		{"fieldname": "config_key", "label": _("Configuration"), "fieldtype": "Data", "width": 210},
		{"fieldname": "version", "label": _("Version"), "fieldtype": "Data", "width": 100},
		{"fieldname": "configuration_status", "label": _("Status"), "fieldtype": "Data", "width": 100},
		{"fieldname": "effective_from", "label": _("Effective From"), "fieldtype": "Date", "width": 110},
		{"fieldname": "effective_to", "label": _("Effective To"), "fieldtype": "Date", "width": 110},
		{"fieldname": "source_reference", "label": _("Source"), "fieldtype": "Data", "width": 180},
		{"fieldname": "approval_reference", "label": _("Approval"), "fieldtype": "Data", "width": 180},
		{"fieldname": "blocking_reason", "label": _("Blocking Reason"), "fieldtype": "Data", "width": 280},
	]
