import csv
from pathlib import Path
import unittest


APP_ROOT = Path(__file__).resolve().parents[2]
PHASE_DIR = APP_ROOT / "docs" / "phase-7"


class TestPhase7ReadinessAssets(unittest.TestCase):
	def test_report_catalogue_has_unique_complete_control_rows(self):
		with (PHASE_DIR / "report-catalogue.csv").open(newline="", encoding="utf-8") as handle:
			rows = list(csv.DictReader(handle))

		self.assertGreaterEqual(len(rows), 30)
		self.assertEqual(len(rows), len({row["report_id"] for row in rows}))
		for row in rows:
			for field in (
				"module",
				"report_name",
				"classification",
				"implementation",
				"business_owner",
				"purpose",
				"default_filters",
				"control_totals",
				"export_schedule",
				"security",
				"signoff_status",
			):
				self.assertTrue(row[field].strip(), f"{row['report_id']} has no {field}")

	def test_execution_templates_have_required_evidence_fields(self):
		required = {
			"uat-case-template.csv": {
				"case_id", "rule_ids", "input_reference", "expected_output",
				"actual_output", "status", "tester", "test_date", "evidence_reference",
			},
			"parallel-run-reconciliation.csv": {
				"period", "employee", "component", "legacy_amount", "target_amount",
				"variance", "classification", "status", "evidence_reference",
			},
		}
		for filename, expected in required.items():
			with (PHASE_DIR / filename).open(newline="", encoding="utf-8") as handle:
				fields = set(csv.DictReader(handle).fieldnames or [])
			self.assertTrue(expected <= fields, f"{filename} missing {expected - fields}")

	def test_runbook_covers_critical_operations(self):
		text = (PHASE_DIR / "operational-runbooks.md").read_text(encoding="utf-8")
		for heading in (
			"Payroll cycle", "Passage Benefit", "Loans", "Migration/import",
			"Scheduler/queue failure", "Reconciliation variance", "Backup, restore and rollback",
		):
			self.assertIn(f"## {heading}", text)

	def test_role_guides_and_training_exercises_exist(self):
		for filename in (
			"administrator-guide.md",
			"hr-registry-guide.md",
			"payroll-close-checklist.md",
			"pb-operations-guide.md",
			"loan-operations-guide.md",
			"employee-ess-guide.md",
			"training-exercises.md",
		):
			text = (PHASE_DIR / filename).read_text(encoding="utf-8")
			self.assertGreater(len(text.split()), 50, f"{filename} is only a scaffold")


if __name__ == "__main__":
	unittest.main()
