import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.loan_payroll_reconciliation.loan_payroll_reconciliation import classify_reconciliation


class TestLoanPayrollReconciliation(FrappeTestCase):
	def _row(self, **values):
		row = frappe._dict(scheduled_total=100, paid_total=100, payroll_total=100, schedule_difference=0,
			ledger_difference=0, outstanding_difference=0, duplicate_count=0, unmatched_count=0,
			out_of_period_count=0, reversal_count=0)
		row.update(values)
		return row

	def test_explicit_exception_classifications(self):
		cases = (
			({"duplicate_count": 1}, "Duplicate Deduction"),
			({"unmatched_count": 1}, "Unmatched Deduction"),
			({"out_of_period_count": 1}, "Out-of-period Deduction"),
			({"reversal_count": 1, "paid_total": 0}, "Reversed"),
			({"ledger_difference": 1}, "Ledger Mismatch"),
			({"outstanding_difference": 1}, "Outstanding Balance Mismatch"),
			({"schedule_difference": 1}, "Payroll Allocation Mismatch"),
			({"paid_total": 0}, "Missing Recovery"),
			({"paid_total": 99}, "Partial / Arrears"),
			({"paid_total": 101}, "Over-deduction"),
			({}, "Reconciled"),
		)
		for values, expected in cases:
			with self.subTest(expected):
				self.assertEqual(classify_reconciliation(self._row(**values)), expected)
