"""Internal Salary Component posting-account resolution.

Karyo users maintain Bank and Payroll Bank Branch masters. ERPNext still needs
company-specific ledger mappings when Payroll Entry creates the accrual journal,
so those mappings are derived internally instead of exposed in payroll screens.
"""

import frappe
from frappe import _
from frappe.utils import flt


def _usable_account(account, company):
	if not account:
		return None
	row = frappe.db.get_value(
		"Account", account, ["company", "is_group", "disabled"], as_dict=True
	)
	if not row or row.company != company or row.is_group or row.disabled:
		return None
	return account


def default_component_account(company, component_type):
	"""Resolve the internal accrual account used by established payroll mappings."""
	if component_type == "Earning":
		account = frappe.db.get_value(
			"Salary Component Account",
			{"parent": "Basic", "parenttype": "Salary Component", "company": company},
			"account",
		)
		account = _usable_account(account, company)
		if account:
			return account
		account = frappe.db.get_value(
			"Account",
			{"company": company, "account_name": "Salary", "is_group": 0, "disabled": 0},
			"name",
		)
		if account:
			return account
		fallback = frappe.db.get_value("Company", company, "default_expense_account")
	else:
		fallback = frappe.db.get_value("Company", company, "default_payroll_payable_account")
	return _usable_account(fallback, company)


def ensure_component_account(salary_component, company):
	"""Ensure one component has a valid company mapping without user input."""
	current = frappe.db.get_value(
		"Salary Component Account",
		{"parent": salary_component, "parenttype": "Salary Component", "company": company},
		"account",
	)
	if _usable_account(current, company):
		return current

	component = frappe.get_doc("Salary Component", salary_component)
	account = default_component_account(company, component.type)
	if not account:
		frappe.throw(
			_("Payroll could not resolve its internal {0} posting account for company {1}.").format(
				_(component.type), company
			)
		)

	row = next((row for row in component.accounts if row.company == company), None)
	if row:
		row.account = account
	else:
		component.append("accounts", {"company": company, "account": account})
	component.flags.ignore_permissions = True
	component.save(ignore_permissions=True)
	return account


def ensure_salary_slip_component_accounts(salary_slips, company):
	"""Resolve all non-zero components used by the selected draft slips."""
	names = [row.name if hasattr(row, "name") else row for row in salary_slips]
	if not names:
		return {}
	rows = frappe.get_all(
		"Salary Detail",
		filters={"parent": ("in", names), "parenttype": "Salary Slip"},
		fields=["salary_component", "amount"],
		limit_page_length=0,
	)
	components = sorted({row.salary_component for row in rows if row.salary_component and flt(row.amount)})
	return {component: ensure_component_account(component, company) for component in components}


def ensure_payroll_entry_component_accounts(payroll_entry):
	"""Maintenance entry point for an existing Payroll Entry and all draft slips."""
	entry = frappe.get_doc("Payroll Entry", payroll_entry)
	slips = frappe.get_all(
		"Salary Slip", filters={"payroll_entry": entry.name, "docstatus": 0}, pluck="name"
	)
	return ensure_salary_slip_component_accounts(slips, entry.company)
