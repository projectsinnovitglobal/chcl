from unittest import TestCase
from unittest.mock import patch

import frappe

from karyo.payroll.attendance_bonus import higher_duty_payable_days
from karyo.karyo.doctype.prb_payroll_run.prb_payroll_run import PRBPayrollRun


class TestHigherDutyProration(TestCase):
	@patch("karyo.payroll.attendance_bonus.higher_duty_payable_days")
	@patch("karyo.karyo.doctype.prb_payroll_run.prb_payroll_run.acting_allowance", return_value=1200)
	@patch.object(PRBPayrollRun, "_submitted_source")
	def test_payroll_run_prorates_the_monthly_allowance(
		self, submitted_source, acting_allowance, payable_days
	):
		submitted_source.return_value = frappe._dict(
			employee="EMP-0001", company="Test Company", assignment_type="Acting",
			assignment_days=10, from_date="2026-09-10", to_date="2026-09-19",
			higher_initial_salary=42000, higher_max_salary=68000, accounting_officer=0,
		)
		payable_days.return_value = frappe._dict(
			period_days=30, assignment_days=8, unpaid_leave_days=1, absent_days=1,
			eligible_days=6, factor=0.2, include_holidays=True, excluded_dates=[],
		)
		run = frappe.new_doc("PRB Payroll Run")
		run.employee = "EMP-0001"
		run.company = "Test Company"
		run.payroll_cycle = "SEP-2026"
		run.basic_salary = 35000
		run.salary_point = "010"
		row = frappe._dict(
			input_code="ACTING", source_doctype="PRB Higher Duty Assignment",
			source_name="HDA-0001", parameters_json="{}",
		)

		with patch(
			"karyo.karyo.doctype.prb_payroll_run.prb_payroll_run.frappe.db.get_value",
			return_value=frappe._dict(start_date="2026-09-01", end_date="2026-09-30"),
		):
			amount, rule = run._calculate_higher_duty_input(row)

		self.assertEqual(amount, 240)
		self.assertEqual(rule, "PRB-16.10.5")
		self.assertEqual(acting_allowance.call_args.kwargs["days"], 10)
		self.assertEqual(frappe.parse_json(row.parameters_json)["higher_duty_proration"]["eligible_days"], 6)

	@patch("karyo.payroll.salary_scales.grade_scale")
	def test_employee_grade_resolves_its_effective_salary_scale(self, grade_scale):
		grade_scale.return_value = (
			frappe._dict(salary_scale="SENIOR-OFFICER"),
			frappe._dict(name="SENIOR-OFFICER", lowest_salary=42000, upper_salary=68000),
		)
		doc = frappe.new_doc("PRB Higher Duty Assignment")
		doc.higher_grade = "Senior Officer"
		doc.from_date = "2026-09-10"

		doc._resolve_higher_post_salary()

		grade_scale.assert_called_once_with("Senior Officer", "2026-09-10")
		self.assertEqual(doc.higher_salary_scale, "SENIOR-OFFICER")
		self.assertEqual(doc.higher_initial_salary, 42000)
		self.assertEqual(doc.higher_max_salary, 68000)

	@patch("hrms.utils.holiday_list.get_holiday_dates_between", return_value=[])
	@patch("erpnext.setup.doctype.employee.employee.get_holiday_list_for_employee", return_value=None)
	@patch("karyo.payroll.attendance_bonus.frappe.get_cached_value")
	@patch("karyo.payroll.attendance_bonus.frappe.get_all")
	def test_ten_day_assignment_pays_only_eligible_days(
		self, get_all, get_cached_value, _holiday_list, _holidays
	):
		get_cached_value.return_value = frappe._dict(
			include_holidays_in_total_working_days=1,
			consider_marked_attendance_on_holidays=1,
			daily_wages_fraction_for_half_day=0.5,
		)

		def records(doctype, **_kwargs):
			if doctype == "Leave Type":
				return [
					frappe._dict(
						name="Leave Without Pay", is_lwp=1, is_ppl=0,
						fraction_of_daily_salary_per_leave=0, include_holiday=0,
					)
				]
			if doctype == "Leave Application":
				return [
					frappe._dict(
						from_date="2026-09-12", to_date="2026-09-12", half_day=0,
						half_day_date=None, leave_type="Leave Without Pay",
					)
				]
			if doctype == "Attendance":
				return [
					frappe._dict(
						attendance_date="2026-09-15", status="Absent", leave_type=None,
						half_day_status=None,
					)
				]
			return []

		get_all.side_effect = records
		result = higher_duty_payable_days(
			"EMP-0001", "2026-09-10", "2026-09-19", "2026-09-01", "2026-09-30"
		)

		self.assertEqual(result.period_days, 30)
		self.assertEqual(result.assignment_days, 10)
		self.assertEqual(result.unpaid_leave_days, 1)
		self.assertEqual(result.absent_days, 1)
		self.assertEqual(result.eligible_days, 8)
		self.assertEqual(result.factor, 0.266667)

	@patch("hrms.utils.holiday_list.get_holiday_dates_between", return_value=[])
	@patch("erpnext.setup.doctype.employee.employee.get_holiday_list_for_employee", return_value=None)
	@patch("karyo.payroll.attendance_bonus.frappe.get_cached_value")
	@patch("karyo.payroll.attendance_bonus.frappe.get_all")
	def test_paid_leave_is_not_deducted(self, get_all, get_cached_value, _holiday_list, _holidays):
		get_cached_value.return_value = frappe._dict(
			include_holidays_in_total_working_days=1,
			consider_marked_attendance_on_holidays=1,
			daily_wages_fraction_for_half_day=0.5,
		)
		get_all.side_effect = lambda doctype, **_kwargs: (
			[
				frappe._dict(
					attendance_date="2026-09-12", status="On Leave",
					leave_type="Annual Leave", half_day_status=None,
				)
			] if doctype == "Attendance" else []
		)

		result = higher_duty_payable_days(
			"EMP-0001", "2026-09-10", "2026-09-19", "2026-09-01", "2026-09-30"
		)

		self.assertEqual(result.eligible_days, 10)
		self.assertEqual(result.unpaid_leave_days, 0)
		self.assertEqual(result.absent_days, 0)
