"""Karyo Loan Management — reference + master DocTypes (Phase 2 start).

    bench --site dev.localhost execute karyo.setup.loan.setup

Creates Loan Type (reference), Karyo Loan (master) and Karyo Loan Schedule
(child). Guarantors, Loan Committee workflow, disbursement, static-deduction
posting and recast transactions follow in later steps. Idempotent.
"""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_loan_doctypes():
	make_doctype(
		"Loan Type",
		autoname="field:loan_code",
		naming_rule="By fieldname",
		title_field="loan_name",
		fields=[
			f("loan_code", "Data", "Loan Code", reqd=1, unique=1, in_list_view=1),
			f("loan_name", "Data", "Loan Name", reqd=1, in_list_view=1),
			f(
				"loan_category",
				"Select",
				"Category",
				options="Personal\nMotor Vehicle\nMotorcycle\nMedical\nMultipurpose\nOther",
				in_list_view=1,
			),
			f("interest_rate", "Percent", "Annual Interest Rate", reqd=1, in_list_view=1),
			f("max_amount", "Currency", "Maximum Amount"),
			f("max_period_months", "Int", "Maximum Period (Months)", reqd=1),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("requires_md_approval", "Check", "Managing Director Approval Required", default="0"),
			f("ins_sb", "Section Break", "Insurance"),
			f("insurance_required", "Check", "Insurance Required"),
			f("insurance_threshold", "Currency", "Insurance Threshold"),
			f("pdb_sb", "Section Break", "Payroll Components (PDB)"),
			f("pdb_capital", "Link", "Capital Component", options="Salary Component"),
			f("pdb_interest", "Link", "Interest Component", options="Salary Component"),
			f("pdb_cb", "Column Break"),
			f("pdb_insurance", "Link", "Insurance Component", options="Salary Component"),
			f("valid_sb", "Section Break", "Validity"),
			f("start_date", "Date", "Start Date"),
			f("end_date", "Date", "End Date"),
		],
	)
	make_doctype(
		"Karyo Loan Schedule",
		istable=1,
		fields=[
			f("month", "Int", "Month", in_list_view=1),
			f("opening_balance", "Currency", "Opening Balance", in_list_view=1),
			f("capital", "Currency", "Capital", in_list_view=1),
			f("interest", "Currency", "Interest", in_list_view=1),
			f("insurance", "Currency", "Insurance", in_list_view=1),
			f("total", "Currency", "Total Refund", in_list_view=1),
			f("closing_balance", "Currency", "Closing Balance", in_list_view=1),
			f("status", "Select", "Status", options="Pending\nPaid", default="Pending"),
		],
	)
	make_doctype(
		"Karyo Loan",
		is_submittable=1,
		autoname="naming_series:",
		title_field="employee_name",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="LOAN-.YYYY.-.#####",
				default="LOAN-.YYYY.-.#####",
			),
			f(
				"employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1,
				ignore_user_permissions=1,
			),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("loan_type", "Link", "Loan Type", options="Loan Type", reqd=1, in_list_view=1),
			f("company", "Link", "Company", options="Company"),
			f("hcb", "Column Break"),
			f("disbursement_date", "Date", "Disbursement / Start Date"),
			f("repayment_start_date", "Date", "Repayment Start Date"),
			f(
				"status",
				"Select",
				"Status",
				options="Draft\nActive\nSettled\nClosed",
				default="Draft",
				read_only=1,
				in_list_view=1,
			),
			f("terms_sb", "Section Break", "Terms"),
			f("approved_amount", "Currency", "Approved Amount (Principal)", reqd=1, in_list_view=1),
			f("period_months", "Int", "Period (Months)", reqd=1),
			f("interest_rate", "Percent", "Annual Interest Rate", fetch_from="loan_type.interest_rate"),
			f("terms_cb", "Column Break"),
			f("insurance_rate", "Float", "Insurance Rate (per Rs 10,000)", precision=4),
			f(
				"sum_assured",
				"Currency",
				"Sum Assured",
				description="Defaults to approved amount if blank (BR-FAR-LMS-INS-004).",
			),
			f("computed_sb", "Section Break", "Computed Components"),
			f("monthly_capital", "Currency", "Monthly Capital", read_only=1),
			f("monthly_interest", "Currency", "Monthly Interest", read_only=1),
			f("monthly_insurance", "Currency", "Monthly Insurance", read_only=1),
			f("monthly_refund", "Currency", "Monthly Refund", read_only=1, in_list_view=1),
			f("computed_cb", "Column Break"),
			f("total_interest", "Currency", "Total Interest", read_only=1),
			f("total_insurance", "Currency", "Total Insurance", read_only=1),
			f("sched_sb", "Section Break", "Repayment Schedule"),
			f("schedule", "Table", "Schedule", options="Karyo Loan Schedule"),
		],
	)


def setup():
	print("Karyo Loan setup:")
	create_loan_doctypes()
	frappe.db.commit()
	print("Done.")
