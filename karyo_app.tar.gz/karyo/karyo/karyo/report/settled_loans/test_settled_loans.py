import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.settled_loans.settled_loans import _waived_interest


class TestSettledLoans(FrappeTestCase):
	def test_waiver_uses_immutable_pre_settlement_snapshot(self):
		row = frappe._dict(ewf_waive_interest=1, prior_state_snapshot='{"outstanding_interest": 245.5}')
		self.assertEqual(_waived_interest(row), 245.5)
		row.ewf_waive_interest = 0
		self.assertEqual(_waived_interest(row), 0)
