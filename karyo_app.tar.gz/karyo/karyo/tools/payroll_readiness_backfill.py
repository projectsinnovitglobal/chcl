"""One-time, auditable repair for demo payroll-readiness employee defaults."""

import secrets

import frappe

from karyo.payroll.readiness import run_readiness


READINESS_CODES = (
	"TAX_IDENTIFIER_MISSING",
	"COST_CENTER_MISSING",
	"PRB_APPLICABILITY_UNCONFIRMED",
)


def _random_tax_identifier():
	"""Return a visibly synthetic, unique identifier for demo employee data."""
	while True:
		value = f"DEMO-TAX-{secrets.token_hex(5).upper()}"
		if not frappe.db.exists("Employee", {"pan_number": value}):
			return value


def execute(payroll_cycle):
	"""Fill only missing values for employees flagged by one payroll cycle."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	default_cost_center = frappe.db.get_value("Company", cycle.company, "cost_center")
	if not default_cost_center:
		frappe.throw(f"Company {cycle.company} has no default Cost Center.")
	if not frappe.db.exists(
		"Cost Center",
		{"name": default_cost_center, "company": cycle.company, "is_group": 0, "disabled": 0},
	):
		frappe.throw(f"Company default Cost Center {default_cost_center} is not an active leaf Cost Center.")

	employees = frappe.get_all(
		"Payroll Readiness Exception",
		filters={
			"payroll_cycle": payroll_cycle,
			"status": "Open",
			"validation_code": ("in", READINESS_CODES),
		},
		pluck="employee",
		order_by="employee asc",
		limit_page_length=0,
	)
	employees = list(dict.fromkeys(employees))
	result = {
		"payroll_cycle": payroll_cycle,
		"employees": len(employees),
		"tax_identifiers_created": 0,
		"cost_centers_selected": 0,
		"prb_applicable_aligned": 0,
		"prb_not_applicable_confirmed": 0,
	}
	for employee_name in employees:
		employee = frappe.db.get_value(
			"Employee",
			employee_name,
			[
				"pan_number", "payroll_cost_center", "karyo_prb_opted_in",
				"karyo_prb_grade", "karyo_prb_salary_point",
			],
			as_dict=True,
		)
		if not employee:
			continue
		values = {}
		if not employee.pan_number:
			values["pan_number"] = _random_tax_identifier()
			result["tax_identifiers_created"] += 1
		if not employee.payroll_cost_center:
			values["payroll_cost_center"] = default_cost_center
			result["cost_centers_selected"] += 1
		if employee.karyo_prb_grade and employee.karyo_prb_salary_point and not employee.karyo_prb_opted_in:
			values["karyo_prb_opted_in"] = 1
			result["prb_applicable_aligned"] += 1
		elif not employee.karyo_prb_grade and not employee.karyo_prb_salary_point and not employee.karyo_prb_opted_in:
			result["prb_not_applicable_confirmed"] += 1
		if values:
			frappe.db.set_value("Employee", employee_name, values)

	result["readiness"] = run_readiness(payroll_cycle, employees)
	return result
