from datetime import datetime, timezone
import unittest
from unittest.mock import patch

from karyo.tasks import is_mbc_month_start, run_previous_month_scheduled


class TestMBCScheduler(unittest.TestCase):
	def test_utc_time_maps_to_mauritius_month_start(self):
		self.assertTrue(is_mbc_month_start(datetime(2026, 8, 31, 20, 0, tzinfo=timezone.utc)))

	def test_other_candidate_cron_dates_are_skipped(self):
		self.assertFalse(is_mbc_month_start(datetime(2026, 8, 30, 20, 0, tzinfo=timezone.utc)))
		self.assertFalse(is_mbc_month_start(datetime(2026, 9, 1, 20, 0, tzinfo=timezone.utc)))

	def test_month_start_guard_invokes_previous_month_job_once(self):
		with (
			patch("karyo.tasks.is_mbc_month_start", return_value=True),
			patch("karyo.tasks.run_previous_month", return_value={"pay_period": "2026-08"}) as run,
		):
			self.assertEqual(run_previous_month_scheduled()["pay_period"], "2026-08")
			run.assert_called_once_with()

	def test_non_month_start_guard_does_not_invoke_job(self):
		with (
			patch("karyo.tasks.is_mbc_month_start", return_value=False),
			patch("karyo.tasks.run_previous_month") as run,
		):
			result = run_previous_month_scheduled()
			self.assertTrue(result["skipped"])
			run.assert_not_called()


if __name__ == "__main__":
	unittest.main()
