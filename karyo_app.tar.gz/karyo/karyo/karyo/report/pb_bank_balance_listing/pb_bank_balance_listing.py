# Copyright (c) 2026, AstraFlow and contributors
# For license information, please see license.txt

"""PB Bank Balance Listing (§9.2 #1) — current PB balances for HR/Finance review.

Minimum fields (BRD §9.2): employee, opening balance, earned, taken, adjustments,
closing balance, last computation date.
"""

import frappe


def execute(filters=None):
	filters = frappe._dict(filters or {})
	return _columns(), _data(filters)


def _columns():
	return [
		{
			"label": "Employee",
			"fieldname": "employee",
			"fieldtype": "Link",
			"options": "Employee",
			"width": 120,
		},
		{"label": "Employee Name", "fieldname": "employee_name", "fieldtype": "Data", "width": 180},
		{"label": "Company", "fieldname": "company", "fieldtype": "Link", "options": "Company", "width": 150},
		{"label": "Opening Balance", "fieldname": "opening_balance", "fieldtype": "Currency", "width": 130},
		{"label": "Earned", "fieldname": "total_earned", "fieldtype": "Currency", "width": 120},
		{"label": "Taken", "fieldname": "total_taken", "fieldtype": "Currency", "width": 120},
		{"label": "Adjustments", "fieldname": "total_adjustments", "fieldtype": "Currency", "width": 120},
		{"label": "Closing Balance", "fieldname": "current_balance", "fieldtype": "Currency", "width": 140},
		{"label": "Last Computation", "fieldname": "last_computation", "fieldtype": "Date", "width": 130},
	]


def _data(filters):
	bank_filters = {}
	if filters.get("company"):
		bank_filters["company"] = filters.company
	if filters.get("employee"):
		bank_filters["employee"] = filters.employee

	banks = frappe.get_all(
		"Passage Benefit Bank",
		filters=bank_filters,
		fields=[
			"name as employee",
			"employee_name",
			"company",
			"opening_balance",
			"total_earned",
			"total_taken",
			"total_adjustments",
			"current_balance",
		],
		order_by="employee_name asc",
	)
	# Last submitted computation end-date per employee (single grouped query).
	last = dict(
		frappe.get_all(
			"Passage Benefit Computation",
			filters={"docstatus": 1},
			fields=["employee", "max(to_date) as last_computation"],
			group_by="employee",
			as_list=True,
		)
	)
	for b in banks:
		b["last_computation"] = last.get(b["employee"])
	return banks
