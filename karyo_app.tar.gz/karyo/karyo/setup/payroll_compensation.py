"""Effective-dated banded compensation schemes (PAY-016)."""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Payroll Compensation Band",
		istable=1,
		fields=[
			f("lower_salary", "Currency", "Lower Salary", reqd=1, in_list_view=1),
			f("upper_salary", "Currency", "Upper Salary", in_list_view=1),
			f("is_open_ended", "Check", "No Upper Limit", default="0", in_list_view=1),
			f("percentage", "Percent", "Percentage", default="0", in_list_view=1),
			f("flat_amount", "Currency", "Flat Amount", default="0", in_list_view=1),
		],
	)
	make_doctype(
		"Payroll Compensation Scheme",
		autoname="format:{scheme_code}-{version}",
		title_field="description",
		fields=[
			f("identity_sb", "Section Break", "Scheme Identity"),
			f("scheme_code", "Data", "Scheme Code", reqd=1, in_list_view=1),
			f("version", "Data", "Version", reqd=1, default="DEMO-1", in_list_view=1),
			f("description", "Data", "Description", reqd=1, in_list_view=1),
			f("company", "Link", "Company", options="Company", in_standard_filter=1),
			f("identity_cb", "Column Break"),
			f(
				"calculation_method",
				"Select",
				"Calculation Method",
				options="Percentage\nFlat Amount\nPercentage Plus Flat\nHigher of Percentage or Flat",
				default="Percentage",
				reqd=1,
				in_list_view=1,
			),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("allow_band_gaps", "Check", "Allow Intentional Band Gaps", default="0"),
			f("mapping_sb", "Section Break", "Payroll Mapping"),
			f(
				"basis_operation_code",
				"Link",
				"Salary Basis Operation Code",
				options="Payroll Operation Code",
				reqd=1,
			),
			f("compensation_pdb_code", "Link", "Compensation PDB", options="Payroll PDB Code", reqd=1),
			f("mapping_cb", "Column Break"),
			f("rounding_precision", "Int", "Rounding Precision", default="2", reqd=1),
			f(
				"rounding_method",
				"Select",
				"Rounding Method",
				options="Round Half Up\nRound Half to Even",
				default="Round Half Up",
				reqd=1,
			),
			f("eligibility_sb", "Section Break", "Eligibility — Blank Means All"),
			f("employment_type", "Link", "Employment Type", options="Employment Type"),
			f("department", "Link", "Department", options="Department"),
			f("eligibility_cb", "Column Break"),
			f("designation", "Link", "Designation", options="Designation"),
			f("prb_grade", "Data", "PRB Grade"),
			f("bands_sb", "Section Break", "Compensation Bands — Bounds are Inclusive"),
			f("bands", "Table", "Compensation Bands", options="Payroll Compensation Band", reqd=1),
			f("validity_sb", "Section Break", "Validity and Governance"),
			f("effective_from", "Date", "Effective From", reqd=1, in_list_view=1),
			f("effective_to", "Date", "Effective To"),
			f(
				"configuration_version",
				"Link",
				"Configuration Version",
				options="Payroll Configuration Version",
				reqd=1,
			),
			f("source_reference", "Data", "Source Reference"),
			f("notes", "Small Text", "Notes"),
		],
	)


def _ensure_component():
	name = "Compensation (Demo)"
	if frappe.db.exists("Salary Component", name):
		return
	frappe.get_doc(
		{
			"doctype": "Salary Component",
			"salary_component": name,
			"salary_component_abbr": "CMPD",
			"type": "Earning",
			"is_tax_applicable": 1,
			"depends_on_payment_days": 0,
		}
	).insert(ignore_permissions=True)


def seed_demo_data():
	if frappe.db.exists(
		"Payroll Compensation Scheme", {"scheme_code": "CMP-DEMO", "version": "DEMO-1"}
	):
		return
	configuration = frappe.db.get_value(
		"Payroll Configuration Version",
		{"config_key": "DEMO-COMPENSATION-2026", "version": "DEMO-1"},
		"name",
	)
	if not configuration or not frappe.db.exists("Payroll PDB Code", "CMP"):
		return
	frappe.get_doc(
		{
			"doctype": "Payroll Compensation Scheme",
			"scheme_code": "CMP-DEMO",
			"version": "DEMO-1",
			"description": "Annual Compensation (Demo — illustrative only)",
			"calculation_method": "Higher of Percentage or Flat",
			"basis_operation_code": "GSAL",
			"compensation_pdb_code": "CMP",
			"rounding_precision": 2,
			"rounding_method": "Round Half Up",
			"is_active": 1,
			"effective_from": "2026-01-01",
			"configuration_version": configuration,
			"source_reference": "DEMO ONLY — rates are not approved compensation policy",
			"bands": [
				{
					"lower_salary": 0,
					"upper_salary": 50000,
					"percentage": 3,
					"flat_amount": 1000,
				},
				{
					"lower_salary": 50000.01,
					"is_open_ended": 1,
					"percentage": 2,
					"flat_amount": 1500,
				},
			],
			"notes": "Illustrative development data; replace through configuration/import.",
		}
	).insert(ignore_permissions=True)


def setup():
	print("Karyo Payroll compensation setup:")
	create_doctypes()
	# The demo CMP PDB mapping becomes available after its component exists.
	_ensure_component()
	from karyo.install import samples_enabled

	if samples_enabled():
		from karyo.setup.payroll_configuration import seed_demo_configurations

		seed_demo_configurations()
		from karyo.setup.payroll_pdb import seed_demo_data as seed_pdb_demo

		seed_pdb_demo()
		seed_demo_data()
	frappe.db.commit()
	print("Done (versioned compensation schemes, bands, mappings, and demo data created).")
