"""Shared configuration metadata for attendance-based payroll bonuses."""

import frappe
from frappe import _
from frappe.utils import add_days, cint, date_diff, flt, getdate


BONUS_BASES = {
	"ATTENDANCE_BONUS": {
		"label": "Attendance Bonus",
		"setting": "attendance_bonus_base",
		"default": 2140,
		"rule_ref": "ATT-CALC-003",
	},
	"INCENTIVE_ATTENDANCE": {
		"label": "Incentive Attendance Bonus",
		"setting": "incentive_attendance_bonus_base",
		"default": 1500,
		"rule_ref": "ATT-CALC-003",
	},
	"INCENTIVE_PRESENCE": {
		"label": "Incentive Presence Bonus",
		"setting": "incentive_presence_base",
		"default": 1500,
		"rule_ref": "ATT-CALC-006",
	},
}

AUTOMATIC_BONUS_CODES = ("ATTENDANCE_BONUS", "INCENTIVE_ATTENDANCE")
AUTOMATIC_BONUS_PURPOSES = (
	"Attendance Bonus",
	"Incentive Attendance Bonus",
	"PRB Attendance Bonuses",
)


def higher_duty_payable_days(employee, assignment_start, assignment_end, period_start, period_end):
	"""Return the payroll-cycle fraction payable for a higher-duty assignment.

	The denominator follows the native Payroll Settings treatment of holidays.
	Within the overlapping assignment period, paid leave and paid holidays remain
	payable; only submitted absence and the unpaid portion of approved leave are
	deducted. Missing Attendance is therefore not silently treated as absence.
	"""
	from erpnext.setup.doctype.employee.employee import get_holiday_list_for_employee
	from hrms.utils.holiday_list import get_holiday_dates_between

	period_start, period_end = getdate(period_start), getdate(period_end)
	assignment_start = max(getdate(assignment_start), period_start)
	assignment_end = min(getdate(assignment_end), period_end)
	if period_end < period_start or assignment_end < assignment_start:
		return frappe._dict(
			period_days=0.0, assignment_days=0.0, unpaid_leave_days=0.0,
			absent_days=0.0, eligible_days=0.0, factor=0.0, excluded_dates=[],
		)

	settings = frappe.get_cached_value(
		"Payroll Settings", None,
		("include_holidays_in_total_working_days", "consider_marked_attendance_on_holidays", "daily_wages_fraction_for_half_day"),
		as_dict=True,
	) or frappe._dict()
	include_holidays = bool(cint(settings.include_holidays_in_total_working_days))
	consider_holiday_attendance = include_holidays and bool(cint(settings.consider_marked_attendance_on_holidays))
	half_day_fraction = flt(settings.daily_wages_fraction_for_half_day) or 0.5

	holiday_list = get_holiday_list_for_employee(employee, raise_exception=False)
	holidays = set(
		getdate(day) for day in (
			get_holiday_dates_between(holiday_list, period_start, period_end) if holiday_list else []
		)
	)
	period_dates = {
		getdate(add_days(period_start, offset))
		for offset in range(date_diff(period_end, period_start) + 1)
		if include_holidays or getdate(add_days(period_start, offset)) not in holidays
	}
	assignment_dates = {day for day in period_dates if assignment_start <= day <= assignment_end}

	leave_types = {
		row.name: row for row in frappe.get_all(
			"Leave Type",
			or_filters={"is_lwp": 1, "is_ppl": 1},
			fields=["name", "is_lwp", "is_ppl", "fraction_of_daily_salary_per_leave", "include_holiday"],
			limit_page_length=0,
		)
	}
	excluded = {}

	def exclude(day, units, reason):
		day = getdate(day)
		if day not in assignment_dates or units <= 0:
			return
		current = excluded.get(day)
		if not current or units > current["units"]:
			excluded[day] = {"units": min(1.0, flt(units)), "reason": reason}

	for application in frappe.get_all(
		"Leave Application",
		filters={
			"employee": employee, "status": "Approved", "docstatus": 1,
			"from_date": ("<=", assignment_end), "to_date": (">=", assignment_start),
			"leave_type": ("in", tuple(leave_types) or ("",)),
		},
		fields=["from_date", "to_date", "half_day", "half_day_date", "leave_type"],
		limit_page_length=500,
	):
		leave_type = leave_types.get(application.leave_type)
		if not leave_type:
			continue
		unpaid_fraction = 1.0 if leave_type.is_lwp else max(
			0.0, 1.0 - flt(leave_type.fraction_of_daily_salary_per_leave)
		)
		for offset in range(date_diff(application.to_date, application.from_date) + 1):
			day = getdate(add_days(application.from_date, offset))
			if day in holidays and not leave_type.include_holiday:
				continue
			day_fraction = 1.0 - half_day_fraction if (
				application.half_day and getdate(application.half_day_date or application.to_date) == day
			) else 1.0
			exclude(day, day_fraction * unpaid_fraction, "Unpaid leave")

	for attendance in frappe.get_all(
		"Attendance",
		filters={
			"employee": employee, "attendance_date": ("between", [assignment_start, assignment_end]),
			"docstatus": 1, "status": ("in", ["Absent", "Half Day", "On Leave"]),
		},
		fields=["attendance_date", "status", "leave_type", "half_day_status"],
		limit_page_length=500,
	):
		day = getdate(attendance.attendance_date)
		if day in holidays and not consider_holiday_attendance:
			continue
		leave_type = leave_types.get(attendance.leave_type)
		if attendance.status == "Absent":
			exclude(day, 1.0, "Absent")
		elif attendance.status == "Half Day":
			if attendance.half_day_status == "Absent":
				exclude(day, half_day_fraction, "Absent")
			elif leave_type:
				unpaid_fraction = 1.0 if leave_type.is_lwp else max(
					0.0, 1.0 - flt(leave_type.fraction_of_daily_salary_per_leave)
				)
				exclude(day, (1.0 - half_day_fraction) * unpaid_fraction, "Unpaid leave")
		elif attendance.status == "On Leave" and leave_type:
			unpaid_fraction = 1.0 if leave_type.is_lwp else max(
				0.0, 1.0 - flt(leave_type.fraction_of_daily_salary_per_leave)
			)
			exclude(day, unpaid_fraction, "Unpaid leave")

	unpaid_leave_days = flt(sum(item["units"] for item in excluded.values() if item["reason"] == "Unpaid leave"), 2)
	absent_days = flt(sum(item["units"] for item in excluded.values() if item["reason"] == "Absent"), 2)
	assignment_days = flt(len(assignment_dates), 2)
	eligible_days = flt(max(0.0, assignment_days - unpaid_leave_days - absent_days), 2)
	period_days = flt(len(period_dates), 2)
	return frappe._dict(
		period_days=period_days,
		assignment_days=assignment_days,
		unpaid_leave_days=unpaid_leave_days,
		absent_days=absent_days,
		eligible_days=eligible_days,
		factor=flt(min(1.0, eligible_days / period_days), 6) if period_days else 0.0,
		include_holidays=include_holidays,
		excluded_dates=[
			{"date": str(day), "units": excluded[day]["units"], "reason": excluded[day]["reason"]}
			for day in sorted(excluded)
		],
	)


def presence_leave_units(employee, start_date, end_date):
	"""Return unique absence units from submitted Attendance and approved leave.

	Attendance and Leave Application/Leave Transaction may describe the same day.
	Using the highest unit per date prevents that overlap from being counted twice.
	A separate working-attendance total is returned so that an employee with no
	submitted presence in the month cannot receive a presence-based bonus merely
	because no absence was recorded either.
	"""
	from erpnext.setup.doctype.employee.employee import is_holiday

	start, end = getdate(start_date), getdate(end_date)
	if end < start:
		return frappe._dict(total=0.0, attendance=0.0, approved_leave=0.0, dates=[])
	attendance_units = {}
	working_units = {}
	for row in frappe.get_all(
		"Attendance",
		filters={
			"employee": employee, "attendance_date": ["between", [start, end]], "docstatus": 1,
			"status": ["in", ["Present", "Work From Home", "Half Day", "Absent", "On Leave"]],
		},
		fields=["attendance_date", "status"], limit_page_length=500,
	):
		date = getdate(row.attendance_date)
		if row.status in ("Present", "Work From Home"):
			working_units[date] = 1.0
		elif row.status == "Half Day":
			working_units[date] = 0.5
			attendance_units[date] = 0.5
		else:
			attendance_units[date] = 1.0

	leave_units = {}
	linked_applications = set()
	applications = frappe.get_all(
		"Leave Application",
		filters={
			"employee": employee, "status": "Approved", "docstatus": ["!=", 2],
			"from_date": ["<=", end], "to_date": [">=", start],
		},
		fields=["name", "from_date", "to_date", "half_day", "half_day_date", "total_leave_days"],
		limit_page_length=500,
	)
	for application in applications:
		linked_applications.add(application.name)
		remaining = flt(application.total_leave_days, 2)
		for offset in range(date_diff(application.to_date, application.from_date) + 1):
			date = getdate(add_days(application.from_date, offset))
			if remaining <= 0 or is_holiday(employee, date, raise_exception=False):
				continue
			unit = 0.5 if application.half_day and getdate(application.half_day_date or application.to_date) == date else 1.0
			unit = min(unit, remaining)
			remaining -= unit
			if start <= date <= end:
				leave_units[date] = max(leave_units.get(date, 0), unit)

	# Legacy/imported approved transactions can exist without a Leave Application.
	for transaction in frappe.get_all(
		"Leave Transaction",
		filters={
			"employee": employee, "legacy_status": "Approved", "cancelled": 0,
			"start_date": ["<=", end], "end_date": [">=", start],
		},
		fields=["leave_request_id", "start_date", "end_date", "duration_units", "duration_unit", "half_day"],
		limit_page_length=500,
	):
		if transaction.leave_request_id in linked_applications or transaction.duration_unit != "Days":
			continue
		remaining = flt(transaction.duration_units, 2)
		for offset in range(date_diff(transaction.end_date, transaction.start_date) + 1):
			date = getdate(add_days(transaction.start_date, offset))
			if remaining <= 0 or is_holiday(employee, date, raise_exception=False):
				continue
			unit = min(1.0, remaining)
			remaining -= unit
			if start <= date <= end:
				leave_units[date] = max(leave_units.get(date, 0), unit)

	combined = dict(attendance_units)
	for date, unit in leave_units.items():
		combined[date] = max(combined.get(date, 0), unit)
	return frappe._dict(
		total=flt(sum(combined.values()), 2),
		attendance=flt(sum(attendance_units.values()), 2),
		approved_leave=flt(sum(leave_units.values()), 2),
		worked=flt(sum(working_units.values()), 2),
		has_working_attendance=bool(working_units),
		dates=[{"date": date, "units": combined[date]} for date in sorted(combined)],
	)


def era_leave_units(employee, start_date, end_date):
	"""Return unique casual and other absence units for the ERA deduction.

	Approved leave is more specific than a generic Absent/On Leave Attendance
	row, so it supplies the category when both describe the same date. Half days
	remain 0.5 and overlapping sources are counted only once.
	"""
	from erpnext.setup.doctype.employee.employee import is_holiday

	start, end = getdate(start_date), getdate(end_date)
	by_date = {}

	def add(date, units, leave_type=None, explicit=False):
		date = getdate(date)
		if not start <= date <= end:
			return
		category = "casual" if "casual" in str(leave_type or "").lower() else "other"
		current = by_date.get(date)
		if not current or units > current["units"] or (explicit and not current["explicit"]):
			by_date[date] = {"units": flt(units, 2), "category": category, "explicit": explicit}

	for row in frappe.get_all(
		"Attendance",
		filters={
			"employee": employee, "attendance_date": ["between", [start, end]], "docstatus": 1,
			"status": ["in", ["Half Day", "Absent", "On Leave"]],
		},
		fields=["attendance_date", "status", "leave_type"], limit_page_length=500,
	):
		add(row.attendance_date, 0.5 if row.status == "Half Day" else 1.0, row.leave_type, bool(row.leave_type))

	for application in frappe.get_all(
		"Leave Application",
		filters={
			"employee": employee, "status": "Approved", "docstatus": ["!=", 2],
			"from_date": ["<=", end], "to_date": [">=", start],
		},
		fields=["from_date", "to_date", "half_day", "half_day_date", "total_leave_days", "leave_type"],
		limit_page_length=500,
	):
		remaining = flt(application.total_leave_days, 2)
		for offset in range(date_diff(application.to_date, application.from_date) + 1):
			date = getdate(add_days(application.from_date, offset))
			if remaining <= 0 or is_holiday(employee, date, raise_exception=False):
				continue
			units = 0.5 if application.half_day and getdate(application.half_day_date or application.to_date) == date else 1.0
			units = min(units, remaining)
			remaining -= units
			add(date, units, application.leave_type, True)

	casual = flt(sum(item["units"] for item in by_date.values() if item["category"] == "casual"), 2)
	other = flt(sum(item["units"] for item in by_date.values() if item["category"] == "other"), 2)
	return frappe._dict(
		casual=casual,
		other=other,
		dates=[{"date": str(date), "units": by_date[date]["units"], "category": by_date[date]["category"]} for date in sorted(by_date)],
	)


def configured_bonus_base(input_code):
	"""Return the positive configured base, falling back to the approved default."""
	rule = BONUS_BASES.get(str(input_code or "").strip().upper())
	if not rule:
		return 0.0
	value = frappe.db.get_single_value("PRB Payroll Settings", rule["setting"])
	return flt(value) if flt(value) > 0 else flt(rule["default"])


def with_configured_bases(rows):
	"""Copy bonus row presets and fill every visible Base Amount."""
	result = []
	for source in rows or []:
		row = dict(source)
		if row.get("amount") in (None, ""):
			row["amount"] = configured_bonus_base(row.get("input_code"))
		result.append(row)
	return result


def _purpose_for_bonus_codes(codes):
	codes = set(codes)
	if codes == set(AUTOMATIC_BONUS_CODES):
		return "PRB Attendance Bonuses"
	if codes == {"ATTENDANCE_BONUS"}:
		return "Attendance Bonus"
	if codes == {"INCENTIVE_ATTENDANCE"}:
		return "Incentive Attendance Bonus"
	frappe.throw(_("No supported attendance-bonus components were selected."))


def _bonus_input(code):
	rule = BONUS_BASES[code]
	return {
		"category": "Allowance",
		"input_code": code,
		"description": rule["label"],
		"amount": configured_bonus_base(code),
	}


def _submitted_bonus_runs(employee, payroll_cycle):
	return frappe.get_all(
		"PRB Payroll Run",
		filters={
			"employee": employee,
			"payroll_cycle": payroll_cycle,
			"run_purpose": ("in", AUTOMATIC_BONUS_PURPOSES),
			"docstatus": 1,
		},
		fields=["name", "posting_status", "snapshot_status"],
		order_by="creation asc, name asc",
		limit_page_length=0,
	)


def _run_bonus_codes(run):
	return {
		row.component_code
		for row in run.get("components") or []
		if row.component_code in AUTOMATIC_BONUS_CODES
	}


def _automatic_draft(employee, payroll_cycle):
	name = frappe.db.get_value(
		"PRB Payroll Run",
		{
			"employee": employee,
			"payroll_cycle": payroll_cycle,
			"run_purpose": ("in", AUTOMATIC_BONUS_PURPOSES),
			"custom_entry_source": "Automatic",
			"docstatus": 0,
		},
		"name",
		order_by="modified desc",
	)
	return frappe.get_doc("PRB Payroll Run", name) if name else None


def automatic_bonus_eligibility(employee, cycle):
	"""Return the configured, attendance-derived bonus rows for one pay cycle."""
	breakdown = presence_leave_units(employee, cycle.start_date, cycle.end_date)
	from karyo.prb.allowances import attendance_bonus

	items = []
	for code in AUTOMATIC_BONUS_CODES:
		row = _bonus_input(code)
		row["calculated_amount"] = (
			attendance_bonus(breakdown.total, row["amount"])
			if breakdown.get("has_working_attendance") else 0
		)
		items.append(row)
	return frappe._dict(
		leave_units=breakdown.total,
		worked_units=breakdown.get("worked") or 0,
		has_working_attendance=bool(breakdown.get("has_working_attendance")),
		leave_breakdown=breakdown,
		items=items,
		eligible=bool(breakdown.get("has_working_attendance"))
			and any(flt(row["calculated_amount"]) > 0 for row in items),
	)


def _eligibility_reason(cycle, eligibility, automatic=False):
	if not eligibility.has_working_attendance:
		return _(
			"Not eligible: no submitted Present, Work From Home or Half Day Attendance was recorded from {0} to {1}."
		).format(cycle.start_date, cycle.end_date)
	prefix = _("Automatically calculated") if automatic else _("Calculated")
	return _(
		"{0} for {1} to {2} from {3} working attendance unit(s) and {4} unique absence unit(s)."
	).format(prefix, cycle.start_date, cycle.end_date, eligibility.worked_units, eligibility.leave_units)


def process_attendance_bonus_drafts(payroll_cycle, employees=None):
	"""Calculate the selected month's combined attendance bonuses into Draft runs.

	Processing is deliberately separate from approval and payroll posting. This
	keeps the calculated employee/component amounts reviewable before they create
	Additional Salary entries.
	"""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle) if isinstance(payroll_cycle, str) else payroll_cycle
	cycle.check_permission("read")
	from karyo.payroll.employee_processing import resolve_employees

	employees, _options = resolve_employees(cycle, employees)
	result = frappe._dict(processed=0, created=0, updated=0, eligible=0,
		not_eligible=0, already_approved=0, runs=[], employees=[])
	for employee in employees:
		eligibility = automatic_bonus_eligibility(employee, cycle)
		covered = set()
		for row in _submitted_bonus_runs(employee, cycle.name):
			covered.update(_run_bonus_codes(frappe.get_doc("PRB Payroll Run", row.name)))
		missing = [row for row in eligibility["items"] if row["input_code"] not in covered]
		if not missing:
			result.already_approved += 1
			continue

		name = frappe.db.get_value(
			"PRB Payroll Run",
			{
				"employee": employee,
				"payroll_cycle": cycle.name,
				"run_purpose": ("in", AUTOMATIC_BONUS_PURPOSES),
				"custom_entry_source": "Automatic",
				"docstatus": 0,
			},
			"name",
			order_by="modified desc",
		)
		doc = frappe.get_doc("PRB Payroll Run", name) if name else frappe.new_doc("PRB Payroll Run")
		is_new = doc.is_new()
		doc.employee = employee
		doc.company = cycle.company
		doc.payroll_cycle = cycle.name
		doc.payroll_period = cycle.get("payroll_period")
		doc.calculation_date = cycle.payment_date or cycle.end_date
		doc.review_year = getdate(cycle.end_date).year
		doc.run_purpose = _purpose_for_bonus_codes(row["input_code"] for row in missing)
		doc.set("employee_inputs", [])
		for row in missing:
			doc.append("employee_inputs", {
				key: row[key] for key in ("category", "input_code", "description", "amount")
			})
		if doc.meta.has_field("custom_entry_source"):
			doc.custom_entry_source = "Automatic"
		payable = any(flt(row["calculated_amount"]) > 0 for row in missing)
		if doc.meta.has_field("custom_eligibility_status"):
			doc.custom_eligibility_status = "Eligible" if payable else "Not Eligible"
		if doc.meta.has_field("custom_eligibility_reason"):
			doc.custom_eligibility_reason = _eligibility_reason(cycle, eligibility)
		if doc.meta.has_field("custom_manual_reference"):
			doc.custom_manual_reference = _("Processed from the PRB Attendance screen for {0}.").format(cycle.name)
		doc.flags.ignore_permissions = True
		if is_new:
			doc.insert(ignore_permissions=True)
			result.created += 1
		else:
			doc.save(ignore_permissions=True)
			result.updated += 1
		result.processed += 1
		result.eligible += 1 if payable else 0
		result.not_eligible += 0 if payable else 1
		result.runs.append(doc.name)
		result.employees.append(employee)
	return result


def approve_attendance_bonus_drafts(payroll_cycle, employees=None):
	"""Approve the latest processed Draft for each selected employee."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle) if isinstance(payroll_cycle, str) else payroll_cycle
	cycle.check_permission("read")
	from karyo.payroll.employee_processing import employee_error_message, resolve_employees

	employees, _options = resolve_employees(cycle, employees)
	result = frappe._dict(approved=0, skipped=0, runs=[])
	for employee in employees:
		covered = set()
		for row in _submitted_bonus_runs(employee, cycle.name):
			covered.update(_run_bonus_codes(frappe.get_doc("PRB Payroll Run", row.name)))
		missing = set(AUTOMATIC_BONUS_CODES) - covered
		if not missing:
			result.skipped += 1
			continue
		drafts = frappe.get_all("PRB Payroll Run", filters={
			"employee": employee, "payroll_cycle": cycle.name,
			"run_purpose": ("in", AUTOMATIC_BONUS_PURPOSES),
			"custom_entry_source": "Automatic", "docstatus": 0,
		}, fields=["name", "custom_eligibility_status"], order_by="modified desc", limit_page_length=0)
		candidate = None
		for row in drafts:
			doc = frappe.get_doc("PRB Payroll Run", row.name)
			codes = _run_bonus_codes(doc)
			if codes and codes.issubset(missing):
				candidate = doc
				break
		if not candidate or candidate.custom_eligibility_status == "Not Eligible" or not flt(candidate.gross_pay):
			result.skipped += 1
			continue
		try:
			candidate.flags.ignore_permissions = True
			candidate.submit()
		except frappe.ValidationError as error:
			frappe.throw(employee_error_message(employee, error))
		result.approved += 1
		result.runs.append(candidate.name)
	return result


def post_attendance_bonuses(payroll_cycle, employees=None):
	"""Post approved payable attendance bonuses to mapped payroll components."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle) if isinstance(payroll_cycle, str) else payroll_cycle
	cycle.check_permission("read")
	from karyo.payroll.employee_processing import employee_error_message, resolve_employees
	from karyo.payroll.prb_posting import post_run

	employees, _options = resolve_employees(cycle, employees)
	rows = frappe.get_all("PRB Payroll Run", filters={
		"employee": ("in", employees or [""]), "payroll_cycle": cycle.name,
		"run_purpose": ("in", AUTOMATIC_BONUS_PURPOSES), "docstatus": 1,
		"snapshot_status": "Approved", "posting_status": ("!=", "Posted"),
	}, fields=["name", "employee"], order_by="employee asc, creation asc", limit_page_length=0)
	result = frappe._dict(posted=0, additional_salary=0, runs=[])
	for row in rows:
		run = frappe.get_doc("PRB Payroll Run", row.name)
		eligibility = automatic_bonus_eligibility(row.employee, cycle)
		if (not eligibility.eligible or not flt(run.gross_pay)
				or run.custom_eligibility_status == "Not Eligible"):
			continue
		try:
			posted = post_run(run.name)
		except frappe.ValidationError as error:
			frappe.throw(employee_error_message(row.employee, error))
		result.posted += 1
		result.additional_salary += len(posted.get("posted") or [])
		result.runs.append(run.name)
	return result


def process_automatic_attendance_bonuses(payroll_cycle, employees):
	"""Calculate, approve and post payable attendance bonuses before Salary Slips.

	The payroll-cycle population is the assignment scope. Existing submitted runs
	remain authoritative and are posted if needed; missing payable components are
	created once in an auditable automatic run. Repeated payroll preparation is
	idempotent and cannot create a second payment for the same employee/component.
	"""
	cycle = (
		frappe.get_doc("Payroll Cycle", payroll_cycle)
		if isinstance(payroll_cycle, str)
		else payroll_cycle
	)
	employees = list(dict.fromkeys(employees or []))
	result = {
		"eligible": 0,
		"not_eligible": 0,
		"created": 0,
		"posted_runs": 0,
		"already_processed": 0,
		"runs": [],
	}
	from karyo.payroll.prb_posting import post_run

	for employee in employees:
		person = frappe.db.get_value(
			"Employee", employee, ["company", "status"], as_dict=True
		)
		if not person or person.company != cycle.company or person.status != "Active":
			continue

		eligibility = automatic_bonus_eligibility(employee, cycle)
		if not eligibility.eligible:
			# Recalculate an existing automatic Draft so the EOM screen immediately
			# stops showing a stale payable amount. Submitted/posted snapshots remain
			# immutable and are simply prevented from being posted again here.
			draft = _automatic_draft(employee, cycle.name)
			if draft:
				draft.custom_eligibility_status = "Not Eligible"
				draft.custom_eligibility_reason = _eligibility_reason(cycle, eligibility, automatic=True)
				draft.flags.ignore_permissions = True
				draft.save(ignore_permissions=True)
			result["not_eligible"] += 1
			continue
		result["eligible"] += 1

		covered = set()
		for row in _submitted_bonus_runs(employee, cycle.name):
			run = frappe.get_doc("PRB Payroll Run", row.name)
			codes = _run_bonus_codes(run)
			if not codes:
				continue
			covered.update(codes)
			if run.posting_status != "Posted":
				post_run(run.name)
				result["posted_runs"] += 1
			result["runs"].append(run.name)

		missing = [
			row for row in eligibility["items"]
			if row["input_code"] not in covered and flt(row["calculated_amount"]) > 0
		]
		if not missing:
			result["already_processed"] += 1
			continue

		doc = _automatic_draft(employee, cycle.name) or frappe.new_doc("PRB Payroll Run")
		doc.employee = employee
		doc.company = cycle.company
		doc.payroll_cycle = cycle.name
		doc.payroll_period = cycle.get("payroll_period")
		doc.calculation_date = cycle.payment_date or cycle.end_date
		doc.review_year = getdate(cycle.end_date).year
		doc.run_purpose = _purpose_for_bonus_codes(row["input_code"] for row in missing)
		doc.set("employee_inputs", [])
		for row in missing:
			doc.append("employee_inputs", {
				key: row[key] for key in ("category", "input_code", "description", "amount")
			})
		if doc.meta.has_field("custom_entry_source"):
			doc.custom_entry_source = "Automatic"
		if doc.meta.has_field("custom_eligibility_status"):
			doc.custom_eligibility_status = "Eligible"
		if doc.meta.has_field("custom_eligibility_reason"):
			doc.custom_eligibility_reason = _eligibility_reason(cycle, eligibility, automatic=True)
		if doc.meta.has_field("custom_manual_reference"):
			doc.custom_manual_reference = _(
				"Automatically generated during payroll preparation for {0}."
			).format(cycle.name)

		doc.flags.ignore_permissions = True
		if doc.is_new():
			doc.insert(ignore_permissions=True)
		else:
			doc.save(ignore_permissions=True)
		doc.flags.ignore_permissions = True
		doc.submit()
		post_run(doc.name)
		result["created"] += 1
		result["posted_runs"] += 1
		result["runs"].append(doc.name)
	return result


def calculation_help(screen, rows):
	"""Payload used by the drawer's expandable sample and calculation flow."""
	items = []
	for row in rows or []:
		code = str(row.get("input_code") or "").strip().upper()
		rule = BONUS_BASES.get(code, {})
		items.append({
			"input_code": code,
			"label": row.get("description") or rule.get("label") or code,
			"base": flt(row.get("amount") or configured_bonus_base(code)),
			"setting": rule.get("setting"),
			"rule_ref": rule.get("rule_ref"),
		})
	return {
		"button_label": "See sample calculation",
		"items": items,
		"combined": len(items) > 1,
		"screen": screen,
		"flow": [
			"Prepare Payroll selects every employee in the payroll population automatically; manual selection remains available for corrections.",
			"The system merges submitted Attendance and approved leave in the cycle by date: Half Day = 0.5; Absent or On Leave = 1 day. Overlapping records count once.",
			"It applies 100%, 75%, 50%, 25% or 0% to the editable base amount.",
			"For a qualifying employee, the system creates and approves an auditable PRB Payroll Run.",
			"It automatically posts the applicable Additional Salary component to the employee and payroll cycle; Salary Slip calculation then includes it.",
		],
	}
