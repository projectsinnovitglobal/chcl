# Copyright (c) 2026, AstraFlow and Contributors
# See license.txt

"""Phase 5 — Employee Self-Service channel (G11; PB-APP-001/010).

Verifies that the ESS layer resolves the employee from the logged-in user (never
the client), shows only the caller's own data, runs the identical desk validation
on submit, advances the request to Pending Approval for HR, and blocks acting on
another employee's request.

    bench --site dev.localhost run-tests --module karyo.passage_benefit.test_ess
"""

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.passage_benefit import ess


def _make_user(email):
	if frappe.db.exists("User", email):
		return email
	frappe.get_doc(
		{
			"doctype": "User",
			"email": email,
			"first_name": email.split("@")[0],
			"send_welcome_email": 0,
			"roles": [{"role": "Employee"}],
		}
	).insert(ignore_permissions=True)
	return email


class TestPassageBenefitESS(FrappeTestCase):
	def setUp(self):
		frappe.db.delete("Passage Benefit Parameter Version", {"parent": "Passage Benefit Settings"})
		self.company = frappe.db.get_value("Company", {}, "name")
		if not self.company:
			self.skipTest("no Company on site")
		if not frappe.db.exists("Workflow", "Passage Benefit Application"):
			self.skipTest("PB Application workflow not installed")
		frappe.db.set_single_value("Passage Benefit Settings", "min_salary_threshold", 0)
		frappe.db.set_single_value("Passage Benefit Settings", "min_years_service", 10)
		frappe.db.set_single_value("Passage Benefit Settings", "eligibility_mode", "Route-based (salary or service)")
		frappe.db.set_single_value("Passage Benefit Settings", "require_confirmation", 0)
		frappe.db.set_single_value("Passage Benefit Settings", "require_permanent_employee", 0)
		frappe.db.set_single_value("Passage Benefit Settings", "vacation_leave_type", None)
		frappe.db.set_single_value("Passage Benefit Settings", "allow_negative_balance", 0)

		self.user1 = _make_user("ess.one@karyo.test")
		self.user2 = _make_user("ess.two@karyo.test")
		self.emp1 = self._make_employee("Ess", "One", self.user1)
		self.emp2 = self._make_employee("Ess", "Two", self.user2)
		self._make_bank(self.emp1, 10000)
		self._make_bank(self.emp2, 10000)
		self.item = self._usage_item()
		frappe.db.set_value("Passage Benefit Usage Item", self.item, "requires_document", 0)

	def tearDown(self):
		frappe.set_user("Administrator")

	def _make_employee(self, first, last, user):
		existing = frappe.db.get_value("Employee", {"user_id": user}, "name")
		if existing:
			frappe.db.set_value("Employee", existing, {"status": "Active", "pb_eligible": 1})
			return existing
		return (
			frappe.get_doc(
				{
					"doctype": "Employee",
					"first_name": first,
					"last_name": last,
					"gender": frappe.db.get_value("Gender", {}, "name") or "Male",
					"date_of_birth": "1985-01-01",
					"date_of_joining": "2015-01-01",
					"company": self.company,
					"status": "Active",
					"pb_eligible": 1,
					"user_id": user,
				}
			)
			.insert(ignore_permissions=True, ignore_mandatory=True)
			.name
		)

	def _make_bank(self, employee, opening):
		if frappe.db.exists("Passage Benefit Bank", employee):
			return
		frappe.get_doc(
			{
				"doctype": "Passage Benefit Bank",
				"employee": employee,
				"opening_date": "2026-01-01",
				"opening_balance": opening,
			}
		).insert(ignore_permissions=True)

	def _usage_item(self):
		name = "Karyo ESS Usage"
		if not frappe.db.exists("Passage Benefit Usage Item", name):
			frappe.get_doc(
				{
					"doctype": "Passage Benefit Usage Item",
					"usage_item_code": name,
					"usage_item_name": name,
					"encash_rate": 100,
					"min_balance_credit": 0,
					"requires_document": 0,
					"is_active": 1,
				}
			).insert(ignore_permissions=True)
		return name

	# --- identity / isolation ---------------------------------------------
	def test_summary_shows_own_data(self):
		frappe.set_user(self.user1)
		summary = ess.get_my_summary()
		self.assertEqual(summary["employee"], self.emp1)
		self.assertEqual(summary["bank"]["current_balance"], 10000)
		self.assertTrue(summary["has_bank"])
		self.assertTrue(summary["eligible"])

	def test_guest_is_blocked(self):
		frappe.set_user("Guest")
		with self.assertRaises(frappe.PermissionError):
			ess.get_my_summary()

	def test_unlinked_desk_user_gets_empty_summary(self):
		user = _make_user(f"ess.unlinked.{frappe.generate_hash(length=8)}@karyo.test")
		frappe.set_user(user)
		summary = ess.get_my_summary()
		self.assertIsNone(summary["employee"])
		self.assertFalse(summary["has_bank"])
		self.assertEqual(summary["applications"], [])
		self.assertEqual(summary["ledger"], [])

	# --- submission uses the desk validation path -------------------------
	def test_submit_binds_to_current_user_and_advances(self):
		frappe.set_user(self.user1)
		res = ess.submit_application(
			usage_item=self.item,
			trips=[{"destination": "Rodrigues", "ticket_amount": 500}],
			submit_for_approval=1,
		)
		self.assertEqual(res["workflow_state"], "Pending Approval")
		self.assertEqual(res["request_amount"], 500)  # trips drive the amount (PB-APP-003)
		self.assertEqual(res["claimable_amount"], 500)  # 100% encash rate
		# The request is bound to the logged-in employee, not any client-supplied id.
		self.assertEqual(
			frappe.db.get_value("Passage Benefit Application", res["name"], "employee"), self.emp1
		)
		comment = frappe.get_all(
			"Comment",
			filters={"reference_doctype": "Passage Benefit Application", "reference_name": res["name"], "comment_type": "Workflow"},
			fields=["owner", "content"],
			order_by="creation desc",
			limit=1,
		)[0]
		self.assertEqual(comment.owner, self.user1)
		self.assertIn("Submitted for approval", comment.content)

	def test_submit_enforces_balance_check(self):
		frappe.set_user(self.user1)
		with self.assertRaises(frappe.ValidationError):
			ess.submit_application(
				usage_item=self.item,
				trips=[{"destination": "Moon", "ticket_amount": 999999}],
				submit_for_approval=0,
			)

	def test_required_private_upload_is_bound_to_own_request(self):
		frappe.db.set_value("Passage Benefit Usage Item", self.item, "requires_document", 1)
		file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "ess-ticket.pdf",
				"file_url": f"/private/files/ess-ticket-{self.emp1}.pdf",
				"is_private": 1,
				"owner": self.user1,
			}
		)
		file.db_insert()
		frappe.db.set_value("File", file.name, "owner", self.user1, update_modified=False)
		frappe.set_user(self.user1)
		res = ess.submit_application(
			usage_item=self.item,
			trips=[{"destination": "Rodrigues", "ticket_amount": 500}],
			supporting_document=file.file_url,
		)
		attached = frappe.db.get_value(
			"File", file.name, ["attached_to_doctype", "attached_to_name"], as_dict=True
		)
		self.assertEqual(attached.attached_to_doctype, "Passage Benefit Application")
		self.assertEqual(attached.attached_to_name, res["name"])

	def test_employee_cannot_attach_another_users_private_upload(self):
		file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "other-ticket.pdf",
				"file_url": f"/private/files/other-ticket-{self.emp2}.pdf",
				"is_private": 1,
				"owner": self.user2,
			}
		)
		file.db_insert()
		frappe.db.set_value("File", file.name, "owner", self.user2, update_modified=False)
		frappe.set_user(self.user1)
		with self.assertRaises(frappe.PermissionError):
			ess.submit_application(
				usage_item=self.item,
				trips=[{"destination": "Rodrigues", "ticket_amount": 500}],
				supporting_document=file.file_url,
				submit_for_approval=0,
			)

	# --- withdraw is guarded to the owner ---------------------------------
	def test_cannot_withdraw_another_employees_request(self):
		frappe.set_user(self.user1)
		res = ess.submit_application(
			usage_item=self.item, trips=[{"destination": "Rodrigues", "ticket_amount": 100}]
		)
		frappe.set_user(self.user2)
		with self.assertRaises(frappe.PermissionError):
			ess.withdraw_application(res["name"])

	def test_withdraw_own_pending_request(self):
		frappe.set_user(self.user1)
		res = ess.submit_application(
			usage_item=self.item, trips=[{"destination": "Rodrigues", "ticket_amount": 100}]
		)
		out = ess.withdraw_application(res["name"])
		self.assertEqual(out["workflow_state"], "Rejected")
		self.assertEqual(
			frappe.db.get_value("Passage Benefit Application", res["name"], "remarks"),
			"Withdrawn by employee through ESS.",
		)

	def test_preview_uses_server_rules_without_creating_or_debiting(self):
		frappe.set_user(self.user1)
		before = frappe.db.count("Passage Benefit Application", {"employee": self.emp1})
		balance = frappe.db.get_value("Passage Benefit Bank", self.emp1, "current_balance")
		result = ess.preview_application(usage_item=self.item, request_amount=500)
		self.assertTrue(result["ready"])
		self.assertEqual(result["claimable_amount"], 500)
		self.assertFalse(ess.preview_application(usage_item=self.item, request_amount=999999)["ready"])
		self.assertEqual(frappe.db.count("Passage Benefit Application", {"employee": self.emp1}), before)
		self.assertEqual(frappe.db.get_value("Passage Benefit Bank", self.emp1, "current_balance"), balance)

	def test_preview_and_submission_reject_future_date_and_inactive_bank(self):
		from frappe.utils import add_days, today
		frappe.set_user(self.user1)
		self.assertFalse(ess.preview_application(usage_item=self.item, request_amount=500, posting_date=add_days(today(),1))["ready"])
		with self.assertRaises(frappe.ValidationError):
			ess.submit_application(usage_item=self.item, request_amount=500, posting_date=add_days(today(),1))
		frappe.db.set_value("Passage Benefit Bank", self.emp1, "status", "Inactive")
		self.assertFalse(ess.preview_application(usage_item=self.item, request_amount=500)["ready"])
		with self.assertRaises(frappe.ValidationError):
			ess.submit_application(usage_item=self.item, request_amount=500)
		frappe.db.set_value("Passage Benefit Bank", self.emp1, "status", "Active")

	def test_pending_withdrawal_remains_possible_after_bank_is_inactive(self):
		frappe.set_user(self.user1)
		request = ess.submit_application(usage_item=self.item, request_amount=500)
		frappe.db.set_value("Passage Benefit Bank", self.emp1, "status", "Inactive")
		self.assertEqual(ess.withdraw_application(request["name"])["workflow_state"], "Rejected")
		frappe.db.set_value("Passage Benefit Bank", self.emp1, "status", "Active")
