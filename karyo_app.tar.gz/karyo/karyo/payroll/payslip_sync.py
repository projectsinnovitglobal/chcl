"""Keep payslip display fields tied to their authoritative payroll sources."""

import json

import frappe
from frappe import _
from frappe.utils import add_days, date_diff, flt, getdate


def _basic_component():
	"""Return the Salary Component governed by the active BASIC PDB mapping."""
	pdb_code = frappe.db.get_value(
		"PRB Payroll Component Mapping",
		{"component_code": "BASIC", "is_active": 1},
		"pdb_code",
	)
	return (
		frappe.db.get_value("Payroll PDB Code", pdb_code, "salary_component")
		if pdb_code
		else None
	)


def _approved_leave_dates(employee, start_date, end_date):
	"""Expand approved applications into unique payable leave units by date."""
	from erpnext.setup.doctype.employee.employee import is_holiday

	start, end = getdate(start_date), getdate(end_date)
	units = {}
	for application in frappe.get_all(
		"Leave Application",
		filters={
			"employee": employee,
			"status": "Approved",
			"docstatus": 1,
			"from_date": ("<=", end),
			"to_date": (">=", start),
		},
		fields=["from_date", "to_date", "half_day", "half_day_date", "total_leave_days"],
		limit_page_length=500,
	):
		remaining = flt(application.total_leave_days, 2)
		for offset in range(date_diff(application.to_date, application.from_date) + 1):
			day = getdate(add_days(application.from_date, offset))
			if remaining <= 0 or is_holiday(employee, day, raise_exception=False):
				continue
			value = 0.5 if (
				application.half_day
				and getdate(application.half_day_date or application.to_date) == day
			) else 1.0
			value = min(value, remaining)
			remaining -= value
			if start <= day <= end:
				units[day] = max(units.get(day, 0), value)
	return units


def salary_slip_attendance_summary(employee, start_date, end_date, native_absent_days=0):
	"""Return non-overlapping attendance and leave figures for one payslip.

	Native HRMS ``absent_days`` remains the payroll deduction input.  Leave days
	are deliberately separate: they come from submitted On Leave/Half Day rows
	and approved Leave Applications, with the same date counted only once.
	"""
	start, end = getdate(start_date), getdate(end_date)
	leave_by_date = _approved_leave_dates(employee, start, end)
	present_by_date = {}
	absent_by_date = {}
	attendance_names = []
	for row in frappe.get_all(
		"Attendance",
		filters={
			"employee": employee,
			"attendance_date": ("between", [start, end]),
			"docstatus": 1,
		},
		fields=["name", "attendance_date", "status", "leave_type", "half_day_status"],
		limit_page_length=500,
	):
		attendance_names.append(row.name)
		day = getdate(row.attendance_date)
		if row.status in {"Present", "Work From Home"}:
			present_by_date[day] = max(present_by_date.get(day, 0), 1.0)
		elif row.status == "On Leave":
			leave_by_date[day] = max(leave_by_date.get(day, 0), 1.0)
		elif row.status == "Absent":
			absent_by_date[day] = max(absent_by_date.get(day, 0), 1.0)
		elif row.status == "Half Day":
			present_by_date[day] = max(present_by_date.get(day, 0), 0.5)
			if row.leave_type or row.half_day_status == "On Leave":
				leave_by_date[day] = max(leave_by_date.get(day, 0), 0.5)
			else:
				absent_by_date[day] = max(absent_by_date.get(day, 0), 0.5)

	leave_days = flt(sum(leave_by_date.values()), 2)
	present_days = flt(sum(present_by_date.values()), 2)
	explicit_absent_days = flt(sum(absent_by_date.values()), 2)
	native_absent_days = flt(native_absent_days, 2)
	return frappe._dict(
		leave_days=leave_days,
		present_days=present_days,
		explicit_absent_days=explicit_absent_days,
		unmarked_absent_days=flt(max(0, native_absent_days - explicit_absent_days), 2),
		native_absent_days=native_absent_days,
		attendance_records=attendance_names,
		leave_dates=[str(day) for day in sorted(leave_by_date)],
	)


def payslip_values(doc):
	"""Resolve Basic Pay and attendance totals from the rows used by payroll."""
	basic_component = _basic_component()
	basic_pay = sum(
		flt(row.amount)
		for row in (doc.get("earnings") or [])
		if basic_component and row.salary_component == basic_component
	)
	attendance = salary_slip_attendance_summary(
		doc.employee, doc.start_date, doc.end_date, doc.get("absent_days") or 0
	)
	return frappe._dict(
		basic_component=basic_component,
		basic_pay=flt(basic_pay, 2),
		**attendance,
	)


def sync_salary_slip_fields(doc, method=None):
	"""Salary Slip validate hook: persist the values displayed on every output."""
	if not (doc.get("employee") and doc.get("start_date") and doc.get("end_date")):
		return
	values = payslip_values(doc)
	if doc.meta.has_field("karyo_basic_pay"):
		doc.karyo_basic_pay = values.basic_pay
	if doc.meta.has_field("karyo_leave_days"):
		doc.karyo_leave_days = values.leave_days
	if doc.meta.has_field("karyo_present_days"):
		doc.karyo_present_days = values.present_days
	if doc.meta.has_field("karyo_attendance_summary"):
		doc.karyo_attendance_summary = json.dumps(dict(values), sort_keys=True, default=str)

	# A positive governed base and positive payment days must produce the mapped
	# Basic earning. Blocking here prevents a plausible-looking gross figure made
	# entirely of allowances from being released as a valid salary slip.
	assignment_date = getdate(doc.get("actual_start_date") or doc.start_date)
	assignment = frappe.db.get_value(
		"Salary Structure Assignment",
		{
			"employee": doc.employee,
			"salary_structure": doc.get("salary_structure"),
			"from_date": ("<=", assignment_date),
			"docstatus": 1,
		},
		["name", "base"],
		order_by="from_date desc, creation desc",
		as_dict=True,
	)
	structure_has_basic = bool(
		values.basic_component
		and doc.get("salary_structure")
		and frappe.db.exists(
			"Salary Detail",
			{
				"parent": doc.salary_structure,
				"parenttype": "Salary Structure",
				"parentfield": "earnings",
				"salary_component": values.basic_component,
			},
		)
	)
	from karyo.hr.final_settlement import is_post_exit_run
	if structure_has_basic and flt(doc.get("payment_days")) > 0 and values.basic_pay <= 0 and not is_post_exit_run(doc.employee, doc.start_date):
		frappe.throw(
			_(
				"Basic Pay is missing from this Salary Slip although Salary Structure {0} "
				"contains the mapped Basic component. Correct Salary Structure Assignment {1} "
				"and regenerate the slip."
			).format(doc.salary_structure, assignment.name if assignment else _("(missing)"))
		)


def backfill_salary_slip_fields():
	"""Populate display fields on existing non-cancelled slips after migration."""
	meta = frappe.get_meta("Salary Slip")
	fieldnames = {
		fieldname
		for fieldname in (
			"karyo_basic_pay", "karyo_leave_days", "karyo_present_days", "karyo_attendance_summary"
		)
		if meta.has_field(fieldname)
	}
	if not fieldnames:
		return 0
	updated = 0
	for name in frappe.get_all("Salary Slip", filters={"docstatus": ("<", 2)}, pluck="name"):
		doc = frappe.get_doc("Salary Slip", name)
		values = payslip_values(doc)
		payload = {
			"karyo_basic_pay": values.basic_pay,
			"karyo_leave_days": values.leave_days,
			"karyo_present_days": values.present_days,
			"karyo_attendance_summary": json.dumps(dict(values), sort_keys=True, default=str),
		}
		frappe.db.set_value(
			"Salary Slip", name,
			{key: value for key, value in payload.items() if key in fieldnames},
			update_modified=False,
		)
		updated += 1
	return updated
