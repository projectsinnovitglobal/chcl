"""Native desk widgets: Number Cards + Dashboard Charts for the Karyo workspace.

    bench --site dev.localhost execute karyo.setup.dashboards.setup

Idempotent delete-recreate (same convention as setup/workspace.py — user edits to
these records are reset on re-run). workspace.py references the names created
here, so this module must run before it in install.SETUP_SEQUENCE.
"""

import json

import frappe

CHART_PALETTE = ["#0B6CFB", "#10B981", "#F6821F", "#7EB0FC", "#0A4FB5", "#A3A3A3"]

NUMBER_CARDS = [
	{
		"label": "Active Loans",
		"document_type": "Karyo Loan",
		"function": "Count",
		"filters_json": json.dumps([["Karyo Loan", "status", "=", "Active", False]]),
		"color": "#0B6CFB",
	},
	{
		"label": "Outstanding Capital",
		"document_type": "Karyo Loan",
		"function": "Sum",
		"aggregate_function_based_on": "outstanding_capital",
		"filters_json": json.dumps([["Karyo Loan", "status", "=", "Active", False]]),
		"color": "#0B6CFB",
	},
	{
		"label": "Monthly Loan Deductions",
		"document_type": "Karyo Loan",
		"function": "Sum",
		"aggregate_function_based_on": "monthly_refund",
		"filters_json": json.dumps([["Karyo Loan", "status", "=", "Active", False]]),
		"color": "#0A4FB5",
	},
	{
		"label": "Loans in Pipeline",
		"document_type": "Karyo Loan",
		"function": "Count",
		"filters_json": json.dumps(
			[
				[
					"Karyo Loan",
					"workflow_state",
					"in",
					[
						"Loan Committee Scheduled",
						"Under Loan Committee Review",
						"Recommended",
						"Managing Director Approval Pending",
						"Approved",
						"Agreement Printed",
						"Disbursed",
					],
					False,
				]
			]
		),
		"color": "#F59E0B",
	},
	{
		"label": "Active PB Banks",
		"document_type": "Passage Benefit Bank",
		"function": "Count",
		"filters_json": json.dumps([["Passage Benefit Bank", "status", "=", "Active", False]]),
		"color": "#10B981",
	},
	{
		"label": "PB Total Balance",
		"document_type": "Passage Benefit Bank",
		"function": "Sum",
		"aggregate_function_based_on": "current_balance",
		"filters_json": json.dumps([["Passage Benefit Bank", "status", "=", "Active", False]]),
		"color": "#10B981",
	},
	{
		"label": "Claims Awaiting Action",
		"document_type": "Passage Benefit Application",
		"function": "Count",
		"filters_json": json.dumps(
			[
				[
					"Passage Benefit Application",
					"workflow_state",
					"in",
					["Pending Approval", "Recommended", "Approved"],
					False,
				]
			]
		),
		"color": "#F6821F",
	},
	{
		"label": "Payroll Exceptions",
		"document_type": "PRB Payroll Run",
		"function": "Count",
		"filters_json": json.dumps([["PRB Payroll Run", "exception_code", "is", "set", False]]),
		"color": "#DC2626",
	},
	{
		"label": "Draft Payroll Runs",
		"document_type": "PRB Payroll Run",
		"function": "Count",
		"filters_json": json.dumps([["PRB Payroll Run", "docstatus", "=", "0", False]]),
		"color": "#A3A3A3",
	},
	{
		"label": "Appraisals Submitted",
		"document_type": "PMS Appraisal",
		"function": "Count",
		"filters_json": json.dumps([["PMS Appraisal", "docstatus", "=", "1", False]]),
		"color": "#0B6CFB",
	},
]

CHARTS = [
	{
		"chart_name": "PB Accrual Trend",
		"chart_type": "Sum",
		"document_type": "Passage Benefit Ledger Entry",
		"based_on": "posting_date",
		"value_based_on": "amount",
		"timeseries": 1,
		"timespan": "Last Year",
		"time_interval": "Monthly",
		"type": "Line",
		"filters_json": json.dumps([["Passage Benefit Ledger Entry", "entry_type", "=", "Earning", False]]),
		"color": "#10B981",
	},
	{
		"chart_name": "PB Applications by State",
		"chart_type": "Group By",
		"group_by_type": "Count",
		"document_type": "Passage Benefit Application",
		"group_by_based_on": "workflow_state",
		"type": "Donut",
		"filters_json": json.dumps([]),
	},
	{
		"chart_name": "Loans by Type",
		"chart_type": "Group By",
		"group_by_type": "Sum",
		"document_type": "Karyo Loan",
		"group_by_based_on": "loan_type",
		"aggregate_function_based_on": "outstanding_capital",
		"type": "Donut",
		"filters_json": json.dumps([["Karyo Loan", "docstatus", "=", "1", False]]),
	},
	{
		"chart_name": "Loan Pipeline",
		"chart_type": "Group By",
		"group_by_type": "Count",
		"document_type": "Karyo Loan",
		"group_by_based_on": "workflow_state",
		"type": "Bar",
		"filters_json": json.dumps([]),
		"color": "#0B6CFB",
	},
	{
		"chart_name": "Payroll Gross by Period",
		"chart_type": "Group By",
		"group_by_type": "Sum",
		"document_type": "PRB Payroll Run",
		"group_by_based_on": "period",
		"aggregate_function_based_on": "gross_pay",
		"type": "Bar",
		"filters_json": json.dumps([["PRB Payroll Run", "docstatus", "=", "1", False]]),
		"color": "#0B6CFB",
	},
	{
		"chart_name": "EOY Bonus by Case",
		"chart_type": "Group By",
		"group_by_type": "Sum",
		"document_type": "EOY Bonus",
		"group_by_based_on": "case",
		"aggregate_function_based_on": "bonus_amount",
		"type": "Percentage",
		"filters_json": json.dumps([["EOY Bonus", "docstatus", "=", "1", False]]),
	},
	{
		"chart_name": "New Employees",
		"chart_type": "Count",
		"document_type": "Employee",
		"based_on": "date_of_joining",
		"timeseries": 1,
		"timespan": "Last Year",
		"time_interval": "Monthly",
		"type": "Bar",
		"filters_json": json.dumps([]),
		"color": "#0B6CFB",
	},
]


def create_number_cards():
	for card in NUMBER_CARDS:
		if frappe.db.exists("Number Card", card["label"]):
			frappe.delete_doc("Number Card", card["label"], ignore_permissions=True, force=True)
		doc = frappe.get_doc(
			{
				"doctype": "Number Card",
				"name": card["label"],
				"type": "Document Type",
				"module": "Karyo",
				"is_public": 1,
				"is_standard": 0,
				"show_percentage_stats": 1,
				"stats_time_interval": "Monthly",
				**card,
			}
		)
		doc.insert(ignore_permissions=True)
		print(f"  + Number Card: {card['label']}")


def create_charts():
	for chart in CHARTS:
		if frappe.db.exists("Dashboard Chart", chart["chart_name"]):
			frappe.delete_doc("Dashboard Chart", chart["chart_name"], ignore_permissions=True, force=True)
		doc = frappe.get_doc(
			{
				"doctype": "Dashboard Chart",
				"name": chart["chart_name"],
				"module": "Karyo",
				"is_public": 1,
				"is_standard": 0,
				"custom_options": json.dumps({"colors": CHART_PALETTE, "height": 260}),
				**chart,
			}
		)
		doc.insert(ignore_permissions=True)
		print(f"  + Dashboard Chart: {chart['chart_name']}")


def setup():
	print("Karyo number cards + dashboard charts:")
	create_number_cards()
	create_charts()
	frappe.db.commit()
	print("Done.")
