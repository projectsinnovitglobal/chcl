"""End-of-Year Bonus DocType + payroll component (EOY-*).

bench --site dev.localhost execute karyo.setup.eoy.setup
"""

import frappe

from karyo.setup.foundation import f, make_doctype

COMPONENT = "EOY Bonus"


def create_component():
	if not frappe.db.exists("Salary Component", COMPONENT):
		frappe.get_doc(
			{
				"doctype": "Salary Component",
				"salary_component": COMPONENT,
				"salary_component_abbr": "EOY",
				"type": "Earning",
				"is_tax_applicable": 1,
			}
		).insert(ignore_permissions=True)
		print(f"  + Salary Component: {COMPONENT}")


def create_doctype():
	make_doctype(
		"EOY Bonus",
		is_submittable=1,
		autoname="naming_series:",
		title_field="employee_name",
		fields=[
			f("naming_series", "Select", "Series", options="EOY-.YYYY.-.#####", default="EOY-.YYYY.-.#####"),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("year", "Int", "Year", reqd=1, in_list_view=1),
			f(
				"case",
				"Select",
				"Case",
				options="Full Year\nPro-rata Service\nHalf-pay Leave\nIntermittent / Bank Scheme\nExcluded",
				default="Full Year",
				reqd=1,
				in_list_view=1,
			),
			f("hcb", "Column Break"),
			f("monthly_salary", "Currency", "Monthly Salary"),
			f(
				"acting_allowance",
				"Currency",
				"Acting Allowance",
				description="Added to the base for acting/higher-duty cases (EOY-11/12).",
			),
			f("inp_sb", "Section Break", "Case Inputs"),
			f("service_months", "Int", "Service Months", depends_on="eval:doc.case=='Pro-rata Service'"),
			f(
				"actual_salary_drawn",
				"Currency",
				"Actual Salary Drawn",
				depends_on="eval:doc.case=='Half-pay Leave'",
			),
			f(
				"total_annual_salary",
				"Currency",
				"Total Annual Salary",
				depends_on="eval:doc.case=='Half-pay Leave'",
			),
			f("icb", "Column Break"),
			f(
				"actual_annual_earnings",
				"Currency",
				"Actual Annual Earnings",
				depends_on="eval:doc.case=='Intermittent / Bank Scheme'",
			),
			f(
				"fulltime_annual_salary",
				"Currency",
				"Full-time Annual Salary",
				depends_on="eval:doc.case=='Intermittent / Bank Scheme'",
			),
			f(
				"excluded_reason",
				"Select",
				"Excluded Reason",
				options="\nresigned_private\nown_convenience\ndismissed\ninterdiction",
				depends_on="eval:doc.case=='Excluded'",
			),
			f(
				"reinstated",
				"Check",
				"Reinstated (interdiction, approved)",
				depends_on="eval:doc.case=='Excluded'",
			),
			f("res_sb", "Section Break", "Result"),
			f("bonus_amount", "Currency", "Bonus Amount", read_only=1, in_list_view=1),
			f("pdb_component", "Link", "Payroll Component", options="Salary Component"),
			f("rcb", "Column Break"),
			f(
				"additional_salary",
				"Link",
				"Payroll Entry (Additional Salary)",
				options="Additional Salary",
				read_only=1,
			),
		],
	)


def setup():
	print("Karyo EOY Bonus setup:")
	create_component()
	create_doctype()
	frappe.db.commit()
	print("Done.")
