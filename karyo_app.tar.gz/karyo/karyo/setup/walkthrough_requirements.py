"""Install the cross-module controls requested in the HRMS walkthrough.

The fields live on the records that own the transaction: Employee owns bank
routing and temporary post-exit eligibility, Salary Slip snapshots remittance
instructions, Salary Appointment owns exceptional pay authority, and Employee
Separation owns the final-settlement snapshot.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	create_custom_fields(
		{
			"Employee": [
				{"fieldname": "karyo_secondary_bank_sb", "fieldtype": "Section Break", "label": "Secondary Salary Bank (Optional Fixed Amount)", "insert_after": "iban", "collapsible": 0, "depends_on": "eval:doc.salary_mode == 'Bank'", "description": "Enter the fixed amount to transfer here. Payroll sends the remaining net salary to the primary account."},
				{"fieldname": "karyo_secondary_payroll_bank", "fieldtype": "Link", "label": "Secondary Payroll Bank", "options": "Bank", "insert_after": "karyo_secondary_bank_sb", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_secondary_payroll_bank_branch", "fieldtype": "Link", "label": "Secondary Payroll Bank Branch", "options": "Payroll Bank Branch", "insert_after": "karyo_secondary_payroll_bank", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_secondary_bank_account_no", "fieldtype": "Data", "label": "Secondary Account Number", "insert_after": "karyo_secondary_payroll_bank_branch", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_secondary_bank_account_holder", "fieldtype": "Data", "label": "Secondary Account Holder", "insert_after": "karyo_secondary_bank_account_no", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_secondary_bank_cb", "fieldtype": "Column Break", "insert_after": "karyo_secondary_bank_account_holder", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_secondary_bank_fixed_amount", "fieldtype": "Currency", "label": "Fixed Amount to Secondary Bank", "insert_after": "karyo_secondary_bank_cb", "depends_on": "eval:doc.salary_mode == 'Bank'", "description": "The lesser of this amount and net pay is sent to the secondary account; the balance is sent to the primary account."},
				{"fieldname": "karyo_secondary_bank_effective_from", "fieldtype": "Date", "label": "Secondary Account Effective From", "insert_after": "karyo_secondary_bank_fixed_amount", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_secondary_bank_effective_to", "fieldtype": "Date", "label": "Secondary Account Effective To", "insert_after": "karyo_secondary_bank_effective_from", "depends_on": "eval:doc.salary_mode == 'Bank'"},
				{"fieldname": "karyo_post_exit_payroll_sb", "fieldtype": "Section Break", "label": "Approved Post-Exit Payment Window", "insert_after": "karyo_bank_master_details", "collapsible": 1},
				{"fieldname": "karyo_post_exit_payroll_enabled", "fieldtype": "Check", "label": "Temporarily Active for Approved Payment", "read_only": 1, "insert_after": "karyo_post_exit_payroll_sb"},
				{"fieldname": "karyo_post_exit_payroll_until", "fieldtype": "Date", "label": "Payment Window Until", "read_only": 1, "insert_after": "karyo_post_exit_payroll_enabled"},
				{"fieldname": "karyo_post_exit_payment_reference", "fieldtype": "Data", "label": "Approval Reference", "read_only": 1, "insert_after": "karyo_post_exit_payroll_until"},
			],
			"Salary Slip": [
				{"fieldname": "karyo_bank_split_sb", "fieldtype": "Section Break", "label": "Salary Bank Split", "insert_after": "net_pay", "collapsible": 1},
				{"fieldname": "karyo_primary_remittance_bank", "fieldtype": "Link", "label": "Primary Bank", "options": "Bank", "read_only": 1, "insert_after": "karyo_bank_split_sb"},
				{"fieldname": "karyo_primary_remittance_branch", "fieldtype": "Link", "label": "Primary Branch", "options": "Payroll Bank Branch", "read_only": 1, "insert_after": "karyo_primary_remittance_bank"},
				{"fieldname": "karyo_primary_remittance_account", "fieldtype": "Data", "label": "Primary Account", "read_only": 1, "insert_after": "karyo_primary_remittance_branch"},
				{"fieldname": "karyo_primary_remittance_amount", "fieldtype": "Currency", "label": "Primary Amount", "read_only": 1, "insert_after": "karyo_primary_remittance_account"},
				{"fieldname": "karyo_bank_split_cb", "fieldtype": "Column Break", "insert_after": "karyo_primary_remittance_amount"},
				{"fieldname": "karyo_secondary_remittance_bank", "fieldtype": "Link", "label": "Secondary Bank", "options": "Bank", "read_only": 1, "insert_after": "karyo_bank_split_cb"},
				{"fieldname": "karyo_secondary_remittance_branch", "fieldtype": "Link", "label": "Secondary Branch", "options": "Payroll Bank Branch", "read_only": 1, "insert_after": "karyo_secondary_remittance_bank"},
				{"fieldname": "karyo_secondary_remittance_account", "fieldtype": "Data", "label": "Secondary Account", "read_only": 1, "insert_after": "karyo_secondary_remittance_branch"},
				{"fieldname": "karyo_secondary_remittance_amount", "fieldtype": "Currency", "label": "Secondary Amount", "read_only": 1, "insert_after": "karyo_secondary_remittance_account"},
			],
			"Employee Salary Appointment": [
				{"fieldname": "beyond_scale_sb", "fieldtype": "Section Break", "label": "Long-Service Salary Beyond Scale", "insert_after": "prb_year", "collapsible": 0, "depends_on": "eval:doc.pay_basis!='PRB'"},
				{"fieldname": "beyond_scale_authorized", "fieldtype": "Check", "label": "Long Service Increment", "insert_after": "beyond_scale_sb", "depends_on": "eval:doc.pay_basis!='PRB'"},
				{"fieldname": "beyond_scale_salary", "fieldtype": "Currency", "label": "Authorized Basic Salary", "options": "currency", "insert_after": "beyond_scale_authorized", "depends_on": "eval:doc.beyond_scale_authorized"},
				{"fieldname": "beyond_scale_authority", "fieldtype": "Small Text", "label": "Beyond-Scale Authority / Reference", "insert_after": "beyond_scale_salary", "depends_on": "eval:doc.beyond_scale_authorized"},
				{"fieldname": "beyond_scale_reason", "fieldtype": "Small Text", "label": "Long-Service Justification", "insert_after": "beyond_scale_authority", "depends_on": "eval:doc.beyond_scale_authorized"},
				{"fieldname": "prb_phase_percent", "fieldtype": "Percent", "label": "PRB Increase Applied", "read_only": 1, "insert_after": "beyond_scale_reason", "depends_on": "eval:doc.pay_basis=='PRB'"},
				{"fieldname": "prb_full_salary", "fieldtype": "Currency", "label": "PRB Full Revised Salary", "options": "currency", "read_only": 1, "insert_after": "prb_phase_percent", "depends_on": "eval:doc.pay_basis=='PRB'"},
			],
			"Employee Separation": [
				{"fieldname": "karyo_leaving_date", "fieldtype": "Date", "label": "Leaving Service Date", "insert_after": "boarding_begins_on", "reqd": 1, "allow_on_submit": 1, "description": "The authoritative cut-off date for leave, Passage Benefit and loan balances."},
				{"fieldname": "karyo_final_settlement_sb", "fieldtype": "Section Break", "label": "Leaving Service Final Settlement", "insert_after": "karyo_leaving_date", "collapsible": 0},
				{"fieldname": "karyo_settlement_status", "fieldtype": "Select", "label": "Settlement Status", "options": "Preview\nFinalized", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_final_settlement_sb"},
				{"fieldname": "karyo_settlement_as_at", "fieldtype": "Date", "label": "Balance Cut-off Date", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_settlement_status"},
				{"fieldname": "karyo_basic_salary", "fieldtype": "Currency", "label": "Basic Salary at Leaving Date", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_settlement_as_at"},
				{"fieldname": "karyo_service_years", "fieldtype": "Float", "label": "Total Years of Service", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_basic_salary"},
				{"fieldname": "karyo_benefits_sb", "fieldtype": "Section Break", "label": "Benefits", "insert_after": "karyo_service_years"},
				{"fieldname": "karyo_settlement_benefits", "fieldtype": "HTML", "label": "Benefits and Outstanding Balances", "insert_after": "karyo_benefits_sb"},
				*[
					{"fieldname": "karyo_" + field, "fieldtype": "Float" if field.endswith("days") else "Currency",
					 "label": label, "hidden": 1, "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_settlement_benefits"}
					for field, label in [
						("sick_current_days", "Sick Leave - Current Year (Days)"), ("sick_bank_days", "Sick Leave - Bank Balance (Days)"),
						("annual_current_days", "Annual Leave - Current Year (Days)"), ("annual_bank_days", "Annual Leave - Bank Balance (Days)"),
						("sick_current_amount", "Sick Leave - Current Year Amount"), ("sick_bank_amount", "Sick Leave - Bank Amount"),
						("annual_current_amount", "Annual Leave - Current Year Amount"), ("annual_bank_amount", "Annual Leave - Bank Amount"),
					]
				],
				{"fieldname": "karyo_settlement_totals_sb", "fieldtype": "Section Break", "label": "Settlement Totals", "insert_after": "karyo_settlement_benefits"},
				{"fieldname": "karyo_sick_leave_days", "fieldtype": "Float", "label": "Remaining Sick Leave Balance (Days)", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_settlement_totals_sb"},
				{"fieldname": "karyo_vacation_leave_days", "fieldtype": "Float", "label": "Annual Leave Balance (Days)", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_sick_leave_days"},
				{"fieldname": "karyo_leave_settlement_amount", "fieldtype": "Currency", "label": "Leave Settlement Amount", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_vacation_leave_days"},
				{"fieldname": "karyo_final_settlement_cb", "fieldtype": "Column Break", "insert_after": "karyo_leave_settlement_amount"},
				{"fieldname": "karyo_pb_balance", "fieldtype": "Currency", "label": "Passage Benefit Balance", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_final_settlement_cb"},
				{"fieldname": "karyo_loan_outstanding", "fieldtype": "Currency", "label": "Outstanding Loan Balance", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_pb_balance"},
				{"fieldname": "karyo_gross_settlement", "fieldtype": "Currency", "label": "Total Accrued Benefits / Gross Settlement", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_loan_outstanding"},
				{"fieldname": "karyo_net_settlement", "fieldtype": "Currency", "label": "Net Settlement", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_gross_settlement"},
				{"fieldname": "karyo_settlement_explanation", "fieldtype": "Small Text", "label": "Calculation", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_net_settlement"},
				{"fieldname": "karyo_settlement_finalized_on", "fieldtype": "Datetime", "label": "Finalized On", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_settlement_explanation"},
				{"fieldname": "karyo_settlement_breakdown", "fieldtype": "Long Text", "label": "Settlement Source Snapshot", "read_only": 1, "allow_on_submit": 1, "hidden": 1, "insert_after": "karyo_settlement_finalized_on"},
			],
		},
		ignore_validate=True,
		update=True,
	)
	for doctype in ("Employee", "Salary Slip", "Employee Salary Appointment", "Employee Separation"):
		frappe.clear_cache(doctype=doctype)
	_backfill_separation_leaving_dates()
	_backfill_separation_settlements()


def _backfill_separation_leaving_dates():
	if not frappe.db.has_column("Employee Separation", "karyo_leaving_date"):
		return
	frappe.db.sql(
		"""update `tabEmployee Separation` s
		inner join `tabEmployee` e on e.name=s.employee
		set s.karyo_leaving_date=coalesce(e.relieving_date, s.boarding_begins_on)
		where s.karyo_leaving_date is null"""
	)


def _backfill_separation_settlements():
	from karyo.hr.final_settlement import refresh_separation_snapshot

	for name in frappe.get_all(
		"Employee Separation",
		filters={"docstatus": ("<", 2), "karyo_leaving_date": ("is", "set"), "karyo_settlement_as_at": ("is", "not set")},
		pluck="name", limit_page_length=0,
	):
		try:
			refresh_separation_snapshot(name)
		except Exception:
			frappe.log_error(frappe.get_traceback(), f"Final settlement backfill failed for {name}")


def setup():
	apply()
	frappe.db.commit()
	print("  + Walkthrough payroll, banking and settlement controls ensured")
