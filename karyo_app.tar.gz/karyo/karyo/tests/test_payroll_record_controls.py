"""Shared action policy uses native validation, permissions and linked-record protection."""
import unittest
from unittest.mock import Mock, patch
from uuid import uuid4
import frappe
from karyo.desk.payroll_drawer import _editability, record_form, record_save, record_action, record_tools
from frappe.desk.search import search_link


class TestPayrollRecordControls(unittest.TestCase):
    def setUp(self):
        self.user=frappe.session.user;frappe.set_user('Administrator');frappe.db.savepoint('record_controls')
        self.notify=patch('frappe.publish_realtime');self.notify.start()
        self.suffix='Controls-'+uuid4().hex[:10]
        self.component=record_save('salarysetup','Salary Component',{'salary_component':self.suffix,
            'salary_component_abbr':self.suffix,'type':'Earning','depends_on_payment_days':0,'is_tax_applicable':0})['name']

    def tearDown(self):
        self.notify.stop();frappe.set_user('Administrator');frappe.db.rollback(save_point='record_controls');frappe.set_user(self.user)

    def test_disabled_switch_updates_dropdown_and_unused_delete(self):
        tools=record_tools(frappe.get_doc('Salary Component',self.component))
        self.assertTrue(tools['enabled']);self.assertTrue(tools['show_toggle']);self.assertTrue(tools['can_toggle'])
        record_action('salarysetup','Salary Component',self.component,'disable')
        self.assertEqual(frappe.db.get_value('Salary Component',self.component,'disabled'),1)
        disabled_tools=record_tools(frappe.get_doc('Salary Component',self.component))
        self.assertTrue(disabled_tools['toggle_supported']);self.assertTrue(disabled_tools['can_toggle'])
        self.assertFalse(disabled_tools['show_toggle'])
        self.assertNotIn(self.component,[r['value'] for r in search_link('Salary Component',self.suffix,filters={'disabled':0})])
        record_action('salarysetup','Salary Component',self.component,'enable')
        self.assertEqual(frappe.db.get_value('Salary Component',self.component,'disabled'),0)
        self.assertIn(self.component,[r['value'] for r in search_link('Salary Component',self.suffix,filters={'disabled':0})])
        self.assertTrue(record_form('salarysetup','Salary Component',self.component)['record_tools']['can_delete'])
        record_action('salarysetup','Salary Component',self.component,'delete')
        self.assertFalse(frappe.db.exists('Salary Component',self.component))

    def test_submitted_structure_has_governed_edit_and_delete_controls(self):
        company=frappe.db.get_value('Company',{},'name')
        structure=record_save('salarysetup','Salary Structure',{'record_name':self.suffix,'company':company,
            'currency':frappe.db.get_value('Company',company,'default_currency'),'is_active':'Yes','payroll_frequency':'Monthly',
            'earnings':[{'salary_component':self.component,'amount':1000,'depends_on_payment_days':0}]})['name']
        record_action('salarysetup','Salary Structure',structure,'submit')
        info=record_form('salarysetup','Salary Structure',structure)['record_tools']
        self.assertTrue(info['can_toggle']);self.assertTrue(info['can_edit']);self.assertTrue(info['amend_before_edit'])
        self.assertTrue(info['can_delete']);self.assertTrue(info['cancel_before_delete'])
        replacement=record_action('salarysetup','Salary Structure',structure,'amend')['name']
        replacement_doc=frappe.get_doc('Salary Structure',replacement)
        self.assertEqual(replacement_doc.docstatus,0);self.assertEqual(replacement_doc.is_active,'No')
        self.assertEqual(replacement_doc.earnings[0].salary_component,self.component)
        source=frappe.get_doc('Salary Structure',structure)
        self.assertEqual(source.docstatus,1);self.assertEqual(source.is_active,'Yes')
        record_action('salarysetup','Salary Structure',replacement,'delete')
        record_action('salarysetup','Salary Structure',structure,'delete')
        self.assertFalse(frappe.db.exists('Salary Structure',structure))

    def test_no_synthetic_switch_or_permission_bypass(self):
        assignment=frappe.db.get_value('Salary Structure Assignment',{},'name')
        info=record_tools(frappe.get_doc('Salary Structure Assignment',assignment))
        self.assertFalse(info['show_toggle']);self.assertFalse(info['can_toggle']);self.assertIsNone(info['enabled'])
        with self.assertRaises(frappe.ValidationError):record_action('salarysetup','Salary Structure Assignment',assignment,'disable')
        frappe.set_user('Guest')
        for action in ('enable','disable','delete'):
            with self.assertRaises(frappe.PermissionError):record_action('salarysetup','Salary Component',self.component,action)

    def test_submitted_assignment_actions_open_setup_and_cancel_before_delete(self):
        assignment=frappe.db.get_value('Salary Structure Assignment',{'docstatus':1},'name')
        self.assertTrue(assignment)
        doc=frappe.get_doc('Salary Structure Assignment',assignment)
        info=record_tools(doc)
        self.assertTrue(info['can_edit'])
        self.assertEqual(info['edit_employee'],doc.employee)
        self.assertTrue(info['can_delete'])
        self.assertTrue(info['cancel_before_delete'])

    def test_process_managed_availability_is_not_rendered_as_an_action(self):
        grade=frappe.db.get_value('PRB Grade Scale',{},'name')
        self.assertTrue(grade)
        info=record_tools(frappe.get_doc('PRB Grade Scale',grade))
        self.assertFalse(info['show_toggle']);self.assertFalse(info['can_toggle'])
        with self.assertRaises(frappe.ValidationError):
            record_action('master-prb-grade-scale','PRB Grade Scale',grade,'enable')

    def test_system_manager_can_delete_an_inactive_record(self):
        record_action('salarysetup','Salary Component',self.component,'disable')
        frappe.set_user('mbc.admin@mbc.mu')
        tools=record_tools(frappe.get_doc('Salary Component',self.component))
        self.assertFalse(tools['enabled']);self.assertTrue(tools['can_delete'])
        record_action('salarysetup','Salary Component',self.component,'delete')
        self.assertFalse(frappe.db.exists('Salary Component',self.component))

    def test_automatic_era_run_is_review_only(self):
        doc=Mock(doctype='PRB Payroll Run',docstatus=0)
        doc.get.side_effect=lambda field: {
            'run_purpose':'ERA Hours Payment','custom_entry_source':'Automatic'}.get(field)
        editable, reason=_editability({},doc)
        self.assertFalse(editable)
        self.assertIn('cannot be edited',reason)
