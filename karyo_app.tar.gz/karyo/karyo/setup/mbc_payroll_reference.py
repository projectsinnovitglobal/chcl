"""Client-supplied MBC payroll reference data.

Sources under ``docs/payroll/Reference Documnet/``:

* ``Employer_Employee_Contribution_Registration.xlsx`` — contribution rate
  register (sheets "Contribution Rates", "System Mapping") and the legacy PDB
  reference codes.
* ``Salary scale_SalaryPointCalculation_Grade linkage_EmployeeBasicSalary.docx``
  — the FAR17 worked example, its salary/increment bands and the 38 points it
  must generate.
* ``MRAPAYEGuide.pdf`` — Fair Share Contribution on high income earners
  (15% of leviable income above Rs 12,000,000, collected through PAYE from
  1 July 2025).

Everything here is idempotent: re-running updates the received records in place
rather than creating a second copy.
"""

import frappe
from frappe.utils import flt

PDB_CONFIG_KEY = "MBC-PDB-2025-26"
CONTRIBUTION_CONFIG_KEY = "MBC-CONTRIBUTIONS-2025-26"
VERSION = "RECEIVED-1"
EFFECTIVE_FROM = "2025-07-01"
CONTRIBUTION_SOURCE = "Employer_Employee_Contribution_Registration.xlsx"
SCALE_SOURCE = "Salary scale_SalaryPointCalculation_Grade linkage_EmployeeBasicSalary.docx"

# Salary basis for every contribution. The register supplies rates and bands but
# not the earnings set each contribution is computed on, so the schemes are
# created against the existing gross-salary operation code and flagged for the
# payroll owner to confirm before the configuration is approved.
BASIS_OPERATION_CODE = "GSAL"
BASIS_NOTE = (
	"Rates and bands are exactly as supplied in the contribution register. "
	"The salary basis operation code still needs payroll-owner confirmation: "
	"the register does not state which earnings each contribution is computed on."
)

# (scheme code, description, employee abbr, employer abbr, bands, allow_band_gaps)
# Bands are (lower, upper, employee %, employer %) taken from the "Contribution
# Rates" sheet, whose rates are stored there as fractions.
REGISTER = [
	(
		"CSG",
		"Contribution Sociale Generalisee",
		"CSG",
		"ERCSG",
		# Preserve the received register boundary exactly. The source starts the
		# upper band at Rs 50,001; values between Rs 50,000 and Rs 50,001 must not
		# silently receive an invented rate.
		[(0, 50000, 0, 4.5), (50001, 99999999, 0, 9)],
		True,
	),
	("PCDC", "Pension Contribution DC", "PCDC", "ERPCDC", [(0, 9999999, 6, 12)], False),
	("FPS", "Family Protection Scheme", "FPS", "ERFPS", [(0, 9999999, 2, 2)], False),
	("CSFPS", "CS Family Protection Scheme", "CSFPS", "ERCSFPS", [(0, 9999999, 2, 2)], False),
	("PENSION", "Pension Contribution", "PENS", "ERPENS", [(0, 9999999, 6, 19)], False),
	("LEVY", "Levy Charges", "LEVY", "ERLEVY", [(0, 999999999, 0, 1.5)], False),
	("NSFP", "NSF - Permanent", "NSFP", "ERNSFP", [(0, 999999, 0, 2.5)], False),
	# The register starts NSF - Contractual at Rs 100; below that no
	# contribution is due, so the gap under the first band is intentional.
	("NSFC", "NSF - Contractual", "NSFC", "ERNSFC", [(100, 999999, 1, 2.5)], True),
	("SIC2", "Family Protection Scheme (SIC2)", "SIC2", "ERSIC2", [(0, 99999999, 2, 2)], False),
	("NPF", "National Pensions Fund", "NPF", "ERNPF", [(0, 999999999, 0, 2.5)], False),
]

# "REFERENCE CODES" block of the System Mapping sheet: client PDB codes that
# carry no rate in the register. Created so the PDB catalogue matches the
# client's own code list; no contribution scheme is generated for them.
REFERENCE_CODES = [
	("CONT21", "Pension 6%", "CONT21"),
	("CONT3", "National Savings Fund", "CONT3"),
	("CONT22", "GGSU", "CONT22"),
	("CONT23", "GGSU BF", "CONT23"),
]

FAIR_SHARE_THRESHOLD = 12000000
FAIR_SHARE_RATE = 15

FAR17_BANDS = [
	(16785, 260),
	(17825, 275),
	(18925, 300),
	(19525, 325),
	(21475, 375),
	(22225, 400),
	(23425, 525),
	(26050, 675),
	(27400, 825),
	(34825, 0),
]


def _configuration(config_key, configuration_type, source, notes):
	name = frappe.db.get_value(
		"Payroll Configuration Version", {"config_key": config_key, "version": VERSION}, "name"
	)
	if name:
		return name
	doc = frappe.get_doc(
		{
			"doctype": "Payroll Configuration Version",
			"config_key": config_key,
			"configuration_type": configuration_type,
			"version": VERSION,
			"configuration_status": "Draft",
			"is_production_eligible": 0,
			"effective_from": EFFECTIVE_FROM,
			"source_reference": source,
			"notes": notes,
		}
	).insert(ignore_permissions=True)
	frappe.db.set_value("Payroll Configuration Version", doc.name, "company", None)
	return doc.name


def _pdb_type(configuration):
	if frappe.db.exists("Payroll PDB Type", "CONT"):
		return "CONT"
	return frappe.get_doc(
		{
			"doctype": "Payroll PDB Type",
			"pdb_type": "CONT",
			"description": "Employer and employee contributions",
			"classification": "Deduction",
			"is_active": 1,
			"effective_from": EFFECTIVE_FROM,
			"configuration_version": configuration,
		}
	).insert(ignore_permissions=True).name


def _component(name, abbr, *, employer):
	"""Employee contributions reduce net pay; employer contributions do not."""
	if frappe.db.exists("Salary Component", name):
		frappe.db.set_value("Salary Component", name, "disabled", 0)
		return name
	return frappe.get_doc(
		{
			"doctype": "Salary Component",
			"salary_component": name,
			"salary_component_abbr": abbr,
			"type": "Deduction",
			"depends_on_payment_days": 0,
			"is_tax_applicable": 0,
			"do_not_include_in_total": 1 if employer else 0,
			"remove_if_zero_valued": 1,
			"disabled": 0,
		}
	).insert(ignore_permissions=True).name


def _pdb_code(code, description, component, configuration, sequence, overwrite=False):
	values = {
		"pdb_type": "CONT",
		"description": description,
		"salary_component": component,
		"transaction_mode": "Static",
		"display_sequence": sequence,
		"taxable": 0,
		"exempt": 0,
		"prorata": 0,
		"reducing_balance": 0,
		"is_active": 1,
		"effective_from": EFFECTIVE_FROM,
		"configuration_version": configuration,
		"source_reference": CONTRIBUTION_SOURCE,
	}
	if frappe.db.exists("Payroll PDB Code", code):
		doc = frappe.get_doc("Payroll PDB Code", code)
		if not overwrite:
			return doc.name
		doc.update(values)
		doc.save(ignore_permissions=True)
		return doc.name
	return frappe.get_doc({"doctype": "Payroll PDB Code", "pdb_code": code, **values}).insert(
		ignore_permissions=True
	).name


def load_contribution_register(overwrite=False):
	"""Create the client's contribution register: PDB codes and rate schemes.

	``overwrite`` re-applies the register over records that already exist. It is
	off by default so a migration never silently reverts an edit a payroll owner
	has made to a received scheme.
	"""
	pdb_configuration = _configuration(
		PDB_CONFIG_KEY,
		"PDB Catalogue",
		CONTRIBUTION_SOURCE,
		"Client PDB codes received with the contribution register. "
		"Approve before switching the environment to Production.",
	)
	contribution_configuration = _configuration(
		CONTRIBUTION_CONFIG_KEY, "Contribution", CONTRIBUTION_SOURCE, BASIS_NOTE
	)
	_pdb_type(pdb_configuration)

	created, updated = [], []
	for sequence, (code, description, ee_abbr, er_abbr, bands, allow_gaps) in enumerate(REGISTER, 1):
		employee_component = _component(f"{description} (Employee)", ee_abbr, employer=False)
		employer_component = _component(f"{description} (Employer)", er_abbr, employer=True)
		_pdb_code(code, description, employee_component, pdb_configuration, sequence, overwrite)
		scheme_name = f"{code}-{VERSION}"
		values = {
			"scheme_code": code,
			"version": VERSION,
			"description": description,
			"calculation_mode": "Percentage",
			"basis_operation_code": BASIS_OPERATION_CODE,
			"employee_pdb_code": code,
			"employer_salary_component": employer_component,
			"employee_ceiling": 0,
			"employer_ceiling": 0,
			"rounding_precision": 2,
			"rounding_method": "Round Half Up",
			"is_active": 1,
			"allow_band_gaps": 1 if allow_gaps else 0,
			"effective_from": EFFECTIVE_FROM,
			"configuration_version": contribution_configuration,
			"source_reference": CONTRIBUTION_SOURCE,
			"notes": BASIS_NOTE,
			"bands": [
				{
					"lower_salary": lower,
					"upper_salary": upper,
					"is_open_ended": 0,
					"employee_value": employee_rate,
					"employer_value": employer_rate,
				}
				for lower, upper, employee_rate, employer_rate in bands
			],
		}
		if frappe.db.exists("Payroll Contribution Scheme", scheme_name):
			if not overwrite:
				continue
			doc = frappe.get_doc("Payroll Contribution Scheme", scheme_name)
			doc.set("bands", [])
			doc.update(values)
			doc.save(ignore_permissions=True)
			updated.append(doc.name)
		else:
			created.append(
				frappe.get_doc({"doctype": "Payroll Contribution Scheme", **values})
				.insert(ignore_permissions=True)
				.name
			)

	for sequence, (code, description, abbr) in enumerate(REFERENCE_CODES, len(REGISTER) + 1):
		component = _component(description, abbr, employer=False)
		_pdb_code(code, description, component, pdb_configuration, sequence, overwrite)

	return {"created": created, "updated": updated}


def load_fair_share_contribution():
	"""Apply the Finance Act 2025 Fair Share Contribution to the PAYE year."""
	applied = []
	for name in frappe.get_all(
		"Payroll PAYE Year", filters={"is_active": 1}, pluck="name"
	):
		doc = frappe.get_doc("Payroll PAYE Year", name)
		if flt(doc.fair_share_rate) == FAIR_SHARE_RATE and flt(doc.fair_share_threshold) == FAIR_SHARE_THRESHOLD:
			continue
		doc.fair_share_threshold = FAIR_SHARE_THRESHOLD
		doc.fair_share_rate = FAIR_SHARE_RATE
		doc.save(ignore_permissions=True)
		applied.append(name)
	return applied


def load_salary_scales():
	"""Load the FAR17 scale from the client salary-scale guide."""
	if frappe.db.exists("Salary Scale", {"scale_code": "FAR17"}):
		return None
	band_rows = []
	for sequence, (salary, increment) in enumerate(FAR17_BANDS, 1):
		code = f"FAR17-BAND-{sequence:02d}"
		if not frappe.db.exists("Salary Increment Band", code):
			frappe.get_doc(
				{
					"doctype": "Salary Increment Band",
					"band_code": code,
					"description": f"FAR17 breakpoint {sequence}",
					"salary_breakpoint": salary,
					"increment_amount": increment,
					"currency": "MUR",
					"effective_from": "2026-01-01",
				}
			).insert(ignore_permissions=True)
		band_rows.append({"increment_band": code, "salary": salary, "increment": increment})
	doc = frappe.get_doc(
		{
			"doctype": "Salary Scale",
			"scale_code": "FAR17",
			"description": "Approved FAR17 scale (Rs 16,785 - Rs 34,825)",
			"scale_type": "Step Salary",
			"prb_year": 2026,
			"currency": "MUR",
			"lowest_salary": FAR17_BANDS[0][0],
			"upper_salary": FAR17_BANDS[-1][0],
			"valid_from": "2026-01-01",
			"bands": band_rows,
			"source_reference": SCALE_SOURCE,
		}
	).insert(ignore_permissions=True)
	return doc.name


def apply():
	"""Idempotent hook: load anything the client register is still missing."""
	load_contribution_register()
	load_fair_share_contribution()
	load_salary_scales()
	repair_prb_component_mappings()
	rename_demo_banks()
	retire_demo_labels()
	frappe.db.commit()


def setup(overwrite=False):
	print("Karyo MBC payroll reference data:")
	register = load_contribution_register(overwrite)
	fair_share = load_fair_share_contribution()
	scale = load_salary_scales()
	frappe.db.commit()
	print(
		f"  contribution schemes created={len(register['created'])} updated={len(register['updated'])}"
	)
	print(f"  fair share applied to={fair_share}")
	print(f"  salary scale={scale}")
	print("Done.")


DEMO_SUFFIXES = (" (Demo — illustrative only)", " (Demo)")
DESCRIPTION_DOCTYPES = (
	("Payroll PDB Code", "description"),
	("Payroll PDB Type", "description"),
	("Payroll Operation Code", "description"),
	("Payroll Operation Code Item", "description"),
	("Payroll Compensation Scheme", "description"),
	("Payroll Contribution Scheme", "description"),
	("Payroll Configuration Version", "notes"),
	("PRB Payroll Component Mapping", "description"),
)


def _strip_demo(text):
	for suffix in DEMO_SUFFIXES:
		if text and text.endswith(suffix):
			return text[: -len(suffix)]
	return text


def retire_demo_labels():
	"""Remove development "(Demo)" labelling from client-facing payroll records.

	Salary Components are renamed only when no salary slip or salary structure
	row refers to them, so payroll history is never rewritten. The illustrative
	CSG scheme is deactivated once the client's own register is loaded, because
	its rates were never statutory values.
	"""
	renamed = []
	for name in frappe.get_all(
		"Salary Component", filters={"salary_component": ("like", "%(Demo)%")}, pluck="name"
	):
		target = _strip_demo(name)
		if target == name or frappe.db.exists("Salary Component", target):
			continue
		if frappe.db.count("Salary Detail", {"salary_component": name}):
			continue
		frappe.rename_doc("Salary Component", name, target, force=True)
		frappe.db.set_value("Salary Component", target, "salary_component", target)
		renamed.append((name, target))

	relabelled = 0
	for doctype, fieldname in DESCRIPTION_DOCTYPES:
		for row in frappe.get_all(
			doctype, filters={fieldname: ("like", "%(Demo%")}, fields=["name", fieldname]
		):
			cleaned = _strip_demo(row.get(fieldname))
			if cleaned != row.get(fieldname):
				frappe.db.set_value(doctype, row["name"], fieldname, cleaned, update_modified=False)
				relabelled += 1

	deactivated = []
	if frappe.db.exists("Payroll Contribution Scheme", {"scheme_code": "CSG", "version": VERSION}):
		for name in frappe.get_all(
			"Payroll Contribution Scheme",
			filters={"scheme_code": ("like", "%-DEMO"), "is_active": 1},
			pluck="name",
		):
			frappe.db.set_value("Payroll Contribution Scheme", name, "is_active", 0)
			deactivated.append(name)

	frappe.db.commit()
	return {"renamed": renamed, "relabelled": relabelled, "deactivated": deactivated}


def repair_prb_component_mappings():
	"""Create PDB codes for PRB allowances whose mapping has lost its target.

	Every PRB Payroll Component Mapping must resolve to a PDB code, otherwise
	posting an overtime, night-duty, acting or mileage input to a salary slip
	fails. The salary components already exist, so the repair only restores the
	missing catalogue entries.
	"""
	from karyo.setup.prb_posting import DEMO_COMPONENTS

	configuration = _configuration(
		PDB_CONFIG_KEY,
		"PDB Catalogue",
		CONTRIBUTION_SOURCE,
		"Client PDB codes received with the contribution register. "
		"Approve before switching the environment to Production.",
	)
	# A PDB code may not start before the PDB type it uses.
	type_from = frappe.db.get_value("Payroll PDB Type", "PAY", "effective_from")
	effective_from = max(str(type_from), EFFECTIVE_FROM) if type_from else EFFECTIVE_FROM
	created = []
	for sequence, (code, description, existing_pdb, _mode) in enumerate(DEMO_COMPONENTS, 1):
		pdb_code = existing_pdb or f"PRB-{code.replace('_', '-')}"
		if frappe.db.exists("Payroll PDB Code", pdb_code):
			# The PDB may already exist while its component mapping was missed by
			# an older setup run. Repair that half-configured state below.
			if not frappe.db.exists("PRB Payroll Component Mapping", code):
				frappe.get_doc({"doctype": "PRB Payroll Component Mapping", "component_code": code,
					"description": description, "pdb_code": pdb_code, "posting_mode": _mode,
					"is_active": 1}).insert(ignore_permissions=True)
			continue
		component = f"PRB {description}"
		if not frappe.db.exists("Salary Component", component):
			# These are governed payroll rules, not sample data. They must be
			# available in production for the applicable payroll process.
			if code not in {"ATTENDANCE_BONUS", "INCENTIVE_PRESENCE", "EXCESS_HOURS"}:
				continue
			abbr = {
				"ATTENDANCE_BONUS": "ATB",
				"INCENTIVE_PRESENCE": "IPB",
				"EXCESS_HOURS": "EXH",
			}[code]
			frappe.get_doc({"doctype": "Salary Component", "salary_component": component,
				"salary_component_abbr": abbr, "type": "Earning", "is_tax_applicable": 1,
				"depends_on_payment_days": 0}).insert(ignore_permissions=True)
		frappe.get_doc(
			{
				"doctype": "Payroll PDB Code",
				"pdb_code": pdb_code,
				"pdb_type": "PAY",
				"description": f"PRB {description}",
				"short_description": description[:140],
				"salary_component": component,
				"transaction_mode": "Once Off",
				"display_sequence": 100 + sequence,
				"taxable": 1,
				"exempt": 0,
				"prorata": 0,
				"is_active": 1,
				"effective_from": effective_from,
				"configuration_version": configuration,
				"source_reference": "PRB 2026 allowance catalogue",
			}
		).insert(ignore_permissions=True)
		if not frappe.db.exists("PRB Payroll Component Mapping", code):
			frappe.get_doc({"doctype": "PRB Payroll Component Mapping", "component_code": code,
				"description": description, "pdb_code": pdb_code, "posting_mode": _mode,
				"is_active": 1}).insert(ignore_permissions=True)
		created.append(pdb_code)
	frappe.db.commit()
	return created


def rename_demo_banks():
	"""Drop the development suffix from the bank master used by payroll exports."""
	renamed = []
	for name in frappe.get_all("Bank", filters={"name": ("like", "%(Demo)%")}, pluck="name"):
		target = _strip_demo(name)
		if target == name or frappe.db.exists("Bank", target):
			continue
		frappe.rename_doc("Bank", name, target, force=True)
		frappe.db.set_value("Bank", target, "bank_name", target)
		renamed.append((name, target))

	# Branch names are built from the bank name, so they keep the old label until
	# they are renamed in turn.
	for row in frappe.get_all(
		"Payroll Bank Branch", fields=["name", "bank", "branch_code", "branch_name"]
	):
		target = f"{row.bank}-{row.branch_code}"
		if target != row.name and not frappe.db.exists("Payroll Bank Branch", target):
			frappe.rename_doc("Payroll Bank Branch", row.name, target, force=True)
			renamed.append((row.name, target))
		cleaned = _strip_demo(row.branch_name)
		if cleaned != row.branch_name:
			frappe.db.set_value("Payroll Bank Branch", target, "branch_name", cleaned)
	frappe.db.commit()
	return renamed
