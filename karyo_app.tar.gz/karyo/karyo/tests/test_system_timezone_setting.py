"""Default time-zone configuration exposed through Admin Settings."""

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.setup.system_settings import apply


class TestSystemTimezoneSetting(FrappeTestCase):
	def test_default_time_zone_is_editable_and_required(self):
		apply()
		field = frappe.get_meta("System Settings", cached=False).get_field("time_zone")
		self.assertEqual(field.label, "Default Time Zone")
		self.assertFalse(field.read_only)
		self.assertTrue(field.reqd)
