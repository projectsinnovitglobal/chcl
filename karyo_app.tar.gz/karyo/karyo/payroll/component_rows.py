"""Component selection and unsaved calculations for PRB Payroll Run."""
import frappe
from frappe import _
from frappe.utils import flt, nowdate

CATEGORIES = {
 'Acting':['ACTING','RESPONSIBILITY'],
 'Overtime':['OVERTIME','NIGHT_DUTY','EXCESS_HOURS','WEATHER'],
 'Allowance':['ATTENDANCE_BONUS','INCENTIVE_ATTENDANCE','INCENTIVE_PRESENCE','ERA_HOURS','CAR_MILEAGE','MOTORCYCLE_MILEAGE','AUTOCYCLE_MILEAGE','MEAL','SUBSISTENCE','OUT_OF_POCKET','INDUCEMENT','DISTURBANCE'],
 'Leave':['VACATION_DEATH','SLB_EXIT'], 'PMS':['PMS_AWARD'],
}


def _catalog():
 choices={}
 for row in frappe.get_all('PRB Payroll Component Mapping',filters={'is_active':1},fields=['component_code','description','pdb_code']):
  pdb=frappe.db.get_value('Payroll PDB Code',row.pdb_code,['salary_component','is_active'],as_dict=True)
  category=next((cat for cat,codes in CATEGORIES.items() if row.component_code in codes),None)
  component=frappe.db.get_value('Salary Component',pdb.salary_component,['disabled','type'],as_dict=True) if pdb else None
  mapped=bool(pdb and pdb.is_active and component and not component.disabled and component.type=='Earning')
  # PRB calculations are defined independently of their downstream posting mapping.
  if not mapped and not category and row.component_code!='BASIC':continue
  choices[row.component_code]={'code':row.component_code,'description':row.description,'salary_component':pdb.salary_component if mapped else None,'pdb_code':row.pdb_code if mapped else None,'category':category}
 mapped={row['salary_component'] for row in choices.values()}
 for row in frappe.get_all('Salary Component',filters={'disabled':0,'type':'Earning'},fields=['name','salary_component_abbr','description']):
  if row.name in mapped:continue
  code='BASIC' if row.name.lower()=='basic' else row.salary_component_abbr
  if code and code not in choices:choices[code]={'code':code,'description':row.name,'salary_component':row.name,'category':None}
 return choices


@frappe.whitelist()
def choices():
 frappe.has_permission('PRB Payroll Run','read',throw=True)
 return sorted(_catalog().values(),key=lambda row:row['code'])


def calculate_component(run, row):
 item=_catalog().get(row.component_code)
 if not item:frappe.throw(_('Select an active earning component: {0}.').format(row.component_code))
 result=dict(component_code=item['code'],description=item['description'],salary_component=item['salary_component'],pdb_code=item.get('pdb_code'),source='Calculated')
 if item['code']=='BASIC':
  if run.exception_code:frappe.throw(run.exception_detail)
  result.update(amount=run.basic_salary,rule_ref=run._basic_rule_ref)
 elif item['category']:
  inputs=[r for r in run.employee_inputs if r.input_code==item['code']]
  if not inputs:frappe.throw(_('Add an Employee Input for {0} and enter its calculation values.').format(item['code']))
  calculations=[run._calculate_input(r) for r in inputs]
  result.update(amount=sum(v[0] for v in calculations),rule_ref=', '.join(dict.fromkeys(v[1] for v in calculations)))
 else:
  component=frappe.get_cached_doc('Salary Component',item['salary_component'])
  assignment=frappe.db.get_value('Salary Structure Assignment',{'employee':run.employee,'docstatus':1,'from_date':['<=',run.calculation_date or nowdate()]},['salary_structure','base','variable'],order_by='from_date desc',as_dict=True)
  if assignment and frappe.db.exists('Salary Detail',{'parent':assignment.salary_structure,'parenttype':'Salary Structure','salary_component':component.name,'parentfield':'earnings'}):
   # Native HRMS computes the employee's configured formulas and payment days.
   from hrms.payroll.doctype.salary_structure.salary_structure import make_salary_slip
   cache=getattr(run,'_component_slip_cache',{})
   if assignment.salary_structure not in cache:
    cache[assignment.salary_structure]=make_salary_slip(assignment.salary_structure,employee=run.employee,posting_date=run.calculation_date or nowdate())
    run._component_slip_cache=cache
   slip=cache[assignment.salary_structure]
   result.update(amount=sum(flt(r.amount) for r in slip.earnings if r.salary_component==component.name),rule_ref='Salary Structure: '+assignment.salary_structure)
  else:
   from hrms.payroll.doctype.salary_slip.salary_slip import SalarySlip
   employee=frappe.get_doc('Employee',run.employee)
   data=employee.as_dict();data.update({'basic_salary':run.basic_salary,'BASIC':run.basic_salary})
   if assignment:data.update(base=run.basic_salary or assignment.base,variable=assignment.variable)
   detail=frappe.get_doc({'doctype':'Salary Detail','salary_component':component.name,'abbr':component.salary_component_abbr,'amount':component.amount,'condition':component.condition,'formula':component.formula,'amount_based_on_formula':component.amount_based_on_formula})
   amount=SalarySlip({'doctype':'Salary Slip'}).eval_condition_and_formula(detail,data)
   result.update(amount=flt(amount),rule_ref='Salary Component: '+component.name)
 return result


@frappe.whitelist()
def preview(doc):
 data=frappe.parse_json(doc)
 if data.get('doctype')!='PRB Payroll Run':frappe.throw(_('Invalid payroll document.'))
 run=frappe.get_doc(data)
 if run.docstatus:frappe.throw(_('Only draft payroll runs can be recalculated.'))
 if run.is_new():frappe.has_permission(run.doctype,'create',throw=True)
 else:frappe.get_doc(run.doctype,run.name).check_permission('write')
 frappe.get_doc('Employee',run.employee).check_permission('read')
 run._action="save"
 run._validate_links()
 run._set_context();run._validate_attendance_bonus_scope();run._compute_basic()
 run._rebuild_components()
 return {'karyo_salary_appointment':run.karyo_salary_appointment,'components':[r.as_dict() for r in run.components], 'basic_salary':run.basic_salary,'gross_pay':sum(flt(r.amount) for r in run.components),'exception_code':run.exception_code,'exception_detail':run.exception_detail,'company':run.company}


def setup():
 from frappe.custom.doctype.property_setter.property_setter import make_property_setter
 make_property_setter('PRB Payroll Component','source','options','Manual\nAuto\nCalculated','Text')
 make_property_setter('PRB Payroll Component','source','read_only',1,'Check')
 make_property_setter('PRB Payroll Component','component_code','fieldtype','Autocomplete','Data')
 make_property_setter('PRB Payroll Component','rule_ref','read_only',1,'Check')
 make_property_setter('PRB Payroll Input','input_code','fieldtype','Autocomplete','Data')
 for field in ['quantity','rate','amount']:
  make_property_setter('PRB Payroll Input',field,'in_list_view',1,'Check')

 make_property_setter('PRB Payroll Component','amount','read_only_depends_on','eval:doc.source != \"Manual\"','Data')
 for field,columns in [('category',1),('input_code',2),('description',2),('quantity',1),('rate',2),('amount',2)]:
  make_property_setter('PRB Payroll Input',field,'columns',columns,'Int')
