from karyo.payroll.salary_scales import sync_all_employee_hourly_rates
from karyo.setup.employee_master import ensure_hourly_rate_fields


def execute():
	ensure_hourly_rate_fields()
	sync_all_employee_hourly_rates()
