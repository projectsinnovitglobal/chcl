frappe.pages["expenses-overview"].on_page_load = function (wrapper) {
	karyo.overview.render(wrapper, "expenses-overview", {
		title: __("Expenses & Travel"),
		subtitle: __("Claims, advances, travel and fleet"),
		actions: [
			{ label: __("New Expense Claim"), primary: true, onclick: () => frappe.new_doc("Expense Claim") },
			{ label: __("New Travel Request"), onclick: () => frappe.new_doc("Travel Request") },
		],
	});
};
