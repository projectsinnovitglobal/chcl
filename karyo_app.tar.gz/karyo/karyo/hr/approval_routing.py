"""Resolve employee approval routes from Department or reporting manager defaults."""

import frappe
from frappe import _


ROUTES = {
	"shift_request_approver": ("shift_request_approver", "karyo_shift_approver_source"),
	"leave_approver": ("leave_approvers", "karyo_leave_approver_source"),
	"expense_approver": ("expense_approvers", "karyo_expense_approver_source"),
}
INHERITED_SOURCES = {"Department", "Reporting Manager"}


def _department_approver(department, parentfield):
	if not department:
		return None
	return frappe.db.get_value(
		"Department Approver",
		{"parent": department, "parenttype": "Department", "parentfield": parentfield, "idx": 1},
		"approver",
	)


def _reporting_approver(reports_to):
	if not reports_to:
		return None
	user = frappe.db.get_value(
		"Employee", {"name": reports_to, "status": "Active"}, "user_id"
	)
	if not user or not frappe.db.get_value("User", user, "enabled"):
		return None
	return user


def resolve_approvers(department=None, reports_to=None):
	"""Return the effective default and its source for every approval route."""
	reporting = _reporting_approver(reports_to)
	resolved = {}
	for employee_field, (department_field, _source_field) in ROUTES.items():
		approver = _department_approver(department, department_field)
		resolved[employee_field] = {
			"approver": approver or reporting,
			"source": "Department" if approver else "Reporting Manager" if reporting else "",
		}
	return resolved


@frappe.whitelist()
def employee_defaults(department=None, reports_to=None, employee=None):
	"""Approval defaults used while editing an Employee form."""
	if employee:
		frappe.get_doc("Employee", employee).check_permission("write")
	elif not frappe.has_permission("Employee", "create"):
		frappe.throw(_("Not permitted to configure employee approvers."), frappe.PermissionError)
	return resolve_approvers(department, reports_to)


def prepare_employee_approvers(doc, method=None):
	"""Refresh inherited values while preserving explicit employee overrides."""
	resolved = resolve_approvers(doc.get("department"), doc.get("reports_to"))
	previous = doc.get_doc_before_save() if not doc.is_new() else None

	for employee_field, (_department_field, source_field) in ROUTES.items():
		current = doc.get(employee_field)
		source = doc.get(source_field) or ""
		candidate = resolved[employee_field]
		old_value = previous.get(employee_field) if previous else None
		old_source = (previous.get(source_field) or "") if previous else ""

		if source == "Individual":
			if current:
				continue
		elif source in INHERITED_SOURCES:
			# A changed value with an unchanged inherited marker is a direct API or
			# import override. The browser marks this explicitly before save.
			if previous and source == old_source and current != old_value and current != candidate["approver"]:
				doc.set(source_field, "Individual")
				continue
		elif current:
			# Classify legacy records without a source marker once. Matching values
			# remain synchronized; different values are employee overrides.
			if current == candidate["approver"] and candidate["source"]:
				doc.set(source_field, candidate["source"])
			else:
				doc.set(source_field, "Individual")
			continue

		doc.set(employee_field, candidate["approver"])
		doc.set(source_field, candidate["source"])


def sync_department_employees(doc, method=None):
	"""Push changed Department defaults only to employees that inherit them."""
	previous = doc.get_doc_before_save()
	if previous:
		old = [next((row.approver for row in previous.get(field) or []), None) for field, _source in ROUTES.values()]
		new = [next((row.approver for row in doc.get(field) or []), None) for field, _source in ROUTES.values()]
		if old == new:
			return

	filters = {"department": doc.name}
	for employee in frappe.get_all("Employee", filters=filters, pluck="name"):
		values = frappe.db.get_value(
			"Employee", employee,
			[source for _table, source in ROUTES.values()],
			as_dict=True,
		) or {}
		if not any(values.get(source) != "Individual" for _table, source in ROUTES.values()):
			continue
		employee_doc = frappe.get_doc("Employee", employee)
		employee_doc.flags.ignore_permissions = True
		employee_doc.save(ignore_permissions=True)
