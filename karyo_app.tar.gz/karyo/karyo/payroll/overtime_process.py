"""Attendance-facing register and payroll approval gate for additional hours."""

import json

import frappe
from frappe import _
from frappe.utils import flt, get_first_day, get_last_day, getdate, now_datetime, today

from karyo.payroll.governance import has_actor_role


TIME_CODES = {
	"Overtime": "OVERTIME",
	"Night Duty": "NIGHT_DUTY",
	"Excess Hours": "EXCESS_HOURS",
}


def _period(from_date=None, to_date=None):
	start = getdate(from_date or get_first_day(today()))
	end = getdate(to_date or get_last_day(start))
	if end < start:
		frappe.throw(_("To Date cannot be before From Date."))
	if (end - start).days > 92:
		frappe.throw(_("Select a period of 93 days or less."))
	return start, end


def _approval_field_available():
	return frappe.get_meta("PRB Overtime Authorization").has_field("payroll_approval_status")


def _base_rows(from_date=None, to_date=None, company=None, employee=None, approval_status=None):
	start, end = _period(from_date, to_date)
	filters = {
		"docstatus": 1,
		"actual_start": ("between", [f"{start} 00:00:00", f"{end} 23:59:59"]),
	}
	if company:
		filters["company"] = company
	if employee:
		filters["employee"] = employee
	if approval_status and _approval_field_available():
		filters["payroll_approval_status"] = approval_status
	fields = [
		"name", "employee", "employee_name", "company", "claim_type", "actual_start", "actual_end",
		"actual_hours", "approved_hours", "overtime_period", "eligibility_reason", "authorization_status",
		"hourly_rate", "calculation_explanation", "modified",
	]
	if _approval_field_available():
		fields.extend([
			"payroll_approval_status", "payroll_decision_reason", "payroll_approved_by",
			"payroll_approved_on", "payroll_rejected_by", "payroll_rejected_on",
		])
	rows = frappe.get_list(
		"PRB Overtime Authorization", filters=filters, fields=fields,
		order_by="actual_start desc, employee_name asc", limit_page_length=1000,
	)
	for row in rows:
		if not row.get("payroll_approval_status"):
			row["payroll_approval_status"] = (
				"Pending" if row.authorization_status == "Recorded" and flt(row.approved_hours) > 0
				else "Awaiting Actuals"
			)
	return rows, start, end


def _attach_payroll(rows):
	if not rows:
		return rows
	names = [row.name for row in rows]
	inputs = frappe.db.sql(
		"""select i.name as input_row, i.source_name, i.parent as payroll_run,
			r.snapshot_status, r.posting_status, r.docstatus
		from `tabPRB Payroll Input` i
		inner join `tabPRB Payroll Run` r on r.name=i.parent and r.docstatus<2
		where i.source_doctype='PRB Overtime Authorization' and i.source_name in %(names)s
		order by r.modified desc""",
		{"names": tuple(names)}, as_dict=True,
	)
	by_source = {}
	for item in inputs:
		by_source.setdefault(item.source_name, item)
	input_names = [item.input_row for item in inputs]
	amounts = {}
	if input_names:
		for component in frappe.get_all(
			"PRB Payroll Component", filters={"input_row": ("in", input_names)},
			fields=["input_row", "amount", "salary_component", "additional_salary"],
			limit_page_length=0,
		):
			amounts[component.input_row] = component
	for row in rows:
		link = by_source.get(row.name)
		component = amounts.get(link.input_row) if link else None
		row.update({
			"payroll_run": link.payroll_run if link else None,
			"payroll_snapshot_status": link.snapshot_status if link else None,
			"payroll_posting_status": link.posting_status if link else None,
			"payroll_amount": flt(component.amount) if component else 0,
			"salary_component": component.salary_component if component else None,
			"additional_salary": component.additional_salary if component else None,
		})
	return rows


def additional_hours_rows(from_date=None, to_date=None, company=None, employee=None, approval_status=None):
	rows, start, end = _base_rows(from_date, to_date, company, employee, approval_status)
	return _attach_payroll(rows), start, end


def employee_summary(from_date=None, to_date=None, company=None, employee=None):
	rows, start, end = additional_hours_rows(from_date, to_date, company, employee)
	summary = {}
	for row in rows:
		item = summary.setdefault(row.employee, {
			"employee": row.employee,
			"employee_name": row.employee_name,
			"company": row.company,
			"overtime_hours": 0.0,
			"night_duty_hours": 0.0,
			"work_on_holiday_hours": 0.0,
			"excess_hours": 0.0,
			"total_additional_hours": 0.0,
			"payroll_amount": 0.0,
			"records": 0,
			"statuses": set(),
			"payroll_runs": set(),
		})
		hours = flt(row.approved_hours)
		if row.claim_type == "Night Duty":
			item["night_duty_hours"] += hours
		elif row.claim_type == "Excess Hours":
			item["excess_hours"] += hours
		elif row.overtime_period == "public_holiday":
			item["work_on_holiday_hours"] += hours
		else:
			item["overtime_hours"] += hours
		item["total_additional_hours"] += hours
		item["payroll_amount"] += flt(row.payroll_amount)
		item["records"] += 1
		item["statuses"].add(row.payroll_approval_status)
		if row.payroll_run:
			item["payroll_runs"].add(row.payroll_run)
	for item in summary.values():
		statuses = item.pop("statuses")
		if "Rejected" in statuses and len(statuses) == 1:
			status = "Rejected"
		elif "Pending" in statuses:
			status = "Pending Approval"
		elif "Awaiting Actuals" in statuses:
			status = "Awaiting Actuals"
		elif item["payroll_runs"]:
			status = "Linked to Payroll"
		elif "Approved" in statuses:
			status = "Ready for Payroll"
		else:
			status = "Not Ready"
		item["payroll_status"] = status
		item["payroll_runs"] = ", ".join(sorted(item["payroll_runs"]))
	return sorted(summary.values(), key=lambda row: ((row["employee_name"] or "").lower(), row["employee"])), start, end


@frappe.whitelist()
def register_context(from_date=None, to_date=None, company=None, employee=None):
	frappe.has_permission("PRB Overtime Authorization", "read", throw=True)
	summary, start, end = employee_summary(from_date, to_date, company, employee)
	rows, _start, _end = additional_hours_rows(start, end, company, employee)
	return {
		"from_date": start,
		"to_date": end,
		"company": company,
		"employee": employee,
		"summary": summary,
		"rows": rows,
		"totals": {
			"employees": len(summary),
			"records": len(rows),
			"overtime_hours": sum(flt(row["overtime_hours"]) for row in summary),
			"night_duty_hours": sum(flt(row["night_duty_hours"]) for row in summary),
			"work_on_holiday_hours": sum(flt(row["work_on_holiday_hours"]) for row in summary),
			"excess_hours": sum(flt(row["excess_hours"]) for row in summary),
			"total_additional_hours": sum(flt(row["total_additional_hours"]) for row in summary),
			"payroll_amount": sum(flt(row["payroll_amount"]) for row in summary),
		},
	}


def process_context(period_key=None, search=None, approval_status=None):
	from karyo.desk.payroll_screens import payslip_period_options

	options = payslip_period_options()
	selected = next((row for row in options if row["key"] == period_key), None)
	if not selected:
		selected = options[0] if options else None
	rows = []
	if selected:
		rows, _start, _end = additional_hours_rows(
			selected["start_date"], selected["end_date"], selected["company"],
			approval_status=approval_status,
		)
	query = (search or "").strip().lower()
	if query:
		rows = [row for row in rows if query in " ".join([
			str(row.get("name") or ""), str(row.get("employee") or ""),
			str(row.get("employee_name") or ""), str(row.get("claim_type") or ""),
		]).lower()]
	return {
		"periods": options,
		"selected_period": selected["key"] if selected else None,
		"period": selected,
		"rows": rows,
		"can_approve": has_actor_role("approver"),
		"counts": {
			"pending": sum(row.payroll_approval_status == "Pending" for row in rows),
			"approved": sum(row.payroll_approval_status == "Approved" for row in rows),
			"rejected": sum(row.payroll_approval_status == "Rejected" for row in rows),
			"hours": sum(flt(row.approved_hours) for row in rows),
		},
	}


def _parse_names(names):
	values = json.loads(names) if isinstance(names, str) else names
	values = list(dict.fromkeys(str(value) for value in (values or []) if value))
	if not values:
		frappe.throw(_("Select at least one overtime record."))
	if len(values) > 200:
		frappe.throw(_("Process no more than 200 records at once."))
	return values


@frappe.whitelist(methods=["POST"])
def decide(names, decision, reason=None):
	if not has_actor_role("approver"):
		frappe.throw(_("A Payroll Approver must approve or reject additional hours."), frappe.PermissionError)
	is_administrator = (
		frappe.session.user == "Administrator"
		or "System Manager" in frappe.get_roles(frappe.session.user)
	)
	decision = str(decision or "").title()
	if decision not in {"Approved", "Rejected"}:
		frappe.throw(_("Decision must be Approved or Rejected."))
	if decision == "Rejected" and not str(reason or "").strip():
		frappe.throw(_("Enter a rejection reason."))
	processed = []
	for name in _parse_names(names):
		doc = frappe.get_doc("PRB Overtime Authorization", name)
		# System administrators are the operational fallback approver and must not
		# be blocked merely because they are not the employee's assigned approver.
		if not is_administrator:
			doc.check_permission("write")
		if doc.docstatus != 1 or doc.authorization_status != "Recorded" or flt(doc.approved_hours) <= 0:
			frappe.throw(_("{0} is not a recorded, payable additional-hours item.").format(name))
		linked = frappe.db.sql(
			"""select i.parent from `tabPRB Payroll Input` i
			inner join `tabPRB Payroll Run` r on r.name=i.parent and r.docstatus<2
			where i.source_doctype='PRB Overtime Authorization' and i.source_name=%s limit 1""",
			name,
		)
		if linked:
			frappe.throw(_("{0} is already linked to Payroll Run {1} and its decision is locked.").format(name, linked[0][0]))
		now = now_datetime()
		values = {
			"payroll_approval_status": decision,
			"payroll_decision_reason": str(reason or "").strip() or None,
			"payroll_approved_by": frappe.session.user if decision == "Approved" else None,
			"payroll_approved_on": now if decision == "Approved" else None,
			"payroll_rejected_by": frappe.session.user if decision == "Rejected" else None,
			"payroll_rejected_on": now if decision == "Rejected" else None,
		}
		doc.db_set(values, update_modified=True)
		doc.add_comment("Info", _("Payroll overtime decision: {0}{1}").format(
			decision, _(" — {0}").format(reason) if reason else "",
		))
		doc.notify_update()
		processed.append(name)
	return {
		"processed": processed,
		"decision": decision,
		"message": _("{0} additional-hours record(s) {1}.").format(len(processed), decision.lower()),
	}
