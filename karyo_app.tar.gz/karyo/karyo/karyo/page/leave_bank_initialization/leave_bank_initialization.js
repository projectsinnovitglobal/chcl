frappe.pages["leave-bank-initialization"].on_page_load = function (wrapper) {
	const currentYear = frappe.datetime.get_today().slice(0, 4);
	const $body = karyo.pages.scaffold(wrapper, {
		title: __("Initialize Leave Banks"),
		subtitle: __("Open annual allocations and employee sick/vacation banks from governed MBC leave rules"),
		actions: [],
	});
	const $panel = karyo.pages.panel($body, { title: __("Calendar-year initialization") });
	$('<p class="text-muted"></p>').text(__("This operation is safe to repeat. Existing submitted allocations and bank records are not duplicated.")).appendTo($panel);
	const $form = $('<div class="row"></div>').appendTo($panel);
	const dialog = new frappe.ui.Dialog({
		title: __("Initialize Leave Banks"),
		fields: [
			{ fieldtype: "Link", fieldname: "company", options: "Company", label: __("Company"), reqd: 1, default: frappe.defaults.get_user_default("Company") },
			{ fieldtype: "Int", fieldname: "year", label: __("Leave Year"), reqd: 1, default: currentYear },
			{ fieldtype: "Date", fieldname: "entitlement_date", label: __("Entitlement Date"), reqd: 1, default: `${currentYear}-01-01` },
		],
		primary_action_label: __("Initialize"),
		primary_action: async values => {
			dialog.get_primary_btn().prop("disabled", true);
			try {
				const result = await frappe.xcall("karyo.hr.leave_controls.initialize_leave_banks", values);
				dialog.hide();
				$panel.find(".leave-init-result").remove();
				$('<div class="alert alert-success leave-init-result"></div>').text(__("Processed {0} employees: {1} allocations, {2} sick banks and {3} vacation banks created.", [result.employees, result.allocations, result.sick_banks, result.vacation_banks])).appendTo($panel);
			} finally {
				dialog.get_primary_btn().prop("disabled", false);
			}
		},
	});
	$('<button type="button" class="btn btn-primary"></button>').text(__("Initialize Leave Banks")).on("click", () => dialog.show()).appendTo($form);
};
