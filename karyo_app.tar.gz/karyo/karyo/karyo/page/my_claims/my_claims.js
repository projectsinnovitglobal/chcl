frappe.pages['my-claims'].on_page_load = function(wrapper) {
 const api='karyo.hr.employee_claims.', state={month:'',status:'',start:0,request:0};
 const $body=karyo.pages.scaffold(wrapper,{title:__('Expense Claims'),subtitle:__('Your expense claims, approval status and reimbursements'),actions:[]});
 $body.addClass('karyo-payroll-management pm-attendance-page pm-claims-page');
 const $filters=$('<div class="pm-card pm-attendance-filters"><label><span></span><input type="month" class="form-control" aria-label="Claim month"></label><label><span></span><select class="form-control" aria-label="Claim status"></select></label><button type="button" class="pm-btn pm-claims-reset"></button><button type="button" class="pm-btn primary pm-claims-new" hidden></button></div>').appendTo($body);
 $filters.find('span').eq(0).text(__('Month (optional)'));$filters.find('span').eq(1).text(__('Status'));
 for(const status of ['', 'Approved','Rejected','Cancelled'])$('<option>').val(status).text(__(status||'All statuses')).appendTo($filters.find('select'));
 const $content=$('<div class="pm-attendance-results">').appendTo($body),$pager=$('<div class="pm-attendance-pager">').appendTo($body);
 const date=v=>v?frappe.datetime.str_to_user(v):'—';
 const money=(v,c)=>format_currency(v||0,c);
 const plain=v=>new DOMParser().parseFromString(v||'','text/html').body.textContent;
 async function edit(row={}) {
  const current=row.name?await frappe.xcall(api+'get_record',{name:row.name}):{};
  const expenseTypes=[...new Set([...(state.expenseTypes||[]),...(current.expenses||[]).map(item=>item.expense_type).filter(Boolean)])];
  const d=karyo.loan_ui.drawer({title:row.name?__('Edit Claim · {0}',[row.name]):__('New Claim'),size:'large',fields:[
   {fieldtype:'Date',fieldname:'posting_date',label:__('Claim Date'),default:current.posting_date||frappe.datetime.get_today(),reqd:1},
   {fieldtype:'Table',fieldname:'expenses',label:__('Expense Items'),reqd:1,in_place_edit:1,data:current.expenses||[],fields:[
    {fieldtype:'Date',fieldname:'expense_date',label:__('Expense Date'),reqd:1,in_list_view:1},
    {fieldtype:'Select',fieldname:'expense_type',label:__('Expense Type'),options:expenseTypes.join('\n'),reqd:1,in_list_view:1},
    {fieldtype:'Data',fieldname:'description',label:__('Description'),in_list_view:1},
    {fieldtype:'Currency',fieldname:'amount',label:__('Amount'),reqd:1,in_list_view:1}
   ]},
   {fieldtype:'Small Text',fieldname:'remark',label:__('Notes'),default:plain(current.remark||'')},
   {fieldtype:'Attach',fieldname:'receipt',label:__('Receipt'),options:{make_attachments_public:false,restrictions:{allowed_file_types:['.pdf','.png','.jpg','.jpeg']}}}
  ]});
  let busy=false;
  d.set_primary_action(__('Save Claim'),async()=>{const values=d.get_values();if(!values||busy)return;busy=true;d.get_primary_btn().prop('disabled',true);try{await frappe.xcall(api+'save_claim',{name:row.name,values});d.hide();state.opened=frappe.get_route()[1]||null;frappe.show_alert({message:__('Claim saved'),indicator:'green'});await load();}finally{busy=false;d.get_primary_btn().prop('disabled',false);}});
  d.show();
 }

 function table($parent,labels){const $table=$('<table class="pm-table"><thead><tr></tr></thead><tbody></tbody></table>');$('<div class="pm-table-wrap">').append($table).appendTo($parent);for(const label of labels)$('<th scope="col">').text(__(label)).appendTo($table.find('thead tr'));return $table;}
 async function details(name){
  const row=await frappe.xcall(api+'get_record',{name});
  const d=karyo.loan_ui.drawer({title:__('Claim · {0}',[row.name]),fields:[{fieldtype:'HTML',fieldname:'details'}]});
  const $detail=d.fields_dict.details.$wrapper.addClass('karyo-payroll-management pm-claims-detail');
  const $summary=table($detail,['Field','Details']);
  for(const [label,value] of [['Claim',row.name],['Date',date(row.posting_date)],['Status',__(row.display_status)],['Claimed',money(row.total_claimed_amount,row.currency)],['Approved amount',money(row.total_sanctioned_amount,row.currency)],['Reimbursed',money(row.total_amount_reimbursed,row.currency)]])$('<tr>').append($('<td>').text(__(label)),$('<td>').text(value)).appendTo($summary.find('tbody'));
  $('<h4>').text(__('Expense items')).appendTo($detail);
  const $items=table($detail,['Date','Type','Description','Claimed','Approved amount']);
  for(const item of row.expenses){const $tr=$('<tr>').appendTo($items.find('tbody'));for(const value of [date(item.expense_date),item.expense_type,plain(item.description),money(item.amount,row.currency),money(item.sanctioned_amount,row.currency)])$('<td>').text(value||'—').appendTo($tr);}
  if(row.remark)$('<p class="pm-claims-note">').text(plain(row.remark)).appendTo($detail);
  if(row.attachments.length){$('<h4>').text(__('Receipts and attachments')).appendTo($detail);for(const file of row.attachments){if(/^\/(private\/)?files\//.test(file.file_url))$('<p>').append($('<a target="_blank" rel="noopener">').attr('href',file.file_url).text(file.file_name)).appendTo($detail);}}
  if(row.can_edit)d.set_primary_action(__('Edit claim'),()=>{d.hide();edit(row);});
  d.show();
 }
 async function load(){
  const ticket=++state.request;$content.attr('aria-busy','true');
  try{
   const data=await frappe.xcall(api+'get_claims',{month:state.month,status:state.status,start:state.start});if(ticket!==state.request||frappe.get_route()[0]!=='my-claims')return;
   state.employee=data.employee;state.expenseTypes=data.expense_types||[];$filters.find('.pm-claims-new').prop('hidden',!data.can_create);
   $content.empty();$('<p class="pm-muted">').text(__('{0} · {1} claim(s)',[data.employee_name,data.total])).appendTo($content);
   const $table=table($content,['Claim','Date','Status','Claimed','Approved amount','Reimbursed','Actions']);
   $table.find('th').slice(3,6).addClass('text-right');$table.find('th').last().addClass('pm-row-actions');
   for(const row of data.rows){
    const $tr=$('<tr>').appendTo($table.find('tbody'));
    $('<td>').append($('<button type="button" class="pm-btn small ghost pm-claim-view">').text(row.name).on('click',()=>details(row.name))).appendTo($tr);
    $('<td>').text(date(row.posting_date)).appendTo($tr);
    $('<td>').append($('<span class="pm-chip">').text(__(row.display_status))).appendTo($tr);
    for(const key of ['total_claimed_amount','total_sanctioned_amount','total_amount_reimbursed'])$('<td class="text-right">').text(money(row[key],row.currency)).appendTo($tr);
    const $actions=$('<td class="pm-row-actions">').appendTo($tr);
    $('<button type="button" class="pm-btn small pm-claim-view">').text(__('View')).on('click',()=>details(row.name)).appendTo($actions);
    if(row.can_edit)$('<button type="button" class="pm-btn small ghost pm-claim-edit">').text(__('Edit')).on('click',()=>edit(row)).appendTo($actions);
   }
   if(!data.rows.length)$('<tr>').append($('<td colspan="7" class="pm-empty">').text(__('No claims match these filters.'))).appendTo($table.find('tbody'));
   $pager.empty();if(state.start||data.has_more)for(const [label,delta,enabled] of [['Previous',-25,state.start>0],['Next',25,data.has_more]])$('<button class="pm-btn" type="button">').text(__(label)).prop('disabled',!enabled).on('click',()=>{state.start+=delta;load();}).appendTo($pager);
   const name=frappe.get_route()[1];if(name&&name!==state.opened){state.opened=name;if(name==='new')await edit();else await details(name);}
  }catch(error){if(ticket===state.request)$content.empty().append($('<p role="alert">').text(__('Unable to load claims. Please refresh and try again.')));}finally{if(ticket===state.request)$content.removeAttr('aria-busy');}
 }
 $filters.find('input,select').on('change',()=>{state.month=$filters.find('input').val();state.status=$filters.find('select').val();state.start=0;load();});
 $filters.find('.pm-claims-reset').text(__('Reset')).on('click',()=>{state.month='';state.status='';state.start=0;$filters.find('input,select').val('');load();});
 $filters.find('.pm-claims-new').text(__('New claim')).on('click',()=>edit());
 wrapper.reload_claims=load;
 karyo.live.watch('my-claims',load,['Expense Claim'],()=>frappe.get_route()?.[0]==='my-claims');
};
frappe.pages['my-claims'].on_page_show=wrapper=>wrapper.reload_claims?.();
