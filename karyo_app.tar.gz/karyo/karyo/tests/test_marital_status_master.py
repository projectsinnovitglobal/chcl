import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.employee_import import _resolve_link
from karyo.setup.employee_master import MARITAL_STATUSES, apply


class TestMaritalStatusMaster(FrappeTestCase):
	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		apply()

	def test_master_populates_employee_marital_status(self):
		field = frappe.get_meta("Employee").get_field("marital_status")
		self.assertEqual(field.fieldtype, "Link")
		self.assertEqual(field.options, "Marital Status")
		self.assertEqual(
			{
				(row.marital_status_code, row.marital_status_description, row.is_active)
				for row in frappe.get_all(
					"Marital Status",
					fields=["marital_status_code", "marital_status_description", "is_active"],
					limit_page_length=0,
				)
			},
			{(code, description, 1) for code, description in MARITAL_STATUSES},
		)
		self.assertEqual(_resolve_link("marital_status", "M", "Marital Status"), "M")
		self.assertEqual(_resolve_link("marital_status", "Married", "Marital Status"), "M")
