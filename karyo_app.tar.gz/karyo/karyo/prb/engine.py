"""PRB 2026 salary conversion engine (pure, DB-free, unit-testable).

Implements the salary-point lookup and conversion rules (PRB analysis §5, MSC-*,
CONV-*): the Master Salary Conversion Table is a DATA LOOKUP, never recalculated.

    convert to Row 3 (revised 2026); if an annual increment is due on 01-Jan-2026,
    move one salary point FIRST, then convert (CONV-02), capped at the grade top
    (MSC-04 / INC-03).
"""

from karyo.prb.master_table import MASTER_SALARY_TABLE


def build_lookups(table=None):
	"""Return (revised_by_point, ordered_points) for a master table."""
	table = table or MASTER_SALARY_TABLE
	revised = {p: r3 for p, _r1, _r2, r3 in table}
	ordered = [p for p, _r1, _r2, _r3 in table]
	return revised, ordered


def next_point(point, ordered):
	"""The next salary point in sequence, or None at the end."""
	if point not in ordered:
		return None
	i = ordered.index(point)
	return ordered[i + 1] if i + 1 < len(ordered) else None


def increment_value(point, revised=None, ordered=None):
	"""Value of one increment at `point` in revised-2026 terms (MSC-03)."""
	if revised is None:
		revised, ordered = build_lookups()
	nxt = next_point(point, ordered)
	if nxt is None or point not in revised:
		return 0
	return revised[nxt] - revised[point]


def convert_salary_point(point, increment_due=False, grade_top=None, revised=None, ordered=None):
	"""Convert a salary point to its revised 2026 salary.

	`increment_due`: apply the 01-Jan-2026 annual increment before converting
	(CONV-02); capped at `grade_top` if given (MSC-04). Returns a breakdown dict.
	"""
	if revised is None:
		revised, ordered = build_lookups()

	effective_point = point
	if increment_due:
		nxt = next_point(point, ordered)
		if nxt is not None and (grade_top is None or nxt <= grade_top):
			effective_point = nxt

	return {
		"from_point": point,
		"increment_applied": effective_point != point,
		"converted_point": effective_point,
		"revised_salary_2026": revised.get(effective_point),
	}
