import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.tests import test_payslip_confirmation as fixtures
from karyo.payroll.completion import run_process_step
from karyo.payroll.employee_processing import state, resolve_employees, population

class TestEmployeeProcessingScope(unittest.TestCase):
    def setUp(self):
        self.fixture=fixtures.TestPayslipConfirmation()
        self.fixture.setUp()
        self.a=self.fixture.employee.name
        employee=frappe.copy_doc(self.fixture.employee)
        employee.name='scope-employee-'+uuid4().hex
        employee.docstatus=0
        employee.db_insert()
        self.b=employee.name
        assignment=frappe.copy_doc(frappe.get_doc('Salary Structure Assignment',frappe.db.get_value(
            'Salary Structure Assignment',{'employee':self.a,'docstatus':1},'name')))
        assignment.name='scope-assignment-'+uuid4().hex
        assignment.employee=self.b
        assignment.docstatus=1
        assignment.db_insert()
        for n in range(1,31):
            frappe.get_doc({'doctype':'Attendance','name':'scope-attendance-'+uuid4().hex,'employee':self.b,
                'company':employee.company,'attendance_date':f'2026-06-{n:02}','status':'Present','docstatus':1}).db_insert()
        template=frappe.get_doc('Payroll Pay Day',frappe.db.get_value('Payroll Pay Day',{'payroll_type':'Minor'},'name'))
        day=frappe.copy_doc(template)
        day.name='scope-day-'+uuid4().hex
        day.pay_day_code=day.name.upper()
        day.start_date='2026-06-01';day.end_date='2026-06-30';day.payment_date='2026-06-25'
        day.pay_period_label='Scope '+uuid4().hex[:8]
        day.status='Active';day.docstatus=0;day.db_insert()
        self.cycle=frappe.get_doc({'doctype':'Payroll Cycle','pay_day':day.name,'company':employee.company,'status':'Draft'}).insert()
        self.validation=patch('karyo.payroll.readiness.validate_employee',return_value=[])
        self.validate=self.validation.start()
        self.email=patch('frappe.sendmail');self.email.start()
        self.realtime=patch('frappe.publish_realtime');self.realtime.start()
    def tearDown(self):
        self.validation.stop();self.email.stop();self.realtime.stop()
        self.fixture.tearDown()
    def run_step(self,action,employees):
        result=run_process_step(self.cycle.name,action,employees)
        self.cycle.reload()
        return result
    def active(self,employees):
        self.cycle.reload()
        return [s['action'] for s in state(self.cycle,employees)['steps'] if s['available']]
    def test_single_then_multiple_creates_only_missing_selected_slips(self):
        self.run_step('Open Inputs',[self.a])
        self.run_step('Run Readiness Checks',[self.a])
        self.assertEqual(set(population(self.cycle,[self.a,self.b])),{self.a})
        self.assertEqual(self.active([self.a]),['Start Processing'])
        self.assertEqual(self.active([self.b]),['Run Readiness Checks'])
        self.run_step('Start Processing',[self.a])
        self.run_step('Prepare Payroll',[self.a])
        result=self.run_step('Generate Draft Salary Slips',[self.a])
        self.assertEqual(result['generated'],1)
        entry=self.cycle.payroll_entry
        self.assertEqual(frappe.get_all('Salary Slip',filters={'payroll_entry':entry},pluck='employee'),[self.a])
        self.assertEqual(self.active([self.a]),[])
        self.assertEqual(self.active([]),['Run Readiness Checks'])
        self.assertEqual(self.active([self.a,self.b]),['Run Readiness Checks'])
        self.run_step('Run Readiness Checks',[self.a,self.b])
        self.run_step('Start Processing',[self.a,self.b])
        self.run_step('Prepare Payroll',[self.a,self.b])
        result=self.run_step('Generate Draft Salary Slips',[self.a,self.b])
        self.assertEqual((result['generated'],result['reused']),(1,1))
        self.assertEqual(set(frappe.get_all('Salary Slip',filters={'payroll_entry':entry},pluck='employee')),{self.a,self.b})
        self.assertEqual(self.active([self.a,self.b]),[])
        self.assertEqual(set(frappe.get_all('Payroll Employee Detail',filters={'parent':entry},pluck='employee')),{self.a,self.b})

    def test_submitted_entry_accepts_safe_supplemental_population(self):
        for action in ('Open Inputs','Run Readiness Checks','Start Processing','Prepare Payroll',
                       'Generate Draft Salary Slips'):
            self.run_step(action,[self.a])
        entry=frappe.get_doc('Payroll Entry',self.cycle.payroll_entry)
        original_children={row.employee for row in entry.employees}
        original_slip=frappe.db.get_value('Salary Slip',{'payroll_entry':entry.name,'employee':self.a},'name')
        frappe.db.set_value('Payroll Entry',entry.name,{'docstatus':1,'status':'Submitted'})

        self.run_step('Run Readiness Checks',[self.b])
        self.run_step('Start Processing',[self.b])
        current=state(self.cycle,[self.b])
        amend_step=next(step for step in current['steps'] if step['action']=='Prepare Payroll')
        self.assertTrue(current['population_amendment_required'])
        self.assertEqual(amend_step['label'],'Amend Employee Population')
        self.assertTrue(amend_step['population_amendment'])

        result=self.run_step('Prepare Payroll',[self.b])
        self.assertEqual(result['supplemental'],1)
        entry.reload()
        self.assertEqual(entry.docstatus,1)
        self.assertEqual({row.employee for row in entry.employees},original_children)
        self.assertEqual(frappe.db.get_value('Payroll Cycle Employee',{
            'payroll_cycle':self.cycle.name,'employee':self.b},'payroll_entry'),entry.name)

        generated=self.run_step('Generate Draft Salary Slips',[self.b])
        self.assertEqual(generated['generated'],1)
        self.assertEqual(frappe.db.get_value('Salary Slip',{
            'payroll_entry':entry.name,'employee':self.a},'name'),original_slip)
        self.assertTrue(frappe.db.exists('Salary Slip',{'payroll_entry':entry.name,'employee':self.b}))
    def test_selected_readiness_preserves_other_exceptions_and_progress(self):
        self.run_step('Open Inputs',[self.a])
        self.validate.side_effect=lambda cycle, employee: ([{'validation_code':'TEST_BLOCK','severity':'Blocking','message':'Fix B'}] if employee==self.b else [])
        blocked_result=self.run_step('Run Readiness Checks',[self.b])
        self.assertEqual(blocked_result['blockers'][0]['employee'],self.b)
        self.assertIn(frappe.db.get_value('Employee',self.b,'employee_name'),blocked_result['message'])
        self.assertIn(self.b,blocked_result['message'])
        self.assertIn('Fix B',blocked_result['message'])
        before=frappe.db.get_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':self.b},'readiness_checked_on')
        self.run_step('Run Readiness Checks',[self.a])
        self.assertEqual(frappe.db.get_value('Payroll Cycle Employee',{'payroll_cycle':self.cycle.name,'employee':self.b},'readiness_checked_on'),before)
        self.assertEqual(state(self.cycle,[self.a])['counts']['blocking'],0)
        self.assertEqual(state(self.cycle,[self.b])['counts']['blocking'],1)
        self.assertEqual(self.cycle.readiness_status,'Blocked')
        self.run_step('Start Processing',[self.a])
        with self.assertRaises(frappe.ValidationError):self.run_step('Start Processing',[self.b])
    def test_native_failure_rolls_back_entire_selected_batch(self):
        for action in ('Open Inputs','Run Readiness Checks','Start Processing','Prepare Payroll'):
            self.run_step(action,[self.a,self.b])
        entry=self.cycle.payroll_entry
        frappe.db.delete('Salary Structure Assignment',{'employee':self.b})
        frappe.db.savepoint('scope_generation_failure')
        with self.assertRaises(frappe.ValidationError) as error:
            self.run_step('Generate Draft Salary Slips',[self.a,self.b])
        self.assertIn(self.b,str(error.exception))
        self.assertIn(frappe.db.get_value('Employee',self.b,'employee_name'),str(error.exception))
        # Match the request transaction rollback; native processing must not commit.
        frappe.db.rollback(save_point='scope_generation_failure')
        self.assertEqual(frappe.db.count('Salary Slip',{'payroll_entry':entry}),0)
        self.assertEqual(self.active([self.a,self.b]),['Generate Draft Salary Slips'])

    def test_empty_defaults_to_all_and_invalid_scope_is_rejected(self):
        selected,options=resolve_employees(self.cycle,[])
        self.assertEqual(set(selected),{r.name for r in options})
        self.assertIn(self.a,selected);self.assertIn(self.b,selected)
        with self.assertRaises(frappe.ValidationError):resolve_employees(self.cycle,['does-not-exist'])
        frappe.db.set_value('Employee',self.b,'status','Inactive')
        with self.assertRaises(frappe.ValidationError):resolve_employees(self.cycle,[self.b])
        with self.assertRaises(frappe.ValidationError):resolve_employees(self.cycle,{'employee':self.a})
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):run_process_step(self.cycle.name,'Open Inputs',[self.a])
        frappe.set_user('Administrator')

    def test_process_cycle_list_includes_every_eligible_employee_before_processing(self):
        from karyo.desk.payroll_screens import _cycle_employees
        rows = _cycle_employees(self.cycle, limit=0, employees=[self.a, self.b])
        self.assertEqual({row['employee'] for row in rows}, {self.a, self.b})
        self.assertTrue(all(row['process_status'] == 'Not Started' for row in rows))

    def test_ineligible_employee_error_explains_service_date(self):
        frappe.db.set_value('Employee', self.b, 'date_of_joining', '2026-07-01')
        with self.assertRaises(frappe.ValidationError) as error:
            resolve_employees(self.cycle, [self.b])
        message = str(error.exception)
        self.assertIn(frappe.db.get_value('Employee', self.b, 'employee_name'), message)
        self.assertIn('2026-07-01', message)
        self.assertIn('2026-06-01', message)
        self.assertIn('2026-06-30', message)

    def test_minor_prerequisite_is_visible_before_start_and_enforced(self):
        self.run_step('Open Inputs', [self.a])
        self.run_step('Run Readiness Checks', [self.a])
        self.cycle.payroll_type = 'Major'
        self.cycle.minor_sequence_waived = 0
        self.cycle.db_update()
        with patch('frappe.db.get_single_value', return_value=1):
            current = state(self.cycle, [self.a])
            self.assertTrue(current['ready'])
            self.assertIn('Create and approve', current['sequence_blocked_reason'])
            self.assertNotIn('Start Processing', self.active([self.a]))
            with self.assertRaises(frappe.ValidationError):
                self.run_step('Start Processing', [self.a])
            self.cycle.minor_sequence_waived = 1
            self.cycle.minor_waiver_reason = 'No Minor run required for this test period'
            self.cycle.db_update()
            self.assertIsNone(state(self.cycle, [self.a])['sequence_blocked_reason'])
            self.assertIn('Start Processing', self.active([self.a]))
