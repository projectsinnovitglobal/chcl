"""Controlled, reversible loan component correction transaction."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def setup():
	make_doctype("Karyo Loan Correction", is_submittable=1, autoname="naming_series:", title_field="loan", fields=[
		f("naming_series", "Select", "Series", options="KLCOR-.YYYY.-.#####", default="KLCOR-.YYYY.-.#####"),
		f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
		f("employee", "Link", "Employee", options="Employee", read_only=1),
		f("effective_date", "Date", "Effective Date", reqd=1, in_list_view=1),
		f("component", "Select", "Component", options="Capital\nInterest\nInsurance", reqd=1, in_list_view=1),
		f("adjustment_amount", "Currency", "Signed Adjustment Amount", reqd=1, in_list_view=1,
			description="Positive increases the amount owed; negative reduces it."),
		f("schedule_row", "Link", "Affected Current Schedule Row", options="Karyo Loan Schedule", reqd=1),
		f("approval_reference", "Data", "Approval Reference", reqd=1),
		f("evidence_reference", "Data", "Evidence Reference", reqd=1),
		f("reason", "Small Text", "Correction Reason", reqd=1),
		f("snapshot", "Long Text", "Prior State Snapshot", read_only=1, hidden=1),
		f("ledger_entry", "Link", "Correction Ledger Entry", options="Karyo Loan Ledger Entry", read_only=1),
		f("reversal_ledger_entry", "Link", "Reversal Ledger Entry", options="Karyo Loan Ledger Entry", read_only=1),
		f("idempotency_key", "Data", "Idempotency Key", read_only=1, unique=1),
		f("reversal_processed", "Check", "Reversal Processed", read_only=1),
	])
	create_custom_fields({"Karyo Loan Ledger Entry": [
		{"fieldname": "is_reversal", "fieldtype": "Check", "label": "Is Reversal", "read_only": 1, "insert_after": "allocation_references"},
		{"fieldname": "reversal_of", "fieldtype": "Link", "label": "Reversal Of", "options": "Karyo Loan Ledger Entry", "read_only": 1, "insert_after": "is_reversal"},
		{"fieldname": "idempotency_key", "fieldtype": "Data", "label": "Idempotency Key", "read_only": 1, "unique": 1, "insert_after": "reversal_of"},
	]}, ignore_validate=True)
	frappe.db.commit()
