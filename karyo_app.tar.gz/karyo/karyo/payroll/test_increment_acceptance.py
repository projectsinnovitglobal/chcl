"""Multiple salary awards through the production drawer, with rollback fixtures."""
import unittest
from unittest.mock import patch

import frappe
from karyo.tests.test_salary_scales import TestSalaryScales
from karyo.desk.payroll_drawer import record_save
from karyo.payroll.bulk import approve_run, apply_run, employee_preview
from karyo.payroll.salary_scales import approved_appointment, employee_salary, my_salary, sync_employee, validate_salary_slip_base


class TestIncrementAcceptance(unittest.TestCase):
    make_scale = TestSalaryScales.make_scale
    appointment = TestSalaryScales.appointment
    tearDown = TestSalaryScales.tearDown

    def setUp(self):
        TestSalaryScales.setUp(self)
        self.scale = self.make_scale('INCREMENT-' + self.uid, [(19800, 500), (22300, 0)])
        self.scale.submit()
        self.grade.set('karyo_salary_scales', [{'salary_scale': self.scale.name,
            'effective_from': '2026-01-01', 'effective_to': '2026-12-31'}])
        self.grade.save()
        self.original = self.appointment().insert()
        self.original.submit()
        self.employee.db_set({'status': 'Active', 'karyo_payroll_setup_pending_activation': 0})
        self.owner = 'increment-qa-' + self.uid + '@example.invalid'
        frappe.get_doc({'doctype': 'User', 'name': self.owner, 'email': self.owner,
            'first_name': 'Increment QA', 'enabled': 1, 'user_type': 'System User'}).db_insert()
        self.employee.db_set('user_id', self.owner)

    def run_award(self, points=3, date='2026-10-01'):
        result = record_save('bulk', 'Bulk Payroll Run', {
            'run_title': 'Multiple increments QA ' + self.uid,
            'run_type': 'Increment', 'company': self.employee.company,
            'effective_date': date, 'period_start': '2026-01-01', 'period_end': '2026-12-31',
            'lines': [{'employee': self.employee.name, 'include': 1, 'increment_steps': points}],
        })
        batch = frappe.get_doc('Bulk Payroll Run', result['name'])
        self.assertEqual(batch.employee_count, 1, [r.exception_detail for r in batch.lines])
        return batch

    def test_screenshot_three_increments_full_flow_and_repeat(self):
        preview = employee_preview(self.employee.name, '2026-10-01', 'Increment', 3)
        self.assertEqual((preview['increment_steps'], preview['increment_amount'], preview['proposed_salary']), (3, 1500, 21300))
        batch = self.run_award()
        self.assertEqual((batch.lines[0].increment_steps, batch.lines[0].applied_increment_points), (3, 3))
        approve_run(batch.name)
        applied = apply_run(batch.name)
        self.assertEqual(applied['total'], 1500)
        batch.reload(); self.original.reload()
        self.assertEqual(str(self.original.effective_to), '2026-09-30')
        current = approved_appointment(self.employee.name, '2026-10-01')
        self.assertEqual((str(current.salary_point), current.basic_salary), ('4', 21300))
        self.assertEqual(approved_appointment(self.employee.name, '2026-09-30').basic_salary, 19800)
        assignment = frappe.db.get_value('Salary Structure Assignment',
            {'employee': self.employee.name, 'docstatus': 1, 'from_date': '2026-10-01'}, ['base', 'karyo_salary_appointment'], as_dict=True)
        self.assertEqual((assignment.base, assignment.karyo_salary_appointment), (21300, current.name))
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'ctc'), 21300)
        slip = frappe._dict(employee=self.employee.name, salary_structure=self.structure,
            start_date='2026-10-01', end_date='2026-10-31', posting_date='2026-10-31')
        validate_salary_slip_base(slip)
        self.assertEqual((slip.karyo_salary_base, slip.karyo_salary_point), (21300, 4))
        hr = employee_salary(self.employee.name)
        frappe.set_user(self.owner)
        ess = my_salary()
        frappe.set_user('Administrator')
        self.assertEqual(hr, ess)
        self.assertEqual(len(hr['history']), 2)
        self.assertTrue(apply_run(batch.name)['already_applied'])
        self.assertEqual(frappe.db.count('Employee Salary Appointment', {'employee': self.employee.name}), 2)
        self.assertTrue(any(call.args[0] == 'karyo_employee_request_updated'
            and call.args[1]['doctype'] == 'Employee Salary Appointment'
            and call.kwargs.get('user') == self.owner and call.kwargs.get('after_commit')
            for call in frappe.publish_realtime.mock_calls))

    def test_future_and_subsequent_awards_use_dated_point(self):
        first = self.run_award(3, '2026-11-01'); approve_run(first.name); apply_run(first.name)
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'ctc'), 19800)
        second = self.run_award(2, '2026-11-15')
        self.assertEqual((second.lines[0].original_salary_point, second.lines[0].proposed_salary_point), ('4', '6'))
        approve_run(second.name); apply_run(second.name)
        self.assertEqual(approved_appointment(self.employee.name, '2026-11-14').basic_salary, 21300)
        self.assertEqual(approved_appointment(self.employee.name, '2026-11-15').basic_salary, 22300)
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'ctc'), 19800)
        with patch('karyo.payroll.salary_scales.nowdate', return_value='2026-11-15'):
            sync_employee(self.employee.name)
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'ctc'), 22300)

    def test_scale_top_caps_applied_points(self):
        batch = self.run_award(9)
        row = batch.lines[0]
        self.assertEqual((row.increment_steps, row.applied_increment_points, row.proposed_salary, row.increment_amount), (9, 5, 22300, 2500))
        approve_run(batch.name); apply_run(batch.name)
        preview = employee_preview(self.employee.name, '2026-10-02', 'Increment', 2)
        self.assertEqual(preview['exception_code'], 'NOT_INCREMENT_ELIGIBLE')
        self.assertFalse(preview['include'])

    def test_stale_approved_run_is_blocked(self):
        first = self.run_award(2); second = self.run_award(3)
        approve_run(first.name); approve_run(second.name); apply_run(first.name)
        with self.assertRaisesRegex(frappe.ValidationError, 'Salary history has changed'):
            apply_run(second.name)
        self.assertEqual(approved_appointment(self.employee.name, '2026-10-01').basic_salary, 20800)

    def test_changing_points_requires_recalculation(self):
        batch = self.run_award(2)
        batch.lines[0].increment_steps = 3; batch.save()
        self.assertEqual(batch.status, 'Draft')
        with self.assertRaisesRegex(frappe.ValidationError, 'Calculated'):
            approve_run(batch.name)

    def test_employee_cannot_apply_or_approve(self):
        batch = self.run_award()
        frappe.set_user('Guest')
        for action in (approve_run, apply_run):
            with self.assertRaises(frappe.PermissionError): action(batch.name)

    def test_prb_appointment_multiple_future_awards(self):
        self.original.flags.ignore_permissions = True; self.original.cancel()
        grade = frappe.get_doc({'doctype': 'PRB Grade Scale', 'grade_id': 'QA-PRB-' + self.uid,
            'initial_point': '070', 'top_point': '100', 'is_flat_salary': 0}).insert()
        self.employee.db_set({'karyo_prb_opted_in': 1, 'karyo_prb_grade': grade.name,
            'karyo_prb_salary_point': '081'})
        original = self.appointment(pay_basis='PRB', grade=None, salary_point=None,
            prb_grade=grade.name, prb_salary_point='081', prb_year=2026).insert()
        original.submit()
        first = self.run_award(2, '2026-11-01')
        self.assertEqual((first.lines[0].original_salary_point, first.lines[0].proposed_salary_point), ('081', '083'))
        approve_run(first.name); apply_run(first.name)
        second = self.run_award(2, '2026-11-15')
        self.assertEqual((second.lines[0].original_salary_point, second.lines[0].proposed_salary_point), ('083', '085'))
        approve_run(second.name); apply_run(second.name)
        dated = approved_appointment(self.employee.name, '2026-11-15')
        self.assertEqual((dated.pay_basis, dated.prb_salary_point), ('PRB', '085'))
        self.assertEqual(frappe.db.get_value('Employee', self.employee.name, 'karyo_prb_salary_point'), '081')
        base = frappe.db.get_value('Salary Structure Assignment',
            {'employee': self.employee.name, 'docstatus': 1, 'from_date': '2026-11-15'}, 'base')
        self.assertEqual(base, dated.basic_salary)
