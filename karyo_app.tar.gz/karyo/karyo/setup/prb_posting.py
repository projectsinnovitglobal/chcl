"""PRB component mapping and downstream payroll posting metadata (PAY-041)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype

DEMO_COMPONENTS = [
	("BASIC", "Basic Salary", "BASIC", "Overwrite"),
	("ACTING", "Acting Allowance", None, "Add"),
	("RESPONSIBILITY", "Responsibility Allowance", None, "Add"),
	("OVERTIME", "Overtime", None, "Add"),
	("NIGHT_DUTY", "Night Duty", None, "Add"),
	("WEATHER", "Extreme Weather Compensation", None, "Add"),
	("ATTENDANCE_BONUS", "Attendance Bonus", None, "Add"),
	("INCENTIVE_PRESENCE", "Incentive Presence Bonus", None, "Add"),
	("ERA_HOURS", "ERA Hours Payment", None, "Add"),
	("CAR_MILEAGE", "Car Mileage", None, "Add"),
	("MOTORCYCLE_MILEAGE", "Motorcycle Mileage", None, "Add"),
	("AUTOCYCLE_MILEAGE", "Autocycle Mileage", None, "Add"),
	("MEAL", "Meal Allowance", None, "Add"),
	("SUBSISTENCE", "Subsistence Allowance", None, "Add"),
	("OUT_OF_POCKET", "Out-of-Pocket Allowance", None, "Add"),
	("INDUCEMENT", "Inducement Allowance", None, "Add"),
	("DISTURBANCE", "Disturbance Allowance", None, "Add"),
	("VACATION_DEATH", "Vacation Leave Death Refund", None, "Add"),
	("SLB_EXIT", "Sick Leave Bank Exit Payout", None, "Add"),
	("PMS_AWARD", "PMS Award", None, "Add"),
	("EXCESS_HOURS", "Excess Hours", None, "Add"),
]

# Component codes used by the calculation engine must resolve to the client's
# authoritative PDB catalogue when it is installed.  The PRB-* rows remain a
# fallback for isolated demo sites only.
ATTENDANCE_BUSINESS_MAPPINGS = [
	("ATTENDANCE_BONUS", "Attendance Bonus", "ATTE"),
	("INCENTIVE_ATTENDANCE", "Incentive Attendance Bonus", "INC_A"),
	("INCENTIVE_PRESENCE", "Incentive Presence Bonus", "INPB"),
]


def create_doctype():
	make_doctype(
		"PRB Payroll Component Mapping",
		autoname="field:component_code",
		naming_rule="By fieldname",
		fields=[
			f("component_code", "Data", "PRB Component Code", reqd=1, unique=1, in_list_view=1),
			f("description", "Data", "Description", reqd=1, in_list_view=1),
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1, in_list_view=1),
			f(
				"posting_mode",
				"Select",
				"Posting Mode",
				options="Add\nOverwrite",
				default="Add",
				reqd=1,
			),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
		],
	)


def add_posting_fields():
	create_custom_fields(
		{
			"PRB Overtime Authorization": [
				{
					"fieldname": "payroll_approval_status",
					"fieldtype": "Select",
					"label": "Payroll Approval",
					"options": "Awaiting Actuals\nPending\nApproved\nRejected",
					"default": "Awaiting Actuals",
					"read_only": 1,
					"allow_on_submit": 1,
					"in_list_view": 1,
					"in_standard_filter": 1,
					"insert_after": "eligibility_reason",
				},
				{
					"fieldname": "payroll_decision_reason",
					"fieldtype": "Small Text",
					"label": "Payroll Decision Reason",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "payroll_approval_status",
				},
				{
					"fieldname": "payroll_approved_by",
					"fieldtype": "Link",
					"label": "Payroll Approved By",
					"options": "User",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "payroll_decision_reason",
				},
				{
					"fieldname": "payroll_approved_on",
					"fieldtype": "Datetime",
					"label": "Payroll Approved On",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "payroll_approved_by",
				},
				{
					"fieldname": "payroll_rejected_by",
					"fieldtype": "Link",
					"label": "Payroll Rejected By",
					"options": "User",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "payroll_approved_on",
				},
				{
					"fieldname": "payroll_rejected_on",
					"fieldtype": "Datetime",
					"label": "Payroll Rejected On",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "payroll_rejected_by",
				},
			],
			"PRB Payroll Component": [
				{
					"fieldname": "pdb_code",
					"fieldtype": "Link",
					"label": "PDB Code",
					"options": "Payroll PDB Code",
					"read_only": 1,
					"insert_after": "delta_amount",
				},
				{
					"fieldname": "salary_component",
					"fieldtype": "Link",
					"label": "Salary Component",
					"options": "Salary Component",
					"read_only": 1,
					"insert_after": "pdb_code",
				},
				{
					"fieldname": "additional_salary",
					"fieldtype": "Link",
					"label": "Additional Salary",
					"options": "Additional Salary",
					"read_only": 1,
					"insert_after": "salary_component",
				},
			],
			"PRB Payroll Run": [
				{
					"fieldname": "posting_status",
					"fieldtype": "Select",
					"label": "Payroll Posting",
					"options": "Not Posted\nPosted\nReversed",
					"default": "Not Posted",
					"read_only": 1,
					"insert_after": "approved_on",
				},
				{
					"fieldname": "posted_total",
					"fieldtype": "Currency",
					"label": "Posted Total",
					"read_only": 1,
					"insert_after": "posting_status",
				},
				{
					"fieldname": "reconciliation_status",
					"fieldtype": "Select",
					"label": "Reconciliation",
					"options": "Pending\nMatched\nMismatch",
					"default": "Pending",
					"read_only": 1,
					"insert_after": "posted_total",
				},
			],
		},
		ignore_validate=True,
	)


def seed_demo_mappings():
	"""Safe, editable fixtures until the client PDB catalogue is activated."""
	if (frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo") != "Demo":
		return
	configuration = frappe.db.get_value(
		"Payroll Configuration Version",
		{"config_key": "DEMO-PDB-2026", "version": "DEMO-1"},
		"name",
	)
	if not configuration or not frappe.db.exists("Payroll PDB Type", "PAY"):
		return
	for sequence, (code, description, existing_pdb, posting_mode) in enumerate(DEMO_COMPONENTS, 1):
		pdb_code = existing_pdb or f"PRB-{code.replace('_', '-')}"
		if not frappe.db.exists("Payroll PDB Code", pdb_code):
			component = f"PRB {description} (Demo)"
			if not frappe.db.exists("Salary Component", component):
				abbreviation = "EXH" if code == "EXCESS_HOURS" else f"PR{sequence:02}"
				frappe.get_doc(
					{
						"doctype": "Salary Component",
						"salary_component": component,
						"salary_component_abbr": abbreviation,
						"type": "Earning",
						"is_tax_applicable": 1,
						"depends_on_payment_days": 0,
					}
				).insert(ignore_permissions=True)
			frappe.get_doc(
				{
					"doctype": "Payroll PDB Code",
					"pdb_code": pdb_code,
					"pdb_type": "PAY",
					"description": f"PRB {description} (Demo)",
					"short_description": description,
					"salary_component": component,
					"transaction_mode": "Once Off",
					"taxable": 1,
					"is_active": 1,
					"effective_from": "2026-01-01",
					"configuration_version": configuration,
					"source_reference": "DEMO PRB mapping — client catalogue pending",
				}
			).insert(ignore_permissions=True)
		if not frappe.db.exists("PRB Payroll Component Mapping", code):
			frappe.get_doc(
				{
					"doctype": "PRB Payroll Component Mapping",
					"component_code": code,
					"description": f"{description} (Demo)",
					"pdb_code": pdb_code,
					"posting_mode": posting_mode,
					"is_active": 1,
				}
			).insert(ignore_permissions=True)


def ensure_attendance_business_mappings():
	"""Use real Attendance PDB codes instead of duplicate demo components."""
	for component_code, description, pdb_code in ATTENDANCE_BUSINESS_MAPPINGS:
		if not frappe.db.exists("Payroll PDB Code", pdb_code):
			continue
		if frappe.db.exists("PRB Payroll Component Mapping", component_code):
			frappe.db.set_value(
				"PRB Payroll Component Mapping",
				component_code,
				{"description": description, "pdb_code": pdb_code, "posting_mode": "Add", "is_active": 1},
				update_modified=False,
			)
		else:
			frappe.get_doc(
				{
					"doctype": "PRB Payroll Component Mapping",
					"component_code": component_code,
					"description": description,
					"pdb_code": pdb_code,
					"posting_mode": "Add",
					"is_active": 1,
				}
			).insert(ignore_permissions=True)


def backfill_overtime_approval_status():
	"""Place legacy recorded rows into the new payroll decision queue."""
	if not frappe.get_meta("PRB Overtime Authorization").has_field("payroll_approval_status"):
		return
	frappe.db.sql(
		"""update `tabPRB Overtime Authorization`
		set payroll_approval_status = case
			when docstatus=1 and authorization_status='Recorded' and approved_hours>0 then 'Pending'
			else 'Awaiting Actuals' end
		where coalesce(payroll_approval_status, '') in ('', 'Awaiting Actuals')"""
	)


def setup():
	print("Karyo PRB payroll posting setup:")
	create_doctype()
	add_posting_fields()
	backfill_overtime_approval_status()
	from karyo.install import samples_enabled

	if samples_enabled():
		seed_demo_mappings()
	ensure_attendance_business_mappings()
	frappe.db.commit()
	print("Done (PRB component mapping and payroll posting metadata created).")
