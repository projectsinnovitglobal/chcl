"""Provisional MBC security controls authorized by ASM-SEC-* assumptions."""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_delegation():
	make_doctype(
		"Karyo Role Delegation",
		autoname="hash",
		fields=[
			f("delegator", "Link", "Delegator", options="User", reqd=1, in_list_view=1),
			f("delegate", "Link", "Delegate", options="User", reqd=1, in_list_view=1),
			f("role", "Link", "Delegated Role", options="Role", reqd=1, in_list_view=1),
			f("effective_from", "Datetime", "Effective From", reqd=1),
			f("effective_to", "Datetime", "Effective To", reqd=1),
			f("reason", "Small Text", "Reason", reqd=1),
			f("approval_reference", "Data", "Approval Reference", reqd=1),
			f("active", "Check", "Active", default="1", read_only=1),
		],
	)
	meta = frappe.get_doc("DocType", "Karyo Role Delegation")
	meta.set(
		"permissions",
		[
			{"role": "System Manager", "read": 1, "write": 1, "create": 1, "delete": 1, "report": 1},
			{"role": "Payroll Approver", "read": 1, "report": 1},
			{"role": "Payroll Auditor", "read": 1, "report": 1, "export": 1},
		],
	)
	meta.save(ignore_permissions=True)


def setup():
	print("Karyo security foundation setup:")
	create_delegation()
	frappe.db.commit()
	print("Done (effective-dated role delegation controls created).")
