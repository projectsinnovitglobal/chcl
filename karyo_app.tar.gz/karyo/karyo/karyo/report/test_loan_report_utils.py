from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.loan_report_utils import add_loan_permission_condition, mask_reference


class TestLoanReportUtils(FrappeTestCase):
	@patch("karyo.karyo.report.loan_report_utils.permitted_loan_names", return_value=("LN-1", "LN-2"))
	def test_adds_parameterized_row_permission_condition(self, _permitted):
		conditions, params = [], frappe._dict()
		self.assertTrue(add_loan_permission_condition(conditions, params))
		self.assertEqual(conditions, ["l.name in %(permitted_loan_names)s"])
		self.assertEqual(params.permitted_loan_names, ("LN-1", "LN-2"))

	@patch("karyo.karyo.report.loan_report_utils.permitted_loan_names", return_value=())
	def test_no_visible_loans_short_circuits(self, _permitted):
		self.assertFalse(add_loan_permission_condition([], frappe._dict()))

	@patch("karyo.karyo.report.loan_report_utils.frappe.get_roles", return_value=["Payroll Auditor"])
	def test_payment_reference_is_masked_for_auditor(self, _roles):
		masked = mask_reference("BANK-123456")
		self.assertTrue(masked.endswith("3456)"))
		self.assertNotIn("BANK-12", masked)

	@patch("karyo.karyo.report.loan_report_utils.frappe.get_roles", return_value=["Loan Officer"])
	def test_payment_reference_remains_visible_to_operational_role(self, _roles):
		self.assertEqual(mask_reference("BANK-123456"), "BANK-123456")
