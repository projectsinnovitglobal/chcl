"""Persisted statutory payroll calculation results (PAY-052/053/060)."""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Payroll Statutory Result",
		autoname="hash",
		title_field="employee",
		fields=[
			f("identity_sb", "Section Break", "Calculation Identity"),
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1, in_standard_filter=1),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1, in_standard_filter=1),
			f("company", "Link", "Company", options="Company", reqd=1, read_only=1),
			f("identity_cb", "Column Break"),
			f("result_type", "Select", "Result Type", options="PAYE\nEmployee Contribution\nEmployer Contribution", reqd=1, in_list_view=1),
			f("rule_reference", "Data", "Rule / Scheme", reqd=1, in_list_view=1),
			f("business_key", "Data", "Business Key", reqd=1, unique=1, read_only=1),
			f("amounts_sb", "Section Break", "Calculated Amounts"),
			f("salary_basis", "Currency", "Salary / Emoluments Basis", read_only=1),
			f("chargeable_income", "Currency", "Chargeable Income", read_only=1),
			f("current_amount", "Currency", "Current Amount", read_only=1, in_list_view=1),
			f("cumulative_amount", "Currency", "Cumulative Amount", read_only=1),
			f("amounts_cb", "Column Break"),
			f("period_index", "Int", "PAYE Period Index", read_only=1),
			f("configuration_version", "Link", "Configuration Version", options="Payroll Configuration Version", read_only=1),
			f("source_declaration", "Link", "Employee Tax Declaration", options="Employee Tax Declaration", read_only=1),
			f("trace_sb", "Section Break", "Immutable Calculation Trace"),
			f("input_snapshot", "Code", "Input Snapshot", options="JSON", read_only=1),
			f("output_snapshot", "Code", "Output Snapshot", options="JSON", read_only=1),
			f("calculation_hash", "Data", "Calculation Hash", read_only=1),
			f("status_cb", "Column Break"),
			f("status", "Select", "Status", options="Calculated\nReviewed\nApplied\nReversed", default="Calculated", reqd=1, in_list_view=1),
			f("salary_slip", "Link", "Salary Slip", options="Salary Slip", read_only=1),
			f("additional_salary", "Link", "Additional Salary", options="Additional Salary", read_only=1),
		],
	)


def setup():
	print("Karyo statutory result setup:")
	create_doctypes()
	frappe.db.commit()
	print("Done (idempotent PAYE and contribution calculation results created).")
