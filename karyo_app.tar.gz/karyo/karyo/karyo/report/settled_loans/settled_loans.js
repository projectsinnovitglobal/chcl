frappe.query_reports["Settled Loans"] = {
	filters: [
		{ fieldname: "from_date", label: __("Settlement From"), fieldtype: "Date" },
		{ fieldname: "to_date", label: __("Settlement To"), fieldtype: "Date", default: frappe.datetime.get_today() },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type" },
		{ fieldname: "payment_type", label: __("Payment Type"), fieldtype: "Select", options: "\nCash\nCheque\nBank" },
		{ fieldname: "lien_status", label: __("Lien Release Status"), fieldtype: "Select", options: "\nNot Applicable\nRelease Pending\nReleased" },
		{ fieldname: "ewf_waive_interest", label: __("EWF Interest Waived"), fieldtype: "Check" },
	],
};
