"""Import the approved legacy PDB catalogue captured in the client spreadsheet."""

import json
from pathlib import Path

import frappe
from frappe.utils import cint


DATA_FILE = Path(__file__).resolve().parent.parent / "payroll" / "data" / "legacy_pdb_catalogue.json"
CONFIG_KEY = "MBC-LEGACY-PDB-2026"
CONFIG_VERSION = "SHEET-1"
EFFECTIVE_FROM = "2026-01-01"

TYPE_DESCRIPTIONS = {
	"ALL": "Allowances and general payments",
	"ARR": "Arrears",
	"BON": "Bonuses",
	"COMP": "Compensation",
	"CONT": "Contributions",
	"DED": "Deductions",
	"FEE": "Fees",
	"GEN": "General deductions",
	"LOAN": "Loan deductions",
	"PAYE": "PAYE deductions",
	"REP": "Repayments",
	"SAL": "Salary payments",
	"TRV": "Travel payments",
}


def _load_catalogue():
	with DATA_FILE.open(encoding="utf-8") as handle:
		payload = json.load(handle)
	columns = payload["columns"]
	return payload, [dict(zip(columns, values, strict=True)) for values in payload["rows"]]


def _classification(row):
	return "Deduction" if row["payment_deduction"].strip().upper() == "D" else "Payment"


def _type_plan(rows):
	classifications = {}
	for row in rows:
		counts = classifications.setdefault(row["pdb_type"], {})
		classification = _classification(row)
		counts[classification] = counts.get(classification, 0) + 1
	primary = {
		pdb_type: max(counts, key=counts.get)
		for pdb_type, counts in classifications.items()
	}
	return classifications, primary


def _target_type(row, classifications, primary):
	base = row["pdb_type"].strip().upper()
	classification = _classification(row)
	if len(classifications[base]) == 1 or classification == primary[base]:
		return base
	return f"{base}-D" if classification == "Deduction" else f"{base}-P"


def _resolved_code(row, occurrence):
	"""Keep the first legacy code and qualify later conflicting duplicates."""
	code = row["pdb_code"].strip().upper()
	if occurrence == 1:
		return code
	suffix = row["pdb_type"].strip().upper()
	return f"{code}-{suffix}" if occurrence == 2 else f"{code}-{suffix}-{occurrence}"


def _ensure_configuration(payload, row_count):
	name = f"{CONFIG_KEY}-{CONFIG_VERSION}"
	if frappe.db.exists("Payroll Configuration Version", name):
		return name, False
	company = (
		frappe.db.get_single_value("Karyo Payroll Settings", "default_company")
		or frappe.db.get_single_value("Global Defaults", "default_company")
	)
	doc = frappe.get_doc({
		"doctype": "Payroll Configuration Version",
		"config_key": CONFIG_KEY,
		"configuration_type": "PDB Catalogue",
		"company": company,
		"version": CONFIG_VERSION,
		"configuration_status": "Draft",
		"effective_from": EFFECTIVE_FROM,
		"source_reference": payload["source_url"],
		"configuration_json": json.dumps({
			"sheet": payload["sheet"],
			"header_row": payload["header_row"],
			"excluded_rows": payload["excluded_rows"],
			"catalogue_rows": row_count,
		}, sort_keys=True),
		"notes": "Imported from the client legacy PDB master. The documented SAMPLE row is excluded.",
	})
	doc.insert(ignore_permissions=True)
	return doc.name, True


def _ensure_type(pdb_type, classification, configuration):
	if frappe.db.exists("Payroll PDB Type", pdb_type):
		return False
	base = pdb_type.removesuffix("-D").removesuffix("-P")
	description = TYPE_DESCRIPTIONS.get(base, base)
	if pdb_type != base:
		description = f"{description} ({classification})"
	frappe.get_doc({
		"doctype": "Payroll PDB Type",
		"pdb_type": pdb_type,
		"description": description,
		"classification": classification,
		"is_active": 1,
		"effective_from": EFFECTIVE_FROM,
		"configuration_version": configuration,
	}).insert(ignore_permissions=True)
	return True


def _component_matches(component, component_type, taxable, prorata):
	return (
		component.type == component_type
		and not cint(component.disabled)
		and bool(component.depends_on_payment_days) == bool(prorata)
		and (component_type != "Earning" or bool(component.is_tax_applicable) == bool(taxable))
	)


def _component_name(row, component_type, taxable, prorata):
	base = (row["description"] or row["pdb_code"]).strip()[:140]
	candidates = [base, f"{base} ({row['pdb_code']})"[:140]]
	for index in range(2, 100):
		candidates.append(f"{base} ({row['pdb_code']}-{index})"[:140])
	for name in candidates:
		if not frappe.db.exists("Salary Component", name):
			return name, None
		component = frappe.get_doc("Salary Component", name)
		mapped = frappe.db.exists("Payroll PDB Code", {"salary_component": name})
		if not mapped and _component_matches(component, component_type, taxable, prorata):
			return name, component
	frappe.throw(f"Could not allocate a unique Salary Component for PDB Code {row['pdb_code']}.")


def _unique_component_abbr(code):
	base = frappe.scrub(code).replace("_", "").upper()[:10] or "PDB"
	abbr = base
	index = 1
	while frappe.db.exists("Salary Component", {"salary_component_abbr": abbr}):
		index += 1
		abbr = f"{base[:max(1, 10 - len(str(index)))]}{index}"[:10]
	return abbr


def _ensure_component(row, classification, taxable, prorata):
	component_type = "Deduction" if classification == "Deduction" else "Earning"
	name, component = _component_name(row, component_type, taxable, prorata)
	if component:
		return name, False
	doc = frappe.get_doc({
		"doctype": "Salary Component",
		"salary_component": name,
		"salary_component_abbr": _unique_component_abbr(row["pdb_code"]),
		"type": component_type,
		"description": row["description"],
		"depends_on_payment_days": prorata,
		"disabled": 0,
	})
	if component_type == "Earning":
		doc.is_tax_applicable = taxable
	company = (
		frappe.db.get_single_value("Karyo Payroll Settings", "default_company")
		or frappe.db.get_single_value("Global Defaults", "default_company")
	)
	if company:
		doc.append("accounts", {"company": company})
	doc.insert(ignore_permissions=True)
	return doc.name, True


def import_legacy_pdb_catalogue(commit=True):
	"""Create missing configuration, types, components and PDB codes, in that order."""
	payload, rows = _load_catalogue()
	classifications, primary = _type_plan(rows)
	configuration, configuration_created = _ensure_configuration(payload, len(rows))
	created_types = []
	for row in rows:
		pdb_type = _target_type(row, classifications, primary)
		if _ensure_type(pdb_type, _classification(row), configuration):
			created_types.append(pdb_type)

	created_components = []
	created_codes = []
	skipped_codes = []
	duplicate_code_aliases = {}
	code_occurrences = {}
	for sequence, row in enumerate(rows, start=1):
		legacy_code = row["pdb_code"].strip().upper()
		code_occurrences[legacy_code] = code_occurrences.get(legacy_code, 0) + 1
		code = _resolved_code(row, code_occurrences[legacy_code])
		if code != legacy_code:
			duplicate_code_aliases[code] = legacy_code
		if frappe.db.exists("Payroll PDB Code", code):
			skipped_codes.append(code)
			continue
		classification = _classification(row)
		taxable = int(row["taxable"].strip().upper() == "Y")
		prorata = int(row["prorata"].strip().upper() == "Y")
		reducing = int(row["reducing_balance"].strip().upper() == "Y")
		resolved_row = {**row, "pdb_code": code}
		component, component_created = _ensure_component(
			resolved_row, classification, taxable, prorata
		)
		if component_created:
			created_components.append(component)
		frappe.get_doc({
			"doctype": "Payroll PDB Code",
			"pdb_code": code,
			"pdb_type": _target_type(row, classifications, primary),
			"description": row["description"].strip(),
			"short_description": row["short_description"].strip(),
			"salary_component": component,
			"transaction_mode": "Both",
			"display_sequence": sequence,
			"taxable": taxable,
			"exempt": 0,
			"prorata": prorata,
			"reducing_balance": reducing,
			"is_active": 1,
			"effective_from": EFFECTIVE_FROM,
			"configuration_version": configuration,
			"source_reference": (
				f"PDB-Tye-Code Sheet1 row {sequence + 4}"
				+ (f"; legacy code {legacy_code}" if code != legacy_code else "")
			),
		}).insert(ignore_permissions=True)
		created_codes.append(code)

	if frappe.db.exists("DocType", "PRB Payroll Component Mapping"):
		from karyo.setup.prb_posting import ensure_attendance_business_mappings

		ensure_attendance_business_mappings()
	if commit:
		frappe.db.commit()
	return {
		"source_rows": len(rows),
		"configuration": configuration,
		"configuration_created": configuration_created,
		"types_created": len(created_types),
		"type_names": sorted(created_types),
		"components_created": len(created_components),
		"codes_created": len(created_codes),
		"codes_skipped_existing": len(skipped_codes),
		"skipped_code_names": sorted(skipped_codes),
		"duplicate_code_aliases": duplicate_code_aliases,
	}
