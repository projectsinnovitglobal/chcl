"""Regression tests for the employee shift-change request lifecycle."""

import unittest
import uuid

import frappe
from frappe.utils import add_days, nowdate

from karyo.desk.overview import approvals, my_hr
from karyo.hr.shift_change import submit_shift_change_request


class TestShiftChange(unittest.TestCase):
	def setUp(self):
		self.previous_user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("shift_change_request")
		suffix = uuid.uuid4().hex[:8]
		self.email = f"shift.change.{suffix}@example.com"
		self.approver_email = f"shift.approver.{suffix}@example.com"
		frappe.get_doc({
			"doctype": "User",
			"email": self.approver_email,
			"first_name": "Shift Approver",
			"enabled": 1,
			"send_welcome_email": 0,
			"roles": [{"role": "HR User"}],
		}).insert(ignore_permissions=True)
		user = frappe.get_doc({
			"doctype": "User",
			"email": self.email,
			"first_name": "Shift",
			"last_name": "Change Test",
			"enabled": 1,
			"send_welcome_email": 0,
			"roles": [{"role": "Employee"}],
		}).insert(ignore_permissions=True)
		self.employee = frappe.get_doc({
			"doctype": "Employee",
			"first_name": "Shift",
			"last_name": "Change Test",
			"gender": "Prefer not to say",
			"date_of_birth": "1990-01-01",
			"date_of_joining": "2026-01-01",
			"company": "MBC",
			"status": "Active",
			"user_id": user.name,
			"default_shift": "Day Shift",
			"shift_request_approver": self.approver_email,
		}).insert(ignore_permissions=True)
		# New employees are intentionally staged as inactive until payroll setup;
		# this fixture activates its isolated record for ESS lifecycle coverage.
		frappe.db.set_value("Employee", self.employee.name, "status", "Active")

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="shift_change_request")
		frappe.set_user(self.previous_user)

	def test_employee_submission_approval_and_status_sync(self):
		start = add_days(nowdate(), 30)
		end = add_days(start, 1)
		frappe.set_user(self.email)
		self.assertEqual(
			frappe.db.get_value("Employee", self.employee.name, "user_id"), self.email
		)
		self.assertEqual(frappe.session.user, self.email)
		self.assertEqual(frappe.db.get_value("Employee", self.employee.name, "status"), "Active")
		self.assertTrue(frappe.get_all("Employee", filters={"user_id": self.email, "status": "Active"}))
		created = submit_shift_change_request(
			requested_shift="Night Shift",
			from_date=start,
			to_date=end,
			reason="Temporary family transport arrangement",
		)
		self.assertEqual(created["status"], "Pending Approval")
		self.assertEqual(created["current_shift"], "Day Shift")
		self.assertEqual(created["duration_days"], 2)
		self.assertEqual(my_hr()["shift_requests"][0]["name"], created["name"])

		for reviewer in (self.approver_email, "Administrator"):
			frappe.set_user(reviewer)
			queue = next(group for group in approvals()["groups"] if group["doctype"] == "Shift Request")
			self.assertTrue(any(row["name"] == created["name"] for row in queue["items"]))

		# Administrators retain the ability to decide even when another approver
		# is assigned; the configured approver remains recorded for audit.
		frappe.set_user("Administrator")
		request = frappe.get_doc("Shift Request", created["name"])
		request.status = "Approved"
		request.submit()
		self.assertEqual(request.karyo_request_status, "Approved")
		self.assertTrue(frappe.db.exists("Shift Assignment", {
			"shift_request": request.name,
			"employee": self.employee.name,
			"shift_type": "Night Shift",
			"docstatus": 1,
		}))

		frappe.set_user(self.email)
		latest = next(row for row in my_hr()["shift_requests"] if row["name"] == request.name)
		self.assertEqual(latest["pill"], "Approved")


if __name__ == "__main__":
	unittest.main()
