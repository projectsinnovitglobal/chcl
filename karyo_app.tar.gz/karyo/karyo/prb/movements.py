"""PRB salary movements: increments, Long Service Increment, promotion, and
acting / responsibility allowances (pure, DB-free, unit-testable).

Implements PRB analysis §5.2, §6 and the INC-*/PROM-*/ACT-* rule catalogue.
Increment "value" is read along the Master Salary scale (INC-02); grade-specific
Volume 2 scales override this once loaded.
"""

from karyo.prb.engine import build_lookups

LSI_EXCLUSION_MAX = 86750  # INC-16: grades with scale max >= this get no LSI

RESPONSIBILITY_QUALIFICATION_FACTORS = {
	"fully_qualified": 1.0,
	"not_fully_qualified": 0.8,
	"no_additional_qualification_required": 1.0,
}


def higher_duty_allowance_breakdown(
	*,
	assignment_type,
	substantive_salary,
	substantive_point,
	higher_initial,
	higher_max,
	days=7,
	accounting_officer=False,
	qualification_status=None,
	revised=None,
	ordered=None,
	precision=2,
):
	"""Return the complete Acting/Responsibility Allowance audit trail.

	The payroll formula and the form preview both use this function so the
	amount shown to HR cannot drift from the amount posted by payroll.
	"""
	if revised is None:
		revised, ordered = build_lookups()
	salary = float(substantive_salary or 0)
	initial = float(higher_initial or 0)
	maximum = float(higher_max or 0)
	salary_difference = max(0.0, initial - salary)
	increment_steps = []
	current_point = substantive_point
	for step in range(1, 4):
		next_point = advance_point(current_point, 1, ordered)
		from_salary = float(revised.get(current_point, salary if step == 1 else 0) or 0)
		to_salary = float(revised.get(next_point, from_salary) or from_salary)
		increment_steps.append(
			{
				"step": step,
				"from_point": current_point,
				"to_point": next_point,
				"from_salary": from_salary,
				"to_salary": to_salary,
				"increment": round(max(0.0, to_salary - from_salary), precision),
			}
		)
		current_point = next_point
	three_increments = round(sum(row["increment"] for row in increment_steps), precision)
	uncapped_base = max(salary_difference, three_increments)
	maximum_available = max(0.0, maximum - salary)
	selected_base = max(0.0, min(uncapped_base, maximum_available))
	period_factor = qualifying_factor(days, accounting_officer)

	allowance_type = str(assignment_type or "Acting").strip().lower()
	qualification_key = str(qualification_status or "").strip().lower().replace(" ", "_")
	if allowance_type == "responsibility":
		if qualification_key not in RESPONSIBILITY_QUALIFICATION_FACTORS:
			raise ValueError("invalid responsibility qualification status")
		qualification_factor = RESPONSIBILITY_QUALIFICATION_FACTORS[qualification_key]
	else:
		qualification_factor = 1.0
		qualification_key = "not_applicable"

	payable = round(selected_base * period_factor * qualification_factor, precision)
	return {
		"assignment_type": "Responsibility" if allowance_type == "responsibility" else "Acting",
		"substantive_salary": round(salary, precision),
		"substantive_point": substantive_point,
		"higher_initial_salary": round(initial, precision),
		"higher_max_salary": round(maximum, precision),
		"salary_difference": round(salary_difference, precision),
		"increment_steps": increment_steps,
		"three_increment_amount": three_increments,
		"base_selected_from": "Salary difference" if salary_difference >= three_increments else "Three increments",
		"uncapped_base_amount": round(uncapped_base, precision),
		"maximum_available": round(maximum_available, precision),
		"selected_base_amount": round(selected_base, precision),
		"resulting_salary": round(salary + selected_base, precision),
		"assignment_days": int(days or 0),
		"qualifying_period_factor": period_factor,
		"qualifying_period_percentage": round(period_factor * 100, 2),
		"qualification_status": qualification_status,
		"qualification_factor": qualification_factor,
		"qualification_percentage": round(qualification_factor * 100, 2),
		"payable_allowance": payable,
	}


def advance_point(point, n, ordered, top=None):
	"""Move `n` salary points up the scale, capped at the scale end or `top`."""
	if point not in ordered:
		return point
	j = min(ordered.index(point) + n, len(ordered) - 1)
	if top is not None and top in ordered:
		j = min(j, ordered.index(top))
	return ordered[j]


def value_of_n_increments(point, n, revised=None, ordered=None, top=None):
	"""Salary value of `n` increments from `point` (INC-02)."""
	if revised is None:
		revised, ordered = build_lookups()
	adv = advance_point(point, n, ordered, top)
	return revised.get(adv, 0) - revised.get(point, 0)


def lsi_entitlement(years_in_grade, years_at_top, scale_max=None):
	"""Long Service Increments earned (INC-14/15/16). Max 2; excluded for high scales."""
	if scale_max is not None and scale_max >= LSI_EXCLUSION_MAX:
		return 0
	if years_in_grade < 20:
		return 0
	if years_at_top >= 4:
		return 2
	if years_at_top >= 2:
		return 1
	return 0


def promote_grade_to_grade(
	current_salary, current_point, target_initial, target_max, revised=None, ordered=None
):
	"""Grade-to-grade promotion (PROM grade-to-grade): the higher of the target
	initial or up-to-three increments at the point reached, capped at target max."""
	if revised is None:
		revised, ordered = build_lookups()
	three = value_of_n_increments(current_point, 3, revised, ordered)
	candidate = max(target_initial, current_salary + three)
	return min(candidate, target_max)


def promote_class_to_class(
	current_salary, current_point, target_initial, target_max, revised=None, ordered=None
):
	"""Class-to-class promotion: target initial if below it, else one increment
	capped at the target max."""
	if revised is None:
		revised, ordered = build_lookups()
	if current_salary < target_initial:
		return target_initial
	one = value_of_n_increments(current_point, 1, revised, ordered)
	return min(current_salary + one, target_max)


def qualifying_factor(days, accounting_officer=False):
	"""Acting qualifying-period factor (ACT-05/06). Normal: >=7 days. Accounting/
	Responsible Officer: 3-<7 days pays 80%; <3 days pays nothing."""
	if accounting_officer:
		if days < 3:
			return 0.0
		return 1.0 if days >= 7 else 0.8
	return 1.0 if days >= 7 else 0.0


def acting_allowance_base(
	substantive_salary, substantive_point, higher_initial, higher_max, revised=None, ordered=None
):
	"""Base acting allowance (ACT-01): max(higher initial - substantive, 3
	increments), capped so total emoluments do not exceed the higher post max."""
	if revised is None:
		revised, ordered = build_lookups()
	return higher_duty_allowance_breakdown(
		assignment_type="Acting",
		substantive_salary=substantive_salary,
		substantive_point=substantive_point,
		higher_initial=higher_initial,
		higher_max=higher_max,
		revised=revised,
		ordered=ordered,
	)["selected_base_amount"]


def acting_allowance(
	substantive_salary,
	substantive_point,
	higher_initial,
	higher_max,
	days=7,
	accounting_officer=False,
	revised=None,
	ordered=None,
	precision=2,
):
	"""Payable acting allowance after the qualifying-period gate."""
	if revised is None:
		revised, ordered = build_lookups()
	return higher_duty_allowance_breakdown(
		assignment_type="Acting",
		substantive_salary=substantive_salary,
		substantive_point=substantive_point,
		higher_initial=higher_initial,
		higher_max=higher_max,
		days=days,
		accounting_officer=accounting_officer,
		revised=revised,
		ordered=ordered,
		precision=precision,
	)["payable_allowance"]


def responsibility_allowance(
	substantive_salary,
	substantive_point,
	higher_initial,
	higher_max,
	fully_qualified=True,
	qualification_status=None,
	days=7,
	accounting_officer=False,
	revised=None,
	ordered=None,
	precision=2,
):
	"""Responsibility allowance with the PRB-determined qualification factor.

	``qualification_status`` is the governed input used by the payroll workflow.
	The older ``fully_qualified`` boolean remains supported for callers that have
	not yet migrated, but the user is never asked to choose an arbitrary percent.
	"""
	if qualification_status:
		status = str(qualification_status).strip().lower().replace(" ", "_")
	else:
		status = "fully_qualified" if fully_qualified else "not_fully_qualified"
	return higher_duty_allowance_breakdown(
		assignment_type="Responsibility",
		substantive_salary=substantive_salary,
		substantive_point=substantive_point,
		higher_initial=higher_initial,
		higher_max=higher_max,
		days=days,
		accounting_officer=accounting_officer,
		qualification_status=status,
		revised=revised,
		ordered=ordered,
		precision=precision,
	)["payable_allowance"]
