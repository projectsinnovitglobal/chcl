"""Fields used to retain the business identifiers supplied by attendance imports."""

from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def apply():
	create_custom_fields(
		{
			"Attendance": [
				{
					"fieldname": "karyo_import_mapping_section",
					"fieldtype": "Section Break",
					"label": "Imported Shift, Roster and Payroll References",
					"insert_after": "out_time",
				},
				{
					"fieldname": "karyo_shift_code",
					"fieldtype": "Data",
					"label": "Shift Code",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "karyo_import_mapping_section",
				},
				{
					"fieldname": "karyo_roster_code",
					"fieldtype": "Data",
					"label": "Roster Code",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "karyo_shift_code",
				},
				{
					"fieldname": "karyo_roster_schedule",
					"fieldtype": "Link",
					"label": "Roster Schedule",
					"options": "Shift Schedule",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "karyo_roster_code",
				},
				{
					"fieldname": "karyo_roster_assignment",
					"fieldtype": "Link",
					"label": "Roster Assignment",
					"options": "Shift Assignment",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "karyo_roster_schedule",
				},
				{
					"fieldname": "karyo_work_pattern",
					"fieldtype": "Link",
					"label": "Work Pattern",
					"options": "Employee Work Pattern",
					"read_only": 1,
					"allow_on_submit": 1,
					"insert_after": "karyo_roster_assignment",
				},
				{
					"fieldname": "karyo_overtime_hours",
					"fieldtype": "Float",
					"label": "Imported Overtime Hours",
					"precision": "4",
					"read_only": 1,
					"allow_on_submit": 1,
					"description": (
						"Source attendance value. Payroll payment remains subject to the overtime "
						"authorisation and approval workflow."
					),
					"insert_after": "karyo_work_pattern",
				},
				{
					"fieldname": "karyo_bonus_amount",
					"fieldtype": "Currency",
					"label": "Imported Bonus Amount",
					"options": "Company:company:default_currency",
					"read_only": 1,
					"allow_on_submit": 1,
					"description": (
						"Source attendance value. The approved attendance-bonus calculation remains "
						"authoritative for payroll."
					),
					"insert_after": "karyo_overtime_hours",
				},
			],
		},
		update=True,
	)
