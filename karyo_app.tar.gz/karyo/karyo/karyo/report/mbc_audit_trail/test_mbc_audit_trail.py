from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.mbc_audit_trail.mbc_audit_trail import execute


class TestMBCAuditTrail(FrappeTestCase):
	@patch("karyo.karyo.report.mbc_audit_trail.mbc_audit_trail._can_read", return_value=True)
	@patch("frappe.get_list")
	@patch("frappe.has_permission")
	def test_change_expansion_filter_and_sensitive_masking(self, has_permission, get_list, _can_read):
		get_list.return_value = [frappe._dict(
			name="VER-1", ref_doctype="Employee", docname="EMP-1", owner="user@example.com",
			creation="2026-09-20 10:00:00",
			data=frappe.as_json({"changed": [["employee_name", "Old", "New"], ["api_key", "a", "b"]]}),
		)]
		columns, rows, _, _, summary = execute({"action": "Changed", "from_date": "2026-09-01", "to_date": "2026-09-30"})
		has_permission.assert_called_once_with("Version", "read", throw=True)
		self.assertEqual(len(rows), 2)
		self.assertEqual(rows[1]["old_value"], "••••••")
		self.assertEqual(summary[0]["value"], 2)
		self.assertIn("old_value", {column["fieldname"] for column in columns})
