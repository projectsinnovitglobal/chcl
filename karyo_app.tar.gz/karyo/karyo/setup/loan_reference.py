"""Karyo Loan reference data: Insurance Rate + Recomputation Parameter, and
disbursement-capture fields on Karyo Loan (loan module close-out).

    bench --site dev.localhost execute karyo.setup.loan_reference.setup
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_reference_doctypes():
	# Insurance rate table (BR-FAR-LMS-REF-008..011).
	make_doctype(
		"Loan Insurance Rate",
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="LIR-.#####", default="LIR-.#####"),
			f(
				"loan_code", "Data", "Loan Code / ALL", reqd=1, default="ALL", in_list_view=1,
				description="Select an exact Loan Type ID (for example PERS), or ALL as the fallback for loan types without a specific band.",
			),
			f("min_age", "Int", "Age From", in_list_view=1),
			f("max_age", "Int", "Age To", in_list_view=1),
			f("cb1", "Column Break"),
			f("min_term_months", "Int", "Term From (Months)", description="First repayment term covered by this band, in months."),
			f("max_term_months", "Int", "Term To (Months)", description="Last repayment term covered by this band, in months. Use a sufficiently high value for an open-ended final band."),
			f("sb1", "Section Break"),
			f(
				"rate", "Float", "Rate (per 10,000)", reqd=1, in_list_view=1,
				description="Enter the raw charge per Rs 10,000 of sum assured (for example 0.1 or 0.2). This is not a percentage.",
			),
			f("effective_date", "Date", "Effective Date", reqd=1, in_list_view=1),
			f("threshold", "Currency", "Insurance Threshold"),
		],
	)
	# Recomputation parameter (BR-FAR-LMS-REF-012/013, RCT-002).
	make_doctype(
		"Loan Recomputation Parameter",
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="RCP-.#####", default="RCP-.#####"),
			f(
				"function",
				"Select",
				"Function",
				options="RECAST\nGlobal Change of Interest\nIndividual Change of Interest",
				default="RECAST",
				reqd=1,
				in_list_view=1,
			),
			f("loan_type", "Link", "Loan Type (blank = all)", options="Loan Type", in_list_view=1),
			f(
				"value",
				"Percent",
				"Value (Cap %)",
				in_list_view=1,
				description="Max % increase over the current instalment on recast. 0 = no cap.",
			),
			f("cb1", "Column Break"),
			f("start_date", "Date", "Start Date"),
			f("end_date", "Date", "End Date"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("sb1", "Section Break"),
			f("remarks", "Small Text", "Remarks"),
		],
	)


def add_disbursement_fields():
	make_doctype(
		"Karyo Loan Disbursement Event",
		autoname="field:idempotency_key",
		naming_rule="By fieldname",
		fields=[
			f("idempotency_key", "Data", "Idempotency Key", reqd=1, unique=1, in_list_view=1),
			f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
			f("event_type", "Select", "Event Type", options="Disbursement\nFailure\nRetry\nReversal", reqd=1, in_list_view=1),
			f("status", "Select", "Status", options="Posted\nFailed\nReversed", reqd=1, in_list_view=1),
			f("amount", "Currency", "Amount", reqd=1),
			f("payment_method", "Data", "Payment Method"),
			f("payment_reference", "Data", "Payment Reference"),
			f("attempt", "Int", "Attempt", default="1"),
			f("original_event", "Link", "Original Event", options="Karyo Loan Disbursement Event"),
			f("payload_checksum", "Data", "Payload SHA-256", read_only=1),
			f("occurred_on", "Datetime", "Occurred On", read_only=1),
			f("event_user", "Link", "Event User", options="User", read_only=1),
			f("reason", "Small Text", "Failure / Reversal Reason"),
		],
	)
	create_custom_fields(
		{
			"Karyo Loan": [
				{
					"fieldname": "disbursed_amount",
					"fieldtype": "Currency",
					"label": "Disbursed Amount",
					"insert_after": "payment_reference",
				},
				{
					"fieldname": "disbursement_remarks",
					"fieldtype": "Small Text",
					"label": "Disbursement Remarks",
					"insert_after": "disbursed_amount",
				},
				{"fieldname": "bank_reference_details", "fieldtype": "Small Text", "label": "Bank / Transfer Details", "depends_on": "eval:doc.payment_method=='Bank Transfer'", "insert_after": "disbursement_remarks"},
				{"fieldname": "disbursement_basis", "fieldtype": "Select", "label": "Disbursement Basis", "options": "Gross Approved Amount\nNet After Registration Fee", "default": "Net After Registration Fee", "insert_after": "disbursed_amount"},
				{"fieldname": "disbursement_status", "fieldtype": "Select", "label": "Disbursement Status", "options": "Pending\nPosted\nFailed\nReversed", "default": "Pending", "read_only": 1, "insert_after": "disbursement_remarks"},
				{"fieldname": "disbursement_event", "fieldtype": "Link", "label": "Disbursement Event", "options": "Karyo Loan Disbursement Event", "read_only": 1, "insert_after": "disbursement_status"},
				{"fieldname": "disbursement_idempotency_key", "fieldtype": "Data", "label": "Disbursement Idempotency Key", "read_only": 1, "insert_after": "disbursement_event"},
				{"fieldname": "disbursement_attempt", "fieldtype": "Int", "label": "Disbursement Attempt", "default": "0", "read_only": 1, "insert_after": "disbursement_idempotency_key"},
			]
		},
		ignore_validate=True,
	)
	print("  + disbursement fields ensured")


def setup():
	print("Karyo Loan reference setup:")
	create_reference_doctypes()
	add_disbursement_fields()
	frappe.db.commit()
	print("Done.")
