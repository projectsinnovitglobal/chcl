from uuid import uuid4
from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.hr.leave_carry_forward import (
	previous_year_leave_preview,
	process_previous_year_leaves,
)


class TestLeaveCarryForward(FrappeTestCase):
	def setUp(self):
		frappe.set_user("Administrator")
		self.company = frappe.db.get_value("Company", {}, "name")
		if not self.company:
			self.skipTest("No Company fixture")
		if not frappe.db.exists("Fiscal Year", "2026-2027"):
			self.skipTest("The 2026-2027 financial year fixture is required")
		suffix = uuid4().hex[:7]
		self.employee = frappe.get_doc({
			"doctype": "Employee",
			"first_name": "Carry",
			"last_name": f"Forward {suffix}",
			"gender": frappe.db.get_value("Gender", {}, "name") or "Male",
			"date_of_birth": "1985-01-01",
			"date_of_joining": "2020-01-01",
			"company": self.company,
			"status": "Active",
		}).insert(ignore_permissions=True, ignore_mandatory=True)
		frappe.db.set_value("Employee", self.employee.name, "status", "Active")
		self.employee.status = "Active"
		self.leave_type = frappe.get_doc({
			"doctype": "Leave Type",
			"leave_type_name": f"Carry Forward {suffix}",
			"karyo_mbc_leave_code": f"CF{suffix}".upper(),
			"karyo_code_description": "Carry-forward processing test",
			"is_carry_forward": 1,
			"maximum_carry_forwarded_leaves": 7,
			"max_leaves_allowed": 30,
			"karyo_bank_type": "Annual Allocation",
			"karyo_annual_entitlement_days": 10,
		}).insert(ignore_permissions=True)
		self.previous = frappe.get_doc({
			"doctype": "Leave Allocation",
			"employee": self.employee.name,
			"leave_type": self.leave_type.name,
			"from_date": "2025-04-01",
			"to_date": "2026-03-31",
			"new_leaves_allocated": 10,
		}).insert(ignore_permissions=True)
		self.previous.submit()

	def _post_encashment_deduction(self, days=3):
		ledger = frappe.get_doc({
			"doctype": "Leave Ledger Entry",
			"employee": self.employee.name,
			"employee_name": self.employee.employee_name,
			"company": self.company,
			"leave_type": self.leave_type.name,
			"transaction_type": "Leave Encashment",
			"transaction_name": f"TEST-ENC-{uuid4().hex[:8]}",
			"leaves": -days,
			"from_date": "2026-03-31",
			"to_date": "2026-03-31",
			"is_carry_forward": 0,
		})
		ledger.flags.ignore_links = True
		ledger.submit()
		frappe.db.set_value(
			"Leave Allocation", self.previous.name, "total_leaves_encashed", days,
		)

	def test_preview_excludes_encashment_and_shows_only_positive_eligible_balance(self):
		self._post_encashment_deduction(3)
		preview = previous_year_leave_preview(self.company, "2026-2027")
		row = next(row for row in preview["rows"] if row["employee"] == self.employee.name)
		self.assertEqual(row["previous_allocated"], 10)
		self.assertEqual(row["encashed"], 3)
		self.assertEqual(row["unused_balance"], 7)
		self.assertEqual(row["carry_forward"], 7)
		self.assertEqual(row["current_entitlement"], 10)
		self.assertEqual(row["current_bank_total"], 17)

	def test_process_creates_native_bank_and_is_idempotent(self):
		self._post_encashment_deduction(3)
		result = process_previous_year_leaves(self.company, "2026-2027")
		self.assertEqual(result["created"], 1)
		allocation = frappe.db.get_value(
			"Leave Allocation",
			{
				"employee": self.employee.name,
				"leave_type": self.leave_type.name,
				"from_date": "2026-04-01",
				"to_date": "2027-03-31",
				"docstatus": 1,
			},
			["name", "carry_forward", "unused_leaves", "new_leaves_allocated", "total_leaves_allocated"],
			as_dict=True,
		)
		self.assertTrue(allocation)
		self.assertEqual(allocation.carry_forward, 1)
		self.assertEqual(allocation.unused_leaves, 7)
		self.assertEqual(allocation.new_leaves_allocated, 10)
		self.assertEqual(allocation.total_leaves_allocated, 17)
		self.assertEqual(
			frappe.db.get_value("Leave Allocation", self.previous.name, "carry_forwarded_leaves_count"),
			7,
		)
		self.assertEqual(
			frappe.db.get_value(
				"Leave Ledger Entry",
				{
					"transaction_name": allocation.name,
					"transaction_type": "Leave Allocation",
					"is_carry_forward": 1,
					"docstatus": 1,
				},
				"leaves",
			),
			7,
		)
		from karyo.hr.self_service import allocation_balances, leave_balances

		employee_bank = next(
			row for row in leave_balances(self.employee.name, "2026-09-28")
			if row["leave_type"] == self.leave_type.name
		)
		admin_bank = next(
			row for row in allocation_balances(self.employee.name)["balances"]
			if row["leave_type"] == self.leave_type.name
		)
		self.assertEqual(employee_bank["confirmed_remaining"], 17)
		self.assertEqual(admin_bank["confirmed_remaining"], 17)
		second_preview = previous_year_leave_preview(self.company, "2026-2027")
		self.assertNotIn(self.employee.name, {row["employee"] for row in second_preview["rows"]})
		second = process_previous_year_leaves(self.company, "2026-2027")
		self.assertEqual(second["created"], 0)
		self.assertEqual(second["updated"], 0)

	def test_process_adds_carry_forward_to_an_existing_current_year_bank(self):
		self._post_encashment_deduction(4)
		current = frappe.get_doc({
			"doctype": "Leave Allocation",
			"employee": self.employee.name,
			"leave_type": self.leave_type.name,
			"from_date": "2026-04-01",
			"to_date": "2027-03-31",
			"new_leaves_allocated": 10,
		}).insert(ignore_permissions=True)
		current.submit()
		result = process_previous_year_leaves(self.company, "2026-2027")
		self.assertEqual(result["updated"], 1)
		current.reload()
		self.assertEqual(current.carry_forward, 1)
		self.assertEqual(current.unused_leaves, 6)
		self.assertEqual(current.total_leaves_allocated, 16)
		self.assertEqual(
			frappe.db.count("Leave Allocation", {
				"employee": self.employee.name,
				"leave_type": self.leave_type.name,
				"from_date": "2026-04-01",
				"to_date": "2027-03-31",
				"docstatus": 1,
			}),
			1,
		)

	def test_future_year_employee_processing_stages_without_early_encashment(self):
		from karyo.setup.leave import ensure_2027_2028_fiscal_year

		ensure_2027_2028_fiscal_year()
		frappe.db.set_value("Leave Type", self.leave_type.name, "allow_encashment", 1)
		# The employee has no new-year entitlement, but still owns an unused
		# balance that must become a carry-only future allocation.
		frappe.db.set_value("Employee", self.employee.name, "contract_end_date", "2027-03-31")
		source = frappe.get_doc({
			"doctype": "Leave Allocation",
			"employee": self.employee.name,
			"leave_type": self.leave_type.name,
			"from_date": "2026-04-01",
			"to_date": "2027-03-31",
			"new_leaves_allocated": 10,
			"carry_forward": 1,
		}).insert(ignore_permissions=True)
		source.submit()

		with patch("karyo.hr.leave_carry_forward.nowdate", return_value="2026-09-29"):
			bulk = previous_year_leave_preview(self.company, "2027-2028")
			self.assertFalse(bulk["can_process"])
			preview = previous_year_leave_preview(
				self.company, "2027-2028", self.employee.name,
			)
			self.assertTrue(preview["future_preprocessing"])
			self.assertTrue(preview["can_process"])
			row = next(row for row in preview["rows"] if row["employee"] == self.employee.name)
			self.assertEqual(row["carry_forward"], 7)
			result = process_previous_year_leaves(
				self.company, "2027-2028", self.employee.name,
			)

		self.assertEqual(result["created"], 1)
		target = frappe.db.get_value(
			"Leave Allocation",
			{
				"employee": self.employee.name,
				"leave_type": self.leave_type.name,
				"from_date": "2027-04-01",
				"to_date": "2028-03-31",
				"docstatus": 1,
			},
			["name", "carry_forward", "unused_leaves", "new_leaves_allocated", "total_leaves_allocated", "_user_tags"],
			as_dict=True,
		)
		self.assertEqual(target.carry_forward, 1)
		self.assertEqual(target.unused_leaves, 7)
		self.assertEqual(target.new_leaves_allocated, 0)
		self.assertEqual(target.total_leaves_allocated, 7)
		self.assertIn("Carry Forwarded Leaves", target._user_tags)
		self.assertEqual(
			frappe.db.get_value(
				"Leave Ledger Entry",
				{"transaction_name": target.name, "docstatus": 1, "is_carry_forward": 1},
				"leaves",
			),
			7,
		)
		from karyo.hr.self_service import leave_balances

		dashboard = next(
			row for row in leave_balances(self.employee.name, "2026-09-29")
			if row.get("allocation") == target.name
		)
		self.assertEqual(dashboard["tag"], "Carry Forward")
		self.assertEqual(dashboard["carry_forward_days"], 7)
		source.reload()
		self.assertFalse(source.expired)

		from karyo.hr.leave_encashment import encashable_balances

		available = encashable_balances(self.employee.name)
		self.assertNotIn(target.name, {row["leave_allocation"] for row in available})
