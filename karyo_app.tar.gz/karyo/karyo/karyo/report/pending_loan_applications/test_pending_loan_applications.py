from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.pending_loan_applications.pending_loan_applications import _configured_pending_states, execute


class TestPendingLoanApplications(FrappeTestCase):
	@patch("frappe.get_doc")
	@patch("frappe.db.get_value", return_value="Loan Workflow")
	def test_states_and_next_actions_come_from_active_workflow(self, _get_value, get_doc):
		get_doc.return_value = frappe._dict(
			states=[frappe._dict(state="Draft"), frappe._dict(state="Approved"), frappe._dict(state="Rejected"), frappe._dict(state="Active Loan")],
			transitions=[frappe._dict(state="Draft", action="Submit"), frappe._dict(state="Approved", action="Disburse")],
		)
		states, actions = _configured_pending_states()
		self.assertEqual(states, ["Draft", "Approved"])
		self.assertEqual(actions["Approved"], ["Disburse"])

	@patch("frappe.has_permission")
	@patch("frappe.get_all", return_value=[frappe._dict(name="EMP-1", department="Finance", branch="HQ")])
	@patch("frappe.get_list", return_value=[frappe._dict(name="LN-1", employee="EMP-1", workflow_state="Draft",
		date_applied="2026-09-01", creation="2026-09-01")])
	@patch("karyo.karyo.report.pending_loan_applications.pending_loan_applications.today", return_value="2026-09-10")
	@patch("karyo.karyo.report.pending_loan_applications.pending_loan_applications._configured_pending_states",
		return_value=(["Draft"], {"Draft": ["Print Application"]}))
	def test_age_owner_action_and_filters(self, _states, _today, get_list, _get_all, has_permission):
		_columns, rows, _, _, summary = execute({"department": "Finance", "minimum_age_days": 5})
		has_permission.assert_called_once_with("Karyo Loan", "read", throw=True)
		self.assertEqual(rows[0].age_days, 9)
		self.assertEqual(rows[0].next_action, "Print Application")
		self.assertEqual(summary[0]["value"], 1)
		self.assertEqual(get_list.call_args.kwargs["filters"]["workflow_state"], ["in", ["Draft"]])
