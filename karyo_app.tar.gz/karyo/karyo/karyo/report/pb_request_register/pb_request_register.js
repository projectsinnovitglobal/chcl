frappe.query_reports["PB Request Register"] = {
	filters: [
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
		{fieldname: "workflow_state", label: __("Status"), fieldtype: "Link", options: "Workflow State"},
		{fieldname: "pay_period", label: __("Pay Period"), fieldtype: "Data"},
		{fieldname: "from_date", label: __("Posting Date From"), fieldtype: "Date"},
		{fieldname: "to_date", label: __("Posting Date To"), fieldtype: "Date"},
	],
};
