import unittest
from datetime import datetime
from unittest.mock import MagicMock, patch

import frappe

from karyo.hr.attendance_rules import display_status, mark_completed_shifts_absent


class TestAttendanceRules(unittest.TestCase):
	def test_present_requires_a_real_clock_in_for_timing_status(self):
		self.assertEqual(display_status("Present"), "Awaiting Clock In")
		self.assertEqual(display_status("Present", "Late"), "Late")
		self.assertEqual(display_status("Present", late_entry=True), "Awaiting Clock In")
		self.assertEqual(display_status("Absent", "On-time"), "Absent")

	@patch("karyo.hr.attendance_rules._approved_leave", return_value=None)
	@patch("karyo.hr.attendance_rules._is_holiday", return_value=False)
	@patch("karyo.hr.attendance_rules._employee_duty")
	@patch("karyo.hr.attendance_rules.frappe.get_all")
	def test_absent_is_created_only_after_shift_end(self, get_all, duty, holiday, leave):
		get_all.return_value = [frappe._dict(name="EMP-1", employee_name="One", company="MBC",
			date_of_joining="2026-09-01", relieving_date=None, default_shift="Day", holiday_list=None,
			karyo_employee_group=None)]
		duty.return_value = frappe._dict(shift_type="Day", start_time="08:00:00", end_time="16:00:00")
		doc = MagicMock(name="ATT-1")
		doc.name = "ATT-1"
		doc.insert.return_value = doc
		with patch.object(frappe.db, "exists", return_value=None), patch.object(frappe.db, "sql", return_value=[]), patch.object(frappe, "get_doc", return_value=doc):
			result = mark_completed_shifts_absent(datetime(2026, 9, 19, 17, 0))
		self.assertEqual(len(result["created"]), 2)
		self.assertEqual(doc.submit.call_count, 2)

	@patch("karyo.hr.attendance_rules._employee_duty")
	@patch("karyo.hr.attendance_rules.frappe.get_all")
	def test_current_shift_is_not_absent_before_end(self, get_all, duty):
		get_all.return_value = [frappe._dict(name="EMP-1", employee_name="One", company="MBC",
			date_of_joining="2026-09-01", relieving_date=None, default_shift="Day", holiday_list=None,
			karyo_employee_group=None)]
		duty.return_value = frappe._dict(shift_type="Day", start_time="08:00:00", end_time="16:00:00")
		with patch.object(frappe.db, "exists", return_value=None), patch.object(frappe.db, "sql", return_value=[]), patch.object(frappe, "get_doc") as get_doc:
			mark_completed_shifts_absent(datetime(2026, 9, 19, 15, 0))
		# Yesterday is complete; today's still-open shift is never inserted.
		self.assertEqual(get_doc.call_count, 1)
