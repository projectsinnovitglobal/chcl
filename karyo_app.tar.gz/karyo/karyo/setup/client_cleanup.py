"""One-time, repeatable preparation of a client-facing SIL test site."""

import frappe

SIL_COMPANY = "SIL"
LEGACY_COMPANY = "Mauritius Agro Industries Ltd"


def _delete_company_data(company):
	"""Remove records owned by an unrelated company, including their child rows."""
	links = frappe.get_all(
		"DocField",
		filters={"fieldtype": "Link", "options": "Company"},
		fields=["parent", "fieldname"],
	)
	child_tables = set(frappe.get_all("DocType", filters={"istable": 1}, pluck="name"))

	for link in links:
		doctype = link.parent
		if doctype == "Company" or doctype in child_tables or not frappe.db.table_exists(doctype):
			continue
		names = frappe.get_all(doctype, filters={link.fieldname: company}, pluck="name")
		if not names:
			continue
		for child in frappe.get_all(
			"DocField", filters={"parent": doctype, "fieldtype": "Table"}, pluck="options"
		):
			if frappe.db.table_exists(child):
				frappe.db.delete(child, {"parent": ["in", names]})
		frappe.db.delete("Comment", {"reference_doctype": doctype, "reference_name": ["in", names]})
		frappe.db.delete("Version", {"ref_doctype": doctype, "docname": ["in", names]})
		frappe.db.delete(doctype, {"name": ["in", names]})

	# Link fields in child tables are cleaned separately.
	for link in links:
		if link.parent in child_tables and frappe.db.table_exists(link.parent):
			frappe.db.delete(link.parent, {link.fieldname: company})

	frappe.db.delete("DefaultValue", {"defkey": "company", "defvalue": company})
	frappe.db.delete("Company", {"name": company})


def _rename_demo_users():
	for old in frappe.get_all("User", filters={"name": ["like", "%@mai.mu"]}, pluck="name"):
		new = old.replace("@mai.mu", "@sil.mu")
		if frappe.db.exists("User", new):
			continue
		frappe.rename_doc("User", old, new, force=True)


def _delete_test_users():
	for user in frappe.get_all("User", filters={"name": ["like", "test%@example.com"]}, pluck="name"):
		frappe.delete_doc("User", user, force=True, ignore_permissions=True)


def run():
	"""Consolidate the site around SIL and remove unrelated test-company data."""
	if frappe.db.exists("Company", LEGACY_COMPANY) and not frappe.db.exists("Company", SIL_COMPANY):
		frappe.rename_doc("Company", LEGACY_COMPANY, SIL_COMPANY, force=True)
		frappe.db.set_value("Company", SIL_COMPANY, {"company_name": SIL_COMPANY, "abbr": "SIL"})

	for company in frappe.get_all("Company", filters={"name": ["!=", SIL_COMPANY]}, pluck="name"):
		_delete_company_data(company)

	frappe.db.set_default("company", SIL_COMPANY)
	frappe.db.set_single_value("Global Defaults", "default_company", SIL_COMPANY)
	_rename_demo_users()
	_delete_test_users()
	frappe.db.commit()
	frappe.clear_cache()
	return {
		"company": SIL_COMPANY,
		"companies_remaining": frappe.get_all("Company", pluck="name"),
		"employees_remaining": frappe.db.count("Employee"),
	}
