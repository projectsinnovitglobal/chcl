"""Regression checks for employee servicing boundaries (no financial posting)."""
import unittest
from unittest.mock import patch

import frappe
from frappe.utils import nowdate
from karyo.loan import self_service, agreements


class TestLoanServiceRequests(unittest.TestCase):
    def setUp(self):
        self.loan = frappe._dict(name='TEST-LOAN', employee='TEST-EMPLOYEE', company='TEST',
                                 status='Active', docstatus=1, outstanding_capital=1000)
        self.values = frappe._dict(request_type='Advance Payment', effective_date=nowdate(),
                                  amount=100, new_period=12, reason='Test request',
                                  payment_type='Bank Transfer', payment_reference='PAYMENT',
                                  evidence='/private/files/test.pdf')
        self.patches = [patch.object(self_service, '_pending', return_value=False),
                        patch.object(self_service, '_recast_setup_reason', return_value=''),
                        patch.object(self_service, 'validate_open_period')]
        for item in self.patches:
            item.start()
            self.addCleanup(item.stop)

    def test_inactive_loan_cannot_be_serviced(self):
        self.loan.status = 'Settled'
        with self.assertRaises(frappe.ValidationError):
            self_service._inputs(self.loan, self.values)

    def test_duplicate_pending_request_is_rejected(self):
        with patch.object(self_service, '_pending', return_value=True):
            with self.assertRaises(frappe.ValidationError):
                self_service._inputs(self.loan, self.values)

    def test_advance_cannot_equal_or_exceed_capital(self):
        for amount in [0, -1, 1000, 1001]:
            with self.subTest(amount=amount), self.assertRaises(frappe.ValidationError):
                self_service._inputs(self.loan, {**self.values, 'amount': amount})

    def test_period_must_be_positive_whole_months(self):
        for months in [0, -1, 1.5]:
            with self.subTest(months=months), self.assertRaises(frappe.ValidationError):
                self_service._inputs(self.loan, {**self.values, 'new_period': months})

    def test_existing_other_request_evidence_cannot_be_reused(self):
        evidence = frappe._dict(name='OTHER-FILE', owner=frappe.session.user, is_private=1,
                                attached_to_doctype='Loan Service Request', attached_to_name='OTHER-REQUEST')
        with patch('frappe.get_all', return_value=[evidence]):
            with self.assertRaises(frappe.PermissionError):
                self_service._inputs(self.loan, {**self.values, 'name': 'OTHER-REQUEST'})

    def test_client_cannot_override_recast_direction_or_cap(self):
        with patch('frappe.get_doc', side_effect=lambda values: values):
            transaction = self_service._transaction(self.loan, frappe._dict(
                **self.values, direction='Refund', override_cap=1, cap_pct=1000))
        self.assertEqual(transaction['direction'], 'Payment')
        self.assertNotIn('override_cap', transaction)
        self.assertNotIn('cap_pct', transaction)

    def test_bank_transfer_maps_to_settlement_payment_enum(self):
        with patch('frappe.get_doc', side_effect=lambda values: values):
            transaction = self_service._transaction(self.loan, frappe._dict(
                {**self.values, 'request_type': 'Loan Close', 'amount': 1050}))
        self.assertEqual(transaction['payment_type'], 'Bank')
        self.assertEqual(transaction['amount_received'], 1050)

    def test_approval_reuses_identical_submitted_recomputation(self):
        request = frappe._dict(
            request_type='Advance Payment', loan='TEST-LOAN', effective_date='2026-09-20',
            amount=8000, new_period=6,
        )
        with patch('frappe.db.get_value', return_value='RCST-EXISTING') as get_value:
            self.assertEqual(
                self_service._existing_approved_transaction(request),
                'RCST-EXISTING',
            )
        filters = get_value.call_args.args[1]
        self.assertEqual(filters['direction'], 'Payment')
        self.assertEqual(filters['advance_payment'], 8000)
        self.assertEqual(filters['new_period'], 6)
        self.assertEqual(filters['docstatus'], 1)

    def test_employee_summary_totals_only_submitted_advance_payments(self):
        with patch('frappe.get_all', return_value=[frappe._dict(total=8000)]) as get_all:
            self.assertEqual(self_service._advance_payment_total('TEST-LOAN'), 8000)
        filters = get_all.call_args.kwargs['filters']
        self.assertEqual(filters, {
            'loan': 'TEST-LOAN',
            'docstatus': 1,
            'direction': 'Payment',
            'advance_payment': ('>', 0),
        })

    def test_employee_schedule_is_chronological(self):
        doc = frappe._dict(schedule=[
            frappe._dict(due_date='2027-02-20', month=6, idx=0, is_current=1, total=1),
            frappe._dict(due_date='2026-12-20', month=4, idx=0, is_current=1, total=1),
            frappe._dict(due_date='2026-09-15', month=1, idx=1, is_current=0, total=1),
            frappe._dict(due_date='2026-09-20', month=1, idx=0, is_current=1, total=1),
        ])
        rows = self_service._current_schedule(doc)
        self.assertEqual([str(row['due_date']) for row in rows], ['2026-09-20', '2026-12-20', '2027-02-20'])

    def test_issued_agreement_cannot_be_edited_through_loan_save(self):
        doc = frappe._dict(issued_agreement_html='changed')
        doc.get_doc_before_save = lambda: frappe._dict(issued_agreement_html='approved terms')
        with self.assertRaises(frappe.ValidationError):
            agreements.protect_issued_fields(doc)

    def test_employee_can_sign_reviewed_agreement_before_approval(self):
        doc = frappe._dict(
            doctype='Karyo Loan', name='TEST-LOAN', employee='TEST-EMPLOYEE',
            employee_name='Test Employee', workflow_state='Approval Pending',
            is_approval_required=0, docstatus=0, approved_amount=1000,
            period_months=12, agreement_attachment='/private/files/agreement.pdf',
        )
        doc.add_comment = lambda *args, **kwargs: None
        doc.notify_update = lambda: None
        with patch.object(agreements, '_loan', return_value=doc), \
                patch.object(agreements, '_employee_user', return_value=frappe.session.user), \
                patch('frappe.db.set_value') as set_value:
            result = agreements.sign('TEST-LOAN', 'Test Employee', accepted=1)
        self.assertTrue(result['signed_on'])
        self.assertTrue(result['signed_by'])
        self.assertTrue(result['requires_signature'] is False)
        self.assertIn('agreement_signature_hash', set_value.call_args.args[2])

    def test_agreement_stage_precedes_approval(self):
        keys = [key for key, _label in self_service.PROCESS_STAGES]
        self.assertLess(keys.index('agreement'), keys.index('approved'))

    def test_employee_process_maps_application_through_settlement(self):
        expected = {
            'Approval Pending': ('agreement', 29), 'Approved': ('disbursed', 57),
            'Disbursed': ('repayment', 71), 'Active Loan': ('repayment', 71),
            'Settled': ('settled', 100),
        }
        for state, (current, progress) in expected.items():
            with self.subTest(state=state):
                process = self_service._process(frappe._dict(workflow_state=state, status='Settled' if state == 'Settled' else 'Draft'))
                self.assertEqual(next(step['key'] for step in process['steps'] if step['current']), current)
                self.assertEqual(process['progress'], progress)
