"""Operation-code aggregation with an auditable component trace."""

from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP, Decimal

import frappe
from frappe import _
from frappe.utils import getdate

from karyo.payroll.configuration import assert_production_eligible


def calculate_operation(operation_code, amounts, on_date=None, company=None):
	"""Aggregate PDB amounts in configured sequence and return the calculation trace."""
	on_date = getdate(on_date)
	doc = frappe.get_doc("Payroll Operation Code", operation_code)
	if not doc.is_active:
		frappe.throw(_("Payroll Operation Code {0} is inactive.").format(operation_code))
	if getdate(doc.effective_from) > on_date or (
		doc.effective_to and getdate(doc.effective_to) < on_date
	):
		frappe.throw(_("Payroll Operation Code {0} is not effective on {1}.").format(operation_code, on_date))
	if company and doc.company and doc.company != company:
		frappe.throw(_("Payroll Operation Code {0} belongs to a different company.").format(operation_code))

	mode = frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo"
	if mode == "Production":
		assert_production_eligible(doc.configuration_version)

	total = Decimal("0")
	trace = []
	for row in sorted(doc.items, key=lambda item: item.sequence):
		item_from = getdate(row.effective_from or doc.effective_from)
		item_to = getdate(row.effective_to or doc.effective_to) if (row.effective_to or doc.effective_to) else None
		if item_from > on_date or (item_to and item_to < on_date):
			continue
		amount = Decimal(str(amounts.get(row.pdb_code, 0) or 0))
		percentage = Decimal(str(row.inclusion_percentage if row.inclusion_percentage is not None else 100))
		weighted_amount = amount * percentage / Decimal("100")
		signed = -weighted_amount if row.aggregation_sign == "Subtract" else weighted_amount
		total += signed
		trace.append(
			{
				"sequence": row.sequence,
				"pdb_code": row.pdb_code,
				"sign": row.aggregation_sign,
				"amount": float(amount),
				"inclusion_percentage": float(percentage),
				"weighted_amount": float(weighted_amount),
				"signed_amount": float(signed),
			}
		)

	settings = frappe.get_cached_doc("Karyo Payroll Settings")
	precision = int(settings.rounding_precision or 2)
	rounding = ROUND_HALF_EVEN if settings.rounding_method == "Round Half to Even" else ROUND_HALF_UP
	total = total.quantize(Decimal("1").scaleb(-precision), rounding=rounding)
	return {"operation_code": doc.operation_code, "total": float(total), "trace": trace}
