"""Validated CSV import services for payroll contribution and operation references."""

import csv
import io
from collections import OrderedDict
from decimal import Decimal, InvalidOperation

import frappe
from frappe import _

CONTRIBUTION_REQUIRED = {
	"scheme_code",
	"description",
	"calculation_mode",
	"basis_operation_code",
	"employee_pdb_code",
	"employer_salary_component",
	"effective_from",
	"lower_salary",
	"employee_value",
	"employer_value",
}

OPERATION_REQUIRED = {
	"operation_code",
	"description",
	"operation_category",
	"effective_from",
	"pdb_code",
	"sequence",
	"aggregation_sign",
}


def _rows(csv_content):
	reader = csv.DictReader(io.StringIO(csv_content or ""))
	return reader.fieldnames or [], [
		{key: (value or "").strip() for key, value in row.items()} for row in reader
	]


def _decimal(value, fieldname, row_number, errors, *, required=False):
	if value == "" and not required:
		return None
	try:
		return Decimal(value)
	except (InvalidOperation, TypeError):
		errors.append(f"Row {row_number}: {fieldname} must be numeric.")
		return None


def preview_contribution_csv(csv_content):
	"""Validate and group a contribution CSV without changing database state."""
	fields, rows = _rows(csv_content)
	errors = []
	missing = sorted(CONTRIBUTION_REQUIRED - set(fields))
	if missing:
		return {"valid": False, "errors": [f"Missing columns: {', '.join(missing)}"], "schemes": []}
	groups = OrderedDict()
	for index, row in enumerate(rows, 2):
		code = row["scheme_code"].upper()
		if not code:
			errors.append(f"Row {index}: scheme_code is required.")
			continue
		lower = _decimal(row["lower_salary"], "lower_salary", index, errors, required=True)
		upper = _decimal(row.get("upper_salary"), "upper_salary", index, errors)
		employee = _decimal(row["employee_value"], "employee_value", index, errors, required=True)
		employer = _decimal(row["employer_value"], "employer_value", index, errors, required=True)
		open_ended = row.get("is_open_ended", "0") in {"1", "true", "True", "Yes", "yes"}
		if lower is not None and lower < 0:
			errors.append(f"Row {index}: lower_salary cannot be negative.")
		if upper is not None and lower is not None and upper < lower:
			errors.append(f"Row {index}: upper_salary cannot be below lower_salary.")
		if (employee is not None and employee < 0) or (employer is not None and employer < 0):
			errors.append(f"Row {index}: contribution values cannot be negative.")
		header = {
			key: row.get(key, "")
			for key in (
				"scheme_code",
				"version",
				"description",
				"company",
				"calculation_mode",
				"basis_operation_code",
				"employee_pdb_code",
				"employer_salary_component",
				"employee_ceiling",
				"employer_ceiling",
				"rounding_precision",
				"rounding_method",
				"is_active",
				"allow_band_gaps",
				"effective_from",
				"effective_to",
				"source_reference",
			)
		}
		header["scheme_code"] = code
		group = groups.setdefault(code, {"header": header, "bands": [], "dependencies": []})
		if group["header"] != header:
			errors.append(f"Row {index}: scheme header values conflict with earlier {code} rows.")
		group["bands"].append(
			{
				"lower_salary": lower,
				"upper_salary": upper,
				"is_open_ended": open_ended,
				"employee_value": employee,
				"employer_value": employer,
				"row_number": index,
			}
		)
	for code, group in groups.items():
		bands = sorted(group["bands"], key=lambda band: band["lower_salary"] or Decimal("0"))
		for index, band in enumerate(bands):
			if band["is_open_ended"] and index != len(bands) - 1:
				errors.append(f"{code}: only the final band may be open-ended.")
			if index:
				previous = bands[index - 1]
				if previous["is_open_ended"] or band["lower_salary"] <= previous["upper_salary"]:
					errors.append(f"{code}: salary bands overlap at row {band['row_number']}.")
		if not bands[-1]["is_open_ended"]:
			errors.append(f"{code}: final salary band must be open-ended.")
		group["bands"] = bands
		header = group["header"]
		dependencies = [
			("Payroll Operation Code", header["basis_operation_code"]),
			("Payroll PDB Code", header["employee_pdb_code"]),
			("Salary Component", header["employer_salary_component"]),
		]
		group["dependencies"] = [
			f"{doctype}: {name}" for doctype, name in dependencies if name and not frappe.db.exists(doctype, name)
		]
	return {
		"valid": not errors,
		"errors": errors,
		"schemes": [
			{
				"scheme_code": code,
				"band_count": len(group["bands"]),
				"missing_dependencies": group["dependencies"],
			}
			for code, group in groups.items()
		],
		"_groups": groups,
	}


def import_contribution_csv(csv_content, configuration_version):
	"""Create draft contribution scheme versions after full preview validation."""
	preview = preview_contribution_csv(csv_content)
	if not preview["valid"]:
		frappe.throw("\n".join(preview["errors"]), title=_("Contribution Import Invalid"))
	missing = [item for scheme in preview["schemes"] for item in scheme["missing_dependencies"]]
	if missing:
		frappe.throw(
			_("Create or map these references before importing:\n{0}").format("\n".join(sorted(set(missing)))),
			title=_("Contribution Mapping Missing"),
		)
	configuration = frappe.get_doc("Payroll Configuration Version", configuration_version)
	if configuration.configuration_type != "Contribution":
		frappe.throw(_("Configuration Version must be a Contribution configuration."))
	created = []
	for code, group in preview["_groups"].items():
		header = group["header"]
		version = header["version"] or configuration.version
		name = f"{code}-{version}"
		if frappe.db.exists("Payroll Contribution Scheme", name):
			created.append(name)
			continue
		values = {
			"doctype": "Payroll Contribution Scheme",
			**header,
			"version": version,
			"configuration_version": configuration.name,
			"rounding_precision": int(header["rounding_precision"] or 2),
			"rounding_method": header["rounding_method"] or "Round Half Up",
			"is_active": int(header["is_active"] or 1),
			"allow_band_gaps": int(header["allow_band_gaps"] or 0),
			"bands": [
				{
					key: float(value) if isinstance(value, Decimal) else value
					for key, value in band.items()
					if key != "row_number"
				}
				for band in group["bands"]
			],
		}
		created.append(frappe.get_doc(values).insert(ignore_permissions=True).name)
	frappe.db.commit()
	return {"created": created, "count": len(created)}


def preview_operation_code_csv(csv_content):
	"""Validate operation-code rows and report unresolved PDB mappings."""
	fields, rows = _rows(csv_content)
	missing = sorted(OPERATION_REQUIRED - set(fields))
	if missing:
		return {"valid": False, "errors": [f"Missing columns: {', '.join(missing)}"], "operations": []}
	errors = []
	groups = OrderedDict()
	for index, row in enumerate(rows, 2):
		code = row["operation_code"].upper()
		if not code or not row["pdb_code"]:
			errors.append(f"Row {index}: operation_code and pdb_code are required.")
			continue
		try:
			sequence = int(row["sequence"])
		except ValueError:
			errors.append(f"Row {index}: sequence must be an integer.")
			continue
		if row["aggregation_sign"] not in {"Add", "Subtract"}:
			errors.append(f"Row {index}: aggregation_sign must be Add or Subtract.")
		group = groups.setdefault(code, {"sequences": set(), "pdb_codes": set(), "missing": []})
		if sequence in group["sequences"] or row["pdb_code"] in group["pdb_codes"]:
			errors.append(f"Row {index}: duplicate sequence or PDB mapping for {code}.")
		group["sequences"].add(sequence)
		group["pdb_codes"].add(row["pdb_code"])
		if not frappe.db.exists("Payroll PDB Code", row["pdb_code"]):
			group["missing"].append(row["pdb_code"])
	return {
		"valid": not errors,
		"errors": errors,
		"operations": [
			{"operation_code": code, "pdb_count": len(group["pdb_codes"]), "missing_pdb_codes": group["missing"]}
			for code, group in groups.items()
		],
	}
