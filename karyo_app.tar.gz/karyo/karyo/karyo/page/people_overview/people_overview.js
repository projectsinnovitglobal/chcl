frappe.pages["people-overview"].on_page_load = function (wrapper) {
	karyo.overview.render(wrapper, "people-overview", {
		title: __("People Analytics"),
		subtitle: __("Headcount, workforce composition and employee trends"),
		needs_you: false,
		cycle: false,
	});
};
