"""Payroll roles, workflow, and sensitive-field permission levels (PAY-023)."""

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.permissions import add_permission, update_permission_property


ROLES = [
	"Registry Officer",
	"Payroll Input",
	"Payroll Processor",
	"Payroll Reviewer",
	"Payroll Approver",
	"Payroll Finance",
	"Payroll Auditor",
	"Passage Benefit Officer",
	"Loan Officer",
	"Loan Committee",
	"Karyo IT Support",
]

WORKFLOW_STATES = [
	("Draft", "0", "Payroll Input"),
	("Input Open", "0", "Payroll Input"),
	("Processing", "0", "Payroll Processor"),
	("Review", "0", "Payroll Reviewer"),
	("Approved", "1", "Payroll Approver"),
	("Closed", "1", "Payroll Finance"),
	("Reopened", "1", "Payroll Approver"),
	("Cancelled", "2", "Payroll Approver"),
]

WORKFLOW_TRANSITIONS = [
	("Draft", "Open Inputs", "Input Open", "Payroll Input"),
	("Input Open", "Start Processing", "Processing", "Payroll Processor"),
	("Processing", "Return to Inputs", "Input Open", "Payroll Processor"),
	("Processing", "Send for Review", "Review", "Payroll Reviewer"),
	("Review", "Return for Processing", "Processing", "Payroll Reviewer"),
	("Review", "Approve Payroll", "Approved", "Payroll Approver"),
	("Approved", "Close Payroll", "Closed", "Payroll Finance"),
	("Closed", "Reopen Payroll", "Reopened", "Payroll Approver"),
	("Reopened", "Close Payroll", "Closed", "Payroll Finance"),
]

PERMISSIONS = {
	"Payroll Cycle": {
		"Payroll Input": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Processor": {"read": 1, "write": 1, "report": 1, "export": 1},
		"Payroll Reviewer": {"read": 1, "write": 1, "report": 1, "export": 1},
		"Payroll Approver": {"read": 1, "write": 1, "submit": 1, "cancel": 1, "report": 1},
		"Payroll Finance": {"read": 1, "write": 1, "report": 1, "export": 1, "print": 1},
		"Payroll Auditor": {"read": 1, "report": 1, "export": 1, "print": 1},
	},
	"Payroll Readiness Exception": {
		"Payroll Input": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Processor": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Reviewer": {"read": 1, "write": 1, "report": 1},
		"Payroll Approver": {"read": 1, "write": 1, "report": 1},
		"Payroll Auditor": {"read": 1, "report": 1, "export": 1},
	},
	"Payroll Transaction Allocation": {
		"Payroll Processor": {"read": 1, "write": 1, "create": 1, "report": 1},
		"Payroll Reviewer": {"read": 1, "report": 1},
		"Payroll Approver": {"read": 1, "report": 1},
		"Payroll Finance": {"read": 1, "report": 1, "export": 1},
		"Payroll Auditor": {"read": 1, "report": 1, "export": 1},
	},
}


def create_roles():
	for role in ROLES:
		if not frappe.db.exists("Role", role):
			frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1}).insert(
				ignore_permissions=True
			)


def configure_settings(initialize_sod=False):
	settings = frappe.get_single("Karyo Payroll Settings")
	legacy_defaults = {
		"input_role": ("HR User", "Payroll Input"),
		"processor_role": ("HR Manager", "Payroll Processor"),
		"reviewer_role": ("HR Manager", "Payroll Reviewer"),
		"approver_role": ("System Manager", "Payroll Approver"),
		"finance_role": ("Karyo Finance", "Payroll Finance"),
		"auditor_role": ("Auditor", "Payroll Auditor"),
	}
	changed = False
	for fieldname, (legacy, payroll_role) in legacy_defaults.items():
		if not settings.get(fieldname) or settings.get(fieldname) == legacy:
			settings.set(fieldname, payroll_role)
			changed = True
	if initialize_sod:
		settings.enforce_segregation_of_duties = 1
		changed = True
	if changed:
		settings.save(ignore_permissions=True)


def configure_permissions():
	for doctype, roles in PERMISSIONS.items():
		meta = frappe.get_doc("DocType", doctype)
		for role, values in roles.items():
			row = next((permission for permission in meta.permissions if permission.role == role), None)
			if not row:
				row = meta.append("permissions", {"role": role})
			for fieldname, value in values.items():
				row.set(fieldname, value)
		meta.save(ignore_permissions=True)


def configure_sensitive_fields():
	levels = {
		"Payroll Cycle": {
			"gross_pay": 1,
			"total_deductions": 1,
			"net_pay": 1,
			"employee_contributions": 1,
			"employer_contributions": 1,
			"paye_total": 1,
		},
		"Payroll Cycle Artifact": {"file": 2, "content_hash": 2},
	}
	for doctype, fields in levels.items():
		meta = frappe.get_doc("DocType", doctype)
		changed = False
		for fieldname, level in fields.items():
			field = next((row for row in meta.fields if row.fieldname == fieldname), None)
			if field and field.permlevel != level:
				field.permlevel = level
				changed = True
		if changed:
			meta.save(ignore_permissions=True)
	_add_level_permissions(
		"Payroll Cycle",
		1,
		["Payroll Processor", "Payroll Reviewer", "Payroll Approver", "Payroll Finance", "Payroll Auditor"],
	)
	_add_level_permissions("Payroll Cycle", 2, ["Payroll Approver", "Payroll Finance"])
	_configure_employee_tax_permissions()


def _add_level_permissions(doctype, permlevel, roles):
	meta = frappe.get_doc("DocType", doctype)
	changed = False
	for role in roles:
		if any(row.role == role and row.permlevel == permlevel for row in meta.permissions):
			continue
		values = {"role": role, "permlevel": permlevel, "read": 1}
		if role != "Payroll Auditor":
			values["write"] = 1
		meta.append("permissions", values)
		changed = True
	if changed:
		meta.save(ignore_permissions=True)


def _configure_employee_tax_permissions():
	"""Use customization records so the stock ERPNext Employee schema is never exported."""
	payroll_roles = ["Payroll Processor", "Payroll Reviewer", "Payroll Approver"]
	frappe.db.delete("DocPerm", {"parent": "Employee", "role": ("in", payroll_roles)})
	make_property_setter("Employee", "pan_number", "permlevel", 2, "Int", validate_fields_for_doctype=False)
	for role in payroll_roles:
		for level in (0, 2):
			if not frappe.db.exists(
				"Custom DocPerm", {"parent": "Employee", "role": role, "permlevel": level}
			):
				add_permission("Employee", role, level, "read")
			if level == 0:
				update_permission_property("Employee", role, level, "write", 1)


def create_workflow():
	for state, _docstatus, _role in WORKFLOW_STATES:
		if not frappe.db.exists("Workflow State", state):
			frappe.get_doc({"doctype": "Workflow State", "workflow_state_name": state}).insert(
				ignore_permissions=True
			)
	for _state, action, _next_state, _role in WORKFLOW_TRANSITIONS:
		if not frappe.db.exists("Workflow Action Master", action):
			frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": action}).insert(
				ignore_permissions=True
			)
	values = {
		"document_type": "Payroll Cycle",
		"is_active": 1,
		"override_status": 1,
		"workflow_state_field": "status",
		"send_email_alert": 0,
		"states": [
			{"state": state, "doc_status": docstatus, "allow_edit": role}
			for state, docstatus, role in WORKFLOW_STATES
		],
		"transitions": [
			{"state": state, "action": action, "next_state": next_state, "allowed": role}
			for state, action, next_state, role in WORKFLOW_TRANSITIONS
		] + [
			{
				"state": state,
				"action": action,
				"next_state": next_state,
				"allowed": "System Manager",
				"allow_self_approval": 1,
				"condition": (
					"frappe.session.user != 'Administrator' and not "
					f"frappe.db.get_value('Has Role', {{'parent': frappe.session.user, 'role': {role!r}}}, 'name')"
				),
			}
			for state, action, next_state, role in WORKFLOW_TRANSITIONS
			if role != "System Manager"
		],
	}
	if frappe.db.exists("Workflow", "Payroll Cycle Approval"):
		workflow = frappe.get_doc("Workflow", "Payroll Cycle Approval")
		workflow.update({key: value for key, value in values.items() if key not in ("states", "transitions")})
		workflow.set("states", values["states"])
		workflow.set("transitions", values["transitions"])
		workflow.save(ignore_permissions=True)
	else:
		frappe.get_doc(
			{"doctype": "Workflow", "workflow_name": "Payroll Cycle Approval", **values}
		).insert(ignore_permissions=True)


def setup():
	print("Karyo payroll governance setup:")
	from karyo.setup.payroll_configuration import _ensure_settings_fields

	had_sod_field = frappe.get_meta("Karyo Payroll Settings").has_field(
		"enforce_segregation_of_duties"
	)
	_ensure_settings_fields()
	create_roles()
	configure_settings(initialize_sod=not had_sod_field)
	configure_permissions()
	configure_sensitive_fields()
	create_workflow()
	frappe.clear_cache()
	frappe.db.commit()
	print("Done (payroll roles, workflow, segregation, and sensitive permissions created).")
