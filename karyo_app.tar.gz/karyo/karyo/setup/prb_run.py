"""PRB Payroll Run orchestration (PRB-14): per-employee run that auto-computes
basic salary from the PRB salary point, aggregates PRB gross components, handles
exceptions and stores an audit trace.

    bench --site dev.localhost execute karyo.setup.prb_run.setup
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


RUN_EXTENSION_FIELDS = [
	{"fieldname": "company", "fieldtype": "Link", "label": "Company", "options": "Company", "insert_after": "period"},
	{"fieldname": "payroll_period", "fieldtype": "Link", "label": "Payroll Period", "options": "Payroll Period", "insert_after": "company", "reqd": 1},
	{"fieldname": "payroll_cycle", "fieldtype": "Link", "label": "Payroll Cycle", "options": "Payroll Cycle", "insert_after": "payroll_period"},
	{"fieldname": "calculation_date", "fieldtype": "Date", "label": "Calculation Date", "insert_after": "payroll_cycle"},
	{"fieldname": "run_purpose", "fieldtype": "Select", "label": "Run Purpose", "options": "Comprehensive\nAttendance Bonus\nIncentive Attendance Bonus\nPRB Attendance Bonuses\nERA Hours Payment\nAdditional Hours\nActing / Responsibility", "default": "Comprehensive", "read_only": 1, "insert_after": "calculation_date"},
	{"fieldname": "calc_sb", "fieldtype": "Section Break", "label": "Calculation Snapshot", "hidden": 1, "insert_after": "increment_due"},
	{"fieldname": "run_type", "fieldtype": "Select", "label": "Run Type", "options": "Normal\nDelta", "default": "Normal", "read_only": 1, "hidden": 1, "insert_after": "calc_sb"},
	{"fieldname": "baseline_run", "fieldtype": "Link", "label": "Baseline Approved Run", "options": "PRB Payroll Run", "read_only": 1, "hidden": 1, "insert_after": "run_type"},
	{"fieldname": "snapshot_status", "fieldtype": "Select", "label": "Snapshot Status", "options": "Draft\nCalculated\nApproved", "default": "Draft", "read_only": 1, "hidden": 1, "insert_after": "baseline_run"},
	{"fieldname": "version_no", "fieldtype": "Int", "label": "Version", "default": "1", "read_only": 1, "hidden": 1, "insert_after": "snapshot_status"},
	{"fieldname": "delta_total", "fieldtype": "Currency", "label": "Delta Total", "read_only": 1, "hidden": 1, "insert_after": "version_no"},
	{"fieldname": "input_sb", "fieldtype": "Section Break", "label": "Employee Inputs", "insert_after": "delta_total"},
	{"fieldname": "employee_inputs", "fieldtype": "Table", "label": "Employee Inputs", "options": "PRB Payroll Input", "insert_after": "input_sb"},
	{"fieldname": "rule_versions", "fieldtype": "Long Text", "label": "Rule Versions", "read_only": 1, "insert_after": "audit_sb"},
	{"fieldname": "input_snapshot", "fieldtype": "Long Text", "label": "Input Snapshot", "read_only": 1, "hidden": 1, "insert_after": "rule_versions"},
	{"fieldname": "output_snapshot", "fieldtype": "Long Text", "label": "Output Snapshot", "read_only": 1, "hidden": 1, "insert_after": "input_snapshot"},
	{"fieldname": "snapshot_hash", "fieldtype": "Data", "label": "Snapshot Hash", "read_only": 1, "hidden": 1, "insert_after": "output_snapshot"},
	{"fieldname": "approved_by", "fieldtype": "Link", "label": "Approved By", "options": "User", "read_only": 1, "insert_after": "snapshot_hash"},
	{"fieldname": "approved_on", "fieldtype": "Datetime", "label": "Approved On", "read_only": 1, "insert_after": "approved_by"},
]


def ensure_extension_fields():
	"""Upgrade existing sites where the original DocTypes already exist."""
	create_custom_fields(
		{
			"PRB Payroll Run": RUN_EXTENSION_FIELDS,
			"PRB Payroll Component": [
				{"fieldname": "input_row", "fieldtype": "Data", "label": "Input Row", "insert_after": "source"},
				{"fieldname": "delta_amount", "fieldtype": "Currency", "label": "Delta", "read_only": 1, "insert_after": "input_row"},
			],
		},
		ignore_validate=True,
	)


def create_doctypes():
	make_doctype(
		"PRB Payroll Input",
		istable=1,
		fields=[
			f(
				"category",
				"Select",
				"Category",
				options="Acting\nOvertime\nAllowance\nLeave\nPMS",
				reqd=1,
				in_list_view=1,
			),
			f("input_code", "Data", "Input Code", reqd=1, in_list_view=1),
			f("description", "Data", "Description", in_list_view=1),
			f("quantity", "Float", "Quantity", default="0"),
			f("rate", "Currency", "Rate / Base", default="0"),
			f("amount", "Currency", "Fixed Amount", default="0"),
			f("parameters_json", "Long Text", "Parameters (JSON)"),
			f("source_doctype", "Link", "Source Type", options="DocType"),
			f("source_name", "Dynamic Link", "Source Document", options="source_doctype"),
		],
	)
	make_doctype(
		"PRB Payroll Component",
		istable=1,
		fields=[
			f("component_code", "Data", "Component", reqd=1, in_list_view=1),
			f("description", "Data", "Description", in_list_view=1),
			f("amount", "Currency", "Amount", in_list_view=1),
			f("rule_ref", "Data", "Rule Ref", in_list_view=1),
			f("source", "Select", "Source", options="Manual\nAuto", default="Manual", in_list_view=1),
			f("input_row", "Data", "Input Row"),
			f("delta_amount", "Currency", "Delta", read_only=1),
		],
	)
	make_doctype(
		"PRB Payroll Run",
		is_submittable=1,
		autoname="naming_series:",
		title_field="employee_name",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="PRBR-.YYYY.-.#####",
				default="PRBR-.YYYY.-.#####",
			),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("review_year", "Int", "Review Year", default="2026", reqd=1),
			f("period", "Data", "Pay Period"),
			f("hcb", "Column Break"),
			f("company", "Link", "Company", options="Company"),
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle"),
			f("calculation_date", "Date", "Calculation Date"),
			f("run_purpose", "Select", "Run Purpose", options="Comprehensive\nAttendance Bonus\nIncentive Attendance Bonus\nPRB Attendance Bonuses\nERA Hours Payment\nAdditional Hours\nActing / Responsibility", default="Comprehensive", read_only=1),
			f("salary_point", "Data", "Salary Point", fetch_from="employee.karyo_prb_salary_point"),
			f("increment_due", "Check", "Annual Increment Due"),
			f("calc_sb", "Section Break", "Calculation Snapshot", hidden=1),
			f(
				"run_type",
				"Select",
				"Run Type",
				options="Normal\nDelta",
				default="Normal",
				read_only=1,
				hidden=1,
			),
			f("baseline_run", "Link", "Baseline Approved Run", options="PRB Payroll Run", read_only=1, hidden=1),
			f(
				"snapshot_status",
				"Select",
				"Snapshot Status",
				options="Draft\nCalculated\nApproved",
				default="Draft",
				read_only=1,
				in_standard_filter=1,
				hidden=1,
			),
			f("version_no", "Int", "Version", default="1", read_only=1, hidden=1),
			f("delta_total", "Currency", "Delta Total", read_only=1, hidden=1),
			f("input_sb", "Section Break", "Employee Inputs"),
			f("employee_inputs", "Table", "Employee Inputs", options="PRB Payroll Input"),
			f("res_sb", "Section Break", "Result"),
			f("basic_salary", "Currency", "Basic Salary", read_only=1),
			f("gross_pay", "Currency", "PRB Gross Pay", read_only=1, in_list_view=1),
			f("rcb", "Column Break"),
			f("exception_code", "Data", "Exception Code", read_only=1, in_standard_filter=1),
			f("exception_detail", "Small Text", "Exception Detail", read_only=1),
			f("comp_sb", "Section Break", "Components"),
			f("components", "Table", "Components", options="PRB Payroll Component"),
			f("audit_sb", "Section Break", "Audit"),
			f("rule_versions", "Long Text", "Rule Versions", read_only=1),
			f("input_snapshot", "Long Text", "Input Snapshot", read_only=1, hidden=1),
			f("output_snapshot", "Long Text", "Output Snapshot", read_only=1, hidden=1),
			f("snapshot_hash", "Data", "Snapshot Hash", read_only=1, hidden=1),
			f("approved_by", "Link", "Approved By", options="User", read_only=1),
			f("approved_on", "Datetime", "Approved On", read_only=1),
			f("audit_trace", "Long Text", "Audit Trace", read_only=1),
		],
	)


def setup():
	print("Karyo PRB Payroll Run setup:")
	create_doctypes()
	ensure_extension_fields()
	frappe.db.commit()
	print("Done.")
