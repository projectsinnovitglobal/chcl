"""Resolve non-PRB basic pay from an approved employee salary structure."""
import frappe
from frappe.utils import flt


def from_salary_structure(run):
 employee=frappe.get_doc('Employee',run.employee)
 # The explicit applicability flag is authoritative. Legacy imports can retain
 # old PRB grade text after an employee has been marked non-PRB; that stale
 # text must not disable an otherwise valid Salary Structure Assignment.
 if employee.karyo_prb_opted_in:
  return None
 assignment=frappe.db.get_value('Salary Structure Assignment',{
  'employee':run.employee,'company':run.company,'docstatus':1,
  'from_date':['<=',run.calculation_date],
 },['name','salary_structure','base'],order_by='from_date desc, creation desc',as_dict=True)
 if not assignment:return None
 structure=frappe.get_doc('Salary Structure',assignment.salary_structure)
 if structure.docstatus!=1 or structure.company!=run.company or structure.is_active!='Yes':return None
 # Use the configured BASIC mapping or the explicit standard Basic component.
 names={'Basic','Basic Salary','Karyo Basic'}
 pdb=frappe.db.get_value('PRB Payroll Component Mapping',{'component_code':'BASIC','is_active':1},'pdb_code')
 if pdb:
  mapped=frappe.db.get_value('Payroll PDB Code',pdb,'salary_component')
  if mapped:names.add(mapped)
 basic_rows=[r for r in structure.earnings if r.salary_component in names]
 if len(basic_rows)!=1:return None
 basic_row=basic_rows[0]
 # The standard and most common Salary Structure rule is Basic = assignment
 # base.  A preview slip without an explicit payroll period prorates this to a
 # single day, which is not the monthly salary basis used by overtime.
 if basic_row.amount_based_on_formula and (basic_row.formula or '').strip().lower() == 'base':
  amount=flt(assignment.base)
 elif not basic_row.amount_based_on_formula and flt(basic_row.amount)>0:
  amount=flt(basic_row.amount)
 else:
  from hrms.payroll.doctype.salary_structure.salary_structure import make_salary_slip
  slip=make_salary_slip(structure.name,employee=run.employee,posting_date=run.calculation_date)
  amount=sum(flt(row.amount) for row in slip.earnings if row.salary_component==basic_row.salary_component)
 if amount<=0:return None
 return {'amount':amount,'rule_ref':'Salary Structure: '+structure.name,'salary_structure':structure.name,'salary_structure_assignment':assignment.name,'salary_component':basic_row.salary_component}
