"""Process submitted one-off payments after exit without resuming regular pay."""

import frappe
from frappe import _
from frappe.utils import cint, date_diff, getdate
from hrms.payroll.doctype.additional_salary.additional_salary import AdditionalSalary
from hrms.payroll.doctype.salary_slip.salary_slip import SalarySlip, get_salary_component_data

from karyo.hr.final_settlement import is_post_exit_run, payment_window_active


class PostExitAdditionalSalary(AdditionalSalary):
	def validate_dates(self):
		emp = frappe.get_doc("Employee", self.employee)
		if not payment_window_active(emp):
			return super().validate_dates()
		if cint(self.is_recurring):
			frappe.throw(_("Post-exit payments must be one-off Additional Salaries."))
		if not self.payroll_date:
			frappe.throw(_("Payroll Date is required for a post-exit payment."))
		if not getdate(emp.relieving_date) < getdate(self.payroll_date) <= getdate(emp.karyo_post_exit_payroll_until):
			frappe.throw(_("The post-exit Payroll Date must be after the leaving date and within the approved payment window."))


class PostExitSalarySlip(SalarySlip):
	def _post_exit(self):
		return bool(self.employee and is_post_exit_run(self.employee, self.start_date))

	@property
	def relieving_date(self):
		# Preserve the Employee's actual leaving date. Only this supplemental slip
		# uses payroll dates for native tax/accounting calculations.
		return None if self._post_exit() else super().relieving_date

	def get_working_days_details(self, lwp=None, for_preview=0):
		if not self._post_exit():
			return super().get_working_days_details(lwp=lwp, for_preview=for_preview)
		self.total_working_days = date_diff(self.end_date, self.start_date) + 1
		self.payment_days = self.total_working_days
		self.leave_without_pay = self.absent_days = 0

	def calculate_component_amounts(self, component_type):
		if not self._post_exit():
			return super().calculate_component_amounts(component_type)
		if not getattr(self, "_salary_structure_doc", None):
			self.set_salary_structure_doc()
		# Rebuild on every validation so draft edits cannot introduce regular pay
		# or keep an input that was subsequently cancelled.
		if component_type == "earnings":
			self.set(component_type, [])
		self.data, self.default_data = self.get_data_for_eval()
		additional_salaries = frappe.get_all("Additional Salary", filters={
			"employee": self.employee, "docstatus": 1, "disabled": 0, "is_recurring": 0,
			"type": "Earning" if component_type == "earnings" else "Deduction",
			"payroll_date": ("between", [self.start_date, self.end_date]),
		}, fields=["name", "salary_component as component", "amount", "is_recurring",
			"overwrite_salary_structure_amount as overwrite", "deduct_full_tax_on_selected_payroll_date"])
		if component_type == "deductions":
			approved_sources = {row.name for row in additional_salaries}
			self.set(component_type, [row for row in self.get(component_type)
				if not row.additional_salary or row.additional_salary in approved_sources])
		for additional in additional_salaries:
			component = get_salary_component_data(additional.component)
			self.update_component_row(component, additional.amount, component_type, additional)
		if component_type == "deductions":
			self.add_tax_components()

	def validate(self):
		super().validate()
		if self._post_exit() and not any(row.additional_salary for row in self.earnings):
			frappe.throw(_("Submit an approved one-off Additional Salary before generating a post-exit payslip."))
