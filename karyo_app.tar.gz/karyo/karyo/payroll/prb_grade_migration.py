"""Import, validate, report, and activate official PRB grade scales."""

import csv
import hashlib
import io

import frappe
from frappe import _
from frappe.utils import cint, flt, now_datetime

from karyo.payroll.configuration import assert_production_eligible


CSV_FIELDS = (
	"grade_id",
	"organisation",
	"sector",
	"volume_part",
	"initial_point",
	"top_point",
	"qualification_bar_point",
	"is_flat_salary",
	"flat_salary",
	"source_reference",
)


def _content(dataset):
	if not dataset.source_file:
		frappe.throw(_("Attach the official grade-scale CSV first."))
	file_name = frappe.db.get_value("File", {"file_url": dataset.source_file}, "name")
	if not file_name:
		frappe.throw(_("Attached source CSV could not be found."))
	file_doc = frappe.get_doc("File", file_name)
	content = file_doc.get_content()
	return content.decode() if isinstance(content, bytes) else content


@frappe.whitelist()
def import_csv(name):
	dataset = frappe.get_doc("PRB Grade Scale Dataset", name)
	if dataset.status != "Draft":
		frappe.throw(_("Only a Draft dataset can be imported."))
	content = _content(dataset)
	reader = csv.DictReader(io.StringIO(content.lstrip("\ufeff")))
	missing = [field for field in CSV_FIELDS if field not in (reader.fieldnames or [])]
	if missing:
		frappe.throw(_("CSV is missing columns: {0}").format(", ".join(missing)))
	dataset.set("rows", [])
	for values in reader:
		dataset.append(
			"rows",
			{
				**{field: (values.get(field) or "").strip() for field in CSV_FIELDS},
				"is_flat_salary": cint(values.get("is_flat_salary")),
				"flat_salary": flt(values.get("flat_salary")),
			},
		)
	dataset.source_hash = hashlib.sha256(content.encode()).hexdigest()
	dataset.status = "Draft"
	dataset.save()
	return {"dataset": dataset.name, "rows": len(dataset.rows), "source_hash": dataset.source_hash}


def _exception(dataset, severity, code, detail, grade=None, employee=None):
	dataset.append(
		"exceptions",
		{
			"severity": severity,
			"exception_code": code,
			"grade_id": grade,
			"employee": employee,
			"detail": detail,
		},
	)


@frappe.whitelist()
def validate_dataset(name):
	dataset = frappe.get_doc("PRB Grade Scale Dataset", name)
	if dataset.status == "Activated":
		frappe.throw(_("Activated datasets cannot be revalidated."))
	dataset.set("exceptions", [])
	seen = set()
	points = set(frappe.get_all("PRB Salary Point", pluck="salary_point"))
	grades = {}
	for row in dataset.rows:
		row.grade_id = (row.grade_id or "").strip().upper()
		if not row.grade_id:
			_exception(dataset, "Error", "MISSING_GRADE", "Grade ID is required.")
			continue
		if row.grade_id in seen:
			_exception(dataset, "Error", "DUPLICATE_GRADE", "Grade appears more than once.", row.grade_id)
		seen.add(row.grade_id)
		grades[row.grade_id] = row
		if row.is_flat_salary:
			if flt(row.flat_salary) <= 0:
				_exception(dataset, "Error", "INVALID_FLAT_SALARY", "Flat salary must be positive.", row.grade_id)
			if row.initial_point or row.top_point or row.qualification_bar_point:
				_exception(dataset, "Error", "FLAT_WITH_POINTS", "Flat salary grade cannot also define scale points.", row.grade_id)
			continue
		if not row.initial_point or not row.top_point:
			_exception(dataset, "Error", "MISSING_POINT_RANGE", "Initial and top points are required.", row.grade_id)
			continue
		for label, point in (
			("initial", row.initial_point),
			("top", row.top_point),
			("qualification bar", row.qualification_bar_point),
		):
			if point and point not in points:
				_exception(dataset, "Error", "UNKNOWN_SALARY_POINT", f"{label.title()} point {point} does not exist.", row.grade_id)
		if row.initial_point > row.top_point:
			_exception(dataset, "Error", "REVERSED_RANGE", "Initial point exceeds top point.", row.grade_id)
		if row.qualification_bar_point and not (
			row.initial_point <= row.qualification_bar_point <= row.top_point
		):
			_exception(dataset, "Error", "QUALIFICATION_BAR_OUTSIDE_RANGE", "Qualification bar is outside the grade range.", row.grade_id)

	for employee in frappe.get_all(
		"Employee",
		filters={"status": "Active"},
		fields=["name", "karyo_prb_grade", "karyo_prb_salary_point"],
	):
		if not employee.karyo_prb_grade:
			_exception(dataset, "Warning", "EMPLOYEE_MISSING_GRADE", "Active employee has no PRB grade.", employee=employee.name)
			continue
		scale = grades.get(employee.karyo_prb_grade)
		if not scale:
			_exception(dataset, "Error", "EMPLOYEE_GRADE_MISSING", "Employee grade is absent from the official dataset.", employee.karyo_prb_grade, employee.name)
		elif not scale.is_flat_salary and (
			not employee.karyo_prb_salary_point
			or not (scale.initial_point <= employee.karyo_prb_salary_point <= scale.top_point)
		):
			_exception(dataset, "Error", "EMPLOYEE_POINT_OUTSIDE_GRADE", "Employee salary point is missing or outside the official grade range.", employee.karyo_prb_grade, employee.name)
	dataset.row_count = len(dataset.rows)
	dataset.error_count = sum(1 for row in dataset.exceptions if row.severity == "Error")
	dataset.warning_count = sum(1 for row in dataset.exceptions if row.severity == "Warning")
	dataset.status = "Validated" if not dataset.error_count else "Draft"
	dataset.validated_by = frappe.session.user
	dataset.validated_on = now_datetime()
	dataset.save()
	return {
		"dataset": dataset.name,
		"rows": dataset.row_count,
		"errors": dataset.error_count,
		"warnings": dataset.warning_count,
		"status": dataset.status,
	}


@frappe.whitelist()
def activate_dataset(name):
	dataset = frappe.get_doc("PRB Grade Scale Dataset", name)
	if dataset.status != "Validated" or dataset.error_count:
		frappe.throw(_("Dataset must pass validation without errors before activation."))
	if not dataset.is_official_client_data:
		frappe.throw(_("Confirm that this is official client data before activation."))
	configuration = frappe.get_doc("Payroll Configuration Version", dataset.configuration_version)
	if configuration.configuration_type != "PRB Grade Scale":
		frappe.throw(_("Configuration Version must be a PRB Grade Scale configuration."))
	assert_production_eligible(configuration)
	frappe.db.sql("update `tabPRB Grade Scale` set is_active=0 where is_active=1")
	for row in dataset.rows:
		values = {
			"organisation": row.organisation,
			"sector": row.sector,
			"volume_part": row.volume_part,
			"initial_point": row.initial_point or None,
			"top_point": row.top_point or None,
			"qualification_bar_point": row.qualification_bar_point or None,
			"flat_salary": row.flat_salary,
			"is_flat_salary": row.is_flat_salary,
			"dataset": dataset.name,
			"data_origin": "Official",
			"is_active": 1,
			"effective_from": dataset.effective_from,
			"source_reference": row.source_reference or dataset.source_reference,
		}
		if frappe.db.exists("PRB Grade Scale", row.grade_id):
			frappe.db.set_value("PRB Grade Scale", row.grade_id, values)
		else:
			frappe.get_doc({"doctype": "PRB Grade Scale", "grade_id": row.grade_id, **values}).insert(ignore_permissions=True)
	dataset.db_set(
		{"status": "Activated", "activated_by": frappe.session.user, "activated_on": now_datetime()},
		update_modified=False,
	)
	return {"dataset": dataset.name, "activated": len(dataset.rows)}


@frappe.whitelist()
def get_migration_report(name):
	dataset = frappe.get_doc("PRB Grade Scale Dataset", name)
	return {
		"dataset": dataset.name,
		"status": dataset.status,
		"source_reference": dataset.source_reference,
		"source_hash": dataset.source_hash,
		"summary": {
			"rows": dataset.row_count,
			"errors": dataset.error_count,
			"warnings": dataset.warning_count,
		},
		"grade_scales": [
			{
				"grade_id": row.grade_id,
				"initial_point": row.initial_point,
				"top_point": row.top_point,
				"qualification_bar_point": row.qualification_bar_point,
				"is_flat_salary": bool(row.is_flat_salary),
				"flat_salary": row.flat_salary,
			}
			for row in dataset.rows
		],
		"exceptions": [
			{
				"severity": row.severity,
				"code": row.exception_code,
				"grade_id": row.grade_id,
				"employee": row.employee,
				"detail": row.detail,
			}
			for row in dataset.exceptions
		],
	}


def assert_employee_official_scale(employee):
	grade = frappe.db.get_value("Employee", employee, "karyo_prb_grade")
	scale = frappe.db.get_value("PRB Grade Scale", grade, ["data_origin", "is_active"], as_dict=True)
	if not scale or scale.data_origin != "Official" or not scale.is_active:
		frappe.throw(_("Employee {0} does not have an active official PRB grade scale.").format(employee))
	return True
