"""Employee reference-master integration tests."""

import frappe
from frappe.tests.utils import FrappeTestCase
from frappe.utils import random_string

from karyo.desk.org_units import save as save_org_unit
from karyo.setup.employee_reference import REFERENCE_DOCTYPES, TITLE_VALUES, apply


class TestEmployeeReference(FrappeTestCase):
	def test_employee_fields_use_reference_masters(self):
		meta = frappe.get_meta("Employee")
		for fieldname, doctype in (("salutation", "Salutation"), ("gender", "Gender")):
			field = meta.get_field(fieldname)
			self.assertEqual(field.fieldtype, "Link")
			self.assertEqual(field.options, doctype)

	def test_hr_manager_can_maintain_reference_masters(self):
		apply()
		for doctype in REFERENCE_DOCTYPES:
			permissions = [
				row for row in frappe.get_meta(doctype).get_permissions() if row.role == "HR Manager"
			]
			self.assertTrue(any(row.read and row.create and row.write and row.delete for row in permissions))

	def test_salutation_master_uses_title_fields_and_supplied_values(self):
		apply()
		meta = frappe.get_meta("Salutation")
		self.assertEqual(meta.get_field("salutation").label, "Title ID")
		self.assertEqual(meta.get_field("title_description").label, "Title Description")
		for title_id, description in TITLE_VALUES:
			self.assertEqual(
				frappe.db.get_value("Salutation", title_id, "title_description"), description
			)

	def test_salutation_editor_creates_and_updates_title(self):
		suffix = random_string(8).upper()
		created = save_org_unit(
			"Salutation",
			{"salutation": f"TTL-{suffix}", "title_description": "Test title"},
		)
		updated = save_org_unit(
			"Salutation",
			{"salutation": f"TTX-{suffix}", "title_description": "Updated title"},
			created["name"],
		)
		self.assertEqual(updated["name"], f"TTX-{suffix}")
		self.assertEqual(
			frappe.db.get_value("Salutation", updated["name"], "title_description"),
			"Updated title",
		)
