"""Client-facing alias for the canonical, payroll-aware loan schedule report."""

from karyo.karyo.report.loan_schedule.loan_schedule import execute

__all__ = ["execute"]
