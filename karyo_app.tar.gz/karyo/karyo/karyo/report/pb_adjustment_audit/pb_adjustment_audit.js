frappe.query_reports["PB Adjustment Audit"] = {
	filters: [
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
		{fieldname: "from_date", label: __("Posting Date From"), fieldtype: "Date"},
		{fieldname: "to_date", label: __("Posting Date To"), fieldtype: "Date"},
	],
};
