"""Per-employee Payroll Cycle processing state (PAY-060)."""

import frappe

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Payroll Cycle Employee",
		autoname="hash",
		title_field="employee",
		fields=[
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1, in_standard_filter=1),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1, in_standard_filter=1),
			f("company", "Link", "Company", options="Company", reqd=1, read_only=1),
			f("business_key", "Data", "Business Key", reqd=1, unique=1, read_only=1),
			f("status", "Select", "Status", options="Included\nExcluded\nPayroll Entry Ready\nSalary Slip Created\nProcessed\nReconciled\nFailed", reqd=1, in_list_view=1, in_standard_filter=1),
			f("exclusion_reason", "Small Text", "Exclusion / Failure Reason", read_only=1),
			f("payroll_entry", "Link", "Payroll Entry", options="Payroll Entry", read_only=1),
			f("salary_slip", "Link", "Salary Slip", options="Salary Slip", read_only=1),
			f("last_processed_on", "Datetime", "Last Processed On", read_only=1),
			f("readiness_checked_on", "Datetime", "Employee Readiness Checked On", read_only=1),
			f("processing_started_on", "Datetime", "Employee Processing Started On", read_only=1),
		],
	)


def setup():
	print("Karyo Payroll processing setup:")
	create_doctypes()
	frappe.db.commit()
	print("Done (per-employee Payroll Cycle processing state created).")
