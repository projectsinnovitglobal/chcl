"""Validated salary remittance split between primary and secondary accounts."""

import frappe
from frappe import _
from frappe.utils import flt, getdate


def _active(from_date, to_date, on_date):
	on_date = getdate(on_date)
	return (not from_date or getdate(from_date) <= on_date) and (not to_date or getdate(to_date) >= on_date)


def validate_employee_split(doc, method=None):
	amount = flt(doc.get("karyo_secondary_bank_fixed_amount"))
	if amount < 0:
		frappe.throw(_("Fixed Amount to Secondary Bank cannot be negative."))
	if not amount:
		return
	required = {
		"karyo_secondary_payroll_bank": _("Secondary Payroll Bank"),
		"karyo_secondary_payroll_bank_branch": _("Secondary Payroll Bank Branch"),
		"karyo_secondary_bank_account_no": _("Secondary Account Number"),
	}
	missing = [label for fieldname, label in required.items() if not doc.get(fieldname)]
	if doc.get("salary_mode") != "Bank":
		missing.append(_("Salary Mode = Bank"))
	if missing:
		frappe.throw(_("Complete the secondary salary routing before entering a fixed amount: {0}.").format(", ".join(missing)))
	branch = frappe.db.get_value(
		"Payroll Bank Branch", doc.karyo_secondary_payroll_bank_branch,
		["bank", "is_active", "effective_from", "effective_to"], as_dict=True,
	)
	if not branch or not branch.is_active or branch.bank != doc.karyo_secondary_payroll_bank:
		frappe.throw(_("Select an active secondary branch belonging to the secondary bank."))
	if not frappe.db.get_value("Bank", doc.karyo_secondary_payroll_bank, "karyo_payroll_active"):
		frappe.throw(_("Select a bank that is active for secondary payroll transfers."))
	if doc.get("karyo_secondary_bank_effective_to") and doc.get("karyo_secondary_bank_effective_from") and getdate(
		doc.karyo_secondary_bank_effective_to
	) < getdate(doc.karyo_secondary_bank_effective_from):
		frappe.throw(_("Secondary Account Effective To cannot be before Effective From."))
	if doc.get("bank_ac_no") == doc.get("karyo_secondary_bank_account_no"):
		frappe.throw(_("Primary and secondary salary account numbers must be different."))


def split_for_employee(employee, net_pay, on_date):
	"""Return the deterministic, balanced remittance snapshot for one payslip."""
	emp = frappe.db.get_value(
		"Employee", employee,
		[
			"salary_mode", "karyo_payroll_bank", "karyo_payroll_bank_branch", "bank_ac_no",
			"karyo_secondary_payroll_bank", "karyo_secondary_payroll_bank_branch",
			"karyo_secondary_bank_account_no", "karyo_secondary_bank_fixed_amount",
			"karyo_secondary_bank_effective_from", "karyo_secondary_bank_effective_to",
		], as_dict=True,
	)
	net = max(0, flt(net_pay, 2))
	if not emp or emp.salary_mode != "Bank":
		return frappe._dict(primary_amount=net, secondary_amount=0)
	secondary = 0.0
	if (
		flt(emp.karyo_secondary_bank_fixed_amount) > 0
		and emp.karyo_secondary_payroll_bank
		and emp.karyo_secondary_payroll_bank_branch
		and emp.karyo_secondary_bank_account_no
		and _active(emp.karyo_secondary_bank_effective_from, emp.karyo_secondary_bank_effective_to, on_date)
	):
		secondary = min(net, flt(emp.karyo_secondary_bank_fixed_amount, 2))
	return frappe._dict(
		primary_bank=emp.karyo_payroll_bank,
		primary_branch=emp.karyo_payroll_bank_branch,
		primary_account=emp.bank_ac_no,
		primary_amount=flt(net - secondary, 2),
		secondary_bank=emp.karyo_secondary_payroll_bank if secondary else None,
		secondary_branch=emp.karyo_secondary_payroll_bank_branch if secondary else None,
		secondary_account=emp.karyo_secondary_bank_account_no if secondary else None,
		secondary_amount=secondary,
	)


def populate_salary_slip(doc, method=None):
	if not doc.get("employee"):
		return
	values = split_for_employee(doc.employee, doc.get("net_pay"), doc.get("end_date") or doc.get("posting_date"))
	for fieldname, key in {
		"karyo_primary_remittance_bank": "primary_bank",
		"karyo_primary_remittance_branch": "primary_branch",
		"karyo_primary_remittance_account": "primary_account",
		"karyo_primary_remittance_amount": "primary_amount",
		"karyo_secondary_remittance_bank": "secondary_bank",
		"karyo_secondary_remittance_branch": "secondary_branch",
		"karyo_secondary_remittance_account": "secondary_account",
		"karyo_secondary_remittance_amount": "secondary_amount",
	}.items():
		if doc.meta.has_field(fieldname):
			doc.set(fieldname, values.get(key))
	if abs(flt(values.primary_amount) + flt(values.secondary_amount) - max(0, flt(doc.net_pay))) >= 0.005:
		frappe.throw(_("Salary bank split must reconcile exactly to Net Pay."))
