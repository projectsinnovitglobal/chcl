import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.payroll.formula_controls import get_controls, preview, save


class TestFormulaControls(FrappeTestCase):
	def setUp(self):
		self.original_user = frappe.session.user
		frappe.set_user("Administrator")
		self.structure = frappe.db.get_value(
			"Salary Structure", {"docstatus": 1, "is_active": "Yes"}, "name", order_by="name"
		)
		self.assertTrue(self.structure)
		self.formula_row = frappe.db.get_value(
			"Salary Detail",
			{"parent": self.structure, "amount_based_on_formula": 1},
			["name", "salary_component", "formula", "condition"],
			as_dict=True,
		)
		self.assertTrue(self.formula_row)

	def tearDown(self):
		frappe.set_user(self.original_user)

	def test_lists_all_structure_rows_with_preview(self):
		result = get_controls(50000)
		structure = next(row for row in result["structures"] if row["name"] == self.structure)
		self.assertTrue(structure["rows"])
		self.assertIn("net", structure["totals"])
		row = next(row for row in structure["rows"] if row["name"] == self.formula_row.name)
		self.assertEqual(row["formula"], self.formula_row.formula)
		self.assertIn("preview_status", row)

	def test_unsaved_formula_and_condition_recalculate_in_place(self):
		result = preview(
			self.structure,
			50000,
			[{"name": self.formula_row.name, "condition": "base > 40000", "formula": "base * 0.02"}],
		)
		self.assertEqual(result["rows"][self.formula_row.name]["preview_amount"], 1000)
		blocked = preview(
			self.structure,
			30000,
			[{"name": self.formula_row.name, "condition": "base > 40000", "formula": "base * 0.02"}],
		)
		self.assertEqual(blocked["rows"][self.formula_row.name]["preview_amount"], 0)
		self.assertEqual(blocked["rows"][self.formula_row.name]["preview_status"], "Condition not met")

	def test_save_updates_submitted_structure_and_creates_audit_version(self):
		modified = frappe.db.get_value("Salary Structure", self.structure, "modified")
		versions = frappe.db.count("Version", {"ref_doctype": "Salary Structure", "docname": self.structure})
		result = save(
			self.structure,
			50000,
			[{"name": self.formula_row.name, "condition": "base >= 0", "formula": "base * 0.02"}],
			str(modified),
		)
		updated = frappe.db.get_value(
			"Salary Detail", self.formula_row.name, ["condition", "formula", "amount_based_on_formula"], as_dict=True
		)
		self.assertEqual(updated.condition, "base >= 0")
		self.assertEqual(updated.formula, "base * 0.02")
		self.assertEqual(updated.amount_based_on_formula, 1)
		self.assertEqual(result["preview"]["rows"][self.formula_row.name]["preview_amount"], 1000)
		self.assertNotEqual(result["structure"]["modified"], str(modified))
		self.assertEqual(
			frappe.db.count("Version", {"ref_doctype": "Salary Structure", "docname": self.structure}),
			versions + 1,
		)

	def test_invalid_formula_is_not_saved(self):
		before = frappe.db.get_value("Salary Detail", self.formula_row.name, "formula")
		modified = frappe.db.get_value("Salary Structure", self.structure, "modified")
		with self.assertRaises(frappe.ValidationError):
			save(
				self.structure,
				50000,
				[{"name": self.formula_row.name, "condition": "", "formula": "base *** 2"}],
				str(modified),
			)
		self.assertEqual(frappe.db.get_value("Salary Detail", self.formula_row.name, "formula"), before)

	def test_non_admin_user_is_blocked_server_side(self):
		frappe.set_user("Guest")
		with self.assertRaises(frappe.PermissionError):
			get_controls(50000)
