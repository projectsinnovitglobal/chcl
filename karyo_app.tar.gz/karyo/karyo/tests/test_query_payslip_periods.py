"""Query and Generate Payslip must use identical master values and data scope."""
import unittest
from unittest.mock import patch
from uuid import uuid4
import frappe
from karyo.desk.payroll_screens import _query, _payslips, payslip_period_options
from karyo.payroll.screen_specs import SCREENS

class TestQueryPayslipPeriods(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('query_period_test')

    def tearDown(self):
        frappe.db.rollback(save_point='query_period_test')
        frappe.set_user(self.user)

    def compare(self, params):
        query = _query('query', SCREENS['query'], params)
        generate = _payslips('payslipgen', SCREENS['payslipgen'], params)
        for field in ('cycles', 'selected_cycle', 'selection', 'period_context'):
            self.assertEqual(query[field], generate[field])
        self.assertEqual([r.name for r in query['list']['rows']], [r.name for r in generate['list']['rows']])
        return query

    def test_defaults_periods_and_employee_match(self):
        self.compare({})
        self.compare({'pay_day': 'obsolete-cycle'})
        for option in payslip_period_options():
            self.compare({'pay_day': option['key']})
            self.compare({'pay_day': option['key'], 'employee': 'MBC/HR/00001'})

    def test_no_accessible_periods_does_not_show_unscoped_slips(self):
        with patch('karyo.desk.payroll_screens.payslip_period_options', return_value=[]):
            result = self.compare({})
            self.assertEqual(result['list']['rows'], [])
            self.assertIsNone(result['selected_cycle'])
