"""Seed realistic HR demo data across the stock HRMS modules.

    bench --site dev.localhost execute karyo.setup.demo_hr.seed

Creates a Mauritian demo company (Mauritius Agro Industries Ltd, MUR) with a
full workforce and transactions in every HR module the Karyo sidebar exposes:
recruitment, attendance & shifts, leave, payroll, expenses & travel,
performance, training, tax & benefits — plus Passage Benefit banks and loans
for the new staff. Idempotent: every block checks for existing records first.
Deterministic (seeded random) so re-runs produce the same data.
"""

import random
import traceback
from datetime import date, timedelta

import frappe
from frappe.utils import add_days, getdate

R = random.Random(20260710)

COMPANY = "SIL"
ABBR = "MAI"
CURRENCY = "MUR"
HOLIDAY_LIST = "Mauritius Public Holidays 2026"
STRUCTURE = "MAI Staff Structure"
TAX_SLAB = "Mauritius PAYE 2025-26"
TODAY = date(2026, 7, 10)

BRANCHES = ["Port Louis HQ", "Curepipe", "Réduit Research Station", "Flacq"]
DEPARTMENTS = [
	"Human Resources",
	"Finance",
	"ICT",
	"Field Operations",
	"Research & Development",
	"Administration",
]
DESIGNATIONS = [
	"General Manager",
	"HR Manager",
	"HR Officer",
	"Senior HR Officer",
	"Accountant",
	"Accounts Clerk",
	"ICT Manager",
	"Software Developer",
	"Senior Software Developer",
	"Research Scientist",
	"Lab Technician",
	"Senior Lab Technician",
	"Agricultural Officer",
	"Senior Agricultural Officer",
	"Field Supervisor",
	"Driver",
	"Office Attendant",
	"Clerk",
	"Procurement Officer",
	"Communications Officer",
]
GRADES = ["Workman", "Officer", "Senior Officer", "Management"]

# (name, gender, department, designation, grade, branch, base MUR, doj)
STAFF = [
	(
		"Sanjay Bhugowandeen",
		"Male",
		"Administration",
		"General Manager",
		"Management",
		"Port Louis HQ",
		145000,
		"2011-03-01",
	),
	(
		"Marie-Ange Laurent",
		"Female",
		"Human Resources",
		"HR Manager",
		"Management",
		"Port Louis HQ",
		98000,
		"2013-08-12",
	),
	(
		"Yashna Seebaluck",
		"Female",
		"Human Resources",
		"HR Officer",
		"Officer",
		"Port Louis HQ",
		38000,
		"2019-02-04",
	),
	(
		"Kevin Li Ying",
		"Male",
		"Finance",
		"Accountant",
		"Senior Officer",
		"Port Louis HQ",
		72000,
		"2014-06-16",
	),
	(
		"Bibi Nawsheen Jaulim",
		"Female",
		"Finance",
		"Accounts Clerk",
		"Workman",
		"Port Louis HQ",
		26000,
		"2021-01-11",
	),
	("Ashwin Purrun", "Male", "ICT", "ICT Manager", "Senior Officer", "Port Louis HQ", 85000, "2012-09-03"),
	("Julien Maurice", "Male", "ICT", "Software Developer", "Officer", "Port Louis HQ", 52000, "2018-04-02"),
	(
		"Divya Beeharry",
		"Female",
		"ICT",
		"Software Developer",
		"Officer",
		"Port Louis HQ",
		48000,
		"2026-03-02",
	),
	(
		"Anand Seeruttun",
		"Male",
		"Research & Development",
		"Research Scientist",
		"Senior Officer",
		"Réduit Research Station",
		82000,
		"2010-01-18",
	),
	(
		"Priyanka Dookun",
		"Female",
		"Research & Development",
		"Research Scientist",
		"Senior Officer",
		"Réduit Research Station",
		78000,
		"2015-10-05",
	),
	(
		"Cédric Étienne",
		"Male",
		"Research & Development",
		"Lab Technician",
		"Officer",
		"Réduit Research Station",
		34000,
		"2017-07-24",
	),
	(
		"Zaheer Atchia",
		"Male",
		"Research & Development",
		"Lab Technician",
		"Officer",
		"Réduit Research Station",
		33000,
		"2020-02-17",
	),
	(
		"Ravish Gopee",
		"Male",
		"Field Operations",
		"Agricultural Officer",
		"Officer",
		"Flacq",
		42000,
		"2016-05-09",
	),
	(
		"Leela Chuttoo",
		"Female",
		"Field Operations",
		"Agricultural Officer",
		"Officer",
		"Flacq",
		41000,
		"2016-11-21",
	),
	(
		"Jean-Noël Baptiste",
		"Male",
		"Field Operations",
		"Field Supervisor",
		"Officer",
		"Flacq",
		45000,
		"2013-02-25",
	),
	(
		"Kritika Ramdhony",
		"Female",
		"Field Operations",
		"Agricultural Officer",
		"Officer",
		"Curepipe",
		40000,
		"2019-09-16",
	),
	(
		"Farhan Rojoa",
		"Male",
		"Field Operations",
		"Agricultural Officer",
		"Officer",
		"Curepipe",
		39000,
		"2026-06-01",
	),
	("Sylvio Legrand", "Male", "Field Operations", "Driver", "Workman", "Port Louis HQ", 22000, "2015-03-30"),
	("Dharmesh Beegoo", "Male", "Field Operations", "Driver", "Workman", "Flacq", 21500, "2018-08-13"),
	(
		"Marie-Josée Perrine",
		"Female",
		"Administration",
		"Office Attendant",
		"Workman",
		"Port Louis HQ",
		18500,
		"2014-12-01",
	),
	("Vanessa Chung", "Female", "Administration", "Clerk", "Workman", "Port Louis HQ", 25000, "2022-05-02"),
	(
		"Ibrahim Cassim",
		"Male",
		"Administration",
		"Procurement Officer",
		"Officer",
		"Port Louis HQ",
		44000,
		"2015-06-22",
	),
	("Shalini Gowrea", "Female", "Administration", "Clerk", "Workman", "Curepipe", 24000, "2023-01-09"),
	(
		"Georges Adolphe",
		"Male",
		"Administration",
		"Office Attendant",
		"Workman",
		"Curepipe",
		19000,
		"2017-04-10",
	),
	(
		"Roshan Jugurnauth",
		"Male",
		"Field Operations",
		"Field Supervisor",
		"Officer",
		"Réduit Research Station",
		46000,
		"2012-11-05",
	),
	(
		"Anjali Motah",
		"Female",
		"Field Operations",
		"Agricultural Officer",
		"Officer",
		"Réduit Research Station",
		38500,
		"2021-08-02",
	),
	("Li Wen Cheung", "Female", "Finance", "Accountant", "Officer", "Port Louis HQ", 47000, "2019-11-18"),
	(
		"Prakash Callychurn",
		"Male",
		"Field Operations",
		"Agricultural Officer",
		"Officer",
		"Flacq",
		40500,
		"2018-01-15",
	),
	(
		"Nathalie Rousseau",
		"Female",
		"Administration",
		"Communications Officer",
		"Officer",
		"Port Louis HQ",
		43000,
		"2020-09-07",
	),
	(
		"Ashok Ramkissoon",
		"Male",
		"Research & Development",
		"Lab Technician",
		"Officer",
		"Réduit Research Station",
		32000,
		"2022-10-03",
	),
]

# Former employees for exits / separations demo
LEFT_STAFF = [
	(
		"Rakesh Domun",
		"Male",
		"Field Operations",
		"Agricultural Officer",
		"Officer",
		"Flacq",
		39500,
		"2014-05-12",
		"2026-04-30",
	),
	(
		"Sandrine Lafleur",
		"Female",
		"Administration",
		"Clerk",
		"Workman",
		"Port Louis HQ",
		23500,
		"2019-03-04",
		"2026-02-28",
	),
]

HOLIDAYS_2026 = [
	("2026-01-01", "New Year's Day"),
	("2026-01-02", "New Year Holiday"),
	("2026-02-01", "Abolition of Slavery"),
	("2026-02-15", "Maha Shivaratree"),
	("2026-02-17", "Chinese Spring Festival"),
	("2026-03-12", "Independence and Republic Day"),
	("2026-03-20", "Eid-ul-Fitr"),
	("2026-05-01", "Labour Day"),
	("2026-08-15", "Assumption of the Blessed Virgin Mary"),
	("2026-09-14", "Ganesh Chaturthi"),
	("2026-11-02", "Arrival of Indentured Labourers"),
	("2026-11-08", "Divali"),
	("2026-12-25", "Christmas Day"),
]

# Renames for leftover test employees so existing Karyo demo data looks real
RENAME_POOL = [
	"Sunil Teeluck",
	"Kavita Neerunjun",
	"Jean-Marc Adeline",
	"Shabnam Emrith",
	"Vishal Ramchurn",
	"Lindsay Perle",
	"Meera Sookun",
	"Ahmad Nazeer",
	"Pooja Beedasy",
	"Ryan Chintaram",
	"Sarita Fowdar",
	"Olivier Baguant",
	"Reshma Sewpaul",
	"Imran Peermamode",
	"Corinne Marion",
	"Deepak Rughoo",
	"Anisha Curpen",
	"Yannick Espitalier",
	"Bhavna Toolsee",
	"Steven Ah-Kine",
	"Nalini Padaruth",
]

MU_FIRST = [
	"Avinash",
	"Bhavish",
	"Chloé",
	"Dinesh",
	"Elodie",
	"Faizal",
	"Geeta",
	"Hansley",
	"Ishika",
	"Jonathan",
	"Keshini",
	"Ludovic",
	"Mala",
	"Naushad",
	"Oomila",
	"Pravin",
	"Reena",
	"Sanjiv",
	"Tania",
	"Uttam",
	"Véronique",
	"Warren",
	"Xavier",
	"Yuvraj",
	"Zainab",
]
MU_LAST = [
	"Auckloo",
	"Bissessur",
	"Coopoosamy",
	"Dawonauth",
	"Figaro",
	"Gooljar",
	"Hurdoyal",
	"Jhurry",
	"Koodoruth",
	"Lallmahomed",
	"Mooneesawmy",
	"Nundlall",
	"Oozeer",
	"Pyneeandee",
	"Ragoo",
	"Seetul",
	"Tirvengadum",
	"Uteem",
	"Valaydon",
	"Woochit",
]


def _block(label, fn):
	try:
		fn()
		frappe.db.commit()
		print(f"  OK   {label}")
	except Exception:
		frappe.db.rollback()
		print(f"  FAIL {label}")
		traceback.print_exc(limit=6)


def _exists(dt, filters):
	return frappe.db.exists(dt, filters)


def _insert(doc_dict, submit=False):
	doc = frappe.get_doc(doc_dict)
	doc.insert(ignore_permissions=True, ignore_mandatory=True)
	if submit:
		doc.submit()
	return doc


def _emp(full_name):
	name = frappe.db.get_value("Employee", {"employee_name": full_name, "company": COMPANY}, "name")
	if not name:
		frappe.throw(f"Employee {full_name} not found")
	return name


def _dept(label):
	return f"{label} - {ABBR}"


def _account(like, fallback=None):
	acc = frappe.db.get_value("Account", {"company": COMPANY, "account_name": like, "is_group": 0}, "name")
	if not acc:
		acc = frappe.db.get_value(
			"Account", {"company": COMPANY, "account_name": ["like", f"%{like}%"], "is_group": 0}, "name"
		)
	return acc or fallback


def _holidays():
	return {getdate(d) for (d, _label) in HOLIDAYS_2026}


def _working_days(start, end):
	"""Weekdays between start/end that are not Mauritian public holidays."""
	hols = _holidays()
	days, d = [], getdate(start)
	end = getdate(end)
	while d <= end:
		if d.weekday() < 5 and d not in hols:
			days.append(d)
		d = add_days(d, 1)
	return days


# ---------------------------------------------------------------- foundation


def company():
	if not frappe.db.exists("Company", COMPANY):
		frappe.get_doc(
			{
				"doctype": "Company",
				"company_name": COMPANY,
				"abbr": ABBR,
				"default_currency": CURRENCY,
				"country": "Mauritius",
				"create_chart_of_accounts_based_on": "Standard Template",
				"chart_of_accounts": "Standard",
			}
		).insert(ignore_permissions=True)


def holiday_list():
	if not frappe.db.exists("Holiday List", HOLIDAY_LIST):
		hl = frappe.get_doc(
			{
				"doctype": "Holiday List",
				"holiday_list_name": HOLIDAY_LIST,
				"from_date": "2026-01-01",
				"to_date": "2026-12-31",
			}
		)
		for d, label in HOLIDAYS_2026:
			hl.append("holidays", {"holiday_date": d, "description": label})
		# weekly offs: Saturday + Sunday
		d = date(2026, 1, 1)
		while d <= date(2026, 12, 31):
			if d.weekday() >= 5:
				hl.append("holidays", {"holiday_date": d, "description": "Weekly Off", "weekly_off": 1})
			d += timedelta(days=1)
		hl.insert(ignore_permissions=True)
	frappe.db.set_value("Company", COMPANY, "default_holiday_list", HOLIDAY_LIST)


def org_masters():
	for b in BRANCHES:
		if not frappe.db.exists("Branch", b):
			_insert({"doctype": "Branch", "branch": b})
	for d in DEPARTMENTS:
		if not frappe.db.exists("Department", _dept(d)):
			_insert({"doctype": "Department", "department_name": d, "company": COMPANY})
	for d in DESIGNATIONS:
		if not frappe.db.exists("Designation", d):
			_insert({"doctype": "Designation", "designation_name": d})
	for g in GRADES:
		if not frappe.db.exists("Employee Grade", g):
			_insert({"doctype": "Employee Grade", "__newname": g})
	if not frappe.db.exists("Employment Type", "Permanent"):
		_insert({"doctype": "Employment Type", "employee_type_name": "Permanent"})


def salary_components():
	comps = [
		("Basic", "B", "Earning", {}),
		("Transport Allowance", "TA", "Earning", {}),
		("Medical Allowance", "MA", "Earning", {}),
		("CSG", "CSG", "Deduction", {}),
		("NSF", "NSF", "Deduction", {}),
		("PAYE", "PAYE", "Deduction", {
			"variable_based_on_taxable_salary": 1,
			"is_income_tax_component": 1,
			"depends_on_payment_days": 0,
		}),
		("Retention Bonus", "RB", "Earning", {}),
		("Performance Incentive", "PI", "Earning", {}),
	]
	for name, abbr, ctype, extra in comps:
		if frappe.db.exists("Salary Component", name):
			if name == "PAYE" and frappe.db.get_value(
				"Salary Component", name, "depends_on_payment_days"
			):
				frappe.db.set_value(
					"Salary Component", name, "depends_on_payment_days", 0,
					update_modified=False,
				)
			continue
		doc = {
			"doctype": "Salary Component",
			"salary_component": name,
			"salary_component_abbr": abbr,
			"type": ctype,
		}
		doc.update(extra)
		_insert(doc)


def payroll_periods_and_slab():
	for pname, start, end in [
		("2025-2026", "2025-07-01", "2026-06-30"),
		("2026-2027", "2026-07-01", "2027-06-30"),
	]:
		if not _exists("Payroll Period", {"company": COMPANY, "start_date": start}):
			_insert(
				{
					"doctype": "Payroll Period",
					"__newname": f"{pname} ({ABBR})",
					"company": COMPANY,
					"start_date": start,
					"end_date": end,
				}
			)
	if frappe.db.exists("Income Tax Slab", TAX_SLAB):
		return
	brackets = [
		(0, 390000, 0),
		(390000, 430000, 2),
		(430000, 470000, 4),
		(470000, 530000, 6),
		(530000, 590000, 8),
		(590000, 890000, 10),
		(890000, 1190000, 12),
		(1190000, 1490000, 14),
		(1490000, 1890000, 16),
		(1890000, 2390000, 18),
		(2390000, 0, 20),
	]
	slab = frappe.get_doc(
		{
			"doctype": "Income Tax Slab",
			"__newname": TAX_SLAB,
			"company": COMPANY,
			"currency": CURRENCY,
			"effective_from": "2025-07-01",
			"allow_tax_exemption": 1,
		}
	)
	for frm, to, pct in brackets:
		slab.append("slabs", {"from_amount": frm, "to_amount": to, "percent_deduction": pct})
	slab.insert(ignore_permissions=True)
	slab.submit()


def salary_structure():
	if frappe.db.exists("Salary Structure", STRUCTURE):
		return
	ss = frappe.get_doc(
		{
			"doctype": "Salary Structure",
			"__newname": STRUCTURE,
			"company": COMPANY,
			"payroll_frequency": "Monthly",
			"currency": CURRENCY,
			"earnings": [
				{"salary_component": "Basic", "amount_based_on_formula": 1, "formula": "base"},
				{"salary_component": "Transport Allowance", "amount": 2600},
				{"salary_component": "Medical Allowance", "amount": 1500},
			],
			"deductions": [
				{"salary_component": "CSG", "amount_based_on_formula": 1, "formula": "base * 0.015"},
				{"salary_component": "NSF", "amount_based_on_formula": 1, "formula": "base * 0.01"},
				{"salary_component": "PAYE", "amount": 0},
			],
		}
	)
	ss.insert(ignore_permissions=True)
	ss.submit()


def employees():
	genders = {g.name for g in frappe.get_all("Gender")}
	for g in ("Male", "Female"):
		if g not in genders:
			_insert({"doctype": "Gender", "gender": g})
	rows = [(*s, None) for s in STAFF] + list(LEFT_STAFF)
	for full_name, gender, dept, desig, grade, branch, base, doj, *rest in rows:
		relieving = rest[0] if rest else None
		if frappe.db.get_value("Employee", {"employee_name": full_name, "company": COMPANY}):
			continue
		first, last = full_name.rsplit(" ", 1) if " " in full_name else (full_name, "")
		doj_d = getdate(doj)
		dob = date(doj_d.year - R.randint(22, 38), R.randint(1, 12), R.randint(1, 28))
		email = f"{first.split(' ')[0].lower()}.{last.lower().replace(' ', '')}@gmail.com"
		for a, b in (("é", "e"), ("è", "e"), ("ë", "e"), ("-", ""), ("ô", "o")):
			email = email.replace(a, b)
		emp = frappe.get_doc(
			{
				"doctype": "Employee",
				"first_name": first,
				"last_name": last,
				"gender": gender,
				"date_of_birth": dob,
				"date_of_joining": doj,
				"company": COMPANY,
				"department": _dept(dept),
				"designation": desig,
				"grade": grade,
				"branch": branch,
				"employment_type": "Permanent",
				"holiday_list": HOLIDAY_LIST,
				"status": "Left" if relieving else "Active",
				"relieving_date": relieving,
				"cell_number": f"5{R.randint(700, 989)} {R.randint(1000, 9999)}",
				"personal_email": email,
				"pb_eligible": 1,
			}
		)
		emp.insert(ignore_permissions=True, ignore_mandatory=True)
		from_date = max(doj_d, date(2026, 1, 1)) if not relieving else doj_d
		_insert(
			{
				"doctype": "Salary Structure Assignment",
				"employee": emp.name,
				"salary_structure": STRUCTURE,
				"company": COMPANY,
				"from_date": from_date,
				"base": base,
				"income_tax_slab": TAX_SLAB,
			},
			submit=True,
		)
	# request approvals (comp leave / attendance request / shift request) require
	# the employee-level approver to match the approving user
	for emp in frappe.get_all("Employee", filters={"company": COMPANY}, pluck="name"):
		frappe.db.set_value(
			"Employee",
			emp,
			{
				"leave_approver": "Administrator",
				"expense_approver": "Administrator",
				"shift_request_approver": "Administrator",
			},
			update_modified=False,
		)


# --------------------------------------------------------------------- leave


def leave_setup():
	if not frappe.db.exists("Leave Type", "Annual Leave"):
		_insert(
			{
				"doctype": "Leave Type",
				"leave_type_name": "Annual Leave",
				"karyo_mbc_leave_code": "ANN",
				"karyo_code_description": "Annual Leave for Contract Employees",
				"max_leaves_allowed": 22,
				"is_carry_forward": 1,
				"allow_encashment": 1,
				"encashment_threshold_days": 5,
				"earning_component": "Leave Encashment",
			}
		)
	if not frappe.db.exists("Leave Type", "Maternity Leave"):
		_insert({"doctype": "Leave Type", "leave_type_name": "Maternity Leave", "karyo_mbc_leave_code": "MAT", "karyo_code_description": "Maternity Leave", "max_leaves_allowed": 98})
	if not _exists("Leave Period", {"company": COMPANY, "from_date": "2026-01-01"}):
		_insert(
			{
				"doctype": "Leave Period",
				"company": COMPANY,
				"from_date": "2026-01-01",
				"to_date": "2026-12-31",
				"is_active": 1,
			}
		)


def leave_allocations():
	# SIL V1.1 demo baseline: contract Annual/Sick 21; Casual 11.
	allocs = [("Annual Leave", 21), ("Sick Leave", 21), ("Casual Leave", 11)]
	for emp in frappe.get_all("Employee", filters={"company": COMPANY, "status": "Active"}, pluck="name"):
		for lt, days in allocs:
			# Any submitted allocation intersecting the demo year is authoritative;
			# this makes reruns safe even when an allocation began before 1 January.
			if _exists(
				"Leave Allocation",
				{
					"employee": emp,
					"leave_type": lt,
					"docstatus": 1,
					"from_date": ("<=", "2026-12-31"),
					"to_date": (">=", "2026-01-01"),
				},
			):
				continue
			_insert(
				{
					"doctype": "Leave Allocation",
					"employee": emp,
					"leave_type": lt,
					"from_date": "2026-01-01",
					"to_date": "2026-12-31",
					"new_leaves_allocated": days,
				},
				submit=True,
			)


def leave_applications():
	if frappe.db.count("Leave Application", {"company": COMPANY}) >= 20:
		return
	reasons = {
		"Annual Leave": [
			"Family holiday",
			"Wedding in the family",
			"Personal matters",
			"Travel to Rodrigues",
		],
		"Sick Leave": ["Flu and fever", "Medical appointment", "Back pain", "Dental surgery"],
		"Casual Leave": ["Household emergency", "Child's school event", "Religious ceremony"],
	}
	emps = frappe.get_all("Employee", filters={"company": COMPANY, "status": "Active"}, pluck="name")
	wd = _working_days("2026-02-02", "2026-07-03")
	used = {}
	made = 0
	for emp in emps:
		for _ in range(R.randint(1, 2)):
			lt = R.choice(["Annual Leave", "Annual Leave", "Sick Leave", "Casual Leave"])
			start = R.choice(wd[: len(wd) - 5])
			length = R.randint(1, 4 if lt == "Annual Leave" else 2)
			end = wd[min(wd.index(start) + length - 1, len(wd) - 1)]
			if any(s <= end and start <= e for (s, e) in used.get(emp, [])):
				continue
			used.setdefault(emp, []).append((start, end))
			status = "Approved" if start < TODAY - timedelta(days=3) else R.choice(["Open", "Approved"])
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Leave Application",
						"employee": emp,
						"leave_type": lt,
						"from_date": start,
						"to_date": end,
						"description": R.choice(reasons[lt]),
						"status": status,
						"leave_approver": "Administrator",
						"posting_date": max(start - timedelta(days=R.randint(2, 10)), date(2026, 1, 5)),
					},
					submit=(status == "Approved"),
				)
				made += 1
			except Exception as e:
				frappe.db.rollback(save_point="demo_sp")
				print("       skip:", str(e)[:120])
	print(f"       leave applications: {made}")


def leave_extras():
	# a Saturday worked -> compensatory leave request
	for emp_name in ("Jean-Noël Baptiste", "Ravish Gopee"):
		emp = _emp(emp_name)
		work_day = date(2026, 5, 16)  # Saturday
		if not _exists("Attendance", {"employee": emp, "attendance_date": work_day}):
			_insert(
				{"doctype": "Attendance", "employee": emp, "attendance_date": work_day, "status": "Present"},
				submit=True,
			)
		if not _exists("Compensatory Leave Request", {"employee": emp, "work_from_date": work_day}):
			_insert(
				{
					"doctype": "Compensatory Leave Request",
					"employee": emp,
					"work_from_date": work_day,
					"work_end_date": work_day,
					"reason": "Field mission during weekend — anthracnose outbreak survey",
					"leave_type": "Compensatory Off",
				},
				submit=True,
			)
	# attendance request (work from home)
	emp = _emp("Divya Beeharry")
	if not _exists("Attendance Request", {"employee": emp}):
		_insert(
			{
				"doctype": "Attendance Request",
				"employee": emp,
				"from_date": date(2026, 6, 25),
				"to_date": date(2026, 6, 26),
				"reason": "Work From Home",
				"explanation": "Home internet installation — worked remotely on ESS portal module",
			},
			submit=True,
		)
	# leave encashment (draft if the computed amount fails validation)
	emp = _emp("Anand Seeruttun")
	if not _exists("Leave Encashment", {"employee": emp}):
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Leave Encashment",
					"employee": emp,
					"leave_type": "Annual Leave",
					"leave_period": frappe.db.get_value("Leave Period", {"company": COMPANY}, "name"),
					"encashment_date": date(2026, 6, 30),
				},
				submit=True,
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip encashment submit:", str(e)[:110])
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Leave Encashment",
						"employee": emp,
						"leave_type": "Annual Leave",
						"leave_period": frappe.db.get_value("Leave Period", {"company": COMPANY}, "name"),
						"encashment_date": date(2026, 6, 30),
					}
				)
			except Exception as e2:
				frappe.db.rollback(save_point="demo_sp")
				print("       skip encashment:", str(e2)[:110])


# ---------------------------------------------------------- attendance/shift


def attendance():
	if frappe.db.count("Attendance", {"company": COMPANY}) > 400:
		return
	emps = frappe.get_all(
		"Employee",
		filters={"company": COMPANY, "status": "Active"},
		fields=["name", "date_of_joining"],
	)
	on_leave = {}
	for la in frappe.get_all(
		"Leave Application",
		filters={"company": COMPANY, "status": "Approved", "docstatus": 1},
		fields=["employee", "from_date", "to_date"],
	):
		d = la.from_date
		while d <= la.to_date:
			on_leave.setdefault(la.employee, set()).add(d)
			d = add_days(d, 1)
	days = _working_days("2026-05-04", TODAY - timedelta(days=1))
	made = 0
	for e in emps:
		for d in days:
			if d < e.date_of_joining:
				continue
			if d in on_leave.get(e.name, set()):
				continue  # leave applications already mark these days
			if _exists("Attendance", {"employee": e.name, "attendance_date": d}):
				continue
			roll = R.random()
			status = "Present" if roll < 0.94 else ("Half Day" if roll < 0.97 else "Absent")
			frappe.db.savepoint("demo_sp")
			try:
				_insert(
					{
						"doctype": "Attendance",
						"employee": e.name,
						"attendance_date": d,
						"status": status,
					},
					submit=True,
				)
				made += 1
			except Exception as e:
				frappe.db.rollback(save_point="demo_sp")
				print("       skip:", str(e)[:120])
	print(f"       attendance records: {made}")


def checkins():
	if frappe.db.count("Employee Checkin") > 50:
		return
	emps = [
		_emp(n)
		for n in (
			"Julien Maurice",
			"Divya Beeharry",
			"Yashna Seebaluck",
			"Cédric Étienne",
			"Zaheer Atchia",
			"Vanessa Chung",
			"Kritika Ramdhony",
			"Ibrahim Cassim",
			"Li Wen Cheung",
			"Nathalie Rousseau",
		)
	]
	days = _working_days(TODAY - timedelta(days=10), TODAY - timedelta(days=1))
	for emp in emps:
		for d in days:
			t_in = f"{d} 08:{R.randint(30, 59):02d}:00"
			t_out = f"{d} 16:{R.randint(15, 59):02d}:00"
			for log_type, t in (("IN", t_in), ("OUT", t_out)):
				if not _exists("Employee Checkin", {"employee": emp, "time": t}):
					_insert({"doctype": "Employee Checkin", "employee": emp, "time": t, "log_type": log_type})


def shifts():
	if not frappe.db.exists("Shift Type", "Night Shift"):
		_insert(
			{
				"doctype": "Shift Type",
				"__newname": "Night Shift",
				"start_time": "22:00:00",
				"end_time": "06:00:00",
			}
		)
	day = frappe.get_doc("Shift Type", "Day Shift")
	if not day.start_time:
		day.start_time, day.end_time = "08:30:00", "16:30:00"
		day.save(ignore_permissions=True)
	assignments = [
		("Sylvio Legrand", "Day Shift"),
		("Dharmesh Beegoo", "Day Shift"),
		("Marie-Josée Perrine", "Day Shift"),
		("Georges Adolphe", "Night Shift"),
		("Cédric Étienne", "Day Shift"),
		("Zaheer Atchia", "Night Shift"),
	]
	for emp_name, shift in assignments:
		emp = _emp(emp_name)
		if not _exists("Shift Assignment", {"employee": emp, "shift_type": shift}):
			_insert(
				{
					"doctype": "Shift Assignment",
					"employee": emp,
					"shift_type": shift,
					"company": COMPANY,
					"start_date": "2026-01-05",
					"status": "Active",
				},
				submit=True,
			)
	emp = _emp("Zaheer Atchia")
	if not _exists("Shift Request", {"employee": emp}):
		_insert(
			{
				"doctype": "Shift Request",
				"employee": emp,
				"shift_type": "Day Shift",
				"from_date": date(2026, 8, 3),
				"approver": "Administrator",
				"status": "Draft",
			}
		)


# --------------------------------------------------------------- recruitment


def recruitment():
	openings = [
		(
			"Senior Agricultural Officer",
			"Field Operations",
			"Lead extension services in the northern zone, coordinate farmer field schools and manage a team of 4 field officers.",
		),
		(
			"Software Developer",
			"ICT",
			"Python developer to extend the Karyo HRMS platform — payroll engines, ESS portal and API integrations.",
		),
		(
			"HR Officer",
			"Human Resources",
			"Handle recruitment, onboarding and leave administration for a workforce of 150+ across 4 sites.",
		),
		(
			"Driver",
			"Field Operations",
			"Category B/C licence, field mission support across the island, vehicle log discipline required.",
		),
	]
	for title, dept, desc in openings:
		if not _exists("Job Opening", {"job_title": title, "company": COMPANY}):
			_insert(
				{
					"doctype": "Job Opening",
					"job_title": title,
					"designation": title if frappe.db.exists("Designation", title) else None,
					"department": _dept(dept),
					"company": COMPANY,
					"status": "Open",
					"description": desc,
					"currency": CURRENCY,
					"lower_range": 30000,
					"upper_range": 60000,
					"posted_on": "2026-05-15",
				}
			)
	sources = ["Website Listing", "Employee Referral", "Walk In"]
	statuses = ["Open", "Open", "Replied", "Hold", "Rejected", "Accepted"]
	applicants = []
	for i in range(12):
		fn, ln = MU_FIRST[i], MU_LAST[i]
		title = openings[i % 4][0]
		email = f"{fn.lower()}.{ln.lower()}@gmail.com".replace("é", "e")
		applicants.append((f"{fn} {ln}", email, title))
		if _exists("Job Applicant", {"email_id": email}):
			continue
		opening = frappe.db.get_value("Job Opening", {"job_title": title, "company": COMPANY}, "name")
		_insert(
			{
				"doctype": "Job Applicant",
				"applicant_name": f"{fn} {ln}",
				"email_id": email,
				"phone_number": f"5{R.randint(700, 989)} {R.randint(1000, 9999)}",
				"country": "Mauritius",
				"job_title": opening,
				"designation": title if frappe.db.exists("Designation", title) else None,
				"source": R.choice(sources),
				"status": statuses[i % len(statuses)],
				"cover_letter": f"Dear Hiring Manager, I wish to apply for the post of {title}. "
				"I hold relevant qualifications and several years of experience in the field.",
			}
		)
	frappe.get_doc("User", "Administrator").add_roles("Interviewer")
	for itype in ("Technical Round", "HR Round"):
		if not frappe.db.exists("Interview Type", itype):
			_insert({"doctype": "Interview Type", "__newname": itype, "description": itype})
	for skill in ("Agronomy", "Python", "Communication"):
		if not frappe.db.exists("Skill", skill):
			_insert({"doctype": "Skill", "skill_name": skill})
	if not frappe.db.exists("Interview Round", "Technical Assessment"):
		_insert(
			{
				"doctype": "Interview Round",
				"__newname": "Technical Assessment",
				"round_name": "Technical Assessment",
				"interview_type": "Technical Round",
				"expected_average_rating": 3.5,
				"interviewers": [{"user": "Administrator"}],
				"expected_skill_set": [{"skill": "Python"}, {"skill": "Communication"}],
			}
		)
	for i, (_aname, email, _title) in enumerate(applicants[:4]):
		applicant = frappe.db.get_value("Job Applicant", {"email_id": email}, "name")
		if applicant and not _exists("Interview", {"job_applicant": applicant}):
			_insert(
				{
					"doctype": "Interview",
					"job_applicant": applicant,
					"interview_round": "Technical Assessment",
					"scheduled_on": add_days(TODAY, 3 + i * 2) if i > 1 else date(2026, 6, 15 + i),
					"from_time": "10:00:00",
					"to_time": "11:00:00",
					"status": "Pending" if i > 1 else "Under Review",
				}
			)
	for _aname, email, title in applicants:
		applicant = frappe.db.get_value("Job Applicant", {"email_id": email, "status": "Accepted"}, "name")
		if not applicant or _exists("Job Offer", {"job_applicant": applicant}):
			continue
		_insert(
			{
				"doctype": "Job Offer",
				"job_applicant": applicant,
				"company": COMPANY,
				"designation": title if frappe.db.exists("Designation", title) else "Clerk",
				"offer_date": date(2026, 6, 26),
				"status": "Accepted",
			},
			submit=True,
		)
	referrer = _emp("Julien Maurice")
	if not _exists("Employee Referral", {"email": "kavish.bundhoo@gmail.com"}):
		_insert(
			{
				"doctype": "Employee Referral",
				"first_name": "Kavish",
				"last_name": "Bundhoo",
				"email": "kavish.bundhoo@gmail.com",
				"contact_no": "5799 2314",
				"for_designation": "Software Developer",
				"current_employer": "Ceridian Mauritius",
				"referrer": referrer,
				"is_applicable_for_referral_bonus": 1,
			},
			submit=True,
		)
	if not _exists("Job Requisition", {"designation": "Lab Technician", "company": COMPANY}):
		_insert(
			{
				"doctype": "Job Requisition",
				"designation": "Lab Technician",
				"department": _dept("Research & Development"),
				"no_of_positions": 1,
				"company": COMPANY,
				"status": "Pending",
				"requested_by": _emp("Anand Seeruttun"),
				"expected_by": date(2026, 9, 1),
				"description": "Replacement for retiring technician in the plant pathology laboratory.",
			}
		)


# ----------------------------------------------------------------- lifecycle


def lifecycle():
	promos = [
		("Cédric Étienne", "Lab Technician", "Senior Lab Technician"),
		("Ravish Gopee", "Agricultural Officer", "Senior Agricultural Officer"),
	]
	for emp_name, old, new in promos:
		emp = _emp(emp_name)
		if _exists("Employee Promotion", {"employee": emp}):
			continue
		if frappe.db.get_value("Employee", emp, "designation") != old:
			continue
		_insert(
			{
				"doctype": "Employee Promotion",
				"employee": emp,
				"promotion_date": date(2026, 7, 1),
				"promotion_details": [
					{"property": "Designation", "fieldname": "designation", "current": old, "new": new}
				],
			},
			submit=True,
		)
	emp = _emp("Prakash Callychurn")
	if not _exists("Employee Transfer", {"employee": emp}):
		_insert(
			{
				"doctype": "Employee Transfer",
				"employee": emp,
				"transfer_date": date(2026, 6, 1),
				"transfer_details": [
					{"property": "Branch", "fieldname": "branch", "current": "Flacq", "new": "Curepipe"}
				],
			},
			submit=True,
		)
	for gt in ("Workplace Conflict", "Compensation Dispute", "Working Conditions"):
		if not frappe.db.exists("Grievance Type", gt):
			_insert({"doctype": "Grievance Type", "__newname": gt, "description": gt})
	griev = [
		(
			"Sylvio Legrand",
			"Working Conditions",
			"No rest area at the Flacq depot for drivers between missions.",
			"Resolved",
		),
		(
			"Vanessa Chung",
			"Workplace Conflict",
			"Repeated scheduling conflicts with the registry desk roster.",
			"Open",
		),
	]
	for emp_name, gtype, desc, status in griev:
		emp = _emp(emp_name)
		if _exists("Employee Grievance", {"raised_by": emp}):
			continue
		_insert(
			{
				"doctype": "Employee Grievance",
				"subject": desc[:60],
				"raised_by": emp,
				"date": date(2026, 5, 20),
				"grievance_type": gtype,
				"description": desc,
				"status": status,
				"grievance_against_party": "Company",
				"grievance_against": COMPANY,
			}
		)
	emp = _emp("Rakesh Domun")
	if not _exists("Exit Interview", {"employee": emp}):
		_insert(
			{
				"doctype": "Exit Interview",
				"employee": emp,
				"date": date(2026, 4, 24),
				"status": "Completed",
				"employee_status": "Exit Confirmed",
			}
		)
	offer = frappe.db.get_value(
		"Job Offer", {"company": COMPANY, "status": "Accepted"}, ["name", "job_applicant"], as_dict=True
	)
	if offer and not _exists("Employee Onboarding", {"job_applicant": offer.job_applicant}):
		applicant = frappe.get_doc("Job Applicant", offer.job_applicant)
		_insert(
			{
				"doctype": "Employee Onboarding",
				"job_applicant": offer.job_applicant,
				"job_offer": offer.name,
				"employee_name": applicant.applicant_name,
				"company": COMPANY,
				"designation": "Software Developer",
				"department": _dept("ICT"),
				"date_of_joining": date(2026, 8, 3),
				"boarding_begins_on": date(2026, 7, 27),
				"holiday_list": HOLIDAY_LIST,
				"activities": [
					{"activity_name": "Sign employment contract", "role": "HR Manager", "duration": 1},
					{
						"activity_name": "Create user accounts and email",
						"role": "System Manager",
						"duration": 1,
					},
					{"activity_name": "Issue laptop and access badge", "role": "HR User", "duration": 2},
					{"activity_name": "Team induction at ICT department", "role": "HR User", "duration": 3},
				],
			}
		)


# ------------------------------------------------------------------ expenses


def expenses():
	types = [
		("Travel", "Travel Expenses"),
		("Meals", "Entertainment Expenses"),
		("Fuel", "Travel Expenses"),
		("Accommodation", "Travel Expenses"),
		("Training & Seminars", "Miscellaneous Expenses"),
	]
	for tname, acc_name in types:
		acc = _account(acc_name)
		if not frappe.db.exists("Expense Claim Type", tname):
			doc = {"doctype": "Expense Claim Type", "expense_type": tname}
			if acc:
				doc["accounts"] = [{"company": COMPANY, "default_account": acc}]
			_insert(doc)
		else:
			ect = frappe.get_doc("Expense Claim Type", tname)
			if acc and not any(a.company == COMPANY for a in ect.accounts):
				ect.append("accounts", {"company": COMPANY, "default_account": acc})
				ect.save(ignore_permissions=True)
	payable = _account("Creditors")
	cost_center = frappe.db.get_value("Company", COMPANY, "cost_center")
	claims = [
		(
			"Ravish Gopee",
			"Travel",
			3400,
			"Field mission to Rodrigues — inter-island ferry and taxi",
			date(2026, 6, 8),
		),
		(
			"Leela Chuttoo",
			"Fuel",
			1850,
			"Fuel for farmer field school visits, Flacq region",
			date(2026, 6, 12),
		),
		(
			"Anand Seeruttun",
			"Training & Seminars",
			12500,
			"Registration — Indian Ocean Agronomy Conference, Réunion",
			date(2026, 5, 22),
		),
		("Yashna Seebaluck", "Meals", 950, "Working lunch — recruitment panel, 4 pax", date(2026, 6, 18)),
		(
			"Ibrahim Cassim",
			"Travel",
			620,
			"Taxi to Ministry of Agro-Industry for tender submission",
			date(2026, 6, 25),
		),
		(
			"Jean-Noël Baptiste",
			"Accommodation",
			5400,
			"Overnight stay — storm damage assessment, south",
			date(2026, 6, 5),
		),
		("Kritika Ramdhony", "Fuel", 1620, "Fuel — extension visits Curepipe/Midlands", date(2026, 7, 2)),
		(
			"Nathalie Rousseau",
			"Meals",
			2100,
			"Press briefing catering — national agri-fair launch",
			date(2026, 7, 6),
		),
	]
	for i, (emp_name, etype, amount, desc, dt) in enumerate(claims):
		emp = _emp(emp_name)
		if _exists("Expense Claim", {"employee": emp, "total_claimed_amount": amount}):
			continue
		submit = i < 6
		doc = frappe.get_doc(
			{
				"doctype": "Expense Claim",
				"employee": emp,
				"expense_approver": "Administrator",
				"approval_status": "Approved" if submit else "Draft",
				"company": COMPANY,
				"payable_account": payable,
				"cost_center": cost_center,
				"posting_date": dt,
				"expenses": [
					{
						"expense_date": dt,
						"expense_type": etype,
						"description": desc,
						"amount": amount,
						"sanctioned_amount": amount,
						"cost_center": cost_center,
					}
				],
			}
		)
		doc.insert(ignore_permissions=True, ignore_mandatory=True)
		if submit:
			frappe.db.savepoint("demo_sp")
			try:
				doc.submit()
			except Exception as e:
				frappe.db.rollback(save_point="demo_sp")
				print("       skip:", str(e)[:120])
	advances = [
		("Ravish Gopee", 8000, "Field mission advance — Rodrigues extension programme"),
		("Sylvio Legrand", 3000, "Fuel float for southern field missions"),
		("Priyanka Dookun", 15000, "Conference travel advance — SADC research symposium"),
	]
	adv_account = _account("Employee Advances") or _account("Cash")
	if adv_account and frappe.db.get_value("Account", adv_account, "account_type") != "Receivable":
		frappe.db.set_value("Account", adv_account, "account_type", "Receivable")
	for emp_name, amount, purpose in advances:
		emp = _emp(emp_name)
		if _exists("Employee Advance", {"employee": emp}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Employee Advance",
					"employee": emp,
					"purpose": purpose,
					"advance_amount": amount,
					"posting_date": date(2026, 6, 15),
					"advance_account": adv_account,
					"exchange_rate": 1,
					"company": COMPANY,
				},
				submit=True,
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])
	for p in ("Field Mission", "Conference", "Training"):
		if not frappe.db.exists("Purpose of Travel", p):
			_insert({"doctype": "Purpose of Travel", "purpose_of_travel": p})
	travels = [
		("Priyanka Dookun", "International", "Conference", "SADC agricultural research symposium, Pretoria"),
		("Ravish Gopee", "Domestic", "Field Mission", "Extension support mission to Rodrigues — 5 days"),
		("Marie-Ange Laurent", "International", "Training", "HR analytics masterclass, Johannesburg"),
	]
	for emp_name, ttype, purpose, desc in travels:
		emp = _emp(emp_name)
		if _exists("Travel Request", {"employee": emp}):
			continue
		_insert(
			{
				"doctype": "Travel Request",
				"employee": emp,
				"travel_type": ttype,
				"purpose_of_travel": purpose,
				"travel_funding": "Require Full Funding",
				"description": desc,
			}
		)


def fleet():
	vehicles = [
		("4521 JN 24", "Toyota", "Hilux", "Diesel", 45210, "Sylvio Legrand"),
		("2287 FM 22", "Nissan", "NV350", "Diesel", 88450, "Dharmesh Beegoo"),
	]
	for plate, make, model, fuel, odo, emp_name in vehicles:
		if frappe.db.exists("Vehicle", plate):
			continue
		_insert(
			{
				"doctype": "Vehicle",
				"license_plate": plate,
				"make": make,
				"model": model,
				"fuel_type": fuel,
				"uom": "Litre",
				"last_odometer": odo,
				"acquisition_date": date(2024, 3, 1),
				"employee": _emp(emp_name),
				"location": "Port Louis HQ",
			}
		)
	if not frappe.db.exists("Driver", {"full_name": "Sylvio Legrand"}):
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Driver",
					"full_name": "Sylvio Legrand",
					"employee": _emp("Sylvio Legrand"),
					"status": "Active",
				}
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])
	logs = [
		("4521 JN 24", "Sylvio Legrand", date(2026, 7, 1), 45480, 42.5),
		("4521 JN 24", "Sylvio Legrand", date(2026, 7, 7), 45790, 38.0),
		("2287 FM 22", "Dharmesh Beegoo", date(2026, 7, 3), 88720, 51.2),
	]
	for plate, emp_name, dt, odo, fuel_qty in logs:
		if _exists("Vehicle Log", {"license_plate": plate, "date": dt}):
			continue
		_insert(
			{
				"doctype": "Vehicle Log",
				"license_plate": plate,
				"employee": _emp(emp_name),
				"date": dt,
				"odometer": odo,
				"fuel_qty": fuel_qty,
				"price": 61.9,
			},
			submit=True,
		)


# --------------------------------------------------------------- performance


def performance():
	kras = ["Research Output", "Extension Services Delivery", "Operational Efficiency", "Team Development"]
	for k in kras:
		if not frappe.db.exists("KRA", k):
			_insert({"doctype": "KRA", "title": k})
	for c in ("Communication", "Initiative", "Reliability"):
		if not frappe.db.exists("Employee Feedback Criteria", c):
			_insert({"doctype": "Employee Feedback Criteria", "criteria": c})
	template = "MAI Officer Template 2026"
	if not frappe.db.exists("Appraisal Template", template):
		_insert(
			{
				"doctype": "Appraisal Template",
				"__newname": template,
				"template_title": template,
				"goals": [
					{"kra": "Research Output", "per_weightage": 30},
					{"kra": "Extension Services Delivery", "per_weightage": 30},
					{"kra": "Operational Efficiency", "per_weightage": 25},
					{"kra": "Team Development", "per_weightage": 15},
				],
				"rating_criteria": [
					{"criteria": "Communication", "per_weightage": 40},
					{"criteria": "Initiative", "per_weightage": 30},
					{"criteria": "Reliability", "per_weightage": 30},
				],
			}
		)
	cycle = "Jan-Jun 2026"
	appraisees = [
		"Ravish Gopee",
		"Leela Chuttoo",
		"Kritika Ramdhony",
		"Cédric Étienne",
		"Julien Maurice",
		"Yashna Seebaluck",
	]
	if not frappe.db.exists("Appraisal Cycle", cycle):
		_insert(
			{
				"doctype": "Appraisal Cycle",
				"cycle_name": cycle,
				"company": COMPANY,
				"start_date": "2026-01-01",
				"end_date": "2026-06-30",
				"kra_evaluation_method": "Manual Rating",
				"appraisees": [{"employee": _emp(n), "appraisal_template": template} for n in appraisees],
			}
		)
	for n in appraisees:
		emp = _emp(n)
		if _exists("Appraisal", {"employee": emp, "appraisal_cycle": cycle}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			doc = frappe.get_doc(
				{
					"doctype": "Appraisal",
					"employee": emp,
					"appraisal_cycle": cycle,
					"appraisal_template": template,
					"company": COMPANY,
					"rate_goals_manually": 1,
				}
			)
			doc.set_kras_and_rating_criteria()
			for row in doc.appraisal_kra:
				row.goal_score = R.randint(3, 5)
			for row in doc.self_ratings:
				row.rating = R.uniform(0.6, 1.0)
			doc.insert(ignore_permissions=True, ignore_mandatory=True)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])
	goals = [
		("Julien Maurice", "Ship ESS mobile portal v1", 70),
		("Divya Beeharry", "Automate payroll regression test-pack", 45),
		("Ravish Gopee", "Run 12 farmer field schools in the north", 60),
		("Priyanka Dookun", "Publish 2 peer-reviewed papers", 50),
		("Yashna Seebaluck", "Digitise employee files (150 dossiers)", 85),
		("Ibrahim Cassim", "Reduce procurement cycle time to 15 days", 30),
	]
	for emp_name, goal, progress in goals:
		emp = _emp(emp_name)
		if _exists("Goal", {"employee": emp, "goal_name": goal}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Goal",
					"goal_name": goal,
					"employee": emp,
					"start_date": "2026-01-05",
					"end_date": "2026-12-18",
					"progress": progress,
					"appraisal_cycle": cycle,
					"kra": "Operational Efficiency",
				}
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])


# ------------------------------------------------------------------ training


def training():
	programs = [
		(
			"Pesticide Safety & Handling",
			"Dr S. Facknath",
			"Safe storage, mixing and application of phytosanitary products; MSDS literacy.",
		),
		(
			"Digital Skills for Extension Officers",
			"Karyo Academy",
			"Tablets in the field: e-forms, GPS plot mapping and the Karyo mobile app.",
		),
	]
	for pname, trainer, desc in programs:
		if not frappe.db.exists("Training Program", pname):
			_insert(
				{
					"doctype": "Training Program",
					"training_program": pname,
					"trainer_name": trainer,
					"description": desc,
					"status": "Scheduled",
				}
			)
	attendees = [
		"Ravish Gopee",
		"Leela Chuttoo",
		"Kritika Ramdhony",
		"Farhan Rojoa",
		"Prakash Callychurn",
		"Anjali Motah",
	]
	past = "Pesticide Safety Workshop — May 2026"
	if not _exists("Training Event", {"event_name": past}):
		ev = frappe.get_doc(
			{
				"doctype": "Training Event",
				"event_name": past,
				"training_program": "Pesticide Safety & Handling",
				"type": "Workshop",
				"level": "Intermediate",
				"trainer_name": "Dr S. Facknath",
				"company": COMPANY,
				"start_time": "2026-05-19 09:00:00",
				"end_time": "2026-05-20 16:00:00",
				"introduction": "Two-day practical workshop on pesticide safety for field staff.",
				"location": "Réduit Research Station",
				"employees": [{"employee": _emp(n), "attendance": "Present"} for n in attendees],
			}
		)
		ev.insert(ignore_permissions=True, ignore_mandatory=True)
		ev.submit()
		ev.db_set("event_status", "Completed")
		result = frappe.get_doc(
			{
				"doctype": "Training Result",
				"training_event": ev.name,
				"employees": [
					{
						"employee": _emp(n),
						"hours": 14,
						"grade": R.choice(["A", "A", "B", "B+"]),
						"comments": "Completed practical assessment.",
					}
					for n in attendees[:4]
				],
			}
		)
		result.insert(ignore_permissions=True, ignore_mandatory=True)
		result.submit()
		for n in attendees[:2]:
			_insert(
				{
					"doctype": "Training Feedback",
					"employee": _emp(n),
					"training_event": ev.name,
					"feedback": "Very hands-on. The MSDS module should be repeated annually.",
				},
				submit=True,
			)
	upcoming = "Digital Field Tools Bootcamp — Aug 2026"
	if not _exists("Training Event", {"event_name": upcoming}):
		ev = frappe.get_doc(
			{
				"doctype": "Training Event",
				"event_name": upcoming,
				"training_program": "Digital Skills for Extension Officers",
				"type": "Workshop",
				"level": "Beginner",
				"trainer_name": "Karyo Academy",
				"company": COMPANY,
				"start_time": "2026-08-11 09:00:00",
				"end_time": "2026-08-12 16:00:00",
				"introduction": "Hands-on bootcamp: e-forms, GPS plot mapping, Karyo mobile app.",
				"location": "Port Louis HQ — Training Room 2",
				"employees": [{"employee": _emp(n), "attendance": "Present"} for n in attendees[:4]],
			}
		)
		ev.insert(ignore_permissions=True, ignore_mandatory=True)
		ev.submit()


# ------------------------------------------------------------ tax & benefits


def tax_benefits():
	if not frappe.db.exists("Employee Tax Exemption Category", "Retirement Savings"):
		_insert(
			{
				"doctype": "Employee Tax Exemption Category",
				"__newname": "Retirement Savings",
				"max_amount": 50000,
				"is_active": 1,
			}
		)
	if not frappe.db.exists("Employee Tax Exemption Sub Category", "Private Pension Contribution"):
		_insert(
			{
				"doctype": "Employee Tax Exemption Sub Category",
				"__newname": "Private Pension Contribution",
				"exemption_category": "Retirement Savings",
				"max_amount": 50000,
				"is_active": 1,
			}
		)
	period = frappe.db.get_value("Payroll Period", {"company": COMPANY, "start_date": "2026-07-01"}, "name")
	for emp_name, amount in [("Kevin Li Ying", 42000), ("Anand Seeruttun", 50000)]:
		emp = _emp(emp_name)
		if _exists("Employee Tax Exemption Declaration", {"employee": emp}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Employee Tax Exemption Declaration",
					"employee": emp,
					"payroll_period": period,
					"company": COMPANY,
					"currency": CURRENCY,
					"declarations": [
						{
							"exemption_sub_category": "Private Pension Contribution",
							"exemption_category": "Retirement Savings",
							"amount": amount,
							"max_amount": 50000,
						}
					],
				},
				submit=True,
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])
	emp = _emp("Julien Maurice")
	if not _exists("Retention Bonus", {"employee": emp}):
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Retention Bonus",
					"employee": emp,
					"company": COMPANY,
					"bonus_payment_date": date(2026, 12, 31),
					"bonus_amount": 25000,
					"salary_component": "Retention Bonus",
				},
				submit=True,
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])
	incentives = [("Ravish Gopee", 5000), ("Yashna Seebaluck", 4000), ("Leela Chuttoo", 4500)]
	for emp_name, amount in incentives:
		emp = _emp(emp_name)
		if _exists("Employee Incentive", {"employee": emp}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Employee Incentive",
					"employee": emp,
					"company": COMPANY,
					"incentive_amount": amount,
					"payroll_date": date(2026, 7, 25),
					"salary_component": "Performance Incentive",
				},
				submit=True,
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])


# ------------------------------------------------------------------- payroll


def salary_slips():
	if frappe.db.count("Salary Slip", {"company": COMPANY}) >= 20:
		return
	made = 0
	for emp in frappe.get_all(
		"Employee",
		filters={"company": COMPANY, "status": "Active", "date_of_joining": ["<=", "2026-06-01"]},
		pluck="name",
	):
		if _exists("Salary Slip", {"employee": emp, "start_date": "2026-06-01"}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Salary Slip",
					"employee": emp,
					"start_date": "2026-06-01",
					"end_date": "2026-06-30",
					"company": COMPANY,
					"posting_date": "2026-06-30",
				},
				submit=True,
			)
			made += 1
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])
	print(f"       salary slips (June 2026): {made}")


def timesheets():
	for at in ("Field Visit", "Lab Analysis", "Software Development"):
		if not frappe.db.exists("Activity Type", at):
			_insert({"doctype": "Activity Type", "activity_type": at})
	sheets = [
		("Julien Maurice", "Software Development", 8),
		("Cédric Étienne", "Lab Analysis", 7),
		("Ravish Gopee", "Field Visit", 8),
	]
	for emp_name, activity, hours in sheets:
		emp = _emp(emp_name)
		if _exists("Timesheet", {"employee": emp}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_insert(
				{
					"doctype": "Timesheet",
					"employee": emp,
					"company": COMPANY,
					"time_logs": [
						{"activity_type": activity, "from_time": "2026-07-06 09:00:00", "hours": hours},
						{"activity_type": activity, "from_time": "2026-07-07 09:00:00", "hours": hours},
					],
				},
				submit=True,
			)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])


# ------------------------------------------------------- karyo PB and loans


def karyo_pb_loans():
	from karyo.setup.demo import _active_loan, _pb_bank_and_earn, _pb_claim

	pb_emps = [
		"Ravish Gopee",
		"Leela Chuttoo",
		"Kritika Ramdhony",
		"Julien Maurice",
		"Yashna Seebaluck",
		"Cédric Étienne",
		"Zaheer Atchia",
		"Ibrahim Cassim",
		"Li Wen Cheung",
		"Anjali Motah",
		"Prakash Callychurn",
		"Nathalie Rousseau",
	]
	bases = {name: base for (name, _g, _d, _des, _gr, _b, base, _doj) in STAFF}
	for n in pb_emps:
		emp = _emp(n)
		if frappe.db.exists("Passage Benefit Bank", {"employee": emp}):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			_pb_bank_and_earn(emp, bases[n])
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])
	for n in pb_emps[:2]:
		emp = _emp(n)
		if not frappe.db.exists("Passage Benefit Application", {"employee": emp}):
			frappe.db.savepoint("demo_sp")
			try:
				_pb_claim(emp)
			except Exception as e:
				frappe.db.rollback(save_point="demo_sp")
				print("       skip:", str(e)[:120])
	loans = [
		("Julien Maurice", ["Ravish Gopee", "Ibrahim Cassim"]),
		("Leela Chuttoo", ["Kritika Ramdhony"]),
		("Ibrahim Cassim", None),
	]
	for emp_name, guarantor_names in loans:
		emp = _emp(emp_name)
		if frappe.db.exists("Karyo Loan", {"employee": emp}):
			continue
		guarantors = [_emp(g) for g in guarantor_names] if guarantor_names else None
		frappe.db.savepoint("demo_sp")
		try:
			_active_loan(emp, COMPANY, guarantors=guarantors)
		except Exception as e:
			frappe.db.rollback(save_point="demo_sp")
			print("       skip:", str(e)[:120])


# ----------------------------------------------------- cleanup of test names


def rename_test_employees():
	stale = frappe.get_all(
		"Employee",
		filters={
			"employee_name": [
				"in",
				["Karyo AutoBuild", "_Test Employee", "_Test Employee 1", "_Test Employee 2"],
			]
		},
		pluck="name",
		order_by="name",
	)
	renamed = []
	for i, emp in enumerate(stale):
		if i >= len(RENAME_POOL):
			break
		full = RENAME_POOL[i]
		first, last = full.rsplit(" ", 1)
		frappe.db.set_value(
			"Employee",
			emp,
			{"first_name": first, "middle_name": "", "last_name": last, "employee_name": full},
			update_modified=False,
		)
		renamed.append(emp)
	if not renamed:
		return
	# propagate the denormalized employee_name everywhere
	tables = frappe.get_all(
		"DocField",
		filters={"fieldname": "employee_name", "fieldtype": ["in", ["Data", "Read Only"]]},
		pluck="parent",
	)
	ids = tuple(renamed)
	for dt in sorted(set(tables)):
		if dt == "Employee" or not frappe.get_meta(dt).has_field("employee"):
			continue
		frappe.db.savepoint("demo_sp")
		try:
			frappe.db.sql(
				f"""update `tab{dt}` t join `tabEmployee` e on t.employee = e.name
				set t.employee_name = e.employee_name where t.employee in %(ids)s""",
				{"ids": ids},
			)
		except Exception:
			pass
	print(f"       renamed {len(renamed)} test employees")


def set_defaults():
	frappe.db.set_single_value("Global Defaults", "default_company", COMPANY)
	frappe.clear_cache()


def seed():
	print(f"Karyo HR demo seed — {COMPANY}")
	_block("company", company)
	_block("holiday list", holiday_list)
	_block("org masters", org_masters)
	_block("salary components", salary_components)
	_block("payroll periods + tax slab", payroll_periods_and_slab)
	_block("salary structure", salary_structure)
	_block("employees + assignments", employees)
	_block("leave setup", leave_setup)
	_block("leave allocations", leave_allocations)
	_block("leave applications", leave_applications)
	_block("leave extras", leave_extras)
	_block("attendance", attendance)
	_block("checkins", checkins)
	_block("shifts", shifts)
	_block("recruitment", recruitment)
	_block("lifecycle", lifecycle)
	_block("expenses & travel", expenses)
	_block("fleet", fleet)
	_block("performance", performance)
	_block("training", training)
	_block("tax & benefits", tax_benefits)
	_block("salary slips", salary_slips)
	_block("timesheets", timesheets)
	_block("karyo PB + loans", karyo_pb_loans)
	_block("rename test employees", rename_test_employees)
	_block("global defaults", set_defaults)
	print("Done.")


def verify():
	from frappe.desk.query_report import run

	r = run(
		"Monthly Attendance Sheet",
		filters={"filter_based_on": "Month", "month": "06", "year": "2026", "company": COMPANY},
		ignore_prepared_report=True,
	)
	print("ATT_SHEET_ROWS", len(r.get("result") or []))
	pb = frappe.get_all(
		"Passage Benefit Bank", fields=["employee_name", "current_balance"], order_by="current_balance desc", limit=4
	)
	print("PB_TOP", [(p.employee_name, p.current_balance) for p in pb])
	ln = frappe.get_all("Karyo Loan", filters={"docstatus": 1}, fields=["employee_name", "status"])
	print("LOANS", [(l.employee_name, l.status) for l in ln])
