"""Payroll bank file generation for the UAT payroll flow."""

import hashlib
import re

import frappe
from frappe import _
from frappe.utils import flt, getdate, now_datetime


BANK_PAYMENT_MODES = {"bank", "bank transfer", "electronic transfer", "wire transfer"}
NON_BANK_PAYMENT_MODES = {"cash", "cheque", "check"}


def _ascii(value, width=None):
	text = re.sub(r"[^\x20-\x7E]", " ", str(value or "")).strip()
	text = re.sub(r"\s+", " ", text)
	return text[:width] if width else text


def _is_bank_paid(row):
	mode = (row.mode_of_payment or "").strip().lower()
	if mode in NON_BANK_PAYMENT_MODES:
		return False
	if mode in BANK_PAYMENT_MODES:
		return True
	return bool(
		(row.bank_name and row.bank_account_no)
		or (row.get("karyo_primary_remittance_bank") and row.get("karyo_primary_remittance_account"))
		or (row.get("karyo_secondary_remittance_bank") and row.get("karyo_secondary_remittance_account"))
	)


def _is_target_bank(row, bank_code):
	bank = (row.bank_name or "").lower()
	code = (bank_code or "").lower()
	if code == "mcb":
		return "mcb" in bank or "mauritius commercial bank" in bank
	return code and code in bank


def _cycle_slips(cycle, bank_code):
	if not cycle.payroll_entry:
		frappe.throw(_("Payroll Cycle has no Payroll Entry."))
	meta = frappe.get_meta("Salary Slip")
	rows = frappe.get_all(
		"Salary Slip",
		filters={"payroll_entry": cycle.payroll_entry, "docstatus": 1, "company": cycle.company},
		fields=[
			"name", "employee", "employee_name", "start_date", "end_date", "posting_date",
			"mode_of_payment", "bank_name", "bank_account_no", "net_pay",
		] + [
			fieldname for fieldname in (
				"karyo_primary_remittance_bank",
				"karyo_primary_remittance_account",
				"karyo_primary_remittance_amount",
				"karyo_secondary_remittance_bank",
				"karyo_secondary_remittance_account",
				"karyo_secondary_remittance_amount",
			) if meta.has_field(fieldname)
		],
		order_by="employee asc, name asc",
		limit_page_length=0,
	)
	included, seen = [], set()
	for row in rows:
		if row.employee in seen or not _is_bank_paid(row):
			continue
		if not _slip_payments(row, bank_code):
			continue
		seen.add(row.employee)
		included.append(row)
	return included


def _slip_payments(slip, bank_code):
	"""Return payable bank rows for one slip, honoring primary/secondary split fields."""
	split_rows = []
	for label in ("primary", "secondary"):
		bank = slip.get(f"karyo_{label}_remittance_bank")
		account = slip.get(f"karyo_{label}_remittance_account")
		amount = flt(slip.get(f"karyo_{label}_remittance_amount"), 2)
		if amount > 0 and bank and account:
			split_rows.append({"bank_name": bank, "account": account, "amount": amount, "destination": label.title()})
	if split_rows:
		return [
			row for row in split_rows
			if _is_target_bank(frappe._dict(bank_name=row["bank_name"]), bank_code)
		]
	if _is_target_bank(slip, bank_code):
		return [{
			"bank_name": slip.bank_name,
			"account": slip.bank_account_no,
			"amount": flt(slip.net_pay, 2),
			"destination": "Primary",
		}]
	return []


def bank_paid_slip_count(payroll_cycle):
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	if not cycle.payroll_entry:
		return 0
	meta = frappe.get_meta("Salary Slip")
	rows = frappe.get_all(
		"Salary Slip",
		filters={"payroll_entry": cycle.payroll_entry, "docstatus": 1, "company": cycle.company},
		fields=["mode_of_payment", "bank_name", "bank_account_no"] + [
			fieldname for fieldname in (
				"karyo_primary_remittance_bank",
				"karyo_primary_remittance_account",
				"karyo_secondary_remittance_bank",
				"karyo_secondary_remittance_account",
			) if meta.has_field(fieldname)
		],
		limit_page_length=0,
	)
	return sum(1 for row in rows if _is_bank_paid(row))


def bank_artifact_exists(payroll_cycle, bank_code="MCB"):
	return bool(
		frappe.db.sql(
			"""
			select name from `tabPayroll Cycle Artifact`
			where parent=%s and parenttype='Payroll Cycle'
				and artifact_type='Bank File'
				and status in ('Generated','Verified','Released')
			""",
			payroll_cycle,
		)
	)


def build_mcb_ascii(payroll_cycle, file_name=None):
	"""Build the MCB UAT ASCII file and persist it as a cycle artifact."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle)
	cycle.check_permission("read")
	if cycle.docstatus == 2:
		frappe.throw(_("Cancelled Payroll Cycles cannot generate bank files."))
	slips = _cycle_slips(cycle, "MCB")
	if not slips:
		frappe.throw(_("No submitted MCB bank-paid Salary Slips are available for this Payroll Cycle."))
	payments = [
		frappe._dict({"slip": row, **payment})
		for row in slips
		for payment in _slip_payments(row, "MCB")
	]
	if not payments:
		frappe.throw(_("No MCB remittance rows are available for this Payroll Cycle."))
	period_label = getdate(cycle.end_date).strftime("%b%Y").upper()
	file_name = _ascii(file_name or f"{_ascii(cycle.company, 12)}_{period_label}.txt")
	total = sum(flt(row.amount) for row in payments)
	lines = [
		"01|{company}|{file_name}|{payment_date}|{count}|{total:.2f}".format(
			company=_ascii(cycle.company, 20),
			file_name=file_name,
			payment_date=getdate(cycle.payment_date),
			count=len(payments),
			total=total,
		)
	]
	for row in payments:
		lines.append(
			"02|{employee}|{name}|{account}|{amount:.2f}|{slip}|{destination}".format(
				employee=_ascii(row.slip.employee, 20),
				name=_ascii(row.slip.employee_name, 40),
				account=_ascii(row.account, 34),
				amount=flt(row.amount),
				slip=_ascii(row.slip.name, 30),
				destination=_ascii(row.destination, 10),
			)
		)
	lines.append(f"99|{len(payments)}|{total:.2f}")
	content = "\r\n".join(lines) + "\r\n"
	content_hash = hashlib.sha256(content.encode("ascii")).hexdigest()
	_store_artifact(cycle, file_name, content, content_hash)
	return {
		"payroll_cycle": cycle.name,
		"file_name": file_name,
		"bank": "MCB",
		"employees": len(slips),
		"payments": len(payments),
		"total": total,
		"content": content,
		"content_hash": content_hash,
	}


def _store_artifact(cycle, file_name, content, content_hash):
	from frappe.utils.file_manager import save_file

	file_doc = save_file(file_name, content.encode("ascii"), cycle.doctype, cycle.name, is_private=1)
	existing = next(
		(row for row in cycle.get("artifacts") if row.artifact_name == file_name and row.artifact_type == "Bank File"),
		None,
	)
	row = existing or cycle.append("artifacts", {})
	row.update(
		{
			"artifact_type": "Bank File",
			"artifact_name": file_name,
			"status": "Generated",
			"file": file_doc.file_url,
			"generated_on": now_datetime(),
			"content_hash": content_hash,
			"reference_doctype": "Payroll Entry",
			"reference_name": cycle.payroll_entry,
		}
	)
	cycle.flags.ignore_permissions = True
	cycle.save()
