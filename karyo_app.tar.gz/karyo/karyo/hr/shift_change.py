"""Employee shift-change requests with roster context and synchronized status."""

import frappe
from frappe import _
from frappe.utils import cint, date_diff, getdate, nowdate
from hrms.hr.doctype.shift_request.shift_request import ShiftRequest

from karyo.hr.clocking import _own_employee


class KaryoShiftRequest(ShiftRequest):
	"""Validate requests against the employee's dated roster, not a stale default."""

	def validate_default_shift(self):
		current_shift = self.get("karyo_current_shift") or _current_shift(self.employee, self.from_date)
		if self.shift_type == current_shift:
			frappe.throw(
				_("Requested Shift must be different from the current shift: {0}.").format(
					frappe.bold(current_shift)
				)
			)


def _current_shift(employee, on_date):
	from karyo.hr.roster import employee_duty

	duty = employee_duty(employee, getdate(on_date))
	return (
		(duty.shift_type if duty and not duty.get("is_rest_day") else None)
		or frappe.db.get_value("Employee", employee, "default_shift")
	)


def _request_status(doc):
	if doc.docstatus == 2:
		return "Cancelled"
	if doc.status == "Approved":
		return "Approved"
	if doc.status == "Rejected":
		return "Rejected"
	return "Pending Approval"


def prepare_shift_request(doc, method=None):
	"""Persist the snapshot employees and approvers need to read consistently."""
	if not doc.employee or not doc.from_date:
		return
	doc.karyo_current_shift = doc.karyo_current_shift or _current_shift(doc.employee, doc.from_date)
	end = getdate(doc.to_date or doc.from_date)
	doc.karyo_duration_days = max(1, date_diff(end, getdate(doc.from_date)) + 1)
	doc.karyo_request_status = _request_status(doc)
	if doc.is_new() and not str(doc.get("karyo_reason") or "").strip():
		frappe.throw(_("Enter the reason for the shift-change request."))


def notify_shift_request_update(doc, method=None):
	from karyo.hr.self_service import notify_employee_request

	if doc.docstatus == 2 and doc.get("karyo_request_status") != "Cancelled":
		doc.db_set("karyo_request_status", "Cancelled", update_modified=False)
	notify_employee_request(doc, method)


@frappe.whitelist()
def shift_change_context(from_date=None):
	person = _own_employee(required=True)
	date = getdate(from_date or nowdate())
	employee = frappe.db.get_value(
		"Employee", person.name,
		["name", "employee_name", "company", "department", "shift_request_approver"],
		as_dict=True,
	)
	return {
		"employee": employee.name,
		"employee_name": employee.employee_name,
		"company": employee.company,
		"department": employee.department,
		"current_shift": _current_shift(employee.name, date),
		"approver": employee.shift_request_approver,
		"from_date": date,
		"status": "Pending Approval",
	}


@frappe.whitelist(methods=["POST"])
def submit_shift_change_request(requested_shift, from_date, to_date=None, reason=None):
	"""Create an employee-owned request ready for its configured approver."""
	person = _own_employee(required=True)
	employee = frappe.db.get_value(
		"Employee", person.name,
		["name", "employee_name", "company", "department", "shift_request_approver"],
		as_dict=True,
	)
	start = getdate(from_date)
	end = getdate(to_date or from_date)
	if start < getdate(nowdate()):
		frappe.throw(_("The shift change cannot start in the past."))
	if end < start:
		frappe.throw(_("To Date cannot be before From Date."))
	if not frappe.db.exists("Shift Type", requested_shift):
		frappe.throw(_("Select a valid requested shift."))
	reason = str(reason or "").strip()
	if not reason:
		frappe.throw(_("Enter the reason for the shift-change request."))
	current_shift = _current_shift(employee.name, start)
	if requested_shift == current_shift:
		frappe.throw(_("Requested Shift must be different from the current shift."))
	approver = employee.shift_request_approver or frappe.db.get_value(
		"Department Approver",
		{"parent": employee.department, "parentfield": "shift_request_approver"},
		"approver",
	)
	if not approver:
		frappe.throw(_("No Shift Request Approver is configured for your employee or department. Contact HR."))
	doc = frappe.get_doc({
		"doctype": "Shift Request",
		"employee": employee.name,
		"company": employee.company,
		"approver": approver,
		"shift_type": requested_shift,
		"from_date": start,
		"to_date": end,
		"status": "Draft",
		"karyo_current_shift": current_shift,
		"karyo_reason": reason,
		"karyo_duration_days": cint(date_diff(end, start) + 1),
		"karyo_request_status": "Pending Approval",
	})
	# Identity is fixed to the signed-in employee above. This avoids granting
	# broad Employee/Department access merely to submit a self-service request.
	doc.insert(ignore_permissions=True)
	return {
		"name": doc.name,
		"current_shift": doc.karyo_current_shift,
		"requested_shift": doc.shift_type,
		"reason": doc.karyo_reason,
		"from_date": doc.from_date,
		"to_date": doc.to_date,
		"duration_days": doc.karyo_duration_days,
		"status": doc.karyo_request_status,
		"route": f"/app/shift-request/{doc.name}",
	}
