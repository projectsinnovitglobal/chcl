frappe.pages["my-leave-bank"].on_page_load = function (wrapper) {
	const $body = karyo.pages.scaffold(wrapper, {
		title: __("My Leave Bank"),
		subtitle: __("Your allocated, taken and available leave"),
		actions: [
			{ label: __("Request leave"), primary: true, onclick: () => frappe.new_doc("Leave Application") },
			{ label: __("Encash leave"), onclick: () => frappe.new_doc("Leave Encashment") },
			{ label: __("My Calendar"), onclick: () => frappe.set_route("my-calendar") },
		],
	});

	const number = karyo.pages.leave_days;
	const dailyNumber = number;
	$body.addClass("karyo-my-leave-bank");
	function render(data) {
		$body.empty();
		const rows = data.allocations || [];
		const category = (codes, name) => {
			const matches = rows.filter((row) => !row.is_dependent && (
				codes.includes(String(row.leave_code || "").toUpperCase()) ||
				String(row.leave_type || "").toLowerCase().includes(name)
			));
			return {
				total: matches.reduce((value, row) => value + flt(row.total || 0), 0),
				taken: matches.reduce((value, row) => value + flt(row.taken || 0), 0),
				remaining: matches.reduce((value, row) => value + flt(row.remaining || 0), 0),
			};
		};
		const casual = category(["CASL01", "CASL02"], "casual");
		const annual = category(["ANN", "ANN01"], "annual");
		// Dependent views such as Paternity use an existing Vacation balance and
		// must not inflate the overall entitlement totals.
		const sum = (field) => rows.filter((row) => !row.is_dependent).reduce((total, row) => total + flt(row[field] || 0), 0);
		const encashment = data.encashment || {};
		const accrual = data.vacation_accrual || data.vacation_leave_bank;
		karyo.pages.stats($body, [
			{ label: __("Casual Leave"), value: number(casual.remaining), sub: __("{0} allocated · {1} taken", [number(casual.total), number(casual.taken)]), icon: "calendar-check", icon_color: "green" },
			{ label: __("Annual Leave"), value: number(annual.remaining), sub: __("{0} allocated · {1} taken", [number(annual.total), number(annual.taken)]), icon: "calendar-days", icon_color: "blue" },
			...(accrual ? [{
				label: __("Vacation earned per day"), value: dailyNumber(accrual.daily_accrual_days),
				sub: __("days · {0} days/year ÷ {1} days", [number(accrual.annual_accrual_days), accrual.days_in_year]),
				icon: "calendar-plus", icon_color: "blue",
			}] : []),
			{ label: __("Allocated"), value: number(sum("total")), sub: __("days"), icon: "calendar-plus", icon_color: "blue" },
			{ label: __("Taken"), value: number(sum("taken")), sub: __("days"), icon: "calendar-minus", icon_color: "orange" },
			{ label: __("Pending"), value: number(sum("pending")), sub: __("days reserved"), icon: "clock", icon_color: "orange" },
			{ label: __("Available"), value: number(sum("remaining")), sub: __("days"), icon: "calendar-check", icon_color: "green" },
			{ label: __("Available to encash"), value: flt(encashment.available_days), sub: __("days eligible"), icon: "badge-dollar-sign", icon_color: "green", onclick: () => frappe.new_doc("Leave Encashment") },
			{ label: __("Encashed this year"), value: flt(encashment.encashed_days_this_year), sub: __("approved days"), icon: "coins", icon_color: "blue", route: "/app/leave-encashment" },
		]);

		const encashment_rows = (encashment.history || []).map((row) => ({
			date: frappe.datetime.str_to_user(row.encashment_date),
			leave_type: row.leave_type,
			days: number(row.encashment_days),
			amount: format_currency(row.encashment_amount || 0, row.currency),
			status: __(row.status || "Draft"),
			earning: row.additional_salary || __("Pending approval"),
		}));
		karyo.pages.table(
			karyo.pages.grid($body, 1),
			{ title: __("My leave encashments") },
			[
				{ label: __("Date"), field: "date" },
				{ label: __("Leave Type / Category"), field: "leave_type" },
				{ label: __("Days"), field: "days" },
				{ label: __("Amount"), field: "amount" },
				{ label: __("Status"), field: "status" },
				{ label: __("Employee Earning"), field: "earning" },
			],
			encashment_rows
		);

		const $banks = karyo.pages.grid($body, 2).addClass("karyo-leave-bank-panels");
		[
			[__("Sick Leave Bank"), data.sick_leave_bank, "bank_days"],
			[__("Vacation Leave Bank"), data.vacation_leave_bank, "balance_days"],
		].forEach(([title, bank, balance_field]) => {
			const $panel = karyo.pages.panel($banks, { title });
			if (!bank) {
				karyo.pages.empty_state($panel, { title: __("No bank record allocated") });
				return;
			}
			const $counter = $('<div class="karyo-bank-counter"></div>').appendTo($panel);
			[
				[__("Allotted"), bank.allotted_days],
				[__("Taken"), bank.taken_days],
				[__("Available"), bank.available_days],
				[__("Bank balance"), bank[balance_field]],
				...(title === __("Vacation Leave Bank") ? [
					[__("Service band"), bank.service_years == null ? "—" : __("{0} years", [number(bank.service_years)])],
					[__("Annual accrual"), bank.annual_accrual_days],
					[__("Earned per day"), bank.daily_accrual_days],
					[__("Earned to date"), bank.earned_to_date_days],
					[__("Ceiling"), bank.ceiling_days],
				] : []),
			].forEach(([label, value]) =>
				$('<div><span></span><strong></strong></div>')
					.find("span").text(label).end()
					.find("strong").text(label === __("Earned per day") ? dailyNumber(value) : number(value)).end()
					.appendTo($counter)
			);
		});

		const display_rows = rows.map((row) => ({
			leave_type: row.leave_type,
			leave_code: row.leave_code || "—",
			period: `${frappe.datetime.str_to_user(row.from_date)} →\n${frappe.datetime.str_to_user(row.to_date)}`,
			availability: row.availability_status || __("Available now"),
			total: number(row.total),
			taken: number(row.taken),
			pending: number(row.pending),
			expired: number(row.expired),
			remaining: number(row.remaining),
			earned_per_day: row.daily_accrual_days == null ? "—" : dailyNumber(row.daily_accrual_days),
			depends_on: row.depends_on || "—",
		}));
		const $balance = karyo.pages.table(
			karyo.pages.grid($body, 1),
			{ title: __("My leave balance · Financial Year {0}", [data.fiscal_year?.name || "—"]) },
			[
				{ label: __("Code"), field: "leave_code" },
				{ label: __("Leave Type / Category"), field: "leave_type" },
				{ label: __("Available from / valid through"), field: "period" },
				{ label: __("Availability"), field: "availability" },
				{ label: __("Allocated"), field: "total" },
				{ label: __("Taken"), field: "taken" },
				{ label: __("Pending"), field: "pending" },
				{ label: __("Expired"), field: "expired" },
				{ label: __("Available"), field: "remaining" },
				{ label: __("Vacation earned per day"), field: "earned_per_day" },
				{ label: __("Depends on / deducts from"), field: "depends_on" },
			],
			display_rows
		);
		$balance.addClass("karyo-leave-balance-table");

		const transaction_rows = (data.transactions || []).map((row) => ({
			request: row.leave_request_id,
			code: row.leave_code,
			period: `${frappe.datetime.str_to_user(row.start_date)} → ${frappe.datetime.str_to_user(row.end_date)}`,
			duration: row.two_hour_permission
				? __("{0} hours → {1} days", [number(row.requested_hours), dailyNumber(row.equivalent_leave_days)])
				: `${number(row.duration_units)} ${__(row.duration_unit || "Days")}`,
			status: row.cancelled ? __("Cancelled") : row.legacy_status,
		}));
		karyo.pages.table(
			karyo.pages.grid($body, 1),
			{ title: __("Leave transactions") },
			[
				{ label: __("Leave Request ID"), field: "request" },
				{ label: __("Leave Code"), field: "code" },
				{ label: __("Period"), field: "period" },
				{ label: __("Duration"), field: "duration" },
				{ label: __("Status"), field: "status" },
			],
			transaction_rows
		);

		const rule_rows = (data.leave_types || []).map((row) => ({
			leave_code: row.leave_code,
			leave_type: row.leave_type,
			eligibility: row.eligible
				? (row.available == null ? __("Eligible") : __("Eligible · {0} days available", [number(row.available)]))
				: __("Not eligible — {0}", [row.eligibility_reason || __("Eligibility requirements are not met")]),
			balance_source: __(row.bank_type || "None"),
			depends_on: row.deducts_from || "—",
			entitlement: row.annual_entitlement ? number(row.annual_entitlement) : "—",
			limit: row.max_days ? number(row.max_days) : "—",
			documents: row.attachment_after ? __("Required after {0} days", [number(row.attachment_after)]) : "—",
		}));
		karyo.pages.table(
			karyo.pages.grid($body, 1),
			{ title: __("Leave types / categories available to me") },
			[
				{ label: __("Code"), field: "leave_code" },
				{ label: __("Leave Type / Category"), field: "leave_type" },
				{ label: __("Eligibility"), field: "eligibility" },
				{ label: __("Balance source"), field: "balance_source" },
				{ label: __("Depends on / deducts from"), field: "depends_on" },
				{ label: __("Annual entitlement"), field: "entitlement" },
				{ label: __("Application limit"), field: "limit" },
				{ label: __("Supporting document"), field: "documents" },
			],
			rule_rows
		);
	}

	karyo.live.request(
		wrapper,
		{
			method: "karyo.hr.self_service.my_leave_bank",
			callback: (r) => render(r.message || {}),
		},
		["Employee", "Leave Type", "MBC Leave Settings", "Leave Balance", "Leave Transaction", "Leave Allocation", "Leave Application", "Leave Ledger Entry", "Leave Encashment", "Additional Salary", "Sick Leave Bank", "Sick Leave Bank Posting", "Vacation Leave Bank", "Vacation Leave Posting"]
	);
};
