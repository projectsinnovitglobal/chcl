import frappe
from frappe import _
from frappe.utils import flt, getdate

from karyo.payroll.banking import mask_account


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if getdate(filters.from_date) > getdate(filters.to_date):
		frappe.throw(_("From Date cannot be after To Date."))
	conditions = ["ss.docstatus=1", "ss.company=%(company)s", "ss.end_date between %(from_date)s and %(to_date)s"]
	if filters.employee:
		conditions.append("ss.employee=%(employee)s")
	rows = frappe.db.sql(
		f"""select ss.name as salary_slip, ss.employee, ss.employee_name, ss.end_date, ss.currency,
			ss.net_pay, ss.karyo_primary_remittance_bank, ss.karyo_primary_remittance_branch,
			ss.karyo_primary_remittance_account, ss.karyo_primary_remittance_amount,
			ss.karyo_secondary_remittance_bank, ss.karyo_secondary_remittance_branch,
			ss.karyo_secondary_remittance_account, ss.karyo_secondary_remittance_amount
		from `tabSalary Slip` ss where {' and '.join(conditions)}
		order by ss.employee_name, ss.employee, ss.end_date""",
		filters, as_dict=True,
	)
	data = []
	for row in rows:
		for destination, bank, branch, account, amount in (
			("Primary", row.karyo_primary_remittance_bank, row.karyo_primary_remittance_branch, row.karyo_primary_remittance_account, row.karyo_primary_remittance_amount),
			("Secondary", row.karyo_secondary_remittance_bank, row.karyo_secondary_remittance_branch, row.karyo_secondary_remittance_account, row.karyo_secondary_remittance_amount),
		):
			if flt(amount) <= 0 or (filters.bank and bank != filters.bank):
				continue
			data.append({
				"salary_slip": row.salary_slip, "employee": row.employee, "employee_name": row.employee_name,
				"payment_date": row.end_date, "destination": destination, "bank": bank, "branch": branch,
				"account": mask_account(account), "amount": amount, "currency": row.currency,
			})
	columns = [
		{"fieldname": "salary_slip", "label": _("Salary Slip"), "fieldtype": "Link", "options": "Salary Slip", "width": 150},
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 120},
		{"fieldname": "employee_name", "label": _("Employee Name"), "width": 180},
		{"fieldname": "payment_date", "label": _("Payment Date"), "fieldtype": "Date", "width": 100},
		{"fieldname": "destination", "label": _("Destination"), "width": 90},
		{"fieldname": "bank", "label": _("Bank"), "fieldtype": "Link", "options": "Bank", "width": 150},
		{"fieldname": "branch", "label": _("Branch"), "fieldtype": "Link", "options": "Payroll Bank Branch", "width": 140},
		{"fieldname": "account", "label": _("Account"), "width": 120},
		{"fieldname": "amount", "label": _("Amount"), "fieldtype": "Currency", "options": "currency", "width": 120},
		{"fieldname": "currency", "label": _("Currency"), "fieldtype": "Link", "options": "Currency", "hidden": 1},
	]
	return columns, data
