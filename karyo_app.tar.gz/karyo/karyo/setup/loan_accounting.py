"""Governed loan accounting mappings and posting links."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def setup():
	make_doctype(
		"Loan Accounting Mapping",
		autoname="naming_series:",
		fields=[
			f("naming_series", "Select", "Series", options="LAM-.#####", default="LAM-.#####"),
			f("company", "Link", "Company", options="Company", reqd=1, in_list_view=1),
			f("loan_type", "Link", "Loan Type (blank = all)", options="Loan Type", in_list_view=1),
			f("accounts_sb", "Section Break", "Accounts"),
			f("principal_receivable_account", "Link", "Principal Receivable", options="Account", reqd=1),
			f("bank", "Link", "Bank", options="Bank", reqd=1),
			f("bank_branch", "Link", "Branch", options="Payroll Bank Branch", reqd=1),
			f("registration_fee_income_account", "Link", "Registration Fee Income", options="Account"),
			f("accounts_cb", "Column Break"),
			f("interest_income_account", "Link", "Interest Income", options="Account", reqd=1),
			f("insurance_payable_account", "Link", "Insurance Payable", options="Account"),
			f("waiver_account", "Link", "Waiver / Write-off", options="Account"),
			f("rounding_account", "Link", "Rounding", options="Account"),
			f("validity_sb", "Section Break", "Validity"),
			f("start_date", "Date", "Start Date", reqd=1),
			f("end_date", "Date", "End Date"),
			f("is_active", "Check", "Active", default="1"),
			f("governance_sb", "Section Break", "Configuration Governance", hidden=1),
			f("configuration_status", "Select", "Configuration Status", options="Demo\nDraft\nValidated\nApproved\nActive\nSuperseded\nRetired", default="Demo", reqd=1, hidden=1),
			f("configuration_version", "Data", "Version", default="1.0", hidden=1),
			f("is_production_eligible", "Check", "Approved for Production", hidden=1),
			f("source_reference", "Data", "Source Reference", hidden=1),
			f("approval_reference", "Data", "Approval Reference", hidden=1),
			f("governance_cb", "Column Break", hidden=1),
			f("approved_by", "Link", "Approved By", options="User", read_only=1, hidden=1),
			f("approved_on", "Datetime", "Approved On", read_only=1, hidden=1),
			f("bank_cash_account", "Link", "Legacy Disbursement Account", options="Account", hidden=1, read_only=1, no_copy=1),
		],
	)
	_apply_compatibility_fields()
	_backfill_bank_and_branch()
	frappe.db.commit()
	print("Loan accounting mapping and posting links ensured.")


def _apply_compatibility_fields():
	create_custom_fields(
		{
			"Loan Accounting Mapping": [
				{
					"fieldname": "payroll_clearing_account",
					"fieldtype": "Link",
					"label": "Legacy Recovery Account",
					"options": "Account",
					"insert_after": "bank_cash_account",
					"hidden": 1,
					"read_only": 1,
					"no_copy": 1,
				},
				{"fieldname": "refund_account", "fieldtype": "Link", "label": "Refund Account", "options": "Account", "insert_after": "waiver_account"},
			],
			"Karyo Loan": [
				{"fieldname": "disbursement_journal_entry", "fieldtype": "Link", "label": "Disbursement Journal Entry", "options": "Journal Entry", "read_only": 1, "insert_after": "disbursement_event"},
				{"fieldname": "accounting_mapping", "fieldtype": "Link", "label": "Accounting Mapping", "options": "Loan Accounting Mapping", "read_only": 1, "insert_after": "disbursement_journal_entry"},
				{"fieldname": "accounting_mapping_version", "fieldtype": "Data", "label": "Accounting Mapping Version", "read_only": 1, "insert_after": "accounting_mapping"},
			],
			"Karyo Loan Disbursement Event": [
				{"fieldname": "journal_entry", "fieldtype": "Link", "label": "Journal Entry", "options": "Journal Entry", "read_only": 1, "insert_after": "original_event"},
			],
			"Karyo Loan Payroll Allocation": [
				{"fieldname": "journal_entry", "fieldtype": "Link", "label": "Recovery Journal Entry", "options": "Journal Entry", "read_only": 1, "insert_after": "reversal_of"},
			],
			"Salary Detail": [
				{"fieldname": "karyo_loan", "fieldtype": "Link", "label": "Source Loan", "options": "Karyo Loan", "read_only": 1, "insert_after": "additional_salary"},
				{"fieldname": "karyo_loan_component", "fieldtype": "Select", "label": "Loan Component", "options": "Capital\nInterest\nInsurance", "read_only": 1, "insert_after": "karyo_loan"},
				{"fieldname": "karyo_loan_reference", "fieldtype": "Data", "label": "Loan Reference", "read_only": 1, "insert_after": "karyo_loan_component"},
				{"fieldname": "karyo_loan_pdb_code", "fieldtype": "Data", "label": "Loan PDB Code", "read_only": 1, "insert_after": "karyo_loan_reference"},
			],
			"Karyo Loan Settlement": [
				{"fieldname": "journal_entry", "fieldtype": "Link", "label": "Settlement Journal Entry", "options": "Journal Entry", "read_only": 1, "insert_after": "total_balance_due"},
			],
			"Karyo Loan Recast": [
				{"fieldname": "journal_entry", "fieldtype": "Link", "label": "Advance / Refund Journal Entry", "options": "Journal Entry", "read_only": 1, "insert_after": "advance_payment"},
				{"fieldname": "accounting_idempotency_key", "fieldtype": "Data", "label": "Accounting Idempotency Key", "read_only": 1, "insert_after": "journal_entry"},
			],
		},
		ignore_validate=True,
	)


def _backfill_bank_and_branch():
	"""Carry the company's governed bank routing onto existing mappings."""
	for row in frappe.get_all(
		"Loan Accounting Mapping", fields=["name", "company", "bank", "bank_branch"]
	):
		if row.bank and row.bank_branch:
			continue
		company = frappe.db.get_value(
			"Company", row.company, ["karyo_payroll_bank", "karyo_payroll_bank_branch"], as_dict=True
		) or {}
		values = {}
		if not row.bank and company.get("karyo_payroll_bank"):
			values["bank"] = company["karyo_payroll_bank"]
		if not row.bank_branch and company.get("karyo_payroll_bank_branch"):
			values["bank_branch"] = company["karyo_payroll_bank_branch"]
		if values:
			frappe.db.set_value("Loan Accounting Mapping", row.name, values, update_modified=False)


def apply():
	"""Apply the Bank/Branch UI and hide obsolete account selectors after migrate."""
	frappe.reload_doc("karyo", "doctype", "loan_accounting_mapping")
	_apply_compatibility_fields()
	_backfill_bank_and_branch()
	frappe.clear_cache(doctype="Loan Accounting Mapping")
	frappe.db.commit()
