from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.setup.payroll_profiles import prb_salary_value


class TestPRBSalaryPhases(FrappeTestCase):
	@patch("karyo.setup.payroll_profiles.frappe.db.get_value")
	def test_2026_applies_half_and_2027_applies_full_increase(self, get_value):
		get_value.return_value = frappe._dict(gross_2025=40000, revised_2026=44000)
		self.assertEqual(prb_salary_value("10", 2026, "2026-01-01"), 42000)
		self.assertEqual(prb_salary_value("10", 2026, "2027-01-01"), 44000)
