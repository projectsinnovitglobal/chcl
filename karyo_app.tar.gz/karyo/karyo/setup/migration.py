"""Auditable generic staging controls for MBC legacy migration."""

import frappe
from karyo.setup.foundation import f, make_doctype


def permission(role, **allowed):
	"""Build an explicit DocPerm row; DocPerm defaults must never grant omitted rights."""
	row = {
		"role": role, "read": 0, "write": 0, "create": 0, "delete": 0,
		"submit": 0, "cancel": 0, "amend": 0, "report": 0, "export": 0,
		"import": 0, "print": 0, "email": 0, "share": 0,
	}
	row.update(allowed)
	return row


MIGRATION_PERMISSIONS = [
	permission("System Manager", read=1, write=1, create=1, delete=1, report=1, export=1, print=1),
	permission("Data Migration Manager", read=1, write=1, create=1, delete=1, report=1, export=1, print=1),
	permission("Payroll Auditor", read=1, report=1, export=1),
]


def create_doctypes():
	make_doctype("MBC Migration Row", istable=1, fields=[
		f("row_number", "Int", "Row", reqd=1, in_list_view=1),
		f("legacy_id", "Data", "Legacy ID", reqd=1, in_list_view=1),
		f("source_hash", "Data", "Source Hash", reqd=1),
		f("payload_json", "Long Text", "Source Payload", reqd=1),
		f("status", "Select", "Status", options="Valid\nRejected\nLoaded\nDuplicate", reqd=1, in_list_view=1),
		f("error_code", "Data", "Error Code", in_list_view=1), f("error_message", "Small Text", "Error Message"),
		f("target_doctype", "Link", "Target DocType", options="DocType"),
		f("target_name", "Dynamic Link", "Target Record", options="target_doctype"),
		f("control_amount", "Currency", "Control Amount"),
	])
	make_doctype("MBC Migration Batch", autoname="field:load_id", naming_rule="By fieldname", fields=[
		f("load_id", "Data", "Load ID", reqd=1, unique=1, in_list_view=1),
		f("migration_domain", "Select", "Domain", options="Organisation\nEmployee\nSalary\nLeave\nSick Leave Bank\nVacation Leave Bank\nPassage Benefit\nPayroll YTD\nLoan\nAttachment", reqd=1, in_list_view=1),
		f("source_filename", "Data", "Source Filename", reqd=1), f("source_checksum", "Data", "SHA-256", reqd=1),
		f("source_as_at", "Date", "Source As At", reqd=1), f("source_reference", "Data", "Source Reference", reqd=1),
		f("status", "Select", "Status", options="Preview\nValidated\nLoaded\nReconciled\nFailed\nCleared", default="Preview", reqd=1, in_list_view=1),
		f("counts_sb", "Section Break", "Control Totals"), f("source_count", "Int", "Source Count", read_only=1),
		f("valid_count", "Int", "Valid", read_only=1), f("rejected_count", "Int", "Rejected", read_only=1),
		f("duplicate_count", "Int", "Duplicate", read_only=1), f("target_count", "Int", "Target Count", read_only=1),
		f("ccb", "Column Break"), f("source_total", "Currency", "Source Amount", read_only=1),
		f("target_total", "Currency", "Target Amount", read_only=1), f("difference", "Currency", "Difference", read_only=1),
		f("rows_sb", "Section Break", "Staged Rows"), f("rows", "Table", "Rows", options="MBC Migration Row", reqd=1),
		f("approval_sb", "Section Break", "Approval and Audit"), f("mapping_version", "Data", "Mapping Version", reqd=1),
		f("approval_reference", "Data", "Approval Reference"), f("reconciliation_reference", "Data", "Reconciliation Reference"),
	])


def configure_security():
	for role in ("Data Migration Manager", "Payroll Auditor"):
		if not frappe.db.exists("Role", role):
			frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1}).insert(ignore_permissions=True)
	meta = frappe.get_doc("DocType", "MBC Migration Batch")
	meta.set("permissions", MIGRATION_PERMISSIONS)
	meta.save(ignore_permissions=True)


def setup():
	print("Karyo MBC migration staging setup:")
	create_doctypes()
	configure_security()
	frappe.db.commit()
	print("Done (staging, row exceptions, checksums and reconciliation controls created).")
