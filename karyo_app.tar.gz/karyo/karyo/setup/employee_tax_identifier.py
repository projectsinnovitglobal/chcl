"""Expose the native payroll tax identifier in Employee > Salary."""

import frappe
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.permissions import add_permission, update_permission_property


def apply():
    # Keep the native field: readiness checks and tax reports already read it.
    for property_name, value, fieldtype in (
        ("label", "Tax Identifier", "Data"),
        ("description", "Enter the employee's tax account number. Save the employee, then rerun Payroll Readiness Checks to clear the missing tax identifier exception.", "Text"),
        ("hidden", 0, "Check"),
        ("read_only", 0, "Check"),
        ("permlevel", 2, "Int"),
    ):
        make_property_setter("Employee", "pan_number", property_name, value, fieldtype,
                             validate_fields_for_doctype=False)
    # Tax data stays at the restricted permission level; reviewers retain read access.
    for role in ("HR Manager", "Payroll Processor"):
        if not frappe.db.exists("Role", role):
            continue
        if not frappe.db.exists("Custom DocPerm", {
            "parent": "Employee", "role": role, "permlevel": 2, "if_owner": 0,
        }):
            add_permission("Employee", role, 2, "read")
        for permission in ("read", "write"):
            update_permission_property("Employee", role, 2, permission, 1)
    frappe.clear_cache(doctype="Employee")


def setup():
    apply()
