import frappe
from frappe.tests.utils import FrappeTestCase

from karyo import product_scope
from karyo.setup import role_access


class TestRoleAccess(FrappeTestCase):
	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		role_access.setup()

	def test_only_current_modules_are_exposed(self):
		self.assertEqual(role_access.ACTIVE_MODULE_DEFS, ("Karyo", "HR", "Payroll"))
		bootinfo = frappe._dict(
			user=frappe._dict(),
			allowed_workspaces=[
				{"name": "MBC", "module": "Karyo"},
				{"name": "Employees", "module": "HR"},
				{"name": "Selling", "module": "Selling"},
				{"name": "CRM", "module": "CRM"},
			],
			module_wise_workspaces={
				"Karyo": [{"name": "MBC"}],
				"HR": [{"name": "Employees"}],
				"Selling": [{"name": "Selling"}],
			},
			dashboards=[
				{"name": "Payroll", "module": "Payroll"},
				{"name": "Sales", "module": "Selling"},
			],
		)
		product_scope.extend_bootinfo(bootinfo)
		self.assertEqual({row["module"] for row in bootinfo.allowed_workspaces}, {"Karyo", "HR"})
		self.assertEqual(set(bootinfo.module_wise_workspaces), {"Karyo", "HR"})
		self.assertEqual([row["module"] for row in bootinfo.dashboards], ["Payroll"])

	def test_legacy_erp_accounts_are_out_of_product_scope(self):
		hidden = product_scope.hidden_doctypes()
		self.assertTrue({"Account", "Bank Account", "Loan Accounting Mapping"}.issubset(hidden))
		self.assertIn("accounts-master", product_scope.HIDDEN_PAGES)

	def test_requested_role_profiles_are_seeded(self):
		profiles = set(frappe.get_all("Role Profile", pluck="name"))
		self.assertTrue(set(role_access.PROFILE_NAMES).issubset(profiles))
		for module in role_access.PROFILE_NAMES:
			roles = set(
				frappe.get_all(
					"Has Role",
					filters={"parenttype": "Role Profile", "parent": module},
					pluck="role",
				)
			)
			self.assertIn(role_access.capability_role(module, "View"), roles)

	def test_capability_roles_have_real_server_permissions(self):
		examples = {
			"People": "Employee",
			"Attendance": "Attendance",
			"Leave": "Leave Application",
			"Passage Benefits": "Passage Benefit Application",
			"Payroll": "Payroll Cycle",
			"Loan Reports": "Karyo Loan",
			"Administration": "Role Profile",
		}
		for module, doctype in examples.items():
			for action in role_access.ACTION_RIGHTS:
				self.assertEqual(
					frappe.db.count(
						"Custom DocPerm",
						{"parent": doctype, "role": role_access.capability_role(module, action), "permlevel": 0},
					),
					1,
				)
			view = frappe.db.get_value(
				"Custom DocPerm",
				{"parent": doctype, "role": role_access.capability_role(module, "View"), "permlevel": 0},
				["read", "write", "delete"],
				as_dict=True,
			)
			edit = frappe.db.get_value(
				"Custom DocPerm",
				{"parent": doctype, "role": role_access.capability_role(module, "Edit"), "permlevel": 0},
				["read", "write", "create"],
				as_dict=True,
			)
			delete = frappe.db.get_value(
				"Custom DocPerm",
				{"parent": doctype, "role": role_access.capability_role(module, "Delete"), "permlevel": 0},
				["read", "delete"],
				as_dict=True,
			)
			self.assertEqual((view.read, view.write, view.delete), (1, 0, 0))
			self.assertEqual((edit.read, edit.write, edit.create), (1, 1, 1))
			self.assertEqual((delete.read, delete.delete), (1, 1))

	def test_role_profile_rejects_hidden_default_roles(self):
		doc = frappe.new_doc("Role Profile")
		doc.role_profile = "Access validation fixture"
		doc.append("roles", {"role": "MBC People View"})
		doc.append("roles", {"role": "Sales User"})
		role_access.validate_role_profile(doc)
		self.assertEqual([row.role for row in doc.roles], ["MBC People View"])

	def test_user_more_information_and_role_ordering_are_curated(self):
		self.assertTrue(frappe.get_meta("User").get_field("short_bio").hidden)
		role_meta = frappe.get_meta("Role")
		self.assertEqual(role_meta.sort_field, "disabled")
		self.assertEqual(role_meta.sort_order, "ASC")
