from datetime import date
from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.attendance_report import _add_additional_hours


class TestAttendanceAdditionalHours(FrappeTestCase):
	def test_report_appends_governed_hours_and_payroll_columns(self):
		columns = [{"label": "Employee", "fieldname": "employee", "fieldtype": "Link"}]
		data = [{"employee": "EMP-0001", "employee_name": "Test Employee"}]
		summary = [{
			"employee": "EMP-0001",
			"overtime_hours": 3,
			"night_duty_hours": 2,
			"work_on_holiday_hours": 4,
			"excess_hours": 1,
			"total_additional_hours": 10,
			"payroll_amount": 2500,
			"payroll_status": "Ready for Payroll",
		}]
		filters = frappe._dict(company="Test Company", employee=None)

		with patch(
			"hrms.hr.report.monthly_attendance_sheet.monthly_attendance_sheet.get_dates_in_period",
			return_value=[date(2026, 9, 1), date(2026, 9, 30)],
		), patch(
			"karyo.payroll.overtime_process.employee_summary",
			return_value=(summary, date(2026, 9, 1), date(2026, 9, 30)),
		):
			columns, data = _add_additional_hours(columns, data, filters)

		self.assertEqual(
			[column["fieldname"] for column in columns[-7:]],
			[
				"overtime_hours", "night_duty_hours", "work_on_holiday_hours",
				"excess_hours", "total_additional_hours", "payroll_amount", "payroll_status",
			],
		)
		self.assertEqual(data[0]["total_additional_hours"], 10)
		self.assertEqual(data[0]["payroll_status"], "Ready for Payroll")

