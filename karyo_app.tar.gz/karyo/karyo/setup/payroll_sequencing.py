"""Configurable major/minor sequencing and transaction allocation (PAY-021)."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctype():
	make_doctype(
		"Payroll Transaction Allocation",
		autoname="hash",
		fields=[
			f("payroll_cycle", "Link", "Payroll Cycle", options="Payroll Cycle", reqd=1, in_list_view=1),
			f("company", "Link", "Company", options="Company", reqd=1),
			f("pay_period_label", "Data", "Pay Period", reqd=1, in_list_view=1),
			f("payroll_type", "Data", "Payroll Type", reqd=1, in_list_view=1),
			f("source_sb", "Section Break", "Source Transaction"),
			f("source_doctype", "Link", "Source Type", options="DocType", reqd=1),
			f("source_name", "Dynamic Link", "Source", options="source_doctype", reqd=1),
			f("employee", "Link", "Employee", options="Employee"),
			f("source_key", "Data", "Source Key", reqd=1, unique=1, read_only=1),
			f("source_cb", "Column Break"),
			f(
				"transaction_class",
				"Select",
				"Transaction Class",
				options="Static\nOnce-off",
				reqd=1,
				in_list_view=1,
			),
			f("amount", "Currency", "Amount", reqd=1, in_list_view=1),
			f(
				"status",
				"Select",
				"Status",
				options="Reserved\nPaid\nReconciled\nReleased",
				default="Reserved",
				reqd=1,
				in_list_view=1,
			),
			f("reconciliation_sb", "Section Break", "Major Reconciliation"),
			f(
				"reconciled_in_major_cycle",
				"Link",
				"Reconciled in Major Cycle",
				options="Payroll Cycle",
			),
			f("reconciled_on", "Datetime", "Reconciled On", read_only=1),
		],
	)


def add_configuration_fields():
	create_custom_fields(
		{
			"Karyo Payroll Settings": [
				{
					"fieldname": "sequencing_sb",
					"fieldtype": "Section Break",
					"label": "Major / Minor Sequencing",
					"insert_after": "negative_net_pay_limit",
				},
				{
					"fieldname": "minor_once_off_enabled",
					"fieldtype": "Check",
					"label": "Allow Once-off Transactions in Minor Payroll",
					"default": "1",
					"insert_after": "sequencing_sb",
				},
				{
					"fieldname": "require_minor_before_major",
					"fieldtype": "Check",
					"label": "Require Minor Approval Before Major",
					"default": "1",
					"insert_after": "minor_once_off_enabled",
				},
			],
			"Payroll Cycle": [
				{
					"fieldname": "sequencing_sb",
					"fieldtype": "Section Break",
					"label": "Major / Minor Sequencing",
					"insert_after": "exception_count",
				},
				{
					"fieldname": "preceding_minor_cycle",
					"fieldtype": "Link",
					"label": "Preceding Minor Cycle",
					"options": "Payroll Cycle",
					"read_only": 1,
					"insert_after": "sequencing_sb",
				},
				{
					"fieldname": "minor_sequence_waived",
					"fieldtype": "Check",
					"label": "Waive Minor Payroll Requirement",
					"insert_after": "preceding_minor_cycle",
				},
				{
					"fieldname": "minor_waiver_reason",
					"fieldtype": "Small Text",
					"label": "Minor Waiver Reason",
					"mandatory_depends_on": "eval:doc.minor_sequence_waived",
					"insert_after": "minor_sequence_waived",
				},
				{
					"fieldname": "minor_reconciled_total",
					"fieldtype": "Currency",
					"label": "Minor Payments Reconciled",
					"read_only": 1,
					"insert_after": "minor_waiver_reason",
				},
			],
		},
		ignore_validate=True,
	)


def setup():
	print("Karyo payroll sequencing setup:")
	create_doctype()
	add_configuration_fields()
	frappe.db.commit()
	print("Done (major/minor sequencing and allocation controls created).")
