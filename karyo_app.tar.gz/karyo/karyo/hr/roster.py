"""Governed roster, work-pattern and dated shift-assignment helpers."""

from datetime import datetime, timedelta
import re

import frappe
from frappe import _
from frappe.utils import add_days, cint, flt, get_first_day, get_last_day, getdate, nowdate
from hrms.hr.doctype.shift_schedule_assignment.shift_schedule_assignment import ShiftScheduleAssignment


def _time_hours(start, end):
	if start is None or end is None:
		return 0.0
	def seconds(value):
		if isinstance(value, timedelta):
			return value.total_seconds()
		if hasattr(value, "hour"):
			return value.hour * 3600 + value.minute * 60 + value.second
		parts = [float(part) for part in str(value).split(":")]
		return parts[0] * 3600 + parts[1] * 60 + parts[2]
	start_seconds, end_seconds = seconds(start), seconds(end)
	if end_seconds <= start_seconds:
		end_seconds += 24 * 3600
	return round((end_seconds - start_seconds) / 3600, 2)


def _working_days_label(value, saturday=False, sunday=False, roster=False):
	if str(value or "").strip():
		return str(value).strip()
	if roster:
		return "As per roster"
	if sunday:
		return "Mon-Sun"
	if saturday:
		return "Mon-Sat"
	return "Mon-Fri"


def validate_attendance_configuration_master(doc, method=None):
	"""Keep the sheet-derived Shift and Calendar fields internally consistent."""
	from karyo.karyo.doctype.employee_location.employee_location import validate_organisation_scope

	validate_organisation_scope(doc, "karyo_department", "karyo_section", "karyo_location")
	if doc.get("karyo_location"):
		from karyo.karyo.doctype.employee_location.employee_location import validate_active_location

		validate_active_location(doc.karyo_location)
	if doc.doctype == "Shift Type":
		doc.karyo_description = (doc.get("karyo_description") or doc.name or "").strip()
		doc.karyo_daily_hours = _time_hours(doc.start_time, doc.end_time)
		doc.karyo_working_days = _working_days_label(
			doc.get("karyo_working_days"), doc.get("karyo_saturday_working"), doc.get("karyo_sunday_working")
		)
		if not doc.get("karyo_effective_from"):
			doc.karyo_effective_from = nowdate()
		if doc.get("karyo_effective_to") and getdate(doc.karyo_effective_to) < getdate(doc.karyo_effective_from):
			frappe.throw(_("Effective To cannot be before Effective From."))
		return
	if doc.doctype != "Holiday List":
		return
	if not doc.get("karyo_calendar_code"):
		base = re.sub(r"[^A-Z0-9]+", "-", str(doc.get("holiday_list_name") or doc.name or "CALENDAR").upper()).strip("-")[:120]
		candidate, suffix = base or "CALENDAR", 1
		while frappe.db.exists("Holiday List", {"karyo_calendar_code": candidate, "name": ["!=", doc.name or ""]}):
			suffix += 1
			candidate = f"{base[:130-len(str(suffix))]}-{suffix}"
		doc.karyo_calendar_code = candidate
	if not doc.get("karyo_description"):
		doc.karyo_description = doc.get("holiday_list_name") or doc.name
	if not doc.get("karyo_working_days"):
		doc.karyo_working_days = _working_days_label(
			None, doc.get("karyo_saturday_working"), doc.get("karyo_sunday_working")
		)


def shift_context(shift_type):
	if not shift_type:
		return frappe._dict(shift_type=None, shift_code=None, start_time=None, end_time=None, duty_hours=0)
	row = frappe.db.get_value(
		"Shift Type", shift_type, ["name", "karyo_shift_code", "start_time", "end_time"], as_dict=True
	)
	if not row:
		return frappe._dict(shift_type=shift_type, shift_code=None, start_time=None, end_time=None, duty_hours=0)
	row.shift_type = row.name
	row.shift_code = row.karyo_shift_code
	row.duty_hours = _time_hours(row.start_time, row.end_time)
	return row


@frappe.whitelist()
def attendance_configuration_rows():
	"""Unified Attendance register in the exact legacy sheet column order."""
	frappe.has_permission("Shift Type", "read", throw=True)
	rows = []
	for row in frappe.get_list(
		"Shift Type",
		fields=[
			"name", "karyo_shift_code", "karyo_description", "karyo_department", "karyo_section",
			"karyo_location", "karyo_employee_category", "karyo_working_days", "start_time", "end_time",
			"karyo_daily_hours", "karyo_saturday_working", "karyo_sunday_working", "karyo_ph_treatment",
			"karyo_effective_from", "karyo_effective_to", "karyo_remarks",
		],
		order_by="karyo_shift_code asc, name asc", limit_page_length=0,
	):
		rows.append({
			"record_type": "Shift", "code": row.karyo_shift_code or row.name,
			"description": row.karyo_description or row.name, "department": row.karyo_department,
			"section": row.karyo_section, "location": row.karyo_location,
			"employee_category": row.karyo_employee_category,
			"working_days": _working_days_label(row.karyo_working_days, row.karyo_saturday_working, row.karyo_sunday_working),
			"normal_start": _display_time(row.start_time), "normal_end": _display_time(row.end_time),
			"daily_hours": flt(row.karyo_daily_hours) or _time_hours(row.start_time, row.end_time),
			"saturday_working": "Y" if row.karyo_saturday_working else "N",
			"sunday_working": "Y" if row.karyo_sunday_working else "N",
			"ph_treatment": row.karyo_ph_treatment, "effective_from": row.karyo_effective_from,
			"effective_to": row.karyo_effective_to, "remarks": row.karyo_remarks,
			"doctype": "Shift Type", "name": row.name,
		})
	for row in frappe.get_list(
		"Employee Work Pattern",
		fields=[
			"name", "work_pattern_code", "work_pattern_name", "department", "section", "location",
			"employee_category", "working_days", "default_shift", "normal_start", "normal_end", "daily_hours",
			"saturday_working", "sunday_working", "ph_treatment", "effective_from", "effective_to", "remarks",
			"prb_group",
		],
		filters={"disabled": 0}, order_by="work_pattern_code asc", limit_page_length=0,
	):
		shift = shift_context(row.default_shift)
		rows.append({
			"record_type": "Work Pattern", "code": row.work_pattern_code,
			"description": row.work_pattern_name, "department": row.department, "section": row.section,
			"location": row.location, "employee_category": row.employee_category,
			"working_days": _working_days_label(row.working_days, row.saturday_working, row.sunday_working, row.prb_group == "roster"),
			"normal_start": _display_time(row.normal_start or shift.start_time),
			"normal_end": _display_time(row.normal_end or shift.end_time),
			"daily_hours": flt(row.daily_hours) or shift.duty_hours,
			"saturday_working": "Y" if row.saturday_working else "N",
			"sunday_working": "Y" if row.sunday_working else "N",
			"ph_treatment": row.ph_treatment, "effective_from": row.effective_from,
			"effective_to": row.effective_to, "remarks": row.remarks,
			"doctype": "Employee Work Pattern", "name": row.name,
		})
	for row in frappe.get_list(
		"Holiday List",
		fields=[
			"name", "holiday_list_name", "karyo_calendar_code", "karyo_description", "karyo_department",
			"karyo_section", "karyo_location", "karyo_employee_category", "karyo_working_days",
			"karyo_saturday_working", "karyo_sunday_working", "karyo_ph_treatment", "from_date", "to_date",
			"karyo_remarks",
		],
		order_by="from_date desc, holiday_list_name asc", limit_page_length=0,
	):
		rows.append({
			"record_type": "Calendar", "code": row.karyo_calendar_code or row.name,
			"description": row.karyo_description or row.holiday_list_name or row.name,
			"department": row.karyo_department, "section": row.karyo_section,
			"location": row.karyo_location, "employee_category": row.karyo_employee_category,
			"working_days": _working_days_label(row.karyo_working_days, row.karyo_saturday_working, row.karyo_sunday_working),
			"normal_start": None, "normal_end": None, "daily_hours": None,
			"saturday_working": "Y" if row.karyo_saturday_working else "N",
			"sunday_working": "Y" if row.karyo_sunday_working else "N",
			"ph_treatment": row.karyo_ph_treatment, "effective_from": row.from_date,
			"effective_to": row.to_date, "remarks": row.karyo_remarks,
			"doctype": "Holiday List", "name": row.name,
		})
	return rows


def work_pattern_context(work_pattern):
	"""Resolve the employee-facing defaults owned by one Work Pattern."""
	if not work_pattern:
		return frappe._dict(
			work_pattern=None, shift_type=None, shift_code=None, calendar_code=None,
			prb_group=None, normal_weekly_hours=0, maximum_work_days=0,
		)
	row = frappe.db.get_value(
		"Employee Work Pattern", work_pattern,
		["name", "default_shift", "calendar_code", "prb_group", "normal_weekly_hours", "maximum_work_days", "disabled"],
		as_dict=True,
	)
	if not row or row.disabled:
		return frappe._dict(work_pattern=work_pattern)
	shift = shift_context(row.default_shift)
	return frappe._dict(
		work_pattern=row.name, shift_type=row.default_shift, shift_code=shift.shift_code,
		calendar_code=row.calendar_code, prb_group=row.prb_group,
		normal_weekly_hours=flt(row.normal_weekly_hours), maximum_work_days=cint(row.maximum_work_days),
	)


@frappe.whitelist()
def employee_work_pattern_assignments():
	"""Employee assignments from the exact Work Pattern field shown on Employee."""
	frappe.has_permission("Employee Work Pattern", "read", throw=True)
	frappe.has_permission("Employee", "read", throw=True)
	employees = frappe.get_list(
		"Employee",
		filters={"status": ["!=", "Left"], "karyo_work_pattern": ["is", "set"]},
		fields=[
			"name", "employee_name", "company", "department", "status",
			"karyo_employee_group", "karyo_work_pattern", "default_shift", "holiday_list",
		],
		order_by="employee_name asc, name asc", limit_page_length=0,
	)
	patterns = {
		row.name: row for row in frappe.get_all(
			"Employee Work Pattern",
			fields=[
				"name", "work_pattern_code", "work_pattern_name", "default_shift",
				"default_shift_code", "prb_group", "normal_weekly_hours", "calendar_code", "disabled",
			],
			limit_page_length=0,
		)
	}
	rows = []
	for employee in employees:
		pattern = patterns.get(employee.karyo_work_pattern) or frappe._dict(name=employee.karyo_work_pattern)
		assignment = _active_schedule_assignment(employee.name)
		rows.append({
			"employee": employee.name,
			"employee_name": employee.employee_name,
			"company": employee.company,
			"department": employee.department,
			"employee_group": employee.karyo_employee_group,
			"work_pattern": employee.karyo_work_pattern,
			"work_pattern_code": pattern.get("work_pattern_code") or employee.karyo_work_pattern,
			"work_pattern_name": pattern.get("work_pattern_name") or employee.karyo_work_pattern,
			"prb_group": pattern.get("prb_group"),
			"normal_weekly_hours": flt(pattern.get("normal_weekly_hours")),
			"shift_type": employee.default_shift or pattern.get("default_shift"),
			"shift_code": pattern.get("default_shift_code"),
			"holiday_list": employee.holiday_list or pattern.get("calendar_code"),
			"roster_schedule": assignment.shift_schedule if assignment else None,
			"assignment": assignment.name if assignment else None,
			"pattern_disabled": cint(pattern.get("disabled")),
		})
	return {"rows": rows, "total": len(rows), "source_field": "Employee.karyo_work_pattern"}


def validate_shift_schedule(doc, method=None):
	if not doc.meta.has_field("karyo_is_rotational") or not doc.karyo_is_rotational:
		return
	cycle_days = cint(doc.karyo_rotation_cycle_days)
	if not 1 <= cycle_days <= 56:
		frappe.throw(_("Rotation Cycle Days must be between 1 and 56."))
	if not doc.karyo_rotation_steps:
		frappe.throw(_("Add at least one Rotation Step."))
	seen = set()
	for step in doc.karyo_rotation_steps:
		day = cint(step.day_index)
		if day < 1 or day > cycle_days:
			frappe.throw(_("Rotation cycle day {0} must be between 1 and {1}.").format(day, cycle_days))
		if day in seen:
			frappe.throw(_("Rotation cycle day {0} is entered more than once.").format(day))
		seen.add(day)
		if step.is_rest_day:
			step.shift_type = None
			step.shift_code = None
			step.start_time = None
			step.end_time = None
			step.duty_hours = 0
			step.duty_label = step.duty_label or _("Rest Day")
			continue
		if not step.shift_type:
			frappe.throw(_("Select a Shift Type for rotation cycle day {0}.").format(day))
		shift = shift_context(step.shift_type)
		step.shift_code = shift.shift_code
		step.start_time = shift.start_time
		step.end_time = shift.end_time
		step.duty_hours = shift.duty_hours
		step.duty_label = step.duty_label or step.shift_type


def _display_time(value):
	if value is None:
		return ""
	if isinstance(value, timedelta):
		seconds = int(value.total_seconds()) % (24 * 3600)
		return f"{seconds // 3600:02d}:{(seconds % 3600) // 60:02d}"
	if hasattr(value, "hour"):
		return f"{value.hour:02d}:{value.minute:02d}"
	parts = str(value).split(".", 1)[0].split(":")
	if len(parts) >= 2:
		try:
			return f"{int(parts[0]):02d}:{int(parts[1]):02d}"
		except ValueError:
			pass
	return str(value)


def schedule_assignment_values(shift_schedule):
	"""Return the Shift Type and read-only rotation snapshot for an assignment."""
	if not shift_schedule:
		return {}
	schedule = frappe.db.get_value(
		"Shift Schedule", shift_schedule,
		["name", "shift_type", "karyo_is_rotational", "karyo_rotation_cycle_days", "docstatus"],
		as_dict=True,
	)
	if not schedule or schedule.docstatus != 1:
		return {}
	lines = []
	if schedule.karyo_is_rotational:
		steps = frappe.get_all(
			"Shift Rotation Step", filters={"parent": schedule.name},
			fields=["day_index", "duty_label", "is_rest_day", "shift_type", "shift_code", "start_time", "end_time"],
			order_by="day_index asc", limit_page_length=0,
		)
		for step in steps:
			if step.is_rest_day:
				lines.append(_("Day {0}: Rest Day").format(step.day_index))
				continue
			label = step.duty_label or step.shift_type
			code = f" [{step.shift_code}]" if step.shift_code else ""
			times = ""
			if step.start_time is not None and step.end_time is not None:
				times = f" ({_display_time(step.start_time)}–{_display_time(step.end_time)})"
			lines.append(f"{_('Day')} {step.day_index}: {label}{code}{times}")
	return {
		"karyo_shift_type": schedule.shift_type,
		"karyo_shift_code": shift_context(schedule.shift_type).shift_code,
		"karyo_is_rotational_schedule": cint(schedule.karyo_is_rotational),
		"karyo_rotation_cycle_days_snapshot": cint(schedule.karyo_rotation_cycle_days)
			if schedule.karyo_is_rotational else 0,
		"karyo_rotation_pattern": "\n".join(lines),
	}


@frappe.whitelist()
def shift_schedule_details(shift_type=None, shift_schedule=None):
	"""Resolve a submitted schedule and its rotation fields from a Shift Type."""
	if shift_schedule:
		values = schedule_assignment_values(shift_schedule)
		if values and shift_type and values["karyo_shift_type"] != shift_type:
			frappe.throw(_("Shift Schedule {0} does not belong to Shift Type {1}.").format(
				shift_schedule, shift_type,
			))
		return {"shift_schedule": shift_schedule, **values} if values else {}
	if not shift_type:
		return {}
	schedules = frappe.get_all(
		"Shift Schedule", filters={"shift_type": shift_type, "docstatus": 1},
		pluck="name", order_by="modified desc", limit_page_length=2,
	)
	if len(schedules) != 1:
		return {"matching_schedule_count": len(schedules)}
	return {"shift_schedule": schedules[0], **schedule_assignment_values(schedules[0])}


def prepare_schedule_assignment(doc, method=None):
	# A schedule selected first can supply its Shift Type.  The field remains
	# mandatory, while the schedule itself is optional for a fixed-shift duty.
	values = schedule_assignment_values(doc.get("shift_schedule")) if doc.get("shift_schedule") else {}
	if values and not doc.get("karyo_shift_type"):
		doc.karyo_shift_type = values["karyo_shift_type"]
	if not doc.get("karyo_shift_type"):
		frappe.throw(_("Select a Shift Type."))
	if doc.meta.has_field("karyo_shift_code"):
		doc.karyo_shift_code = shift_context(doc.karyo_shift_type).shift_code
	if not doc.get("shift_schedule"):
		for fieldname, value in {
			"karyo_is_rotational_schedule": 0,
			"karyo_rotation_cycle_days_snapshot": 0,
			"karyo_rotation_pattern": None,
			"karyo_rotation_anchor_date": None,
		}.items():
			if doc.meta.has_field(fieldname):
				doc.set(fieldname, value)
		return
	if not values:
		frappe.throw(_("Select a submitted Shift Schedule or leave it blank to use Shift Type directly."))
	selected_shift_type = doc.get("karyo_shift_type")
	if selected_shift_type and selected_shift_type != values["karyo_shift_type"]:
		frappe.throw(_("Shift Schedule {0} belongs to Shift Type {1}, not {2}.").format(
			doc.shift_schedule, values["karyo_shift_type"], selected_shift_type,
		))
	for fieldname, value in values.items():
		if doc.meta.has_field(fieldname):
			doc.set(fieldname, value)
	if values["karyo_is_rotational_schedule"]:
		if not doc.karyo_rotation_anchor_date:
			doc.karyo_rotation_anchor_date = doc.create_shifts_after or nowdate()
	elif doc.meta.has_field("karyo_rotation_anchor_date"):
		doc.karyo_rotation_anchor_date = None


class KaryoShiftScheduleAssignment(ShiftScheduleAssignment):
	"""Extend the native scheduler with a multi-shift rotational cycle."""

	def create_shifts(self, start_date: str, end_date: str | None = None) -> None:
		start_date = getdate(start_date)
		end_date = getdate(end_date or add_days(start_date, 90))
		if not self.shift_schedule:
			if not self.karyo_shift_type:
				frappe.throw(_("Select a Shift Type before creating duties."))
			# Preserve manually-entered or previously generated dated duties. Create
			# only the uncovered contiguous ranges for this recurring assignment.
			for range_start, range_end in _uncovered_duty_ranges(self.employee, start_date, end_date):
				self.create_individual_assignment(self.karyo_shift_type, range_start, range_end)
			self.db_set("create_shifts_after", end_date, update_modified=False)
			return
		schedule = frappe.get_doc("Shift Schedule", self.shift_schedule)
		if not schedule.get("karyo_is_rotational"):
			for range_start, range_end in _uncovered_duty_ranges(self.employee, start_date, end_date):
				super().create_shifts(range_start, range_end)
			self.db_set("create_shifts_after", end_date, update_modified=False)
			return
		anchor = getdate(self.get("karyo_rotation_anchor_date") or start_date)
		cycle_days = cint(schedule.karyo_rotation_cycle_days)
		steps = {cint(row.day_index): row for row in schedule.karyo_rotation_steps}
		date = getdate(start_date)
		end = getdate(end_date)
		while date <= end:
			cycle_day = ((date - anchor).days % cycle_days) + 1
			step = steps.get(cycle_day)
			if step and not step.is_rest_day and step.shift_type and _date_has_no_duty(self.employee, date):
				self.create_individual_assignment(step.shift_type, date, date)
			date = getdate(add_days(date, 1))
		self.db_set("create_shifts_after", end, update_modified=False)


def _existing_duty_ranges(employee, start, end):
	rows = frappe.get_all(
		"Shift Assignment",
		filters={"employee": employee, "docstatus": 1, "start_date": ["<=", end]},
		fields=["start_date", "end_date"], limit_page_length=0,
	)
	return [
		(getdate(row.start_date), getdate(row.end_date) if row.end_date else getdate(end))
		for row in rows if not row.end_date or getdate(row.end_date) >= getdate(start)
	]


def _date_has_no_duty(employee, date):
	date = getdate(date)
	return not any(start <= date <= end for start, end in _existing_duty_ranges(employee, date, date))


def _uncovered_duty_ranges(employee, start, end):
	start, end = getdate(start), getdate(end)
	existing = _existing_duty_ranges(employee, start, end)
	ranges = []
	range_start = None
	day = start
	while day <= end:
		covered = any(row_start <= day <= row_end for row_start, row_end in existing)
		if not covered and range_start is None:
			range_start = day
		if covered and range_start is not None:
			ranges.append((range_start, getdate(add_days(day, -1))))
			range_start = None
		day = getdate(add_days(day, 1))
	if range_start is not None:
		ranges.append((range_start, end))
	return ranges


def apply_employee_group_mapping(doc, method=None):
	group = None
	if doc.get("karyo_employee_group"):
		group = frappe.db.get_value(
			"Employee Group",
			doc.karyo_employee_group,
			["karyo_payroll_group", "karyo_work_pattern", "karyo_default_shift"],
			as_dict=True,
		)
	if group:
		if group.karyo_payroll_group:
			doc.karyo_payroll_group = group.karyo_payroll_group
		if group.karyo_work_pattern:
			doc.karyo_work_pattern = group.karyo_work_pattern
	pattern = work_pattern_context(doc.get("karyo_work_pattern"))
	if pattern.get("shift_type"):
		doc.default_shift = group.karyo_default_shift if group and group.karyo_default_shift else pattern.shift_type
	if pattern.get("calendar_code"):
		doc.holiday_list = pattern.calendar_code
	if doc.meta.has_field("karyo_shift_code"):
		doc.karyo_shift_code = shift_context(doc.get("default_shift")).shift_code


def current_duty(employee, on_date=None):
	on_date = getdate(on_date or nowdate())
	# Apply the nullable end-date part in Python; Frappe's simple filters cannot
	# express (end_date is null OR end_date >= on_date) as one safe condition.
	rows = frappe.get_all(
		"Shift Assignment",
		# Status is the assignment's current lifecycle state. An assignment that
		# ended earlier this month is Inactive today but remains authoritative for
		# its historical dates, so date coverage (not current status) is the rule.
		filters={"employee": employee, "docstatus": 1, "start_date": ["<=", on_date]},
		fields=["name", "shift_type", "start_date", "end_date", "shift_schedule_assignment", "shift_location"],
		order_by="start_date desc, creation desc",
		limit_page_length=50,
	)
	rows = [row for row in rows if not row.end_date or getdate(row.end_date) >= on_date]
	if len(rows) > 1:
		frappe.throw(_("More than one active Shift Assignment covers {0} for {1}. Resolve the overlap before calculating duty.").format(on_date, employee))
	if not rows:
		return None
	row = rows[0]
	shift = shift_context(row.shift_type)
	schedule = None
	if row.shift_schedule_assignment:
		schedule = frappe.db.get_value("Shift Schedule Assignment", row.shift_schedule_assignment, "shift_schedule")
	return frappe._dict(
		assignment=row.name,
		schedule_assignment=row.shift_schedule_assignment,
		schedule=schedule,
		shift_type=row.shift_type,
		shift_code=shift.shift_code,
		start_time=shift.start_time,
		end_time=shift.end_time,
		duty_hours=shift.duty_hours,
		shift_location=row.shift_location,
	)


def employee_duty(employee, on_date=None):
	"""Resolve the employee-facing duty from every saved shift mapping.

	Submitted dated Shift Assignments remain authoritative. The recurring
	assignment is also resolved directly so a newly saved roster is visible before
	the generator runs, including explicit rotation rest days. A direct Employee,
	Work Pattern, Group, or shift-code mapping is the final fallback.
	"""
	on_date = getdate(on_date or nowdate())
	employee_name = employee.get("name") if hasattr(employee, "get") else employee
	duty = current_duty(employee_name, on_date)
	if duty:
		duty.source = "Dated roster"
		duty.is_rest_day = False
		return duty

	fields = [
		"name", "default_shift", "karyo_shift_code", "karyo_work_pattern", "karyo_employee_group",
		"karyo_roster_schedule", "karyo_shift_schedule_assignment", "karyo_roster_effective_from",
	]
	profile = frappe.db.get_value("Employee", employee_name, fields, as_dict=True) or frappe._dict(name=employee_name)
	assignment = _active_schedule_assignment(employee_name)
	if assignment:
		effective_from = assignment.get("karyo_rotation_anchor_date") or profile.get("karyo_roster_effective_from")
		if not effective_from:
			first_duty = frappe.db.get_value(
				"Shift Assignment",
				{"shift_schedule_assignment": assignment.name, "docstatus": 1},
				"start_date", order_by="start_date asc",
			)
			effective_from = first_duty or add_days(assignment.get("create_shifts_after") or on_date, 1)
		if getdate(effective_from) <= on_date:
			schedule_name = assignment.get("shift_schedule")
			if schedule_name:
				schedule = frappe.db.get_value(
					"Shift Schedule", schedule_name,
					["shift_type", "karyo_is_rotational", "karyo_rotation_cycle_days"], as_dict=True,
				) or frappe._dict()
				if cint(schedule.get("karyo_is_rotational")) and cint(schedule.get("karyo_rotation_cycle_days")):
					anchor = getdate(assignment.get("karyo_rotation_anchor_date") or effective_from)
					cycle_day = ((on_date - anchor).days % cint(schedule.karyo_rotation_cycle_days)) + 1
					step = frappe.db.get_value(
						"Shift Rotation Step", {"parent": schedule_name, "day_index": cycle_day},
						["is_rest_day", "shift_type", "shift_code", "start_time", "end_time"], as_dict=True,
					)
					if step and cint(step.is_rest_day):
						return frappe._dict(
							assignment=None, schedule_assignment=assignment.name, schedule=schedule_name,
							shift_type=None, shift_code=None, start_time=None, end_time=None, duty_hours=0,
							shift_location=assignment.get("shift_location"), source="Roster schedule",
							is_rest_day=True,
						)
					if step and step.shift_type:
						shift = shift_context(step.shift_type)
						return frappe._dict(
							assignment=None, schedule_assignment=assignment.name, schedule=schedule_name,
							shift_type=step.shift_type, shift_code=step.shift_code or shift.shift_code,
							start_time=step.start_time or shift.start_time, end_time=step.end_time or shift.end_time,
							duty_hours=_time_hours(step.start_time or shift.start_time, step.end_time or shift.end_time),
							shift_location=assignment.get("shift_location"), source="Roster schedule",
							is_rest_day=False,
						)
				shift_name = assignment.get("karyo_shift_type") or schedule.get("shift_type")
			else:
				shift_name = assignment.get("karyo_shift_type")
			if shift_name:
				shift = shift_context(shift_name)
				return frappe._dict(
					assignment=None, schedule_assignment=assignment.name, schedule=schedule_name,
					shift_type=shift_name, shift_code=shift.shift_code, start_time=shift.start_time,
					end_time=shift.end_time, duty_hours=shift.duty_hours,
					shift_location=assignment.get("shift_location"), source="Recurring shift",
					is_rest_day=False,
				)

	shift_name = profile.get("default_shift")
	if not shift_name and profile.get("karyo_work_pattern"):
		shift_name = work_pattern_context(profile.karyo_work_pattern).get("shift_type")
	if not shift_name and profile.get("karyo_employee_group"):
		shift_name = frappe.db.get_value("Employee Group", profile.karyo_employee_group, "karyo_default_shift")
	if not shift_name and profile.get("karyo_shift_code"):
		shift_name = frappe.db.get_value("Shift Type", {"karyo_shift_code": profile.karyo_shift_code}, "name")
	if not shift_name:
		return None
	shift = shift_context(shift_name)
	return frappe._dict(
		assignment=None, schedule_assignment=None, schedule=None,
		shift_type=shift_name, shift_code=shift.shift_code, start_time=shift.start_time,
		end_time=shift.end_time, duty_hours=shift.duty_hours, shift_location=None,
		source="Default shift", is_rest_day=False,
	)


@frappe.whitelist()
def roster_overview(employee=None, from_date=None, to_date=None):
	frappe.has_permission("Shift Assignment", "read", throw=True)
	start = getdate(from_date or nowdate())
	end = getdate(to_date or add_days(start, 30))
	filters = {"docstatus": 1, "start_date": ["<=", end]}
	if employee:
		filters["employee"] = employee
	assignments = frappe.get_list(
		"Shift Assignment",
		filters=filters,
		fields=["name", "employee", "employee_name", "company", "shift_type", "shift_location", "status", "start_date", "end_date", "shift_schedule_assignment"],
		order_by="start_date asc, employee_name asc",
		limit_page_length=500,
	)
	assignments = [row for row in assignments if not row.end_date or getdate(row.end_date) >= start]
	employee_names = list({row.employee for row in assignments})
	employees = {
		row.name: row
		for row in frappe.get_all(
			"Employee",
			filters={"name": ["in", employee_names]},
			fields=["name", "karyo_employee_group", "karyo_work_pattern"],
		)
	}
	for row in assignments:
		shift = shift_context(row.shift_type)
		emp = employees.get(row.employee) or {}
		row.employee_group_code = emp.get("karyo_employee_group")
		row.work_pattern = emp.get("karyo_work_pattern")
		row.shift_code = shift.shift_code
		row.start_time = _display_time(shift.start_time)
		row.end_time = _display_time(shift.end_time)
		row.duty_hours = shift.duty_hours
		row.shift_schedule = (
			frappe.db.get_value("Shift Schedule Assignment", row.shift_schedule_assignment, "shift_schedule")
			if row.shift_schedule_assignment else None
		)
	return {"from_date": str(start), "to_date": str(end), "rows": assignments}


def _expand_month_roster(assignments, start, end):
	"""Expand dated Shift Assignments into one display row for every calendar day."""
	days = []
	day = getdate(start)
	end = getdate(end)
	while day <= end:
		covering = [
			row for row in assignments
			if getdate(row.start_date) <= day
			and (not row.end_date or getdate(row.end_date) >= day)
		]
		if len(covering) > 1:
			days.append({
				"date": str(day), "status": "Conflict", "is_rest_day": False,
				"error": _("More than one Shift Assignment covers this date."),
			})
		elif covering:
			row = covering[0]
			days.append({
				"date": str(day), "status": "Assigned", "is_rest_day": False,
				"assignment": row.name, "shift_type": row.shift_type,
				"shift_code": row.shift_code, "start_time": _display_time(row.start_time),
				"end_time": _display_time(row.end_time), "duty_hours": flt(row.duty_hours),
				"shift_schedule": row.shift_schedule, "shift_location": row.shift_location,
			})
		else:
			days.append({
				"date": str(day), "status": "Rest / No duty", "is_rest_day": True,
				"assignment": None, "shift_type": None, "shift_code": None,
				"start_time": None, "end_time": None, "duty_hours": 0,
				"shift_schedule": None, "shift_location": None,
			})
		day = getdate(add_days(day, 1))
	return days


@frappe.whitelist()
def employee_month_roster(employee, month=None):
	"""Return an employee's complete calendar month from authoritative dated duties."""
	frappe.has_permission("Shift Assignment", "read", throw=True)
	if not employee:
		frappe.throw(_("Select an employee."))
	employee_doc = frappe.get_doc("Employee", employee)
	employee_doc.check_permission("read")

	month_value = str(month or nowdate())[:7]
	if not re.fullmatch(r"\d{4}-\d{2}", month_value):
		frappe.throw(_("Month must use YYYY-MM format."))
	try:
		start = getdate(get_first_day(f"{month_value}-01"))
		end = getdate(get_last_day(start))
	except (TypeError, ValueError):
		frappe.throw(_("Month must use YYYY-MM format."))

	assignments = roster_overview(employee=employee, from_date=start, to_date=end)["rows"]
	days = _expand_month_roster(assignments, start, end)
	return {
		"employee": employee_doc.name,
		"employee_name": employee_doc.employee_name,
		"work_pattern": employee_doc.get("karyo_work_pattern"),
		"month": month_value,
		"month_label": start.strftime("%B %Y"),
		"from_date": str(start),
		"to_date": str(end),
		"days": days,
		"summary": {
			"scheduled_days": sum(row["status"] == "Assigned" for row in days),
			"rest_days": sum(row["is_rest_day"] for row in days),
			"total_hours": sum(flt(row.get("duty_hours")) for row in days),
			"conflicts": sum(row["status"] == "Conflict" for row in days),
		},
	}


SHIFT_SETUP_GROUPS = {"shift", "roster", "staggered"}


def _setup_employee_names(employees, required=False):
	if isinstance(employees, str):
		employees = frappe.parse_json(employees)
	if employees in (None, ""):
		employees = []
	if not isinstance(employees, list) or len(employees) > 100:
		frappe.throw(_("Select up to 100 employees."))
	names = list(dict.fromkeys(str(name).strip() for name in employees if str(name).strip()))
	if required and not names:
		frappe.throw(_("Select at least one employee."))
	return names


def _active_schedule_assignment(employee, exclude=None):
	filters = {"employee": employee, "enabled": 1, "docstatus": ["<", 2]}
	if exclude:
		filters["name"] = ["!=", exclude]
	rows = frappe.get_all(
		"Shift Schedule Assignment", filters=filters,
		fields=["name", "employee", "shift_schedule", "karyo_shift_type", "karyo_shift_code",
			"shift_location", "create_shifts_after", "karyo_rotation_anchor_date", "enabled"],
		order_by="modified desc", limit_page_length=1,
	)
	return rows[0] if rows else None


def _assignment_snapshot(assignment):
	if not assignment:
		return {
			"karyo_roster_schedule": None,
			"karyo_shift_schedule_assignment": None,
			"karyo_shift_location": None,
			"karyo_roster_effective_from": None,
		}
	first_duty = frappe.db.get_value(
		"Shift Assignment", {"shift_schedule_assignment": assignment.get("name"), "docstatus": 1},
		"start_date", order_by="start_date asc",
	)
	return {
		"karyo_roster_schedule": assignment.get("shift_schedule"),
		"karyo_shift_schedule_assignment": assignment.get("name"),
		"karyo_shift_location": assignment.get("shift_location"),
		"karyo_roster_effective_from": assignment.get("karyo_rotation_anchor_date")
			or first_duty or add_days(assignment.get("create_shifts_after") or nowdate(), 1),
	}


def ensure_schedule_assignment_duties(assignment, horizon_days=90):
	"""Generate the first dated duties immediately for a recurring assignment."""
	doc = assignment if hasattr(assignment, "create_shifts") else frappe.get_doc("Shift Schedule Assignment", assignment)
	if frappe.db.exists("Shift Assignment", {"shift_schedule_assignment": doc.name, "docstatus": 1}):
		return 0
	start = getdate(doc.get("karyo_rotation_anchor_date") or add_days(doc.get("create_shifts_after") or nowdate(), 1))
	doc.create_shifts(start, add_days(start, cint(horizon_days) or 90))
	return frappe.db.count("Shift Assignment", {"shift_schedule_assignment": doc.name, "docstatus": 1})


def backfill_schedule_assignment_duties():
	"""Repair active recurring assignments created before immediate generation."""
	generated, failed = {}, {}
	for index, name in enumerate(frappe.get_all(
		"Shift Schedule Assignment", filters={"enabled": 1, "docstatus": ["<", 2]},
		pluck="name", limit_page_length=0,
	), 1):
		savepoint = f"shift_duty_backfill_{index}"
		frappe.db.savepoint(savepoint)
		try:
			count = ensure_schedule_assignment_duties(name)
			if count:
				generated[name] = count
		except Exception as error:
			frappe.db.rollback(save_point=savepoint)
			failed[name] = str(error)
	return {"generated": generated, "failed": failed}


def _write_assignment_snapshot(employee, assignment):
	meta = frappe.get_meta("Employee")
	values = {
		fieldname: value for fieldname, value in _assignment_snapshot(assignment).items()
		if meta.has_field(fieldname)
	}
	if values and frappe.db.exists("Employee", employee):
		frappe.db.set_value("Employee", employee, values, update_modified=False)


def sync_employee_roster_mapping(doc, method=None):
	"""Keep the Employee Attendance tab aligned with the live assignment."""
	if not doc.get("employee"):
		return
	assignment = doc if method != "on_trash" and doc.get("enabled") and doc.docstatus < 2 else _active_schedule_assignment(
		doc.employee, exclude=doc.name,
	)
	_write_assignment_snapshot(doc.employee, assignment)


def _setup_row(employee):
	assignment = _active_schedule_assignment(employee.name)
	group_type = None
	if employee.get("karyo_employee_group"):
		group_type = frappe.db.get_value("Employee Group", employee.karyo_employee_group, "karyo_prb_group")
	requires_assignment = group_type in SHIFT_SETUP_GROUPS
	profile_complete = all(employee.get(fieldname) for fieldname in (
		"karyo_employee_group", "karyo_work_pattern", "default_shift", "holiday_list",
	))
	return {
		**employee,
		"group_type": group_type,
		"assignment": assignment,
		"requires_assignment": requires_assignment,
		"complete": bool(profile_complete and (assignment or not requires_assignment)),
	}


@frappe.whitelist()
def shift_roster_setup_status(employees=None):
	"""Current employee-bound setup and the dependencies used by the wizard."""
	names = _setup_employee_names(employees)
	filters = {"status": ["!=", "Left"]}
	if names:
		filters["name"] = ["in", names]
	rows = frappe.get_list(
		"Employee", filters=filters,
		fields=["name", "employee_name", "company", "department", "status", "karyo_employee_group",
			"karyo_work_pattern", "default_shift", "karyo_shift_code", "holiday_list"],
		order_by="employee_name asc", limit_page_length=100 if names else 2000,
	)
	if names and {row.name for row in rows} != set(names):
		frappe.throw(_("One or more selected employees are unavailable or outside your permissions."), frappe.PermissionError)
	result_rows = [_setup_row(row) for row in rows] if names else []
	rostered_rows = []
	if not names:
		rostered_employees = set(frappe.get_all(
			"Shift Schedule Assignment",
			filters={"enabled": 1, "docstatus": ["<", 2]},
			pluck="employee",
			limit_page_length=0,
		))
		rostered_rows = [
			_setup_row(row) for row in rows if row.name in rostered_employees
		]
	return {
		"rows": result_rows,
		"rostered_rows": rostered_rows,
		"employee_options": [] if names else [
			{"value": row.name, "label": row.employee_name or row.name,
				"description": " · ".join(filter(None, (row.name, row.department, row.company)))}
			for row in rows
		],
		"master_counts": {
			"employee_groups": frappe.db.count("Employee Group"),
			"work_patterns": frappe.db.count("Employee Work Pattern", {"disabled": 0}),
			"shift_types": frappe.db.count("Shift Type"),
			"holiday_lists": frappe.db.count("Holiday List"),
			"shift_schedules": frappe.db.count("Shift Schedule", {"docstatus": 1}),
		},
	}


@frappe.whitelist()
def shift_roster_setup_defaults(employee_group=None, work_pattern=None, shift_type=None):
	"""Resolve downstream choices so every displayed value matches Employee validation."""
	result = {"employee_group": employee_group, "work_pattern": work_pattern,
		"shift_type": shift_type, "shift_code": None, "holiday_list": None,
		"group_type": None, "group_work_pattern": None, "group_shift_type": None,
		"pattern_shift_type": None, "shift_schedule": None, "matching_schedule_count": 0}
	if employee_group:
		group = frappe.get_doc("Employee Group", employee_group)
		group.check_permission("read")
		result.update({
			"work_pattern": group.get("karyo_work_pattern") or work_pattern,
			"shift_type": group.get("karyo_default_shift") or shift_type,
			"group_type": group.get("karyo_prb_group"),
			"group_work_pattern": group.get("karyo_work_pattern"),
			"group_shift_type": group.get("karyo_default_shift"),
		})
	if result["work_pattern"]:
		pattern = frappe.get_doc("Employee Work Pattern", result["work_pattern"])
		pattern.check_permission("read")
		if pattern.disabled:
			frappe.throw(_("Select an active Work Pattern."))
		result["shift_type"] = pattern.default_shift or result["shift_type"]
		result["pattern_shift_type"] = pattern.default_shift
		result["shift_code"] = pattern.default_shift_code
		result["holiday_list"] = pattern.calendar_code
		result["group_type"] = result["group_type"] or pattern.prb_group
	if result["shift_type"]:
		shift = frappe.get_doc("Shift Type", result["shift_type"])
		shift.check_permission("read")
		result["shift_code"] = shift.get("karyo_shift_code")
		schedules = frappe.get_list(
			"Shift Schedule", filters={"shift_type": result["shift_type"], "docstatus": 1},
			pluck="name", order_by="modified desc", limit_page_length=2,
		)
		result["matching_schedule_count"] = len(schedules)
		if len(schedules) == 1:
			result["shift_schedule"] = schedules[0]
	result["requires_assignment"] = result["group_type"] in SHIFT_SETUP_GROUPS
	result["requires_schedule"] = result["group_type"] == "roster"
	return result


def _resolved_shift_roster_values(employee_group, work_pattern, shift_type, holiday_list, shift_schedule):
	defaults = frappe._dict(shift_roster_setup_defaults(employee_group, work_pattern, shift_type))
	if defaults.get("work_pattern") and work_pattern and defaults.work_pattern != work_pattern:
		frappe.throw(_("Employee Group {0} is mapped to Work Pattern {1}, not {2}.").format(
			employee_group, defaults.work_pattern, work_pattern,
		))
	if defaults.get("shift_type") and shift_type and defaults.shift_type != shift_type:
		frappe.throw(_("Work Pattern {0} is mapped to Shift Type {1}, not {2}.").format(
			defaults.work_pattern, defaults.shift_type, shift_type,
		))
	values = frappe._dict({
		"employee_group": employee_group,
		"work_pattern": defaults.work_pattern or work_pattern,
		"shift_type": defaults.shift_type or shift_type,
		"holiday_list": defaults.holiday_list or holiday_list,
		"group_type": defaults.group_type,
		"requires_assignment": defaults.requires_assignment,
		"requires_schedule": defaults.requires_schedule,
		"shift_schedule": shift_schedule,
	})
	missing = [label for fieldname, label in (
		("employee_group", _("Employee Group")), ("work_pattern", _("Work Pattern")),
		("shift_type", _("Shift Type")), ("holiday_list", _("Holiday Calendar")),
	) if not values.get(fieldname)]
	if missing:
		frappe.throw(_("Complete these Shift & Roster dependencies: {0}.").format(", ".join(missing)))
	for doctype, name in (
		("Employee Group", values.employee_group), ("Employee Work Pattern", values.work_pattern),
		("Shift Type", values.shift_type), ("Holiday List", values.holiday_list),
	):
		doc = frappe.get_doc(doctype, name)
		doc.check_permission("read")
	if shift_schedule:
		schedule = frappe.get_doc("Shift Schedule", shift_schedule)
		schedule.check_permission("read")
		if schedule.docstatus != 1:
			frappe.throw(_("Select a submitted Shift Schedule."))
		if schedule.shift_type != values.shift_type:
			frappe.throw(_("Shift Schedule {0} belongs to Shift Type {1}, not {2}.").format(
				shift_schedule, schedule.shift_type, values.shift_type,
			))
	return values


def _replace_shift_assignments_from(employee, effective_from):
	"""Retire duties replaced by a new employee roster from an effective date.

	Historical portions remain submitted for audit. A range crossing the change
	date is shortened; duties beginning on/after it are cancelled so the new
	recurring assignment can generate the authoritative replacement immediately.
	"""
	effective_from = getdate(effective_from)
	previous_day = getdate(add_days(effective_from, -1))
	result = {"cancelled": [], "shortened": []}
	rows = frappe.get_all(
		"Shift Assignment",
		filters={"employee": employee, "docstatus": 1},
		fields=["name", "start_date", "end_date"],
		order_by="start_date asc, name asc",
		limit_page_length=0,
	)
	for row in rows:
		start = getdate(row.start_date)
		end = getdate(row.end_date) if row.end_date else None
		if end and end < effective_from:
			continue
		if start < effective_from:
			frappe.db.set_value(
				"Shift Assignment", row.name, "end_date", previous_day,
				update_modified=False,
			)
			result["shortened"].append(row.name)
			continue
		doc = frappe.get_doc("Shift Assignment", row.name)
		doc.flags.ignore_permissions = True
		doc.cancel()
		result["cancelled"].append(row.name)
	return result


@frappe.whitelist(methods=["POST"])
def save_shift_roster_setup(employees, employee_group, work_pattern=None, shift_type=None,
	holiday_list=None, assignment_mode="direct", shift_schedule=None, shift_location=None,
	effective_from=None):
	"""Atomically bind one setup to one or many Employees and recurring duties."""
	names = _setup_employee_names(employees, required=True)
	assignment_mode = str(assignment_mode or "direct")
	if assignment_mode not in {"direct", "schedule"}:
		frappe.throw(_("Choose Direct recurring shift or Roster schedule."))
	values = _resolved_shift_roster_values(
		employee_group, work_pattern, shift_type, holiday_list,
		shift_schedule if assignment_mode == "schedule" else None,
	)
	if values.requires_schedule and assignment_mode != "schedule":
		frappe.throw(_("Roster employees require a submitted Shift Schedule."))
	if assignment_mode == "schedule" and not shift_schedule:
		frappe.throw(_("Select a submitted Shift Schedule."))
	if assignment_mode in {"direct", "schedule"} and not frappe.has_permission("Shift Schedule Assignment", "create"):
		frappe.throw(_("You do not have permission to create Shift / Roster Assignments."), frappe.PermissionError)
	requested_start = getdate(effective_from or nowdate())
	updated, assignments, adjusted, replaced = [], [], [], []
	for name in names:
		employee = frappe.get_doc("Employee", name)
		employee.check_permission("write")
		employee.karyo_employee_group = values.employee_group
		employee.karyo_work_pattern = values.work_pattern
		employee.default_shift = values.shift_type
		employee.holiday_list = values.holiday_list
		employee.save()
		updated.append(name)
		assignment = _active_schedule_assignment(name)
		if assignment_mode in {"direct", "schedule"}:
			desired_schedule = shift_schedule if assignment_mode == "schedule" else None
			if assignment and assignment.karyo_shift_type == values.shift_type and (assignment.shift_schedule or None) == desired_schedule:
				doc = frappe.get_doc("Shift Schedule Assignment", assignment.name)
				doc.check_permission("write")
				if shift_location != doc.shift_location:
					doc.shift_location = shift_location
					doc.save()
			else:
				if assignment:
					old = frappe.get_doc("Shift Schedule Assignment", assignment.name)
					old.check_permission("write")
					old.enabled = 0
					old.save()
				replacement = _replace_shift_assignments_from(name, requested_start)
				if replacement["cancelled"] or replacement["shortened"]:
					replaced.append({"employee": name, **replacement})
				start = requested_start
				doc = frappe.get_doc({
					"doctype": "Shift Schedule Assignment", "employee": name,
					"company": employee.company, "karyo_shift_type": values.shift_type,
					"shift_schedule": desired_schedule, "shift_location": shift_location,
					"shift_status": "Active", "enabled": 1,
					"create_shifts_after": add_days(start, -1),
					"karyo_rotation_anchor_date": start if desired_schedule else None,
				}).insert()
			assignments.append(doc.name)
			ensure_schedule_assignment_duties(doc)
			_write_assignment_snapshot(name, doc)
		elif assignment:
			_write_assignment_snapshot(name, assignment)
		else:
			_write_assignment_snapshot(name, None)
	return {
		"updated": updated, "assignments": assignments, "adjusted": adjusted, "replaced": replaced,
		"message": _("Shift & Roster Setup saved for {0} employee(s).").format(len(updated)),
	}
