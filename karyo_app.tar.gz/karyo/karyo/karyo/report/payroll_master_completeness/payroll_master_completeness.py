"""Cross-master activation report for Phase 2 payroll readiness."""

import frappe
from frappe import _
from frappe.utils import getdate, nowdate


MASTER_SPECS = {
	"Payroll PDB Type": ("pdb_type", ("description", "classification", "configuration_version")),
	"Payroll PDB Code": ("pdb_code", ("pdb_type", "salary_component", "transaction_mode", "effective_from", "configuration_version")),
	"Payroll Operation Code": ("operation_code", ("operation_category", "effective_from", "configuration_version")),
	"Payroll Bank Branch": ("branch_code", ("bank", "branch_name", "effective_from", "configuration_version")),
	"Payroll Pay Day": ("pay_day_code", ("company", "payroll_period", "payment_date", "input_cutoff_date", "configuration_version")),
	"Payroll PAYE Year": ("tax_year", ("version", "periods_per_year", "bands", "effective_from", "source_reference", "configuration_version")),
	"Payroll Contribution Scheme": ("scheme_code", ("basis_operation_code", "employee_pdb_code", "employer_salary_component", "bands", "effective_from", "configuration_version")),
	"PRB Grade Scale": ("grade_id", ("initial_point", "top_point")),
}


def execute(filters=None):
	filters = frappe._dict(filters or {})
	on_date = getdate(filters.get("on_date") or nowdate())
	rows = []
	for doctype, (key_field, required) in MASTER_SPECS.items():
		fields = list(dict.fromkeys(["name", key_field, "is_active", "effective_from", "effective_to", "configuration_version", *required]))
		fields = [field for field in fields if frappe.get_meta(doctype).has_field(field) or field == "name"]
		for record in frappe.get_all(doctype, fields=fields, order_by="name"):
			rows.append(_assess(doctype, record, key_field, required, on_date))
	return _columns(), rows


def _assess(doctype, record, key_field, required, on_date):
	missing = [field for field in required if field in record and not record.get(field)]
	reasons = [_("Missing {0}").format(field.replace("_", " ")) for field in missing]
	if "is_active" in record and not record.is_active:
		reasons.append(_("Inactive"))
	if record.get("effective_from") and getdate(record.effective_from) > on_date:
		reasons.append(_("Not yet effective"))
	if record.get("effective_to") and getdate(record.effective_to) < on_date:
		reasons.append(_("Expired"))
	configuration = record.get("configuration_version")
	if configuration:
		status, eligible = frappe.db.get_value("Payroll Configuration Version", configuration, ["configuration_status", "is_production_eligible"]) or (None, None)
		if status != "Active" or not eligible:
			reasons.append(_("Configuration is not production eligible"))
	return {
		"status": "Blocked" if reasons else "Ready", "master_type": doctype,
		"record": record.name, "business_key": record.get(key_field),
		"configuration_version": configuration, "finding": "; ".join(reasons),
	}


def _columns():
	return [
		{"fieldname": "status", "label": _("Status"), "fieldtype": "Data", "width": 90},
		{"fieldname": "master_type", "label": _("Master Type"), "fieldtype": "Data", "width": 190},
		{"fieldname": "record", "label": _("Record"), "fieldtype": "Dynamic Link", "options": "master_type", "width": 180},
		{"fieldname": "business_key", "label": _("Business Key"), "fieldtype": "Data", "width": 150},
		{"fieldname": "configuration_version", "label": _("Configuration Version"), "fieldtype": "Link", "options": "Payroll Configuration Version", "width": 190},
		{"fieldname": "finding", "label": _("Finding"), "fieldtype": "Data", "width": 340},
	]
