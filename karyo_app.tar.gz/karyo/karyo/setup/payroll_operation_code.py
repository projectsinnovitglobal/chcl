"""General payroll operation-code mappings (PAY-012)."""

import json

import frappe

from karyo.setup.foundation import f, make_doctype


DEMO_OPERATIONS = [
	("GSAL", "Gross Salary", "Earnings Total", ["BASIC", "EOY", "PBE"]),
	("TDED", "Total Deductions", "Deductions Total", ["PAYE", "NSF", "LOANC", "LOANI", "LOANINS"]),
]


def create_doctypes():
	make_doctype(
		"Payroll Operation Code Item",
		istable=1,
		fields=[
			f("pdb_code", "Link", "PDB Code", options="Payroll PDB Code", reqd=1, in_list_view=1),
			f("sequence", "Int", "Sequence", reqd=1, in_list_view=1),
			f(
				"aggregation_sign",
				"Select",
				"Aggregation Sign",
				options="Add\nSubtract",
				default="Add",
				reqd=1,
				in_list_view=1,
			),
			f(
				"description", "Data", "Description", fetch_from="pdb_code.description",
				read_only=1, in_list_view=1,
			),
			f(
				"inclusion_percentage", "Percent", "Inclusion % / Weight",
				default="100", reqd=1, in_list_view=1,
			),
			f(
				"salary_basis_treatment", "Select", "Salary-Basis Treatment",
				options=(
					"Always\nWhen paid in payroll period\n"
					"Included only when actually processed/paid in relevant payroll period"
				), default="Always", reqd=1,
				in_list_view=1,
			),
			f("effective_from", "Date", "Effective From", in_list_view=1),
			f("effective_to", "Date", "Effective To", in_list_view=1),
			f("remarks", "Small Text", "Remarks", in_list_view=1),
		],
	)
	make_doctype(
		"Payroll Operation Code",
		autoname="field:operation_code",
		naming_rule="By fieldname",
		title_field="description",
		fields=[
			f("identity_sb", "Section Break", "Operation Identity"),
			f(
				"operation_code", "Data", "Operation Code", reqd=1, unique=1, in_list_view=1
			),
			f("description", "Data", "Description", reqd=1, in_list_view=1),
			f(
				"operation_category",
				"Select",
				"Category",
				options=(
					"Earnings Total\nDeductions Total\nContribution Basis\nTax Basis\n"
					"Net Pay Basis\nReporting Group\nOther"
				),
				default="Other",
				reqd=1,
				in_list_view=1,
			),
			f("identity_cb", "Column Break"),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("effective_from", "Date", "Effective From", reqd=1, default="2026-01-01"),
			f("effective_to", "Date", "Effective To"),
			f(
				"configuration_version",
				"Link",
				"Configuration Version",
				options="Payroll Configuration Version",
				reqd=1,
			),
			f("mapping_sb", "Section Break", "Ordered PDB Mapping"),
			f("items", "Table", "PDB Codes", options="Payroll Operation Code Item", reqd=1),
			f("governance_sb", "Section Break", "Governance"),
			f("company", "Link", "Company", options="Company"),
			f("source_reference", "Data", "Source Reference"),
			f(
				"legacy_loan_operation_code",
				"Link",
				"Related Loan Appraisal Operation",
				options="Loan Operation Code",
			),
			f(
				"notes",
				"Small Text",
				"Notes",
				description=(
					"Nested operation codes are intentionally unsupported, so circular mappings "
					"cannot be created."
				),
			),
		],
	)


def ensure_demo_configuration():
	if frappe.db.exists(
		"Payroll Configuration Version", {"config_key": "DEMO-OP-CODES-2026", "version": "DEMO-1"}
	):
		return frappe.db.get_value(
			"Payroll Configuration Version",
			{"config_key": "DEMO-OP-CODES-2026", "version": "DEMO-1"},
			"name",
		)
	return frappe.get_doc(
		{
			"doctype": "Payroll Configuration Version",
			"config_key": "DEMO-OP-CODES-2026",
			"configuration_type": "Operation Codes",
			"version": "DEMO-1",
			"configuration_status": "Demo",
			"is_production_eligible": 0,
			"effective_from": "2026-01-01",
			"source_reference": "Payroll manual examples",
			"configuration_json": json.dumps(
				{"warning": "Demo aggregate mappings; replace with signed client catalogue."}, indent=2
			),
			"notes": "DEMO ONLY — not eligible for production payroll.",
		}
	).insert(ignore_permissions=True).name


def seed_demo_data():
	configuration = ensure_demo_configuration()
	for operation_code, description, category, pdb_codes in DEMO_OPERATIONS:
		if frappe.db.exists("Payroll Operation Code", operation_code):
			continue
		available = [code for code in pdb_codes if frappe.db.exists("Payroll PDB Code", code)]
		if not available:
			continue
		frappe.get_doc(
			{
				"doctype": "Payroll Operation Code",
				"operation_code": operation_code,
				"description": f"{description} (Demo)",
				"operation_category": category,
				"is_active": 1,
				"effective_from": "2026-01-01",
				"configuration_version": configuration,
				"source_reference": "DEMO mapping — client operation-code catalogue pending",
				"items": [
					{"pdb_code": code, "sequence": index, "aggregation_sign": "Add"}
					for index, code in enumerate(available, 1)
				],
			}
		).insert(ignore_permissions=True)


def setup():
	print("Karyo Payroll operation-code setup:")
	create_doctypes()
	from karyo.install import samples_enabled

	if samples_enabled():
		seed_demo_data()
	frappe.db.commit()
	print("Done (ordered general PDB mappings created; loan appraisal codes preserved).")
