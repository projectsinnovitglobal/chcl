import unittest
import frappe
from karyo.tests import test_employee_payslip_button as payslip_fixture
from karyo.payroll.employee_salary_workspace import context, overtime_payroll_context, preview
from karyo.desk.payroll_management import generate_employee_payslip


def _delete_test_salary_structure(name):
    """Remove the temporary submitted structure after fixture links are cleaned up."""
    if not frappe.db.exists('Salary Structure', name):
        return
    frappe.db.delete('Salary Detail', {'parent': name})
    frappe.db.delete('Salary Structure', {'name': name})


class TestEmployeeSalaryWorkspace(unittest.TestCase):
    def setUp(self):
        self.fixture = payslip_fixture.TestEmployeePayslipButton()
        self.fixture.setUp()
        self.employee = self.fixture.employee.name

    def tearDown(self):
        self.fixture.tearDown()

    def test_preview_matches_generated_payslip_without_creating_records(self):
        before = frappe.db.count('Salary Slip')
        result = preview(self.employee, '2026-06')
        self.assertTrue(result['preview_only'])
        self.assertEqual(frappe.db.count('Salary Slip'), before)
        slip = frappe.get_doc('Salary Slip', generate_employee_payslip(self.employee, self.fixture.period, '2026-06')['name'])
        for field in ['salary_structure', 'gross_pay', 'total_deduction', 'net_pay', 'payment_days']:
            self.assertEqual(result[field], slip.get(field), field)
        self.assertEqual([(r['salary_component'], r['amount']) for r in result['earnings']],
                         [(r.salary_component, r.amount) for r in slip.earnings])

    def test_context_scopes_assignments_and_slips_to_employee(self):
        doc = generate_employee_payslip(self.employee, self.fixture.period, '2026-06')
        result = context(self.employee, '2026-06')
        self.assertTrue(result['period'])
        self.assertEqual(len(result['assignments']), 1)
        self.assertEqual([s.name for s in result['slips']], [doc['name']])
        self.assertTrue(result['components'])
        self.assertTrue(result['component_catalogue'])
        self.assertEqual(result['current'].salary_structure, self.fixture.salary_structure)
        for fieldname in (
            'group', 'payroll_type', 'pay_day', 'grade', 'grade_description', 'scale',
            'salary_point', 'ctc', 'salary_appointment', 'salary_effective_from',
            'payment_mode', 'payroll_bank', 'payroll_bank_branch',
        ):
            self.assertIn(fieldname, result)

    def test_missing_setup_and_unauthorized_access_are_blocked(self):
        frappe.db.delete('Salary Structure Assignment', {'employee': self.employee})
        with self.assertRaisesRegex(frappe.ValidationError, 'Salary Structure Assignment'):
            preview(self.employee, '2026-06')
        frappe.set_user('Guest')
        for method in [context, preview]:
            with self.assertRaises(frappe.PermissionError):
                method(self.employee, '2026-06')

    def test_payroll_tab_contains_setup_without_duplicate_appointments_tab(self):
        fields = frappe.get_meta('Employee').fields
        tabs = [f.fieldname for f in fields if f.fieldtype == 'Tab Break']
        self.assertNotIn('karyo_salary_allocation_tab', tabs)
        self.assertEqual(frappe.get_meta('Employee').get_field('salary_information').label, 'Payroll')
        current = None
        mapping = {}
        for f in fields:
            if f.fieldtype == 'Tab Break': current = f.fieldname
            mapping[f.fieldname] = current
        self.assertEqual(mapping['karyo_salary_workspace'], 'karyo_employee_payroll_tab')
        for fieldname in (
            'karyo_time_payroll_section', 'karyo_hourly_rate',
            'karyo_hourly_rate_calculation', 'karyo_time_payroll_linkage',
        ):
            self.assertEqual(mapping[fieldname], 'karyo_employee_payroll_tab')
        order = [field.fieldname for field in fields]
        self.assertLess(order.index('karyo_salary_workspace'), order.index('karyo_time_payroll_section'))
        self.assertLess(order.index('karyo_time_payroll_section'), order.index('karyo_hourly_rate'))
        self.assertLess(order.index('karyo_hourly_rate'), order.index('karyo_time_payroll_linkage'))

    def test_overtime_payroll_context_exposes_rate_and_all_component_links(self):
        result = overtime_payroll_context(self.employee)
        self.assertEqual(result['employee'], self.employee)
        self.assertGreater(result['rate']['hourly_rate'], 0)
        self.assertIn('monthly basic', result['rate']['calculation'])
        mappings = {row['component_code']: row for row in result['mappings']}
        self.assertEqual(set(mappings), {'OVERTIME', 'NIGHT_DUTY', 'EXCESS_HOURS'})
        for row in mappings.values():
            self.assertTrue(row['active'])
            self.assertTrue(row['pdb_code'])
            self.assertTrue(row['salary_component'])

    def test_selection_persists_and_same_month_change_preserves_history(self):
        from unittest.mock import patch
        from uuid import uuid4
        from karyo.payroll.employee_salary_workspace import select_structure, component_table
        original = frappe.get_doc('Salary Structure', self.fixture.salary_structure)
        slab = frappe.db.get_value('Salary Structure Assignment', {'employee': self.employee}, 'income_tax_slab')
        frappe.db.set_value('Income Tax Slab', slab, 'currency', original.currency)
        alternate = frappe.copy_doc(original)
        alternate.name = 'Structure selection ' + uuid4().hex
        alternate.docstatus = 1
        alternate.db_insert()
        self.addCleanup(_delete_test_salary_structure, alternate.name)
        for kind in ('earnings', 'deductions'):
            for row in alternate.get(kind):
                row.parent = alternate.name
                row.docstatus = 1
                row.db_insert()
        with patch('karyo.payroll.employee_salary_workspace.today', return_value='2026-06-14'):
            selected = select_structure(self.employee, alternate.name)
            self.assertEqual(selected['current'].salary_structure, alternate.name)
            self.assertTrue(selected['calculation'])
            self.assertEqual(component_table(self.employee)['current'].salary_structure, alternate.name)
            count = frappe.db.count('Salary Structure Assignment', {'employee': self.employee})
            select_structure(self.employee, alternate.name)
            self.assertEqual(frappe.db.count('Salary Structure Assignment', {'employee': self.employee}), count)
            changed = select_structure(self.employee, original.name)
            self.assertEqual(changed['current'].salary_structure, original.name)
            self.assertEqual(frappe.db.get_value('Salary Structure Assignment', selected['current'].name, 'docstatus'), 2)
            generated = generate_employee_payslip(self.employee, self.fixture.period, '2026-06')
            slip = frappe.get_doc('Salary Slip', generated['name'])
            self.assertEqual(slip.salary_structure, original.name)
            self.assertEqual(slip.net_pay, preview(self.employee, '2026-06')['net_pay'])
            # Draft payroll is a recalculable working document. Changing the
            # governed structure refreshes it instead of blocking setup.
            select_structure(self.employee, alternate.name)
            slip.reload()
            self.assertEqual(slip.salary_structure, alternate.name)
            frappe.db.set_value('Salary Slip', slip.name, 'docstatus', 1)
            with self.assertRaisesRegex(frappe.ValidationError, 'submitted payslips'):
                select_structure(self.employee, original.name)

    def test_selection_rejects_draft_structure_and_guest(self):
        from karyo.payroll.employee_salary_workspace import select_structure
        structure = self.fixture.salary_structure
        frappe.db.set_value('Salary Structure', structure, 'docstatus', 0)
        with self.assertRaisesRegex(frappe.ValidationError, 'active, submitted'):
            select_structure(self.employee, structure)
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):
            select_structure(self.employee, structure)

    def test_prb_row3_point_updates_native_assignment_base(self):
        from karyo.payroll.employee_salary_workspace import sync_base_from_prb_point

        assignment = sync_base_from_prb_point(self.employee, "060", "2026-09-17")
        self.assertTrue(assignment)
        latest = frappe.db.get_value(
            "Salary Structure Assignment",
            {"employee": self.employee, "docstatus": 1},
            ["name", "from_date", "base"],
            as_dict=True,
            order_by="from_date desc, creation desc",
        )
        self.assertEqual(latest.name, assignment)
        self.assertEqual(str(latest.from_date), "2026-09-17")
        self.assertEqual(latest.base, 37290)


    def test_structure_table_uses_template_amounts_without_payroll_adjustments(self):
        from karyo.payroll.employee_salary_workspace import component_table
        assignment = frappe.db.get_value('Salary Structure Assignment', {'employee': self.employee}, 'name')
        frappe.db.set_value('Salary Structure Assignment', assignment,
                            {'salary_structure': 'MAI Staff Structure', 'base': 50000})
        before = frappe.db.count('Salary Slip')
        result = component_table(self.employee, '2026-06')['calculation']
        self.assertTrue(result['structure_only'])
        earnings = {r['salary_component']: r['amount'] for r in result['earnings']}
        deductions = {r['salary_component']: r['amount'] for r in result['deductions']}
        self.assertEqual(earnings, {'Basic': 50000, 'Transport Allowance': 2600, 'Medical Allowance': 1500})
        self.assertEqual(deductions, {'CSG': 750, 'NSF': 500, 'PAYE': None})
        self.assertEqual(result['gross_pay'], 54100)
        self.assertEqual(result['total_deduction'], 1250)
        self.assertEqual(result['net_pay'], 52850)
        self.assertEqual(result['pending_components'], ['PAYE'])
        self.assertEqual(frappe.db.count('Salary Slip'), before)
        # A structure table has no Payroll Period or attendance prerequisite.
        frappe.db.delete('Payroll Period', {'name': self.fixture.period})
        self.assertEqual(component_table(self.employee, '2026-06')['calculation'], result)
