"""Karyo Loan — payroll operation codes + appraisal drill-down (Phase 4A).

    bench --site dev.localhost execute karyo.setup.loan_operation_code.setup

Creates Loan Operation Code + its item child (payroll appraisal groupings for
Eligible Salary, External Deductions and Other Deductions with per-component
percentage weighting — BR-FAR-LMS-REF-017/018) and the Karyo Loan Appraisal
Detail drill-down child table (PAY-008/010). Operation codes are client-specific
config (OI-FAR-004) and are not seeded; appraisal falls back to base salary until
they are configured. Idempotent.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"Loan Operation Code Item",
		istable=1,
		fields=[
			f(
				"salary_component",
				"Link",
				"Salary Component",
				options="Salary Component",
				reqd=1,
				in_list_view=1,
			),
			f(
				"percentage",
				"Percent",
				"Weighting %",
				default="100",
				in_list_view=1,
				description="Portion of this component included in the grouping (REF-018).",
			),
		],
	)
	make_doctype(
		"Loan Operation Code",
		autoname="field:operation_code",
		naming_rule="By fieldname",
		title_field="description",
		fields=[
			f("operation_code", "Data", "Operation Code", reqd=1, unique=1, in_list_view=1),
			f("description", "Data", "Description", in_list_view=1),
			f(
				"function",
				"Select",
				"Function",
				options="Eligible Salary\nExternal Deductions\nOther Deductions",
				reqd=1,
				in_list_view=1,
			),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
			f("comp_sb", "Section Break", "Salary Components"),
			f("components", "Table", "Components", options="Loan Operation Code Item"),
		],
	)
	make_doctype(
		"Karyo Loan Appraisal Detail",
		istable=1,
		fields=[
			f("function", "Data", "Function", in_list_view=1),
			f("operation_code", "Data", "Operation Code", in_list_view=1),
			f("salary_component", "Link", "Salary Component", options="Salary Component", in_list_view=1),
			f("pdb_type", "Data", "PDB Type", in_list_view=1),
			f("amount", "Currency", "Amount", in_list_view=1),
			f("percentage", "Percent", "Weighting %"),
			f("weighted_amount", "Currency", "Weighted Amount", in_list_view=1),
		],
	)


def add_loan_fields():
	create_custom_fields(
		{
			"Karyo Loan": [
				{"fieldname": "appraisal_payroll_cycle", "fieldtype": "Link", "label": "Appraisal Payroll Cycle", "options": "Payroll Cycle", "insert_after": "appraisal_sb"},
				{"fieldname": "appraisal_payroll_period", "fieldtype": "Link", "label": "Payroll Period", "options": "Payroll Period", "read_only": 0, "reqd": 0, "insert_after": "appraisal_payroll_cycle", "description": "Mandatory before appraisal/approval; must be backed by an Approved or Closed Payroll Cycle."},
				{"fieldname": "current_deduction_pct", "fieldtype": "Percent", "label": "Current Deduction %", "read_only": 1, "insert_after": "deduction_pct"},
				{"fieldname": "maximum_deduction_pct", "fieldtype": "Percent", "label": "Maximum Deduction % Applied", "read_only": 1, "insert_after": "current_deduction_pct"},
				{
					"fieldname": "appraisal_details_sb",
					"fieldtype": "Section Break",
					"label": "Appraisal Breakdown",
					"insert_after": "override_deduction_limit",
					"collapsible": 1,
				},
				{
					"fieldname": "appraisal_details",
					"fieldtype": "Table",
					"label": "Appraisal Detail",
					"options": "Karyo Loan Appraisal Detail",
					"insert_after": "appraisal_details_sb",
				},
				{"fieldname": "appraisal_snapshot", "fieldtype": "Code", "label": "Frozen Appraisal Snapshot", "options": "JSON", "read_only": 1, "insert_after": "appraisal_details"},
				{"fieldname": "appraisal_snapshot_hash", "fieldtype": "Data", "label": "Appraisal Snapshot Hash", "read_only": 1, "insert_after": "appraisal_snapshot"},
				{"fieldname": "appraised_by", "fieldtype": "Link", "label": "Appraised By", "options": "User", "read_only": 1, "insert_after": "appraisal_snapshot_hash"},
				{"fieldname": "appraised_on", "fieldtype": "Datetime", "label": "Appraised On", "read_only": 1, "insert_after": "appraised_by"},
				{"fieldname": "calculation_snapshot", "fieldtype": "Code", "label": "Frozen Calculation Snapshot", "options": "JSON", "read_only": 1, "hidden": 1, "insert_after": "appraised_on"},
				{"fieldname": "calculation_snapshot_hash", "fieldtype": "Data", "label": "Calculation Snapshot Hash", "read_only": 1, "hidden": 1, "insert_after": "calculation_snapshot"},
				{"fieldname": "planned_repayment_end_date", "fieldtype": "Date", "label": "Planned Repayment End Date", "read_only": 1, "insert_after": "repayment_start_date"},
				{"fieldname": "remaining_service_months", "fieldtype": "Int", "label": "Remaining Service Months", "read_only": 1, "insert_after": "planned_repayment_end_date"},
			],
			"Karyo Settings": [
				{"fieldname": "require_appraisal_payroll_cycle", "fieldtype": "Check", "label": "Require Approved/Closed Payroll Cycle for Loan Appraisal", "default": "1", "read_only": 1, "insert_after": "max_deduction_pct", "description": "Mandatory for MBC loan appraisal."},
				{"fieldname": "loan_deduction_override_role", "fieldtype": "Link", "label": "Affordability Override Role", "options": "Role", "insert_after": "require_appraisal_payroll_cycle", "description": "MBC-controlled role permitted to override the maximum deduction percentage."},
				{"fieldname": "loan_interest_recovery_method", "fieldtype": "Select", "label": "Loan Interest Recovery Method", "options": "Equal Monthly Payroll Deduction\nReducing Balance Per Schedule", "default": "Equal Monthly Payroll Deduction", "insert_after": "loan_deduction_override_role", "description": "Configurable pending MBC confirmation; equal monthly preserves the existing payroll treatment."},
			],
		},
		ignore_validate=True,
	)
	print("  + Karyo Loan appraisal drill-down field ensured")


def setup():
	print("Karyo Loan operation code setup:")
	create_doctypes()
	add_loan_fields()
	if not frappe.db.get_single_value("Karyo Settings", "loan_interest_recovery_method"):
		# Preserve the existing payroll treatment explicitly; this remains a
		# provisional configurable value until MBC confirms SCH-005.
		frappe.db.set_single_value("Karyo Settings", "loan_interest_recovery_method", "Equal Monthly Payroll Deduction")
	frappe.db.commit()
	print("Done.")
