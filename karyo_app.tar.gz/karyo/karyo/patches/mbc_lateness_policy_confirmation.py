"""Apply MBC's confirmed late/early-to-Casual-Leave policy."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


POLICY = {
	"enable_lateness_leave_deduction": 1,
	"lateness_divisor_source": "Scheduled Shift",
	"lateness_accumulation_period": "Payroll Period",
	"lateness_minimum_minutes": 120,
	"lateness_rounding_mode": "Up",
	"lateness_rounding_increment_days": 0.5,
	"lateness_approval_workflow": "Leave Approver Submits Deduction",
	"lateness_policy_approval_reference": "MBC confirmation 2026-09-24",
}


def execute():
	create_custom_fields({
		"Attendance": [
			{"fieldname": "karyo_detected_late_minutes", "fieldtype": "Float",
				"label": "Chargeable Late / Early Minutes", "read_only": 1,
				"insert_after": "karyo_lateness_sb"},
			{"fieldname": "karyo_detected_late_entry_minutes", "fieldtype": "Float",
				"label": "Late Entry Minutes after Grace", "read_only": 1,
				"insert_after": "karyo_detected_late_minutes"},
			{"fieldname": "karyo_detected_early_exit_minutes", "fieldtype": "Float",
				"label": "Early Exit Minutes after Grace", "read_only": 1,
				"insert_after": "karyo_detected_late_entry_minutes"},
			{"fieldname": "karyo_late_entry_grace_minutes", "fieldtype": "Float",
				"label": "Late Entry Grace Applied", "read_only": 1,
				"insert_after": "karyo_detected_early_exit_minutes"},
			{"fieldname": "karyo_early_exit_grace_minutes", "fieldtype": "Float",
				"label": "Early Exit Grace Applied", "read_only": 1,
				"insert_after": "karyo_late_entry_grace_minutes"},
		],
	}, update=True)
	for fieldname, value in POLICY.items():
		frappe.db.set_single_value("MBC Leave Settings", fieldname, value)

	# Shift Type already provides these number inputs; make their use in the MBC
	# conversion explicit for administrators configuring late/early modules.
	make_property_setter(
		"Shift Type", "late_entry_grace_period", "description",
		"Minutes ignored after shift start. Only excess late minutes enter the MBC Payroll Cycle calculation.",
		"Text",
	)
	make_property_setter(
		"Shift Type", "early_exit_grace_period", "description",
		"Minutes ignored before shift end. Only excess early-exit minutes enter the MBC Payroll Cycle calculation.",
		"Text",
	)
	frappe.clear_cache(doctype="Attendance")
	frappe.clear_cache(doctype="Shift Type")
	frappe.clear_document_cache("MBC Leave Settings", "MBC Leave Settings")

