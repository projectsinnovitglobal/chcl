"""PRB 2026 overtime, night duty, acting and responsibility allowance tests.

Anchored to ``PRB_2026_Overtime_NightDuty_Acting_Responsibility_Computation.docx``
(Pay Review 2026, Volume 1, chapter 16.5 and section 16.10), supplied by the
client. Section numbers in the test names refer to that document.
"""

from unittest import TestCase

from karyo.prb.movements import (
	acting_allowance_base,
	higher_duty_allowance_breakdown,
	responsibility_allowance,
)
from karyo.prb.overtime import (
	deemed_hours,
	eligible_overtime_hours,
	excess_hours_amount,
	hourly_rate,
	night_duty_amount,
	night_duty_amount_from_salary,
	night_duty_eligibility,
	night_window_hours,
	overtime_amount_from_salary,
	overtime_claim_eligibility,
	overtime_eligibility,
	overtime_period_covers_interval,
	overtime_period_hours,
	weekly_threshold,
)

# FAR17 from the client salary-scale guide: Rs 16,785 to Rs 34,825 over 38
# points. The acting-allowance example in section 8.4 moves 26,050 -> 26,725 ->
# 27,400 -> 28,225, which is the 675/675/825 run in this scale.
FAR17_BANDS = [
	(16785, 260), (17825, 275), (18925, 300), (19525, 325), (21475, 375),
	(22225, 400), (23425, 525), (26050, 675), (27400, 825), (34825, 0),
]


def _far17():
	salaries = [FAR17_BANDS[0][0]]
	for index, (salary, increment) in enumerate(FAR17_BANDS[:-1]):
		stop = FAR17_BANDS[index + 1][0]
		salaries.extend(range(salary + increment, stop + 1, increment))
	ordered = list(range(1, len(salaries) + 1))
	return {point: salary for point, salary in zip(ordered, salaries)}, ordered


class TestPRB2026OvertimeReference(TestCase):
	def test_far17_matches_the_client_scale_guide(self):
		revised, ordered = _far17()
		self.assertEqual(len(ordered), 38)
		self.assertEqual((revised[1], revised[2], revised[38]), (16785, 17045, 34825))

	# Section 5 — hourly-rate computation.
	def test_hourly_rate_uses_the_prescribed_denominators(self):
		self.assertEqual(hourly_rate(55000 * 12, 33.75), 376.07)
		self.assertEqual(hourly_rate(45000 * 12, 40), 259.62)

	# Section 12 — worked examples.
	def test_worked_example_below_the_ceiling(self):
		self.assertEqual(overtime_amount_from_salary(55000, 5), 2820.51)

	def test_worked_example_in_the_eighty_percent_band(self):
		self.assertEqual(
			overtime_amount_from_salary(65000, 4, urgent=True, middle_band_requires_urgent=True),
			2133.33,
		)

	def test_worked_example_workmens_group_sunday(self):
		self.assertEqual(
			overtime_amount_from_salary(45000, 8, group="workmen", period="sunday_holiday_cyclone"),
			4153.85,
		)

	def test_worked_example_higher_duties_includes_the_allowance(self):
		# Rs 50,000 salary plus a Rs 3,000 Responsibility Allowance; the ceiling
		# gate still looks at the substantive basic salary.
		self.assertEqual(overtime_amount_from_salary(53000, 3, monthly_basic=50000), 1630.77)

	# Section 7 — salary ceiling.
	def test_salary_ceiling_boundaries(self):
		self.assertEqual(overtime_eligibility(60599), (True, 1.0))
		self.assertEqual(overtime_eligibility(60600, middle_band_requires_urgent=True), (False, 0.0))
		self.assertEqual(overtime_eligibility(60600, urgent=True, middle_band_requires_urgent=True), (True, 0.8))
		self.assertEqual(overtime_eligibility(77750, urgent=True, middle_band_requires_urgent=True), (True, 0.8))
		self.assertEqual(overtime_eligibility(77751), (False, 0.0))

	def test_middle_band_requires_urgent_work_in_the_prb_policy(self):
		self.assertEqual(
			overtime_amount_from_salary(
				65000, 4, middle_band_requires_urgent=True,
			),
			0,
		)

	# Section 2 — weekly eligibility.
	def test_weekly_thresholds(self):
		self.assertEqual(weekly_threshold("other"), 40)
		self.assertEqual(weekly_threshold("workmen"), 40)
		self.assertEqual(weekly_threshold("surveillant"), 60)

	def test_overtime_starts_only_above_the_weekly_threshold(self):
		self.assertEqual(eligible_overtime_hours(40, 40, "workmen"), 0)
		self.assertEqual(eligible_overtime_hours(45, 40, "workmen"), 5)
		self.assertEqual(eligible_overtime_hours(60, 60, "surveillant"), 0)
		self.assertEqual(eligible_overtime_hours(65, 60, "surveillant"), 5)

	def test_short_week_becomes_payable_once_forty_hours_are_exceeded(self):
		# A 33.75-hour officer working 38 hours has not passed 40, so nothing is
		# overtime. At 45 hours everything above the normal week is payable.
		self.assertEqual(eligible_overtime_hours(38, 33.75), 0)
		self.assertEqual(eligible_overtime_hours(45, 33.75), 11.25)

	def test_continuous_overtime_uses_the_weekly_average(self):
		self.assertEqual(eligible_overtime_hours(160, 33.75, weeks=4), 0)
		self.assertEqual(eligible_overtime_hours(170, 33.75, weeks=4), 35)

	# Section 4 — hours counted for overtime.
	def test_deemed_hours_for_leave_and_public_holidays(self):
		self.assertEqual(deemed_hours(9, "approved_leave"), 8)
		self.assertEqual(deemed_hours(6, "approved_leave"), 6)
		self.assertEqual(deemed_hours(9, "public_holiday"), 8)
		self.assertEqual(deemed_hours(8, "approved_leave", shift_worker=True, shift_hours=12), 12)
		self.assertEqual(deemed_hours(8, "public_holiday", shift_worker=True), 0)

	# Section 10 — extra hours between 33 3/4 and 40 (paragraph 16.5.71).
	def test_excess_hours_pay_the_normal_rate_only_above_the_minimum(self):
		rate = hourly_rate(55000 * 12, 33.75)
		self.assertEqual(excess_hours_amount(4, rate, monthly_basic=55000), 0)
		self.assertEqual(excess_hours_amount(5, rate, monthly_basic=55000), round(5 * rate, 2))
		self.assertEqual(excess_hours_amount(14, rate, monthly_basic=55000, basis="month"), 0)
		self.assertEqual(
			excess_hours_amount(15, rate, monthly_basic=55000, basis="month"), round(15 * rate, 2)
		)

	def test_excess_hours_exclude_shift_patterns_and_the_upper_salary_point(self):
		rate = hourly_rate(55000 * 12, 33.75)
		for group in ("shift", "roster", "staggered"):
			self.assertEqual(excess_hours_amount(8, rate, group=group, monthly_basic=55000), 0)
		self.assertEqual(excess_hours_amount(8, rate, monthly_basic=77750), 0)

	# Section 9 — night duty allowance.
	def test_night_duty_is_a_quarter_of_the_normal_hourly_rate(self):
		rate = hourly_rate(52000 * 12, 33.75)
		self.assertEqual(night_duty_amount(8, rate), round(8 * rate * 0.25, 2))
		self.assertEqual(night_duty_amount(8, rate, percentage=20), round(8 * rate * 0.20, 2))

	def test_night_duty_window_and_category_controls(self):
		self.assertEqual(night_window_hours("2026-09-20 22:00:00", "2026-09-21 06:00:00"), 6)
		self.assertTrue(night_duty_eligibility("other", overtime_eligible=True))
		self.assertTrue(night_duty_eligibility("other", hourly_paid=True))
		for group in ("shift", "roster", "staggered"):
			self.assertFalse(night_duty_eligibility(group, overtime_eligible=True))
		self.assertEqual(
			night_duty_amount_from_salary(52000, 6, overtime_eligible=True),
			533.33,
		)

	def test_recorded_times_must_match_the_prescribed_rate_period(self):
		self.assertEqual(
			overtime_period_hours("2026-09-21 18:00:00", "2026-09-21 23:00:00", "weekday_day"),
			5,
		)
		self.assertTrue(
			overtime_period_covers_interval(
				"2026-09-21 23:00:00", "2026-09-22 05:00:00", "weekday_night"
			)
		)
		self.assertFalse(
			overtime_period_covers_interval(
				"2026-09-21 22:00:00", "2026-09-22 01:00:00", "weekday_day"
			)
		)
		self.assertTrue(
			overtime_period_covers_interval(
				"2026-09-20 08:00:00", "2026-09-20 16:00:00", "sunday"
			)
		)

	def test_authorised_claim_applies_weekly_and_shift_controls(self):
		result = overtime_claim_eligibility(
			claimed_hours=8,
			total_actual_hours=45,
			normal_weekly_hours=40,
			group="workmen",
		)
		self.assertEqual(result, {"eligible": True, "hours": 5.0, "reason": "ELIGIBLE"})
		self.assertEqual(
			overtime_claim_eligibility(
				claimed_hours=8,
				total_actual_hours=48,
				normal_weekly_hours=40,
				group="shift",
				period="sunday",
				outside_normal_schedule=False,
			)["reason"],
			"INSIDE_NORMAL_SHIFT",
		)
		self.assertEqual(
			overtime_claim_eligibility(
				claimed_hours=5,
				total_actual_hours=45,
				normal_weekly_hours=33.75,
				group="staggered",
				period="weekday_day",
				outside_normal_schedule=False,
			)["reason"],
			"INSIDE_NORMAL_SHIFT",
		)
		self.assertEqual(
			overtime_claim_eligibility(
				claimed_hours=8,
				total_actual_hours=48,
				normal_weekly_hours=40,
				group="shift",
				days_worked=7,
			)["reason"],
			"SHIFT_WEEK_EXCEEDS_SIX_DAYS",
		)
		self.assertEqual(
			overtime_claim_eligibility(
				claimed_hours=8,
				total_actual_hours=48,
				group="disciplined_force",
			)["reason"],
			"DISCIPLINED_FORCE_EXCLUDED",
		)

	# Section 8 — acting and responsibility allowances.
	def test_acting_allowance_takes_the_higher_of_the_two_measures(self):
		revised, ordered = _far17()
		point = next(p for p, salary in revised.items() if salary == 26050)
		self.assertEqual(
			acting_allowance_base(26050, point, 28225, 34825, revised, ordered), 2175
		)

	def test_acting_breakdown_explains_posts_salary_difference_and_each_increment(self):
		revised, ordered = _far17()
		point = next(p for p, salary in revised.items() if salary == 26050)
		result = higher_duty_allowance_breakdown(
			assignment_type="Acting",
			substantive_salary=26050,
			substantive_point=point,
			higher_initial=28225,
			higher_max=34825,
			revised=revised,
			ordered=ordered,
		)
		self.assertEqual(result["salary_difference"], 2175)
		self.assertEqual([row["increment"] for row in result["increment_steps"]], [675, 675, 825])
		self.assertEqual(result["three_increment_amount"], 2175)
		self.assertEqual(result["qualification_percentage"], 100)
		self.assertEqual(result["payable_allowance"], 2175)

	def test_responsibility_breakdown_shows_eighty_percent_and_final_amount(self):
		revised, ordered = _far17()
		point = next(p for p, salary in revised.items() if salary == 26050)
		result = higher_duty_allowance_breakdown(
			assignment_type="Responsibility",
			substantive_salary=26050,
			substantive_point=point,
			higher_initial=28225,
			higher_max=34825,
			qualification_status="Not Fully Qualified",
			revised=revised,
			ordered=ordered,
		)
		self.assertEqual(result["qualification_percentage"], 80)
		self.assertEqual(result["payable_allowance"], 1740)

	def test_responsibility_allowance_percentage_follows_qualification(self):
		revised, ordered = _far17()
		point = next(p for p, salary in revised.items() if salary == 26050)
		kwargs = {"revised": revised, "ordered": ordered}
		self.assertEqual(responsibility_allowance(26050, point, 28225, 34825, True, **kwargs), 2175)
		self.assertEqual(responsibility_allowance(26050, point, 28225, 34825, False, **kwargs), 1740)

	def test_acting_allowance_cannot_exceed_the_higher_post_maximum(self):
		revised, ordered = _far17()
		point = next(p for p, salary in revised.items() if salary == 26050)
		# A higher post whose maximum is only Rs 27,000 caps the allowance.
		self.assertEqual(acting_allowance_base(26050, point, 28225, 27000, revised, ordered), 950)


if __name__ == "__main__":
	import unittest

	unittest.main()
