"""Materialize approved payroll inputs before Salary Slips are calculated."""

import frappe
from frappe import _
from frappe.utils import getdate


def _pending_recurring(cycle):
	if cycle.payroll_type != "Major":
		return []
	from karyo.payroll.recurring import eligible_recurring_pdbs

	rows = []
	for row in eligible_recurring_pdbs(cycle):
		if row.end_date and getdate(row.end_date) < getdate(cycle.start_date):
			continue
		if not frappe.db.exists(
			"Employee Recurring PDB Posting",
			{"payroll_cycle": cycle.name, "recurring_pdb": row.name, "status": "Posted"},
		):
			rows.append(row)
	return rows


def _approved_once_off_batches(cycle):
	return frappe.get_all(
		"Once-Off PDB Batch",
		filters={"payroll_cycle": cycle.name, "company": cycle.company, "status": "Approved"},
		pluck="name",
		order_by="creation, name",
	)


def pending_cycle_inputs(cycle):
	"""Return approved inputs that have not yet been posted to this cycle."""
	cycle = frappe.get_doc("Payroll Cycle", cycle) if isinstance(cycle, str) else cycle
	recurring = _pending_recurring(cycle)
	batches = _approved_once_off_batches(cycle)
	employees = {row.employee for row in recurring}
	if batches:
		employees.update(
			frappe.get_all(
				"Once-Off PDB Line", filters={"parent": ("in", batches)}, pluck="employee"
			)
		)
	return {
		"recurring": [row.name for row in recurring],
		"once_off_batches": batches,
		"employees": sorted(employees),
	}


def assert_no_pending_cycle_inputs(cycle):
	"""Prevent review/approval while an approved payroll input is still omitted."""
	pending = pending_cycle_inputs(cycle)
	if pending["recurring"] or pending["once_off_batches"]:
		frappe.throw(
			_(
				"Payroll inputs are pending: {0} static deduction(s), {1} approved once-off batch(es). "
				"Run Generate Draft Salary Slips again before continuing."
			).format(len(pending["recurring"]), len(pending["once_off_batches"]))
		)
	return pending


def _submitted_slips(cycle, employees):
	if not employees:
		return []
	return frappe.get_all(
		"Salary Slip",
		filters={
			"company": cycle.company,
			"employee": ("in", employees),
			"start_date": cycle.start_date,
			"end_date": cycle.end_date,
			"docstatus": 1,
		},
		fields=["name", "employee"],
		order_by="employee, name",
	)


def _refresh_draft_slips(cycle, employees):
	"""Rebuild draft slips so newly posted Additional Salary rows are included."""
	if not employees:
		return []
	refreshed = []
	for name in frappe.get_all(
		"Salary Slip",
		filters={
			"company": cycle.company,
			"employee": ("in", employees),
			"start_date": cycle.start_date,
			"end_date": cycle.end_date,
			"docstatus": 0,
		},
		pluck="name",
		order_by="employee, name",
	):
		slip = frappe.get_doc("Salary Slip", name)
		slip.get_emp_and_working_day_details()
		slip.save(ignore_permissions=True)
		refreshed.append(name)
	return refreshed


def materialize_cycle_inputs(payroll_cycle, refresh_draft_slips=True):
	"""Post static and approved once-off PDBs exactly once for a payroll cycle.

	The operation deliberately refuses to alter an employee whose Salary Slip is
	already submitted. That is an accounting correction, not a safe recalculation.
	"""
	cycle = (
		frappe.get_doc("Payroll Cycle", payroll_cycle)
		if isinstance(payroll_cycle, str)
		else payroll_cycle
	)
	if cycle.status not in ("Processing", "Review"):
		frappe.throw(_("Payroll Cycle must be Processing or Review before payroll inputs are posted."))

	pending = pending_cycle_inputs(cycle)
	submitted = _submitted_slips(cycle, pending["employees"])
	if submitted:
		frappe.throw(
			_(
				"New static or once-off inputs affect submitted Salary Slips: {0}. "
				"Reopen/correct those payroll results before posting the inputs."
			).format(", ".join(row.name for row in submitted))
		)

	recurring_result = {"created": [], "skipped": [], "failed": []}
	if cycle.payroll_type == "Major":
		from karyo.payroll.recurring import post_recurring_for_cycle

		recurring_result = post_recurring_for_cycle(cycle.name)

	from karyo.payroll.once_off import post_batch

	once_off_results = [post_batch(name) for name in pending["once_off_batches"]]
	refreshed = _refresh_draft_slips(cycle, pending["employees"]) if refresh_draft_slips else []
	return {
		"recurring": recurring_result,
		"once_off": once_off_results,
		"refreshed_salary_slips": refreshed,
		"affected_employees": pending["employees"],
	}
