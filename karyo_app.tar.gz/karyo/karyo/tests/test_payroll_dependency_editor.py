"""Real document lifecycle and fresh lookup checks, rolled back after each test."""
import unittest
from uuid import uuid4
from unittest.mock import patch
import frappe
from karyo.desk.payroll_drawer import record_form, record_save, record_action
from frappe.desk.search import search_link


class TestPayrollDependencyEditor(unittest.TestCase):
    def setUp(self):
        self.user = frappe.session.user
        frappe.set_user('Administrator')
        frappe.db.savepoint('dependency_editor')
        self.notify = patch('frappe.publish_realtime'); self.notify.start()
        self.mail = patch('frappe.sendmail'); self.mail.start()
        self.suffix = uuid4().hex[:10]

    def tearDown(self):
        self.notify.stop(); self.mail.stop()
        frappe.db.rollback(save_point='dependency_editor')
        frappe.set_user(self.user)

    def test_template_lifecycle_and_direct_employee_assignment_is_blocked(self):
        component = record_save('salarysetup', 'Salary Component', {
            'salary_component': 'Dependency '+self.suffix, 'salary_component_abbr': 'D'+self.suffix,
            'type': 'Earning', 'depends_on_payment_days': 0, 'is_tax_applicable': 0})['name']
        company = frappe.db.get_value('Company', {}, 'name')
        currency = frappe.db.get_value('Company', company, 'default_currency')
        structure = record_save('process', 'Salary Structure', {
            'record_name': 'Dependency '+self.suffix, 'company': company, 'currency': currency,
            'is_active': 'Yes', 'payroll_frequency': 'Monthly',
            'earnings': [{'salary_component': component, 'amount': 1000, 'depends_on_payment_days': 0}]})['name']
        self.assertEqual(frappe.db.get_value('Salary Structure', structure, 'docstatus'), 0)
        filters={'company':company,'docstatus':1,'is_active':'Yes'}
        self.assertNotIn(structure, [r['value'] for r in search_link('Salary Structure', self.suffix, filters=filters)])
        original = frappe.get_doc('Salary Structure', structure).earnings[0]
        record_save('salarysetup', 'Salary Structure', {'earnings': [{'name': original.name,
            'salary_component': component, 'amount': 1200, 'depends_on_payment_days': 0}]}, structure)
        saved = frappe.get_doc('Salary Structure', structure).earnings[0]
        self.assertEqual(saved.name, original.name)
        self.assertEqual(saved.abbr, original.abbr)
        record_action('process', 'Salary Structure', structure, 'submit')
        self.assertIn(structure, [r['value'] for r in search_link('Salary Structure', self.suffix, filters=filters)])
        # Employee mappings are generated only by the governed Employee Payroll
        # Setup flow; the old parallel assignment entry path must stay closed.
        with self.assertRaisesRegex(frappe.ValidationError, 'Employee Payroll Setup'):
            record_form('salarysetup', 'Salary Structure Assignment')
        with self.assertRaisesRegex(frappe.ValidationError, 'direct assignments are disabled'):
            record_save('process','Salary Structure Assignment', {
                'employee':'not-used', 'salary_structure':structure,
                'from_date':'2026-09-01', 'base':1000,
            })

    def test_setup_entries_are_immediately_searchable(self):
        for doctype, screen in [('Payroll Contribution Scheme','contribution'),('Payroll Compensation Scheme','compensation'),('Payroll PAYE Year','paye')]:
            name=frappe.db.get_value(doctype,{},'name')
            self.assertTrue(name,doctype)
            spec=record_form(screen,doctype,name,is_admin=True)
            values={f['fieldname']:f['value'] for section in spec['sections'] for f in section['fields'] if not f['read_only']}
            values.update({f['fieldname']:f['value'] for f in spec['admin']['fields'] if not f['read_only']})
            for table in spec['tables']:
                values[table['fieldname']]=[{k:v for k,v in row.items() if k!='name'} for row in table['rows']]
            code='tax_year' if doctype=='Payroll PAYE Year' else 'scheme_code'
            values[code]='DEP-'+self.suffix
            values['version']=1
            values['is_active']=1
            result=record_save(screen,doctype,values,is_admin=True)
            matches=search_link(doctype,self.suffix,filters={'is_active':1})
            self.assertIn(result['name'],[r['value'] for r in matches])

    def test_permission_boundary_and_no_unknown_dependencies(self):
        with self.assertRaises(frappe.ValidationError):record_form('process','User','Administrator')
        frappe.set_user('Guest')
        with self.assertRaises(frappe.PermissionError):record_form('process','Employee',frappe.db.get_value('Employee',{},'name'))

    def test_readiness_employee_correction_uses_field_permissions(self):
        name=frappe.db.get_value('Employee',{'status':'Active'},'name')
        frappe.set_user('mbc.admin@mbc.mu')
        spec=record_form('process','Employee',name)
        fields={f['fieldname']:f for section in spec['sections'] for f in section['fields']}
        self.assertIn('pan_number',fields)
        self.assertFalse(fields['pan_number']['read_only'])
        original=frappe.get_doc('Employee',name)
        record_save('process','Employee',{'pan_number':'DEP'+self.suffix,'company':'Invalid Company'},name)
        saved=frappe.get_doc('Employee',name)
        self.assertEqual(saved.pan_number,'DEP'+self.suffix)
        self.assertEqual(saved.company,original.company)
        self.assertEqual(saved.bank_ac_no,original.bank_ac_no)

    def test_employee_correction_uses_editable_payroll_bank_and_prefilled_branch_fields(self):
        name=frappe.db.get_value('Employee',{'status':'Active'},'name')
        spec=record_form('process','Employee',name,is_admin=True)
        sections={section['label']:{field['fieldname']:field for field in section['fields']} for section in spec['sections']}
        payment=sections['Payment details']
        self.assertNotIn('bank_name',payment)
        self.assertNotIn('bank_ac_no',payment)
        self.assertFalse(payment['karyo_payroll_bank']['read_only'])
        self.assertFalse(payment['karyo_payroll_bank_branch']['read_only'])
        derived=sections['Prefilled bank and branch details']
        self.assertEqual(set(derived),{
            'karyo_bank_code','karyo_bank_transfer_code','karyo_bank_other_code',
            'karyo_branch_code','karyo_branch_name','karyo_branch_transfer_code','karyo_branch_other_code',
        })
        self.assertTrue(all(field['read_only'] for field in derived.values()))
