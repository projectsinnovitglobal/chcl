frappe.query_reports["Static Deduction"] = {
	filters: [
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "loan", label: __("Loan"), fieldtype: "Link", options: "Karyo Loan" },
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "component", label: __("Component"), fieldtype: "Select", options: "\nCapital\nInterest\nInsurance" },
		{ fieldname: "status", label: __("Status"), fieldtype: "Select", options: "\nActive\nEnded\nSuperseded\nCancelled" },
		{ fieldname: "from_date", label: __("Effective From"), fieldtype: "Date" },
		{ fieldname: "to_date", label: __("Effective To"), fieldtype: "Date" },
	],
};
