"""Payroll workflow authorization and segregation-of-duties controls."""

import frappe
from frappe import _


ROLE_FIELDS = {
	"input": "input_role",
	"processor": "processor_role",
	"reviewer": "reviewer_role",
	"approver": "approver_role",
	"finance": "finance_role",
	"auditor": "auditor_role",
}

TRANSITION_ACTORS = {
	("Draft", "Input Open"): "input",
	("Draft", "Cancelled"): "approver",
	("Input Open", "Processing"): "processor",
	("Input Open", "Cancelled"): "approver",
	("Processing", "Input Open"): "processor",
	("Processing", "Review"): "reviewer",
	("Processing", "Cancelled"): "approver",
	("Review", "Processing"): "reviewer",
	("Review", "Approved"): "approver",
	("Review", "Cancelled"): "approver",
	("Approved", "Closed"): "finance",
	("Closed", "Reopened"): "approver",
	("Reopened", "Processing"): "processor",
	("Reopened", "Closed"): "finance",
}

SENSITIVE_ACCESS = {
	"bank_file": {"approver", "finance"},
	"tax_identifier": {"processor", "reviewer", "approver", "auditor"},
	"salary": {"processor", "reviewer", "approver", "finance", "auditor"},
	"close": {"finance"},
	"reopen": {"approver"},
}


def configured_role(actor):
	fieldname = ROLE_FIELDS[actor]
	return frappe.db.get_single_value("Karyo Payroll Settings", fieldname)


def has_actor_role(actor, roles=None, user=None):
	user = user or frappe.session.user
	if user == "Administrator":
		return True
	roles = set(roles if roles is not None else frappe.get_roles(user))
	if actor in ("processor", "reviewer", "approver") and "System Manager" in roles:
		return True
	role = configured_role(actor)
	return bool(role and role in roles)


def assert_transition_role(previous_status, next_status, roles=None, user=None):
	actor = TRANSITION_ACTORS.get((previous_status, next_status))
	if not actor:
		return
	role = configured_role(actor)
	if not has_actor_role(actor, roles, user):
		frappe.throw(
			_("Only users with role {0} may move Payroll Cycle from {1} to {2}.").format(
				role, previous_status, next_status
			),
			frappe.PermissionError,
		)


def assert_segregation_of_duties(cycle, user=None):
	if cycle.status != "Approved":
		return
	# Administrators provide the explicitly authorized fallback when an approver is unavailable.
	user = user or frappe.session.user
	if user == "Administrator" or "System Manager" in frappe.get_roles(user):
		return
	if not frappe.db.get_single_value("Karyo Payroll Settings", "enforce_segregation_of_duties"):
		return
	if cycle.processed_by and cycle.processed_by == (user or frappe.session.user):
		frappe.throw(
			_("The payroll processor cannot be the final payroll approver. "
			  "This payroll was processed by {0}. Ask a different user with the {1} role "
			  "to open the same payroll period, select these employees, and run Approve Payroll.").format(
				cycle.processed_by, configured_role("approver") or _("Payroll Approver")
			),
			frappe.PermissionError,
		)


def can_access_sensitive_payroll(category, roles=None, user=None):
	user = user or frappe.session.user
	if user == "Administrator" or "System Manager" in set(
		roles if roles is not None else frappe.get_roles()
	):
		return True
	return any(has_actor_role(actor, roles, user) for actor in SENSITIVE_ACCESS.get(category, set()))


def assert_sensitive_access(category, roles=None, user=None):
	if not can_access_sensitive_payroll(category, roles, user):
		frappe.throw(
			_("You are not permitted to access this sensitive payroll information."),
			frappe.PermissionError,
		)
