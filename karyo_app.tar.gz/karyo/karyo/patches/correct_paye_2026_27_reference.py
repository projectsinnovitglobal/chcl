"""Replace the desk placeholder with the published MRA 2026/27 PAYE rules."""

import frappe


MRA_SOURCE = "https://www.mra.mu/individuals/reliefs-deductions-allowances; https://www.mra.mu/employers/paye"


def execute():
	name = frappe.db.get_value(
		"Payroll PAYE Year",
		{"tax_year": ("in", ["2026-27", "2026/2027"]), "company": "MBC"},
		"name", order_by="modified desc",
	)
	if not name:
		return
	configuration = "MRA-PAYE-2026-27-OFFICIAL-1"
	if not frappe.db.exists("Payroll Configuration Version", configuration):
		frappe.get_doc({
			"doctype": "Payroll Configuration Version", "config_key": "MRA-PAYE-2026-27",
			"configuration_type": "PAYE", "company": "MBC", "version": "OFFICIAL-1",
			"configuration_status": "Draft", "effective_from": "2026-07-01", "effective_to": "2027-06-30",
			"source_reference": MRA_SOURCE,
			"notes": "Official MRA 2026/27 rates loaded for validation and approval.",
		}).insert(ignore_permissions=True)
	doc = frappe.get_doc("Payroll PAYE Year", name)
	doc.update({
		"tax_year": "2026/2027", "company": "MBC", "currency": "MUR", "periods_per_year": 13,
		"currency_precision": 0, "no_edf_rate": 15, "no_edf_optional_rate": 20,
		"monthly_no_paye_threshold": 38462, "director_flat_rate": 15,
		"fair_share_threshold": 12000000, "fair_share_rate": 15,
		"dependent_1_relief": 110000, "dependent_2_relief": 190000,
		"dependent_3_relief": 275000, "dependent_4_plus_relief": 355000,
		"effective_from": "2026-07-01", "effective_to": "2027-06-30", "is_active": 1,
		"configuration_version": configuration, "source_reference": MRA_SOURCE,
	})
	doc.set("bands", [])
	for upper, rate, open_ended in ((500000, 0, 0), (1000000, 10, 0), (None, 20, 1)):
		doc.append("bands", {"upper_chargeable_income": upper, "tax_rate": rate, "is_open_ended": open_ended})
	doc.save(ignore_permissions=True)

