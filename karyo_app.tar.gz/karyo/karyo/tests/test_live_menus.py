import unittest
from uuid import uuid4
from unittest.mock import MagicMock, patch
import frappe
from frappe.utils import add_days, nowdate
from karyo.hr.clocking import (
	_additional_hours_by_employee_date,
	_clock_access,
	_record_authorized_work,
	attendance_clock_view,
	attendance_times,
	dashboard,
)
from karyo.hr.leave_controls import allocatable_leave_type_query, eligible_leave_type_query
from karyo.hr.self_service import allocation_balances, my_leaves


class TestLiveMenus(unittest.TestCase):
	def setUp(self):
		self.previous_user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("live_menus_test")
		self.mail = patch("frappe.sendmail")
		self.mail.start()
		self.email = "live-menus-" + uuid4().hex + "@example.test"
		self.employee = frappe.get_doc({"doctype":"Employee", "first_name":"Live Menus Test", "gender":"Female", "date_of_birth":"1990-01-01", "date_of_joining":"2020-01-01", "status":"Active", "company":frappe.db.get_value("Company",{},"name")})
		password = "Q9!"+uuid4().hex
		self.employee._mbc_account_setup={"link_user":1,"login_email":self.email,"password":password,"confirm_password":password}
		self.employee.insert()

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="live_menus_test")
		frappe.clear_cache(user=self.email)
		self.mail.stop()
		frappe.set_user(self.previous_user)

	def punch(self, day=None):
		return frappe.get_doc({"doctype":"Employee Checkin","employee":self.employee.name,"log_type":"IN","time":str(day or nowdate())+" 09:00:00"}).insert()

	def test_first_punch_exists_without_processed_attendance(self):
		self.punch()
		frappe.set_user(self.email)
		view=attendance_clock_view([])
		self.assertEqual(len(view["live_rows"]),1)
		self.assertEqual(view["live_rows"][0].status,"Clocked In")
		self.assertTrue(view["live_rows"][0].get("__clock_live"))

	def test_previous_day_unprocessed_punch_remains_visible(self):
		self.punch(add_days(nowdate(),-1))
		frappe.set_user(self.email)
		view=attendance_clock_view([])
		self.assertEqual(str(view["live_rows"][0].attendance_date),str(add_days(nowdate(),-1)))
		self.assertEqual(attendance_clock_view([],[["Attendance","attendance_date","=",nowdate()]])["live_rows"],[])

	def test_live_clock_dashboard_keeps_overnight_clock_in_available(self):
		self.punch(add_days(nowdate(),-1))
		frappe.set_user(self.email)
		view=dashboard()
		self.assertEqual(view["current_date"],nowdate())
		self.assertIsNotNone(view["self"]["time"])
		self.assertTrue(view["self"]["clocked_in"])

	def test_processed_row_replaces_virtual_row(self):
		self.punch()
		attendance=frappe.get_doc({"doctype":"Attendance","employee":self.employee.name,"attendance_date":nowdate(),"status":"Present"}).insert()
		attendance.submit()
		frappe.set_user(self.email)
		view=attendance_clock_view([attendance.name])
		self.assertEqual(len(view["live_rows"]),1)
		self.assertEqual(view["live_rows"][0].name,attendance.name)
		self.assertFalse(view["live_rows"][0].get("__clock_live"))

	def test_draft_attendance_does_not_replace_live_punch_status(self):
		self.punch()
		frappe.get_doc({"doctype":"Attendance","employee":self.employee.name,"attendance_date":nowdate(),"status":"Absent"}).insert()
		frappe.set_user(self.email)
		view=attendance_clock_view([])
		self.assertEqual(len(view["live_rows"]),1)
		self.assertEqual(view["live_rows"][0].status,"Clocked In")
		self.assertTrue(view["live_rows"][0].get("__clock_live"))

	def test_clock_filters_cannot_select_another_employee(self):
		self.punch()
		other=frappe.db.get_value("Employee",{"name":["!=",self.employee.name]},"name")
		frappe.set_user(self.email)
		self.assertEqual(attendance_clock_view([],[["Attendance","employee","=",other]])["live_rows"],[])
		self.assertEqual(attendance_times(["nonexistent-attendance"]),{})

	def test_hr_attendance_clock_columns_are_permission_scoped(self):
		self.punch()
		attendance=frappe.get_doc({"doctype":"Attendance","employee":self.employee.name,
			"attendance_date":nowdate(),"status":"Present"}).insert()
		attendance.submit()
		view=attendance_clock_view([attendance.name])
		self.assertFalse(any(row.employee == self.employee.name for row in view["live_rows"]))
		self.assertEqual(view["records"][attendance.name]["employee_name"],self.employee.employee_name)
		self.assertTrue(view["records"][attendance.name]["clock_in"])

	def test_attendance_day_includes_governed_additional_hour_breakdown(self):
		day = nowdate()
		query_row = frappe._dict(
			employee=self.employee.name,
			attendance_date=day,
			overtime_hours=2,
			night_duty_hours=1.5,
			excess_hours=0.5,
		)
		with patch.object(frappe.db, "sql", return_value=[query_row]):
			result = _additional_hours_by_employee_date([
				frappe._dict(employee=self.employee.name, attendance_date=day),
			])
		values = result[(self.employee.name, frappe.utils.getdate(day))]
		self.assertEqual(values["overtime_hours"], 2)
		self.assertEqual(values["night_duty_hours"], 1.5)
		self.assertEqual(values["excess_hours"], 0.5)
		self.assertEqual(values["additional_hours"], 4)

	def test_holiday_clocking_requires_submitted_additional_hours_authority(self):
		with (
			patch("erpnext.setup.doctype.employee.employee.is_holiday", return_value=True),
			patch("karyo.hr.roster.current_duty", return_value=None),
			patch.object(frappe, "get_cached_value", return_value=None),
			patch("karyo.hr.clocking._active_clock_authorization", return_value=None),
		):
			blocked = _clock_access(self.employee.name, "2026-09-27 09:00:00")
		self.assertFalse(blocked["can_clock_in"])
		self.assertIn("holidays", blocked["reason"])

		authority = frappe._dict(name="OTAUTH-2026-00001")
		with (
			patch("erpnext.setup.doctype.employee.employee.is_holiday", return_value=True),
			patch("karyo.hr.roster.current_duty", return_value=None),
			patch.object(frappe, "get_cached_value", return_value=None),
			patch("karyo.hr.clocking._active_clock_authorization", return_value=authority),
		):
			allowed = _clock_access(self.employee.name, "2026-09-27 09:00:00")
		self.assertTrue(allowed["can_clock_in"])
		self.assertEqual(allowed["authorization"], authority.name)

	def test_clock_out_remains_available_after_authorized_window(self):
		latest = frappe._dict(log_type="IN")
		access = _clock_access(self.employee.name, "2026-09-27 23:59:00", latest=latest)
		self.assertTrue(access["can_clock_out"])
		self.assertFalse(access["can_clock_in"])

	def test_authorized_clock_pair_updates_overtime_and_links_logs(self):
		authorization = frappe._dict(name="OTAUTH-2026-00001", shift_type="Night Shift")
		authority = frappe._dict(actual_start=None, actual_end=None)
		authority.save = MagicMock()
		clock_in = frappe._dict(name="IN-1", log_type="IN", time="2026-09-27 22:00:00", shift="Night Shift")
		clock_out = frappe._dict(name="OUT-1", log_type="OUT", time="2026-09-28 03:00:00", shift="Night Shift")
		with (
			patch("karyo.hr.clocking._active_clock_authorization", return_value=authorization),
			patch.object(frappe, "get_doc", return_value=authority),
			patch.object(frappe.db, "savepoint"),
			patch.object(frappe.db, "get_value", return_value="ATT-1"),
			patch.object(frappe.db, "set_value") as set_value,
		):
			_record_authorized_work(self.employee.name, clock_in, clock_out)
		self.assertEqual(authority.actual_start, clock_in.time)
		self.assertEqual(authority.actual_end, clock_out.time)
		authority.save.assert_called_once_with(ignore_permissions=True)
		self.assertEqual([call.args[1] for call in set_value.call_args_list], ["IN-1", "OUT-1"])

	def test_leave_allocations_use_submitted_ledger_and_cancel_live(self):
		suffix=uuid4().hex[:10]
		leave_type=frappe.get_doc({"doctype":"Leave Type","leave_type_name":"Live Leave "+suffix,"karyo_mbc_leave_code":"TLIVE"+suffix,"karyo_code_description":"Live leave test"}).insert()
		allocation=frappe.get_doc({"doctype":"Leave Allocation","employee":self.employee.name,"leave_type":leave_type.name,"from_date":add_days(nowdate(),-1),"to_date":add_days(nowdate(),30),"new_leaves_allocated":12}).insert()
		frappe.set_user(self.email)
		self.assertEqual(my_leaves()["balances"],[])
		frappe.set_user("Administrator")
		allocation.submit()
		frappe.set_user(self.email)
		balance=my_leaves()["balances"][0]
		self.assertEqual(balance["total"],12)
		self.assertEqual(balance["remaining"],12)
		self.assertEqual(balance["pending"],0)
		frappe.set_user("Administrator")
		allocation.cancel()
		frappe.set_user(self.email)
		self.assertEqual(my_leaves()["balances"],[])

	def test_leave_type_choices_follow_employee_allocations(self):
		suffix = uuid4().hex[:10]
		assigned = frappe.get_doc({
			"doctype": "Leave Type", "leave_type_name": "Assigned Leave " + suffix,
			"karyo_mbc_leave_code": "TASG" + suffix,
			"karyo_code_description": "Assigned leave picker test",
		}).insert()
		unassigned = frappe.get_doc({
			"doctype": "Leave Type", "leave_type_name": "Unassigned Leave " + suffix,
			"karyo_mbc_leave_code": "TUNA" + suffix,
			"karyo_code_description": "Unassigned leave picker test",
		}).insert()
		frappe.get_doc({
			"doctype": "Leave Allocation", "employee": self.employee.name,
			"leave_type": assigned.name, "from_date": nowdate(),
			"to_date": add_days(nowdate(), 30), "new_leaves_allocated": 2,
		}).insert().submit()

		frappe.set_user(self.email)
		choices = eligible_leave_type_query(
			"Leave Type", "", "name", 0, 1000,
			{"employee": self.employee.name, "on_date": nowdate()},
		)
		self.assertIn(assigned.name, {row[0] for row in choices})
		self.assertNotIn(unassigned.name, {row[0] for row in choices})

		frappe.set_user("Administrator")
		catalogue = allocatable_leave_type_query("Leave Type", suffix, "name", 0, 1000, {})
		self.assertEqual({assigned.name, unassigned.name}, {row[0] for row in catalogue})
		register = allocation_balances(self.employee.name)["balances"]
		self.assertIn(assigned.name, {row["leave_type"] for row in register})
		self.assertNotIn(unassigned.name, {row["leave_type"] for row in register})

	def test_allocation_access_is_read_only_and_employee_scoped(self):
		suffix=uuid4().hex[:10]
		leave_type=frappe.get_doc({"doctype":"Leave Type","leave_type_name":"Scoped Leave "+suffix,"karyo_mbc_leave_code":"TSCOPE"+suffix,"karyo_code_description":"Scoped leave test"}).insert()
		own=frappe.get_doc({"doctype":"Leave Allocation","employee":self.employee.name,"leave_type":leave_type.name,"from_date":nowdate(),"to_date":add_days(nowdate(),30),"new_leaves_allocated":3}).insert()
		other_name=frappe.db.get_value("Leave Allocation",{"employee":["!=",self.employee.name]},"name")
		other=frappe.get_doc("Leave Allocation",other_name) if other_name else None
		frappe.set_user(self.email)
		self.assertTrue(frappe.has_permission("Leave Allocation","read",doc=own))
		self.assertFalse(frappe.has_permission("Leave Allocation","write",doc=own))
		self.assertFalse(frappe.has_permission("Leave Allocation","create"))
		self.assertTrue(all(row.employee==self.employee.name for row in frappe.get_list("Leave Allocation",fields=["employee"])))
		if other:
			self.assertFalse(frappe.has_permission("Leave Allocation","read",doc=other))
			self.assertEqual(frappe.get_list("Leave Allocation",filters={"name":other.name}),[])

	def test_advance_currency_is_scoped_without_salary_assignment_access(self):
		from karyo.hr.self_service import employee_advance_currency
		expected = frappe.db.get_value("Company", self.employee.company, "default_currency")
		frappe.set_user(self.email)
		self.assertEqual(employee_advance_currency(), {"employee":self.employee.name,"currency":expected})
		self.assertFalse(frappe.has_permission("Salary Structure Assignment", "read"))
		self.assertTrue(frappe.has_permission("Currency", "select"))
