"""One-time, repeatable consolidation of the site around a single company, MBC.

    bench --site <site> execute karyo.setup.mbc_cleanup.run

- Removes every other company (the empty "MBC" shell and "_Test Company"
  fixtures) with all records they own.
- Renames the live company (SIL) to MBC, including the " - MAI" abbreviation
  still carried by its accounts, cost centres, warehouses, departments, pay
  days and payroll periods.
- Drops the future demo payroll (the February 2027 cycle and everything
  attached to it) and pay days after September 2026.
- Removes unit-test fixtures (users, fiscal years, holiday lists).
"""

import frappe

COMPANY = "MBC"
LIVE_COMPANY = "SIL"
OLD_ABBR = "MAI"
KEEP_UNTIL = "2026-09-30"


def _delete_company_data(company):
	"""Remove records owned by an unrelated company, including their child rows."""
	links = frappe.get_all(
		"DocField", filters={"fieldtype": "Link", "options": "Company"}, fields=["parent", "fieldname"]
	)
	child_tables = set(frappe.get_all("DocType", filters={"istable": 1}, pluck="name"))
	for link in links:
		doctype = link.parent
		if doctype == "Company" or doctype in child_tables or not frappe.db.table_exists(doctype):
			continue
		names = frappe.get_all(doctype, filters={link.fieldname: company}, pluck="name")
		if not names:
			continue
		for child in frappe.get_all("DocField", filters={"parent": doctype, "fieldtype": "Table"}, pluck="options"):
			if frappe.db.table_exists(child):
				frappe.db.delete(child, {"parent": ["in", names]})
		frappe.db.delete("Comment", {"reference_doctype": doctype, "reference_name": ["in", names]})
		frappe.db.delete("Version", {"ref_doctype": doctype, "docname": ["in", names]})
		frappe.db.delete(doctype, {"name": ["in", names]})
	for link in links:
		if link.parent in child_tables and frappe.db.table_exists(link.parent):
			frappe.db.delete(link.parent, {link.fieldname: company})
	frappe.db.delete("DefaultValue", {"defkey": "company", "defvalue": company})
	frappe.db.delete("Company", {"name": company})


def _delete_docs(doctype, names):
	for name in names:
		try:
			frappe.delete_doc(doctype, name, force=True, ignore_permissions=True, delete_permanently=True)
		except Exception:
			# Fall back to a raw delete for records whose controllers refuse.
			for child in frappe.get_all("DocField", filters={"parent": doctype, "fieldtype": "Table"}, pluck="options"):
				if frappe.db.table_exists(child):
					frappe.db.delete(child, {"parent": name})
			frappe.db.delete(doctype, {"name": name})


def _delete_future_payroll():
	"""Drop payroll cycles after the cut-off and everything that hangs off them."""
	cycles = frappe.get_all("Payroll Cycle", filters={"start_date": [">", KEEP_UNTIL]}, fields=["name", "payroll_entry"])
	existing = set(frappe.get_all("Payroll Cycle", pluck="name")) - {c.name for c in cycles}
	for cycle in cycles:
		if cycle.payroll_entry and frappe.db.exists("Payroll Entry", cycle.payroll_entry):
			_delete_docs("Salary Slip", frappe.get_all("Salary Slip", filters={"payroll_entry": cycle.payroll_entry}, pluck="name"))
			frappe.db.set_value("Payroll Entry", cycle.payroll_entry, "docstatus", 2)
			_delete_docs("Payroll Entry", [cycle.payroll_entry])
	# Anything linked to a removed cycle, or to a cycle that no longer exists.
	for link in frappe.get_all("DocField", filters={"fieldtype": "Link", "options": "Payroll Cycle"}, fields=["parent", "fieldname"]):
		if not frappe.db.table_exists(link.parent) or frappe.get_meta(link.parent).issingle:
			continue
		if frappe.get_meta(link.parent).istable:
			frappe.db.delete(link.parent, {link.fieldname: ["not in", list(existing) + [None, ""]]})
			continue
		orphans = frappe.get_all(link.parent, filters={link.fieldname: ["not in", list(existing)], link.fieldname: ["is", "set"]}, pluck="name")
		orphans = [n for n in orphans if frappe.db.get_value(link.parent, n, link.fieldname) not in existing]
		_delete_docs(link.parent, orphans)
	_delete_docs("Payroll Cycle", [c.name for c in cycles])
	# Draft bulk runs not attached to any period are leftovers from testing.
	_delete_docs("Bulk Payroll Run", frappe.get_all("Bulk Payroll Run", filters={"payroll_cycle": ["is", "not set"], "docstatus": 0}, pluck="name"))
	# Pay days beyond the cut-off (all still Planned) and rows pointing at them.
	future_days = frappe.get_all("Payroll Pay Day", filters={"start_date": [">", KEEP_UNTIL]}, pluck="name")
	for link in frappe.get_all("DocField", filters={"fieldtype": "Link", "options": "Payroll Pay Day"}, fields=["parent", "fieldname"]):
		if link.parent != "Payroll Cycle" and frappe.db.table_exists(link.parent):
			if frappe.get_meta(link.parent).istable:
				frappe.db.delete(link.parent, {link.fieldname: ["in", future_days]})
			else:
				_delete_docs(link.parent, frappe.get_all(link.parent, filters={link.fieldname: ["in", future_days]}, pluck="name"))
	_delete_docs("Payroll Pay Day", future_days)


def _rename_company():
	if frappe.db.exists("Company", LIVE_COMPANY) and not frappe.db.exists("Company", COMPANY):
		frappe.rename_doc("Company", LIVE_COMPANY, COMPANY, force=True)
	frappe.db.set_value("Company", COMPANY, {"company_name": COMPANY, "abbr": COMPANY})
	# Masters still carry the legacy " - MAI" suffix / "MAI-" prefix.
	for doctype in ("Account", "Cost Center", "Warehouse", "Department", "Payroll Period"):
		for name in frappe.get_all(doctype, filters={"name": ["like", f"%{OLD_ABBR}%"]}, pluck="name"):
			new = name.replace(f" - {OLD_ABBR}", f" - {COMPANY}").replace(f"({OLD_ABBR})", f"({COMPANY})")
			if new != name and not frappe.db.exists(doctype, new):
				frappe.rename_doc(doctype, name, new, force=True)
	for name in frappe.get_all("Payroll Pay Day", filters={"name": ["like", f"{OLD_ABBR}-%"]}, pluck="name"):
		frappe.rename_doc("Payroll Pay Day", name, COMPANY + name[len(OLD_ABBR):], force=True)
	frappe.db.set_default("company", COMPANY)
	frappe.db.set_single_value("Global Defaults", "default_company", COMPANY)


def _delete_test_fixtures():
	for user in frappe.get_all("User", filters={"name": ["like", "test%@example.com"]}, pluck="name"):
		frappe.delete_doc("User", user, force=True, ignore_permissions=True)
	_delete_docs("Fiscal Year", frappe.get_all("Fiscal Year", filters={"name": ["like", "_Test%"]}, pluck="name"))
	for holiday_list in ("_Test Holiday List", "Salary Slip Test Holiday List"):
		if frappe.db.exists("Holiday List", holiday_list):
			default = frappe.db.get_value("Company", COMPANY, "default_holiday_list")
			frappe.db.set_value("Employee", {"holiday_list": holiday_list}, "holiday_list", default)
			_delete_docs("Holiday List", [holiday_list])


def run():
	for company in frappe.get_all("Company", filters={"name": ["!=", LIVE_COMPANY]}, pluck="name"):
		_delete_company_data(company)
	_delete_future_payroll()
	_rename_company()
	_delete_test_fixtures()
	frappe.db.commit()
	frappe.clear_cache()
	return {
		"companies": frappe.get_all("Company", pluck="name"),
		"employees": frappe.db.count("Employee"),
		"payroll_cycles": frappe.get_all("Payroll Cycle", fields=["name", "pay_period_label", "status"]),
		"pay_days": frappe.get_all("Payroll Pay Day", pluck="name", order_by="start_date"),
		"salary_slips": frappe.db.count("Salary Slip"),
	}
