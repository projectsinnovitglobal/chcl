from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.karyo.report.loan_agreement_listing.loan_agreement_listing import _agreement_row, _matches, execute


class TestLoanAgreementListing(FrappeTestCase):
	@patch("frappe.get_all")
	@patch("frappe.get_list")
	def test_bulk_report_has_constant_query_count_and_export_metadata(self, get_list, get_all):
		get_list.return_value = [frappe._dict(name=f"LOAN-{i}", employee=f"EMP-{i}", employee_name="Test",
			loan_type="Staff", workflow_state="Agreement Printed", approved_amount=1000,
			agreement_printed_on="2026-08-01", insurance_rate=0, lien_required=0) for i in range(250)]
		get_all.side_effect = [[], []]  # one bulk document query, one requirement query
		columns, data, _, _, summary = execute({})
		self.assertEqual(len(data), 250)
		# Frappe may perform one permission lookup around report execution; the two
		# report data reads remain constant regardless of the number of loans.
		self.assertLessEqual(get_all.call_count, 3)
		queried_doctypes = [call.args[0] for call in get_all.call_args_list if call.args]
		self.assertEqual(queried_doctypes.count("Karyo Loan Document"), 1)
		self.assertEqual(queried_doctypes.count("Loan Document Requirement"), 1)
		self.assertEqual(summary[0]["value"], 250)
		self.assertEqual(next(c for c in columns if c["fieldname"] == "approved_amount")["fieldtype"], "Currency")
		self.assertEqual(next(c for c in columns if c["fieldname"] == "generated_on")["fieldtype"], "Date")
		self.assertTrue(all(isinstance(row, dict) for row in data))

	@patch("karyo.karyo.report.loan_agreement_listing.loan_agreement_listing._required_document_types")
	@patch("frappe.get_all")
	def test_signed_verified_agreement_and_missing_documents(self, get_all, requirements):
		get_all.return_value = [frappe._dict(document_type="Agreement", attachment="/private/files/agreement.pdf",
			document_reference="AGR-V2", verified=1, verified_by="auditor@example.com", verified_on="2026-08-02 12:00:00",
			uploaded_by="loan@example.com", uploaded_on="2026-08-02")]
		requirements.return_value = {"Agreement", "Approval"}
		loan = frappe._dict(name="LOAN-1", employee="EMP-1", employee_name="Test", loan_type="Staff",
			workflow_state="Agreement Printed", approved_amount=1000, agreement_printed_on="2026-08-01")
		row = _agreement_row(loan)
		self.assertEqual(row.signed_status, "Signed")
		self.assertEqual(row.verified_status, "Verified")
		self.assertEqual(row.template_version, "AGR-V2")
		self.assertEqual(row.missing_documents, "Approval")
		self.assertTrue(_matches(row, frappe._dict(signed_status="Signed", from_date="2026-08-01")))
