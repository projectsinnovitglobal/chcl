"""Company ownership fields used by the organisation structure masters."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter


def _default_company():
	return frappe.db.get_single_value("Global Defaults", "default_company") or frappe.db.get_value(
		"Company", {}, "name", order_by="creation asc"
	)


def apply():
	company = _default_company()
	frappe.reload_doc("karyo", "doctype", "employee_location")
	create_custom_fields(
		{
			"Employee": [
				{
					"fieldname": "karyo_location",
					"fieldtype": "Link",
					"label": "Location",
					"options": "Employee Location",
					"insert_after": "branch",
					"in_list_view": 1,
					"in_standard_filter": 1,
				},
			],
			"Branch": [
				{
					"fieldname": "company",
					"fieldtype": "Link",
					"label": "Company",
					"options": "Company",
					"insert_after": "branch",
					"in_list_view": 1,
					"in_standard_filter": 1,
					"default": company,
				},
			],
			"Designation": [
				{
					"fieldname": "company",
					"fieldtype": "Link",
					"label": "Company",
					"options": "Company",
					"insert_after": "designation_name",
					"in_list_view": 1,
					"in_standard_filter": 1,
					"default": company,
				},
			],
			"Department": [
				{
					"fieldname": "payroll_leave_controls",
					"fieldtype": "Section Break",
					"label": "Payroll and Leave Controls",
					"insert_after": "disabled",
				},
				{
					"fieldname": "payroll_cost_center",
					"fieldtype": "Link",
					"label": "Payroll Cost Center",
					"options": "Cost Center",
					"insert_after": "payroll_leave_controls",
					"in_standard_filter": 1,
				},
				{
					"fieldname": "payroll_leave_controls_column",
					"fieldtype": "Column Break",
					"insert_after": "payroll_cost_center",
				},
				{
					"fieldname": "leave_block_list",
					"fieldtype": "Link",
					"label": "Leave Block List",
					"options": "Leave Block List",
					"insert_after": "payroll_leave_controls_column",
					"in_standard_filter": 1,
				},
			],
		},
		ignore_validate=True,
	)
	make_property_setter("Department", "company", "in_list_view", 1, "Check")
	# The list already has the document-name column labelled Department. Showing
	# department_name as well creates two adjacent columns with the same label.
	make_property_setter("Department", "department_name", "in_list_view", 0, "Check")

	# Appraisal templates belong to the appraisal process, not the Designation
	# master.  Preserve the skills block while removing the obsolete control.
	appraisal_field = frappe.db.get_value(
		"Custom Field", {"dt": "Designation", "fieldname": "appraisal_template"}, "name"
	)
	if appraisal_field:
		frappe.delete_doc("Custom Field", appraisal_field, ignore_permissions=True)
	required_skills = frappe.db.get_value(
		"Custom Field", {"dt": "Designation", "fieldname": "required_skills_section"}, "name"
	)
	if required_skills:
		frappe.db.set_value(
			"Custom Field", required_skills, "insert_after", "description", update_modified=False
		)

	for doctype in ("Branch", "Designation", "Department"):
		if company:
			frappe.db.set_value(doctype, {"company": ["in", (None, "")]}, "company", company, update_modified=False)
		custom_field = frappe.db.get_value("Custom Field", {"dt": doctype, "fieldname": "company"}, "name")
		if custom_field:
			frappe.db.set_value(
				"Custom Field",
				custom_field,
				{"reqd": 1, "default": company or ""},
				update_modified=False,
			)
		frappe.clear_cache(doctype=doctype)

	print("  + Organisation masters linked to Company; Designation appraisal field removed")
