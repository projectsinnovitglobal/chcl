import frappe
from frappe import _
from frappe.utils import flt, getdate
from karyo.karyo.report.loan_report_utils import add_loan_permission_condition


def execute(filters=None):
	filters = frappe._dict(filters or {})
	if not filters.as_at_date:
		frappe.throw(_("As At Date is required."))
	conditions = ["coalesce(l.disbursement_date, l.creation) <= %(as_at_date)s"]
	if not add_loan_permission_condition(conditions, filters):
		return _columns(), []
	for field, expression in (
		("status", "l.status"), ("loan", "l.name"), ("employee", "l.employee"),
		("loan_type", "l.loan_type"), ("department", "e.department"), ("location", "e.branch"),
	):
		if filters.get(field):
			conditions.append(f"{expression}=%({field})s")
	rows = frappe.db.sql(
		f"""
		select l.name loan, l.employee, l.employee_name, l.loan_type, l.status,
			l.approved_amount, l.outstanding_capital, l.outstanding_interest,
			l.outstanding_insurance, l.schedule_version, l.lien_status,
			l.repayment_start_date, l.period_months, e.department, e.branch location
		from `tabKaryo Loan` l
		left join `tabEmployee` e on e.name=l.employee
		where {' and '.join(conditions)}
		order by e.department, e.branch, l.employee, l.name
		""",
		filters,
		as_dict=True,
	)
	data = []
	for row in rows:
		_enrich(row, filters.as_at_date)
		if not filters.deduction_health or row.deduction_health == filters.deduction_health:
			data.append(row)
	return _columns(), data


def _enrich(row, as_at_date):
	schedules = frappe.get_all(
		"Karyo Loan Schedule",
		filters={"parent": row.loan, "is_current": 1},
		fields=["due_date", "capital", "interest", "insurance", "paid_capital", "paid_interest", "paid_insurance", "status"],
		order_by="due_date asc, month asc",
	)
	pending = [s for s in schedules if _outstanding(s) > 0.005]
	overdue = [s for s in pending if s.due_date and getdate(s.due_date) < getdate(as_at_date)]
	row.remaining_periods = len(pending)
	row.next_due_date = min((s.due_date for s in pending if s.due_date), default=None)
	row.arrears_amount = sum(_outstanding(s) for s in overdue)
	row.arrears_periods = len(overdue)
	row.outstanding_total = flt(row.outstanding_capital) + flt(row.outstanding_interest) + flt(row.outstanding_insurance)
	deductions = frappe.get_all("Karyo Loan Deduction", filters={"parent": row.loan}, fields=["component_type", "monthly_amount", "status"])
	active = {d.component_type for d in deductions if d.status == "Active" and flt(d.monthly_amount) > 0}
	required = {component for component, amount in (("Capital", row.outstanding_capital), ("Interest", row.outstanding_interest), ("Insurance", row.outstanding_insurance)) if flt(amount) > 0.005}
	row.monthly_deduction = sum(flt(d.monthly_amount) for d in deductions if d.status == "Active")
	if not required:
		row.deduction_health = "Not Applicable"
	elif required <= active:
		row.deduction_health = "Healthy"
	elif required & active:
		row.deduction_health = "Partial"
	else:
		row.deduction_health = "Missing"


def _outstanding(schedule):
	return max(0, flt(schedule.capital) - flt(schedule.paid_capital)) + max(0, flt(schedule.interest) - flt(schedule.paid_interest)) + max(0, flt(schedule.insurance) - flt(schedule.paid_insurance))


def _columns():
	def c(fieldname, label, fieldtype="Data", width=110, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("loan", "Loan", "Link", 145, "Karyo Loan"), c("employee", "Employee", "Link", 130, "Employee"),
		c("employee_name", "Employee Name", width=160), c("loan_type", "Loan Type", "Link", 125, "Loan Type"),
		c("department", "Department", "Link", 140, "Department"), c("location", "Location / Branch", "Link", 130, "Branch"),
		c("status", "Status", width=85), c("schedule_version", "Version", "Int", 65), c("approved_amount", "Approved", "Currency"),
		c("outstanding_capital", "Capital Balance", "Currency"), c("outstanding_interest", "Interest Balance", "Currency"),
		c("outstanding_insurance", "Insurance Balance", "Currency"), c("outstanding_total", "Total Outstanding", "Currency", 135),
		c("remaining_periods", "Periods Left", "Int", 85), c("next_due_date", "Next Due", "Date", 95),
		c("monthly_deduction", "Monthly Deduction", "Currency", 125), c("deduction_health", "Deduction Health", width=115),
		c("arrears_periods", "Arrears Periods", "Int", 100), c("arrears_amount", "Arrears", "Currency"), c("lien_status", "Lien Status", width=115)]
