import unittest
from unittest.mock import patch

import frappe
from frappe.utils import getdate

from karyo.hr.self_service import (
	_calendar_attendance,
	_calendar_roster,
	_upcoming_leave_allocations,
	my_roster,
)


class TestSelfServiceCalendar(unittest.TestCase):
	def test_future_financial_year_quota_is_visible_but_not_spendable(self):
		allocation = frappe._dict(
			name="ALLOC-FUTURE", leave_type="Special Leave for Revision",
			from_date=getdate("2026-10-01"), to_date=getdate("2027-01-31"),
			new_leaves_allocated=12, total_leaves_allocated=12, total_leaves_encashed=0,
		)
		fiscal_year = frappe._dict(
			year_start_date=getdate("2026-04-01"), year_end_date=getdate("2027-03-31"),
		)
		meta = {"Special Leave for Revision": frappe._dict(
			karyo_mbc_leave_code="EXAMS", karyo_bank_type="Allocated",
		)}
		with patch.object(frappe, "get_all", return_value=[allocation]):
			rows = _upcoming_leave_allocations(
				"EMP-1", getdate("2026-09-25"), fiscal_year, meta,
			)
		self.assertEqual(rows[0]["total"], 12)
		self.assertEqual(rows[0]["remaining"], 0)
		self.assertEqual(rows[0]["available_from"], getdate("2026-10-01"))
		self.assertIn("Available from", rows[0]["availability_status"])

	def test_my_roster_overlays_approved_leave_and_additional_hours(self):
		person = frappe._dict(name="EMP-1", employee_name="Employee One")
		employee = frappe._dict(
			employee_name="Employee One", company="MBC", default_shift="Night Shift",
			karyo_work_pattern="Night Pattern", karyo_employee_group="Roster",
		)
		days = [{
			"date": getdate("2026-09-02"), "label": "Night Shift", "shift_type": "Night Shift",
			"shift_code": "NIGHT", "start_time": "22:00", "end_time": "06:00",
			"duty_hours": 8, "assignment": "SHIFT-1", "schedule": "Rotation A",
			"location": "HQ", "source": "Dated roster", "is_rest_day": False,
			"error": None, "additional_duties": [{
				"name": "AUTH-1", "type": "Night Duty", "status": "Authorised",
				"hours": 6, "assigned_hours": 6, "start": "2026-09-02 22:00:00",
				"end": "2026-09-03 04:00:00", "shift": "Night Shift", "reference": "Manager",
			}],
		}]
		leave = frappe._dict(
			name="LEAVE-1", leave_type="Casual Leave", from_date="2026-09-02",
			to_date="2026-09-02", half_day=0, half_day_date=None,
		)
		with (
			patch("karyo.hr.self_service._own_employee", return_value=person),
			patch.object(frappe.db, "get_value", return_value=employee),
			patch("erpnext.setup.doctype.employee.employee.get_holiday_list_for_employee", return_value=None),
			patch.object(frappe, "get_all", return_value=[leave]),
			patch("karyo.hr.self_service._calendar_roster", return_value=days),
			patch("karyo.hr.clocking._clock_access", return_value={"can_clock_in": True, "reason": "Open"}),
		):
			result = my_roster("2026-09")
		self.assertEqual(result["days"][0]["leave"][0]["name"], "LEAVE-1")
		self.assertEqual(result["summary"]["additional_hours"]["Night Duty"], 6)
		self.assertEqual(result["clock_access"]["reason"], "Open")

	def test_confirmed_attendance_is_present_in_calendar(self):
		person = frappe._dict(name="EMP-1")
		attendance = frappe._dict(
			name="ATT-1", attendance_date="2026-09-10", status="Present",
			attendance_request="REQ-1", karyo_is_corrected=1,
		)
		with (
			patch.object(frappe, "get_all", return_value=[attendance]),
			patch("karyo.hr.clocking.attendance_clock_view", return_value={"records": {}, "live_rows": []}),
		):
			events, summary = _calendar_attendance(
				person, getdate("2026-09-01"), getdate("2026-09-30")
			)
		self.assertEqual(events[0]["title"], "Present")
		self.assertEqual(summary, {"present": 1, "absent": 0})

	def test_calendar_simplifies_timing_states_to_day_level_status(self):
		person = frappe._dict(name="EMP-1")
		rows = [
			frappe._dict(name="ATT-LATE", attendance_date="2026-09-09", status="Present"),
			frappe._dict(name="ATT-MISSING", attendance_date="2026-09-10", status="Present"),
		]
		clock = {
			"records": {
				"ATT-LATE": {"status": "Late"},
				"ATT-MISSING": {"status": "Awaiting Clock In"},
			},
			"live_rows": [],
		}
		with (
			patch.object(frappe, "get_all", return_value=rows),
			patch("karyo.hr.clocking.attendance_clock_view", return_value=clock),
			patch("karyo.hr.self_service.nowdate", return_value="2026-09-24"),
		):
			events, summary = _calendar_attendance(
				person, getdate("2026-09-01"), getdate("2026-09-30")
			)
		self.assertEqual([row["title"] for row in events], ["Present", "Absent"])
		self.assertEqual(events[0]["detail"], "Attendance · Late")
		self.assertEqual(events[1]["detail"], "Attendance · Awaiting Clock In")
		self.assertEqual(summary, {"present": 1, "absent": 1})

	def test_month_roster_has_every_day_and_additional_duty_details(self):
		person = frappe._dict(name="EMP-1")
		employee = frappe._dict(default_shift="Day Shift")
		authority = frappe._dict(
			name="AUTH-1", claim_type="Night Duty", authorization_status="Authorised",
			planned_start="2026-09-02 20:00:00", planned_end="2026-09-03 02:00:00",
			planned_hours=6, approved_hours=0, shift_type="Night Shift", authority_reference="Manager",
		)
		shift = frappe._dict(
			shift_type="Day Shift", shift_code="DAY", start_time="09:00:00",
			end_time="18:00:00", duty_hours=9, assignment="SHIFT-1",
			schedule=None, shift_location="HQ",
		)
		with (
			patch.object(frappe, "get_all", return_value=[authority]),
			patch("karyo.hr.roster.current_duty", return_value=shift),
		):
			rows = _calendar_roster(
				person, employee, getdate("2026-09-01"), getdate("2026-09-03"), set()
			)
		self.assertEqual(len(rows), 3)
		self.assertEqual(rows[0]["start_time"], "09:00")
		self.assertEqual(rows[1]["additional_duties"][0]["type"], "Night Duty")
		self.assertEqual(rows[1]["additional_duties"][0]["assigned_hours"], 6)

	def test_rotation_rest_day_is_not_reported_as_unassigned(self):
		person = frappe._dict(name="EMP-1")
		employee = frappe._dict(default_shift="Day Shift")
		rest = frappe._dict(
			shift_type=None, shift_code=None, start_time=None, end_time=None,
			duty_hours=0, assignment=None, schedule="Rotation A", shift_location=None,
			source="Roster schedule", is_rest_day=True,
		)
		with (
			patch.object(frappe, "get_all", return_value=[]),
			patch("karyo.hr.roster.employee_duty", return_value=rest),
		):
			rows = _calendar_roster(
				person, employee, getdate("2026-09-29"), getdate("2026-09-29"), set()
			)
		self.assertEqual(rows[0]["label"], "Rest / roster day")
		self.assertTrue(rows[0]["is_rest_day"])
		self.assertEqual(rows[0]["source"], "Roster schedule")


if __name__ == "__main__":
	unittest.main()
