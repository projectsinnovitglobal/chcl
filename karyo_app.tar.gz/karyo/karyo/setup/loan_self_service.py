"""Install the loan service-request register and issued agreement fields."""
import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def setup():
	frappe.reload_doc('karyo', 'doctype', 'loan_service_request', force=True)
	frappe.db.sql("""update `tabLoan Service Request` r join `tabKaryo Loan` l on l.name=r.loan set r.company=l.company where coalesce(r.company,'')=''""")
	create_custom_fields({'Karyo Loan': [
		{'fieldname':'agreement_attachment','label':'Agreement File','fieldtype':'Attach','insert_after':'agreement_printed_on','read_only':1},
		{'fieldname':'agreement_signed_on','label':'Agreement Signed On','fieldtype':'Datetime','insert_after':'agreement_attachment','read_only':1},
		{'fieldname':'agreement_signed_by','label':'Agreement Signed By','fieldtype':'Link','options':'User','insert_after':'agreement_signed_on','read_only':1},
		{'fieldname':'agreement_signer_name','label':'Agreement Signer Name','fieldtype':'Data','insert_after':'agreement_signed_by','read_only':1},
		{'fieldname':'agreement_signature_ip','label':'Agreement Signature IP','fieldtype':'Data','insert_after':'agreement_signer_name','read_only':1},
		{'fieldname':'agreement_signature_hash','label':'Agreement Signature Hash','fieldtype':'Data','insert_after':'agreement_signature_ip','read_only':1},
		{'fieldname':'agreement_issued_on','label':'Agreement Issued On','fieldtype':'Datetime','insert_after':'agreement_signature_hash','read_only':1},
		{'fieldname':'agreement_issued_by','label':'Agreement Issued By','fieldtype':'Link','options':'User','insert_after':'agreement_issued_on','read_only':1},
		{'fieldname':'issued_agreement_html','label':'Issued Agreement','fieldtype':'Long Text','insert_after':'agreement_issued_by','hidden':1,'read_only':1},
		{'fieldname':'closing_document_reference','label':'Closing Document Reference','fieldtype':'Data','insert_after':'settlement_date','read_only':1},
		{'fieldname':'closing_document_issued_on','label':'Closing Document Issued On','fieldtype':'Datetime','insert_after':'closing_document_reference','read_only':1},
		{'fieldname':'closing_document_issued_by','label':'Closing Document Issued By','fieldtype':'Link','options':'User','insert_after':'closing_document_issued_on','read_only':1},
		{'fieldname':'issued_closing_document_html','label':'Issued Closing Document','fieldtype':'Long Text','insert_after':'closing_document_issued_by','hidden':1,'read_only':1},
	]})
	from karyo.loan.closing_documents import backfill, ensure_print_format
	ensure_print_format()
	backfill()
