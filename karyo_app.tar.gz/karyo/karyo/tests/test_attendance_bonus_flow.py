"""Attendance menu bonus calculation through payroll posting."""

from unittest.mock import patch

import frappe
from frappe.tests.utils import FrappeTestCase

from karyo.desk.payroll_drawer import record_form, record_save
from karyo.desk.payroll_screens import screen_data
from karyo.payroll.prb_posting import post_run
from karyo.payroll.screen_specs import SCREENS, SCREEN_DOCTYPES
from karyo.payroll.attendance_bonus import (
	automatic_bonus_eligibility,
	approve_attendance_bonus_drafts,
	era_leave_units,
	post_attendance_bonuses,
	process_attendance_bonus_drafts,
	process_automatic_attendance_bonuses,
)
from karyo.payroll.era_hours import approve_era_drafts, post_era_runs, process_era_drafts
from karyo.prb.allowances import attendance_bonus


class TestAttendanceBonusFlow(FrappeTestCase):
	def setUp(self):
		self.previous_user = frappe.session.user
		frappe.set_user("Administrator")
		frappe.db.savepoint("attendance_bonus_flow")
		self.cycle = frappe.db.get_value(
			"Payroll Cycle",
			{"docstatus": ("<", 2), "payroll_period": ("is", "set"), "payment_date": ("is", "set")},
			["name", "company", "start_date", "end_date", "payment_date"],
			as_dict=True,
			order_by="end_date desc",
		)
		if not self.cycle:
			self.skipTest("No usable Payroll Cycle fixture")
		employees = frappe.db.sql(
			"""select employee.name
			from `tabEmployee` employee
			inner join `tabSalary Structure Assignment` assignment
				on assignment.employee=employee.name and assignment.company=employee.company
				and assignment.docstatus=1 and assignment.from_date<=%(start_date)s
			left join `tabPRB Payroll Run` bonus
				on bonus.employee=employee.name and bonus.payroll_cycle=%(cycle)s
				and bonus.docstatus=1 and bonus.run_purpose in
					('Attendance Bonus', 'Incentive Attendance Bonus', 'PRB Attendance Bonuses')
			left join `tabPRB Payroll Run` era
				on era.employee=employee.name and era.payroll_cycle=%(cycle)s
				and era.docstatus=1 and era.run_purpose='ERA Hours Payment'
			where employee.company=%(company)s and employee.status='Active'
				and bonus.name is null and era.name is null
				and (assignment.base<=31525 or assignment.base between 32350 and 54200)
			order by employee.name limit 1""",
			{"company": self.cycle.company, "cycle": self.cycle.name, "start_date": self.cycle.start_date},
		)
		if not employees:
			self.skipTest("No active employee for the Payroll Cycle company")
		self.employee = employees[0][0]

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback(save_point="attendance_bonus_flow")
		frappe.set_user(self.previous_user)

	def test_attendance_and_era_menu_screens_are_registered(self):
		self.assertEqual(SCREENS["attendancebonus"]["run_purpose"], "Attendance Bonus")
		self.assertEqual(
			SCREENS["incentiveattendancebonus"]["bonus_inputs"][0]["input_code"],
			"INCENTIVE_ATTENDANCE",
		)
		self.assertEqual(len(SCREENS["presencebonus"]["bonus_inputs"]), 2)
		self.assertEqual(SCREENS["presencebonus"]["layout"], "attendance_bonus")
		self.assertIn("Attendance + Incentive", SCREENS["presencebonus"]["title"])
		for screen in ("attendancebonus", "incentiveattendancebonus", "presencebonus"):
			self.assertIn("Attendance", SCREEN_DOCTYPES[screen])
		self.assertEqual(SCREENS["erahours"]["run_purpose"], "ERA Hours Payment")
		self.assertEqual(SCREENS["erahours"]["layout"], "attendance_bonus")
		self.assertEqual(SCREENS["erahours"]["governed_inputs"][0]["input_code"], "ERA_HOURS")
		self.assertIn("Attendance", SCREEN_DOCTYPES["erahours"])
		era = screen_data("erahours", {})
		self.assertEqual(era["workflow"], "era")
		self.assertEqual(
			[column["fieldname"] for column in era["list"]["columns"]][2:4],
			["excess_hours", "era_payment"],
		)

	def test_era_automatic_leave_inputs_merge_attendance_and_approved_leave(self):
		attendance = [frappe._dict(attendance_date="2026-09-02", status="Absent", leave_type=None)]
		approved_leave = [frappe._dict(
			from_date="2026-09-02", to_date="2026-09-03", half_day=0,
			half_day_date=None, total_leave_days=2, leave_type="Casual Leave",
		)]
		with patch.object(frappe, "get_all", side_effect=[attendance, approved_leave]), patch(
			"erpnext.setup.doctype.employee.employee.is_holiday", return_value=False
		):
			result = era_leave_units(self.employee, "2026-09-01", "2026-09-30")
		# 2 Sep exists in both sources and is counted once. Approved Casual Leave
		# supplies the category; 3 Sep is the second casual day.
		self.assertEqual(result.casual, 2)
		self.assertEqual(result.other, 0)
		self.assertEqual(len(result.dates), 2)

	def test_locked_defaults_survive_drawer_save_and_calculate_bonus_only(self):
		data = screen_data("attendancebonus", {})
		self.assertEqual(data["defaults"]["run_purpose"], "Attendance Bonus")
		self.assertEqual(data["defaults"]["employee_inputs"][0]["input_code"], "ATTENDANCE_BONUS")
		self.assertEqual(data["defaults"]["employee_inputs"][0]["amount"], 2140)
		incentive = screen_data("incentiveattendancebonus", {})
		self.assertEqual(incentive["defaults"]["employee_inputs"][0]["amount"], 1500)
		self.assertEqual(incentive["calculation_help"]["items"][0]["base"], 1500)
		self.assertEqual(
			incentive["calculation_help"]["items"][0]["setting"], "incentive_attendance_bonus_base"
		)
		self.assertIn("Half Day = 0.5", incentive["calculation_help"]["flow"][1])
		combined = screen_data("presencebonus", {})
		self.assertEqual(combined["layout"], "attendance_bonus")
		self.assertEqual(
			combined["payroll_group"],
			frappe.db.get_value("Payroll Pay Day", combined["cycle"]["pay_day"], "payroll_group"),
		)
		self.assertEqual(
			[column["fieldname"] for column in combined["list"]["columns"]][2:5],
			["attendance_bonus", "incentive_bonus", "prb_attendance_bonus"],
		)
		self.assertEqual(combined["kpis"][0]["label"], "Employees")
		self.assertEqual(combined["kpis"][-1]["label"], "PRB Attendance Bonus Total")
		form = record_form("attendancebonus", "PRB Payroll Run", defaults=data["defaults"], is_admin=True)
		self.assertEqual(form["tables"][0]["rows"][0]["input_code"], "ATTENDANCE_BONUS")
		self.assertEqual(form["tables"][0]["rows"][0]["amount"], 2140)
		self.assertEqual(form["tables"][0]["calculation_help"]["button_label"], "See sample calculation")
		self.assertFalse(form["tables"][0]["calculation_help"]["combined"])

		result = record_save(
			"attendancebonus",
			"PRB Payroll Run",
			{
				"employee": self.employee,
				"payroll_cycle": self.cycle.name,
				"calculation_date": self.cycle.payment_date,
				# Locked category/code/description deliberately do not round-trip.
				"employee_inputs": [{"amount": 2140}],
			},
			is_admin=True,
		)
		run = frappe.get_doc("PRB Payroll Run", result["name"])
		self.assertEqual(run.run_purpose, "Attendance Bonus")
		self.assertEqual([row.input_code for row in run.employee_inputs], ["ATTENDANCE_BONUS"])
		self.assertEqual([row.component_code for row in run.components], ["ATTENDANCE_BONUS"])
		self.assertNotIn("BASIC", [row.component_code for row in run.components])
		self.assertIn("leaves_taken", frappe.parse_json(run.employee_inputs[0].parameters_json))

	def test_approved_combined_bonus_posts_both_authoritative_salary_components(self):
		# Posting is the subject of this test. Keep the absence input deterministic
		# instead of depending on whichever live Attendance fixture shares the cycle.
		with patch(
			"karyo.karyo.doctype.prb_payroll_run.prb_payroll_run.PRBPayrollRun._presence_leave_units",
			return_value=0,
		):
			result = record_save(
				"presencebonus",
				"PRB Payroll Run",
				{
					"employee": self.employee,
					"payroll_cycle": self.cycle.name,
					"calculation_date": self.cycle.payment_date,
					"employee_inputs": [{"amount": 3000}, {"amount": 1800}],
				},
				is_admin=True,
			)
			run = frappe.get_doc("PRB Payroll Run", result["name"])
			amounts = {row.component_code: row.amount for row in run.components}
			self.assertEqual(amounts["ATTENDANCE_BONUS"], attendance_bonus(0, 3000))
			self.assertEqual(amounts["INCENTIVE_ATTENDANCE"], attendance_bonus(0, 1800))
			run.submit()
		breakdown = frappe._dict(total=0, attendance=0, approved_leave=0, worked=1,
			has_working_attendance=True, dates=[])
		with patch("karyo.payroll.attendance_bonus.presence_leave_units", return_value=breakdown):
			posted = post_run(run.name)
		self.assertEqual(len(posted["posted"]), 2)
		additional = [frappe.get_doc("Additional Salary", name) for name in posted["posted"]]
		self.assertEqual(
			{row.salary_component for row in additional},
			{"ATTENDANCE BONUS", "INCENTIVE ATTENDANCE BONUS"},
		)
		self.assertTrue(all(row.karyo_payroll_cycle == self.cycle.name for row in additional))
		self.assertTrue(all(row.ref_docname == run.name for row in additional))

	def test_prepare_payroll_automatically_creates_posts_and_reuses_eligible_bonus(self):
		breakdown = frappe._dict(total=0, attendance=0, approved_leave=0, worked=1,
			has_working_attendance=True, dates=[])
		with patch("karyo.payroll.attendance_bonus.presence_leave_units", return_value=breakdown):
			first = process_automatic_attendance_bonuses(self.cycle.name, [self.employee])
			second = process_automatic_attendance_bonuses(self.cycle.name, [self.employee])
		self.assertEqual(first["created"], 1)
		self.assertEqual(first["posted_runs"], 1)
		self.assertEqual(second["created"], 0)
		self.assertEqual(second["already_processed"], 1)
		run = frappe.get_doc("PRB Payroll Run", first["runs"][0])
		self.assertEqual(run.docstatus, 1)
		self.assertEqual(run.run_purpose, "PRB Attendance Bonuses")
		self.assertEqual(run.custom_entry_source, "Automatic")
		self.assertEqual(run.posting_status, "Posted")
		self.assertEqual(
			{row.component_code for row in run.components},
			{"ATTENDANCE_BONUS", "INCENTIVE_ATTENDANCE"},
		)
		self.assertTrue(all(row.additional_salary for row in run.components))

	def test_screen_process_approve_and_submit_are_separate_steps(self):
		breakdown = frappe._dict(total=0, attendance=0, approved_leave=0, worked=1,
			has_working_attendance=True, dates=[])
		selection = ([self.employee], [])
		with patch("karyo.payroll.employee_processing.resolve_employees", return_value=selection), patch(
			"karyo.payroll.attendance_bonus.presence_leave_units", return_value=breakdown
		):
			processed = process_attendance_bonus_drafts(self.cycle.name, [self.employee])
			self.assertEqual(processed.processed, 1)
			run = frappe.get_doc("PRB Payroll Run", processed.runs[0])
			self.assertEqual(run.docstatus, 0)
			self.assertEqual(run.run_purpose, "PRB Attendance Bonuses")
			self.assertEqual(
				{row.component_code for row in run.components},
				{"ATTENDANCE_BONUS", "INCENTIVE_ATTENDANCE"},
			)
			approved = approve_attendance_bonus_drafts(self.cycle.name, [self.employee])
			self.assertEqual(approved.approved, 1)
			self.assertEqual(frappe.db.get_value("PRB Payroll Run", run.name, "docstatus"), 1)
			posted = post_attendance_bonuses(self.cycle.name, [self.employee])
			self.assertEqual(posted.posted, 1)
			self.assertEqual(posted.additional_salary, 2)

	def test_no_working_attendance_is_not_eligible_for_either_bonus(self):
		breakdown = frappe._dict(total=0, attendance=0, approved_leave=0, worked=0,
			has_working_attendance=False, dates=[])
		with patch("karyo.payroll.attendance_bonus.presence_leave_units", return_value=breakdown):
			eligibility = automatic_bonus_eligibility(self.employee, self.cycle)
		self.assertFalse(eligibility.eligible)
		self.assertEqual(eligibility.worked_units, 0)
		self.assertEqual([row["calculated_amount"] for row in eligibility["items"]], [0, 0])

		selection = ([self.employee], [])
		with patch("karyo.payroll.employee_processing.resolve_employees", return_value=selection), patch(
			"karyo.payroll.attendance_bonus.presence_leave_units", return_value=breakdown
		):
			processed = process_attendance_bonus_drafts(self.cycle.name, [self.employee])
		run = frappe.get_doc("PRB Payroll Run", processed.runs[0])
		self.assertEqual(run.custom_eligibility_status, "Not Eligible")
		self.assertEqual(run.gross_pay, 0)
		self.assertTrue(all(row.amount == 0 for row in run.components))
		run.submit()
		with patch("karyo.payroll.attendance_bonus.presence_leave_units", return_value=breakdown):
			with self.assertRaisesRegex(frappe.ValidationError, "no submitted working Attendance"):
				post_run(run.name)

	def test_era_process_approve_and_submit_are_separate_steps(self):
		selection = ([self.employee], [])
		hours = frappe._dict(hours=32, sources=["ERA-AUTH-TEST"])
		with patch("karyo.payroll.employee_processing.resolve_employees", return_value=selection), patch(
			"karyo.payroll.era_hours.eligible_era_hours", return_value=hours
		):
			processed = process_era_drafts(self.cycle.name, [self.employee])
			self.assertEqual(processed.processed, 1)
			run = frappe.get_doc("PRB Payroll Run", processed.runs[0])
			self.assertEqual(run.docstatus, 0)
			self.assertEqual(run.run_purpose, "ERA Hours Payment")
			self.assertEqual(run.employee_inputs[0].quantity, 32)
			self.assertEqual([row.component_code for row in run.components], ["ERA_HOURS"])
			approved = approve_era_drafts(self.cycle.name, [self.employee])
			self.assertEqual(approved.approved, 1)
			posted = post_era_runs(self.cycle.name, [self.employee])
			self.assertEqual(posted.posted, 1)
			self.assertEqual(posted.additional_salary, 1)

	def test_blank_base_is_filled_and_non_positive_base_is_rejected(self):
		result = record_save(
			"attendancebonus",
			"PRB Payroll Run",
			{
				"employee": self.employee,
				"payroll_cycle": self.cycle.name,
				"calculation_date": self.cycle.payment_date,
				"employee_inputs": [{"amount": ""}],
			},
			is_admin=True,
		)
		self.assertEqual(frappe.get_doc("PRB Payroll Run", result["name"]).employee_inputs[0].amount, 2140)
		with self.assertRaisesRegex(frappe.ValidationError, "Base Amount"):
			record_save(
				"incentiveattendancebonus",
				"PRB Payroll Run",
				{
					"employee": self.employee,
					"payroll_cycle": self.cycle.name,
					"calculation_date": self.cycle.payment_date,
					"employee_inputs": [{"amount": -1}],
				},
				is_admin=True,
			)
