"""PRB core setup: Salary Point reference DocType + Master Salary Table loader.

bench --site dev.localhost execute karyo.setup.prb.setup
"""

import frappe

from karyo.prb.master_table import MASTER_SALARY_TABLE
from karyo.setup.foundation import f, make_doctype


def create_doctypes():
	make_doctype(
		"PRB Salary Point",
		autoname="format:{review_year}-{salary_point}",
		title_field="salary_point",
		fields=[
			f("review_year", "Int", "Review Year", default="2026", reqd=1, in_list_view=1),
			f("salary_point", "Data", "Salary Point", reqd=1, in_list_view=1),
			f("cb", "Column Break"),
			f("basic_2021", "Currency", "Row 1 — Basic Salary 2021"),
			f("gross_2025", "Currency", "Row 2 — Gross Salary 2025"),
			f("revised_2026", "Currency", "Row 3 — Revised Salary 2026", in_list_view=1),
		],
	)


def load_master_table(review_year=2026):
	created = 0
	for pt, r1, r2, r3 in MASTER_SALARY_TABLE:
		name = f"{review_year}-{pt}"
		if frappe.db.exists("PRB Salary Point", name):
			continue
		frappe.get_doc(
			{
				"doctype": "PRB Salary Point",
				"review_year": review_year,
				"salary_point": pt,
				"basic_2021": r1,
				"gross_2025": r2,
				"revised_2026": r3,
			}
		).insert(ignore_permissions=True)
		created += 1
	print(f"  + loaded {created} salary points ({len(MASTER_SALARY_TABLE)} in table)")


def setup():
	print("Karyo PRB core setup:")
	create_doctypes()
	load_master_table()
	frappe.db.set_single_value("Karyo Settings", "enable_prb_payroll", 1)
	frappe.db.commit()
	print("Done.")
