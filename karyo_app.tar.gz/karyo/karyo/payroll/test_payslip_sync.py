import unittest
from datetime import date
from unittest.mock import patch

import frappe

from karyo.payroll.payslip_sync import salary_slip_attendance_summary


class TestPayslipAttendanceSync(unittest.TestCase):
	def test_leave_days_are_not_copied_from_absent_days(self):
		attendance = [
			frappe._dict(name="ATT-1", attendance_date=date(2026, 9, 1), status="Present", leave_type=None, half_day_status=None),
			frappe._dict(name="ATT-2", attendance_date=date(2026, 9, 2), status="On Leave", leave_type="Sick Leave", half_day_status=None),
			frappe._dict(name="ATT-3", attendance_date=date(2026, 9, 3), status="Half Day", leave_type="Casual Leave", half_day_status="On Leave"),
			frappe._dict(name="ATT-4", attendance_date=date(2026, 9, 4), status="Absent", leave_type=None, half_day_status=None),
		]
		applications = [
			# This is the same day as ATT-2 and must not be counted twice.
			frappe._dict(from_date=date(2026, 9, 2), to_date=date(2026, 9, 2), half_day=0, half_day_date=None, total_leave_days=1),
		]

		def rows(doctype, **kwargs):
			return applications if doctype == "Leave Application" else attendance

		with patch.object(frappe, "get_all", side_effect=rows), patch(
			"erpnext.setup.doctype.employee.employee.is_holiday", return_value=False
		):
			result = salary_slip_attendance_summary(
				"EMP-1", "2026-09-01", "2026-09-30", native_absent_days=3
			)

		self.assertEqual(result.leave_days, 1.5)
		self.assertEqual(result.present_days, 1.5)
		self.assertEqual(result.explicit_absent_days, 1)
		self.assertEqual(result.unmarked_absent_days, 2)


if __name__ == "__main__":
	unittest.main()
