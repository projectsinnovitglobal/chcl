"""Reviewable ERA-hours calculation, approval and payroll-posting workflow."""

import json

import frappe
from frappe import _
from frappe.utils import flt, getdate


ERA_PURPOSE = "ERA Hours Payment"
ERA_CODE = "ERA_HOURS"


def eligible_era_hours(employee, cycle):
	"""Return payroll-approved excess hours recorded inside the cycle dates."""
	meta = frappe.get_meta("PRB Overtime Authorization")
	filters = {
		"employee": employee,
		"company": cycle.company,
		"claim_type": "Excess Hours",
		"docstatus": 1,
		"actual_start": ("between", [f"{cycle.start_date} 00:00:00", f"{cycle.end_date} 23:59:59"]),
		"approved_hours": (">", 0),
	}
	if meta.has_field("payroll_approval_status"):
		filters["payroll_approval_status"] = "Approved"
	else:
		filters["authorization_status"] = "Recorded"
	rows = frappe.get_all(
		"PRB Overtime Authorization",
		filters=filters,
		fields=["name", "approved_hours"],
		order_by="actual_start asc, name asc",
		limit_page_length=0,
	)
	return frappe._dict(
		hours=flt(sum(flt(row.approved_hours) for row in rows), 6),
		sources=[row.name for row in rows],
	)


def _resolved(cycle, employees):
	from karyo.payroll.employee_processing import resolve_employees

	return resolve_employees(cycle, employees)[0]


def process_era_drafts(payroll_cycle, employees=None):
	"""Calculate selected employees into reviewable ERA Draft runs."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle) if isinstance(payroll_cycle, str) else payroll_cycle
	cycle.check_permission("read")
	result = frappe._dict(
		processed=0, created=0, updated=0, eligible=0, not_eligible=0,
		already_approved=0, runs=[], employees=[],
	)
	for employee in _resolved(cycle, employees):
		if frappe.db.exists("PRB Payroll Run", {
			"employee": employee, "payroll_cycle": cycle.name,
			"run_purpose": ERA_PURPOSE, "docstatus": 1,
		}):
			result.already_approved += 1
			continue
		hours = eligible_era_hours(employee, cycle)
		name = frappe.db.get_value("PRB Payroll Run", {
			"employee": employee, "payroll_cycle": cycle.name,
			"run_purpose": ERA_PURPOSE, "custom_entry_source": "Automatic", "docstatus": 0,
		}, "name", order_by="modified desc")
		doc = frappe.get_doc("PRB Payroll Run", name) if name else frappe.new_doc("PRB Payroll Run")
		is_new = doc.is_new()
		doc.employee = employee
		doc.company = cycle.company
		doc.payroll_cycle = cycle.name
		doc.payroll_period = cycle.get("payroll_period")
		doc.calculation_date = cycle.payment_date or cycle.end_date
		doc.review_year = getdate(cycle.end_date).year
		doc.run_purpose = ERA_PURPOSE
		doc.set("employee_inputs", [])
		doc.append("employee_inputs", {
			"category": "Allowance",
			"input_code": ERA_CODE,
			"description": _("ERA Hours Payment"),
			"quantity": hours.hours,
			"parameters_json": json.dumps({
				"eligible_excess_hours": hours.hours,
				"authorization_sources": hours.sources,
			}, sort_keys=True),
		})
		if doc.meta.has_field("custom_entry_source"):
			doc.custom_entry_source = "Automatic"
		if doc.meta.has_field("custom_manual_reference"):
			doc.custom_manual_reference = _("Processed from approved excess-hours records for {0}.").format(cycle.name)
		doc.flags.ignore_permissions = True
		if is_new:
			doc.insert(ignore_permissions=True)
			result.created += 1
		else:
			doc.save(ignore_permissions=True)
			result.updated += 1
		payable = doc.custom_eligibility_status == "Eligible" and flt(doc.gross_pay) > 0
		result.processed += 1
		result.eligible += int(payable)
		result.not_eligible += int(not payable)
		result.runs.append(doc.name)
		result.employees.append(employee)
	return result


def approve_era_drafts(payroll_cycle, employees=None):
	"""Submit the latest payable ERA Draft for each selected employee."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle) if isinstance(payroll_cycle, str) else payroll_cycle
	cycle.check_permission("read")
	from karyo.payroll.employee_processing import employee_error_message

	result = frappe._dict(approved=0, skipped=0, runs=[])
	for employee in _resolved(cycle, employees):
		if frappe.db.exists("PRB Payroll Run", {
			"employee": employee, "payroll_cycle": cycle.name,
			"run_purpose": ERA_PURPOSE, "docstatus": 1,
		}):
			result.skipped += 1
			continue
		name = frappe.db.get_value("PRB Payroll Run", {
			"employee": employee, "payroll_cycle": cycle.name,
			"run_purpose": ERA_PURPOSE, "custom_entry_source": "Automatic", "docstatus": 0,
		}, "name", order_by="modified desc")
		if not name:
			result.skipped += 1
			continue
		doc = frappe.get_doc("PRB Payroll Run", name)
		if doc.custom_eligibility_status != "Eligible" or not flt(doc.gross_pay):
			result.skipped += 1
			continue
		try:
			doc.flags.ignore_permissions = True
			doc.submit()
		except frappe.ValidationError as error:
			frappe.throw(employee_error_message(employee, error))
		result.approved += 1
		result.runs.append(doc.name)
	return result


def post_era_runs(payroll_cycle, employees=None):
	"""Post approved ERA results through the configured ERA payroll mapping."""
	cycle = frappe.get_doc("Payroll Cycle", payroll_cycle) if isinstance(payroll_cycle, str) else payroll_cycle
	cycle.check_permission("read")
	from karyo.payroll.employee_processing import employee_error_message
	from karyo.payroll.prb_posting import post_run

	selected = _resolved(cycle, employees)
	rows = frappe.get_all("PRB Payroll Run", filters={
		"employee": ("in", selected or [""]), "payroll_cycle": cycle.name,
		"run_purpose": ERA_PURPOSE, "docstatus": 1,
		"snapshot_status": "Approved", "posting_status": ("!=", "Posted"),
	}, fields=["name", "employee", "gross_pay", "custom_eligibility_status"],
		order_by="employee asc, creation asc", limit_page_length=0)
	result = frappe._dict(posted=0, additional_salary=0, runs=[])
	for row in rows:
		if not flt(row.gross_pay) or row.custom_eligibility_status == "Not Eligible":
			continue
		try:
			posted = post_run(row.name)
		except frappe.ValidationError as error:
			frappe.throw(employee_error_message(row.employee, error))
		result.posted += 1
		result.additional_salary += len(posted.get("posted") or [])
		result.runs.append(row.name)
	return result
