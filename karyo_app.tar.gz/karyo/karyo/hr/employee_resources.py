"""Employee assignments and issued documents, always scoped to the session employee."""
import frappe
from frappe import _
from frappe.utils import getdate, nowdate
from karyo.hr.clocking import _own_employee


@frappe.whitelist()
def assignments():
    employee = _own_employee()
    from erpnext.setup.doctype.employee.employee import get_holiday_list_for_employee
    holiday_list = get_holiday_list_for_employee(employee.name, raise_exception=False)
    holiday = None
    if holiday_list:
        doc = frappe.get_doc('Holiday List', holiday_list)
        holiday = dict(name=doc.name, from_date=doc.from_date, to_date=doc.to_date,
            rows=[dict(date=h.holiday_date, description=h.description, weekly_off=h.weekly_off)
                  for h in sorted(doc.holidays, key=lambda h: getdate(h.holiday_date))])
    policies = frappe.get_all('Leave Policy Assignment', filters={'employee':employee.name, 'docstatus':1},
        fields=['name','leave_policy','effective_from','effective_to'], order_by='effective_from desc')
    today = getdate(nowdate())
    for row in policies:
        row['status'] = 'Upcoming' if getdate(row.effective_from)>today else 'Expired' if getdate(row.effective_to)<today else 'Current'
        row['details'] = frappe.get_all('Leave Policy Detail', filters={'parent':row.leave_policy,'parenttype':'Leave Policy'},
            fields=['leave_type','annual_allocation'], order_by='idx')
    # Employee onboarding stores selected schemes directly on Employee. Show all
    # manual and conditional selections even when native assignments predate them.
    from karyo.hr.leave_controls import _employee_leave_schemes
    selected = frappe.db.get_value('Employee', employee.name, 'karyo_leave_scheme')
    selected_schemes = _employee_leave_schemes(employee.name, selected)
    for scheme in reversed(selected_schemes):
        if any(row.leave_policy == scheme for row in policies):
            continue
        policies.insert(0, frappe._dict(
            name='selected-scheme', leave_policy=scheme,
            effective_from=f'{today.year}-01-01', effective_to=f'{today.year}-12-31',
            status='Current (selected)' if scheme == selected else 'Current (additional)',
            details=frappe.get_all('Leave Policy Detail', filters={'parent':scheme,'parenttype':'Leave Policy'},
                fields=['leave_type','annual_allocation'], order_by='idx'),
        ))
    return dict(holiday=holiday, policies=policies)


def _documents():
    employee = frappe.get_doc('Employee', _own_employee().name)
    rows = []
    for field, label in [
        ('passport', 'Passport'),
        ('driving_licence', 'Driving Licence'),
        ('offer_letter', 'Offer Letter'),
        ('joining_letter', 'Joining Letter'),
        ('karyo_other_letters', 'Other Letter'),
    ]:
        url = employee.get(field)
        if not url:
            continue
        # Only files actually attached to this employee may be served.
        file = frappe.db.get_value('File', {'file_url':url,'attached_to_doctype':'Employee','attached_to_name':employee.name},
            ['name','file_name','creation'], as_dict=True)
        if file:
            rows.append(dict(key='file:'+file.name, title=label, filename=file.file_name, date=file.creation))
    return sorted(rows,key=lambda r:str(r['date'] or ''),reverse=True)


@frappe.whitelist()
def documents():
    return _documents()


@frappe.whitelist()
def document(key, download=0):
    row = next((r for r in _documents() if r['key']==key),None)
    if not row:
        frappe.throw(_('This document is not available to you.'),frappe.PermissionError)
    kind, name = key.split(':',1)
    if kind == 'file':
        content = frappe.get_doc('File',name).get_content()
        if not int(download) and row['filename'].lower().endswith('.docx'):
            # Browser-readable text preview; Download always returns the original file.
            import io
            import zipfile
            import xml.etree.ElementTree as ET
            from html import escape
            from frappe.utils.pdf import get_pdf
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                info = archive.getinfo('word/document.xml')
                if info.file_size > 20 * 1024 * 1024:
                    frappe.throw(_('This document is too large to preview. Please download it.'))
                root = ET.fromstring(archive.read(info))
            ns = {'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
            paragraphs = [''.join(t.text or '' for t in p.findall('.//w:t', ns)) for p in root.findall('.//w:p', ns)]
            html = '<html><head><meta charset="utf-8"></head><body><h2>'+escape(row['title'])+'</h2><p>Document text preview. Download the original for its complete formatting.</p>'+''.join('<p>'+escape(p)+'</p>' for p in paragraphs)+'</body></html>'
            content = get_pdf(html)
            row['filename'] = row['filename'][:-5] + '-preview.pdf' 
    else:
        frappe.throw(_('This document is not available to you.'), frappe.PermissionError)
    frappe.local.response.filename = row['filename']
    frappe.local.response.filecontent = content
    frappe.local.response.type = 'download'
    # Restrict inline rendering to safe document types; HTML attachments download.
    safe_inline = row['filename'].lower().endswith(('.pdf','.png','.jpg','.jpeg','.gif','.webp','.txt'))
    frappe.local.response.display_content_as = 'attachment' if int(download) or not safe_inline else 'inline'
