"""Navigation resolves the permitted prerequisite without mutating payroll."""
import unittest
from unittest.mock import patch
import frappe
from karyo.desk.payroll_screens import _sequence_remediation


class TestPayrollRemediation(unittest.TestCase):
    def setUp(self):
        self.cycle = dict(name='major', company='Company A', pay_period_label='July 2026',
                          start_date='2026-07-01', end_date='2026-07-31')
        self.scope = {'sequence_blocked_reason': 'Minor approval required'}
        self.day = dict(company='Company A', pay_period_label='July 2026', payroll_type='Minor',
                        status='Active', pay_day='minor-day', key='payday::minor-day')
        self.doc = patch('frappe.get_doc', return_value=frappe._dict(minor_sequence_waived=0)).start()
        self.permission = patch('frappe.has_permission', return_value=True).start()
        self.requirement = patch('karyo.payroll.sequencing.major_sequence_requirement', return_value=('blocked', 'minor')).start()
        self.rows = patch('frappe.get_list', return_value=[frappe._dict(name='minor', pay_day='minor-day', status='Input Open')]).start()
        self.addCleanup(patch.stopall)

    def test_exact_minor_and_period_key(self):
        wrong = dict(self.day, company='Company B', key='wrong')
        action = _sequence_remediation(self.cycle, self.scope, [wrong, self.day])
        self.assertEqual(action['period'], 'payday::minor-day')
        self.assertEqual(action['screen'], 'process')
        self.rows.return_value[0].status = 'Review'
        self.assertEqual(_sequence_remediation(self.cycle, self.scope, [self.day])['screen'], 'close')

    def test_missing_cycle_can_open_existing_day_or_create(self):
        self.requirement.return_value = ('blocked', None)
        action = _sequence_remediation(self.cycle, self.scope, [self.day])
        self.assertEqual(action['pay_day'], 'minor-day')
        action = _sequence_remediation(self.cycle, self.scope, [])
        self.assertEqual(action['doctype'], 'Payroll Pay Day')
        self.assertEqual(action['defaults']['company'], 'Company A')
        self.assertNotIn('payment_date', action['defaults'])

    def test_inaccessible_cycle_does_not_link_another_run(self):
        self.rows.return_value = []
        action = _sequence_remediation(self.cycle, self.scope, [self.day])
        self.assertEqual(action['screen'], 'paydays')
        self.assertNotIn('period', action)
        self.requirement.return_value = ('blocked', None)
        self.permission.return_value = False
        self.assertNotIn('doctype', _sequence_remediation(self.cycle, self.scope, []))

    def test_waiver_and_unblocked(self):
        self.assertIsNone(_sequence_remediation(self.cycle, {}, [self.day]))
        self.doc.return_value.minor_sequence_waived = 1
        action = _sequence_remediation(self.cycle, self.scope, [self.day])
        self.assertEqual(action['name'], 'major')
        self.assertEqual(action['doctype'], 'Payroll Cycle')
