import frappe
from frappe import _
from frappe.utils import cint


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions, values = ["1=1"], {"year": cint(filters.get("year")) or frappe.utils.now_datetime().year}
	for field, expression in (
		("company", "e.company"), ("department", "e.department"),
		("employee", "b.employee"), ("status", "b.status"),
	):
		if filters.get(field):
			conditions.append(f"{expression} = %({field})s")
			values[field] = filters.get(field)
	if cint(filters.get("with_refund")):
		conditions.append("ifnull(p.refund_amount, 0) > 0")

	data = frappe.db.sql(
		f"""
		select b.employee, b.employee_name, e.company, e.department, %(year)s as year,
			coalesce(p.annual_entitlement_days, b.allotted_days) as annual_entitlement_days,
			coalesce(p.sick_leave_taken_days, b.taken_days) as sick_leave_taken_days,
			coalesce(p.unused_days, greatest(b.allotted_days - b.taken_days, 0)) as unused_days,
			coalesce(p.opening_bank_days, b.opening_bank_days) as opening_bank_days,
			coalesce(p.bank_credit_days, 0) as bank_credit_days,
			coalesce(p.refund_days, 0) as refund_days,
			coalesce(p.refund_amount, 0) as refund_amount,
			coalesce(p.closing_bank_days, b.bank_days) as closing_bank_days,
			b.advance_allotted_days,
			coalesce(p.opening_advance_days, b.advance_balance_days) as opening_advance_days,
			coalesce(p.advance_offset_days, 0) as advance_offset_days,
			coalesce(p.new_advance_balance, b.advance_balance_days) as advance_balance_days,
			b.available_days, b.status, p.name as posting
		from `tabSick Leave Bank` b
		inner join `tabEmployee` e on e.name = b.employee
		left join `tabSick Leave Bank Posting` p on p.name = (
			select p2.name from `tabSick Leave Bank Posting` p2
			where p2.employee = b.employee and p2.year = %(year)s and p2.docstatus = 1
			order by p2.creation desc limit 1
		)
		where {' and '.join(conditions)}
		order by b.employee_name, b.employee
		""",
		values,
		as_dict=True,
	)
	return _columns(), data


def _columns():
	return [
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 135},
		{"fieldname": "employee_name", "label": _("Employee Name"), "width": 180},
		{"fieldname": "company", "label": _("Company"), "fieldtype": "Link", "options": "Company", "width": 110},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 140},
		{"fieldname": "year", "label": _("Year"), "fieldtype": "Int", "width": 70},
		{"fieldname": "annual_entitlement_days", "label": _("Annual Entitlement"), "fieldtype": "Float", "width": 125},
		{"fieldname": "sick_leave_taken_days", "label": _("Taken"), "fieldtype": "Float", "width": 85},
		{"fieldname": "unused_days", "label": _("Unused"), "fieldtype": "Float", "width": 85},
		{"fieldname": "opening_bank_days", "label": _("Opening Bank"), "fieldtype": "Float", "width": 105},
		{"fieldname": "bank_credit_days", "label": _("Bank Credit"), "fieldtype": "Float", "width": 95},
		{"fieldname": "refund_days", "label": _("Refund Days"), "fieldtype": "Float", "width": 95},
		{"fieldname": "refund_amount", "label": _("Refund Amount"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "closing_bank_days", "label": _("Closing Bank"), "fieldtype": "Float", "width": 105},
		{"fieldname": "advance_allotted_days", "label": _("Advance Allotment"), "fieldtype": "Float", "width": 125},
		{"fieldname": "opening_advance_days", "label": _("Opening Advance"), "fieldtype": "Float", "width": 120},
		{"fieldname": "advance_offset_days", "label": _("Advance Offset"), "fieldtype": "Float", "width": 110},
		{"fieldname": "advance_balance_days", "label": _("Advance Outstanding"), "fieldtype": "Float", "width": 140},
		{"fieldname": "available_days", "label": _("Available"), "fieldtype": "Float", "width": 90},
		{"fieldname": "status", "label": _("Status"), "width": 85},
		{"fieldname": "posting", "label": _("Year-end Posting"), "fieldtype": "Link", "options": "Sick Leave Bank Posting", "width": 150},
	]
