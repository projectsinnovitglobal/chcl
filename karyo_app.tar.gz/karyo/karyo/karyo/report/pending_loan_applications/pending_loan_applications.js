frappe.query_reports["Pending Loan Applications"] = {
	filters: [
		{fieldname: "workflow_state", label: __("Application Status"), fieldtype: "Link", options: "Workflow State"},
		{fieldname: "loan_type", label: __("Loan Type"), fieldtype: "Link", options: "Loan Type"},
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee"},
		{fieldname: "owner", label: __("Owner"), fieldtype: "Link", options: "User"},
		{fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department"},
		{fieldname: "location", label: __("Location / Branch"), fieldtype: "Link", options: "Branch"},
		{fieldname: "minimum_age_days", label: __("Minimum Age (Days)"), fieldtype: "Int", default: 0}
	]
};
