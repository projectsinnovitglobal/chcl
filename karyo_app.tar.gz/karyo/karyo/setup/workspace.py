"""Karyo desk workspace + reports (demo visibility layer).

    bench --site dev.localhost execute karyo.setup.workspace.setup

Creates Query Reports for Passage Benefit and Loan, and a public 'Karyo HRMS'
workspace with cards, links and shortcuts. Idempotent.
"""

import json

import frappe

ROLES = ["System Manager", "HR Manager", "HR User"]

REPORTS = [
	{
		"name": "Passage Benefit Bank Balances",
		"ref_doctype": "Passage Benefit Bank",
		"query": """select
			employee as "Employee:Link/Employee:150",
			employee_name as "Name::180",
			opening_balance as "Opening:Currency:110",
			total_earned as "Earned:Currency:110",
			total_taken as "Taken:Currency:110",
			total_adjustments as "Adjustments:Currency:120",
			current_balance as "Current Balance:Currency:140",
			status as "Status::90"
		from `tabPassage Benefit Bank`
		order by current_balance desc""",
	},
	{
		"name": "Passage Benefit Ledger",
		"ref_doctype": "Passage Benefit Ledger Entry",
		"query": """select
			posting_date as "Date:Date:100",
			employee as "Employee:Link/Employee:140",
			entry_type as "Type::110",
			amount as "Amount:Currency:130",
			balance_after as "Balance After:Currency:140",
			pay_period as "Pay Period::110",
			reference_name as "Reference::160"
		from `tabPassage Benefit Ledger Entry`
		where docstatus = 1
		order by posting_date desc, creation desc""",
	},
	{
		"name": "PB Parameter Change History",
		"ref_doctype": "Passage Benefit Settings",
		"query": """select
			item_sequence as "Version:Int:80",
			effective_from as "Effective From:Date:110",
			pb_percentage as "PB Percentage:Percent:110",
			salary_basis as "Salary Basis::170",
			min_years_service as "Minimum Service:Int:120",
			min_salary_threshold as "Salary Threshold:Currency:140",
			leap_year_treatment as "Leap Year::140",
			rounding_stage as "Rounding Stage::130",
			remarks as "Remarks::220"
		from `tabPassage Benefit Parameter Version`
		where parenttype='Passage Benefit Settings'
		order by effective_from desc, item_sequence desc""",
	},
	{
		"name": "PB Run Reconciliation",
		"ref_doctype": "Passage Benefit Computation Run",
		"query": """select
			name as "Run:Link/Passage Benefit Computation Run:170",
			run_datetime as "Run Time:Datetime:150",
			run_source as "Source::90",
			pay_period as "Period::100",
			payroll_cycle as "Payroll Cycle:Link/Payroll Cycle:150",
			total_targets as "Targets:Int:80",
			total_processed as "Processed:Int:90",
			total_skipped as "Skipped:Int:80",
			total_failed as "Failed:Int:80",
			total_earned as "Earned:Currency:120",
			ledger_posted_count as "Ledger Count:Int:100",
			ledger_posted_amount as "Ledger Amount:Currency:130",
			status as "Status::150"
		from `tabPassage Benefit Computation Run`
		order by run_datetime desc""",
	},
	{
		"name": "Loan Portfolio",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			loan_type as "Type:Link/Loan Type:120",
			approved_amount as "Principal:Currency:120",
			outstanding_capital as "Outstanding:Currency:130",
			monthly_refund as "Monthly:Currency:120",
			status as "Status::90"
		from `tabKaryo Loan`
		where docstatus = 1
		order by outstanding_capital desc""",
	},
	{
		"name": "Loan Guarantor Exposure",
		"ref_doctype": "Karyo Loan Guarantor",
		"query": """select
			g.guarantor as "Guarantor:Link/Employee:160",
			g.guarantor_name as "Name::180",
			count(l.name) as "Active Guarantees:Int:140",
			sum(l.outstanding_capital) as "Total Exposure:Currency:150"
		from `tabKaryo Loan Guarantor` g
		inner join `tabKaryo Loan` l on l.name = g.parent
		where l.status = 'Active'
		group by g.guarantor
		order by count(l.name) desc""",
	},
	{
		"name": "Passage Benefit Request Register",
		"ref_doctype": "Passage Benefit Application",
		"query": """select
			name as "Application:Link/Passage Benefit Application:170",
			employee as "Employee:Link/Employee:140",
			usage_item as "Usage Item:Link/Passage Benefit Usage Item:130",
			request_amount as "Requested:Currency:110",
			claimable_amount as "Claimable:Currency:110",
			amount_taken as "Taken:Currency:110",
			workflow_state as "Status::120",
			pay_period as "Pay Period::100"
		from `tabPassage Benefit Application`
		order by creation desc""",
	},
	{
		"name": "Loan Repayment Schedule",
		"ref_doctype": "Karyo Loan",
		"report_type": "Script Report",
	},
	{
		"name": "Loan Deduction Report",
		"ref_doctype": "Karyo Loan",
		"query": """select
			employee as "Employee:Link/Employee:140",
			salary_component as "Component:Link/Salary Component:170",
			amount as "Monthly Amount:Currency:130",
			from_date as "From:Date:100",
			to_date as "To:Date:100",
			ref_docname as "Loan Reference::150"
		from `tabAdditional Salary`
		where ref_doctype in ('Karyo Loan', 'Karyo Loan Recast') and docstatus = 1
		order by employee, salary_component""",
	},
	{
		"name": "PRB Payroll Register",
		"ref_doctype": "PRB Payroll Run",
		"query": """select
			name as "Run:Link/PRB Payroll Run:150",
			employee as "Employee:Link/Employee:150",
			employee_name as "Name::160",
			review_year as "Year:Int:70",
			period as "Period::110",
			salary_point as "Point::70",
			basic_salary as "Basic:Currency:120",
			gross_pay as "Gross:Currency:120",
			exception_code as "Exception::140"
		from `tabPRB Payroll Run`
		where docstatus = 1
		order by review_year desc, employee""",
	},
	{
		"name": "Sick Leave Bank Balances",
		"ref_doctype": "Sick Leave Bank",
		"report_type": "Script Report",
		"is_standard": "Yes",
	},
	{
		"name": "Vacation Leave Balances",
		"ref_doctype": "Vacation Leave Bank",
		"report_type": "Script Report",
		"is_standard": "Yes",
	},
	{
		"name": "MBC Employee Leave Balance",
		"ref_doctype": "Leave Balance",
		"report_type": "Script Report",
		"is_standard": "Yes",
	},
	{
		"name": "EOY Bonus Register",
		"ref_doctype": "EOY Bonus",
		"query": """select
			employee as "Employee:Link/Employee:150",
			employee_name as "Name::170",
			year as "Year:Int:70",
			`case` as "Case::150",
			monthly_salary as "Monthly:Currency:120",
			bonus_amount as "Bonus:Currency:130"
		from `tabEOY Bonus`
		where docstatus = 1
		order by year desc, employee""",
	},
	{
		"name": "PMS Score Summary",
		"ref_doctype": "PMS Appraisal",
		"query": """select
			employee as "Employee:Link/Employee:150",
			employee_name as "Name::170",
			year as "Year:Int:70",
			appraisal_type as "Type::100",
			overall_score as "Score:Percent:120"
		from `tabPMS Appraisal`
		where docstatus = 1
		order by year desc, overall_score desc""",
	},
	{
		# Training manual, "Query Pay Register": allowances, compensation,
		# contribution, travelling, PAYE and basic salary for each employee.
		"name": "MBC Pay Register",
		"ref_doctype": "Salary Slip",
		"report_type": "Script Report",
		"is_standard": "Yes",
	},
]

# Additional loan reports toward the 15-report catalogue (RPT-001..014).
LOAN_REPORTS = [
	{
		"name": "Loan Application Register",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			loan_type as "Type:Link/Loan Type:110",
			amount_applied as "Applied:Currency:110",
			approved_amount as "Approved:Currency:110",
			date_applied as "Date Applied:Date:100",
			workflow_state as "Status::170"
		from `tabKaryo Loan`
		order by creation desc""",
	},
	{
		"name": "Pending Loan Applications",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			loan_type as "Type:Link/Loan Type:110",
			amount_applied as "Applied:Currency:110",
			workflow_state as "Status::170",
			committee_date as "Committee Date:Date:120"
		from `tabKaryo Loan`
		where workflow_state in ('Draft','Printed','Loan Committee Scheduled',
			'Under Loan Committee Review','Pending','Managing Director Approval Pending')
		order by creation""",
	},
	{
		"name": "Loan Committee Review",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			loan_type as "Type:Link/Loan Type:110",
			approved_amount as "Approved:Currency:120",
			committee_date as "Committee Date:Date:120",
			workflow_state as "Status::170"
		from `tabKaryo Loan`
		where workflow_state in ('Loan Committee Scheduled','Under Loan Committee Review','Recommended')
		order by committee_date""",
	},
	{
		"name": "Loan Approval Outcomes",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			approved_amount as "Approved:Currency:120",
			committee_decision as "Decision::110",
			workflow_state as "Status::150",
			committee_remarks as "Remarks::220"
		from `tabKaryo Loan`
		where workflow_state in ('Recommended','Approved','Rejected','Agreement Printed','Disbursed')
		order by modified desc""",
	},
	{
		"name": "Loan Agreement Listing",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			loan_type as "Type:Link/Loan Type:120",
			approved_amount as "Approved:Currency:120",
			agreement_printed_on as "Agreement Printed:Date:140",
			workflow_state as "Status::160"
		from `tabKaryo Loan`
		where agreement_printed_on is not null
		order by agreement_printed_on desc, name""",
	},
	{
		"name": "Loan Disbursement Register",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			loan_type as "Type:Link/Loan Type:120",
			disbursement_date as "Disbursement Date:Date:140",
			disbursed_amount as "Disbursed:Currency:120",
			payment_reference as "Payment Reference::170",
			status as "Status::100"
		from `tabKaryo Loan`
		where disbursement_date is not null
		order by disbursement_date desc, name""",
	},
	{
		"name": "Active Loans",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:140",
			loan_type as "Type:Link/Loan Type:120",
			approved_amount as "Principal:Currency:120",
			outstanding_capital as "Outstanding:Currency:130",
			monthly_refund as "Monthly:Currency:110",
			disbursement_date as "Disbursed:Date:100"
		from `tabKaryo Loan`
		where status = 'Active'
		order by outstanding_capital desc""",
	},
	{
		"name": "Loan Statement",
		"ref_doctype": "Karyo Loan",
		"query": """select
			l.name as "Loan:Link/Karyo Loan:150",
			l.employee as "Employee:Link/Employee:140",
			l.approved_amount as "Principal:Currency:110",
			sum(case when s.status='Paid' then s.capital else 0 end) as "Capital Paid:Currency:120",
			sum(case when s.status<>'Paid' then s.capital else 0 end) as "Capital Due:Currency:120",
			sum(case when s.status='Paid' then s.interest else 0 end) as "Interest Paid:Currency:120",
			sum(case when s.status<>'Paid' then s.interest else 0 end) as "Interest Due:Currency:120",
			sum(case when s.status<>'Paid' then s.total else 0 end) as "Balance Due:Currency:120"
		from `tabKaryo Loan` l
		left join `tabKaryo Loan Schedule` s on s.parent = l.name
		where l.docstatus = 1
		group by l.name
		order by l.name""",
	},
	{
		"name": "Outstanding Loan Balances",
		"ref_doctype": "Karyo Loan",
		"query": """select
			l.name as "Loan:Link/Karyo Loan:150",
			l.employee as "Employee:Link/Employee:140",
			l.outstanding_capital as "Outstanding Capital:Currency:150",
			sum(case when s.status<>'Paid' then s.interest else 0 end) as "Outstanding Interest:Currency:150",
			sum(case when s.status<>'Paid' then s.insurance else 0 end) as "Outstanding Insurance:Currency:150"
		from `tabKaryo Loan` l
		left join `tabKaryo Loan Schedule` s on s.parent = l.name
		where l.status = 'Active'
		group by l.name
		order by l.outstanding_capital desc""",
	},
	{
		"name": "Loan Budget - Interest Element",
		"ref_doctype": "Karyo Loan",
		"query": """select
			l.loan_type as "Loan Type:Link/Loan Type:150",
			count(distinct l.name) as "Active Loans:Int:110",
			sum(case when s.status<>'Paid' then s.interest else 0 end) as "Projected Interest:Currency:170"
		from `tabKaryo Loan` l
		left join `tabKaryo Loan Schedule` s on s.parent = l.name
		where l.status = 'Active'
		group by l.loan_type
		order by 3 desc""",
	},
	{
		"name": "Loan Ledger",
		"ref_doctype": "Karyo Loan Ledger Entry",
		"query": """select
			loan as "Loan:Link/Karyo Loan:150",
			date_processed as "Date:Date:100",
			ref_type as "Ref Type::130",
			period as "Period::80",
			debit as "Debit:Currency:120",
			credit as "Credit:Currency:120",
			balance_after as "Balance After:Currency:130",
			reference as "Reference::150"
		from `tabKaryo Loan Ledger Entry`
		order by loan, creation""",
	},
	{
		"name": "Loanees Without Deductions",
		"ref_doctype": "Karyo Loan",
		"query": """select
			l.name as "Loan:Link/Karyo Loan:150",
			l.employee as "Employee:Link/Employee:150",
			l.monthly_refund as "Monthly:Currency:120",
			l.status as "Status::90"
		from `tabKaryo Loan` l
		where l.status = 'Active'
		and not exists (
			select 1 from `tabKaryo Loan Deduction` d
			where d.parent = l.name and d.status = 'Active'
		)
		order by l.name""",
	},
	{
		"name": "Settled Loans",
		"ref_doctype": "Karyo Loan",
		"query": """select
			name as "Loan:Link/Karyo Loan:150",
			employee as "Employee:Link/Employee:150",
			loan_type as "Type:Link/Loan Type:120",
			approved_amount as "Principal:Currency:120",
			settlement_date as "Settled On:Date:110"
		from `tabKaryo Loan`
		where status = 'Settled'
		order by settlement_date desc""",
	},
	{
		"name": "Pending Lien Registration",
		"ref_doctype": "Karyo Loan",
		"query": """select
			l.name as "Loan:Link/Karyo Loan:150",
			l.employee as "Employee:Link/Employee:150",
			l.loan_type as "Type:Link/Loan Type:120",
			l.lien_status as "Lien Status::110",
			l.workflow_state as "State::150"
		from `tabKaryo Loan` l
		inner join `tabLoan Type` t on t.name = l.loan_type
		where t.lien_required = 1
			and coalesce(l.lien_status,'') <> 'Registered'
			and l.status <> 'Settled'
		order by l.name""",
	},
]
REPORTS += LOAN_REPORTS

PAYROLL_REPORTS = [
	{
		"name": "MBC Payroll Register",
		"ref_doctype": "Payroll Cycle",
		"query": """select
			pce.payroll_cycle as "Cycle:Link/Payroll Cycle:150",
			pce.employee as "Employee:Link/Employee:140",
			ss.employee_name as "Name::170",
			ss.gross_pay as "Gross:Currency:120",
			ss.total_deduction as "Deductions:Currency:120",
			ss.net_pay as "Net Pay:Currency:120",
			pce.status as "Status::130"
		from `tabPayroll Cycle Employee` pce
		left join `tabSalary Slip` ss on ss.name=pce.salary_slip
		order by pce.payroll_cycle desc, pce.employee""",
	},
	{
		"name": "MBC Payroll Summary Statistics",
		"ref_doctype": "Payroll Cycle",
		"query": """select
			pce.payroll_cycle as "Cycle:Link/Payroll Cycle:170",
			count(*) as "Employees:Int:100",
			sum(coalesce(ss.gross_pay,0)) as "Gross:Currency:130",
			sum(coalesce(ss.total_deduction,0)) as "Deductions:Currency:130",
			sum(coalesce(ss.net_pay,0)) as "Net Pay:Currency:130",
			sum(case when pce.status='Failed' then 1 else 0 end) as "Failed:Int:90"
		from `tabPayroll Cycle Employee` pce
		left join `tabSalary Slip` ss on ss.name=pce.salary_slip
		group by pce.payroll_cycle
		order by pce.payroll_cycle desc""",
	},
	{
		"name": "Payroll Exception and Readiness",
		"ref_doctype": "Payroll Readiness Exception",
		"query": """select
			payroll_cycle as "Cycle:Link/Payroll Cycle:150",
			employee as "Employee:Link/Employee:140",
			validation_code as "Code::150",
			severity as "Severity::120",
			status as "Status::100",
			message as "Finding::300",
			resolved_by as "Resolved By:Link/User:150",
			resolved_on as "Resolved On:Datetime:150"
		from `tabPayroll Readiness Exception`
		order by status, severity, modified desc""",
	},
	{
		"name": "Payroll Source to Salary Slip Trace",
		"ref_doctype": "Payroll Source Trace",
		"query": """select
			payroll_cycle as "Cycle:Link/Payroll Cycle:150",
			employee as "Employee:Link/Employee:140",
			category as "Category::110",
			source_doctype as "Source Type:Link/DocType:150",
			source_name as "Source::170",
			pdb_code as "PDB::90",
			salary_component as "Salary Component:Link/Salary Component:170",
			amount as "Amount:Currency:120",
			additional_salary as "Additional Salary:Link/Additional Salary:160",
			status as "Status::100",
			creation as "Created At:Datetime:155"
		from `tabPayroll Source Trace`
		order by creation desc, payroll_cycle desc, employee""",
	},
	{
		"name": "Payroll Statutory Reconciliation",
		"ref_doctype": "Payroll Statutory Result",
		"query": """select
			payroll_cycle as "Cycle:Link/Payroll Cycle:150",
			result_type as "Result Type::150",
			count(*) as "Employees:Int:100",
			sum(current_amount) as "Current Amount:Currency:140",
			sum(cumulative_amount) as "Cumulative Amount:Currency:150",
			sum(case when status not in ('Reviewed','Applied') then 1 else 0 end) as "Unreviewed:Int:100"
		from `tabPayroll Statutory Result`
		group by payroll_cycle, result_type
		order by payroll_cycle desc, result_type""",
	},
	{
		"name": "Payroll PDB to GL Mapping",
		"ref_doctype": "Payroll PDB Code",
		"query": """select
			pdb_code as "PDB::90",
			description as "Description::190",
			pdb_type as "Type:Link/Payroll PDB Type:150",
			salary_component as "Salary Component:Link/Salary Component:180",
			default_cost_center as "Cost Center:Link/Cost Center:180",
			is_active as "Active:Check:70",
			configuration_version as "Configuration Version::150"
		from `tabPayroll PDB Code`
		order by display_sequence, pdb_code""",
	},
]
REPORTS += PAYROLL_REPORTS

# Reports named in the client Payroll Management user manual (Reports section).
# Fixed-format bank ASCII files and MRA/NSF returns are deliberately absent:
# they need the recipient's published record layout, which is not in the client
# package, and a guessed layout would be rejected on submission.
PAYROLL_MANUAL_REPORTS = [
	{
		"name": "MBC Salary Sheet",
		"ref_doctype": "Salary Slip",
		"query": """select
			ss.start_date as "Period Start:Date:110",
			ss.employee as "Employee:Link/Employee:140",
			ss.employee_name as "Name::180",
			ss.department as "Department:Link/Department:170",
			ss.designation as "Designation:Link/Designation:150",
			ss.mode_of_payment as "Payment Mode::110",
			ss.gross_pay as "Gross:Currency:120",
			ss.total_deduction as "Deductions:Currency:120",
			ss.net_pay as "Net Pay:Currency:120",
			ss.total_working_days as "Work Days:Float:100",
			ss.payment_days as "Paid Days:Float:100",
			case ss.docstatus when 1 then 'Submitted' when 2 then 'Cancelled' else 'Draft' end as "Status::100"
		from `tabSalary Slip` ss
		where ss.docstatus < 2
		order by ss.start_date desc, ss.employee""",
	},
	{
		"name": "MBC Net Pay",
		"ref_doctype": "Salary Slip",
		"query": """select
			ss.start_date as "Period Start:Date:110",
			ss.employee as "Employee:Link/Employee:140",
			ss.employee_name as "Name::190",
			ss.mode_of_payment as "Payment Mode::120",
			ss.bank_name as "Bank::150",
			ss.bank_account_no as "Account::150",
			ss.net_pay as "Net Pay:Currency:130"
		from `tabSalary Slip` ss
		where ss.docstatus < 2
		order by ss.start_date desc, ss.net_pay desc""",
	},
	{
		"name": "MBC Payroll by Payment Mode",
		"ref_doctype": "Salary Slip",
		"query": """select
			ss.start_date as "Period Start:Date:110",
			coalesce(nullif(ss.mode_of_payment, ''), 'Not set') as "Payment Mode::150",
			count(*) as "Employees:Int:110",
			sum(ss.gross_pay) as "Gross:Currency:140",
			sum(ss.total_deduction) as "Deductions:Currency:140",
			sum(ss.net_pay) as "Net Pay:Currency:140"
		from `tabSalary Slip` ss
		where ss.docstatus < 2
		group by ss.start_date, coalesce(nullif(ss.mode_of_payment, ''), 'Not set')
		order by ss.start_date desc, 2""",
	},
	{
		"name": "MBC Employee Payment Deduction",
		"ref_doctype": "Salary Slip",
		"query": """select
			ss.start_date as "Period Start:Date:110",
			ss.employee as "Employee:Link/Employee:140",
			ss.employee_name as "Name::170",
			emp.grade as "Grade:Link/Employee Grade:140",
			case sd.parentfield when 'earnings' then 'Payment' else 'Deduction' end as "Payment Type::110",
			sd.salary_component as "Salary Component:Link/Salary Component:180",
			pdb.pdb_code as "PDB::90",
			pdb.pdb_type as "PDB Type:Link/Payroll PDB Type:130",
			sd.amount as "Amount:Currency:120"
		from `tabSalary Detail` sd
		inner join `tabSalary Slip` ss on ss.name = sd.parent and sd.parenttype = 'Salary Slip'
		left join `tabEmployee` emp on emp.name = ss.employee
		left join `tabPayroll PDB Code` pdb on pdb.salary_component = sd.salary_component
		where ss.docstatus < 2 and sd.amount <> 0
		order by ss.start_date desc, ss.employee, sd.parentfield desc, sd.idx""",
	},
	{
		"name": "MBC Variance List",
		"ref_doctype": "Salary Slip",
		"query": """select * from (
			select
				ss.start_date as "Period Start:Date:110",
				ss.employee as "Employee:Link/Employee:140",
				ss.employee_name as "Name::170",
				sd.salary_component as "Salary Component:Link/Salary Component:180",
				sd.amount as "This Period:Currency:130",
				lag(sd.amount) over (
					partition by ss.employee, sd.salary_component, sd.parentfield
					order by ss.start_date
				) as "Previous Period:Currency:140",
				sd.amount - coalesce(lag(sd.amount) over (
					partition by ss.employee, sd.salary_component, sd.parentfield
					order by ss.start_date
				), 0) as "Variance:Currency:120"
			from `tabSalary Detail` sd
			inner join `tabSalary Slip` ss on ss.name = sd.parent and sd.parenttype = 'Salary Slip'
			where ss.docstatus < 2
		) variance
		where `Variance:Currency:120` <> 0
		order by `Period Start:Date:110` desc, abs(`Variance:Currency:120`) desc""",
	},
	{
		"name": "MBC Contribution Report",
		"ref_doctype": "Payroll Statutory Result",
		"query": """select
			psr.payroll_cycle as "Cycle:Link/Payroll Cycle:150",
			psr.employee as "Employee:Link/Employee:140",
			emp.employee_name as "Name::170",
			psr.result_type as "Contribution::170",
			psr.rule_reference as "Scheme::170",
			psr.salary_basis as "Salary Basis:Currency:130",
			psr.current_amount as "Current:Currency:120",
			psr.cumulative_amount as "Cumulative:Currency:130",
			psr.status as "Status::110"
		from `tabPayroll Statutory Result` psr
		left join `tabEmployee` emp on emp.name = psr.employee
		where psr.result_type in ('Employee Contribution', 'Employer Contribution')
		order by psr.payroll_cycle desc, psr.employee, psr.result_type""",
	},
	{
		"name": "MBC PAYE Generated Detail",
		"ref_doctype": "Payroll Statutory Result",
		"query": """select
			psr.payroll_cycle as "Cycle:Link/Payroll Cycle:150",
			pc.payroll_type as "Payroll Type::100",
			pc.payment_date as "Payment Date:Date:110",
			pc.company as "Company:Link/Company:140",
			psr.employee as "Employee:Link/Employee:140",
			emp.employee_name as "Name::170",
			psr.period_index as "P:Int:70",
			psr.salary_basis as "Cumulative Emoluments:Currency:170",
			coalesce(json_unquote(json_extract(psr.output_snapshot, '$.calculation.monthly_iet')),
				json_unquote(json_extract(psr.output_snapshot, '$.allowed_reliefs')), 0) as "EDF / Relief:Currency:130",
			coalesce(json_unquote(json_extract(psr.output_snapshot, '$.calculation.paye_engine.band_factor')),
				json_unquote(json_extract(psr.output_snapshot, '$.band_factor')),
				psr.period_index / coalesce(nullif(py.periods_per_year, 0), 13)) as "P Factor:Float:100",
			psr.chargeable_income as "Chargeable Income:Currency:160",
			psr.cumulative_amount as "Cumulative PAYE:Currency:150",
			coalesce(json_unquote(json_extract(psr.output_snapshot, '$.calculation.previous_paye')),
				json_unquote(json_extract(psr.output_snapshot, '$.previous_paye')), 0) as "Prior PAYE:Currency:130",
			psr.current_amount as "Current PAYE:Currency:130",
			psr.source_declaration as "EDF Declaration:Link/Employee Tax Declaration:180",
			psr.status as "Status::100"
		from `tabPayroll Statutory Result` psr
		left join `tabEmployee` emp on emp.name = psr.employee
		inner join `tabPayroll Cycle` pc on pc.name = psr.payroll_cycle
		left join `tabPayroll PAYE Year` py on py.name = psr.rule_reference
		where psr.result_type = 'PAYE' and psr.status != 'Reversed' and pc.docstatus < 2
		order by psr.payroll_cycle desc, psr.employee""",
	},
	{
		"name": "MBC MRA Annual Return",
		"ref_doctype": "Salary Slip",
		"query": """select
			concat(year(coalesce(pc.payment_date, ss.posting_date, ss.end_date))
				- if(month(coalesce(pc.payment_date, ss.posting_date, ss.end_date)) < 7, 1, 0), '/',
				year(coalesce(pc.payment_date, ss.posting_date, ss.end_date))
				+ if(month(coalesce(pc.payment_date, ss.posting_date, ss.end_date)) >= 7, 1, 0)) as "Income Year::110",
			ss.company as "Company:Link/Company:140",
			ss.employee as "Employee:Link/Employee:140",
			ss.employee_name as "Name::190",
			emp.pan_number as "Tax Account No::150",
			count(*) as "Payroll Runs:Int:110",
			sum(ss.gross_pay) as "Emoluments:Currency:150",
			sum(coalesce(paye.paye_amount, 0)) as "PAYE Withheld:Currency:150",
			sum(ss.net_pay) as "Net Paid:Currency:140"
		from `tabSalary Slip` ss
		left join `tabEmployee` emp on emp.name = ss.employee
		left join `tabPayroll Cycle` pc on pc.name = ss.karyo_payroll_cycle
		left join (
			select parent, sum(amount) as paye_amount
			from `tabSalary Detail`
			where parenttype = 'Salary Slip' and parentfield = 'deductions'
				and exists (select 1 from `tabPayroll PDB Code` pdb
					where pdb.pdb_code = 'PAYE' and pdb.salary_component = `tabSalary Detail`.salary_component)
			group by parent
		) paye on paye.parent = ss.name
		where ss.docstatus = 1
		group by 1, ss.company, ss.employee, ss.employee_name, emp.pan_number
		order by 1 desc, ss.employee""",
	},
	{
		"name": "MBC Statement of Emoluments",
		"ref_doctype": "Salary Slip",
		"query": """select
			year(ss.start_date) as "Calendar Year:Int:110",
			ss.employee as "Employee:Link/Employee:140",
			ss.employee_name as "Name::180",
			sd.salary_component as "Salary Component:Link/Salary Component:190",
			case sd.parentfield when 'earnings' then 'Emolument' else 'Deduction' end as "Category::120",
			coalesce(pdb.pdb_code, '') as "PDB::90",
			case when pdb.taxable = 1 then 'Taxable' when pdb.exempt = 1 then 'Exempt' else '' end as "Tax Treatment::120",
			sum(sd.amount) as "Annual Amount:Currency:150"
		from `tabSalary Detail` sd
		inner join `tabSalary Slip` ss on ss.name = sd.parent and sd.parenttype = 'Salary Slip'
		left join `tabPayroll PDB Code` pdb on pdb.salary_component = sd.salary_component
		where ss.docstatus = 1
		group by year(ss.start_date), ss.employee, ss.employee_name, sd.salary_component,
			sd.parentfield, pdb.pdb_code, pdb.taxable, pdb.exempt
		order by 1 desc, ss.employee, 5, sd.salary_component""",
	},
]
REPORTS += PAYROLL_MANUAL_REPORTS

LEAVE_ATTENDANCE_REPORTS = [
	{
		"name": "MBC Leave Transaction Reconciliation",
		"ref_doctype": "Leave Ledger Entry",
		"roles": ["System Manager", "HR Manager", "HR User", "Payroll Reviewer", "Payroll Auditor"],
		"query": """select
			employee as "Employee:Link/Employee:140",
			leave_type as "Leave Type:Link/Leave Type:150",
			from_date as "From:Date:100",
			to_date as "To:Date:100",
			transaction_type as "Source Type::150",
			transaction_name as "Source::170",
			leaves as "Movement:Float:100",
			is_lwp as "LWP:Check:60",
			is_carry_forward as "Carry Forward:Check:100",
			docstatus as "Document Status:Int:100"
		from `tabLeave Ledger Entry`
		order by employee, leave_type, from_date, creation""",
	},
	{
		"name": "Attendance Punch Exceptions",
		"ref_doctype": "Employee Checkin",
		"roles": ["System Manager", "HR Manager", "HR User", "Payroll Reviewer", "Payroll Auditor"],
		"query": """select
			employee as "Employee:Link/Employee:140",
			employee_name as "Name::170",
			time as "Punch Time:Datetime:150",
			log_type as "Type::80",
			shift as "Shift:Link/Shift Type:130",
			device_id as "Device::120",
			offshift as "Off Shift:Check:80",
			attendance as "Attendance:Link/Attendance:150",
			case when attendance is null then 'Unmatched' when offshift=1 then 'Off Shift' else 'Matched' end as "Result::100"
		from `tabEmployee Checkin`
		where attendance is null or offshift=1
		order by time desc""",
	},
	{
		"name": "Attendance Payment Reconciliation",
		"ref_doctype": "Payroll Source Trace",
		"roles": ["System Manager", "HR Manager", "Payroll Processor", "Payroll Reviewer", "Payroll Approver", "Payroll Auditor"],
		"query": """select
			payroll_cycle as "Cycle:Link/Payroll Cycle:150",
			employee as "Employee:Link/Employee:140",
			source_doctype as "Attendance Source:Link/DocType:150",
			source_name as "Source::170",
			pdb_code as "PDB::90",
			salary_component as "Salary Component:Link/Salary Component:170",
			amount as "Amount:Currency:120",
			additional_salary as "Payroll Output:Link/Additional Salary:160",
			status as "Status::100"
		from `tabPayroll Source Trace`
		where category in ('Overtime','Night Duty','Extreme Weather','Attendance')
		   or source_doctype in ('Attendance','Employee Checkin','Attendance Request')
		order by payroll_cycle desc, employee, creation""",
	},
]
REPORTS += LEAVE_ATTENDANCE_REPORTS

INTEGRATION_REPORTS = [
	{
		"name": "Integration Failure and Reconciliation Monitor",
		"ref_doctype": "MBC Integration Event",
		"roles": ["System Manager", "Integration Manager", "Payroll Auditor"],
		"query": """select
			integration_profile as "Integration:Link/MBC Integration Profile:170",
			occurred_on as "Occurred:Datetime:150",
			status as "Status::100",
			attempt as "Attempt:Int:70",
			source_count as "Source Count:Int:100",
			target_count as "Target Count:Int:100",
			source_total as "Source Total:Currency:120",
			target_total as "Target Total:Currency:120",
			difference as "Difference:Currency:110",
			error_message as "Error::260",
			reconciliation_reference as "Reconciliation::170"
		from `tabMBC Integration Event`
		where status in ('Started','Failed') or difference <> 0 or source_count <> target_count
		order by occurred_on desc""",
	},
]
REPORTS += INTEGRATION_REPORTS


def _report_roles(report):
	if report.get("roles"):
		return report["roles"]
	ref = report["ref_doctype"]
	if ref.startswith("Passage Benefit"):
		return ["System Manager", "Passage Benefit Officer", "Payroll Reviewer", "Payroll Auditor"]
	if ref.startswith("Karyo Loan") or ref in ("Loan Type", "Loan Condition"):
		return ["System Manager", "Loan Officer", "Loan Committee", "Karyo Loan Committee", "Payroll Finance", "Payroll Auditor"]
	if ref in ("Sick Leave Bank", "Vacation Leave Bank", "Leave Balance", "Leave Application", "Attendance"):
		return ["System Manager", "HR Manager", "HR User", "Payroll Auditor"]
	if ref in (
		"Payroll Cycle", "Payroll Readiness Exception", "Payroll Source Trace",
		"Payroll Statutory Result", "Payroll PDB Code", "PRB Payroll Run", "EOY Bonus",
		# The user manual's payroll reports read salary slips; payroll staff run them.
		"Salary Slip",
	):
		return ["System Manager", "Payroll Processor", "Payroll Reviewer", "Payroll Approver", "Payroll Auditor"]
	return ROLES


def create_reports(report_names=None):
	for r in REPORTS:
		if report_names is not None and r["name"] not in report_names:
			continue
		roles = _report_roles(r)
		if frappe.db.exists("Report", r["name"]):
			doc = frappe.get_doc("Report", r["name"])
			doc.ref_doctype = r["ref_doctype"]
			doc.module = "Karyo"
			# Do not downgrade an existing standard report: Frappe deliberately
			# rejects converting standard reports to custom ones during save.
			doc.is_standard = r.get("is_standard", doc.is_standard or "No")
			doc.report_type = r.get("report_type", "Query Report")
			doc.query = r.get("query")
			doc.set("roles", [{"role": role} for role in roles])
			doc.save(ignore_permissions=True)
			continue
		doc = frappe.get_doc(
			{
				"doctype": "Report",
				"report_name": r["name"],
				"ref_doctype": r["ref_doctype"],
				"report_type": r.get("report_type", "Query Report"),
				"module": "Karyo",
				"is_standard": r.get("is_standard", "No"),
				"query": r.get("query"),
				"roles": [{"role": role} for role in roles],
			}
		)
		doc.insert(ignore_permissions=True)
		print(f"  + Report: {r['name']}")


def _all_links():
	def card(label):
		return {"type": "Card Break", "label": label, "hidden": 0, "onboard": 0}

	def link(dt, ltype="DocType"):
		row = {"type": "Link", "label": dt, "link_type": ltype, "link_to": dt, "hidden": 0, "onboard": 0}
		# All Karyo reports are Query Reports — without this flag the framework routes them
		# to the doctype report-view (/app/<dt>/view/report/...) which crashes on
		# JSON.parse(report.json). is_query_report=1 routes to /app/query-report/<name>.
		if ltype == "Report":
			row["is_query_report"] = 1
		return row

	return [
		card("Passage Benefit"),
		link("Passage Benefit Bank"),
		link("Passage Benefit Computation"),
		link("Passage Benefit Application"),
		link("Passage Benefit Adjustment"),
		link("Passage Benefit Usage Item"),
		link("Passage Benefit Not Earned Period"),
		link("Passage Benefit Computation Run"),
		link("PB Bank Balance Listing", "Report"),
		link("PB Computation Log", "Report"),
		link("PB Request Register", "Report"),
		link("PB Payroll Posting Report", "Report"),
		link("PB Adjustment Audit", "Report"),
		link("PB Exception Report", "Report"),
		card("Loan Management"),
		link("Loan Type"),
		link("Karyo Loan"),
		link("Karyo Loan Recast"),
		link("Karyo Loan Correction"),
		link("Karyo Loan Settlement"),
		link("Karyo Loan Interest Change"),
		link("Loan Insurance Rate"),
		link("Loan Recomputation Parameter"),
		link("Loan Condition"),
		link("Loan Operation Code"),
		link("Loan Document Requirement"),
		link("Loan Approval Authority"),
		link("Loan Committee"),
		link("Loan Application Register", "Report"),
		link("Pending Loan Applications", "Report"),
		link("Loan Committee Review", "Report"),
		link("Loan Approval Outcomes", "Report"),
		link("Active Loans", "Report"),
		link("Loan Statement", "Report"),
		link("Outstanding Loan Balances", "Report"),
		link("Loan Budget - Interest Element", "Report"),
		link("Loan Ledger", "Report"),
		link("Loan Deduction Report", "Report"),
		link("Loanees Without Deductions", "Report"),
		link("Settled Loans", "Report"),
		link("Pending Lien Registration", "Report"),
		link("Loan Guarantor Exposure", "Report"),
		card("PRB Payroll"),
		link("PRB Overtime Authorization"),
		link("PRB Higher Duty Assignment"),
		link("PRB Payroll Run"),
		link("PRB Salary Point"),
		link("Sick Leave Bank"),
		link("Sick Leave Bank Posting"),
		link("EOY Bonus"),
		link("PMS Appraisal"),
		link("Vacation Leave Bank"),
		link("Vacation Leave Posting"),
		link("Lateness Leave Deduction"),
		link("PRB Grade Scale"),
		link("PRB Rule Version"),
		card("Reports"),
		link("Passage Benefit Bank Balances", "Report"),
		link("Passage Benefit Ledger", "Report"),
		link("Passage Benefit Request Register", "Report"),
		link("Loan Portfolio", "Report"),
		link("Loan Repayment Schedule", "Report"),
		link("Loan Deduction Report", "Report"),
		link("Loan Guarantor Exposure", "Report"),
		link("PRB Payroll Register", "Report"),
		link("Sick Leave Bank Balances", "Report"),
		link("Vacation Leave Balances", "Report"),
		link("EOY Bonus Register", "Report"),
		link("PMS Score Summary", "Report"),
		card("Configuration"),
		link("Karyo Settings"),
		link("Passage Benefit Settings"),
		link("PRB Payroll Settings"),
	]


def _links():
	"""General HR workspace links, excluding domain-owned Loans/Benefits links."""
	result = []
	skip_section = False
	for row in _all_links():
		if row["type"] == "Card Break":
			skip_section = row["label"] in ("Passage Benefit", "Loan Management")
			if skip_section:
				continue
		if skip_section:
			continue
		target = row.get("link_to", "")
		if target.startswith(("Loan ", "Passage Benefit", "PB ")) or target in (
			"Karyo Loan", "Active Loans", "Settled Loans", "Pending Lien Registration",
			"Loanees Without Deductions",
		):
			continue
		result.append(row)
	return result


# Number cards + charts shown at the top of the workspace. Records are created
# by setup/dashboards.py, which runs earlier in install.SETUP_SEQUENCE.
WORKSPACE_NUMBER_CARDS = ["Claims Awaiting Action", "Payroll Exceptions"]
WORKSPACE_CHARTS = ["Payroll Gross by Period"]


def _content():
	blocks = [{"type": "header", "data": {"text": "Karyo HRMS", "col": 12}}]
	blocks += [
		{"type": "number_card", "data": {"number_card_name": name, "col": 3}}
		for name in WORKSPACE_NUMBER_CARDS
	]
	blocks += [{"type": "chart", "data": {"chart_name": name, "col": 6}} for name in WORKSPACE_CHARTS]
	blocks += [
		{"type": "spacer", "data": {"col": 12}},
		{"type": "card", "data": {"card_name": "PRB Payroll", "col": 4}},
		{"type": "card", "data": {"card_name": "Reports", "col": 4}},
		{"type": "card", "data": {"card_name": "Configuration", "col": 4}},
	]
	return json.dumps(blocks)


def ensure_prb_workflow_links():
	"""Add the governed PRB source screens without rebuilding a customised workspace."""
	name = frappe.db.get_value("Workspace", {"label": "MBC HRMS"}, "name") or frappe.db.get_value(
		"Workspace", {"module": "Karyo", "public": 1}, "name"
	)
	if not name:
		return
	workspace = frappe.get_doc("Workspace", name)
	existing = {row.link_to for row in workspace.links if row.link_to}
	canonical = {row.get("link_to"): row for row in _all_links() if row.get("link_to")}
	for doctype in ("PRB Overtime Authorization", "PRB Higher Duty Assignment"):
		if doctype not in existing:
			workspace.append("links", canonical[doctype])
	workspace.save(ignore_permissions=True)
	frappe.db.commit()


def create_workspace():
	# Workspace autonaming follows the visible label on current Frappe versions,
	# so older sites may store this workspace as either legacy name.
	for workspace_name in ("Karyo HRMS", "MBC HRMS"):
		if frappe.db.exists("Workspace", workspace_name):
			frappe.delete_doc("Workspace", workspace_name, ignore_permissions=True, force=True)
	ws = frappe.get_doc(
		{
			"doctype": "Workspace",
			"name": "Karyo HRMS",
			"label": "MBC HRMS",
			"title": "MBC HRMS",
			"module": "Karyo",
			"public": 1,
			"icon": "users",
			"content": _content(),
			"links": _links(),
			"number_cards": [{"number_card_name": name, "label": name} for name in WORKSPACE_NUMBER_CARDS],
			"charts": [{"chart_name": name, "label": name} for name in WORKSPACE_CHARTS],
			"shortcuts": [
				{"type": "DocType", "label": "MBC Loan", "link_to": "Karyo Loan", "color": "Blue"},
				{
					"type": "DocType",
					"label": "Passage Benefit Computation",
					"link_to": "Passage Benefit Computation",
					"color": "Green",
				},
				{
					"type": "Report",
					"label": "Loan Portfolio",
					"link_to": "Loan Portfolio",
					"is_query_report": 1,
				},
				{
					"type": "Report",
					"label": "PB Bank Balances",
					"link_to": "Passage Benefit Bank Balances",
					"is_query_report": 1,
				},
				{
					"type": "DocType",
					"label": "PRB Payroll Run",
					"link_to": "PRB Payroll Run",
					"color": "Grey",
				},
				{
					"type": "Report",
					"label": "PRB Payroll Register",
					"link_to": "PRB Payroll Register",
					"is_query_report": 1,
				},
			],
		}
	)
	ws.insert(ignore_permissions=True)
	print("  + Workspace: Karyo HRMS")
	create_domain_workspaces()
	# Preserve the legacy workspace record/URL, but remove it from navigation so
	# it cannot reintroduce the old mixed Loans + Benefits menu.
	if frappe.db.exists("Workspace", "SIL HRMS"):
		frappe.db.set_value("Workspace", "SIL HRMS", {"is_hidden": 1, "public": 0})


def _domain_link(label, target=None, link_type="DocType"):
	row = {
		"type": "Link", "label": label, "link_type": link_type,
		"link_to": target or label, "hidden": 0, "onboard": 0,
	}
	if link_type == "Report":
		row["is_query_report"] = 1
	return row


def _domain_card(label):
	return {"type": "Card Break", "label": label, "hidden": 0, "onboard": 0}


def create_domain_workspaces():
	"""Create separate, non-duplicating entry points for Loans and Benefits.

	The links point to the existing pages and DocTypes, so bookmarks and API
	contracts remain backward compatible while navigation ownership is explicit.
	"""
	domains = {
		"Loans": {
			"icon": "money-coins-1",
			"links": [
				_domain_card("Loans"),
				_domain_link("Loan Center", "loan-center", "Page"),
				_domain_link("Loan Committee Review", "Loan Committee Review", "Report"),
				_domain_link("Loan Applications and Loans", "Karyo Loan"),
				_domain_link("Loan Inquiry", "loan-inquiry", "Page"),
				_domain_link("Adjustments / Advance Payment", "Karyo Loan Recast"),
				_domain_link("Corrections", "Karyo Loan Correction"),
				_domain_link("Settlement", "Karyo Loan Settlement"),
				_domain_link("Interest Changes", "Karyo Loan Interest Change"),
				_domain_link("Insurance Changes", "Karyo Loan Insurance Change"),
				_domain_card("Setup"),
				_domain_link("Loan Types", "Loan Type"),
				_domain_link("Loan Insurance Rates", "Loan Insurance Rate"),
				_domain_link("Eligibility Conditions", "Loan Condition"),
				_domain_link("Operation Codes", "Loan Operation Code"),
				_domain_link("Recomputation Parameters", "Loan Recomputation Parameter"),
				_domain_link("Document Requirements", "Loan Document Requirement"),
				_domain_link("Approval Authorities", "Loan Approval Authority"),
				_domain_link("Loan Committee Master", "Loan Committee"),
				_domain_link("Karyo Settings", "Karyo Settings"),
			],
			"shortcuts": [
				{"type": "Page", "label": "Loan Center", "link_to": "loan-center", "color": "Blue"},
				{"type": "DocType", "label": "Loan Applications", "link_to": "Karyo Loan", "color": "Blue"},
				{"type": "Page", "label": "Loan Inquiry", "link_to": "loan-inquiry", "color": "Grey"},
			],
		},
		"Benefits": {
			"icon": "heart",
			"links": [
				_domain_card("Benefits"),
				_domain_link("Benefits Hub", "pb-overview", "Page"),
				_domain_link("New Benefit Claim / Benefit Claims", "Passage Benefit Application"),
				_domain_link("Benefit Ledger", "Passage Benefit Ledger Entry"),
				_domain_link("Benefit Computations", "Passage Benefit Computation"),
				_domain_link("Benefit Adjustments", "Passage Benefit Adjustment"),
				_domain_card("Setup"),
				_domain_link("Benefit Usage Items", "Passage Benefit Usage Item"),
				_domain_link("Benefit Banks", "Passage Benefit Bank"),
				_domain_link("Benefit Settings", "Passage Benefit Settings"),
				_domain_link("Not Earned Periods", "Passage Benefit Not Earned Period"),
			],
			"shortcuts": [
				{"type": "Page", "label": "Benefits Hub", "link_to": "pb-overview", "color": "Green"},
				{"type": "DocType", "label": "Benefit Claims", "link_to": "Passage Benefit Application", "color": "Green"},
				{"type": "DocType", "label": "Benefit Computations", "link_to": "Passage Benefit Computation", "color": "Grey"},
			],
		},
	}
	for name, spec in domains.items():
		if frappe.db.exists("Workspace", name):
			frappe.delete_doc("Workspace", name, ignore_permissions=True, force=True)
		content = json.dumps([
			{"type": "header", "data": {"text": name, "col": 12}},
			{"type": "card", "data": {"card_name": name, "col": 8}},
			{"type": "card", "data": {"card_name": "Setup", "col": 4}},
		])
		frappe.get_doc({
			"doctype": "Workspace", "name": name, "label": name, "title": name,
			"module": "Karyo", "public": 1, "icon": spec["icon"],
			"content": content, "links": spec["links"], "shortcuts": spec["shortcuts"],
		}).insert(ignore_permissions=True)
		print(f"  + Workspace: {name}")


# Stock workspaces ship with clashing sidebar icons (users/tool/crm/integration
# each appear on 2-3 nav items). Every sidebar item must have a unique icon;
# 'Karyo HRMS' keeps "users". Icon names come from the timeless sprite
# from the active icon sprite. DB values win over the app JSON on
# migrate (sync skips docs whose modified timestamp is newer than the file's),
# but a stock app update bumps the file timestamp and re-imports — run_all_setup
# re-applies these.
SIDEBAR_ICON_OVERRIDES = {
	"Recruitment": "share-people",  # was "users" (clash: Karyo HRMS, Users)
	"Users": "permission",  # was "users"
	"Integrations": "external-link",
	"ERP" + "Next Integrations": "external-link",
	"Build": "customization",  # was "tool" (clash: Tools)
	"Tax & Benefits": "liabilities",  # was "crm" (clash: CRM)
}


def fix_sidebar_icons():
	for workspace, icon in SIDEBAR_ICON_OVERRIDES.items():
		if not frappe.db.exists("Workspace", workspace):
			continue
		if frappe.db.get_value("Workspace", workspace, "icon") != icon:
			frappe.db.set_value("Workspace", workspace, "icon", icon)
			print(f"  + Workspace icon: {workspace} -> {icon}")


def validate_reports():
	from frappe.desk.query_report import run

	for r in REPORTS:
		res = run(r["name"], ignore_prepared_report=True)
		print(f"  OK {r['name']}: {len(res.get('columns', []))} cols, {len(res.get('result', []))} rows")


def setup():
	print("Karyo workspace + reports setup:")
	create_reports()
	create_workspace()
	fix_sidebar_icons()
	frappe.db.commit()
	print("Done.")
