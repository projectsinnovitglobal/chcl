import json

import frappe
from frappe import _
from frappe.utils import flt, getdate


DECISION_STATES = {"Recommended", "Pending", "Approved", "Rejected", "Returned"}


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = {}
	for field in ("loan", "employee", "loan_type"):
		if filters.get(field):
			column = "name" if field == "loan" else field
			conditions[column] = filters.get(field)
	loans = frappe.get_list(
		"Karyo Loan", filters=conditions,
		fields=["name", "employee", "employee_name", "loan_type", "amount_applied", "approved_amount",
			"workflow_state", "is_approval_required", "creation", "owner", "committee_decided_by", "committee_decided_on",
			"committee_remarks", "loan_approved_by", "loan_approved_on", "approval_route", "approval_role",
			"approval_authority_version", "returned_by", "returned_on", "return_reason", "rejection_reason"],
		order_by="creation desc", limit_page_length=0,
	)
	data = []
	for loan in loans:
		versions = frappe.get_all("Version", filters={"ref_doctype": "Karyo Loan", "docname": loan.name}, fields=["owner", "creation", "data"], order_by="creation asc")
		data.extend(_decision_rows(frappe._dict(loan), versions))
	data = [r for r in data if _matches(r, filters)]
	summary = [
		{"label": _("Decisions"), "value": len(data), "indicator": "Blue", "datatype": "Int"},
		{"label": _("Requested"), "value": sum(flt(r.requested_amount) for r in data), "indicator": "Grey", "datatype": "Currency"},
		{"label": _("Approved"), "value": sum(flt(r.approved_amount) for r in data if r.outcome == "Approved"), "indicator": "Green", "datatype": "Currency"},
		{"label": _("Returned / Rejected"), "value": sum(r.outcome in ("Returned", "Rejected") for r in data), "indicator": "Orange", "datatype": "Int"},
	]
	return _columns(), data, None, None, summary


def _decision_rows(loan, versions):
	rows = []
	for version in versions:
		try:
			changes = json.loads(version.data or "{}").get("changed", [])
		except (TypeError, ValueError):
			continue
		values = {change[0]: change[2] for change in changes if len(change) > 2}
		state = values.get("workflow_state")
		if state in DECISION_STATES:
			rows.append(_row(loan, state, version.owner, version.creation, values))
	# Older/imported loans may predate Version tracking; expose their stamped evidence.
	if not rows:
		if loan.committee_decided_on and loan.workflow_state in ("Recommended", "Pending", "Rejected"):
			rows.append(_row(loan, loan.workflow_state, loan.committee_decided_by, loan.committee_decided_on, {}))
		if loan.loan_approved_on:
			rows.append(_row(loan, "Approved", loan.loan_approved_by, loan.loan_approved_on, {}))
		if loan.returned_on:
			rows.append(_row(loan, "Returned", loan.returned_by, loan.returned_on, {}))
	return rows


def _row(loan, outcome, user, decision_on, changes):
	if outcome == "Returned":
		level, role = "Return / Rework", "HR Manager / Loan Committee"
	elif outcome in ("Recommended", "Pending", "Rejected"):
		level, role = "Committee Recommendation", "Karyo Loan Committee"
	else:
		level = changes.get("approval_route") or loan.approval_route or ("Final Approval" if loan.get("is_approval_required") else "Direct Approval")
		role = changes.get("approval_role") or loan.approval_role or "HR Manager"
	remarks = changes.get("return_reason") if outcome == "Returned" else changes.get("rejection_reason") or loan.get("rejection_reason") if outcome == "Rejected" else changes.get("committee_remarks")
	remarks = remarks or (loan.return_reason if outcome == "Returned" else loan.committee_remarks if outcome != "Approved" else "")
	return frappe._dict(loan=loan.name, employee=loan.employee, employee_name=loan.employee_name, loan_type=loan.loan_type,
		requested_amount=loan.amount_applied, approved_amount=loan.approved_amount, outcome=outcome,
		decision_user=user, decision_role=role, approval_level=level, decision_on=decision_on, remarks=remarks,
		authority_version=loan.approval_authority_version)


def _matches(row, filters):
	if filters.outcome and row.outcome != filters.outcome:
		return False
	if filters.approval_level and row.approval_level != filters.approval_level:
		return False
	date = getdate(row.decision_on) if row.decision_on else None
	return not ((filters.from_date and (not date or date < getdate(filters.from_date))) or (filters.to_date and (not date or date > getdate(filters.to_date))))


def _columns():
	def c(fieldname, label, fieldtype="Data", width=120, options=None):
		return {"fieldname": fieldname, "label": _(label), "fieldtype": fieldtype, "width": width, **({"options": options} if options else {})}
	return [c("loan", "Loan", "Link", 145, "Karyo Loan"), c("employee", "Employee", "Link", 125, "Employee"), c("employee_name", "Employee Name", width=160),
		c("loan_type", "Loan Type", "Link", 120, "Loan Type"), c("requested_amount", "Requested", "Currency"), c("approved_amount", "Approved", "Currency"),
		c("outcome", "Outcome", width=100), c("approval_level", "Level / Route", width=160), c("decision_user", "Decision User", "Link", 150, "User"),
		c("decision_role", "Role", width=160), c("decision_on", "Decision Date / Time", "Datetime", 155), c("remarks", "Remarks / Rework Reason", width=220), c("authority_version", "Authority Version", width=110)]
