"""Transactional tests for the employee leave and PB dashboard endpoints."""
import unittest
from uuid import uuid4
from unittest.mock import patch
import frappe
from frappe.utils import nowdate, add_days
from karyo.tests.test_live_menus import TestLiveMenus
from karyo.passage_benefit import ess
from karyo.hr.self_service import leave_applications
from karyo.karyo.doctype.sick_leave_bank.sick_leave_bank import balance_snapshot
from karyo import notify


class TestSickLeaveBankAnalytics(unittest.TestCase):
	@patch("karyo.karyo.doctype.sick_leave_bank.sick_leave_bank.frappe.db.get_single_value", return_value=180)
	@patch("karyo.karyo.doctype.sick_leave_bank.sick_leave_bank.frappe.db.get_value")
	def test_dashboard_snapshot_replaces_stale_counters_with_live_allocation(self, get_value, _settings):
		get_value.return_value = frappe._dict({
			"name": "HR-EMP-TEST", "employee": "HR-EMP-TEST", "status": "Active",
			"allotted_days": 3, "taken_days": 2, "available_days": 1,
			"opening_bank_days": 0, "bank_days": 0,
			"advance_allotted_days": 180, "advance_balance_days": 0,
		})
		snapshot = balance_snapshot("HR-EMP-TEST", balances=[{
			"leave_code": "SICK01", "total": 21, "taken": 2,
			"remaining": 19, "confirmed_remaining": 19,
		}])
		self.assertEqual(snapshot.allotted_days, 21)
		self.assertEqual(snapshot.taken_days, 2)
		self.assertEqual(snapshot.available_days, 19)


class TestLeaveDecisionNotification(unittest.TestCase):
	def test_approval_notifies_the_linked_employee_once(self):
		doc = frappe._dict({
			"doctype": "Leave Application", "name": "LEAVE-TEST-1",
			"employee": "HR-EMP-TEST", "leave_type": "Sick Leave",
			"from_date": "2026-09-29", "to_date": "2026-09-30",
			"status": "Approved", "docstatus": 1,
		})
		doc.get_doc_before_save = lambda: frappe._dict(status="Open", docstatus=0)
		with patch.object(notify, "_quiet", return_value=False), patch.object(notify, "_notify_employee") as delivery:
			notify.leave_application_state(doc, "on_update")
			notify.leave_application_state(doc, "on_submit")
		delivery.assert_called_once()
		self.assertIn("Approved", delivery.call_args.args[1])


class TestLeavePBDashboard(TestLiveMenus):
	def make_pb(self):
		frappe.db.set_value('Employee',self.employee.name,{'pb_eligible':1,'date_of_joining':'1990-01-01','karyo_date_confirmed':'1991-01-01','karyo_permanent_pensionable':1})
		frappe.get_doc({'doctype':'Passage Benefit Bank','employee':self.employee.name,'opening_date':nowdate(),'opening_balance':10000}).insert()
		return frappe.get_doc({'doctype':'Passage Benefit Usage Item','usage_item_code':'UI-'+uuid4().hex[:8],'usage_item_name':'Dashboard test redemption','encash_rate':100,'min_balance_credit':0,'requires_document':0,'is_active':1}).insert().name

	def test_pb_summary_redemption_and_withdrawal_remain_scoped(self):
		item=self.make_pb()
		frappe.set_user(self.email)
		before=ess.get_my_summary()
		self.assertEqual(before['employee'],self.employee.name)
		self.assertEqual(before['bank'].current_balance,10000)
		self.assertEqual(before['pending_redemption_amount'],0)
		with patch('frappe.publish_realtime') as publish:
			request=ess.submit_application(item,500,processing_route='Internal')
			self.assertTrue(any(c.args[0]=='list_update' for c in publish.call_args_list if c.args))
		self.assertEqual(request['workflow_state'],'Pending Approval')
		self.assertEqual(ess.get_application_details(request['name'])['request_amount'],500)
		after=ess.get_my_summary()
		self.assertEqual(after['pending_redemption_amount'],500)
		self.assertEqual(after['bank'].current_balance,10000)
		self.assertEqual([r.name for r in after['applications']],[request['name']])
		other=frappe.db.get_value('Passage Benefit Application',{'employee':['!=',self.employee.name]},'name')
		if other:
			with self.assertRaises(frappe.PermissionError):ess.withdraw_application(other)
			with self.assertRaises(frappe.PermissionError):ess.get_application_details(other)
		ess.withdraw_application(request['name'])
		self.assertEqual(ess.get_my_summary()['pending_redemption_amount'],0)
		with self.assertRaises(frappe.ValidationError):ess.submit_application(item,10001,processing_route='Internal')

	def test_leave_status_filter_is_permission_scoped(self):
		suffix=uuid4().hex[:8]
		# This permission-only fixture intentionally bypasses the governed master
		# contract so leave-rule validation cannot change the access assertion.
		kind=frappe.get_doc({'doctype':'Leave Type','leave_type_name':'Dashboard leave '+suffix,'is_lwp':1,'include_holiday':1}).insert(ignore_mandatory=True)
		doc=frappe.get_doc({'doctype':'Leave Application','employee':self.employee.name,'leave_type':kind.name,'from_date':add_days(nowdate(),2),'to_date':add_days(nowdate(),2),'leave_approver':'Administrator','status':'Open'}).insert()
		frappe.set_user(self.email)
		self.assertEqual([d.name for d in leave_applications('Pending')],[doc.name])
		self.assertEqual(leave_applications('Rejected'),[])
		with self.assertRaises(frappe.ValidationError):leave_applications('arbitrary filter')
		frappe.set_user('Administrator')
		doc.status='Rejected';doc.save();doc.submit()
		frappe.set_user(self.email)
		self.assertEqual(leave_applications('Pending'),[])
		self.assertEqual([d.name for d in leave_applications('Rejected')],[doc.name])
