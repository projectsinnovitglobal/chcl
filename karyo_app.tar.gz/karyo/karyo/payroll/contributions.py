"""Contribution calculation using effective, configured salary bands."""

from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP, Decimal

import frappe
from frappe import _
from frappe.utils import getdate

from karyo.payroll.configuration import assert_production_eligible


def _round(value, precision, method):
	rounding = ROUND_HALF_EVEN if method == "Round Half to Even" else ROUND_HALF_UP
	return value.quantize(Decimal("1").scaleb(-precision), rounding=rounding)


def calculate_contribution(scheme, salary_basis, on_date=None, company=None):
	"""Calculate employee/employer values and return the selected-band trace."""
	doc = frappe.get_doc("Payroll Contribution Scheme", scheme)
	on_date = getdate(on_date)
	basis = Decimal(str(salary_basis or 0))
	if basis < 0:
		frappe.throw(_("Contribution salary basis cannot be negative."))
	if not doc.is_active:
		frappe.throw(_("Contribution Scheme {0} is inactive.").format(scheme))
	if getdate(doc.effective_from) > on_date or (
		doc.effective_to and getdate(doc.effective_to) < on_date
	):
		frappe.throw(_("Contribution Scheme {0} is not effective on {1}.").format(scheme, on_date))
	if company and doc.company and company != doc.company:
		frappe.throw(_("Contribution Scheme belongs to a different company."))
	mode = frappe.db.get_single_value("Karyo Payroll Settings", "environment_mode") or "Demo"
	if mode == "Production":
		assert_production_eligible(doc.configuration_version)

	rows = sorted(doc.bands, key=lambda item: item.lower_salary)
	band = next(
		(
			row
			for row in rows
			if basis >= Decimal(str(row.lower_salary))
			and (row.is_open_ended or basis <= Decimal(str(row.upper_salary)))
		),
		None,
	)
	if not band:
		if basis < Decimal(str(rows[0].lower_salary)):
			# The register starts some contributions above zero (NSF - Contractual
			# begins at Rs 100). A basis below the first band owes nothing; only a
			# hole between configured bands is a configuration error.
			return {
				"scheme": doc.name,
				"salary_basis": float(basis),
				"calculation_mode": doc.calculation_mode,
				"band": None,
				"below_minimum": True,
				"minimum_salary": float(rows[0].lower_salary),
				"employee_basis": float(basis),
				"employer_basis": float(basis),
				"employee_amount": 0.0,
				"employer_amount": 0.0,
				"employee_pdb_code": doc.employee_pdb_code,
				"employer_salary_component": doc.employer_salary_component,
			}
		frappe.throw(_("No contribution band covers salary basis {0}.").format(basis))

	employee_basis = min(basis, Decimal(str(doc.employee_ceiling))) if doc.employee_ceiling else basis
	employer_basis = min(basis, Decimal(str(doc.employer_ceiling))) if doc.employer_ceiling else basis
	if doc.calculation_mode == "Percentage":
		employee_raw = employee_basis * Decimal(str(band.employee_value)) / Decimal("100")
		employer_raw = employer_basis * Decimal(str(band.employer_value)) / Decimal("100")
	else:
		employee_raw = Decimal(str(band.employee_value))
		employer_raw = Decimal(str(band.employer_value))
	precision = int(doc.rounding_precision)
	employee_amount = _round(employee_raw, precision, doc.rounding_method)
	employer_amount = _round(employer_raw, precision, doc.rounding_method)
	return {
		"scheme": doc.name,
		"salary_basis": float(basis),
		"calculation_mode": doc.calculation_mode,
		"below_minimum": False,
		"band": {
			"lower_salary": band.lower_salary,
			"upper_salary": None if band.is_open_ended else band.upper_salary,
			"employee_value": band.employee_value,
			"employer_value": band.employer_value,
		},
		"employee_basis": float(employee_basis),
		"employer_basis": float(employer_basis),
		"employee_amount": float(employee_amount),
		"employer_amount": float(employer_amount),
		"employee_pdb_code": doc.employee_pdb_code,
		"employer_salary_component": doc.employer_salary_component,
	}
