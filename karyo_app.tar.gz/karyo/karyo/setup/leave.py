"""PRB Sick Leave Bank DocTypes (SLB-*): a per-employee bank master + a
submittable year-end posting that credits/refunds and updates the bank.

    bench --site dev.localhost execute karyo.setup.leave.setup
"""

import re

import frappe
from frappe import _
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.custom.doctype.property_setter.property_setter import make_property_setter
from frappe.utils import cint, flt, getdate, nowdate

from karyo.setup.foundation import f, make_doctype


# name, group, code, description, YOS, vacation, PB, paid, Sat, Sun, PH
LEAVE_TYPE_MATRIX = [
	("Annual Leave", "ANN", "ANN", "Annual Leave", 1, 1, 0, 1, 1, 1, 1),
	("Annual Leave on No Pay", "ANN", "ANN01", "Annual Leave on No Pay", 0, 0, 0, 0, 1, 1, 1),
	("Casual Leave", "CASL", "CASL01", "Casual Leave", 1, 1, 1, 1, 1, 1, 1),
	("Casual on No Pay", "CASL", "CASL02", "Casual on No Pay", 0, 0, 0, 0, 1, 1, 1),
	("Injury Leave", "INJ", "INJ", "Injury Leave", 1, 0, 0, 1, 1, 1, 1),
	("Injury Above Normal Entitlement", "INJ", "INJ1", "Injury Above Normal Entitlement", 1, 0, 0, 1, 1, 1, 1),
	("Interdiction", "INT", "INT", "Interdiction", 0, 0, 0, 1, 1, 1, 1),
	("Study Leave Without Pay", "LWP", "LWP01", "Study Leave Without Pay", 0, 0, 0, 0, 1, 1, 1),
	("Leave Without Pay", "LWP", "LWP02", "Leave Without Pay", 0, 0, 0, 0, 1, 1, 1),
	("Sick Leave Without Pay", "LWP", "LWP03", "Sick Leave Without Pay", 0, 0, 0, 0, 1, 1, 1),
	("Suspension From Work", "LWP", "LWP04", "Suspension From Work", 0, 0, 0, 0, 1, 1, 1),
	("Maternity Leave", "MAT", "MAT", "Maternity Leave", 1, 0, 0, 1, 1, 1, 1),
	("Mission Overseas", "OVER", "MISION", "Mission Overseas", 1, 1, 1, 1, 1, 1, 1),
	("Training Overseas", "OVER", "TRN", "Training Overseas", 1, 1, 1, 1, 1, 1, 1),
	("Sick Leave", "SICK", "SICK01", "Normal Sick Entitlement", 1, 1, 1, 1, 1, 1, 1),
	("Sick From Bank", "SICK", "SICK02", "Sick From Bank", 1, 0, 0, 1, 1, 1, 1),
	("Advance Sick Leave Full Pay", "SICK", "SICK03", "Advance Sick Leave Full Pay", 1, 0, 0, 1, 1, 1, 1),
	("Advance Sick Leave Half Pay", "SICK", "SICK04", "Advance Sick Leave Half Pay", 1, 0, 0, 1, 1, 1, 1),
	("Pre-Retirement Sick Leave", "SICK", "SICK05", "Sick Leave Bank (Pre-Retirement Leave)", 1, 0, 0, 1, 1, 1, 1),
	("Sick Leave on No Pay", "SICK", "SICK06", "Sick Leave on No Pay", 0, 0, 0, 0, 1, 1, 1),
	("Sick on Roster", "SICK", "SICK07", "Sick on Roster", 0, 0, 0, 1, 1, 1, 1),
	("Absent", "SPE", "ABS", "Absent", 0, 0, 0, 0, 1, 1, 1),
	("Adoption Leave", "SPE", "ADOPT", "Adoption Leave", 1, 0, 0, 1, 1, 1, 1),
	("Isolation Period", "SPE", "COVID", "Isolation Period", 1, 1, 1, 1, 1, 1, 1),
	("Special Leave for Revision", "SPE", "EXAMS", "Special Leave for Revision", 1, 1, 1, 1, 1, 1, 1),
	("Special Leave Upon Delivery of Twins", "SPE", "MAT2", "Special Leave Upon Delivery of Twins", 1, 0, 0, 1, 1, 1, 1),
	("School Leave", "SPE", "SCHOOL", "School Leave", 1, 0, 1, 1, 1, 1, 1),
	("Special Leave", "SPE", "SPCIAL", "Special Leave", 1, 1, 1, 1, 1, 1, 1),
	("Unauthorised Leave", "SPE", "UNAU", "Unauthorised Leave", 0, 0, 0, 0, 1, 1, 1),
	("Vaccination Leave", "SPE", "VACC", "Vaccination Leave", 1, 1, 1, 1, 1, 1, 1),
	("Study Leave", "STD", "STD", "Study Leave", 0, 0, 0, 1, 1, 1, 1),
	("Vacation Leave", "VAC", "VAC01", "Vacation Leave", 1, 0, 0, 1, 1, 1, 1),
	("Casual Against Vacation", "VAC", "VAC02", "Casual Against Vacation", 1, 0, 0, 1, 1, 1, 1),
	("Vacation Leave as Casual (Exceptional)", "VAC", "VAC03", "Vacation Leave as Casual (Exceptional Basis)", 1, 0, 0, 1, 0, 0, 0),
	("Vacation as Pre-Retirement Leave", "VAC", "VAC04", "Vacation as Pre-Retirement Leave", 1, 0, 0, 1, 1, 1, 1),
	("Family Responsibility / Bereavement Leave", "VAC", "VAC05", "Vacation in Case of Demise / Family Responsibility", 1, 0, 0, 1, 1, 1, 1),
	# The validation pack identifies Paternity as a missing MBC configuration but
	# supplies no legacy code. PAT is the governed target-system code.
	("Paternity Leave", "SPE", "PAT", "Paternity Leave", 1, 0, 0, 1, 1, 1, 1),
]


RULE_DETAILS = {
	"ANN": dict(annual=21, bank="Annual Allocation"),
	"CASL01": dict(annual=11, bank="Annual Allocation", min_service=12, categories="PERM"),
	"SICK01": dict(annual=21, bank="Annual Allocation", medical_after=3, attachment=1, ceiling=110, refund_cap=16, refund_divisor=22),
	"SICK02": dict(bank="Sick Leave Bank", prerequisites="SICK01", ceiling=110),
	"SICK03": dict(bank="Sick Leave Bank", prerequisites="SICK01,SICK02", max_total=180, recovery=14),
	"SICK04": dict(bank="Sick Leave Bank", prerequisites="SICK01,SICK02,SICK03", max_total=180, recovery=14),
	"SICK05": dict(bank="Sick Leave Bank"),
	"MAT": dict(annual=112, bank="Annual Allocation", max_application=112, gender="Female"),
	"PAT": dict(bank="None", max_application=10, max_year=10, gender="Male", categories="PERM"),
	"INJ": dict(max_year=30, max_application=30),
	"STD": dict(max_year=15, max_application=15),
	"VAC01": dict(bank="Vacation Leave Bank"),
	"VAC02": dict(bank="Vacation Leave Bank", prerequisites="CASL01", max_year=5, max_application=5, deduct_code="VAC01"),
	"VAC03": dict(bank="Vacation Leave Bank", prerequisites="CASL01", max_year=5, max_application=5, deduct_code="VAC01"),
	"VAC04": dict(bank="Vacation Leave Bank", deduct_code="VAC01"),
	"VAC05": dict(bank="Vacation Leave Bank", max_year=5, max_application=5, deduct_code="VAC01"),
}


LEAVE_CATEGORIES = [
	("Casual Leave", "Casual leave entitlements and requests"),
	("Vacation Leave", "Vacation and annual leave"),
	("Bank Leave / Sick Leave Bank", "Leave available from the sick leave bank"),
	("Sick / Advance Sick Leave", "Normal and advance sick leave"),
	("Leave Without Pay", "Unpaid leave and payroll deduction"),
	(
		"Injury / Maternity / Paternity / Adoption / Study Leave",
		"Statutory, family, injury and study leave",
	),
]


def create_leave_parameter_doctypes():
	make_doctype(
		"MBC Vacation Leave Band",
		istable=1,
		fields=[
			f("service_from_years", "Float", "Service From (years)", reqd=1, in_list_view=1),
			f("service_to_years", "Float", "Service To (years)", in_list_view=1),
			f("annual_entitlement_days", "Float", "Annual Entitlement (days)", reqd=1, in_list_view=1),
			f("accumulation_ceiling_days", "Float", "Accumulation Ceiling (days)", reqd=1, in_list_view=1),
		],
	)
	make_doctype(
		"MBC Leave Settings",
		issingle=1,
		fields=[
			f("general_sb", "Section Break", "General Leave Parameters"),
			f("annual_leave_entitlement", "Float", "Annual Leave Annual Entitlement", default="21"),
			f("casual_annual_entitlement", "Float", "Casual Leave Annual Entitlement", default="11"),
			f("sick_annual_entitlement", "Float", "Sick Leave Annual Entitlement", default="21"),
			f("standard_day_hours", "Float", "Standard Working Day (hours)", default="8"),
			f("cb", "Column Break"),
			f("sick_bank_ceiling", "Float", "Sick Leave Bank Ceiling", default="110"),
			f("sick_refund_cap", "Float", "Maximum Sick Leave Refund", default="16"),
			f("leave_refund_divisor", "Float", "Leave Refund Salary Divisor", default="22"),
			f("advance_sick_recovery_days", "Float", "Advance Sick Annual Recovery", default="14"),
			f("limits_sb", "Section Break", "Provisioned Limits"),
			f("advance_sick_full_pay_limit", "Float", "Advance Sick Full Pay Limit", default="180"),
			f("advance_sick_half_pay_limit", "Float", "Advance Sick Half Pay Limit", default="180"),
			f("vacation_as_casual_limit", "Float", "Vacation as Casual Limit", default="5"),
			f("injury_leave_limit", "Float", "Injury Leave Limit", default="30"),
			f("limits_cb", "Column Break"),
			f("maternity_leave_limit", "Float", "Maternity Leave Limit", default="112"),
			f("paternity_leave_limit", "Float", "Paternity Leave Limit", default="10"),
			f("study_leave_limit", "Float", "Study Leave Limit", default="15"),
			f("family_responsibility_limit", "Float", "Family Responsibility / Bereavement Limit", default="5"),
			f("lateness_sb", "Section Break", "Lateness to Leave — MBC-LV-CAS-004", collapsible=1),
			f("enable_lateness_leave_deduction", "Check", "Enable Lateness Leave Deduction", default="1"),
			f("lateness_divisor_source", "Select", "Working-day Divisor Source", options="Scheduled Shift", default="Scheduled Shift", read_only=1),
			f("lateness_fixed_working_minutes", "Float", "Fixed Working Minutes / Day"),
			f("lateness_accumulation_period", "Select", "Accumulation Period", options="Payroll Period", default="Payroll Period", read_only=1),
			f("lateness_cb", "Column Break"),
			f("lateness_minimum_minutes", "Float", "Minimum Deduction (minutes)", default="120", read_only=1),
			f("lateness_rounding_mode", "Select", "Rounding Rule", options="Up", default="Up", read_only=1),
			f("lateness_rounding_increment_days", "Float", "Rounding Increment (days)", default="0.5", read_only=1),
			f("lateness_approval_workflow", "Select", "Posting Workflow", options="Leave Approver Submits Deduction", default="Leave Approver Submits Deduction", read_only=1),
			f("lateness_policy_approval_reference", "Data", "Policy Approval Reference", default="MBC confirmation 2026-09-24", read_only=1),
			f("vacation_sb", "Section Break", "Vacation Leave Service Bands"),
			f("vacation_leave_bands", "Table", "Vacation Leave Bands", options="MBC Vacation Leave Band"),
			f("effective_from", "Date", "Effective From", default="2026-01-01", reqd=1),
			f("approval_reference", "Data", "Approval / Decision Reference"),
		],
	)


def create_doctypes():
	make_doctype(
		"Employee Leave Scheme Selection",
		istable=1,
		fields=[
			f("leave_scheme", "Link", "Leave Scheme", options="Leave Policy", reqd=1, in_list_view=1),
			f(
				"selection_source", "Select", "Selection Source",
				options="Manual\nConditional", default="Manual", read_only=1, in_list_view=1,
			),
			f("condition", "Data", "Applied Condition", read_only=1, in_list_view=1),
			f("is_active", "Check", "Active", default="1", in_list_view=1),
		],
	)
	create_custom_fields(
		{
			"MBC Leave Settings": [
				{"fieldname": "annual_leave_entitlement", "fieldtype": "Float", "label": "Annual Leave Annual Entitlement", "default": "21", "insert_after": "general_sb"},
				{"fieldname": "effective_from", "fieldtype": "Date", "label": "Effective From", "default": "2026-01-01", "reqd": 1, "insert_after": "vacation_leave_bands"},
				{"fieldname": "approval_reference", "fieldtype": "Data", "label": "Approval / Decision Reference", "insert_after": "effective_from"},
			],
			"Leave Type": [
				{"fieldname": "karyo_mbc_rules_sb", "fieldtype": "Section Break", "label": "Leave Identity and Rules", "insert_after": "leave_type_name", "collapsible": 0},
				{"fieldname": "karyo_is_retired", "fieldtype": "Check", "label": "Retired / Hidden", "default": "0", "insert_after": "karyo_mbc_rules_sb"},
				{"fieldname": "karyo_mbc_leave_code", "fieldtype": "Data", "label": "Leave Code", "insert_after": "karyo_is_retired", "unique": 1, "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
				{"fieldname": "karyo_code_description", "fieldtype": "Data", "label": "Leave Description", "insert_after": "karyo_mbc_leave_code", "reqd": 1, "in_list_view": 1},
				{"fieldname": "karyo_mbc_leave_group", "fieldtype": "Data", "label": "Leave Group", "insert_after": "karyo_code_description"},
				{"fieldname": "karyo_bank_type", "fieldtype": "Select", "label": "Balance Source", "options": "None\nAnnual Allocation\nSick Leave Bank\nVacation Leave Bank", "default": "None", "insert_after": "karyo_code_description"},
				{"fieldname": "karyo_requires_leave_bank", "fieldtype": "Check", "label": "Requires Leave Bank / Allocation", "insert_after": "karyo_bank_type"},
				{"fieldname": "karyo_min_service_months", "fieldtype": "Int", "label": "Minimum Service (months)", "insert_after": "karyo_requires_leave_bank"},
				{"fieldname": "karyo_eligible_employment_categories", "fieldtype": "Data", "label": "Eligible Employment Categories", "description": "Comma-separated Employee employment categories; blank permits all.", "insert_after": "karyo_min_service_months"},
				{"fieldname": "karyo_eligible_gender", "fieldtype": "Select", "label": "Eligible Gender", "options": "\nMale\nFemale", "insert_after": "karyo_eligible_employment_categories"},
				{"fieldname": "karyo_requires_valid_contract", "fieldtype": "Check", "label": "Requires Valid Contract", "insert_after": "karyo_eligible_gender"},
				{"fieldname": "karyo_mbc_rules_cb", "fieldtype": "Column Break", "insert_after": "karyo_requires_valid_contract"},
				{"fieldname": "karyo_max_days_per_application", "fieldtype": "Float", "label": "Maximum Days per Application", "insert_after": "karyo_mbc_rules_cb"},
				{"fieldname": "karyo_max_days_per_year", "fieldtype": "Float", "label": "Maximum Days per Calendar Year", "insert_after": "karyo_max_days_per_application"},
				{"fieldname": "karyo_max_days_total", "fieldtype": "Float", "label": "Maximum Days Overall", "insert_after": "karyo_max_days_per_year"},
				{"fieldname": "karyo_medical_certificate_after_days", "fieldtype": "Float", "label": "Medical Certificate Required After (days)", "insert_after": "karyo_max_days_total"},
				{"fieldname": "karyo_requires_attachment", "fieldtype": "Check", "label": "Attachment Required", "insert_after": "karyo_medical_certificate_after_days"},
				{"fieldname": "karyo_prerequisite_codes", "fieldtype": "Data", "label": "Prerequisite Leave Codes", "description": "Codes that must be exhausted first, in order.", "insert_after": "karyo_requires_attachment"},
				{"fieldname": "karyo_deducts_from_leave_type", "fieldtype": "Link", "label": "Deduct Balance From", "options": "Leave Type", "insert_after": "karyo_prerequisite_codes"},
				{"fieldname": "karyo_matrix_sb", "fieldtype": "Section Break", "label": "MBC Leave Impact Matrix", "insert_after": "karyo_deducts_from_leave_type", "collapsible": 1},
				{"fieldname": "karyo_yos_earned", "fieldtype": "Check", "label": "Years of Service Earned", "insert_after": "karyo_matrix_sb"},
				{"fieldname": "karyo_vacation_earned", "fieldtype": "Check", "label": "Vacation Leave Earned", "insert_after": "karyo_yos_earned"},
				{"fieldname": "karyo_pb_earned", "fieldtype": "Check", "label": "Passage Benefit Earned", "insert_after": "karyo_vacation_earned"},
				{"fieldname": "karyo_paid", "fieldtype": "Check", "label": "Paid Leave", "insert_after": "karyo_pb_earned"},
				{"fieldname": "karyo_matrix_cb", "fieldtype": "Column Break", "insert_after": "karyo_paid"},
				{"fieldname": "karyo_include_saturday", "fieldtype": "Check", "label": "Saturday Included", "insert_after": "karyo_matrix_cb"},
				{"fieldname": "karyo_include_sunday", "fieldtype": "Check", "label": "Sunday Included", "insert_after": "karyo_include_saturday"},
				{"fieldname": "karyo_include_public_holiday", "fieldtype": "Check", "label": "Public Holiday Included", "insert_after": "karyo_include_sunday"},
				{"fieldname": "karyo_entitlement_sb", "fieldtype": "Section Break", "label": "Entitlement, Bank and Refund", "insert_after": "karyo_include_public_holiday", "collapsible": 1},
				{"fieldname": "karyo_annual_entitlement_days", "fieldtype": "Float", "label": "Annual Entitlement (days)", "insert_after": "karyo_entitlement_sb"},
				{"fieldname": "karyo_bank_ceiling_days", "fieldtype": "Float", "label": "Bank Ceiling (days)", "insert_after": "karyo_annual_entitlement_days"},
				{"fieldname": "karyo_refund_cap_days", "fieldtype": "Float", "label": "Refund Cap (days)", "insert_after": "karyo_bank_ceiling_days"},
				{"fieldname": "karyo_entitlement_cb", "fieldtype": "Column Break", "insert_after": "karyo_refund_cap_days"},
				{"fieldname": "karyo_refund_divisor", "fieldtype": "Float", "label": "Refund Salary Divisor", "insert_after": "karyo_entitlement_cb"},
				{"fieldname": "karyo_advance_recovery_days", "fieldtype": "Float", "label": "Advance Recovery per Year", "insert_after": "karyo_refund_divisor"},
				{"fieldname": "karyo_affects_yos", "fieldtype": "Check", "label": "Affects Years of Service", "insert_after": "karyo_advance_recovery_days"},
				{"fieldname": "karyo_pb_not_earned", "fieldtype": "Check", "label": "Passage Benefit Not Earned", "insert_after": "karyo_affects_yos"},
				{"fieldname": "karyo_vacation_not_earned", "fieldtype": "Check", "label": "Vacation Leave Not Earned", "insert_after": "karyo_pb_not_earned"},
			],
			"Leave Application": [
				{"fieldname": "karyo_leave_code", "fieldtype": "Data", "label": "Leave Code", "fetch_from": "leave_type.karyo_mbc_leave_code", "read_only": 1, "insert_after": "leave_type"},
				{"fieldname": "karyo_leave_description", "fieldtype": "Data", "label": "Leave Description", "fetch_from": "leave_type.karyo_code_description", "read_only": 1, "insert_after": "karyo_leave_code"},
				{"fieldname": "karyo_payroll_rules_sb", "fieldtype": "Section Break", "label": "Leave and Payroll Rules", "collapsible": 1, "insert_after": "karyo_leave_description"},
				{"fieldname": "karyo_paid_leave", "fieldtype": "Check", "label": "Paid Leave", "fetch_from": "leave_type.karyo_paid", "read_only": 1, "insert_after": "karyo_payroll_rules_sb"},
				{"fieldname": "karyo_unpaid_leave", "fieldtype": "Check", "label": "Payroll Deduction (Unpaid Leave)", "fetch_from": "leave_type.is_lwp", "read_only": 1, "insert_after": "karyo_paid_leave"},
				{"fieldname": "karyo_partially_paid_leave", "fieldtype": "Check", "label": "Partially Paid Leave", "fetch_from": "leave_type.is_ppl", "read_only": 1, "insert_after": "karyo_unpaid_leave"},
				{"fieldname": "karyo_paid_salary_fraction", "fieldtype": "Float", "label": "Paid Salary Fraction", "fetch_from": "leave_type.fraction_of_daily_salary_per_leave", "read_only": 1, "insert_after": "karyo_partially_paid_leave"},
				{"fieldname": "karyo_payroll_rules_cb", "fieldtype": "Column Break", "insert_after": "karyo_paid_salary_fraction"},
				{"fieldname": "karyo_allow_encashment", "fieldtype": "Check", "label": "Encashment Allowed", "fetch_from": "leave_type.allow_encashment", "read_only": 1, "insert_after": "karyo_payroll_rules_cb"},
				{"fieldname": "karyo_payroll_component", "fieldtype": "Link", "label": "Payroll Earning Component", "options": "Salary Component", "fetch_from": "leave_type.earning_component", "read_only": 1, "insert_after": "karyo_allow_encashment"},
				{"fieldname": "karyo_payroll_impact", "fieldtype": "Check", "label": "Affects Payroll", "read_only": 1, "insert_after": "karyo_payroll_component"},
				{"fieldname": "karyo_balance_source", "fieldtype": "Data", "label": "Balance Source", "fetch_from": "leave_type.karyo_bank_type", "read_only": 1, "insert_after": "karyo_payroll_impact"},
				{"fieldname": "karyo_attachment_required", "fieldtype": "Check", "label": "Attachment Required", "fetch_from": "leave_type.karyo_requires_attachment", "read_only": 1, "insert_after": "karyo_balance_source"},
				{
					"fieldname": "karyo_source_channel",
					"fieldtype": "Select",
					"label": "Source Channel",
					"options": "HR\nRegistry\nSupervisor\nEmployee Self Service\nImport",
					"default": "HR",
					"insert_after": "karyo_leave_description",
				},
				{"fieldname": "karyo_leave_unit", "fieldtype": "Select", "label": "Leave Unit", "options": "Days\nHours", "default": "Days", "reqd": 1, "insert_after": "karyo_source_channel"},
				{"fieldname": "karyo_two_hour_permission", "fieldtype": "Check", "label": "2-Hour Permission", "depends_on": "eval:doc.karyo_leave_code==='CASL01'", "description": "Records Casual Leave as a two-hour permission.", "insert_after": "karyo_leave_unit"},
				{"fieldname": "karyo_requested_hours", "fieldtype": "Float", "label": "Requested Hours", "depends_on": "eval:doc.karyo_leave_unit==='Hours'", "mandatory_depends_on": "eval:doc.karyo_leave_unit==='Hours'", "insert_after": "karyo_two_hour_permission"},
				{"fieldname": "karyo_standard_day_hours", "fieldtype": "Float", "label": "Standard Daily Working Hours", "read_only": 1, "depends_on": "eval:doc.karyo_leave_unit==='Hours'", "insert_after": "karyo_requested_hours"},
				{"fieldname": "karyo_converted_leave_days", "fieldtype": "Float", "label": "Equivalent Leave Duration (days)", "read_only": 1, "precision": "6", "depends_on": "eval:doc.karyo_leave_unit==='Hours'", "insert_after": "karyo_standard_day_hours"},
				{"fieldname": "karyo_half_day_period", "fieldtype": "Select", "label": "Half Day Period", "options": "\nAM\nPM", "depends_on": "half_day", "mandatory_depends_on": "half_day", "insert_after": "half_day_date"},
				{
					"fieldname": "karyo_replaces_leave_application",
					"fieldtype": "Link",
					"label": "Replaces Cancelled Leave Application",
					"options": "Leave Application",
					"insert_after": "karyo_source_channel",
				},
				{
					"fieldname": "karyo_correction_reason",
					"fieldtype": "Small Text",
					"label": "Correction Reason",
					"insert_after": "karyo_replaces_leave_application",
				},
				{
					"fieldname": "karyo_cancellation_approval_reference",
					"fieldtype": "Data",
					"label": "Closed-period Cancellation Approval",
					"insert_after": "karyo_correction_reason",
				},
				{"fieldname": "karyo_cancellation_reason", "fieldtype": "Small Text", "label": "Cancellation Reason", "allow_on_submit": 1, "insert_after": "karyo_cancellation_approval_reference"},
			],
			"Leave Allocation": [
				{
					"fieldname": "karyo_opening_balance_days", "fieldtype": "Float",
					"label": "Opening Balance (days)", "read_only": 1, "allow_on_submit": 1,
					"insert_after": "new_leaves_allocated",
				},
				{
					"fieldname": "karyo_opening_balance_reference", "fieldtype": "Link",
					"label": "Opening Balance Reference", "options": "Leave Opening Balance",
					"read_only": 1, "allow_on_submit": 1,
					"insert_after": "karyo_opening_balance_days",
				},
			],
			"Attendance": [
				{"fieldname": "karyo_lateness_sb", "fieldtype": "Section Break", "label": "Approved Lateness and Leave Deduction", "collapsible": 1, "insert_after": "early_exit"},
				{"fieldname": "karyo_detected_late_minutes", "fieldtype": "Float", "label": "Chargeable Late / Early Minutes", "read_only": 1, "insert_after": "karyo_lateness_sb"},
				{"fieldname": "karyo_detected_late_entry_minutes", "fieldtype": "Float", "label": "Late Entry Minutes after Grace", "read_only": 1, "insert_after": "karyo_detected_late_minutes"},
				{"fieldname": "karyo_detected_early_exit_minutes", "fieldtype": "Float", "label": "Early Exit Minutes after Grace", "read_only": 1, "insert_after": "karyo_detected_late_entry_minutes"},
				{"fieldname": "karyo_late_entry_grace_minutes", "fieldtype": "Float", "label": "Late Entry Grace Applied", "read_only": 1, "insert_after": "karyo_detected_early_exit_minutes"},
				{"fieldname": "karyo_early_exit_grace_minutes", "fieldtype": "Float", "label": "Early Exit Grace Applied", "read_only": 1, "insert_after": "karyo_late_entry_grace_minutes"},
				{"fieldname": "karyo_scheduled_working_minutes", "fieldtype": "Float", "label": "Scheduled Working Minutes", "read_only": 1, "insert_after": "karyo_early_exit_grace_minutes"},
				{"fieldname": "karyo_approved_late_minutes", "fieldtype": "Float", "label": "Approved Late Minutes", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_scheduled_working_minutes"},
				{"fieldname": "karyo_lateness_status", "fieldtype": "Select", "label": "Lateness Status", "options": "\nPending Approval\nApproved\nDeducted\nReversed", "read_only": 1, "allow_on_submit": 1, "in_list_view": 1, "insert_after": "karyo_approved_late_minutes"},
				{"fieldname": "karyo_lateness_cb", "fieldtype": "Column Break", "insert_after": "karyo_lateness_status"},
				{"fieldname": "karyo_lateness_approval_reference", "fieldtype": "Data", "label": "Lateness Approval Reference", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_lateness_cb"},
				{"fieldname": "karyo_lateness_approved_by", "fieldtype": "Link", "label": "Lateness Approved By", "options": "User", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_lateness_approval_reference"},
				{"fieldname": "karyo_lateness_approved_on", "fieldtype": "Datetime", "label": "Lateness Approved On", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_lateness_approved_by"},
				{"fieldname": "karyo_lateness_deduction", "fieldtype": "Link", "label": "Lateness Leave Deduction", "options": "Lateness Leave Deduction", "read_only": 1, "allow_on_submit": 1, "insert_after": "karyo_lateness_approved_on"},
			],
			"Employee": [
				{
					"fieldname": "karyo_leave_schemes", "fieldtype": "Table",
					"label": "Leave Schemes", "options": "Employee Leave Scheme Selection",
					"insert_after": "karyo_leave_scheme",
					"description": "Add more than one scheme. Conditional rows are selected and refreshed from employee attributes.",
				},
			],
			"Leave Encashment": [
				{
					"fieldname": "karyo_encashment_rate_per_day", "fieldtype": "Currency",
					"label": "Encashment Rate per Day", "options": "currency", "read_only": 1,
					"insert_after": "encashment_days",
				},
				{
					"fieldname": "karyo_earning_component", "fieldtype": "Link",
					"label": "Payroll Earning Component", "options": "Salary Component",
					"fetch_from": "leave_type.earning_component", "read_only": 1,
					"insert_after": "additional_salary",
				},
				{
					"fieldname": "karyo_payroll_cycle", "fieldtype": "Link",
					"label": "Payroll Cycle", "options": "Payroll Cycle", "read_only": 1,
					"insert_after": "karyo_earning_component",
				},
			],
		},
		ignore_validate=True,
	)
	make_doctype(
		"Sick Leave Bank",
		autoname="field:employee",
		naming_rule="By fieldname",
		title_field="employee_name",
		fields=[
			f("employee", "Link", "Employee Code", options="Employee", reqd=1, unique=1, in_list_view=1),
			f(
				"employee_name",
				"Data",
				"Employee Name",
				fetch_from="employee.employee_name",
				read_only=1,
				in_list_view=1,
			),
			f("status", "Select", "Status", options="Active\nInactive", default="Active"),
			f("allotted_days", "Float", "Allotted", read_only=1, in_list_view=1),
			f("taken_days", "Float", "Taken", read_only=1, in_list_view=1),
			f("available_days", "Float", "Available", read_only=1, in_list_view=1),
			f("cb", "Column Break"),
			f("opening_bank_days", "Int", "Opening Bank (days)"),
			f("bank_days", "Int", "Bank Balance (days)", read_only=1),
			f("advance_allotted_days", "Float", "Advance Sick Allotment (days)", default="180", read_only=1),
			f("advance_balance_days", "Int", "Advance Sick Outstanding (days)"),
		],
	)
	make_doctype(
		"Sick Leave Bank Posting",
		is_submittable=1,
		autoname="naming_series:",
		fields=[
			f(
				"naming_series",
				"Select",
				"Series",
				options="SLBP-.YYYY.-.#####",
				default="SLBP-.YYYY.-.#####",
			),
			f("employee", "Link", "Employee", options="Employee", reqd=1, in_list_view=1),
			f("sick_leave_bank", "Link", "Sick Leave Bank", options="Sick Leave Bank"),
			f("year", "Int", "Year", reqd=1, in_list_view=1),
			f("hcb", "Column Break"),
			f("annual_entitlement_days", "Int", "Annual Entitlement (days)", default="21"),
			f("sick_leave_taken_days", "Int", "Sick Leave Taken (days)", reqd=1),
			f("monthly_salary", "Currency", "Monthly Salary", reqd=1),
			f("open_sb", "Section Break", "Opening"),
			f("opening_bank_days", "Int", "Opening Bank (days)", read_only=1),
			f("opening_advance_days", "Int", "Opening Advance (days)", read_only=1),
			f("res_sb", "Section Break", "Result"),
			f("unused_days", "Int", "Unused Days", read_only=1),
			f("advance_offset_days", "Int", "Advance Offset (days)", read_only=1),
			f("bank_credit_days", "Int", "Bank Credit (days)", read_only=1),
			f("rcb", "Column Break"),
			f("refund_days", "Int", "Refund Days", read_only=1),
			f("refund_amount", "Currency", "Refund Amount", read_only=1, in_list_view=1),
			f("new_advance_balance", "Int", "New Advance Balance (days)", read_only=1),
			f("closing_bank_days", "Int", "Closing Bank (days)", read_only=1, in_list_view=1),
		],
	)
	make_doctype(
		"Leave Balance",
		autoname="naming_series:",
		title_field="employee",
		fields=[
			f("naming_series", "Select", "Series", options="LB-.YYYY.-.#####", default="LB-.YYYY.-.#####", hidden=1),
			f("employee", "Link", "Employee Code", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1),
			f("leave_year", "Int", "Leave Year", reqd=1, in_list_view=1),
			f("leave_code", "Autocomplete", "Leave Code", reqd=1, in_list_view=1),
			f("leave_type", "Data", "Leave Type / Category", read_only=1),
			f("leave_description", "Data", "Leave Description", read_only=1),
			f("closing_balance", "Float", "Closing Balance", reqd=1, in_list_view=1),
			f("as_at_date", "Date", "As At Date", reqd=1, in_list_view=1),
			f("advance_sick_outstanding_days", "Float", "Advance Sick Outstanding Days"),
			f("advance_sick_recovery_required", "Check", "Advance Sick Recovery Required?"),
			f("is_system_synced", "Check", "System Synced", read_only=1, hidden=1),
		],
	)
	make_doctype(
		"Leave Opening Balance",
		is_submittable=1,
		autoname="naming_series:",
		title_field="employee_name",
		fields=[
			f("naming_series", "Select", "Series", options="LOB-.YYYY.-.#####", default="LOB-.YYYY.-.#####", hidden=1),
			f("employee", "Link", "Employee Code", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1, in_list_view=1),
			f("leave_type", "Link", "Leave Type / Category", options="Leave Type", reqd=1, in_list_view=1),
			f("karyo_leave_code", "Data", "Leave Code", fetch_from="leave_type.karyo_mbc_leave_code", read_only=1, in_list_view=1),
			f("karyo_leave_description", "Data", "Leave Description", fetch_from="leave_type.karyo_code_description", read_only=1),
			f("balance_days", "Float", "Opening Balance (days)", reqd=1, in_list_view=1),
			f("balance_as_at_date", "Date", "Balance As At / Cut-off Date", reqd=1, in_list_view=1),
			f("allocation_to_date", "Date", "Available Until", reqd=1),
			f("source_sb", "Section Break", "Source and Approval"),
			f(
				"source_type", "Select", "Opening Balance Source", reqd=1, in_list_view=1,
				options="Transfer from Ministry / Organisation\nExisting System Migration\nManual Initialisation",
			),
			f("source_organisation", "Data", "Source Ministry / Organisation"),
			f("source_reference", "Data", "Approval / Migration Reference", reqd=1),
			f("remarks", "Small Text", "Remarks"),
			f("posting_sb", "Section Break", "System Posting", collapsible=1),
			f("balance_source", "Data", "Mapped Balance Source", read_only=1),
			f("operational_doctype", "Link", "Posted To", options="DocType", read_only=1),
			f("operational_record", "Dynamic Link", "Operational Record", options="operational_doctype", read_only=1),
			f("prior_opening_balance", "Float", "Previous Opening Balance", read_only=1, hidden=1),
			f("prior_current_balance", "Float", "Previous Current Balance", read_only=1, hidden=1),
			f("allocation_created", "Check", "Allocation Created by this Record", read_only=1, hidden=1),
		],
	)
	make_doctype(
		"Leave Transaction",
		autoname="naming_series:",
		title_field="leave_request_id",
		fields=[
			f("naming_series", "Select", "Series", options="LTX-.YYYY.-.#####", default="LTX-.YYYY.-.#####", hidden=1),
			f("leave_request_id", "Data", "Leave Request ID", reqd=1, unique=1, in_list_view=1),
			f("employee", "Link", "Employee Code", options="Employee", reqd=1, in_list_view=1),
			f("employee_name", "Data", "Employee Name", fetch_from="employee.employee_name", read_only=1),
			f("leave_code", "Autocomplete", "Leave Code", reqd=1, in_list_view=1),
			f("leave_type", "Data", "Leave Type / Category", read_only=1),
			f("leave_description", "Data", "Leave Description", read_only=1),
			f("start_date", "Date", "Start Date", reqd=1, in_list_view=1),
			f("end_date", "Date", "End Date", reqd=1, in_list_view=1),
			f("duration_units", "Float", "Duration Days / Units", reqd=1, in_list_view=1),
			f("duration_unit", "Select", "Duration Unit", options="Days\nHours", default="Days"),
			f("two_hour_permission", "Check", "2-Hour Permission", read_only=1, in_list_view=1),
			f("requested_hours", "Float", "Requested Hours", read_only=1),
			f("standard_day_hours", "Float", "Standard Daily Working Hours", read_only=1),
			f("equivalent_leave_days", "Float", "Equivalent Leave Duration (days)", precision="6", read_only=1),
			f("half_day", "Check", "Half Day?"),
			f("start_time", "Time", "Start Time"),
			f("end_time", "Time", "End Time"),
			f("reason_code", "Data", "Reason / Leave Reason Code"),
			f("legacy_status", "Data", "Status", reqd=1, in_list_view=1),
			f("applied_date", "Date", "Applied Date"),
			f("approved_date", "Date", "Approved Date"),
			f("cancelled", "Check", "Cancelled?"),
			f("cancellation_date", "Date", "Cancellation Date"),
			f("lwp_payroll_period", "Data", "LWP Payroll Period"),
			f("source_record_audit_ref", "Data", "Source Record / Audit Ref"),
			f("rules_sb", "Section Break", "Applied Leave Rules", collapsible=1),
			f("paid_leave", "Check", "Paid Leave", read_only=1),
			f("unpaid_leave", "Check", "Unpaid Leave / Payroll Deduction", read_only=1),
			f("partially_paid_leave", "Check", "Partially Paid Leave", read_only=1),
			f("payroll_impact", "Check", "Payroll Impact", read_only=1),
			f("rules_cb", "Column Break"),
			f("attachment_required", "Check", "Attachment Required", read_only=1),
			f("carry_forward_allowed", "Check", "Carry Forward Allowed", read_only=1),
			f("maximum_carry_forward", "Float", "Maximum Carry Forward", read_only=1),
		],
	)
	ensure_dynamic_doctype_fields("Leave Transaction", [
		f("two_hour_permission", "Check", "2-Hour Permission", read_only=1, in_list_view=1),
		f("requested_hours", "Float", "Requested Hours", read_only=1),
		f("standard_day_hours", "Float", "Standard Daily Working Hours", read_only=1),
		f("equivalent_leave_days", "Float", "Equivalent Leave Duration (days)", precision="6", read_only=1),
	])


def ensure_dynamic_doctype_fields(doctype, fields):
	"""Append new standard fields to a database-defined governed DocType."""
	doc = frappe.get_doc("DocType", doctype)
	existing = {row.fieldname for row in doc.fields}
	missing = [field for field in fields if field["fieldname"] not in existing]
	if not missing:
		return
	for field in missing:
		doc.append("fields", field)
	doc.save(ignore_permissions=True)
	frappe.clear_cache(doctype=doctype)


def remove_leave_source_references():
	"""Remove the retired Leave source-reference fields from metadata and forms."""
	for doctype, fieldname in (
		("MBC Leave Settings", "source_reference"),
		("Leave Type", "karyo_source_reference"),
		("Leave Balance", "source_report_ref"),
	):
		if name := frappe.db.get_value("Custom Field", {"dt": doctype, "fieldname": fieldname}, "name"):
			frappe.delete_doc("Custom Field", name, ignore_permissions=True)
		frappe.db.delete("DocField", {"parent": doctype, "fieldname": fieldname})
		frappe.db.delete("Property Setter", {"doc_type": doctype, "field_name": fieldname})
		frappe.clear_cache(doctype=doctype)


def create_leave_link_metadata_fields():
	"""Expose Leave Code and Leave Description beside every Leave Type link."""
	# A governed custom DocType may already define these as ordinary DocFields.
	# Older setup runs could also have created duplicate Custom Field metadata for
	# that same physical column; remove only that redundant metadata row.
	for custom in frappe.get_all(
		"Custom Field",
		filters={"fieldname": ("in", ["karyo_leave_code", "karyo_leave_description"])},
		fields=["name", "dt", "fieldname"], limit_page_length=0,
	):
		if frappe.db.exists("DocField", {"parent": custom.dt, "fieldname": custom.fieldname}):
			frappe.db.delete("Custom Field", {"name": custom.name})
			frappe.clear_cache(doctype=custom.dt)
	linked_fields = frappe.get_all(
		"DocField", filters={"fieldtype": "Link", "options": "Leave Type"},
		fields=["parent", "fieldname"], limit_page_length=0,
	)
	custom_fields = {}
	for link in linked_fields:
		if link.parent == "Leave Type":
			continue
		existing = {
			row.fieldname for row in frappe.get_all(
				"DocField", filters={"parent": link.parent}, fields=["fieldname"], limit_page_length=0,
			)
		}
		fields = [
			{
				"fieldname": "karyo_leave_code", "fieldtype": "Data", "label": "Leave Code",
				"fetch_from": f"{link.fieldname}.karyo_mbc_leave_code", "read_only": 1,
				"in_list_view": 1, "insert_after": link.fieldname,
			},
			{
				"fieldname": "karyo_leave_description", "fieldtype": "Data", "label": "Leave Description",
				"fetch_from": f"{link.fieldname}.karyo_code_description", "read_only": 1,
				"in_list_view": 1, "insert_after": "karyo_leave_code",
			},
		]
		fields = [field for field in fields if field["fieldname"] not in existing]
		if fields:
			custom_fields[link.parent] = fields
	if custom_fields:
		create_custom_fields(custom_fields, ignore_validate=True)


def configure_leave_type_labels():
	"""Use the business terminology consistently on masters and transactions."""
	make_property_setter("Leave Type", "leave_type_name", "label", "Leave Type / Category", "Data")
	for fieldname, label in {
		"is_carry_forward": "Carry Forward Allowed",
		"expire_carry_forwarded_leaves_after_days": "Carry Forward Expiry (days)",
		"maximum_carry_forwarded_leaves": "Maximum Carry Forward",
		"is_lwp": "Unpaid Leave / Payroll Deduction",
		"is_ppl": "Partially Paid Leave",
		"fraction_of_daily_salary_per_leave": "Paid Salary Fraction",
	}.items():
		make_property_setter("Leave Type", fieldname, "label", label, "Data")
	make_property_setter(
		"Leave Type", None, "search_fields", "karyo_mbc_leave_code,karyo_code_description",
		"Data", for_doctype=True,
	)
	for row in frappe.get_all(
		"DocField", filters={"fieldtype": "Link", "options": "Leave Type"},
		fields=["parent", "fieldname"], limit_page_length=0,
	):
		make_property_setter(row.parent, row.fieldname, "label", "Leave Type / Category", "Data")
	# Most leave masters use whole/half days. Leave Application counters retain six
	# decimals because a two-hour permission can be 0.25, 0.2, etc. depending on
	# the employee's scheduled working day.
	for doctype, fieldnames in {
		"Leave Allocation": (
			"new_leaves_allocated", "total_leaves_allocated", "unused_leaves",
			"carry_forwarded_leaves_count", "total_leaves_encashed",
		),
		"Leave Encashment": ("leave_balance", "actual_encashable_days", "encashment_days"),
		"Leave Type": (
			"max_leaves_allowed", "max_continuous_days_allowed",
			"karyo_max_days_per_application", "karyo_max_days_per_year",
			"karyo_max_days_total", "karyo_annual_entitlement_days",
		),
	}.items():
		meta = frappe.get_meta(doctype)
		for fieldname in fieldnames:
			if meta.has_field(fieldname):
				make_property_setter(doctype, fieldname, "precision", 1, "Int")
	for fieldname in ("total_leave_days", "leave_balance"):
		make_property_setter("Leave Application", fieldname, "precision", 6, "Int")
		# Custom precision is applied after standard DocType synchronization, so
		# widen the existing MariaDB column here as well. Otherwise 0.25 is stored
		# as 0.3 even though the field metadata displays six decimals.
		frappe.db.change_column_type(
			"Leave Application", column=fieldname, type="decimal(21,6)", nullable=False
		)


def configure_encashment_form():
	"""Keep Leave Encashment payroll-only and remove unrelated accounting UI."""
	for fieldname in (
		"accounting_section", "pay_via_payment_entry", "expense_account", "payable_account",
		"column_break_vdnb", "posting_date", "paid_amount", "accounting_dimensions_section",
		"cost_center", "dimension_col_break",
	):
		make_property_setter("Leave Encashment", fieldname, "hidden", 1, "Check")
	make_property_setter("Leave Encashment", "employee", "label", "Employee Code", "Data")
	make_property_setter(
		"Leave Encashment", "karyo_payroll_cycle", "label", "Current Open Payroll Cycle", "Data",
	)
	# The receiving allocation is resolved authoritatively from employee, date and
	# leave type. A Leave Period is neither populated on modern allocations nor
	# consumed by the native encashment posting logic.
	make_property_setter("Leave Encashment", "leave_period", "reqd", 0, "Check")
	make_property_setter("Leave Encashment", "leave_period", "hidden", 1, "Check")
	make_property_setter("Leave Encashment", "encashment_date", "read_only", 1, "Check")


def bind_leave_type_metadata(doc, method=None):
	"""Persist the selected Leave Type's code and description on parent/child rows."""
	cache = {}

	def bind(row):
		link = next((field for field in row.meta.fields
			if field.fieldtype == "Link" and field.options == "Leave Type" and row.get(field.fieldname)), None)
		if not link:
			return
		if not (row.meta.has_field("karyo_leave_code") or row.meta.has_field("karyo_leave_description")):
			return
		leave_type = row.get(link.fieldname)
		if leave_type not in cache:
			cache[leave_type] = frappe.db.get_value(
				"Leave Type", leave_type,
				["karyo_mbc_leave_code", "karyo_code_description", "karyo_paid", "is_lwp", "is_ppl",
				 "fraction_of_daily_salary_per_leave", "allow_encashment", "earning_component",
				 "karyo_bank_type", "karyo_requires_attachment"], as_dict=True,
			) or frappe._dict()
		metadata = cache[leave_type]
		if row.meta.has_field("karyo_leave_code"):
			row.karyo_leave_code = metadata.get("karyo_mbc_leave_code")
		if row.meta.has_field("karyo_leave_description"):
			row.karyo_leave_description = metadata.get("karyo_code_description")
		for fieldname, source in {
			"karyo_paid_leave": "karyo_paid", "karyo_unpaid_leave": "is_lwp",
			"karyo_partially_paid_leave": "is_ppl",
			"karyo_paid_salary_fraction": "fraction_of_daily_salary_per_leave",
			"karyo_allow_encashment": "allow_encashment",
			"karyo_payroll_component": "earning_component",
			"karyo_balance_source": "karyo_bank_type",
			"karyo_attachment_required": "karyo_requires_attachment",
		}.items():
			if row.meta.has_field(fieldname):
				row.set(fieldname, metadata.get(source))
		if row.meta.has_field("karyo_payroll_impact"):
			row.karyo_payroll_impact = cint(bool(
				metadata.get("is_lwp") or metadata.get("is_ppl") or metadata.get("allow_encashment")
			))

	bind(doc)
	for table in doc.meta.get_table_fields():
		for row in doc.get(table.fieldname) or []:
			bind(row)


def backfill_leave_type_metadata():
	"""Populate the new display fields on existing linked records without changing audit dates."""
	leave_types = frappe.get_all(
		"Leave Type", fields=[
			"name", "karyo_mbc_leave_code", "karyo_code_description", "karyo_paid", "is_lwp",
			"is_ppl", "fraction_of_daily_salary_per_leave", "allow_encashment",
			"earning_component", "karyo_bank_type", "karyo_requires_attachment",
		],
		limit_page_length=0,
	)
	for link in frappe.get_all(
		"DocField", filters={"fieldtype": "Link", "options": "Leave Type"},
		fields=["parent", "fieldname"], limit_page_length=0,
	):
		meta = frappe.get_meta(link.parent)
		if not (meta.has_field("karyo_leave_code") and meta.has_field("karyo_leave_description")):
			continue
		if meta.issingle:
			leave_type = frappe.db.get_single_value(link.parent, link.fieldname)
			row = next((item for item in leave_types if item.name == leave_type), None)
			if row:
				frappe.db.set_single_value(link.parent, "karyo_leave_code", row.karyo_mbc_leave_code)
				frappe.db.set_single_value(link.parent, "karyo_leave_description", row.karyo_code_description)
			continue
		for row in leave_types:
			values = {
				"karyo_leave_code": row.karyo_mbc_leave_code,
				"karyo_leave_description": row.karyo_code_description,
			}
			for fieldname, value in {
				"karyo_paid_leave": row.karyo_paid,
				"karyo_unpaid_leave": row.is_lwp,
				"karyo_partially_paid_leave": row.is_ppl,
				"karyo_paid_salary_fraction": row.fraction_of_daily_salary_per_leave,
				"karyo_allow_encashment": row.allow_encashment,
				"karyo_payroll_component": row.earning_component,
				"karyo_payroll_impact": cint(bool(row.is_lwp or row.is_ppl or row.allow_encashment)),
				"karyo_balance_source": row.karyo_bank_type,
				"karyo_attachment_required": row.karyo_requires_attachment,
			}.items():
				if meta.has_field(fieldname):
					values[fieldname] = value
			frappe.db.set_value(
				link.parent, {link.fieldname: row.name}, values,
				update_modified=False,
			)


def complete_leave_type_metadata():
	"""Give legacy, non-matrix Leave Types stable metadata without replacing HR values."""
	known_codes = {
		"Compensatory Off": "COMP",
		"LWP": "LWP",
		"medical": "MED",
		"Privilege Leave": "PL",
	}
	used = set(frappe.get_all(
		"Leave Type", filters={"karyo_mbc_leave_code": ("is", "set")},
		pluck="karyo_mbc_leave_code", limit_page_length=0,
	))
	for row in frappe.get_all(
		"Leave Type", fields=["name", "leave_type_name", "karyo_mbc_leave_code", "karyo_code_description"],
		limit_page_length=0,
	):
		values = {}
		if not row.karyo_mbc_leave_code:
			words = re.findall(r"[A-Za-z0-9]+", row.leave_type_name or row.name)
			base = known_codes.get(row.name)
			if not base:
				base = ("".join(word[0] for word in words) if len(words) > 1 else "".join(words))[:10].upper()
			base = base or "LEAVE"
			candidate = base
			sequence = 2
			while candidate in used:
				candidate = f"{base[:8]}{sequence}"
				sequence += 1
			values["karyo_mbc_leave_code"] = candidate
			used.add(candidate)
		if not row.karyo_code_description:
			values["karyo_code_description"] = row.leave_type_name or row.name
		if values:
			frappe.db.set_value("Leave Type", row.name, values, update_modified=False)


def retire_legacy_medical_leave():
	"""Hide the superseded Medical Leave type while preserving linked audit history."""
	if not frappe.get_meta("Leave Type").has_field("karyo_is_retired"):
		return
	frappe.db.set_value(
		"Leave Type", {"karyo_mbc_leave_code": "MED"}, "karyo_is_retired", 1,
		update_modified=False,
	)


def _leave_type_for_code(leave_code):
	code = (leave_code or "").strip().upper()
	if not code:
		frappe.throw(_("Leave Code is required."))
	leave_type = frappe.db.get_value(
		"Leave Type", {"karyo_mbc_leave_code": code},
		[
			"name", "karyo_mbc_leave_code", "karyo_code_description", "karyo_paid", "is_lwp",
			"is_ppl", "allow_encashment", "karyo_requires_attachment", "is_carry_forward",
			"maximum_carry_forwarded_leaves",
		], as_dict=True,
	)
	if not leave_type:
		frappe.throw(_("Leave Code {0} does not exist in Leave Type / Category.").format(code))
	return leave_type


def validate_leave_balance(doc, method=None):
	"""Resolve the governed code and protect each dated employee balance from duplicates."""
	leave_type = _leave_type_for_code(doc.leave_code)
	doc.leave_code = leave_type.karyo_mbc_leave_code
	doc.leave_type = leave_type.name
	doc.leave_description = leave_type.karyo_code_description
	doc.leave_year = cint(doc.leave_year)
	if doc.leave_year < 1900 or doc.leave_year > 2200:
		frappe.throw(_("Leave Year must be a four-digit year between 1900 and 2200."))
	if flt(doc.advance_sick_outstanding_days) < 0:
		frappe.throw(_("Advance Sick Outstanding Days cannot be negative."))
	if flt(doc.advance_sick_outstanding_days) > 0:
		doc.advance_sick_recovery_required = 1
	if doc.as_at_date and getdate(doc.as_at_date).year not in (doc.leave_year, doc.leave_year + 1):
		frappe.throw(_("As At Date must fall in the Leave Year or on its following-year closing date."))
	filters = {
		"employee": doc.employee,
		"leave_year": doc.leave_year,
		"leave_code": doc.leave_code,
		"as_at_date": doc.as_at_date,
	}
	if doc.name and not doc.is_new():
		filters["name"] = ("!=", doc.name)
	if frappe.db.exists("Leave Balance", filters):
		frappe.throw(_("A Leave Balance already exists for this employee, year, code and As At Date."))


def validate_leave_transaction(doc, method=None):
	"""Validate imported transactions and snapshot their effective Leave Type controls."""
	leave_type = _leave_type_for_code(doc.leave_code)
	doc.leave_code = leave_type.karyo_mbc_leave_code
	doc.leave_type = leave_type.name
	doc.leave_description = leave_type.karyo_code_description
	if doc.start_date and doc.end_date and getdate(doc.end_date) < getdate(doc.start_date):
		frappe.throw(_("End Date cannot be before Start Date."))
	if flt(doc.duration_units) <= 0:
		frappe.throw(_("Duration Days / Units must be greater than zero."))
	if (doc.legacy_status or "").strip().lower() in ("cancelled", "canceled"):
		doc.cancelled = 1
	if doc.cancelled and not doc.cancellation_date:
		frappe.throw(_("Cancellation Date is required for a cancelled Leave Transaction."))
	doc.paid_leave = cint(leave_type.karyo_paid)
	doc.unpaid_leave = cint(leave_type.is_lwp)
	doc.partially_paid_leave = cint(leave_type.is_ppl)
	doc.payroll_impact = cint(bool(
		leave_type.is_lwp or leave_type.is_ppl or leave_type.allow_encashment
	))
	doc.attachment_required = cint(leave_type.karyo_requires_attachment)
	doc.carry_forward_allowed = cint(leave_type.is_carry_forward)
	doc.maximum_carry_forward = flt(leave_type.maximum_carry_forwarded_leaves)


def sync_employee_leave_balances(employee, as_at_date=None):
	"""Materialize current native ledger balances in the Leave Balance register."""
	if not employee or not frappe.db.exists("DocType", "Leave Balance"):
		return
	from karyo.hr.self_service import leave_balances

	as_at_date = getdate(as_at_date or nowdate())
	leave_year = as_at_date.year
	live_rows = [row for row in leave_balances(employee, as_at_date) if row.get("source") != "Leave Balance"]
	advance_days = flt(frappe.db.get_value("Sick Leave Bank", {"employee": employee}, "advance_balance_days"))
	seen_codes = set()
	for row in live_rows:
		code = row.get("leave_code")
		if not code:
			continue
		seen_codes.add(code)
		outstanding = advance_days if code in ("SICK03", "SICK04") else 0
		values = {
			"leave_type": row.get("leave_type"),
			"leave_description": frappe.db.get_value(
				"Leave Type", row.get("leave_type"), "karyo_code_description"
			),
			"closing_balance": flt(row.get("confirmed_remaining")),
			"advance_sick_outstanding_days": outstanding,
			"advance_sick_recovery_required": cint(outstanding > 0),
			"is_system_synced": 1,
		}
		filters = {
			"employee": employee, "leave_year": leave_year,
			"leave_code": code, "as_at_date": as_at_date,
		}
		if name := frappe.db.get_value("Leave Balance", filters, "name"):
			frappe.db.set_value("Leave Balance", name, values, update_modified=False)
		else:
			frappe.get_doc({
				"doctype": "Leave Balance", **filters, **values,
			}).insert(ignore_permissions=True)
	for stale in frappe.get_all(
		"Leave Balance",
		filters={
			"employee": employee, "leave_year": leave_year,
			"as_at_date": as_at_date, "is_system_synced": 1,
		},
		fields=["name", "leave_code"], limit_page_length=0,
	):
		if stale.leave_code not in seen_codes:
			frappe.db.set_value(
				"Leave Balance", stale.name,
				{"closing_balance": 0, "advance_sick_outstanding_days": 0,
				 "advance_sick_recovery_required": 0},
				update_modified=False,
			)


def sync_leave_balance_register(doc, method=None):
	"""Refresh the affected employee after allocation, application or ledger changes."""
	sync_employee_leave_balances(doc.get("employee"))


def sync_all_leave_balances():
	"""Backfill today's synchronized balance table for every active allocation owner."""
	today = nowdate()
	for row in frappe.get_all(
		"Leave Allocation",
		filters={"docstatus": 1, "from_date": ("<=", today), "to_date": (">=", today)},
		fields=["employee"], group_by="employee", limit_page_length=0,
	):
		sync_employee_leave_balances(row.employee, today)


def _preserve_optional_property(doctype, fieldname):
	filters = {"doc_type": doctype, "field_name": fieldname, "property": "reqd"}
	if name := frappe.db.exists("Property Setter", filters):
		frappe.db.set_value("Property Setter", name, "value", "0", update_modified=False)


def seed_leave_settings():
	settings = frappe.get_single("MBC Leave Settings")
	defaults = {
		"annual_leave_entitlement": 21,
		"casual_annual_entitlement": 11,
		"sick_annual_entitlement": 21,
		"standard_day_hours": 8,
		"sick_bank_ceiling": 110,
		"sick_refund_cap": 16,
		"leave_refund_divisor": 22,
		"advance_sick_recovery_days": 14,
		"advance_sick_full_pay_limit": 180,
		"advance_sick_half_pay_limit": 180,
		"vacation_as_casual_limit": 5,
		"injury_leave_limit": 30,
		"maternity_leave_limit": 112,
		"paternity_leave_limit": 10,
		"study_leave_limit": 15,
		"family_responsibility_limit": 5,
		"effective_from": "2026-01-01",
	}
	# The original provisional setup used 28 days deducted from Vacation Leave.
	# The later client-validated rule confirms 10 working days, no leave bank.
	if flt(settings.paternity_leave_limit) == 28:
		settings.paternity_leave_limit = 10
	for field, value in defaults.items():
		if settings.get(field) in (None, "", 0):
			settings.set(field, value)
	if not settings.vacation_leave_bands:
		for lower, upper, annual, ceiling in ((0, 5, 25, 105), (5, 10, 30, 140), (10, 15, 35, 175), (15, 0, 35, 210)):
			settings.append("vacation_leave_bands", {
				"service_from_years": lower, "service_to_years": upper,
				"annual_entitlement_days": annual, "accumulation_ceiling_days": ceiling,
			})
	settings.save(ignore_permissions=True)


def seed_leave_categories():
	"""Maintain the small user-facing category master without removing operational types."""
	allowed = {name for name, _description in LEAVE_CATEGORIES}
	for order, (name, description) in enumerate(LEAVE_CATEGORIES, 1):
		if frappe.db.exists("Leave Category", name):
			frappe.db.set_value(
				"Leave Category", name,
				{"category_name": name, "description": description, "display_order": order},
				update_modified=False,
			)
			continue
		frappe.get_doc({
			"doctype": "Leave Category",
			"category_name": name,
			"description": description,
			"display_order": order,
		}).insert(ignore_permissions=True)

	# This master is deliberately governed: do not let retired/demo categories
	# return after imports or setup reruns.
	for name in frappe.get_all("Leave Category", pluck="name", limit_page_length=0):
		if name not in allowed:
			frappe.delete_doc("Leave Category", name, ignore_permissions=True)


def sync_leave_settings(doc=None, method=None):
	"""Project the governed parameter master onto operational Leave Type fields."""
	settings = doc or frappe.get_single("MBC Leave Settings")
	mapping = {
		"ANN": {"karyo_annual_entitlement_days": settings.annual_leave_entitlement, "max_leaves_allowed": settings.annual_leave_entitlement, "karyo_eligible_employment_categories": "", "karyo_requires_valid_contract": 0},
		"CASL01": {"karyo_annual_entitlement_days": settings.casual_annual_entitlement, "max_leaves_allowed": settings.casual_annual_entitlement},
		"SICK01": {"karyo_annual_entitlement_days": settings.sick_annual_entitlement, "max_leaves_allowed": settings.sick_annual_entitlement, "karyo_bank_ceiling_days": settings.sick_bank_ceiling, "karyo_refund_cap_days": settings.sick_refund_cap, "karyo_refund_divisor": settings.leave_refund_divisor},
		"SICK03": {"karyo_max_days_total": settings.advance_sick_full_pay_limit, "karyo_advance_recovery_days": settings.advance_sick_recovery_days},
		"SICK04": {"karyo_max_days_total": settings.advance_sick_half_pay_limit, "karyo_advance_recovery_days": settings.advance_sick_recovery_days},
		"VAC02": {"karyo_max_days_per_year": settings.vacation_as_casual_limit, "karyo_max_days_per_application": settings.vacation_as_casual_limit},
		"VAC03": {"karyo_max_days_per_year": settings.vacation_as_casual_limit, "karyo_max_days_per_application": settings.vacation_as_casual_limit},
		"INJ": {"karyo_max_days_per_year": settings.injury_leave_limit, "karyo_max_days_per_application": settings.injury_leave_limit},
		"MAT": {"karyo_annual_entitlement_days": settings.maternity_leave_limit, "max_leaves_allowed": settings.maternity_leave_limit, "karyo_max_days_per_application": settings.maternity_leave_limit},
		"PAT": {
			"karyo_max_days_per_application": settings.paternity_leave_limit,
			"karyo_max_days_per_year": settings.paternity_leave_limit,
			"karyo_bank_type": "None", "karyo_requires_leave_bank": 0,
			"karyo_deducts_from_leave_type": None,
			"karyo_eligible_gender": "Male",
			"karyo_eligible_employment_categories": "PERM",
		},
		"STD": {"karyo_max_days_per_year": settings.study_leave_limit, "karyo_max_days_per_application": settings.study_leave_limit},
		"VAC05": {"karyo_max_days_per_year": settings.family_responsibility_limit, "karyo_max_days_per_application": settings.family_responsibility_limit},
	}
	for code, values in mapping.items():
		if name := frappe.db.get_value("Leave Type", {"karyo_mbc_leave_code": code}, "name"):
			frappe.db.set_value("Leave Type", name, values, update_modified=False)
	frappe.clear_cache(doctype="Leave Type")


def _leave_type_values(row):
	name, group, code, description, yos, vacation, pb, paid, saturday, sunday, public_holiday = row
	detail = RULE_DETAILS.get(code, {})
	bank_type = detail.get("bank", "None")
	is_half_pay = code == "SICK04"
	return name, {
		"leave_type_name": name,
		"max_leaves_allowed": detail.get("annual", 0),
		"max_continuous_days_allowed": detail.get("max_application", 0),
		"is_carry_forward": 0,
		"is_lwp": int(not paid),
		"is_ppl": int(is_half_pay),
		"fraction_of_daily_salary_per_leave": 0.5 if is_half_pay else 0,
		"allow_negative": int(bank_type not in ("Annual Allocation",) and paid),
		"include_holiday": int(saturday and sunday and public_holiday),
		"karyo_mbc_leave_code": code,
		"karyo_mbc_leave_group": group,
		"karyo_code_description": description,
		"karyo_bank_type": bank_type,
		"karyo_requires_leave_bank": int(bank_type != "None"),
		"karyo_min_service_months": detail.get("min_service", 0),
		"karyo_eligible_employment_categories": detail.get("categories", ""),
		"karyo_eligible_gender": detail.get("gender", ""),
		"karyo_requires_valid_contract": detail.get("valid_contract", 0),
		"karyo_max_days_per_application": detail.get("max_application", 0),
		"karyo_max_days_per_year": detail.get("max_year", 0),
		"karyo_max_days_total": detail.get("max_total", 0),
		"karyo_medical_certificate_after_days": detail.get("medical_after", 0),
		"karyo_requires_attachment": detail.get("attachment", 0),
		"karyo_prerequisite_codes": detail.get("prerequisites", ""),
		"karyo_yos_earned": yos,
		"karyo_vacation_earned": vacation,
		"karyo_pb_earned": pb,
		"karyo_paid": paid,
		"karyo_include_saturday": saturday,
		"karyo_include_sunday": sunday,
		"karyo_include_public_holiday": public_holiday,
		"karyo_annual_entitlement_days": detail.get("annual", 0),
		"karyo_bank_ceiling_days": detail.get("ceiling", 0),
		"karyo_refund_cap_days": detail.get("refund_cap", 0),
		"karyo_refund_divisor": detail.get("refund_divisor", 0),
		"karyo_advance_recovery_days": detail.get("recovery", 0),
		"karyo_affects_yos": int(not yos),
		"karyo_pb_not_earned": int(not pb),
		"karyo_vacation_not_earned": int(not vacation),
	}


def seed_leave_types():
	"""Create the complete client-supplied code matrix without overwriting later HR changes."""
	code_to_name = {}
	for row in LEAVE_TYPE_MATRIX:
		name, values = _leave_type_values(row)
		code = values["karyo_mbc_leave_code"]
		existing = frappe.db.get_value("Leave Type", {"karyo_mbc_leave_code": code}, "name")
		if not existing and frappe.db.exists("Leave Type", name):
			existing = name
		if existing:
			# A populated MBC code means HR has already taken ownership of this
			# parameter record. Only bootstrap legacy rows that have no code.
			if not frappe.db.get_value("Leave Type", existing, "karyo_mbc_leave_code"):
				frappe.db.set_value("Leave Type", existing, values, update_modified=False)
			code_to_name[code] = existing
			continue
		doc = frappe.get_doc({"doctype": "Leave Type", **values})
		doc.insert(ignore_permissions=True)
		code_to_name[code] = doc.name
	for code, detail in RULE_DETAILS.items():
		if detail.get("deduct_code") and code in code_to_name and detail["deduct_code"] in code_to_name:
			frappe.db.set_value(
				"Leave Type", code_to_name[code], "karyo_deducts_from_leave_type",
				code_to_name[detail["deduct_code"]], update_modified=False,
			)
	return code_to_name


def seed_leave_policies(code_to_name):
	policies = {
		"General Leave policy": [("ANN", 21), ("CASL01", 11), ("SICK01", 21)],
		"MBC Permanent Core Leave Policy": [("ANN", 21), ("CASL01", 11), ("SICK01", 21)],
		"MBC Contract Leave Policy": [("ANN", 21), ("SICK01", 21)],
		"MBC Maternity Leave Policy": [("MAT", 112)],
	}
	for title, rows in policies.items():
		name = frappe.db.get_value("Leave Policy", {"title": title, "docstatus": ("<", 2)}, "name")
		if not name:
			doc = frappe.get_doc({
				"doctype": "Leave Policy", "title": title,
				"leave_policy_details": [
					{"leave_type": code_to_name[code], "annual_allocation": days}
					for code, days in rows if code in code_to_name
				],
			}).insert(ignore_permissions=True)
			doc.submit()
			continue
		doc = frappe.get_doc("Leave Policy", name)
		existing = {row.leave_type: row for row in doc.leave_policy_details}
		missing = [(code_to_name[code], days) for code, days in rows
			if code in code_to_name and code_to_name[code] not in existing]
		if doc.docstatus == 0:
			for leave_type, days in missing:
				doc.append("leave_policy_details", {"leave_type": leave_type, "annual_allocation": days})
			doc.save(ignore_permissions=True)
			doc.submit()
		elif missing:
			# Leave Policy is a submitted governed master. Adding a newly defined
			# entitlement must not require replacing the policy selected on every
			# employee, so add only missing rows and preserve existing HR values.
			for leave_type, days in missing:
				frappe.get_doc({
					"doctype": "Leave Policy Detail", "parent": doc.name,
					"parenttype": "Leave Policy", "parentfield": "leave_policy_details",
					"docstatus": 1, "leave_type": leave_type, "annual_allocation": days,
				}).insert(ignore_permissions=True)
			frappe.db.set_value("Leave Policy", doc.name, "modified", frappe.utils.now(), update_modified=False)


def configure_lwp_integration_flags():
	"""Keep the client-confirmed LWP non-accrual rules on the Leave Type master.

	Payroll continues to use HRMS' native ``is_lwp`` flag. PB, vacation accrual
	and service calculations consume their own explicit flags from that same
	Leave Type instead of duplicating a list of leave names in each module.
	"""
	for leave_type in frappe.get_all("Leave Type", filters={"is_lwp": 1}, pluck="name"):
		frappe.db.set_value("Leave Type", leave_type, {
			"karyo_affects_yos": 1, "karyo_pb_not_earned": 1, "karyo_vacation_not_earned": 1,
		}, update_modified=False)


def configure_encashment_integration():
	"""Complete missing native encashment mappings without replacing HR choices."""
	component = frappe.db.get_value(
		"Salary Component",
		{"name": "Leave Encashment", "type": "Earning", "disabled": 0},
		"name",
	)
	if not component:
		return 0
	leave_types = frappe.get_all(
		"Leave Type",
		filters={"allow_encashment": 1, "earning_component": ("is", "not set")},
		pluck="name",
		limit_page_length=0,
	)
	for leave_type in leave_types:
		frappe.db.set_value(
			"Leave Type", leave_type, "earning_component", component, update_modified=False,
		)
	return len(leave_types)


def configure_leave_encashment_pdb():
	"""Give payroll-posted leave encashments a governed PDB identity."""
	from karyo.setup.payroll_source_trace import CATEGORY_OPTIONS
	category_field = frappe.db.get_value(
		"Custom Field",
		{"dt": "Additional Salary", "fieldname": "karyo_transaction_category"},
		"name",
	)
	if category_field:
		frappe.db.set_value(
			"Custom Field", category_field, "options", CATEGORY_OPTIONS, update_modified=False,
		)
	if not frappe.db.exists("DocType", "Payroll PDB Code"):
		return None
	component = frappe.db.get_value(
		"Salary Component", "Leave Encashment",
		["name", "is_tax_applicable", "depends_on_payment_days"], as_dict=True,
	)
	if not component:
		return None
	existing = frappe.db.get_value(
		"Payroll PDB Code", {"salary_component": component.name, "is_active": 1}, "name",
	)
	if existing:
		return existing
	template = frappe.db.get_value(
		"Payroll PDB Code", "AL",
		["pdb_type", "configuration_version", "company", "effective_from"], as_dict=True,
	)
	if not template:
		rows = frappe.get_all(
			"Payroll PDB Code", filters={"is_active": 1},
			fields=["pdb_type", "configuration_version", "company", "effective_from"],
			order_by="effective_from desc, modified desc", limit_page_length=1,
		)
		template = rows[0] if rows else None
	if not template or not template.configuration_version:
		return None
	code = "LENC" if not frappe.db.exists("Payroll PDB Code", "LENC") else "LENCASH"
	frappe.get_doc({
		"doctype": "Payroll PDB Code",
		"pdb_code": code,
		"pdb_type": template.pdb_type,
		"description": "LEAVE ENCASHMENT",
		"short_description": "Leave Encashment",
		"salary_component": component.name,
		"transaction_mode": "Once Off",
		"taxable": component.is_tax_applicable,
		"prorata": component.depends_on_payment_days,
		"is_active": 1,
		"effective_from": template.effective_from or "2026-01-01",
		"configuration_version": template.configuration_version,
		"company": template.company,
		"source_reference": "Karyo leave encashment payroll mapping",
	}).insert(ignore_permissions=True)
	return code


def ensure_advance_sick_allotments():
	"""Give every active employee one governed 180-day recoverable facility."""
	if not frappe.get_meta("Sick Leave Bank").has_field("advance_allotted_days"):
		return
	allotment = flt(
		frappe.db.get_single_value("MBC Leave Settings", "advance_sick_full_pay_limit") or 180
	)
	existing = {
		row.employee: row.name for row in frappe.get_all(
			"Sick Leave Bank", fields=["name", "employee"], limit_page_length=0,
		)
	}
	for employee in frappe.get_all(
		"Employee", filters={"status": "Active"}, pluck="name", limit_page_length=0,
	):
		if name := existing.get(employee):
			frappe.db.set_value(
				"Sick Leave Bank", name, "advance_allotted_days", allotment,
				update_modified=False,
			)
			continue
		frappe.get_doc({
			"doctype": "Sick Leave Bank", "employee": employee, "status": "Active",
			"opening_bank_days": 0, "bank_days": 0,
			"advance_allotted_days": allotment,
		}).insert(ignore_permissions=True)


def ensure_2027_2028_fiscal_year():
	"""Expose the next governed leave-processing year in the calendar dropdown."""
	name = "2027-2028"
	if frappe.db.exists("Fiscal Year", name):
		return name
	doc = frappe.get_doc({
		"doctype": "Fiscal Year",
		"year": name,
		"year_start_date": "2027-04-01",
		"year_end_date": "2028-03-31",
		"disabled": 0,
	})
	doc.flags.ignore_permissions = True
	doc.insert(ignore_permissions=True)
	return doc.name


def setup():
	print("Karyo governed Leave setup:")
	ensure_2027_2028_fiscal_year()
	create_leave_parameter_doctypes()
	remove_leave_source_references()
	create_doctypes()
	create_leave_link_metadata_fields()
	configure_leave_type_labels()
	configure_encashment_form()
	_preserve_optional_property("Leave Application", "description")
	seed_leave_settings()
	seed_leave_categories()
	code_to_name = seed_leave_types()
	complete_leave_type_metadata()
	retire_legacy_medical_leave()
	backfill_leave_type_metadata()
	sync_leave_settings()
	seed_leave_policies(code_to_name)
	from karyo.hr.leave_controls import backfill_employee_leave_schemes
	backfill_employee_leave_schemes()
	configure_lwp_integration_flags()
	configure_encashment_integration()
	configure_leave_encashment_pdb()
	from karyo.hr.leave_encashment import backfill_payroll_mappings
	backfill_payroll_mappings()
	ensure_advance_sick_allotments()
	from karyo.hr.leave_controls import sync_all_employee_leave_schemes
	sync_all_employee_leave_schemes()
	sync_all_leave_balances()
	frappe.db.commit()
	print("Done.")
