"""Karyo Loan — Refund / Settlement transaction + Advance Payment fields (Phase 3).

    bench --site dev.localhost execute karyo.setup.loan_settlement.setup

Creates the Karyo Loan Settlement transaction (full refund / settlement with
outstanding display, payment type, cheque validation and EWF interest waiver —
BR-FAR-LMS-REFD-001..010) and adds the Advance Payment / Change in Period
direction + component fields to Karyo Loan Recast (ADV-001). Idempotent.
"""

import json

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
from frappe.utils import flt

from karyo.setup.foundation import f, make_doctype


def create_settlement_doctype():
	make_doctype(
		"Karyo Loan Settlement",
		is_submittable=1,
		autoname="naming_series:",
		title_field="loan",
		fields=[
			f("naming_series", "Select", "Series", options="KLS-.YYYY.-.#####", default="KLS-.YYYY.-.#####"),
			f("loan", "Link", "Loan", options="Karyo Loan", reqd=1, in_list_view=1),
			f("employee", "Data", "Employee", read_only=1, in_list_view=1),
			f("loan_type", "Data", "Loan Type", read_only=1),
			f("cb1", "Column Break"),
			f("refund_date", "Date", "Settlement Date", reqd=1, in_list_view=1),
			f("payment_type", "Select", "Payment Method", options="Cash\nCheque\nBank Transfer\nBank", default="Cheque", reqd=1),
			f("cheque_no", "Data", "Cheque Number", depends_on="eval:doc.payment_type=='Cheque'"),
			f("ewf_waive_interest", "Check", "EWF — Waive Interest"),
			f("out_sb", "Section Break", "Outstanding at Refund Date"),
			f("capital_due", "Currency", "Capital Due", read_only=1, in_list_view=1),
			f("interest_due", "Currency", "Interest Due", read_only=1),
			f("insurance_due", "Currency", "Insurance Due", read_only=1),
			f("cb2", "Column Break"),
			f("total_balance_due", "Currency", "Total Balance Due", read_only=1, in_list_view=1),
			f("remaining_instalments", "Int", "Remaining Instalments", read_only=1),
			f("remarks_sb", "Section Break", "Remarks"),
			f("remarks", "Small Text", "Remarks"),
		],
	)


def add_advance_fields():
	create_custom_fields(
		{
			"Karyo Loan Settlement": [
				{"fieldname": "amount_received", "fieldtype": "Currency", "label": "Amount Received", "insert_after": "total_balance_due"},
				{"fieldname": "waived_interest", "fieldtype": "Currency", "label": "Interest Waived", "read_only": 1, "insert_after": "interest_due"},
				{"fieldname": "rounding_adjustment", "fieldtype": "Currency", "label": "Rounding Adjustment", "read_only": 1, "insert_after": "amount_received"},
				{"fieldname": "payment_reference", "fieldtype": "Data", "label": "Payment Reference", "insert_after": "cheque_no"},
				{"fieldname": "approval_reference", "fieldtype": "Data", "label": "Approval Reference", "insert_after": "payment_reference"},
				{"fieldname": "prior_state_snapshot", "fieldtype": "Long Text", "label": "Prior State Snapshot", "read_only": 1, "hidden": 1, "insert_after": "remarks"},
				{"fieldname": "settlement_ledger_entries", "fieldtype": "Small Text", "label": "Settlement Ledger Entries", "read_only": 1, "insert_after": "prior_state_snapshot"},
				{"fieldname": "reversal_ledger_entries", "fieldtype": "Small Text", "label": "Reversal Ledger Entries", "read_only": 1, "insert_after": "settlement_ledger_entries"},
				{"fieldname": "journal_entry", "fieldtype": "Link", "label": "Journal Entry", "options": "Journal Entry", "read_only": 1, "insert_after": "reversal_ledger_entries"},
				{"fieldname": "idempotency_key", "fieldtype": "Data", "label": "Idempotency Key", "unique": 1, "read_only": 1, "insert_after": "journal_entry"},
				{"fieldname": "reversal_processed", "fieldtype": "Check", "label": "Reversal Processed", "read_only": 1, "insert_after": "idempotency_key"},
				{"fieldname": "receipt_reference", "fieldtype": "Data", "label": "Settlement Receipt Reference", "read_only": 1, "insert_after": "reversal_processed"},
			],
			"Karyo Loan Recast": [
				{
					"fieldname": "direction",
					"fieldtype": "Select",
					"label": "Payment / Refund",
					"options": "Payment\nRefund",
					"default": "Payment",
					"insert_after": "effective_date",
				},
				{
					"fieldname": "component",
					"fieldtype": "Select",
					"label": "Applies To",
					"options": "Capital",
					"default": "Capital",
					"read_only": 1,
					"insert_after": "direction",
				},
			],
			"Karyo Loan Schedule": [
				{"fieldname": "waived_interest", "fieldtype": "Currency", "label": "Waived Interest", "read_only": 1, "insert_after": "paid_interest"},
			],
			"Karyo Settings": [
				{"fieldname": "enable_loan_excess_refund", "fieldtype": "Check", "label": "Enable Excess Deduction Refund", "default": "0", "insert_after": "loan_recast_override_role", "description": "Keep disabled until MBC approves the refund accounting/business rule."},
				{"fieldname": "loan_refund_role", "fieldtype": "Link", "label": "Excess Refund Authorising Role", "options": "Role", "insert_after": "enable_loan_excess_refund"},
				{"fieldname": "enable_ewf_interest_waiver", "fieldtype": "Check", "label": "Enable EWF Interest Waiver", "default": "0", "insert_after": "loan_refund_role", "description": "Keep disabled until MBC confirms eligibility and formula."},
				{"fieldname": "loan_ewf_waiver_role", "fieldtype": "Link", "label": "EWF Waiver Authorising Role", "options": "Role", "insert_after": "enable_ewf_interest_waiver"},
			]
		},
		ignore_validate=True,
	)
	print("  + Karyo Loan Recast advance fields ensured")


def configure_permissions():
	"""Financial adjustments are initiated/reviewed by loan staff and submitted by Finance."""
	matrices = {
		"Karyo Loan Recast": {
			"System Manager": (1, 1, 1, 1), "Karyo Finance": (1, 1, 1, 1),
			"Payroll Finance": (1, 1, 1, 1), "HR Manager": (1, 1, 1, 0),
			"Loan Officer": (1, 1, 1, 0), "Payroll Auditor": (1, 0, 0, 0),
		},
		"Karyo Loan Settlement": {
			"System Manager": (1, 1, 1, 1), "Karyo Finance": (1, 1, 1, 1),
			"Payroll Finance": (1, 1, 1, 1), "HR Manager": (1, 0, 0, 0),
			"Payroll Auditor": (1, 0, 0, 0),
		},
	}
	for doctype, roles in matrices.items():
		meta = frappe.get_doc("DocType", doctype)
		meta.set("permissions", [])
		for role, (read, create, write, submit) in roles.items():
			meta.append("permissions", {"role": role, "read": read, "report": read,
				"export": read, "print": read, "email": read, "create": create,
				"write": write, "submit": submit, "cancel": submit, "amend": 0,
				"delete": 0, "share": 0})
		meta.save(ignore_permissions=True)


def reconcile_submitted_settlements():
	"""Repair records submitted before settlement started retaining ``total_paid``.

	Older snapshots do not contain that value.  In those records the loan's current
	``total_paid`` is the pre-settlement amount, so retain it in the snapshot and add
	the received settlement exactly once.  Stamping the snapshot makes this migration
	idempotent and preserves the amount that cancellation must restore.
	"""
	if not frappe.db.table_exists("Karyo Loan Settlement"):
		return
	for row in frappe.get_all(
		"Karyo Loan Settlement",
		filters={"docstatus": 1},
		fields=["name", "loan", "amount_received", "total_balance_due", "prior_state_snapshot"],
	):
		loan = frappe.db.get_value(
			"Karyo Loan",
			row.loan,
			["status", "workflow_state", "total_paid"],
			as_dict=True,
		)
		if not loan or (loan.status != "Settled" and loan.workflow_state != "Settled"):
			continue
		try:
			prior = json.loads(row.prior_state_snapshot or "{}")
		except (TypeError, ValueError):
			continue

		if "total_paid" not in prior:
			prior["total_paid"] = flt(loan.total_paid)
			frappe.db.set_value(
				"Karyo Loan Settlement",
				row.name,
				"prior_state_snapshot",
				json.dumps(prior, default=str, sort_keys=True),
				update_modified=False,
			)

		expected_paid = flt(prior.get("total_paid")) + flt(row.amount_received or row.total_balance_due)
		frappe.db.set_value(
			"Karyo Loan",
			row.loan,
			{
				"outstanding_capital": 0,
				"outstanding_interest": 0,
				"outstanding_insurance": 0,
				"total_paid": expected_paid,
			},
			update_modified=False,
		)


def setup():
	print("Karyo Loan settlement setup:")
	create_settlement_doctype()
	add_advance_fields()
	configure_permissions()
	reconcile_submitted_settlements()
	frappe.db.commit()
	print("Done.")
