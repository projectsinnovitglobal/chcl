"""Initialise Passage Benefit Bank tool (prototype screen 5).

HR filters eligible employees and creates PB Banks in bulk. Only employees that
pass the shared eligibility rule are listed or initialised (PB-BNK-002/006); the
listing carries the years-of-service, Eligible-From-Date and basic salary the
confirmation dialog shows before creating a bank.
"""

import frappe
from frappe import _
from frappe.utils import flt, getdate, today

from karyo.passage_benefit.eligibility import evaluate as evaluate_eligibility

INITIALISATION_ROLES = ("System Manager", "HR Manager", "HR User", "Passage Benefit Officer")


def _check_initialisation_access():
	frappe.only_for(INITIALISATION_ROLES)


@frappe.whitelist()
def list_eligible_employees(
	company=None,
	grade=None,
	branch=None,
	employee=None,
	date_joined_from=None,
	date_joined_to=None,
	bank_created=None,
	as_on=None,
):
	"""Return eligible employees (with YOS / eligible-from / basic salary) for init."""
	_check_initialisation_access()
	# Do not hide failed candidates: HR must see "Not eligible" and the exact
	# submitted-data reason instead of receiving an apparently empty result.
	filters = {}
	if company:
		filters["company"] = company
	if grade:
		filters["grade"] = grade
	if branch:
		filters["branch"] = branch
	if employee:
		filters["name"] = employee
	as_on = getdate(as_on) if as_on else getdate(today())
	rows = frappe.get_list(
		"Employee",
		filters=filters,
		fields=[
			"name",
			"employee_name",
			"grade",
			"branch",
			"company",
			"date_of_joining",
			"karyo_date_joined_service",
		],
		order_by="employee_name asc, name asc",
		limit_page_length=0,
	)
	banks = {row.employee: row for row in frappe.get_list(
		"Passage Benefit Bank", filters={"employee": ("in", [e.name for e in rows])},
		fields=["employee", "current_balance", "status"], limit_page_length=0,
	)} if rows and frappe.has_permission("Passage Benefit Bank", "read") else {}
	out = []
	for e in rows:
		joined_raw = e.karyo_date_joined_service or e.date_of_joining
		joined = getdate(joined_raw) if joined_raw else None
		if date_joined_from and (not joined or joined < getdate(date_joined_from)):
			continue
		if date_joined_to and (not joined or joined > getdate(date_joined_to)):
			continue
		res = evaluate_eligibility(e.name, as_on)
		has_bank = bool(frappe.db.exists("Passage Benefit Bank", e.name))
		if bank_created == "Yes" and not has_bank:
			continue
		if bank_created == "No" and has_bank:
			continue
		out.append(
			{
				"employee": e.name,
				"employee_name": e.employee_name,
				"grade": e.grade,
				"branch": e.branch,
				"company": e.company,
				"currency": frappe.get_cached_value("Company", e.company, "default_currency"),
				"date_joined": joined,
				"eligible": bool(res["eligible"]),
				"eligibility_status": res["eligibility_status"],
				"eligibility_reason": res["message"] or _("All configured Passage Benefit conditions are satisfied."),
				"block_reason": res["block_reason"],
				"eligibility_mode": res["eligibility_mode"],
				"eligibility_rules": res["rules"],
				"eligible_from": res["eligible_from_date"],
				"service_years": res["service_years"],
				"basic_salary": res["salary"],
				"bank_created": has_bank,
				"current_balance": banks.get(e.name, {}).get("current_balance"),
				"bank_status": banks.get(e.name, {}).get("status") or _("Existing bank"),
			}
		)
	return out


@frappe.whitelist()
def create_banks(employees, opening_date=None, opening_balance=0):
	"""Create a PB Bank for each eligible employee that has none. Idempotent."""
	_check_initialisation_access()
	if isinstance(employees, str):
		employees = frappe.parse_json(employees) if employees.strip().startswith("[") else [employees]
	requested_opening_date = getdate(opening_date) if opening_date else None
	opening_balance = flt(opening_balance)
	settings = frappe.get_cached_doc("Passage Benefit Settings")
	if opening_balance < 0 and not settings.get("allow_negative_balance"):
		frappe.throw(_("Opening Balance cannot be negative."))

	created, skipped = [], []
	for emp in employees:
		frappe.db.sql("SELECT name FROM `tabEmployee` WHERE name=%s FOR UPDATE", emp)
		if frappe.db.exists("Passage Benefit Bank", emp):
			skipped.append({"employee": emp, "reason": "bank already exists"})
			continue
		reference_date = requested_opening_date or getdate(today())
		res = evaluate_eligibility(emp, reference_date)
		if not res["eligible"]:
			skipped.append({"employee": emp, "reason": res["message"] or _("Employee is not eligible.")})
			continue
		employee_opening_date = requested_opening_date or getdate(res["eligible_from_date"])
		if employee_opening_date < getdate(res["eligible_from_date"]):
			skipped.append(
				{
					"employee": emp,
					"reason": _("Opening Date cannot be before Eligible From Date {0}.").format(
						res["eligible_from_date"]
					),
				}
			)
			continue
		savepoint = f"pb_bank_{len(created) + len(skipped)}"
		frappe.db.savepoint(savepoint)
		try:
			bank = frappe.get_doc(
				{
					"doctype": "Passage Benefit Bank",
					"employee": emp,
					"company": frappe.db.get_value("Employee", emp, "company"),
					"opening_date": employee_opening_date,
					"opening_balance": opening_balance,
					"eligible_from_date": res["eligible_from_date"],
				}
			)
			bank.insert(ignore_permissions=True)
			created.append(bank.name)
		except Exception as exc:
			frappe.db.rollback(save_point=savepoint)
			skipped.append({"employee": emp, "reason": str(exc)})
	return {"created": created, "skipped": skipped}
