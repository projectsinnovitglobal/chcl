frappe.query_reports["MBC Employee Leave Balance"] = {
	filters: [
		{fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company", default: frappe.defaults.get_user_default("Company")},
		{fieldname: "leave_year", label: __("Leave Year"), fieldtype: "Int", default: new Date().getFullYear()},
		{fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee", get_query: () => ({filters: {company: frappe.query_report.get_filter_value("company")}})},
		{fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department"},
		{fieldname: "leave_code", label: __("Leave Code"), fieldtype: "Data"},
		{fieldname: "as_at_date", label: __("As At Date"), fieldtype: "Date"},
	],
};
